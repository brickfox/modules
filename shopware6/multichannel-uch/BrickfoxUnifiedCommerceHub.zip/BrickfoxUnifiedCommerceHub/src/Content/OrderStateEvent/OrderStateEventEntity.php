<?php

declare(strict_types=1);

namespace Brickfox\UnifiedCommerceHub\Content\OrderStateEvent;

use Shopware\Core\Checkout\Order\OrderEntity;
use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityIdTrait;

class OrderStateEventEntity extends Entity
{
    use EntityIdTrait;

    public const EVENT_TYPE_ORDER_STATUS_UPDATED = "order_status_updated";
    public const EVENT_TYPE_DELIVERY_STATUS_UPDATED = "delivery_status_updated";

    protected string $status;

    protected string $type;
    protected string $orderId;
    protected string $salesChannelId;

    protected ?OrderEntity $order;

    public function getOrder(): ?OrderEntity
    {
        return $this->order;
    }

    public function setOrder(?OrderEntity $order): void
    {
        $this->order = $order;
    }

    public function getSalesChannelId(): string
    {
        return $this->salesChannelId;
    }

    public function setSalesChannelId(string $salesChannelId): void
    {
        $this->salesChannelId = $salesChannelId;
    }

    public function getStatus(): string
    {
        return $this->status;
    }

    public function setStatus(string $status): void
    {
        $this->status = $status;
    }

    public function getType(): string
    {
        return $this->type;
    }

    public function setType(string $type): void
    {
        $this->type = $type;
    }

    public function getOrderId(): string
    {
        return $this->orderId;
    }

    public function setOrderId(string $orderId): void
    {
        $this->orderId = $orderId;
    }
}
