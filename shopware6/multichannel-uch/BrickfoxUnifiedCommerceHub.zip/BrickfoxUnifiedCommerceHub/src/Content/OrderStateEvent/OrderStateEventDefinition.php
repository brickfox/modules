<?php

declare(strict_types=1);

namespace Brickfox\UnifiedCommerceHub\Content\OrderStateEvent;

use Shopware\Core\Checkout\Order\OrderDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Field;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;

class OrderStateEventDefinition extends EntityDefinition
{
    public const ENTITY_NAME = 'brickfox_order_state_event';

    public function getEntityName(): string
    {
        return self::ENTITY_NAME;
    }

    public function getEntityClass(): string
    {
        return OrderStateEventEntity::class;
    }

    public function getCollectionClass(): string
    {
        return OrderStateEventCollection::class;
    }

    protected function defineFields(): FieldCollection
    {
        return new FieldCollection([
            (new Field\IdField('id', 'id'))->addFlags(new Flag\PrimaryKey()),
            (new Field\StringField('event_type', 'type'))->addFlags(new Flag\Required()),
            (new Field\StringField('status', 'status'))->addFlags(new Flag\Required()),
            (new Field\IdField('order_id', 'orderId'))->addFlags(new Flag\ApiAware(), new Flag\Required()),
            (new Field\IdField('sales_channel_id', 'salesChannelId'))->addFlags(new Flag\ApiAware(), new Flag\Required()),
            new Field\ManyToOneAssociationField('order', 'order_id', OrderDefinition::class),
        ]);
    }
}
