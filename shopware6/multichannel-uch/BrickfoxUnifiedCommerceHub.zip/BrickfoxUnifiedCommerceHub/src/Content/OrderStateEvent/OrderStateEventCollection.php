<?php

declare(strict_types=1);

namespace Brickfox\UnifiedCommerceHub\Content\OrderStateEvent;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

/**
 * @extends EntityCollection<OrderStateEventEntity>
 */
class OrderStateEventCollection extends EntityCollection
{
    protected function getExpectedClass(): string
    {
        return OrderStateEventEntity::class;
    }
}
