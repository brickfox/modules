<?php

declare(strict_types=1);

namespace Brickfox\UnifiedCommerceHub\Content\ProductEvent;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

/**
 * @extends EntityCollection<ProductEventEntity>
 */
class ProductEventCollection extends EntityCollection
{
    protected function getExpectedClass(): string
    {
        return ProductEventEntity::class;
    }
}
