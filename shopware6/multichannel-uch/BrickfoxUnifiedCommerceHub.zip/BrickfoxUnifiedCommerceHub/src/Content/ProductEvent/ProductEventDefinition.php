<?php

declare(strict_types=1);

namespace Brickfox\UnifiedCommerceHub\Content\ProductEvent;

use Shopware\Core\Framework\DataAbstractionLayer\EntityDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;
use Shopware\Core\Framework\DataAbstractionLayer\Field;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag;

class ProductEventDefinition extends EntityDefinition
{
    public const ENTITY_NAME = 'brickfox_product_event';

    public function getEntityName(): string
    {
        return self::ENTITY_NAME;
    }

    public function getEntityClass(): string
    {
        return ProductEventEntity::class;
    }

    public function getCollectionClass(): string
    {
        return ProductEventCollection::class;
    }

    protected function defineFields(): FieldCollection
    {
        return new FieldCollection([
            (new Field\IdField('id', 'id'))->addFlags(new Flag\PrimaryKey()),
            (new Field\StringField('event_type', 'type'))->addFlags(new Flag\Required()),
            (new Field\IdField('product_id', 'productId'))->addFlags(new Flag\ApiAware(), new Flag\Required()),
        ]);
    }
}
