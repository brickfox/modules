<?php

declare(strict_types=1);

namespace Brickfox\UnifiedCommerceHub\Content\ProductEvent;

use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityIdTrait;

class ProductEventEntity extends Entity
{
    use EntityIdTrait;

    public const EVENT_TYPE_UPDATED = "updated";
    public const EVENT_TYPE_DELETED = "deleted";

    protected string $type;
    protected string $productId;

    /**
     * @return string
     */
    public function getType(): string
    {
        return $this->type;
    }

    /**
     * @param string $type
     */
    public function setType(string $type): void
    {
        $this->type = $type;
    }

    /**
     * @return string
     */
    public function getProductId(): string
    {
        return $this->productId;
    }

    /**
     * @param string $productId
     */
    public function setProductId(string $productId): void
    {
        $this->productId = $productId;
    }
}
