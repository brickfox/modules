<?php

declare(strict_types=1);

namespace Brickfox\UnifiedCommerceHub;

use Shopware\Core\Framework\Plugin;

class BrickfoxUnifiedCommerceHub extends Plugin
{
}
