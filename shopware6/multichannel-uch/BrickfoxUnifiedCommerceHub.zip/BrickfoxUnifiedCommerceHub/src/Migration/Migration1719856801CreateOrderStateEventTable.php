<?php

declare(strict_types=1);

namespace Brickfox\UnifiedCommerceHub\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

class Migration1719856801CreateOrderStateEventTable extends MigrationStep
{
    public function getCreationTimestamp(): int
    {
        return 1719856801;
    }

    public function update(Connection $connection): void
    {
        $connection->executeStatement(
            "create table brickfox_order_state_event
(
    id                 binary(16)  not null,
    order_id           binary(16)  not null,
    sales_channel_id   binary(16)  not null,
    event_type         VARCHAR(255) not null,
    status             VARCHAR(255) not null,
    created_at         datetime(3) null,
    updated_at         datetime(3) null,
    primary key (id)
)
    collate = utf8mb4_unicode_ci;
"
        );
    }

    public function updateDestructive(Connection $connection): void
    {
    }
}
