<?php

declare(strict_types=1);

namespace Brickfox\UnifiedCommerceHub\Subscriber;

use Brickfox\UnifiedCommerceHub\Content\OrderStateEvent\OrderStateEventEntity;
use Shopware\Core\Checkout\Order\Event\OrderStateMachineStateChangeEvent;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class OrderStateSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private readonly EntityRepository $orderStateEventRepository
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            'state_enter.order.state.completed' => 'onOrderStateChange',
            'state_enter.order.state.in_progress' => 'onOrderStateChange',
            'state_enter.order_delivery.state.returned' => 'onOrderStateChange',
            'state_enter.order_delivery.state.returned_partially' => 'onOrderStateChange',
            'state_enter.order_delivery.state.shipped_partially' => 'onOrderStateChange',
            'state_enter.order_delivery.state.shipped' => 'onOrderStateChange',
        ];
    }

    public function onOrderStateChange(OrderStateMachineStateChangeEvent $event): void
    {
        $eventNameParts = explode('.', $event->getName());
        $entity = $eventNameParts[1];
        $stateName = $eventNameParts[3];

        $eventType = null;

        switch ($entity) {
            case 'order':
                $eventType = OrderStateEventEntity::EVENT_TYPE_ORDER_STATUS_UPDATED;
                break;
            case 'order_delivery':
                $eventType = OrderStateEventEntity::EVENT_TYPE_DELIVERY_STATUS_UPDATED;
                break;
        }

        if ($eventType === null) {
            return;
        }

        $orderStateEvents[] = [
            'orderId' => $event->getOrderId(),
            'salesChannelId' => $event->getSalesChannelId(),
            'type' => $eventType,
            'status' => $stateName,
        ];

        $this->orderStateEventRepository->create($orderStateEvents, $event->getContext());
    }
}
