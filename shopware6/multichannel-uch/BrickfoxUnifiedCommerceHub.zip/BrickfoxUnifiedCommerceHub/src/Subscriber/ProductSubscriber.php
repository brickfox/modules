<?php

declare(strict_types=1);

namespace Brickfox\UnifiedCommerceHub\Subscriber;

use Brickfox\UnifiedCommerceHub\Content\ProductEvent\ProductEventEntity;
use Shopware\Core\Content\Product\ProductEvents;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Event\EntityDeletedEvent;
use Shopware\Core\Framework\DataAbstractionLayer\Event\EntityWrittenEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class ProductSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private EntityRepository $productEventRepository
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            ProductEvents::PRODUCT_WRITTEN_EVENT => 'onProductEvent',
            ProductEvents::PRODUCT_DELETED_EVENT => 'onProductEvent',
        ];
    }

    public function onProductEvent(EntityWrittenEvent|EntityDeletedEvent $event): void
    {
        $productEvents = [];
        foreach ($event->getIds() as $id) {
            $eventType = match (get_class($event)) {
                EntityWrittenEvent::class => ProductEventEntity::EVENT_TYPE_UPDATED,
                EntityDeletedEvent::class => ProductEventEntity::EVENT_TYPE_DELETED,
            };

            $productEvents[] = [
                'productId' => $id,
                'type' => $eventType
            ];
        }

        $this->productEventRepository->create($productEvents, $event->getContext());
    }
}
