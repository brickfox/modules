<?php

namespace BrickfoxMultichannel\Entity\ProductToDelete;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

class BrickfoxProductToDeleteEntityCollection extends EntityCollection
{
    protected function getExpectedClass(): string
    {
        return BrickfoxProductToDeleteEntity::class;
    }
}