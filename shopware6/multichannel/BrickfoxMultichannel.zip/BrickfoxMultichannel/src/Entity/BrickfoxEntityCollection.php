<?php declare(strict_types=1);

namespace BrickfoxMultichannel\Entity;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

class BrickfoxEntityCollection extends EntityCollection
{
    public function getElements(): array
    {
        return ["test" => "this is elements from EntityCollection"];
    }

    protected function getExpectedClass(): string
    {
        return BrickfoxEntity::class;
    }
}
