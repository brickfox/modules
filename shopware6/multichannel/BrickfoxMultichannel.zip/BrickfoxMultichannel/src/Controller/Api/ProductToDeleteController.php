<?php

declare(strict_types=1);

namespace BrickfoxMultichannel\Controller\Api;

use Exception;
use BrickfoxMultichannel\Service\ProductToDelete;
use Shopware\Core\Framework\Context;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Attribute\Route;

class ProductToDeleteController extends AbstractController
{
    public function __construct(private ProductToDelete $productToDeleteService)
    {
    }

    #[Route('/api/swagMarkets/toDeleteProducts', name: 'get.to.delete.products', defaults: ['_routeScope' => ['api']], methods: ['GET'])]
    public function getToDeleteProducts(Context $context): JsonResponse
    {
        //ToDo change service call
        try {
            $result = $this->productToDeleteService->getToDeleteProducts($context);
            return new JsonResponse(['success' => true, 'data' => $result], 200);
        } catch (Exception $e) {
            return new JsonResponse(
                ['success' => false, 'data' => ['message' => $e->getMessage(),]]
            );
        }
    }

    #[Route('/api/swagMarkets/toDeleteProducts', name: 'delete.to.delete.products', defaults: ['_routeScope' => ['api']], methods: ['DELETE'])]
    public function deleteToDeleteProducts(Context $context, Request $request): JsonResponse
    {
        try {
            return new JsonResponse([
                'success' => $this->productToDeleteService->removeToDeleteProducts(
                    $context,
                    $request->request->all()
                )
            ]);
        } catch (Exception $e) {
            return new JsonResponse(
                ['success' => false, 'data' => ['message' => $e->getMessage(),]]
            );
        }
    }
}