<?php

namespace BrickfoxMultichannel\Controller;


use BrickfoxMultichannel\Service\BrickfoxMultichannelService;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class BrickfoxMultichannelController extends AbstractController
{
    public function __construct(
        private BrickfoxMultichannelService $service
    ) {
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    #[Route('/api/brickfox-multichannel/getConfig', name: 'brickfox.multichannel.settings', defaults: ['_routeScope' => ['api']], methods: ['GET'])]
    public function getConfiguration(): JsonResponse
    {
        $response = $this->service->getConfiguration();

        return new JsonResponse(
            $response
            , 200
        );
        // TODO: Implement proper error and exception handling
    }

    #[Route('/api/brickfox-multichannel/checkClient', name: 'brickfox.multichannel.checkClient', defaults: ['_routeScope' => ['api']], methods: ['POST'])]
    public function checkClient(Request $request): JsonResponse
    {
        $clientApiUrl = $request->get('clientApiUrl') ?? null;
        $clientApiKey = $request->get('clientApiKey') ?? null;

        $response = $this->service->checkClient($clientApiKey, $clientApiUrl);

        try {
            if ($response->success) {
                return new JsonResponse([
                    'success' => true,
                    'data' => [
                        "message" => $response,
                    ],
                ], 200);
            }

            return new JsonResponse([
                'success' => false,
                'data' => [
                    'message' => 'Something went wrong while client check.'
                ]
            ], 500);
        } catch (\Exception $e) {
            // TOOD: Implement logging
            return new JsonResponse([
                "error" => true,
                'data' => [
                    "message" => "Customer was not found",
                ],
            ], 404);
        }
    }
}
