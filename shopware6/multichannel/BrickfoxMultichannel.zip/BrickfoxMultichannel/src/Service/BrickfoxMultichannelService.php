<?php declare(strict_types=1);

namespace BrickfoxMultichannel\Service;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\FetchMode;
use GuzzleHttp\Client;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;

class BrickfoxMultichannelService
{
    /**
     * @var EntityRepository
     */
    private $brickfoxRepository;

    /**
     * @var Client
     */
    private $client;

    /**
     * @var Connection
     */
    private $connection;

    /**
     * BrickfoxMultichannelService constructor.
     *
     * @param  EntityRepository  $brickfoxRepository
     * @param  Client  $client
     *
     * @return void
     */
    public function __construct(
        EntityRepository $brickfoxRepository,
        Connection $connection
    ) {
        $this->brickfoxRepository = $brickfoxRepository;
        $this->client             = new Client();
        $this->connection         = $connection;
    }

    /**
     * @return array|null
     */
    public function getConfiguration(): ?array
    {
        $query = $this->connection->createQueryBuilder();

        $query->select('LOWER(HEX(id)) as id, `key`, value')
            ->from('brickfox');

        $result = $query->execute()->fetchAllAssociative();

        return (count($result) > 0) ? $result : null;
    }

    /**
     * @param  string  $apiKey
     * @param  string  $apiUrl
     *
     * @return mixed
     */
    public function checkClient(
        string $apiKey,
        string $apiUrl
    ) {
        try {
            $response = $this->client->get($apiUrl . '/BFpublic/Rest/bfconfiguration', [
                'query' => [
                    'apikey' => $apiKey,
                ],
            ])->getBody()->getContents();

            if (json_decode($response)->success) {
                $this->saveClient([
                    ['key' => 'apiUrl', 'value' => $apiUrl],
                    ['key' => 'apiKey', 'value' => $apiKey],
                ]);
            }

            return json_decode($response);
        } catch(\ErrorException $e) {
            return $e->getMessage();
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param  array  $config
     */
    private function saveClient(array $config)
    {
        try {
            $this->brickfoxRepository->upsert($config,
                Context::createDefaultContext()
            );
        } catch (\Exception $e) {
            // TODO: implement logging
        }
    }
}
