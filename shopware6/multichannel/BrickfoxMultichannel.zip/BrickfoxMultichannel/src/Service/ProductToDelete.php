<?php declare(strict_types=1);

namespace BrickfoxMultichannel\Service;

use Exception;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\EntitySearchResult;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Sorting\FieldSorting;
use Shopware\Core\Framework\Context;


class ProductToDelete 
{
    /** @var EntityRepository */
    private $productToDeleteRepository;

    /**
     * @param EntityRepository $productToDeleteRepository
     */
    public function __construct(EntityRepository $productToDeleteRepository)
    {
        $this->productToDeleteRepository = $productToDeleteRepository;
    }

    /**
     * @param Context $context
     * @return array
     */
    public function getToDeleteProducts(Context $context): array
    {
        $criteria = new Criteria();
        $criteria->setLimit(500);
        $criteria->addSorting(new FieldSorting('createdAt', FieldSorting::ASCENDING));

        /** @var EntitySearchResult $toDeleteProducts */
        $toDeleteProducts = $this->productToDeleteRepository->search($criteria, $context);

        return $toDeleteProducts->jsonSerialize();
    }

    /**
     * @param Context $context
     * @param array $ids
     * @return bool
     */
    public function removeToDeleteProducts(Context $context, array $ids): bool
    {
        try {
            $this->productToDeleteRepository->delete($ids, $context);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
}