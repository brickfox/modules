<?php declare(strict_types=1);

namespace BrickfoxMultichannel;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Plugin;
use Shopware\Core\Framework\Plugin\Context\InstallContext;
use Shopware\Core\Framework\Plugin\Context\UninstallContext;

class BrickfoxMultichannel extends Plugin
{
    public function install(InstallContext $installContext): void
    {
    }

    public function uninstall(UninstallContext $uninstallContext): void
    {
        $connection = $this->container->get(Connection::class);
        $connection->executeStatement("DROP TABLE IF EXISTS `brickfox`");
        $connection->executeStatement("DROP TABLE IF EXISTS `bf_product_to_delete`");
    }
}
