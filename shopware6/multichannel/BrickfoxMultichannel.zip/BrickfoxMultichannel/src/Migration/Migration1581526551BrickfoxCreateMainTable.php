<?php declare(strict_types=1);

namespace BrickfoxMultichannel\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

class Migration1581526551BrickfoxCreateMainTable extends MigrationStep
{
    /**
     * @return integer
     */
    public function getCreationTimestamp(): int
    {
        return 1581526551;
    }

    /**
     * @param Connection $connection
     * @return void
     */
    public function update(Connection $connection): void
    {
        $query = <<<SQL
                CREATE TABLE `brickfox` (
  `id` BINARY(16) NOT NULL,
  `key` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` DATETIME(3) NOT NULL,
  `updated_at` DATETIME(3) NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brickfox_key_IDX` (`key`) USING BTREE,
  KEY `brickfox_id_IDX` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL;

        $connection->executeStatement($query);
    }

    /**
     * @param Connection $connection
     * @return void
     */
    public function updateDestructive(Connection $connection): void
    {
        $connection->executeStatement("DROP TABLE IF EXISTS brickfox");
    }
}
