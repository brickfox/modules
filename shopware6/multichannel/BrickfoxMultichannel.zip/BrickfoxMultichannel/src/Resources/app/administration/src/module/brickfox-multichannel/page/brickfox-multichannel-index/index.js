import template from './brickfox-multichannel-index.html.twig';
import './brickfox-multichannel-index.scss';

const { Component, Application } = Shopware;

Component.register('brickfox-multichannel-index', {
    template,
    inject: ['loginService'],
    metaInfo() {
        return {
            title: this.$createTitle()
        }
    },
    data() {
        return {
            apiKey: null,
            apiUrl: null,
            isRegistered: false,
            isChecking: false,
            error: null,
            isChanged: true
        }
    },
    computed: {
        languageId() {
          return Shopware.State.get('session').currentLocale
        }
    },
    created() {
        this.getConfig();
    },
    methods: {
        getConfig() {
            Application.getContainer('init')
                .httpClient
                .get(
                    '/brickfox-multichannel/getConfig',
                    {
                        headers: {
                            Authorization: `Bearer ${this.loginService.getToken()}`,
                            'Content-Type': 'application/json',
                        }
                    }
                )
                .then(response => {
                    if(response.data.length > 0) {
                        const apiUrl = response.data.find(x => x.key == 'apiUrl');
                        const apiKey = response.data.find(x => x.key == 'apiKey');

                        this.apiUrl = apiUrl.value;
                        this.apiKey = apiKey.value;
                        this.isRegistered = true;
                        this.error = null;
                    }
                })
                .catch(error => {
                    this.error = 'brickfox-multichannel.form.error';
                    this.isRegistered = false;
                });
        },
        saveConfig() {
            this.isChecking = true;

            Application.getContainer('init')
                .httpClient
                .post(
                    '/brickfox-multichannel/checkClient',
                    {
                        'clientApiKey': this.apiKey,
                        'clientApiUrl': this.apiUrl
                    },
                    {
                        headers: {
                            Authorization: `Bearer ${this.loginService.getToken()}`,
                            'Content-Type': 'application/json'
                        }
                    }
                )
                .then(response => {
                    this.isChecking = false;
                    this.isRegistered = true;
                    this.error = null;
                })
                .catch(error => {
                    this.error = 'brickfox-multichannel.form.error'
                    this.isChecking = false;
                    this.isRegistered = false;
                });
        },
    }
});
