import './page/brickfox-multichannel-index';
import deDE from './snippet/de-DE';
import enGB from './snippet/en-GB';

const {Module} = Shopware;

Module.register('brickfox-multichannel', {
    type: 'plugin',
    name: 'multichannel',
    title: 'brickfox-multichannel.general.title',
    description: 'Schnellzugriff auf die beliebtesten Schnittstellen',
    color: '#82c213',
    icon: 'default-action-share',
    snippets: {
        'de-DE': deDE,
        'en-GB': enGB
    },
    routes: {
        index: {
            component: 'brickfox-multichannel-index',
            path: 'index'
        }
    },
    navigation: [
        {
            id: 'brickfox',
            label: 'brickfox-multichannel.menu.mainTitle',
            color: '#82c213',
            path: 'brickfox.multichannel.index',
            icon: 'default-action-share',
            parent: 'sw-catalogue'
        },
        {
            label: 'brickfox-multichannel.menu.mainChildTitle',
            color: '#82c213',
            path: 'brickfox.multichannel.index',
            icon: 'default-basic-plus-circle',
            parent: 'brickfox'
        }
    ]
});
