import './module/brickfox-multichannel';
