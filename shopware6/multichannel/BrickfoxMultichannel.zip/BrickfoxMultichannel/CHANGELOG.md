# Changelog
## 1.1.0
- Adjusted functionality for getting Plugin compatible with SW6.4.
- Add functionality to publish deleted articles to the marketplaces.

## 1.2.0
- Compatibility to shopware 6.4.20.2 and 6.4.5.0

## 1.2.1
- Update administration js to display menu

## 1.2.2
- Compatibility to Shopware 6.5.*