<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 14.08.18
 * Time: 13:38
 */

namespace bfox\multichannel\wrapper\Core;


class OxidRegistry extends OxidRegistry_parent
{

}