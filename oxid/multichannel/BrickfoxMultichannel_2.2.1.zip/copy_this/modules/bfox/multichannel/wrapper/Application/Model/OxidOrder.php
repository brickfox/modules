<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 23.08.18
 * Time: 15:49
 */

namespace bfox\multichannel\wrapper\Application\Model;


class OxidOrder extends OxidOrder_parent
{
    public function newOrderNumber()
    {
        return oxNew(\OxidEsales\Eshop\Core\Counter::class)->getNext($this->_getCounterIdent());
    }
}