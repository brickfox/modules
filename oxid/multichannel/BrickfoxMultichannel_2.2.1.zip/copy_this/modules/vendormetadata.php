<?php
/**
 * Brickfox Multichannel e-commerce. Module for Oxid 6.
 * http://www.brickfox.de
 */

/**
 * Metadata version
 */
$sVendorMetadataVersion = '1.0';
