<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 14.08.18
 * Time: 14:09
 */

namespace bfox\multichannel\wrapper\Core;


class OxidConfig extends OxidConfig_parent
{

}