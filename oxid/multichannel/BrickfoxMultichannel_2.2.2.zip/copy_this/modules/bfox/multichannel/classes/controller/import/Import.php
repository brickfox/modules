<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 24.08.18
 * Time: 13:01
 */

namespace bfox\multichannel\classes\controller\import;


class Import
{

}