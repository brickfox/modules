<?php
/**
 * ConfigurationException
 *
 *
 */


namespace bfox\multichannel\classes\exception;


class ConfigurationException extends \Exception
{
}
