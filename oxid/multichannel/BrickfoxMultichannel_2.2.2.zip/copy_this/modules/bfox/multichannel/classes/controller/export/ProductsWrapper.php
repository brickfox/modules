<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 11.09.18
 * Time: 17:25
 */

namespace bfox\multichannel\classes\controller\export;

use bfox\multichannel\classes\model as Models;
use bfox\multichannel\classes\util as Utils;


class ProductsWrapper extends Wrapper
{
    /** @var array $configCurrency ; */
    protected $configCurrency;

    /**
     * get Currencies
     *
     * @param \OxidEsales\Eshop\Application\Model\Article $articleModel
     * @return array
     */
    protected function getCurrencies(\OxidEsales\Eshop\Application\Model\Article $articleModel)
    {
        $currencies = [];
        $currency   = [];
        $isNet      = false;

        $price = $articleModel->getPrice();
        $fallbackPrice = 0;

        if ($price) {
            $currency["Price"] = $fallbackPrice = $price->getPrice();
            $isNet             = $price->isNettoMode();
        }

        $TPrice = $articleModel->getTPrice();
        if ($TPrice) {
            $currency["Rrp"] = $TPrice->getPrice();
        }

        //Scale Prices (for the moment only gets Scale prices in Variations)
        $scalePrices = $this->getScalePrices($articleModel->getAmountPriceList(), $price->getPrice());
        if (count($scalePrices) > 0) {
            $currency["ScalePrices"] = $scalePrices;
        }

        $currencies["Currency:code:" . $this->configCurrency->name . ":net:" . var_export($isNet, true)] = $currency;

        $additionalCurrencies = Utils\OxidRegistry::getModuleConfig('aOxArticleColumnsCurrencies');

        foreach ($additionalCurrencies as $columnNameCurrency => $currencyCode) {
            $columnName = "oxarticles__" . strtolower($columnNameCurrency);
            $price = $articleModel->$columnName->value;
            $currency = [];

            if ($price > 0) {
                $currency["Price"] = $price;
            } else {
                $currency["Price"] = $fallbackPrice;
            }

            $currencies["Currency:code:" . $currencyCode . ":net:" . var_export($isNet, true)] = $currency;
        }

        return $currencies;
    }

    /**
     * @param \OxidEsales\Eshop\Application\Model\Article $articleModel
     * @return array
     */
    protected function getPackage(\OxidEsales\Eshop\Application\Model\Article $articleModel)
    {
        return [
            "Weight:unit:g"  => $articleModel->getWeight() * 1000,
            "Width:unit:mm"  => $articleModel->getWidth() * 1000,
            "Length:unit:mm" => $articleModel->getLength() * 1000,
            "Height:unit:mm" => $articleModel->getHeight() * 1000
        ];
    }

    protected function getSpecialPrices(\OxidEsales\Eshop\Application\Model\Article $articleModel)
    {

    }

    /**
     * @param $amountPrices
     * @param int $unitPrice
     * @return array
     *
     * The calls here for getRawValue() dont need to be checked because
     * the table fields used here have default values in the database
     */
    protected function getScalePrices($amountPrices, $unitPrice = 0)
    {
        $scalePrices = [];
        $count       = 0;

        foreach ($amountPrices as $amountPrice) {
            $scalePrice = [];

            $absolute = $amountPrice->oxprice2article__oxaddabs->getRawValue();
            $percent  = $amountPrice->oxprice2article__oxaddperc->getRawValue();

            if ((float)$absolute > 0) {
                $price = $absolute;
            } else {
                $price = $unitPrice - ($unitPrice * $percent / 100);
            }

            $scalePrice["Quantity"]              = $amountPrice->oxprice2article__oxamount->getRawValue();
            $scalePrice["Price"]                 = $price;
            $scalePrices["ScalePrice:" . $count] = $scalePrice;
            $count++;
        }

        return $scalePrices;
    }

    /**
     * @param int $flag
     * @param int $stock
     * @return array
     */
    public function getAvailabilityAndStockInfo($flag, $stock)
    {
        switch($flag)
        {
            case 1 :
                $return = array(
                    'available'       => 1,
                    'thirdPartyStock' => 0,
                    'deliveryTime'    => ($stock > 0) ? 'Standard' : 'Relayed',
                );
                break;
            case 4 :
                $return = array(
                    'available'       => 1,
                    'thirdPartyStock' => 1,
                    'deliveryTime'    => 'ThirdPartyStandard',
                );
                break;
            case 2 :
            case 3 :
            default :
                $return = array(
                    'available'       => ($stock > 0) ? 1 : 0,
                    'thirdPartyStock' => 0,
                    'deliveryTime'    => 'Standard',
                );
                break;
        }

        return $return;
    }

    /**
     * @param $oxStock
     * @return string
     */
    protected function getAvailabilityByStock($oxStock)
    {
        if ($oxStock > 0) {
            return "1";
        }

        return "0";
    }
}