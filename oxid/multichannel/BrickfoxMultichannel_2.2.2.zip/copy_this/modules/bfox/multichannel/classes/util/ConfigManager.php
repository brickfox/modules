<?php
/**
 * ConfigManager
 */

namespace bfox\multichannel\classes\util;

use bfox\multichannel\wrapper\Core as OxidCore;

class ConfigManager extends OxidCore\OxidConfig
{

}