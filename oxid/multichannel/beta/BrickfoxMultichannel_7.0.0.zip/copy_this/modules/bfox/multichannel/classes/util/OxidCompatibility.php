<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 24.08.17
 * Time: 12:27
 *
 * Class to provide control for the functionalities and compatibilities for OXID 7
 * to check for more look at https://docs.oxid-esales.com/developer/en/7.0/
 */


namespace bfox\multichannel\classes\util;

use bfox\multichannel\wrapper\Core\OxidRegistry as Registry;

class OxidCompatibility
{


    const OXID_EE_VALUE = 'EE',
        OXID_PE_VALUE = 'PE',
        OXID_CE_VALUE = 'CE';


    /**
     *   Class Properties
     */

    private $supportGetInstance     = false;

    private $supportShops           = false;

    private $versionDescription;


    /**
     *   Class Methods
     */
    public function __construct()
    {

        $config = oxNew(Registry::class);

        $version    = oxNew(\OxidEsales\Eshop\Core\ShopVersion::class)->getVersion();
        $edition    =  oxNew(\OxidEsales\Facts\Facts::class)->getEdition();


        $this->versionDescription = $version . $edition;

        /**
         * OXID 7 compatibility settings
         * In OXID 7, all editions support multishop functionality
         * and getInstance() is not used anymore
         */
        if ($edition === self::OXID_EE_VALUE || $edition === self::OXID_PE_VALUE || $edition === self::OXID_CE_VALUE){
            // For OXID 7, all editions support shops
            $this->supportShops = true;

            // getInstance() is deprecated in OXID 7, always use false
            $this->supportGetInstance = false;
        }

    }


    /**
     *   Class getters and setters
     */

    public function getVersionDescription(){
        return $this->versionDescription;
    }

    public function getSupportShops(){
        return $this->supportShops;
    }

    public function getSupportGetInstance(){
        return $this->supportGetInstance;
    }

}
