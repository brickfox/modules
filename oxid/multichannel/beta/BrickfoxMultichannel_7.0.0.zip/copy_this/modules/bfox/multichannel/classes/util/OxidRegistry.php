<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 08.04.19
 * Time: 16:29
 */

namespace bfox\multichannel\classes\util;

use bfox\multichannel\classes\exception as Exceptions;
use OxidEsales\Eshop\Core\Registry;
use OxidEsales\EshopCommunity\Core\Di\ContainerFacade;
use OxidEsales\EshopCommunity\Internal\Framework\Module\Facade\ModuleSettingServiceInterface;

class OxidRegistry
{
    /**
     * #####################
     *  STATIC METHODS
     * #####################
     */

    /**
     * @return integer default language id
     */
    public static function getDefaultLanguageId()
    {
        return Registry::getConfig()->getConfigParam('sDefaultLang');
    }

    /**
     * @return array default language id
     */
    public static function getOxidLanguageArray()
    {
        return Registry::getLang()->getLanguageArray();
    }

    public static function setBaseLanguage($languageOxidId)
    {
        return Registry::getLang()->setBaseLanguage($languageOxidId);
    }

    public static function getBaseLanguage()
    {
        return Registry::getLang()->getBaseLanguage();
    }

    /**
     * @return string shop directory
     */
    public static function getShopDirectory()
    {
        return Registry::getConfig()->getConfigParam('sShopDir');
    }

    /**
     * @return string shop url
     */
    public static function getShopURL()
    {
        return Registry::getConfig()->getConfigParam('sShopURL');
    }

    public static function getLogsDir()
    {
        return Registry::getConfig()->getLogsDir();
    }

    /**
     * @return int shopId
     */
    public static function getActiveShopId()
    {
        return Registry::getConfig()->getShopId();
    }

    /**
     * @param int $oxshopid
     *
     */
    public static function setActiveShopId($oxshopid)
    {
        Registry::getSession()->initNewSession();
        Registry::getConfig()->setShopId($oxshopid);
        Registry::getSession()->setVariable("shp", $oxshopid);
        Registry::getSession()->setVariable("actshop", $oxshopid);
        Registry::getSession()->setVariable('currentadminshop', $oxshopid);
    }

    public static function getOxidConfig($configKey, $default = null)
    {
        $result = Registry::getConfig()->getConfigParam($configKey);

        if (true === is_null($result)) {
            if($default !== null) {
                $result = $default;
            } else {
                throw oxNew(Exceptions\ConfigurationException::class, 'Invalid configuration key: ' . $configKey . ' for shop id: ' . self::getActiveShopId());
            }
        }

        return $result;
    }

    /**
     * @param string $configKey configuration key
     * @param string $moduleName module name
     * @param string $defaultValue Preferably send here the default defined at the metadata file for this field
     * @param string $defaultValueType We MUST send here the type defined at the metadata file for this field
     * @return mixed configuration value
     * @throws Exceptions\ConfigurationException configuration exception
     */
    public static function getModuleConfig($configKey, $moduleName = 'multichannel', $defaultValue = null, $defaultValueType = null)
    {
        $settingType = self::getSettingType($moduleName, $configKey);
        $moduleSettingService = ContainerFacade::get(ModuleSettingServiceInterface::class);

        $result = match ($settingType) {
            'bool' => $moduleSettingService->getBoolean($configKey, $moduleName),
            'aarr', 'array', 'arr' => $moduleSettingService->getCollection($configKey, $moduleName),
            'int' => $moduleSettingService->getInteger($configKey, $moduleName),
            default => $moduleSettingService->getString($configKey, $moduleName)->toString(),
        };

        if (true === is_null($result)) {
            echo PHP_EOL . oxNew(Exceptions\ConfigurationException::class, 'Invalid configuration key: ' . $configKey . ' for shop id: ' . self::getActiveShopId()) . PHP_EOL;
        }

        return $result;
    }

    /**
     * @param string $configKey configuration key
     * @param mixed $configValue configuration value
     * @param string $configType config type
     * @param string $moduleName module name
     */
    public static function saveModuleConfig($configKey, $configValue, $configType, $moduleName = 'multichannel')
    {
        Registry::getConfig()->saveShopConfVar($configType, $configKey, $configValue, self::getActiveShopId(), $moduleName);
    }

    public static function getMultishopArticleFields()
    {
        return Registry::getConfig()->getMultishopArticleFields();
    }

    public static function getUrlParameter($parameterName)
    {
        return Registry::getRequest()->getRequestParameter($parameterName);
    }

    public static function getActShopCurrencyObject()
    {
        return Registry::getConfig()->getActShopCurrencyObject();
    }

    public static function getListActiveShopIds()
    {
        return Registry::getConfig()->getShopIds();
    }

    private static function getSettingType(string $moduleId, string $configKey)
    {
        // Gehe 3 Ebenen nach oben von `classes/util/` zu `modules/bfox/saleschannel/`
        $metadataPath = realpath(__DIR__ . '/../../metadata.php');

        if (!$metadataPath || !file_exists($metadataPath)) {
            throw new \RuntimeException("metadata.php not found for module: $moduleId");
        }

        // aModule wird durch include gesetzt
        $aModule = [];
        include $metadataPath;

        $settingTypes = [];

        if (!empty($aModule['settings']) && is_array($aModule['settings'])) {
            foreach ($aModule['settings'] as $setting) {
                $name = $setting['name'] ?? null;
                $type = $setting['type'] ?? 'str';
                if ($name) {
                    $settingTypes[$name] = $type;
                }
            }
        }

        return $settingTypes[$configKey] ?? 'str';
    }
}
