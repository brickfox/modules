<?php

namespace bfox\multichannel\classes\controller\transfer;

use bfox\multichannel\classes\util\LogManager;

class Sftp
{
    private string $host;
    private string $user;
    private string $password;
    private ?string $directory = null;
    private int $port = 22;
    public string $error = '';

    /** @var resource|null */
    private $sshConnection = null;
    /** @var resource|null */
    private $sftp = null;

    public function __construct(string $host, string $user, string $password, string $directory = null, $port = null)
    {
        $this->host = $host;
        $this->user = $user;
        $this->password = $password;
        if (!empty($directory)) {
            $this->directory = $directory;
        }
        if ($port !== null && (int)$port > 0) {
            $this->port = (int)$port;
        }

        $this->init();
    }

    public function __destruct()
    {
        $this->close();
    }

    public function isConnected(): bool
    {
        return $this->sshConnection !== null && $this->sftp !== null;
    }

    private function init(): void
    {
        $this->debug('Sftp.init: start');
        if ($this->connect() && $this->login()) {
            $this->debug('Sftp.init: connected and authenticated');
            if (!empty($this->directory)) {
                $this->debug('Sftp.init: changeDirectory to ' . $this->directory);
                $this->changeDirectory($this->directory);
            }
        }
    }

    private function connect(): bool
    {
        if (empty($this->host)) {
            $this->error = 'SFTP-Host nicht konfiguriert';
            return false;
        }

        if (!function_exists('ssh2_connect')) {
            $this->error = 'PHP ssh2-Extension ist nicht verfügbar.';
            return false;
        }

        $this->sshConnection = @\ssh2_connect($this->host, $this->port);
        if (!$this->sshConnection) {
            $this->error = 'SFTP-Verbindung zu ' . $this->host . ' fehlgeschlagen.';
            return false;
        }

        $this->sftp = @\ssh2_sftp($this->sshConnection);
        if (!$this->sftp) {
            $this->error = 'SFTP-Subsystem konnte nicht initialisiert werden.';
            return false;
        }
        return true;
    }

    private function login(): bool
    {
        $ok = @\ssh2_auth_password($this->sshConnection, $this->user, $this->password);
        if (!$ok) {
            $this->error = 'Login ' . $this->user . '@' . $this->host . ' fehlgeschlagen.';
        }
        return (bool)$ok;
    }

    public function close(): void
    {
        $this->sftp = null;
        $this->sshConnection = null;
    }

    public function changeDirectory(string $directory): bool
    {
        // validate directory by stat
        $stat = @\ssh2_sftp_stat($this->sftp, $this->wrapPath($directory));
        if ($stat !== false) {
            $this->directory = rtrim($directory, '/');
            return true;
        }
        $this->error = 'konnte nicht in Verzeichnis ' . $directory . ' wechseln.';
        return false;
    }

    public function listDir(string $pattern): array
    {
        $dir = $this->directory ?: '.';
        $path = $this->wrapPath($dir);
        $handle = @opendir($path);
        if ($handle === false) {
            return [];
        }
        $items = [];
        while (($entry = readdir($handle)) !== false) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $items[] = $entry;
        }
        closedir($handle);

        if ($pattern && $pattern !== '*') {
            $regex = '/^' . str_replace(['*', '.'], ['.*', '\.'], $pattern) . '$/i';
            $items = array_values(array_filter($items, static function ($name) use ($regex) { return (bool)preg_match($regex, $name); }));
        }
        return $items;
    }

    public function getFile(string $localFile, string $remoteFile): bool
    {
        $remotePath = $this->wrapPath($this->resolvePath($remoteFile));
        $stream = @fopen($remotePath, 'r');
        if ($stream === false) {
            $this->error = 'Datei ' . $remoteFile . ' konnte nicht herunter geladen werden.';
            return false;
        }
        $local = @fopen($localFile, 'w');
        if ($local === false) {
            fclose($stream);
            $this->error = 'Lokale Datei ' . $localFile . ' konnte nicht erstellt werden.';
            return false;
        }
        $ok = stream_copy_to_stream($stream, $local) !== false;
        fclose($stream);
        fclose($local);
        if (!$ok) {
            $this->error = 'Datei ' . $remoteFile . ' konnte nicht herunter geladen werden.';
        }
        return $ok;
    }

    public function putFile(string $remoteFile, string $localFile, string $directory = null): bool
    {
        if ($directory !== null) {
            $this->createPath($directory, '');
        }
        $remotePath = $this->wrapPath($this->resolvePath($remoteFile));
        $stream = @fopen($remotePath, 'w');
        if ($stream === false) {
            $this->error = 'Datei ' . $remoteFile . ' konnte nicht hoch geladen werden.';
            return false;
        }
        $local = @fopen($localFile, 'r');
        if ($local === false) {
            fclose($stream);
            $this->error = 'Lokale Datei ' . $localFile . ' konnte nicht gelesen werden.';
            return false;
        }
        $ok = stream_copy_to_stream($local, $stream) !== false;
        fclose($local);
        fclose($stream);
        if (!$ok) {
            $this->error = 'Datei ' . $remoteFile . ' konnte nicht hoch geladen werden.';
        }
        return $ok;
    }

    public function deleteFile(string $file): bool
    {
        $ok = @unlink($this->wrapPath($this->resolvePath($file)));
        if (!$ok) {
            $this->error = 'Datei ' . $file . ' konnte nicht gelöscht werden.';
        }
        return (bool)$ok;
    }

    public function getCurrentDir(): string
    {
        return $this->directory ?: '.';
    }

    public function getFileSize(string $file): int
    {
        $stat = @\ssh2_sftp_stat($this->sftp, $this->wrapPath($this->resolvePath($file)));
        return $stat !== false && isset($stat['size']) ? (int)$stat['size'] : -1;
    }

    public function fileExists(string $file): bool
    {
        return $this->getFileSize($file) !== -1;
    }

    public function getFileMtime(string $file): int
    {
        $stat = @\ssh2_sftp_stat($this->sftp, $this->wrapPath($this->resolvePath($file)));
        return $stat !== false && isset($stat['mtime']) ? (int)$stat['mtime'] : -1;
    }

    public function makeDir(string $dir): bool
    {
        $ok = @mkdir($this->wrapPath($this->resolvePath($dir)));
        if (!$ok) {
            $this->error = 'Verzeichnis ' . $dir . ' konnte nicht angelegt werden.';
        }
        return (bool)$ok;
    }

    public function createPath(string $path, string $root): void
    {
        if (!empty($root)) {
            $tmpPath = str_replace($root, '', $path);
            if ($tmpPath !== false && strlen($tmpPath) > 0) {
                $path = $tmpPath;
            }
            $this->directory = rtrim($root, '/');
        }
        $parts = explode(DIRECTORY_SEPARATOR, trim($path, DIRECTORY_SEPARATOR));
        foreach ($parts as $directory) {
            $list = $this->listDir('');
            if (!in_array($directory, $list, true)) {
                $this->makeDir($directory);
            }
            $this->changeDirectory($this->resolvePath($directory));
        }
    }

    private function resolvePath(string $path): string
    {
        if ($this->directory) {
            return rtrim($this->directory, '/') . '/' . ltrim($path, '/');
        }
        return $path;
    }

    private function wrapPath(string $path): string
    {
        return 'ssh2.sftp://' . intval($this->sftp) . '/' . ltrim($path, '/');
    }

    private function debug(string $message): void
    {
        if (class_exists('bfox\\multichannel\\classes\\util\\LogManager')) {
            LogManager::getInstance()->debug($message);
        }
    }
}


