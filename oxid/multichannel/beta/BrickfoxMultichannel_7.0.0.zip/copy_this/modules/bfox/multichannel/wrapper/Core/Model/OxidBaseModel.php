<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 09.08.18
 * Time: 12:44
 */

namespace bfox\multichannel\wrapper\Core\Model;


class OxidBaseModel extends OxidBaseModel_parent
{

}