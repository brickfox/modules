<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 09.08.18
 * Time: 12:46
 */

namespace bfox\multichannel\wrapper\Core\Model;


class OxidMultiLanguageModel extends OxidMultiLanguageModel_parent
{

}