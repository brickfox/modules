<?php

/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 23.08.18
 * Time: 15:32
 */

namespace bfox\multichannel\classes\controller\import;

use bfox\multichannel\classes\exception\ConfigurationException;
use bfox\multichannel\classes\util as Utils;
use bfox\multichannel\classes\util\OxidRegistry;
use DomDocument;
use OxidEsales\Eshop as Oxid;
use OxidEsales\Eshop\Application\Model\UserPayment;
use OxidEsales\Eshop\Core\Registry;
use OxidEsales\EshopCommunity\Core\Di\ContainerFacade;
use OxidEsales\EshopCommunity\Internal\Utility\Email\EmailValidatorServiceBridgeInterface;
use SimpleXMLElement;


class Orders
{
    /**
     * @var string
     */
    private $_strShopOXID = null;

    /**
     * @var string
     */
    private $_sImportFile = null;

    /**
     * @var int
     */
    private $_iOrderCount = 0;

    /**
     * @var int
     */
    private $_iArticleCount = 0;

    /**
     * @var array
     */
    private $_reportData = [
        'Totals'  => 0,
        'Process' => 0
    ];

    /**
     * @var array
     */
    private $_aFailedOrders = [];

    /**
     * @var string
     */
    private $_sOrderStatus = '';

    private $_logManager;

    /**
     * @param string $strShopOXID
     * @param string $sFile
     * @param Utils\LogManager $logManager
     * @throws ConfigurationException
     */
    public function __construct($strShopOXID = null, $sFile = null, $logManager = null)
    {
        if (is_null($logManager)) {
            $this->_logManager = Utils\LogManager::getInstance();
        } else {
            $this->_logManager = $logManager;
        }

        if (!is_null($strShopOXID)) {
            $this->_strShopOXID = $strShopOXID;
        } else {
            $this->_reportData['Error'] = 'No Shop to work on!';

            return;
        }

        if (!$sFile) {
            $this->_reportData['Error'] = 'No file to import!';
        } else {
            $this->_sImportFile = $sFile;

            if (($xml = simplexml_load_file($this->_sImportFile)) == true) {
                // add total count to report
                $this->_reportData['Totals'] = (string)$xml->attributes()->count;

                foreach ($xml->xpath('Order') as $aOrderXML) {
                    if (!$sUserId = $this->_createUser($aOrderXML->BillingParty, (string)$aOrderXML->SalesChannelName)) {
                        $this->_aFailedOrders[(int)$aOrderXML->OrderId] = 'Could not save user';
                        continue;
                    }

                    if ($this->_checkOrderAlreadyImported((string)$aOrderXML->ExternOrderId, $this->_strShopOXID)) {
                        $this->_aFailedOrders[(int)$aOrderXML->OrderId] = 'Order already imported';
                        continue;
                    }

                    if (count($aOrderXML->xpath('OrderLines')) == 0) {
                        $this->_aFailedOrders[(int)$aOrderXML->OrderId] = 'Orderlines missing in XML';
                        continue;
                    }

                    if (($sOrderId = $this->_createOrder($aOrderXML, $sUserId)) != false) {
                        $this->_reportData['Process'] += 1;

                        // read order products
                        foreach ($aOrderXML->OrderLines->OrderLine as $aOrderedProduct) {
                            $this->_createOrderProduct($aOrderedProduct, $sOrderId);
                        }
                    } else {
                        $this->_aFailedOrders[(int)$aOrderXML->OrderId] = 'Order could not be saved';
                    }
                }
            } else {
                $this->_reportData['Error'] = 'Invalid XML in orderfile!';
            }
        }


        $this->_logManager->debug($this->_iOrderCount . ' orders with ' . $this->_iArticleCount . ' articles imported for shop-id');
        $this->_logManager->setLastRunDate(Utils\ConfigurationKeys::CONFIG_KEY_ORDERS_LAST_RUN);
    }

    /**
     * report array for xml export of report
     *
     * @return string
     */
    public function getReport()
    {
        $obj_dom  = new DomDocument ();
        $rootNode = $obj_dom->createElement('Orders');
        $obj_node = $obj_dom->createElement('Totals', $this->_reportData['Totals']);
        $rootNode->appendChild($obj_node);
        $obj_node = $obj_dom->createElement('Process', $this->_reportData['Process']);
        $rootNode->appendChild($obj_node);
        if (!empty($this->_reportData['Error'])) {
            $obj_node = $obj_dom->createElement('Error', $this->_reportData['Error']);
            $rootNode->appendChild($obj_node);
        }
        foreach ($this->_aFailedOrders as $orderId => $message) {
            $OrderNode = $obj_dom->createElement('Order');
            $obj_node  = $obj_dom->createElement('OrderId', $orderId);
            $OrderNode->appendChild($obj_node);
            $obj_node = $obj_dom->createElement('ErrorMessage', $message);
            $OrderNode->appendChild($obj_node);
            $rootNode->appendChild($OrderNode);
        }
        $obj_dom->appendChild($rootNode);
        $str_xml = $obj_dom->saveXML();
        unset ($obj_dom);

        simplexml_load_string($str_xml);

        return $str_xml;
    }

    /**
     * creates a ordered_articles entry in oxdb
     *
     * @param $ItemData
     * @param $sOrderId
     * @return mixed
     */
    private function _createOrderProduct($ItemData, $sOrderId)
    {
        $oArticle = oxNew(\OxidEsales\Eshop\Application\Model\Article::class);
        if (!$oArticle->load((string)$ItemData->ExternProductId)) {
            Utils\LogManager::getInstance()->debug("Could not Load Order Article. Check the ExternProductId: " . $ItemData->ExternProductId);
            return false;
        }

        $oOrderArticle = oxNew(\OxidEsales\Eshop\Application\Model\OrderArticle::class);

        $reduceStockOnOrderImoprt = (bool)Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_ORDERS_REDUCE_STOCK_ON_IMPORT,
            'multichannel', false, 'bool');

        if($reduceStockOnOrderImoprt === true) {
            $oOrderArticle->setIsNewOrderItem(true);
        }

        $oOrderArticle->setShopId($this->_strShopOXID);

        $oOrderArticle->oxorderarticles__oxorderid = new \OxidEsales\Eshop\Core\Field($sOrderId);
        $oOrderArticle->oxorderarticles__oxamount = new \OxidEsales\Eshop\Core\Field((int)$ItemData->QuantityOrdered);
        $oOrderArticle->oxorderarticles__oxartid = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->ExternProductId));
        $oOrderArticle->oxorderarticles__oxartnum = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->ItemNumber));
        $oOrderArticle->oxorderarticles__oxtitle = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->ProductName));
        $oOrderArticle->oxorderarticles__oxselvariant = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->ProductsVariationsName));
        $oOrderArticle->oxorderarticles__oxnetprice = new \OxidEsales\Eshop\Core\Field((float)$ItemData->ProductsPriceTotalNetto);
        $oOrderArticle->oxorderarticles__oxbrutprice = new \OxidEsales\Eshop\Core\Field((float)$ItemData->ProductsPriceTotal);
        $oOrderArticle->oxorderarticles__oxvatprice = new \OxidEsales\Eshop\Core\Field((float)$ItemData->VatPriceTotal);
        $oOrderArticle->oxorderarticles__oxvat = new \OxidEsales\Eshop\Core\Field((float)$ItemData->TaxRate);
        $oOrderArticle->oxorderarticles__oxprice = new \OxidEsales\Eshop\Core\Field((float)$ItemData->ProductsPriceNetto);
        $oOrderArticle->oxorderarticles__oxbprice = new \OxidEsales\Eshop\Core\Field((float)$ItemData->ProductsPrice);
        $oOrderArticle->oxorderarticles__oxnprice = new \OxidEsales\Eshop\Core\Field((float)$ItemData->ProductsPriceNetto);
        $oOrderArticle->oxorderarticles__oxordershopid = new \OxidEsales\Eshop\Core\Field($this->_strShopOXID);

        if ($oOrderArticle->save()) {
            $this->_iArticleCount++;
            $this->_writeOrderArticleImport($oOrderArticle->getId(), (int)$ItemData->OrderLineId, (string)$ItemData->ExternProductId, $sOrderId, (int)$ItemData->QuantityOrdered);

            return $oOrderArticle->getId();
        }

        return false;
    }

    /**
     * creates a user entry in oxdb
     *
     * @param SimpleXMLElement
     * @param string
     * @return string on success, false otherwise
     */
    private function _createUser($ItemData, $sSalesChannelName)
    {
        $oUser = oxNew(\OxidEsales\Eshop\Application\Model\User::class);
        $oUser->setShopId($this->_strShopOXID);

        // use e-mail address or generate unique username if no valid email is given
        $emailValidatorService = ContainerFacade::get(EmailValidatorServiceBridgeInterface::class);
        $strUsername = ($emailValidatorService->isEmailValid((string)$ItemData->EmailAddress) === true)
            ? (string)$ItemData->EmailAddress
            : $sSalesChannelName . '_' . Utils\SystemManager::generateUId() . '@' .
            str_replace('http://', '', $oUser->getConfig()->getConfigParam('sShopURL'));

        // set user object data
        $oUser->oxuser__oxrights    = new \OxidEsales\Eshop\Core\Field('user');
        $oUser->oxuser__oxactive    = new \OxidEsales\Eshop\Core\Field(1);
        $oUser->oxuser__oxshopid    = new \OxidEsales\Eshop\Core\Field($this->_strShopOXID);
        $oUser->oxuser__oxusername  = new \OxidEsales\Eshop\Core\Field($strUsername);
        $oUser->oxuser__oxsal       = new \OxidEsales\Eshop\Core\Field( Utils\SystemManager::utf8ToLocal((string)$ItemData->Title));
        $oUser->oxuser__oxfname     = new \OxidEsales\Eshop\Core\Field('');
        $oUser->oxuser__oxlname     = new \OxidEsales\Eshop\Core\Field( Utils\SystemManager::utf8ToLocal((string)$ItemData->Name));
        $oUser->oxuser__oxcompany   = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->Company));
        $oUser->oxuser__oxstreet    = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->Address));
        $oUser->oxuser__oxstreetnr  = new \OxidEsales\Eshop\Core\Field('');
        $oUser->oxuser__oxaddinfo   = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->AddressAdd));
        $oUser->oxuser__oxcity      = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->City));
        $oUser->oxuser__oxzip       = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->PostalCode));
        $oUser->oxuser__oxfon       = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->PhonePrivate));
        $oUser->oxuser__oxcountryid = new \OxidEsales\Eshop\Core\Field($this->getCountryIdByIsoCode($ItemData->CountryIso));

        $oUser->save();

        if (strlen($oUser->getId()) > 0) {
            return $oUser->getId();
        } else {
            return false;
        }
    }

    /**
     * creates a order entry in oxdb
     *
     * @param SimpleXMLElement
     * @param string
     * @return mixed
     * @throws ConfigurationException
     */
    private function _createOrder($ItemData, $sUserId)
    {
        $oOrder = oxNew(\OxidEsales\Eshop\Application\Model\Order::class);
        $oOrder->setShopId($this->_strShopOXID);

        if ($ItemData->Fba && (int)$ItemData->Fba != 0) {
            $this->_sOrderStatus =
                OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_ORDERS_FOLDER_FBA,'multichannel');
        } else {
            $this->_sOrderStatus = OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_ORDERS_FOLDER_NEW,'multichannel');
        }

        $oxOrderColumnName = Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_ORDERS_CUSTOMER_ORDER_NUMBER_COLUMN_NAME, 'multichannel', "");

        if(strlen($oxOrderColumnName) > 0) {
            $part1 = "oxorder__" . strtolower($oxOrderColumnName);
            $part2 = "value";

            $oOrder->$part1->$part2 = (string) $ItemData->CustomerId;
        }

        $oOrder->oxorder__oxtransstatus = new \OxidEsales\Eshop\Core\Field('OK');
        $oOrder->oxorder__oxfolder      = new \OxidEsales\Eshop\Core\Field($this->_sOrderStatus);
        $oOrder->oxorder__oxuserid      = new \OxidEsales\Eshop\Core\Field($sUserId);

        if(isset($ItemData->PaymentMethodsValues->transactionId)) {
            $oOrder->oxorder__oxtransid = new \OxidEsales\Eshop\Core\Field((string)$ItemData->PaymentMethodsValues->transactionId);
        }

        if ($this->paymentMethodExists((string)$ItemData->PaymentMethod)) {
            $oOrder->oxorder__oxpaymentid = new \OxidEsales\Eshop\Core\Field($this->createUserPayment($sUserId, (string)$ItemData->PaymentMethod));
        } else {
            $oOrder->oxorder__oxpaymentid = new \OxidEsales\Eshop\Core\Field((string)$ItemData->PaymentMethod);
        }

        $oOrder->oxorder__oxpaymenttype = new \OxidEsales\Eshop\Core\Field((string)$ItemData->PaymentMethod);
        $oOrder->oxorder__oxdeltype     = new \OxidEsales\Eshop\Core\Field((string)$ItemData->ShippingMethod);
        $oOrder->oxorder__oxorderdate   = new \OxidEsales\Eshop\Core\Field((string)$ItemData->OrderDate);
        $oOrder->oxorder__oxordernr     = new \OxidEsales\Eshop\Core\Field($this->getOrderNr((string)$ItemData->ExternOrderId, (string)$ItemData->OrderId, $oOrder));

        $oxOrderNumberColumnName = Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_ORDERS_ORDER_NUMBER_COLUMN_NAME, 'multichannel', "");

        if(strlen($oxOrderNumberColumnName) > 0) {
            $part1 = "oxorder__" . strtolower($oxOrderNumberColumnName);
            $part2 = "value";

            $oOrder->$part1->$part2 = (string)$ItemData->ExternOrderId;
        } else if (strlen((string)$ItemData->CustomerId) > 0) {
            $oOrder->oxorder__oxremark = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal($ItemData->ExternOrderId) . ' | ' . (string)$ItemData->CustomerId);
        } else {
            $oOrder->oxorder__oxremark = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal($ItemData->ExternOrderId));
        }

        $oOrder->oxorder__oxtotalbrutsum  = new \OxidEsales\Eshop\Core\Field((float)$ItemData->TotalAmountProducts);
        $oOrder->oxorder__oxtotalnetsum   = new \OxidEsales\Eshop\Core\Field((float)$ItemData->TotalAmountProductsNetto);
        $oOrder->oxorder__oxtotalordersum = new \OxidEsales\Eshop\Core\Field((float)$ItemData->TotalAmount);
        $oOrder->oxorder__oxdelcost       = new \OxidEsales\Eshop\Core\Field((float)$ItemData->ShippingCost);
        $oOrder->oxorder__oxpaycost       = new \OxidEsales\Eshop\Core\Field((float)$ItemData->PaymentCost);
        $oOrder->oxorder__oxpayvat        = new \OxidEsales\Eshop\Core\Field((float)$ItemData->PaymentTax);

        $currencyXml =  Utils\SystemManager::utf8ToLocal((string)$ItemData->Currency);
        $currencies = $oOrder->getOrderCurrency();

        $currencyName = "";
        $currencyRate = "";

        foreach($currencies as $currency) {
            if($currency->name == $currencyXml) {
                $currencyName = $currency->name;
                $currencyRate = $currency->rate;
                break;
            }
        }

        if(strlen($currencyName) <= 0) {
            $currencyName = Registry::getConfig()->getActShopCurrencyObject()->name;
            $currencyRate = Registry::getConfig()->getActShopCurrencyObject()->rate;
        }

        $oOrder->oxorder__oxcurrency      = new \OxidEsales\Eshop\Core\Field($currencyName);
        $oOrder->oxorder__oxcurrate       = new \OxidEsales\Eshop\Core\Field($currencyRate);
        $oOrder->oxorder__oxdelvat        = new \OxidEsales\Eshop\Core\Field((float)$ItemData->OrderLines->OrderLine->TaxRate);

        $blnAddressAddToAdditionalInfo = (bool) Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_ORDERS_ADDITIONAL_ADDR_INFO_TO_ADD_INFO, 'multichannel', false, 'bool');
        $sBillCompany                  = Utils\SystemManager::utf8ToLocal((string) $ItemData->BillingParty->Company);

        if($blnAddressAddToAdditionalInfo === true) {
            $oOrder->oxorder__oxbilladdinfo = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->BillingParty->AddressAdd));
        } else {
            // by default AddressAdd is appended to Company
            $sBillCompany .= ' ' . Utils\SystemManager::utf8ToLocal((string)$ItemData->BillingParty->AddressAdd);
            $oOrder->oxorder__oxbilladdinfo = new \OxidEsales\Eshop\Core\Field('');
        }

        $sBillCompany = trim($sBillCompany);

        $firstName = Utils\SystemManager::utf8ToLocal((string)$ItemData->BillingParty->FirstName);
        $lastName = Utils\SystemManager::utf8ToLocal((string)$ItemData->BillingParty->LastName);
        $name = Utils\SystemManager::utf8ToLocal((string)$ItemData->BillingParty->Name);

        if(strlen($firstName) <= 0 || strlen($lastName) <= 0) {
            $arr = explode(" ", $name);
            $lastName = $arr[count($arr) - 1];
            unset($arr[count($arr) - 1]);
            $firstName = join(" ", $arr);
        }

        $oOrder->oxorder__oxbillsal = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->BillingParty->Title));
        $oOrder->oxorder__oxbillfname = new \OxidEsales\Eshop\Core\Field($firstName);
        $oOrder->oxorder__oxbilllname = new \OxidEsales\Eshop\Core\Field($lastName);
        $oOrder->oxorder__oxbillcompany = new \OxidEsales\Eshop\Core\Field($sBillCompany);
        $emailValidatorService = ContainerFacade::get(EmailValidatorServiceBridgeInterface::class);
        $oOrder->oxorder__oxbillemail = new \OxidEsales\Eshop\Core\Field(($emailValidatorService->isEmailValid((string)$ItemData->BillingParty->EmailAddress) === true)
            ? (string)$ItemData->BillingParty->EmailAddress : null);

        $splitAddress = (bool)Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_ORDERS_SPLIT_ADDRESS,
            'multichannel', false, 'bool');

        if($splitAddress === true) {
            $address = $this->parseAddressSingleString(Utils\SystemManager::utf8ToLocal((string) $ItemData->BillingParty->Address));
            $oOrder->oxorder__oxbillstreet = new \OxidEsales\Eshop\Core\Field($address["StreetName"]);
            $oOrder->oxorder__oxbillstreetnr = new \OxidEsales\Eshop\Core\Field($address["HouseNumber"]);
        } else {
            $oOrder->oxorder__oxbillstreet = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->BillingParty->Address));
            $oOrder->oxorder__oxbillstreetnr = new \OxidEsales\Eshop\Core\Field('');
        }

        $oOrder->oxorder__oxbillcity = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->BillingParty->City));
        $oOrder->oxorder__oxbillcountryid = new \OxidEsales\Eshop\Core\Field($this->getCountryIdByIsoCode($ItemData->BillingParty->CountryIso));
        $oOrder->oxorder__oxbillzip = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->BillingParty->PostalCode));
        $oOrder->oxorder__oxbillfon = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->BillingParty->PhonePrivate));

        $blnAddressAddToAdditionalInfo = (bool)Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_ORDERS_ADDITIONAL_ADDR_INFO_TO_ADD_INFO, 'multichannel', false, 'bool');
        $sDelCompany = Utils\SystemManager::utf8ToLocal((string)$ItemData->DeliveryParty->Company);

        if($blnAddressAddToAdditionalInfo === true) {
            $oOrder->oxorder__oxdeladdinfo = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->DeliveryParty->AddressAdd));
        } else {
            // by default AddressAdd is appended to Company
            $sDelCompany .= ' ' . Utils\SystemManager::utf8ToLocal((string)$ItemData->DeliveryParty->AddressAdd);
            $oOrder->oxorder__oxdeladdinfo = new \OxidEsales\Eshop\Core\Field('');
        }

        $firstName = Utils\SystemManager::utf8ToLocal((string)$ItemData->DeliveryParty->FirstName);
        $lastName = Utils\SystemManager::utf8ToLocal((string)$ItemData->DeliveryParty->LastName);
        $name = Utils\SystemManager::utf8ToLocal((string)$ItemData->DeliveryParty->Name);

        if(strlen($firstName) <= 0 || strlen($lastName) <= 0) {
            $arr = explode(" ", $name);
            $lastName = $arr[count($arr) - 1];
            unset($arr[count($arr) - 1]);
            $firstName = join(" ", $arr);
        }

        $oOrder->oxorder__oxdellsal = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->DeliveryParty->Title));
        $oOrder->oxorder__oxdelfname = new \OxidEsales\Eshop\Core\Field($firstName);
        $oOrder->oxorder__oxdellname = new \OxidEsales\Eshop\Core\Field($lastName);
        $oOrder->oxorder__oxdelcompany = new \OxidEsales\Eshop\Core\Field($sDelCompany);

        $emailValidatorService = ContainerFacade::get(EmailValidatorServiceBridgeInterface::class);
        $oOrder->oxorder__oxdellemail = new \OxidEsales\Eshop\Core\Field(($emailValidatorService->isEmailValid((string)$ItemData->DeliveryParty->EmailAddress) === true)
            ? (string)$ItemData->DeliveryParty->EmailAddress : null);

        $splitAddress = (bool)Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_ORDERS_SPLIT_ADDRESS,
            'multichannel', false, 'bool');

        if($splitAddress === true) {
            $address = $this->parseAddressSingleString(Utils\SystemManager::utf8ToLocal((string)$ItemData->DeliveryParty->Address));
            $oOrder->oxorder__oxdelstreet = new \OxidEsales\Eshop\Core\Field($address["StreetName"]);
            $oOrder->oxorder__oxdelstreetnr = new \OxidEsales\Eshop\Core\Field($address["HouseNumber"]);
        } else {
            $oOrder->oxorder__oxdelstreet = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->DeliveryParty->Address));
            $oOrder->oxorder__oxdelstreetnr = new \OxidEsales\Eshop\Core\Field('');
        }

        $oOrder->oxorder__oxdelcity = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->DeliveryParty->City));
        $oOrder->oxorder__oxdelcountryid = new \OxidEsales\Eshop\Core\Field($this->getCountryIdByIsoCode($ItemData->DeliveryParty->CountryIso));
        $oOrder->oxorder__oxdelzip = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->DeliveryParty->PostalCode));
        $oOrder->oxorder__oxdelfon = new \OxidEsales\Eshop\Core\Field(Utils\SystemManager::utf8ToLocal((string)$ItemData->DeliveryParty->PhonePrivate));

        $oOrder->oxorder__oxisnettomode = new \OxidEsales\Eshop\Core\Field((int)Registry::getConfig()->getShopConfVar('blEnterNetPrice', Registry::getConfig()->getShopId()));

        if ($oOrder->save()) {
            $salesChannelId = $ItemData->SalesChannelId ? $ItemData->SalesChannelId : 0;
            $this->_iOrderCount++;
            $this->_writeOrderImport($oOrder->getId(), $ItemData->ExternOrderId, $ItemData->OrderId, $this->_strShopOXID, $salesChannelId);

            return $oOrder->getId();
        }

        return false;
    }

    /**
     * @param string $paymentMethod
     * @throws Oxid\Core\Exception\DatabaseConnectionException
     */
    private function paymentMethodExists($paymentMethod)
    {
        return Oxid\Core\DatabaseProvider::getDb()->getOne("SELECT `oxid` FROM `oxpayments` WHERE `oxid` = '$paymentMethod'");
    }

    /**
     * @param string $sUserId
     * @param string $sOxPaymentsId
     * @return false|object
     */
    private function createUserPayment($sUserId, $sOxPaymentsId)
    {
        $oUserPayment = oxNew(UserPayment::class);
        $oUserPayment->oxuser__oxuserid = new \OxidEsales\Eshop\Core\Field($sUserId);
        $oUserPayment->oxuser__oxpaymentsid = new \OxidEsales\Eshop\Core\Field($sOxPaymentsId);
        $oUserPayment->oxuser__oxvalue = new \OxidEsales\Eshop\Core\Field('');
        $oUserPayment->save();

        return $oUserPayment->getId();
    }

    /**
     * @param $externOrderId
     * @param $bfOrderId
     * @param \OxidEsales\Eshop\Application\Model\Order $objectOrder
     * @return string
     * @throws ConfigurationException
     */
    private function getOrderNr($externOrderId, $bfOrderId, \OxidEsales\Eshop\Application\Model\Order $objectOrder)
    {
        $numberingOption = Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_ORDERS_ORDER_NUMBERING);

        switch ($numberingOption) {
            case 'externId':
                $oxordernr = (strlen($externOrderId) > 0 && strlen($externOrderId) < 10) ? $externOrderId : '';
                $oxordernr = (is_numeric($oxordernr) === false) ? '' : $oxordernr;
                break;

            case 'bfId':
                $oxordernr = (strlen($bfOrderId) > 0 && strlen($bfOrderId) < 10) ? $bfOrderId : '';
                break;

            case 'oxId':
            default:
                $oxordernr = $objectOrder->newOrderNumber();

        }

        if ($oxordernr === '') {
            $oxordernr = $objectOrder->newOrderNumber();
        }

        return $oxordernr;
    }

    /**
     * creates the entry in brickfox_import
     *
     * @param string $sOxOrderId
     * @param string $sExternOrderId
     * @param string $sOrderId
     * @param string $sShopId
     * @param int $iSaleschannelId
     * @internal param string $sStatus
     */
    private function _writeOrderImport($sOxOrderId, $sExternOrderId, $sOrderId, $sShopId, $iSaleschannelId)
    {
        $sQ = "insert into brickfox_import (id, oxorderid, externorderid, import_importdate, orderid, shopid, import_oxfolder, saleschannelid) ";
        $sQ .= "values ( '" . Utils\SystemManager::generateUId() . "', '" . $sOxOrderId . "', '" . $sExternOrderId . "', NOW(), '"
            . $sOrderId . "', '" . $sShopId . "', '" . $this->_sOrderStatus . "', " . $iSaleschannelId . " ) ";

        Oxid\Core\DatabaseProvider::getDb()->execute($sQ);
    }

    /**k
     * creates the entry in brickfox_import_articles
     *
     * @param int $iOrderlineId
     * @param string $sProductExternId
     * @param string $sOxorderid
     * @param int $iQuantity
     */
    private function _writeOrderArticleImport($oxOrderArticleId, $iOrderlineId, $sProductExternId, $sOxorderid, $iQuantity)
    {
        $sQ = "insert into brickfox_import_articles (id, import_id, orderline_id, extern_product_id, import_article_oxfolder, import_article_importdate, oxorderid, quantity_ordered) ";
        $sQ .= "values ( '" . Utils\SystemManager::generateUId() . "', '" . $oxOrderArticleId . "', " . $iOrderlineId . ", '"
            . $sProductExternId . "', " . " '', NOW(), '" . $sOxorderid . "', " . $iQuantity . " )";

        Oxid\Core\DatabaseProvider::getDb()->execute($sQ);
    }

    /**
     * checks if order with given already exists in oxdb
     *
     * @param string $externOrderId
     * @param int $iShopId
     * @return boolean
     */
    private function _checkOrderAlreadyImported($externOrderId, $iShopId)
    {
        $returnValue = [];
        $sQuery      = "select externorderid from brickfox_import where externorderid='" . $externOrderId . "' and shopid='" . $iShopId . "'";

        $oResult = Oxid\Core\DatabaseProvider::getDb()->select($sQuery);

        if ($oResult != false && $oResult->count() > 0) {
            while (!$oResult->EOF) {
                $row                                = $oResult->getFields();
                $returnValue[$row['externorderid']] = $row['externorderid'];
                $oResult->fetchRow();
            }
        }

        if (count($returnValue) > 0) {
            return true;
        }

        return false;
    }

    /**
     * @param string $sCountryIsoCode
     * @return string
     * @throws Oxid\Core\Exception\DatabaseConnectionException
     */
    private function getCountryIdByIsoCode($sCountryIsoCode)
    {
        return Oxid\Core\DatabaseProvider::getDb()->getOne("SELECT `oxid` FROM `oxcountry` WHERE `oxisoalpha2` = '$sCountryIsoCode'");
    }

    public function parseAddressSingleString ($address)
    {
        $result = array();

        preg_match("/\d/",$address,$match);

        if(count($match) > 0)
        {
            $pos = strpos($address,$match[0]);
            $len = strlen($address);
            $street = substr($address,0,$pos);
            $number = substr($address,$pos,$len);

            $result['StreetName']        = trim($street);
            $result['HouseNumber']       = trim($number);
        }else{
            $result['StreetName']        = $address;
            $result['HouseNumber']       = "";
        }

        return $result;
    }
}
