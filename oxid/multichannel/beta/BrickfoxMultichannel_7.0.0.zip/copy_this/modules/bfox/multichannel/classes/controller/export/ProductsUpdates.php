<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 11.09.18
 * Time: 16:14
 */

namespace bfox\multichannel\classes\controller\export;

use bfox\multichannel\classes\model as Models;

class ProductsUpdates extends ProductsWrapper
{

    /** @var array $configCurrency; */
    protected $configCurrency;


    public function __construct(\OxidEsales\Eshop\Application\Model\Article $articleModel,
                                \stdClass $oCurrency)
    {
        $this->configCurrency = $oCurrency;


        /**
         * Begin of the output
         */
        $this->output['ProductExternId']        = $articleModel->oxarticles__oxid;
        $this->output['Active']                 = $articleModel->oxarticles__oxactive;

        $variations = $this->getVariations($articleModel);
        if(count($variations) > 0)
        {
            $this->output['Variations'] = $variations;
        }


    }


    /**
     * get Variations
     * @param \OxidEsales\Eshop\Application\Model\Article $articleModel
     * @return array
     */
    private function getVariations(\OxidEsales\Eshop\Application\Model\Article $articleModel)
    {
        $adminVariations = $articleModel->getAdminVariants();
        $count = 1;
        $variations = [];

        if (count($variations) === 0)
        {
            $variation = $this->getVariationArray($articleModel);
            $variations['Variation:'.$count] = $variation;
        }

        foreach($adminVariations as $articleVariation)
        {
            $variation = $this->getVariationArray($articleVariation);

            $variations['Variation:'.$count] = $variation;
            $count++;
        }
        return $variations;
    }


    public function getVariationArray(\OxidEsales\Eshop\Application\Model\Article $articleVariations)
    {
        $array = [];
        $isNet = false;

        $price = $articleVariations->getPrice();
        if ($price)
        {
            $isNet = $price->isNettoMode();
        }

        $availabilityAndStockInfo = $this->getAvailabilityAndStockInfo($articleVariations->oxarticles__oxstockflag, $articleVariations->oxarticles__oxstock);
        $available                = $availabilityAndStockInfo['available'];
        $thirdPartyStock          = $availabilityAndStockInfo['thirdPartyStock'];

        $array['VariationExternId'] = $articleVariations->oxarticles__oxid;
        $array['VariationActive']   = $articleVariations->oxarticles__oxactive;

        $array['Available']         = $available;
        $array['ThirdPartyStock']   = $thirdPartyStock;
        $array['Stock']             = $articleVariations->oxarticles__oxstock;

        $currencies = $this->getCurrencies($articleVariations);
        if(count($currencies) > 0)
        {
            $array["Currencies:net:".var_export($isNet, true)] = $currencies;
        }

        return $array;
    }

}