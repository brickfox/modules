<?php
/**
 * ProductDeleteModel
 * This file is part of brickfox.
 *
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2019 brickfox GmbH http://www.brickfox.de
 */

namespace bfox\multichannel\classes\model;

/**
 * Direkte Extension von OXIDs Core-BaseModel statt ueber den leeren
 * Modul-Wrapper bfox\multichannel\wrapper\Core\Model\OxidBaseModel. Siehe
 * OXID-Doku zur Klassen-Chain (extend_shop_class.html) — leere Wrapper haben
 * keinen funktionalen Mehrwert und scheitern bei deaktiviertem Modul mit
 * "OxidBaseModel_parent not found".
 */
class ProductDeleteModel extends \OxidEsales\Eshop\Core\Model\BaseModel
{

}