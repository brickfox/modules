<?php
/**
 * connect.php - the entry point
 *
 */

namespace bfox\multichannel\scripts;

use bfox\multichannel\classes\controller as Controllers;
use bfox\multichannel\classes\util as Utils;
use bfox\multichannel\classes\exception as Exceptions;


callOxidBootstrap();

checkOutputDebug();

/**
 * Parameter sent by Querystring with requested action to perform
 */
$action = getRequestParameter('action');

/**
 * Array of valid actions to call
 */
$validActions = array(
    'importOrders',
    'exportOrdersStatus',
    'showVersion',
    'exportProducts',
    'exportCategories',
    'exportManufacturers',
    'exportProductsUpdates',
    'customExportProducts',
    'exportNewProducts',
    'exportProductsDeletes',
    'cleanUpExchangeDirectory'
);

start($action, $validActions);


function getRequestParameter($parameterName)
{
    if (isset($_GET[$parameterName])) {
        return $_GET[$parameterName];
    }
}

/**
 * @param string $action Taken from query string request
 * @param array $validActions
 */
function start($action, $validActions)
{
    set_time_limit(60 * 60 * 8);
    ini_set('memory_limit', '3072M');

    // Debug: Eingang der Anfrage
    Utils\LogManager::getInstance()->debug('connect.php start; action=' . (string)$action . ', shp=' . (string)getRequestParameter('shp'));
    Utils\LogManager::getInstance()->debug('connect.php validActions=' . implode(',', $validActions));

    if (true === isset($action) && '' != $action && true === in_array($action, $validActions)) {
        $importExportAction = '';
        switch ($action) {
            case 'importOrders':
                $importExportAction = 'importBrickfoxOrders';
                break;

            case 'exportProducts':
                $importExportAction = 'collectOxidArticles';
                break;

            case 'exportNewProducts':
                $importExportAction = 'collectOxidArticlesCreatedSince';
                break;

            case 'exportProductsUpdates':
                $importExportAction = 'collectOxidArticlesStockAndPrices';
                break;

            case 'customExportProducts':
                $importExportAction = 'collectOxidArticlesCustomized';
                break;

            case 'exportCategories':
                $importExportAction = 'collectOxidCategories';
                break;

            case 'exportManufacturers':
                $importExportAction = 'collectOxidManufacturers';
                break;

            case 'exportOrdersStatus':
                $importExportAction = 'collectOxidOrdersStatus';
                break;

            case 'exportProductsDeletes':
                $importExportAction = 'collectOxidProductsDeletes';
                break;

            case 'cleanUpExchangeDirectory':
                $importExportAction = 'cleanUpExchangeDirectory';
                break;

            case 'showVersion':
                outputVersionInfo();
                Utils\LogManager::getInstance()->debug('connect.php showVersion executed');
                break;
        }

        Utils\LogManager::getInstance()->debug('connect.php resolved method=' . (string)$importExportAction);
        callRequestedAction($importExportAction);
    } else {
        Utils\LogManager::getInstance()->debug('connect.php no valid action provided or action not in whitelist');
    }
}


/**
 * Calls the Oxid bootstrap file to load all the Oxid framework and its contents
 */
function callOxidBootstrap()
{
    $dir           = dirname($_SERVER['SCRIPT_FILENAME']);
    $pathArray     = explode("modules", $dir);
    $bootstrapPath = array_shift($pathArray);

    if (substr($bootstrapPath, -1) !== '/') {
        $bootstrapPath .= '/';
    }

    require_once $bootstrapPath . 'bootstrap.php';

}

function changeMemoryLimits()
{
    $memoryLimit = '2048M';
    ini_set('memory_limit', $memoryLimit);
    Utils\LogManager::getInstance()->debug("Try Memory Limit change to " . $memoryLimit);
}

function changeTimeLimits()
{
    set_time_limit(60 * 60 * 6);
}


/**
 *  Use the debug_mode for Exceptions and Errors description.
 *  Here we change how to handle exceptions as for PHP 7 they are Errors instances.
 */
function checkOutputDebug()
{
    $debug_mode = getRequestParameter('debug_mode');

    if (true === isset($debug_mode) && $debug_mode === 'j') {
        Utils\SystemManager::getInstance()->setDebugMode(true);
        echo "<h2>debug function ON</h2>";

        set_exception_handler(
            [
                new Exceptions\OxidExceptionHandler(),
                'handleUncaughtException'
            ]
        );

        set_error_handler(
            [
                new Exceptions\OxidExceptionHandler(),
                'handleUncaughtError'
            ]
        );
    }
}


/**
 * @param $importExportAction string Name of the method that should be called by the controller
 *
 * Wickelt den eigentlichen Controller-Aufruf in einen INFO-/ERROR-strukturierten
 * Block ein, damit im Modul-Log (multichannel_YYYY_MM_DD.log) IMMER sichtbar ist,
 * - wann eine Operation startet,
 * - ob sie erfolgreich war (mit Laufzeit),
 * - oder mit welchem Throwable sie gescheitert ist (Class + Message + Datei:Zeile
 *   + Stacktrace-Kopf).
 *
 * Vor diesem Wrap war ein Live-TypeError (z.B. count(null) im Categories-Export
 * 2026-05-13) nur in den OXID-Default-Logs sichtbar, nicht im Modul-Log — daher
 * die wiederholte Frage "warum sieht der Support den Fehler nicht?".
 */
function callRequestedAction($importExportAction)
{
    if ('' == $importExportAction) {
        Utils\LogManager::getInstance()->debug('connect.php no controller method to call');
        return;
    }

    $log = Utils\LogManager::getInstance();
    $log->info('[ACTION_START] method=' . $importExportAction);
    $startedAt = microtime(true);

    try {
        $controller = new Controllers\ImportExportController;
        $controller->{$importExportAction}();
        $log->info(sprintf(
            '[ACTION_OK] method=%s duration=%.3fs',
            $importExportAction,
            microtime(true) - $startedAt
        ));
    } catch (\Throwable $e) {
        $log->error(sprintf(
            "[ACTION_FAILED] method=%s duration=%.3fs %s: %s at %s:%d\n%s",
            $importExportAction,
            microtime(true) - $startedAt,
            get_class($e),
            $e->getMessage(),
            $e->getFile(),
            $e->getLine(),
            $e->getTraceAsString()
        ));
        // Re-throw, damit OXIDs Standard-Logging und HTTP-500-Verhalten
        // unveraendert bleiben — wir wollen NICHT verschleiern, dass etwas
        // fehlgeschlagen ist.
        throw $e;
    }
}


/**
 * Return information about the Oxid version Installed and some of its features
 */
function outputVersionInfo()
{
    echo "<h2>Brickfox multichannel plugin for Oxid e-sales 7.1</h2>";
    echo "<h3>Oxid details:</h3>";

    $config = new Utils\OxidCompatibility;

    echo "Version: " . $config->getVersionDescription();
    echo "<br>";
    echo "Multiple Shops support: ";
    echo $config->getSupportShops() ? "true" : "false";
    echo "<br>";
    echo "Singleton (getInstance method) support: ";
    echo $config->getSupportGetInstance() ? "true" : "false";
    echo "<br>";
    echo "<h3>Server max_execution_time: " . ini_get('max_execution_time') . "</h3>";
    echo "<h3>Server max_input_time: " . ini_get('max_input_time') . "</h3>";
    echo "<h3>Server memory_limit: " . ini_get('memory_limit') . "</h3>";

    echo "<hr>";
    #phpinfo();
}
