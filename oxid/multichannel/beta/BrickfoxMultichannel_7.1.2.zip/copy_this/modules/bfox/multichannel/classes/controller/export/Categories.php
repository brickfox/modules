<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 21.08.18
 * Time: 15:31
 */

namespace bfox\multichannel\classes\controller\export;

use bfox\multichannel\classes\model as Models;

class Categories extends Wrapper
{
    /** @var array<string, array<string, string>> Translation:lang:<abbr> => [Name => Title]. */
    private array $translations = [];

    public function __construct(\OxidEsales\Eshop\Application\Model\Category $categoryModel, $exportOptions, $languages)
    {
        $this->setExportOptions($exportOptions);
        $this->languages = $languages;

        $this->output['CategoryId']             = $categoryModel->oxcategories__oxid;
        $this->output['ParentId']               = $categoryModel->oxcategories__oxparentid;
        $this->output['SortOrder']              = $categoryModel->oxcategories__oxsort;

        //Get MultiLanguage Fields.
        $this->getMultilanguageFields($categoryModel);

    }


    /**
     * get Multilanguage Fields
     * @param \OxidEsales\Eshop\Application\Model\Category $categoryModel
     *
     */
    private function getMultilanguageFields(\OxidEsales\Eshop\Application\Model\Category $categoryModel)
    {
        foreach ($this->getLanguages() as $language)
        {

            $languageAbbreviation = $language['abbr'];
            $categoryModel->loadInLang($language['id'], $categoryModel->oxcategories__oxid);

            // get Titles
            $title = $categoryModel->getTitle();
            if (strlen($title) > 0)
            {
                $this->translations['Translation:lang:'.$languageAbbreviation] = ["Name" => $title];
            }

        }

        //Set collected values

        // Belt-and-Suspenders zur typed property "private array $translations = []":
        // !empty() ist null-safe, falls die Property aus einem Grund jenseits unserer
        // Kontrolle (OPcache mit veralteter Klassen-Definition, Reflection-Patches,
        // Subclass) doch null bekommen sollte. Live-Vorfall Kostuempalast 2026-05-13.
        if (!empty($this->translations))
        {
            $this->output['Translations'] = $this->translations;
        }


    }

}