<?php
/**
 * ConfigManager: Modul-Hilfsklasse, die OXIDs Core\Config-Verhalten erbt.
 *
 * Vorher hing diese Klasse am Modul-Wrapper bfox\multichannel\wrapper\Core\OxidConfig,
 * der OXIDs \OxidEsales\Eshop\Core\Config über die `extend`-Chain um eine
 * zusaetzliche Ebene verlaengerte, ohne Code beizusteuern. Laut OXID-Doku
 * (extend_shop_class.html) sollen Modul-Klassen Shop-Methoden konkret erweitern
 * oder gar nicht in der Chain stehen. Empty wrapper sind doppelt problematisch:
 *  - bei deaktiviertem Modul existiert `*_parent` nicht und die Subklasse
 *    laeuft auf einen Class-not-found-Fehler (BS-7864 Folgemeldung).
 *  - sie verlaengern die Chain ohne funktionalen Nutzen.
 *
 * Direkter Bezug zu OXID-Core macht das deterministisch und unabhaengig vom
 * Aktivierungszustand des Moduls.
 */

namespace bfox\multichannel\classes\util;

class ConfigManager extends \OxidEsales\Eshop\Core\Config
{

}