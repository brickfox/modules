<?php

namespace bfox\multichannel\classes\setup;

/**
 * Pre-Aktivierungs-Check fuer das brickfox/multichannel Modul.
 *
 * Wird von OXID via metadata.php (events.onActivate) genau einmal beim
 * Aktivieren des Moduls gerufen. Wenn eine Pflicht-Extension fehlt oder
 * die PHP-Version zu niedrig ist, bricht onActivate() mit einer
 * RuntimeException ab — OXID bleibt im deaktivierten Zustand und zeigt
 * die Botschaft im Admin-Modul-Manager an.
 *
 * Hintergrund: BS-7864 hat gezeigt, wie teuer "stille" Fehlkonfiguration
 * im Modul ist (Connection ohne Subsystem, leere Listen ohne Fehler).
 * Ein deklarativer Check beim Aktivieren ist der frueheste Punkt, an
 * dem wir den User auf eine fehlende externe Abhaengigkeit hinweisen
 * koennen — bevor der erste Cron/Import lauft.
 */
class Events
{
    /**
     * @var array<string, string> Extension-Name => warum sie gebraucht wird.
     */
    public const REQUIRED_EXTENSIONS = [
        'ssh2'      => 'SFTP-Datenaustausch (classes/controller/transfer/Sftp.php, ssh2_connect/ssh2_sftp/ssh2_auth_password)',
        'ftp'       => 'FTP-Datenaustausch (classes/controller/transfer/Ftp.php, ftp_connect/ftp_get/ftp_put/...)',
        'curl'      => 'HTTP-Aufrufe in Order- und Product-Transfer (curl_init/curl_exec/curl_setopt)',
        'simplexml' => 'XML-Parsing beim Import/Export (simplexml_load_file, simplexml_load_string)',
        'dom'       => 'XML-Generierung beim Export (DOMDocument, XMLWriter)',
    ];

    /**
     * Mindest-PHP-Version. Aligned mit OXID 7.1 CE (PHP 8.1+).
     */
    public const REQUIRED_PHP = '8.1.0';

    /**
     * OXID-Activation-Hook. Wirft RuntimeException, wenn die Umgebung
     * die Anforderungen nicht erfuellt.
     */
    public static function onActivate(): void
    {
        self::log('onActivate: start (PHP ' . PHP_VERSION . ')');

        // Sicherheitsnetz (BS-7864): metadata.php persistiert den PSR-4-Autoload
        // beim Installieren. Falls das Modul auf anderem Weg in einen aktiven
        // Zustand kommt, sichern wir die Registrierung hier erneut ab.
        \bfox\multichannel\classes\setup\AutoloadInstaller::ensure(dirname(__DIR__, 2));

        $errors = self::checkRequirements();
        self::log($errors === []
            ? 'onActivate: PHP-/Extension-Anforderungen erfuellt'
            : 'onActivate: Anforderungen NICHT erfuellt: ' . implode(' | ', $errors));

        self::ensureRequirements();
        self::log('onActivate: abgeschlossen');
    }

    /**
     * Schreibt eine Diagnosezeile (apache error_log + source/log). Delegiert an
     * AutoloadInstaller::diag, damit das Log NICHT im Modulverzeichnis landet.
     * Bewusst ohne LogManager, damit es auch in fruehen Bootstrap-/
     * Aktivierungsphasen robust funktioniert.
     */
    private static function log(string $message): void
    {
        AutoloadInstaller::diag(dirname(__DIR__, 2), '[events] ' . $message);
    }

    /**
     * Wie onActivate, aber mit injizierbaren Listen — fuer Tests.
     *
     * @param array<string, string>|null $extensions     Wenn null, wird REQUIRED_EXTENSIONS genommen.
     * @param string|null                $minPhpVersion  Wenn null, wird REQUIRED_PHP genommen.
     * @param string|null                $phpVersion     Wenn null, wird PHP_VERSION genommen.
     *
     * @throws \RuntimeException
     */
    public static function ensureRequirements(
        ?array $extensions = null,
        ?string $minPhpVersion = null,
        ?string $phpVersion = null
    ): void {
        $errors = self::checkRequirements($extensions, $minPhpVersion, $phpVersion);
        if ($errors === []) {
            return;
        }
        throw new \RuntimeException(
            "Brickfox Multichannel kann nicht aktiviert werden — folgende Voraussetzungen fehlen:\n  - "
            . implode("\n  - ", $errors)
            . "\n\nBitte die fehlenden PHP-Extensions installieren bzw. aktivieren und die Modul-Aktivierung erneut starten."
        );
    }

    /**
     * Prueft Anforderungen und liefert eine Liste menschenlesbarer Fehlermeldungen
     * (leer = alles ok). Wirft selbst keine Exception — sinnvoll fuer Health-Checks
     * oder UI-Anzeigen ausserhalb des Aktivierungs-Hooks.
     *
     * @param array<string, string>|null $extensions
     * @param string|null                $minPhpVersion
     * @param string|null                $phpVersion
     *
     * @return string[]
     */
    public static function checkRequirements(
        ?array $extensions = null,
        ?string $minPhpVersion = null,
        ?string $phpVersion = null
    ): array {
        $extensions    = $extensions    ?? self::REQUIRED_EXTENSIONS;
        $minPhpVersion = $minPhpVersion ?? self::REQUIRED_PHP;
        $phpVersion    = $phpVersion    ?? PHP_VERSION;

        $errors = [];

        if (version_compare($phpVersion, $minPhpVersion, '<')) {
            $errors[] = sprintf(
                'PHP-Version: benoetigt mindestens %s, gefunden: %s.',
                $minPhpVersion,
                $phpVersion
            );
        }

        foreach ($extensions as $ext => $purpose) {
            if (!extension_loaded($ext)) {
                $errors[] = sprintf(
                    'PHP-Extension "%s" fehlt — benoetigt fuer: %s.',
                    $ext,
                    $purpose
                );
            }
        }

        return $errors;
    }
}
