<?php

namespace bfox\multichannel\classes\setup;

/**
 * Stellt sicher, dass der PSR-4-Namespace des Moduls im Composer-Autoloader
 * registriert ist.
 *
 * Hintergrund (BS-7864)
 * ---------------------
 * OXID 7 laedt Modul-Extension-Klassen AUSSCHLIESSLICH ueber den Composer-
 * Autoloader (ModuleChainsGenerator::createClassExtension ->
 * $composerClassLoader->findFile($moduleClass)). Dieses Modul wird per ZIP
 * ausgeliefert und in source/modules/ kopiert -- NICHT via `composer require`.
 * Dadurch ist "bfox\multichannel\" Composer unbekannt und JEDE Modulklasse
 * scheitert mit "Module class ... not found": das Frontend (Artikel/Kategorie/
 * Start) wird lahmgelegt und jeder connect.php Import/Export-Lauf bricht ab.
 *
 * Diese Klasse wird von metadata.php aufgerufen (metadata.php wird beim
 * Installieren / Anwenden der Modulkonfiguration evaluiert). Sie
 *   1. registriert den Prefix zur Laufzeit auf dem aktiven ClassLoader
 *      (damit das Modul -- inkl. classes\setup\Events fuer onActivate --
 *      im selben Request ladbar ist), und
 *   2. PERSISTIERT die Registrierung in der Projekt-composer.json + via
 *      `composer dump-autoload`, damit sie auch bei normalen Seitenaufrufen
 *      greift (metadata.php wird NICHT pro Request geladen).
 *
 * Schlaegt die Persistierung fehl (z.B. composer nicht im PATH), wird eine
 * klare, handlungsleitende Meldung geloggt -- statt eines stillen
 * Shop-Totalausfalls.
 */
class AutoloadInstaller
{
    public const PREFIX = 'bfox\\multichannel\\';

    /** @var string Name der Diagnose-Logdatei im OXID-Logverzeichnis (source/log). */
    private const DIAG_LOG = 'bfox_multichannel_setup.log';

    /**
     * Einstiegspunkt: Laufzeit-Registrierung + (einmalige) Persistierung.
     *
     * @param string $moduleDir Absolutes Modulverzeichnis (metadata.php __DIR__).
     */
    public static function ensure(string $moduleDir): void
    {
        $moduleDir = rtrim(str_replace('\\', '/', $moduleDir), '/');

        $added = self::registerRuntime($moduleDir);
        if ($added) {
            self::log($moduleDir, 'runtime: PSR-4 ' . self::PREFIX . ' => ' . $moduleDir . ' registriert');
        }

        if (self::isPersisted($moduleDir)) {
            return;
        }
        self::persist($moduleDir);
    }

    /**
     * Registriert den Prefix auf dem aktiven Composer-ClassLoader (in-memory).
     *
     * @return bool true, wenn neu hinzugefuegt; false, wenn bereits vorhanden
     *              oder kein ClassLoader gefunden.
     */
    public static function registerRuntime(string $moduleDir): bool
    {
        foreach (spl_autoload_functions() ?: [] as $autoloader) {
            $loader = is_array($autoloader) ? ($autoloader[0] ?? null) : null;
            if ($loader instanceof \Composer\Autoload\ClassLoader) {
                $prefixes = $loader->getPrefixesPsr4();
                if (!empty($prefixes[self::PREFIX])) {
                    return false;
                }
                $loader->addPsr4(self::PREFIX, $moduleDir);
                return true;
            }
        }
        return false;
    }

    /**
     * Ist der Prefix bereits dauerhaft im generierten Composer-Autoload?
     */
    public static function isPersisted(string $moduleDir): bool
    {
        $root = self::projectRoot($moduleDir);
        if ($root === null) {
            return false;
        }
        $generated = $root . '/vendor/composer/autoload_psr4.php';
        return is_file($generated)
            && strpos((string) file_get_contents($generated), 'bfox\\\\multichannel') !== false;
    }

    /**
     * Sucht das Projekt-Root (enthaelt composer.json + vendor/composer)
     * oberhalb des Modulverzeichnisses.
     */
    public static function projectRoot(string $moduleDir): ?string
    {
        $dir = $moduleDir;
        for ($i = 0; $i < 8; $i++) {
            $dir = dirname($dir);
            if ($dir === '' || $dir === '/' || $dir === '.') {
                break;
            }
            if (is_file($dir . '/composer.json') && is_dir($dir . '/vendor/composer')) {
                return $dir;
            }
        }
        return null;
    }

    /**
     * Traegt den Prefix dauerhaft ein: composer.json patchen + dump-autoload.
     */
    private static function persist(string $moduleDir): void
    {
        $root = self::projectRoot($moduleDir);
        if ($root === null) {
            self::log($moduleDir, 'WARN: Projekt-Root (composer.json + vendor/) nicht gefunden -- '
                . 'Autoload kann nicht persistiert werden.');
            return;
        }

        // Relativen Pfad zum Modul bevorzugen (portabler in composer.json).
        $relative = self::relativePath($root, $moduleDir);
        $changed = self::patchComposerJson($root, $relative ?? $moduleDir);

        if (self::runDumpAutoload($root)) {
            self::log($moduleDir, 'OK: composer.json' . ($changed ? ' gepatcht +' : ' bereits ok,')
                . ' dump-autoload ausgefuehrt (root=' . $root . ')');
            return;
        }

        self::log(
            $moduleDir,
            'ERROR: "composer dump-autoload" konnte nicht ausgefuehrt werden (composer nicht gefunden '
            . 'oder Fehler). Bitte im Projekt-Root EINMALIG ausfuehren:'
            . "\n    cd " . $root . ' && composer dump-autoload -o'
            . "\n  Alternativ in composer.json unter autoload.psr-4 ergaenzen:"
            . "\n    \"" . self::PREFIX . "\": \"" . ($relative ?? $moduleDir) . '"'
        );
    }

    /**
     * Ergaenzt autoload.psr-4 in der Projekt-composer.json (idempotent).
     *
     * @return bool true, wenn die Datei geaendert wurde.
     */
    public static function patchComposerJson(string $root, string $modulePath): bool
    {
        $file = $root . '/composer.json';
        if (!is_file($file) || !is_writable($file)) {
            return false;
        }
        $json = json_decode((string) file_get_contents($file), true);
        if (!is_array($json)) {
            return false;
        }
        $current = $json['autoload']['psr-4'][self::PREFIX] ?? null;
        if ($current === $modulePath) {
            return false;
        }
        $json['autoload']['psr-4'][self::PREFIX] = $modulePath;
        file_put_contents(
            $file,
            json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n"
        );
        return true;
    }

    /**
     * Fuehrt `composer dump-autoload -o` im Projekt-Root aus.
     */
    private static function runDumpAutoload(string $root): bool
    {
        $composer = self::findComposer();
        if ($composer === null) {
            return false;
        }
        $cmd = sprintf(
            'cd %s && COMPOSER_MEMORY_LIMIT=-1 COMPOSER_HOME=%s %s dump-autoload -o --no-interaction 2>&1',
            escapeshellarg($root),
            escapeshellarg(sys_get_temp_dir() . '/.composer-bfox'),
            escapeshellcmd($composer)
        );
        $output = [];
        $code = 0;
        @exec($cmd, $output, $code);
        return $code === 0 && self::isPersistedAt($root);
    }

    private static function isPersistedAt(string $root): bool
    {
        $generated = $root . '/vendor/composer/autoload_psr4.php';
        return is_file($generated)
            && strpos((string) file_get_contents($generated), 'bfox\\\\multichannel') !== false;
    }

    /**
     * Findet ein ausfuehrbares composer-Binary.
     */
    private static function findComposer(): ?string
    {
        $candidates = ['composer', 'composer.phar', '/usr/local/bin/composer', '/usr/bin/composer'];
        foreach ($candidates as $candidate) {
            $probe = strpos($candidate, '/') === false
                ? @exec(escapeshellcmd('command -v ' . $candidate) . ' 2>/dev/null')
                : (is_file($candidate) ? $candidate : '');
            if (is_string($probe) && $probe !== '') {
                return $probe;
            }
        }
        return null;
    }

    /**
     * Relativer Pfad von $root zu $target (oder null, wenn nicht ableitbar).
     */
    private static function relativePath(string $root, string $target): ?string
    {
        $root = rtrim(str_replace('\\', '/', $root), '/');
        $target = rtrim(str_replace('\\', '/', $target), '/');
        if (strpos($target, $root . '/') === 0) {
            return substr($target, strlen($root) + 1) . '/';
        }
        return null;
    }

    private static function log(string $moduleDir, string $message): void
    {
        self::diag($moduleDir, '[autoload] ' . $message);
    }

    /**
     * Schreibt eine Diagnosezeile nach apache error_log UND -- wenn auffindbar --
     * ins OXID-Logverzeichnis (source/log/bfox_multichannel_setup.log).
     * Bewusst ohne LogManager/oxNew, damit es auch in fruehen Bootstrap-/
     * Aktivierungsphasen robust funktioniert. Schreibt NICHT ins Modul-
     * verzeichnis (das wuerde ins Auslieferungs-ZIP gelangen).
     */
    public static function diag(string $moduleDir, string $message): void
    {
        @error_log('[bfox/multichannel] ' . $message);
        $root = self::projectRoot(rtrim(str_replace('\\', '/', $moduleDir), '/'));
        if ($root === null) {
            return;
        }
        $logDir = $root . '/source/log';
        if (is_dir($logDir) && is_writable($logDir)) {
            @file_put_contents(
                $logDir . '/' . self::DIAG_LOG,
                '[' . gmdate('Y-m-d H:i:s') . ' UTC] ' . $message . "\n",
                FILE_APPEND
            );
        }
    }
}
