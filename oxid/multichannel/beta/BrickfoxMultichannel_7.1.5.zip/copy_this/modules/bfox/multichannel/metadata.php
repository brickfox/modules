<?php
/**
 * Module configuration
 *
 * Pay attention:
 * settings name values should not have more than 32 characters.
 */

/*
 * Self-register the module's PSR-4 namespace on the Composer autoloader.
 *
 * OXID 7 resolves module extension classes EXCLUSIVELY through the Composer
 * autoloader (ModuleChainsGenerator::createClassExtension ->
 * $composerClassLoader->findFile($moduleClass)). This module is shipped as a
 * ZIP and copied into source/modules/ instead of `composer require`, so the
 * "bfox\multichannel\" namespace is otherwise unknown to Composer and every
 * extension class fails to load ("Module class ... not found") -- crippling
 * the shop and breaking connect.php import/export (BS-7864).
 *
 * metadata.php is evaluated while OXID reads the module configuration
 * (install / apply-configuration), so we load the installer directly (the
 * autoloader is not ready yet) and let it register the prefix at runtime and
 * persist it into the project composer.json for normal page requests.
 */
require_once __DIR__ . '/classes/setup/AutoloadInstaller.php';
\bfox\multichannel\classes\setup\AutoloadInstaller::ensure(__DIR__);

// Metadata version
$sMetadataVersion = '2.1';

// Module information
$aModule = array(
    'id'          => 'multichannel',
    'title'       => 'Brickfox Multichannel (PIM)',
    'description'  => array(
        'de' => 'Brickfox Multichannel e-commerce. Module for Oxid 7.',
        'en' => 'Brickfox Multichannel e-commerce. Module for Oxid 7.',
    ),
    'thumbnail'   => 'images/logo.jpg',
    'version'     => '7.1.5',
    'author'      => 'brickfox GmbH',
    'email'       => 'support@brickfox.de',
    'url'         => 'http://www.brickfox.de',

    // OXID Klassen-Erweiterungen: NUR Wrapper, die wirklich Code beisteuern.
    // Leere Wrapper (OxidConfig/OxidRegistry/OxidBaseModel/OxidMultiLanguageModel)
    // waren ohne funktionalen Mehrwert, verlaengerten aber die Klassen-Chain und
    // verursachten "Class *_parent not found"-Fehler bei deaktiviertem Modul
    // (siehe BS-7864 Folgemeldung 2026-05-20). Entfernt nach OXID-Doku
    // "extend_shop_class.html": Extension-Klassen sollen Shop-Methoden konkret
    // erweitern oder gar nicht in der Chain stehen.
    'extend'      => array(
        \OxidEsales\Eshop\Application\Model\Article::class          => \bfox\multichannel\wrapper\Application\Model\OxidArticle::class,
        \OxidEsales\Eshop\Application\Model\Order::class            => \bfox\multichannel\wrapper\Application\Model\OxidOrder::class,
        \OxidEsales\Eshop\Core\Model\ListModel::class               => \bfox\multichannel\wrapper\Core\Model\OxidListModel::class,
        \OxidEsales\Eshop\Core\Exception\ExceptionHandler::class    => \bfox\multichannel\classes\exception\OxidExceptionHandler::class,
    ),


    'events' 	=> array(
        'onActivate' => '\bfox\multichannel\classes\setup\Events::onActivate',
	),
	'templates' => array(
	),
    'blocks' => array(
    ),

	'settings'		=> array(
        array(
            'group' => 'bfox_multichannel_connection',
            'name' => 'strbrickfoxFtpHost',
            'type' => 'str',
            'value' => '',
            'position' => 1
        ),
        array(
            'group' => 'bfox_multichannel_connection',
            'name' => 'strbrickfoxFtpUsername',
            'type' => 'str',
            'value' => '',
            'position' => 2
        ),
        array(
            'group' => 'bfox_multichannel_connection',
            'name' => 'strbrickfoxFtpPassword',
            'type' => 'str',
            'value' => '',
            'position' => 3
        ),
        array(
            'group' => 'bfox_multichannel_connection',
            'name' => 'intbrickfoxFtpPort',
            'type' => 'str',
            'value' => '',
            'position' => 4
        ),
        array(
            'group' => 'bfox_multichannel_connection',
            'name' => 'slcbrickfoxProtocol',
            'type' => 'select',
            'constraints' => 'ftp|sftp',
            'value' => 'sftp',
            'position' => 5
        ),
        array(
            'group' => 'bfox_multichannel_connection',
            'name' => 'strbrickfoxFtpFolder',
            'type' => 'str',
            'value' => 'incoming/',
            'position' => 6
        ),
        array(
            'group' => 'bfox_multichannel_connection',
            'name' => 'strbrickfoxSsl',
            'type' => 'bool',
            'value' => 'false',
            'position' => 7
        ),
        array(
            'group' => 'bfox_multichannel_products',
            'name' => 'aTaxClassMapping',
            'type' => 'aarr',
            'value' => array(
                '19' => 'standart',
                '7'  => 'reduced'
            ),
            'position' => 1
        ),
        array(
            'group' => 'bfox_multichannel_products',
            'name' => 'aArticleAdditionalWhere',
            'type' => 'aarr',
            'value' => array(
                "OXPARENTID" => " = '' " ,
            ),
            'position' => 2
        ),
        array(
            'group' => 'bfox_multichannel_products',
            'name' => 'aOxArticleColumnsCurrencies',
            'type' => 'aarr',
            'value' => array(),
            'position' => 3
        ),
        array(
            'group' => 'bfox_multichannel_products',
            'name' => 'strOxArticleColumnIsbn',
            'type' => 'str',
            'value' => '',
            'position' => 4
        ),
        array(
            'group' => 'bfox_multichannel_products',
            'name' => 'slctImageType',
            'type' => 'select',
            'constraints' => 'Icons|Pics|ZoomPics|Master',
            'value' => 'ZoomPics',
            'position' => 5
        ),
        array(
            'group' => 'bfox_multichannel_products',
            'name' => 'strLastProductsUpdate',
            'type' => 'str',
            'value' => '',
            'position' => 6
        ),
        array(
            'group' => 'bfox_multichannel_customexport',
            'name' => 'aGroupsToExport',
            'type' => 'arr',
            'value' => array(
                "Attributes", "Categories", "Images", "Descriptions", "Currencies", "Options"
            ),
            'position' => 1
        ),
        array(
            'group' => 'bfox_multichannel_customexport',
            'name' => 'aLastUpdateCheck',
            'type' => 'arr',
            'value' => array(
                "oxartextends__oxid", "oxaccessoire2article__oxarticlenid", "oxobject2article__oxarticlenid",
                "oxobject2attribute__oxobjectid", "oxobject2category__oxobjectid", "oxobject2seodata__oxobjectid", "oxprice2article__oxartid"
            ),
            'position' => 2
        ),
        array(
            'group' => 'bfox_multichannel_customexport',
            'name' => 'strCustomExportLastChange',
            'type' => 'str',
            'value' => '',
            'position' => 3
        ),
        array(
            'group' => 'bfox_multichannel_thirdpartystock',
            'name' => 'blnThirdPartyMap',
            'type' => 'bool',
            'value' => 'false',
            'position' => 1
        ),
        array(
            'group' => 'bfox_multichannel_thirdpartystock',
            'name' => 'strThirdPartyMapFrom',
            'type' => 'str',
            'value' => '',
            'position' => 2
        ),
        array(
            'group' => 'bfox_multichannel_thirdpartystock',
            'name' => 'slcThirdPartyMapAs',
            'type' => 'select',
            'constraints' => 'blnText|blnNumber|fieldValue',
            'value' => 'fieldValue',
            'position' => 3
        ),
        array(
            'group' => 'bfox_multichannel_attributes',
            'name' => 'arrAttributesArticlesTable',
            'type' => 'aarr',
            // BS-7864: leeres ARRAY statt Leerstring. Ein '' liefert via
            // ModuleSettingService::getCollection() einen String -> TypeError
            // und HTTP 500 in jedem Export-Pfad (collectOxidArticles, ...).
            'value' => array(),
            'position' => 1
        ),
        array(
            'group' => 'bfox_multichannel_orders',
            'name' => 'blnExportShippedOnlyWithTrackingId',
            'type' => 'bool',
            'value' => 'false',
            'position' => 1
        ),
        array(
            'group' => 'bfox_multichannel_orders',
            'name' => 'blnSplitAddress',
            'type' => 'bool',
            'value' => 'false',
            'position' => 2
        ),
        array(
            'group' => 'bfox_multichannel_orders',
            'name' => 'slcOrderNumberType',
            'type' => 'select',
            'value' => 'bfId',
            'position' => 3,
            'constraints' => 'externId|bfId|oxId'
        ),
         array(
            'group' => 'bfox_multichannel_orders',
            'name' => 'sOrderfolderNew',
            'type' => 'str',
            'value' => 'ORDERFOLDER_NEW',
            'position' => 4
        ),
        array(
            'group' => 'bfox_multichannel_orders',
            'name' => 'sOrderfolderShipped',
            'type' => 'str',
            'value' => 'ORDERFOLDER_FINISHED',
            'position' => 5
        ),
        array(
            'group' => 'bfox_multichannel_orders',
            'name' => 'sOrderfolderFba',
            'type' => 'str',
            'value' => 'ORDERFOLDER_FINISHED',
            'position' => 6
        ),
        array(
            'group' => 'bfox_multichannel_orders',
            'name' => 'slcOrderStatusUpdateType',
            'type' => 'select',
            'value' => 'excludeLines',
            'position' => 7,
            'constraints' => 'excludeLines|includeLines'
        ),
        array(
            'group'     => 'bfox_multichannel_orders',
            'name'      => 'aaOrdersStatusFolderMapping',
            'type'      => 'aarr',
            'value'     => [
                'ORDERFOLDER_NEW'           => 'Pending',
                'ORDERFOLDER_FINISHED'      => 'Shipped',
                'ORDERFOLDER_CANCELLED'     => 'Cancelled',
                'ORDERFOLDER_RETURNED'      => 'Returned',
                'ORDERFOLDER_PARTRETURNED'  => 'PartlyReturned',
            ],
            'position'  => 8,
        ),
        array(
            'group'     => 'bfox_multichannel_orders',
            'name'      => 'sOrderLastRun',
            'type'      => 'str',
            'value'     => '',
            'position'  => 9,
        ),
        array(
            'group'     => 'bfox_multichannel_orders',
            'name'      => 'sCustomerOrderNumberColumnName',
            'type'      => 'str',
            'value'     => '',
            'position'  => 10,
        ),
        array(
            'group'     => 'bfox_multichannel_orders',
            'name'      => 'sOrderNumberColumnName',
            'type'      => 'str',
            'value'     => '',
            'position'  => 11,
        ),
        array(
            'group'     => 'bfox_multichannel_orders',
            'name'      => 'sOrderReturnTrackingIdColumnName',
            'type'      => 'str',
            'value'     => '',
            'position'  => 12,
        ),
        array(
            'group'     => 'bfox_multichannel_orders',
            'name'      => 'blnOrderReduceQuantityOnOrderImport',
            'type'      => 'bool',
            'value'     => 'false',
            'position'  => 13,
        ),
        array(
            'group'     => 'bfox_multichannel_orders',
            'name'      => 'blnAddressAddToAdditionalInfo',
            'type'      => 'bool',
            'value'     => 'false',
            'position'  => 14,
        ),
        array(
            'group'    => 'shops',
            'name'     => 'aBfShopIdToShopIdMapping',
            'type'     => 'aarr',
            // BS-7864: leeres ARRAY statt Leerstring (sonst TypeError im Export).
            'value'    => array(),
            'position' => 1,
        ),
        array(
            'group'    => 'shops',
            'name'     => 'blnOverrideShopsLoopDefault',
            'type'     => 'bool',
            'value'    => 'false',
            'position' => 2,
        ),
        array(
            'group'    => 'shops',
            'name'     => 'aShopsToLoop',
            'type'     => 'arr',
            'value'    => '',
            'position' => 3,
        ),
        array(
            'group'    => 'bfox_multichannel_logging',
            'name'     => 'sLogLevelBf',
            'type'     => 'str',
            'value'    => 'DEBUG,WARN,ERROR',
            'position' => 1,
        ),
        array(
            'group'    => 'bfox_multichannel_logging',
            'name'     => 'sLogFilename',
            'type'     => 'str',
            'value'    => 'multichannel',
            'position' => 2,
        ),
        array(
            'group'    => 'bfox_multichannel_logging',
            'name'     => 'sLogCleanupInDays',
            'type'     => 'str',
            'value'    => '24',
            'position' => 3,
        ),
        array(
            'group'    => 'bfox_multichannel_storage',
            'name'     => 'strStorageDirectory',
            'type'     => 'str',
            'value'    => '/modules/bfox/multichannel/exchange',
            'position' => 1,
        ),
        array(
            'group'    => 'bfox_multichannel_storage',
            'name'     => 'sStorageDirectoryCleanUpInDays',
            'type'     => 'str',
            'value'    => '30',
            'position' => 2,
        ),
        array(
            'group'    => 'bfox_multichannel_storage',
            'name'     => 'boolStorageShopDirectory',
            'type'     => 'bool',
            'value'    => 'true',
            'position' => 3,
        ),
        array(
            'group'    => 'bfox_multichannel_storage',
            'name'     => 'sStorageFilenameOrders',
            'type'     => 'str',
            'value'    => 'Orders',
            'position' => 4,
        ),
        array(
            'group'    => 'bfox_multichannel_storage',
            'name'     => 'sStorageFilenameOrdersStatus',
            'type'     => 'str',
            'value'    => 'Orderstatus',
            'position' => 5,
        ),
        array(
            'group'    => 'bfox_multichannel_storage',
            'name'     => 'sStorageFilenameManufacturers',
            'type'     => 'str',
            'value'    => 'Manufacturers',
            'position' => 6,
        ),
        array(
            'group'    => 'bfox_multichannel_storage',
            'name'     => 'sStorageFilenameCategories',
            'type'     => 'str',
            'value'    => 'Categories',
            'position' => 7,
        ),
        array(
            'group'    => 'bfox_multichannel_storage',
            'name'     => 'sStorageFilenameProducts',
            'type'     => 'str',
            'value'    => 'Products',
            'position' => 8,
        ),
        array(
            'group'    => 'bfox_multichannel_storage',
            'name'     => 'sStorageFilenameProductsUpdate',
            'type'     => 'str',
            'value'    => 'ProductUpdate',
            'position' => 9,
        ),
        array(
            'group'    => 'bfox_multichannel_storage',
            'name'     => 'sStorageFilenameProductDelete',
            'type'     => 'str',
            'value'    => 'ProductDelete',
            'position' => 10,
        ),
        array(
            'group'    => 'bfox_multichannel_scriptLogger',
            'name'     => 'sScriptLoggerCleanupDBHanging',
            'type'     => 'str',
            'value'    => '18000',
            'position' => 1,
        ),
        array(
            'group'    => 'bfox_multichannel_scriptLogger',
            'name'     => 'sScriptLoggerCleanupDBRemoval',
            'type'     => 'str',
            'value'    => '100',
            'position' => 2,
        ),


	),
);
