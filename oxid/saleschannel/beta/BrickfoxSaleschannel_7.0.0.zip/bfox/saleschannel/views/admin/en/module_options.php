<?php
/**
 * German module translations
 *

 *
 */


  namespace bfox\saleschannel\classes;


$aLang = array(
	'charset'										=> 'ISO-8859-15',

	// logging
	'SHOP_MODULE_GROUP_logging'						=> 'Logging setting',
	'SHOP_MODULE_sLogFilename'						=> 'Log filename prefix',
	'SHOP_MODULE_sLogLevelBF'					    => 'Log level',
	'SHOP_MODULE_sLogCleanupInDays'					=> 'Log cleanup time in days',

	// notifier
	'SHOP_MODULE_GROUP_notifier'					=> 'Notifier setting',
	'SHOP_MODULE_sNotifierSubject'					=> 'Email subject',
	'SHOP_MODULE_sNotifierReceiverEmail'			=> 'Email receiver',
	'SHOP_MODULE_sNotifierSenderEmail'				=> 'Sender name',
	'SHOP_MODULE_sNotifierSenderName'				=> 'Sender email',
	'SHOP_MODULE_sNotifierAppendLogfileLines'		=> 'Logfile lines',

	// storage
	'SHOP_MODULE_GROUP_storage'						=> 'Storage setting',
	'SHOP_MODULE_sStorageDirectory'					=> 'Directory',
	'SHOP_MODULE_sStorageFilenameOrders'			=> 'Export orders file name',
	'SHOP_MODULE_sStorageFilenameOrdersStatus'		=> 'Import orders status file name',
	'SHOP_MODULE_sStorageFilenameManufacturers'		=> 'Import manufacturers file name',
	'SHOP_MODULE_sStorageFilenameCategories'		=> 'Import categories file name',
	'SHOP_MODULE_sStorageFilenameProducts'			=> 'Import products file name',
	'SHOP_MODULE_sStorageFilenameProductsUpdate'	=> 'Import products update file name',
	'SHOP_MODULE_sStorageFilenameProductsAssign'	=> 'Import products assignments file name',
	'SHOP_MODULE_sStorageFilenameProductsMap'		=> 'Import products id mapping file name',
	'SHOP_MODULE_sStorageFilenameCategoriesMap'		=> 'Import categories id mapping file name',
    'SHOP_MODULE_sStorageFilenameManufacturersMap'	=> 'Import manufacturers id mapping file name',

	// scriptlogger
	'SHOP_MODULE_GROUP_scriptLogger'				=> 'ScriptLogger setting',
	'SHOP_MODULE_sScriptLoggerCleanupDBHanging'		=> 'ScriptLogger cleanup time in seconds for hanging processes',
	'SHOP_MODULE_sScriptLoggerCleanupDBRemoval'		=> 'ScriptLogger cleanup time in days for old database entries',

	// tax
	'SHOP_MODULE_GROUP_tax'							=> 'Tax setting',
	'SHOP_MODULE_sTaxReduced'						=> 'Reduced tax (BF taxClassId = 2)',

	// mailings
	'SHOP_MODULE_GROUP_mailings'					=> 'Mailing setting',
	'SHOP_MODULE_bSendShippingConfirmationMail'		=> 'Send shipping confirmation mail',

	// delivery to category matching
	'SHOP_MODULE_GROUP_delToCatMatching'			=> 'Delivery to category matching',
	'SHOP_MODULE_sDefaultDelToCatMatching'			=> 'Default matching',

	// bf attributes
	'SHOP_MODULE_GROUP_bfAttributes'				=> 'Brickfox attributes',
	'SHOP_MODULE_aBfAttributesToArticleMapping'		=> 'Hidden brickfox attributes to article mapping',

    // prices
    'SHOP_MODULE_GROUP_prices'				        => 'Price settings',
    'SHOP_MODULE_aPriceGrossStorageMapping'		    => 'brickfox currency code to price field mapping',
    'SHOP_MODULE_aSpecialPriceStorageMapping'		=> 'brickfox currency code to special price field mapping',

    // ImportExport Settings
    'SHOP_MODULE_GROUP_bfImportExportSettings'		=> 'Import / Export Settings',

    'SHOP_MODULE_selImportManufacturerAction'		     => 'Manufacturers not transmitted in XML.',
    'SHOP_MODULE_selImportManufacturerAction_Delete'   => ' - Delete from Database',
    'SHOP_MODULE_selImportManufacturerAction_Inactive' => ' - Keep them, as Inactive.',

    // shops
    'SHOP_MODULE_GROUP_shops'				        => 'Shops settings',
    'SHOP_MODULE_aBfShopIdToShopIdMapping'		    => 'Brickfox shop id to Oxid shop id mapping',
    'SHOP_MODULE_blnOverrideShopsLoopDefault'		=> 'Use custom Shop id List to loop',
    'HELP_SHOP_MODULE_blnOverrideShopsLoopDefault'	=> 'Instead the default (list of all active shops in oxid), uses array below.',
    'SHOP_MODULE_aShopsToLoop'		                => 'Custom Exchange Shops',
    'HELP_SHOP_MODULE_aShopsToLoop'		            => 'Use format 1,2,4,6 ',

    // orders
    'SHOP_MODULE_GROUP_orders'                      => 'Orders export',
    'SHOP_MODULE_sOverwriteCustNr'                  => 'Overwrite customer number with custom field (if it is not empty)',
    'SHOP_MODULE_bExportBirthdate'                  => 'Export customer birth date',
    'SHOP_MODULE_bExportTargetgroup'                => 'Export customer target group (from nfc_groupdiscount)',
    'SHOP_MODULE_blUpdateStockOnCanceledOrders'     => 'Order Status: Update stocks (increase) when cancelling Orders',


    // payments
    'SHOP_MODULE_GROUP_payments'                    => 'Payments',
    'SHOP_MODULE_aaPaymentClassMapping'              => 'Payment types and their mapped classes',

    // REST API
    'SHOP_MODULE_GROUP_bfrestapi'			        => 'Brickfox API settings',
    'SHOP_MODULE_sBfRestApiUrl'                     => 'URL of Brickfox API',
    'SHOP_MODULE_sBfRestApiKey'                     => 'API key',
    'SHOP_MODULE_sBfRestApiLastRun'                 => 'Date of Last Update. Do not change!',

    // ORDER FOLDERS
    'ORDERFOLDER_CANCELLED'                         => 'Cancelled',
    'ORDERFOLDER_RETURNED'                          => 'Order Returned',
    'ORDERFOLDER_PARTRETURNED'                      => 'Item Returned',

);
