<?php
/**
 * Module configuration
 *
 * Pay attention:
 * settings name values should not have more than 32 characters.
 */

// Metadata version
$sMetadataVersion = '2.0';

// Module information
$aModule = array(
    'id'          => 'saleschannel',
    'title'       => 'Brickfox Saleschannel',
    'description'  => array(
        'de' => 'Brickfox Saleschannenl Module for Oxid 6 / 7.',
        'en' => 'Brickfox Saleschannenl Module for Oxid 6 / 7.',
    ),
    'thumbnail'   => 'images/brickfoxLogo.png',
    'version'     => '7.0.0',
    'author'      => 'brickfox GmbH',
    'url'         => 'http://www.brickfox.de',
    'email'       => 'support@brickfox.de',

    'extend'      => array(
        \OxidEsales\Eshop\Application\Model\Article::class       => \bfox\saleschannel\classes\model\oxid\Article::class,
        \OxidEsales\Eshop\Application\Model\Category::class      => \bfox\saleschannel\classes\model\oxid\Category::class,
        \OxidEsales\Eshop\Application\Model\Manufacturer::class  => \bfox\saleschannel\classes\model\oxid\Manufacturer::class,
        \OxidEsales\Eshop\Application\Model\Order::class         => \bfox\saleschannel\classes\model\OrderModel::class
    ),

    'controllers' => array(

    ),
    'events'       => array(
    ),

    'templates' => array(
    ),

    'blocks' => array(
    ),

    'settings'    => array(
        array(
            'group'    => 'logging',
            'name'     => 'sLogLevelBF',
            'type'     => 'str',
            'value'    => 'DEBUG,WARN,ERROR',
            'position' => 1,
        ),
        array(
            'group'    => 'logging',
            'name'     => 'sLogFilename',
            'type'     => 'str',
            'value'    => 'saleschannel',
            'position' => 2,
        ),
        array(
            'group'    => 'logging',
            'name'     => 'sLogCleanupInDays',
            'type'     => 'str',
            'value'    => '24',
            'position' => 3,
        ),
//        array(
//            'group'    => 'notifier',
//            'name'     => 'sNotifierSubject',
//            'type'     => 'str',
//            'value'    => 'saleschannel: An import or export error occurred!',
//            'position' => 1,
//        ),
//        array(
//            'group'    => 'notifier',
//            'name'     => 'sNotifierReceiverEmail',
//            'type'     => 'str',
//            'value'    => '',
//            'position' => 2,
//        ),
//        array(
//            'group'    => 'notifier',
//            'name'     => 'sNotifierSenderEmail',
//            'type'     => 'str',
//            'value'    => '',
//            'position' => 3,
//        ),
//        array(
//            'group'    => 'notifier',
//            'name'     => 'sNotifierSenderName',
//            'type'     => 'str',
//            'value'    => 'Brickfox',
//            'position' => 4,
//        ),
//        array(
//            'group'    => 'notifier',
//            'name'     => 'sNotifierAppendLogfileLines',
//            'type'     => 'str',
//            'value'    => '100',
//            'position' => 5,
//        ),
        array(
            'group'    => 'storage',
            'name'     => 'sStorageDirectory',
            'type'     => 'str',
            'value'    => '/modules/bfox/saleschannel/exchange',
            'position' => 1,
        ),
        array(
            'group'    => 'storage',
            'name'     => 'sStorageFilenameOrders',
            'type'     => 'str',
            'value'    => 'Orders',
            'position' => 2,
        ),
        array(
            'group'    => 'storage',
            'name'     => 'sStorageFilenameOrdersStatus',
            'type'     => 'str',
            'value'    => 'Orderstatus',
            'position' => 3,
        ),
        array(
            'group'    => 'storage',
            'name'     => 'sStorageFilenameManufacturers',
            'type'     => 'str',
            'value'    => 'Manufacturers',
            'position' => 4,
        ),
        array(
            'group'    => 'storage',
            'name'     => 'sStorageFilenameCategories',
            'type'     => 'str',
            'value'    => 'Categories',
            'position' => 5,
        ),
        array(
            'group'    => 'storage',
            'name'     => 'sStorageFilenameProducts',
            'type'     => 'str',
            'value'    => 'Products',
            'position' => 6,
        ),
        array(
            'group'    => 'storage',
            'name'     => 'sStorageFilenameProductsUpdate',
            'type'     => 'str',
            'value'    => 'ProductsUpdate',
            'position' => 7,
        ),
        array(
            'group'    => 'storage',
            'name'     => 'sStorageFilenameProductsAssign',
            'type'     => 'str',
            'value'    => 'ProductsAssignments',
            'position' => 8,
        ),
        array(
            'group'    => 'storage',
            'name'     => 'sStorageFilenameProductsMap',
            'type'     => 'str',
            'value'    => 'ProductsIdMapping',
            'position' => 9,
        ),
        array(
            'group'    => 'storage',
            'name'     => 'sStorageFilenameCategoriesMap',
            'type'     => 'str',
            'value'    => 'CategoriesIdMapping',
            'position' => 10,
        ),
        array(
            'group'    => 'storage',
            'name'     => 'sStorageFilenameManufacturersMap',
            'type'     => 'str',
            'value'    => 'ManufacturersIdMapping',
            'position' => 11,
        ),
        array(
            'group'    => 'scriptLogger',
            'name'     => 'sScriptLoggerCleanupDBHanging',
            'type'     => 'str',
            'value'    => '18000',
            'position' => 1,
        ),
        array(
            'group'    => 'scriptLogger',
            'name'     => 'sScriptLoggerCleanupDBRemoval',
            'type'     => 'str',
            'value'    => '100',
            'position' => 2,
        ),
        array(
            'group'    => 'tax',
            'name'     => 'sTaxReduced',
            'type'     => 'str',
            'value'    => 7,
            'position' => 1,
        ),
        array(
            'group'    => 'mailings',
            'name'     => 'bSendShippingConfirmationMail',
            'type'     => 'bool',
            'value'    => 1,
            'position' => 1,
        ),
        array(
            'group'    => 'delToCatMatching',
            'name'     => 'sDefaultDelToCatMatching',
            'type'     => 'str',
            'value'    => 'Versandkostenregel Standard',
            'position' => 1,
        ),
        array(
            'group'    => 'bfAttributes',
            'name'     => 'aBfAttributesToArticleMapping',
            'type'     => 'aarr',
            'value'    => '',
            'position' => 1,
        ),
        array(
            'group'     => 'prices',
            'name'      => 'aPriceGrossStorageMapping',
            'type'      => 'aarr',
            'value'     => 'EUR => oxarticles__oxprice',
            'position'  => 1,
        ),
        array(
            'group'     => 'prices',
            'name'      => 'aSpecialPriceStorageMapping',
            'type'      => 'aarr',
            'value'     => 'EUR => oxarticles__oxpricea',
            'position'  => 2,
        ),
        array(
            'group'    => 'bfImportExportSettings',
            'name'     => 'selImportManufacturerAction',
            'type'     => 'select',
            'value'    => 'Inactive',
            'position' => 2,
            'constraints' => 'Delete|Inactive'
        ),
//        array(
//            'group'    => 'shops',
//            'name'     => 'aBfShopIdToShopIdMapping',
//            'type'     => 'aarr',
//            'value'    => '',
//            'position' => 1,
//        ),
        array(
            'group'    => 'shops',
            'name'     => 'blnOverrideShopsLoopDefault',
            'type'     => 'bool',
            'value'    => 'false',
            'position' => 2,
        ),
        array(
            'group'    => 'shops',
            'name'     => 'aShopsToLoop',
            'type'     => 'arr',
            'value'    => '',
            'position' => 3,
        ),
        array(
            'group'     => 'orders',
            'name'      => 'blUpdateStockOnCanceledOrders',
            'type'      => 'bool',
            'value'     => 1,
            'position'  => 1,
        ),
        array(
            'group'     => 'orders',
            'name'      => 'sOverwriteCustNr',
            'type'      => 'str',
            'value'     => '',
            'position'  => 2,
        ),
        array(
            'group'     => 'orders',
            'name'      => 'bExportTargetgroup',
            'type'      => 'bool',
            'value'     => 0,
            'position'  => 3,
        ),
        array(
            'group'    => 'payments',
            'name'     => 'aaPaymentClassMapping',
            'type'     => 'aarr',
            'value'    => array(
                'oxidbarzahlen'             => 'PaymentBarzahlen',
                'oxidcreditcard'            => 'PaymentHeidelpay',
                'oxiddebitnote'             => 'PaymentBanktransfer',
                'oxidpaypal'                => 'PaymentPaypal',
                'fcpocreditcard'            => 'PaymentPayone',
                'klarna_part'               => 'PaymentKlarna',
                'klarna_invoice'            => 'PaymentKlarna',
                'klarna_pay_later'          => 'PaymentKlarna',
                'computopcw_creditcard'     => 'PaymentHeidelpay',
                'pi_ratepay_rechnung'       => 'PaymentRatepay',
                'pi_ratepay_rate'           => 'PaymentRatepay',
                'skrill'                    => 'PaymentSkrill',
                'jagamazon'                 => 'PaymentAmazonPayment',
                'bestitamazon'              => 'PaymentBestItAmazon',
                'trosofortgateway_su'       => 'PaymentSofortueberweisung',
                'standard'                  => 'PaymentStandard',
                ),
            'position' => 1,
        ),
//        array(
//            'group'     => 'bfrestapi',
//            'name'      => 'sBfRestApiUrl',
//            'type'      => 'str',
//            'value'     => '',
//            'position'  => 1,
//        ),
//        array(
//            'group'     => 'bfrestapi',
//            'name'      => 'sBfRestApiKey',
//            'type'      => 'str',
//            'value'     => '',
//            'position'  => 2,
//        ),
//        array(
//            'group'     => 'bfrestapi',
//            'name'      => 'sBfRestApiLastRun',
//            'type'      => 'str',
//            'value'     => '',
//            'position'  => 3,
//        ),

    ),
);
