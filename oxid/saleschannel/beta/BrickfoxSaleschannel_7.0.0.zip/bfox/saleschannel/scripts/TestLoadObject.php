<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 31.01.19
 * Time: 11:18
 */

echo "Init...";

//Call the Oxid bootstrap file to load all the necessary content
$bootstrapPath = array_shift(explode("modules", dirname(__FILE__)));
require_once $bootstrapPath . 'bootstrap.php';

$validActions	= array('showVersion', 'Article', 'Attribute', 'Category', 'Manufacturer', 'Shop', 'Bfmap', 'Language');
$action			= oxRegistry::getRequest()->getRequestParameter('action');


if(true === isset($action) && '' != $action && true === in_array($action, $validActions))
{
    $oxshopid = 0;

    if(!empty($_GET['sId']))
    {
        $oxshopid =  $_GET['sId'];
        unset($_GET['sId']);
    }

    oxRegistry::getSession()->setVariable("shp", $oxshopid);
    oxRegistry::getSession()->setVariable('currentadminshop', $oxshopid);
    oxRegistry::getConfig()->setShopId($oxshopid);

    $moduleAction = false;
    switch($action)
    {
        case 'Article':
            $object = "oxArticle";
            $table = "oxarticles";
            $moduleAction = true;
            break;


        case 'Attribute':
            $object = "oxAttribute";
            $table = "oxattribute";
            $moduleAction = true;
            break;


        case 'Category':
            $object = "oxCategory";
            $table = "oxcategories";
            $moduleAction = true;
            break;


        case 'Manufacturer':
            $object = "oxManufacturer";
            $table = "oxmanufacturers";
            $moduleAction = true;
            break;


        case 'Shop':
            $object = "oxShop";
            $table = "oxshops";
            $moduleAction = true;
            break;


        case 'showVersion':
            echo "This is the testscript version.";
            break;


        case 'Bfmap':
            $object = "MappingModel";
            $table = "bfmapping";
            $moduleAction = true;
            break;

        case 'Language':
            print_r("<p>***********   Array, List of : Languages ***************</p>");
            var_dump(oxRegistry::getLang()->getLanguageArray());
            break;

        default:
            echo "Mismatch error!";
            break;
    }

    if($moduleAction)
    {
        unset($_GET['action']);
        setView();

        if(!empty($_GET['oxid']))
        {
            $oxid =  $_GET['oxid'];
            unset($_GET['oxid']);
            getOneObject($object, $oxid);
        }
        else
        {
            if (!empty($_GET['limit'])){
                getObjectSmallList($object, $table, $_GET['limit']);
            }
            else{
                getObjectSmallList($object, $table);
            }
        }
    }
}
else{
    echo "Action Not supported.";
}

function setView(){
    $oxView = oxNew('oxview');
    oxRegistry::getConfig()->setActiveView($oxView);
}

function getObjectSmallList($object, $table, $limit = 12, $skip = 0)
{
    $list = oxNew('oxlist');
    $list->init($object, $table);
    $list->setSqlLimit($skip,$limit);
    $list->getList();

    $aA = $list->getArray();

    outputResults($aA, $list->count(), $object, $skip, $limit);
}


function getOneObject($object, $oxid)
{
    var_dump($oxid);

    $obj = oxNew($object);
    $obj->load($oxid);

    outputResults($obj, 1, '', 0, 1);
}


function outputResults($aObjects, $count, $object, $skip, $limit){

    print_r("<p>***********   (Object){$object}, List of : {$count}  ***************</p>");

    print_r("<p>***********   Showing $limit, skipped  {$skip}  ***************</p>");

    if ($count > 1){
        foreach ($aObjects as $obj){
            echo "<p><pre>";
            print_r($obj);
            echo "</pre></p>";
            echo "<p>###################################</p>";
        }
    }
    else{
        echo "<p><pre>";
        print_r($aObjects);
        echo "</pre></p>";
        echo "<p>###################################</p>";
    }

    exit();
}

