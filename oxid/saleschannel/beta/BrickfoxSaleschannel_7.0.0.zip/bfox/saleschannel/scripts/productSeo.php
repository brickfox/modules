<?php
/**
 * productSeo.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2019 brickfox GmbH http://www.brickfox.de
 */

namespace bfox\saleschannel;

use bfox\saleschannel\classes\controller as Controllers;
use \OxidEsales\Eshop as Oxid;

callOxidBootstrap();
checkOutputDebug();

$productSeoController = new Controllers\ProductSeoController(
    Oxid\Core\Registry::getRequest()->getRequestParameter('sId'),
    Oxid\Core\Registry::getRequest()->getRequestParameter('bfId')
);

$productSeoController->redirect();

/**
 * Calls the Oxid bootstrap file to load all the Oxid framework and its contents
 */
function callOxidBootstrap()
{
    $dir           = dirname(__FILE__);
    $pathArray     = explode("modules", $dir);
    $bootstrapPath = array_shift($pathArray);

    require_once $bootstrapPath . 'bootstrap.php';
}

/**
 *  Use the debug_mode for Exceptions and Errors description.
 *  Here we change how to handle exceptions as for PHP 7 they are Errors instances.
 */
function checkOutputDebug()
{
    $debug_mode = Oxid\Core\Registry::getRequest()->getRequestParameter('debug_mode');

    if (true === isset($debug_mode) && $debug_mode === 'j') {
        echo "<h2>debug function ON</h2>";

        set_exception_handler(
            [
                new classes\exception\ExceptionHandler(),
                'handleUncaughtException'
            ]
        );

        set_error_handler(
            [
                new classes\exception\ExceptionHandler(),
                'handleUncaughtError'
            ]
        );
    }
}
