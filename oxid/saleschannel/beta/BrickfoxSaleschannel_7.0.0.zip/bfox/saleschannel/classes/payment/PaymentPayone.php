<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 27.02.19
 * Time: 13:06
 */

namespace bfox\saleschannel\classes\payment;


class PaymentPayone extends AbstractPayment
{
    /**
     * getPaymentMethodValues
     *
     * @return array payment method values
     */
    public function getPaymentMethodValues()
    {
        $result = array();

        $oxOrderModel  = $this->getOxOrderModel();
        $poTransaction = $oxOrderModel->getFieldData('FCPOTXID');
        $poRefNr       = $oxOrderModel->getFieldData('FCPOREFNR');

        $result['transactionId'] = $poTransaction;
        $result['refNr']         = $poRefNr;

        return $result;
    }
}