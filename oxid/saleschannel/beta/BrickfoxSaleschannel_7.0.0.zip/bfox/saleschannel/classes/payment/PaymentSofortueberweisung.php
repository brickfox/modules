<?php
/**
 * PaymentPaypal
 *

 *
 */

namespace bfox\saleschannel\classes\payment;


class PaymentSofortueberweisung extends AbstractPayment
{
    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/

    /**
     * getPaymentMethodValues
     *
     * @return array payment method values
     */
    public function getPaymentMethodValues()
    {
        $result							= array();

        $oxOrderModel					= $this->getOxOrderModel();

        if($oxOrderModel->getFieldData('oxpaymenttype') === 'trosofortgateway_su')
        {
            $oxTransactionId				= $oxOrderModel->getFieldData('oxtransid');
        }

        if(false === is_null($oxTransactionId) && '' != $oxTransactionId)
        {
            $result['transaction'] = $oxTransactionId;
        }

        return $result;
    }
}