<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 27.02.19
 * Time: 13:15
 */

namespace bfox\saleschannel\classes\payment;

use bfox\saleschannel\classes\payment\model as PaymentModels;
use bfox\saleschannel\classes\util\OxidRegistry;

class PaymentSkrill extends AbstractPayment
{
    /**
     * getPaymentMethodValues
     *
     * @return array payment method values
     */
    public function getPaymentMethodValues()
    {
        $result                         = array();
        $oxOrderModel                   = $this->getOxOrderModel();

        /** @var PaymentModels\PaymentSkrillModel $skrillPaymentTypeModel */
        $skrillPaymentTypeModel         = oxNew(PaymentModels\PaymentSkrillModel::class);
        $skrillPaymentTypeModel->loadByPaymentIdAndShopId($oxOrderModel->getFieldData('oxpaymenttype'), OxidRegistry::getActiveShopId());

        if(true === $skrillPaymentTypeModel->isLoaded())
        {
            $oxType         = $skrillPaymentTypeModel->getFieldData('oxtype');
            $oxTypeParts    = explode('__', $oxType);

            if (true === isset($oxTypeParts[1]))
            {
                $result['subType']       = $oxTypeParts[1];
            }
        }

        // unique id
        $result['uniqueId']		    = $oxOrderModel->getFieldData('oxpayid');

        // reference id
        $result['referenceId']		= $oxOrderModel->getFieldData('oxxid');

        return $result;
    }
}