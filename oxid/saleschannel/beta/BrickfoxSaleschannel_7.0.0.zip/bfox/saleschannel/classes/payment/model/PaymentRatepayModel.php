<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 27.02.19
 * Time: 13:24
 */

namespace bfox\saleschannel\classes\payment\model;

use bfox\saleschannel\classes\model\oxid as OxidModels;


class PaymentRatepayModel extends OxidModels\BaseModel
{
    /**
     * Constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->init('pi_ratepay_orders');
    }

    /**
     * loadByOrderNumber.
     *
     * @param string $orderNumber order number
     * @return boolean is loaded
     */
    public function loadByOrderNumber($orderNumber)
    {
        $sSelect = $this->buildSelectString(
            array($this->getViewName().'.order_number' => $orderNumber)
        );

        return $this->_isLoaded = $this->assignRecord($sSelect);
    }

}