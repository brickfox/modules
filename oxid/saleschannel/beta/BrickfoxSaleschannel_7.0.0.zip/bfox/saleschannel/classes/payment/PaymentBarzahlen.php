<?php
/**
 * PaymentAmazonPayment
 *
 */


namespace bfox\saleschannel\classes\payment;


class PaymentBarzahlen extends AbstractPayment
{
    /*****************************************************************************
     * Callable functions
     *****************************************************************************/

    /**
     * getPaymentMethodValues
     *
     * @return array payment method values
     */
    public function getPaymentMethodValues()
    {
        $result = array();

        $oxOrderModel  = $this->getOxOrderModel();
        $bzTransaction = $oxOrderModel->getFieldData('BZTRANSACTION');
        $bzState       = $oxOrderModel->getFieldData('BZSTATE');
        $bzRefunds     = $oxOrderModel->getFieldData('BZREFUNDS');

        $result['transactionId'] = $bzTransaction;
        $result['state']         = $bzState;
        $result['refunds']       = $bzRefunds;

        return $result;
    }
}