<?php
/**
 * PaymentRatepay
 *

 *
 */


namespace bfox\saleschannel\classes\payment;

  use bfox\saleschannel\classes\payment\model as PaymentModels;


class PaymentRatepay extends AbstractPayment
{
    /**
    * getPaymentMethodValues
    *
    * @return array payment method values
    */
    public function getPaymentMethodValues()
    {
        $result                         = array();
        $oxOrderModel                   = $this->getOxOrderModel();
        $ratepayOrdersModel             = oxNew(PaymentModels\PaymentRatepayModel::class);

        $ratepayOrdersModel->loadByOrderNumber($oxOrderModel->getFieldData('oxid'));

        if(true === $ratepayOrdersModel->isLoaded())
        {
            // transaction id
            $result['transactionId']    = $ratepayOrdersModel->getFieldData('transaction_id');

            // descriptor
            $result['descriptor']       = $ratepayOrdersModel->getFieldData('descriptor');
        }

        return $result;
    }

}