<?php
/**
 * PaymentAmazonPayment
 *

 *
 */


namespace bfox\saleschannel\classes\payment;


class PaymentAmazonPayment extends AbstractPayment
{
    /*****************************************************************************
    *
    * Callable functions
    *
    *****************************************************************************/

    /**
    * getPaymentMethodValues
    *
    * @return array payment method values
    */
    public function getPaymentMethodValues()
    {
        $result					= array();

        $oxOrderModel			= $this->getOxOrderModel();
        $amazonOrderReferenceId	= $oxOrderModel->getFieldData('JAGAMAZONORDERREFERENCEID');
        $amazonAuthorizationId  = $oxOrderModel->getFieldData('JAGAMAZONAUTHORIZATIONID');
        $amazonCaptureId		= $oxOrderModel->getFieldData('JAGAMAZONCAPTUREID');

        $result['orderReferenceId'] = $amazonOrderReferenceId;
        $result['authorizationId']  = $amazonAuthorizationId;
        $result['captureId']        = $amazonCaptureId;

        return $result;
    }
}
