<?php
/**
 * IPayment
 *

 *
 */


  namespace bfox\saleschannel\classes\payment;


interface IPayment
{
	/*****************************************************************************
	 *
	 * Callable functions
	 *
	 *****************************************************************************/

	/**
	 * getPaymentMethodValues
	 *
	 * @return array payment method values
	 */
	public function getPaymentMethodValues();
}