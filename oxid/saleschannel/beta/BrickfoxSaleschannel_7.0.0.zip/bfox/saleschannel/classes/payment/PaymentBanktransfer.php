<?php
/**
 * PaymentBanktransfer
 *

 *
 */


namespace bfox\saleschannel\classes\payment;


class PaymentBanktransfer extends AbstractPayment
{
	/*****************************************************************************
	 *
	 * Callable functions
	 *
	 *****************************************************************************/

	/**
	 * getPaymentMethodValues
	 *
	 * @return array payment method values
	 */
	public function getPaymentMethodValues()
	{
		$result					= array();
		$additionalPaymentData	= $this->getAdditionalPaymentData();

		// bank name
		if(true === array_key_exists('lsbankname', $additionalPaymentData))
		{
			$result['debitBankName']	= $additionalPaymentData['lsbankname'];
		}

		// bank code
		if(true === array_key_exists('lsblz', $additionalPaymentData))
		{
			$result['debitBankCode']	= $additionalPaymentData['lsblz'];
		}

		// account number
		if(true === array_key_exists('lsktonr', $additionalPaymentData))
		{
			$result['debitAccountNumber']	= $additionalPaymentData['lsktonr'];
		}

		// account holder
		if(true === array_key_exists('lsktoinhaber', $additionalPaymentData))
		{
			$result['debitAccountHolder'] = $additionalPaymentData['lsktoinhaber'];
		}

		return $result;
	}
}