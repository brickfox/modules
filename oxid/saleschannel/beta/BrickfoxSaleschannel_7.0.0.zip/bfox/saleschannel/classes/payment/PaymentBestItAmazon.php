<?php
/**
 * PaymentBestItAmazon
 *

 *
 */


namespace bfox\saleschannel\classes\payment;


class PaymentBestItAmazon extends AbstractPayment
{
    /*****************************************************************************
    *
    * Callable functions
    *
    *****************************************************************************/

    /**
    * getPaymentMethodValues
    *
    * @return array payment method values
    */
    public function getPaymentMethodValues()
    {
        $result					= array();

        $oxOrderModel			= $this->getOxOrderModel();
        $amazonOrderReferenceId	= $oxOrderModel->getFieldData('BESTITAMAZONORDERREFERENCEID');
        $amazonAuthorizationId  = $oxOrderModel->getFieldData('BESTITAMAZONAUTHORIZATIONID');
        $amazonCaptureId		= $oxOrderModel->getFieldData('BESTITAMAZONCAPTUREID');

        $result['orderReferenceId'] = $amazonOrderReferenceId;
        $result['authorizationId']  = $amazonAuthorizationId;
        $result['captureId']        = $amazonCaptureId;

        return $result;
    }
}
