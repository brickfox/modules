<?php
/**
 * PaymentStandard
 *

 *
 */


namespace bfox\saleschannel\classes\payment;


class PaymentStandard extends AbstractPayment
{
	/*****************************************************************************
	 *
	 * Callable functions
	 *
	 *****************************************************************************/

	/**
	 * getPaymentMethodValues
	 *
	 * @return array payment method values
	 */
	public function getPaymentMethodValues()
	{
		return	array();
	}
}