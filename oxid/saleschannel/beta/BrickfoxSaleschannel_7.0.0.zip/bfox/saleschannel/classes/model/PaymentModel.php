<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 26.02.19
 * Time: 13:22
 */

namespace bfox\saleschannel\classes\model;


class PaymentModel extends \OxidEsales\Eshop\Application\Model\Payment
{

    /**
     * brickfox types
     */
    const BF_TYPE_ABSOLUTE           = 0,
        BF_TYPE_RELATIVE             = 1;




    /**
     * getPaymentType.
     *
     * @return string payment type
     */
    public function getPaymentType()
    {
        $result = null;

        // relative or absolute
        $type           = $this->getFieldData('oxaddsumtype');

        $typeMapping    = $this->getTypeMapping();

        if(true === array_key_exists($type, $typeMapping))
        {
            $result = $typeMapping[$type];
        }

        return $result;
    }


    /**
     * getTypeMapping.
     *
     * @return array type mapping
     */
    private function getTypeMapping()
    {
        return array(
            '%'     => self::BF_TYPE_RELATIVE,
            'abs'   => self::BF_TYPE_ABSOLUTE
        );
    }
}