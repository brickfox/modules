<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 06.02.19
 * Time: 13:34
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\model\oxid\BaseModel;
use \OxidEsales\Eshop as Oxid;

class PriceToArticleModel extends BaseModel
{
    /*****************************************************************************
     *
     * Class constants
     *
     *****************************************************************************/

    /**
     * table fields
     * @var string
     */
    const OXID				= 'OXID',
        OXSHOPID			= 'OXSHOPID',
        OXARTID			= 'OXARTID',
        OXADDABS			= 'OXADDABS',
        OXADDPERC			= 'OXADDPERC',
        OXAMOUNT			= 'OXAMOUNT',
        OXAMOUNTTO		= 'OXAMOUNTTO';

    /*****************************************************************************
     *
     * Class properties
     *
     *****************************************************************************/

    /**
     * oxid
     * @var string
     */
    private $oxid = null;

    /**
     * ox shop id
     * @var string
     */
    private $oxShopId = null;

    /**
     * ox article id
     * @var string
     */
    private $oxArtId = null;

    /**
     * ox add absolute
     * @var float
     */
    private $oxAddAbs = null;

    /**
     * ox add percent
     * @var float
     */
    private $oxAddPerc = null;

    /**
     * ox amount
     * @var float
     */
    private $oxAmount = null;

    /**
     * ox amount to
     * @var float
     */
    private $oxAmountTo = null;

    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/

    /**
     * Contructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->init('oxprice2article');
    }

    /**
     * getOxPriceToArticleData
     *
     * @param integer $oxArticleId ox article id
     * @return array result
     */
    public static function getOxPriceToArticleData($oxArticleId)
    {
        $result		= array();

        if(false === is_null($oxArticleId) && '' != $oxArticleId)
        {
            /** @var PriceToArticleListModel $priceToArticleListModel */
            $priceToArticleListModel	= oxNew(PriceToArticleListModel::class);
            $priceToArticleListModel->loadArticleAssignments($oxArticleId);

            foreach($priceToArticleListModel as $priceToArticleModel)
            {
                $key = $priceToArticleModel->getFieldData('oxamount') . '_' . $priceToArticleModel->getFieldData('oxamountto');
                $result[$key] = array(
                    self::OXID			=> $priceToArticleModel->getFieldData('oxid'),
                    self::OXSHOPID		=> $priceToArticleModel->getFieldData('oxshopid'),
                    self::OXARTID		=> $priceToArticleModel->getFieldData('oxartid'),
                    self::OXADDABS		=> $priceToArticleModel->getFieldData('oxaddabs'),
                    self::OXADDPERC		=> $priceToArticleModel->getFieldData('oxaddperc'),
                    self::OXAMOUNT		=> $priceToArticleModel->getFieldData('oxamount'),
                    self::OXAMOUNTTO	=> $priceToArticleModel->getFieldData('oxamountto'),
                );
            }
        }
        return $result;
    }

    /**
     * save.
     */
    public function save()
    {
        if(true === is_null($this->getOxid()))
        {
            $this->setOxid(Oxid\Core\UtilsObject::getInstance()->generateUID());
        }

        $this->assign(
            array(
                'oxprice2article__oxid'					=> $this->getOxid(),
                'oxprice2article__oxshopid'				=> $this->getOxShopId(),
                'oxprice2article__oxartid'				=> $this->getOxArtId(),
                'oxprice2article__oxaddabs'				=> $this->getOxAddAbs(),
                'oxprice2article__oxaddperc'			=> $this->getOxAddPerc(),
                'oxprice2article__oxamount'				=> $this->getOxAmount(),
                'oxprice2article__oxamountto'			=> $this->getOxAmountTo(),
            )
        );
        parent::save();
    }

    /**
     * getOxid.
     *
     * @return integer oxid
     */
    public function getOxid()
    {
        return $this->oxid;
    }

    /**
     * setOxid.
     *
     * @param integer $oxid oxid
     */
    public function setOxid($oxid)
    {
        $this->oxid = $oxid;
    }

    /**
     * getOxShopId.
     *
     * @return string ox shop id
     */
    public function getOxShopId()
    {
        return $this->oxShopId;
    }

    /**
     * setOxShopId.
     *
     * @param string $oxShopId ox shop id
     */
    public function setOxShopId($oxShopId)
    {
        $this->oxShopId = $oxShopId;
    }

    /**
     * getOxArtId.
     *
     * @return string ox article id
     */
    public function getOxArtId()
    {
        return $this->oxArtId;
    }

    /**
     * setOxArtId.
     *
     * @param string $oxArtId ox article id
     */
    public function setOxArtId($oxArtId)
    {
        $this->oxArtId = $oxArtId;
    }

    /**
     * getOxAddAbs.
     *
     * @return float ox add abs
     */
    public function getOxAddAbs()
    {
        return $this->oxAddAbs;
    }

    /**
     * setOxAddAbs.
     *
     * @param float $oxAddAbs ox add abs
     */
    public function setOxAddAbs($oxAddAbs)
    {
        $this->oxAddAbs = $oxAddAbs;
    }

    /**
     * getOxAddPerc.
     *
     * @return float ox add perc
     */
    public function getOxAddPerc()
    {
        return $this->oxAddPerc;
    }

    /**
     * setOxAddPerc.
     *
     * @param float $oxAddPerc ox add perc
     */
    public function setOxAddPerc($oxAddPerc)
    {
        $this->oxAddPerc = $oxAddPerc;
    }

    /**
     * getOxAmount.
     *
     * @return float ox amount
     */
    public function getOxAmount()
    {
        return $this->oxAmount;
    }

    /**
     * setOxAmount.
     *
     * @param float $oxAmount ox amount
     */
    public function setOxAmount($oxAmount)
    {
        $this->oxAmount = $oxAmount;
    }

    /**
     * getOxAmountTo.
     *
     * @return float ox amount to
     */
    public function getOxAmountTo()
    {
        return $this->oxAmountTo;
    }

    /**
     * setOxAmountTo.
     *
     * @param float $oxAmountTo ox amount to
     */
    public function setOxAmountTo($oxAmountTo)
    {
        $this->oxAmountTo = $oxAmountTo;
    }

}