<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 23.01.19
 * Time: 16:12
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\model\oxid\BaseModel;
use \OxidEsales\Eshop as Oxid;


class ObjectToDeliveryModel extends BaseModel
{
    /*****************************************************************************
     *
     * Class constants
     *
     *****************************************************************************/
    const	OXTYPE_VALUE_COUNTRIES		= 'oxcountry',
            OXTYPE_VALUE_ARTICLES		= 'oxarticles',
            OXTYPE_VALUE_DELIVERY_SETS	= 'oxdelset',
            OXTYPE_VALUE_CATEGORIES		= 'oxcategories';



    /*****************************************************************************
     *
     * Class properties
     *
     *****************************************************************************/

    /**
     * delivery list model
     * @var DeliveryListModel
     */
    private $deliveryListModel = null;



    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/

    /**
     * Contructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->init('oxobject2delivery');
    }

    /**
     * hasObjectToDeliveries
     *
     * @param string $objectId object id
     * @param string $type type
     * @return boolean is loaded
     */
    public function hasObjectToDeliveries($objectId, $type)
    {
        $query = sprintf('SELECT COUNT(OXID) as amountOfEntries FROM %s WHERE OXOBJECTID = \'%s\' AND OXTYPE = \'%s\'',
            $this->getCoreTableName(),
            $objectId,
            $type
        );

        return (bool) Oxid\Core\DatabaseProvider::getDb()->getOne($query);
    }

    /**
     * saveDefaultCategoriesToDeliveries
     *
     * @param CategoryModel $categoryModel category model
     * @return void
     */
    public function saveDefaultCategoriesToDeliveries(CategoryModel $categoryModel)
    {
        $defaultDeliveryModelsList = $this->getDeliveryListModel()->getDefaultList();
        if(sizeof($defaultDeliveryModelsList) > 0)
        {
            foreach($defaultDeliveryModelsList as $deliveryModel)
            {
                $this->saveDefaultObjectToDeliveries($deliveryModel->getId(), $categoryModel->getId(), self::OXTYPE_VALUE_CATEGORIES);
            }
        }
    }

    /*****************************************************************************
     *
     * helper functions
     *
     *****************************************************************************/

    /**
     * saveDefaultObjectToDeliveries
     *
     * @param string $deliveryId delivery id
     * @param string $objectId object id
     * @param string $objectType object type
     * @return void
     */
    private function saveDefaultObjectToDeliveries($deliveryId, $objectId, $objectType)
    {
        $this->assign(
            array(
                'oxobject2delivery__oxid'			=> Oxid\Core\UtilsObject::getInstance()->generateUID(),
                'oxobject2delivery__oxdeliveryid'	=> $deliveryId,
                'oxobject2delivery__oxobjectid'		=> $objectId,
                'oxobject2delivery__oxtype'			=> $objectType,
            )
        );
        $this->save();
    }

    /**
     * getDeliveryListModel.
     *
     * @return DeliveryListModel $deliveryListModel delivery list model
     */
    private function getDeliveryListModel()
    {
        if(is_null($this->deliveryListModel) === true)
        {
            $this->initDeliveryListModel();
        }
        return $this->deliveryListModel;
    }

    /**
     * initDeliveryListModel
     */
    private function initDeliveryListModel()
    {
        $this->deliveryListModel = oxNew(DeliveryListModel::class);
    }
}