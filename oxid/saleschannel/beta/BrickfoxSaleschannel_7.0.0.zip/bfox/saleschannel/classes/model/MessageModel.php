<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 07.01.19
 * Time: 20:26
 */

namespace bfox\saleschannel\classes\model;

use \OxidEsales\Eshop as Oxid;

class MessageModel extends Oxid\Core\Email
{
    /*****************************************************************************
     *
     * Class properties
     *
     *****************************************************************************/

    /**
     * oConfig
     *
     * Necessary to fix Notice "Undefined property" in oxEmail class
     *
     * @var object
     */
    protected $_oConfig = null;

    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->setMailParams($this->getShop());
        parent::__construct();
    }

}
