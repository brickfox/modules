<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 22.01.19
 * Time: 10:02
 */

namespace bfox\saleschannel\classes\model\oxid;


class ListModel extends \OxidEsales\Eshop\Core\Model\ListModel
{

}