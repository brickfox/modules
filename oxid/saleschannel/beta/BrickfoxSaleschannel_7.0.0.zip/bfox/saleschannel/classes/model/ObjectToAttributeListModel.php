<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 13.02.19
 * Time: 15:45
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\model\oxid as OxidModels;
use \OxidEsales\Eshop as Oxid;

class ObjectToAttributeListModel extends OxidModels\ListModel
{
    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/

    /**
     * loadArticleAttributes.
     *
     * @param string $oxArticleId ox article id
     */
    public function loadArticleAttributes($oxArticleId)
    {
        if('' != $oxArticleId)
        {
            $viewNameGenerator = Oxid\Core\Registry::get(Oxid\Core\TableViewNameGenerator::class);

            $sqlStatement			= sprintf(
                'SELECT * FROM %s WHERE OXOBJECTID = \'%s\';',
                $viewNameGenerator->getViewName('oxobject2attribute'),
                $oxArticleId
            );
            $this->selectString($sqlStatement);
        }
    }
}