<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 06.02.19
 * Time: 15:11
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\model as Models;
use \OxidEsales\Eshop as Oxid;

class MediaURLModel extends \OxidEsales\Eshop\Application\Model\MediaUrl
{

    /**
     * table fields
     * @var string
     */
    const   OXID                = 'OXID',
            OXOBJECTID		    = 'OXOBJECTID',
            OXURL		        = 'OXURL',
            OXDESC              = 'OXDESC',
            OXISUPLOADED        = 'OXISUPLOADED';

    /**
     * ox is uploaded
     */
    const   OXISUPLOADED_ACTIVE   = 1,
            OXISUPLOADED_INACTIVE = 0;



    /**
     * oxid
     * @var string
     */
    private $oxid = null;

    /**
     * ox object id
     * @var string
     */
    private $oxObjectId = null;

    /**
     * ox URL
     * @var string
     */
    private $oxURL = null;

    /**
     *  ox description
     * @var string
     */
    private $oxDesc = null;

    /**
     * ox is uploaded
     */
    private $oxIsUploaded = null;




    /**
     * getMediaURLs
     *
     * @param string $oxObjectId ox object id
     * @return array result
     */
    public static function getMediaURLs($oxObjectId)
    {
        $result		= array();

        if(false === is_null($oxObjectId) && '' != $oxObjectId)
        {
            /** @var Models\MediaURLListModel $mediaURLListModel */
            $mediaURLListModel		= oxNew(Models\MediaURLListModel::class);
            $mediaURLListModel->loadAssignments($oxObjectId);

            /** @var Models\MediaURLModel $mediaURLModel */
            foreach($mediaURLListModel as $mediaURLModel)
            {
                $result[$mediaURLModel->getFieldData('oxid')] = array(
                    self::OXOBJECTID	=> $oxObjectId,
                    self::OXURL	        => $mediaURLModel->getFieldData('oxurl'),
                    self::OXDESC        => $mediaURLModel->getFieldData('oxdesc'),
                );
            }
        }
        return $result;
    }

    /**
     * save.
     */
    public function save()
    {
        if(true === is_null($this->getOxid()))
        {
            $this->setOxid(Oxid\Core\UtilsObject::getInstance()->generateUID());
        }

        $this->assign(
            array(
                'oxmediaurls__oxid'			    => $this->getOxid(),
                'oxmediaurls__oxobjectid'		=> $this->getOxObjectId(),
                'oxmediaurls__oxurl'	        => $this->getOxURL(),
                'oxmediaurls__oxdesc'			=> $this->getOxDesc(),
                'oxmediaurls__oxisuploaded'     => $this->getOxIsUploaded()
            )
        );
        parent::save();
    }

    /**
     * getOxid.
     *
     * @return string oxid
     */
    public function getOxid()
    {
        return $this->oxid;
    }

    /**
     * setOxid.
     *
     * @param string $oxid oxid
     */
    public function setOxid($oxid)
    {
        $this->oxid = $oxid;
    }

    /**
     * getOxObjectId.
     *
     * @return string ox object id
     */
    public function getOxObjectId()
    {
        return $this->oxObjectId;
    }

    /**
     * setOxid.
     *
     * @param string $oxObjectId ox object id
     */
    public function setOxObjectId($oxObjectId)
    {
        $this->oxObjectId = $oxObjectId;
    }

    /**
     * getOxURL.
     *
     * @return string ox url
     */
    public function getOxURL()
    {
        return $this->oxURL;
    }

    /**
     * setOxURL.
     *
     * @param string $oxURL ox url
     */
    public function setOxURL($oxURL)
    {
        $this->oxURL = $oxURL;
    }

    /**
     * getOxDesc.
     *
     * @return string ox sort
     */
    public function getOxDesc()
    {
        return $this->oxDesc;
    }

    /**
     * setOxDesc.
     *
     * @param string $oxDesc ox desc
     */
    public function setOxDesc($oxDesc)
    {
        $this->oxDesc = $oxDesc;
    }

    /**
     * getOxIsUploaded.
     *
     * @return int ox is uploaded
     */
    public function getOxIsUploaded()
    {
        return $this->oxIsUploaded;
    }

    /**
     * setOxIsUploaded.
     *
     * @param int $oxIsUploaded ox is uploaded
     */
    public function setOxIsUploaded($oxIsUploaded)
    {
        $this->oxIsUploaded = $oxIsUploaded;
    }
}