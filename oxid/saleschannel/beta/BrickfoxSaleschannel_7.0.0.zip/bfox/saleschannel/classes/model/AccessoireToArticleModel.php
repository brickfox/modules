<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 20.02.19
 * Time: 12:01
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\model\oxid as OxidModels;
use bfox\saleschannel\classes\util as Utils;
use \OxidEsales\Eshop as Oxid;

class AccessoireToArticleModel extends OxidModels\MultiLanguageModel
{

    /**
     * table fields
     * @var string
     */
    const OXID				= 'OXID',
        OXOBJECTID		    = 'OXOBJECTID',
        OXARTICLENID        = 'OXARTICLENID',
        OXSORT			    = 'OXSORT',

        OXSHOPID			= 'OXSHOPID';


    /**
     * oxid
     * @var string
     */
    private $oxid = null;

    /**
     * ox object id
     * @var string
     */
    private $oxObjectId = null;

    /**
     * ox article id
     * @var string
     */
    private $oxArticleId = null;

    /**
     *  ox sort
     * @var integer
     */
    private $oxSort = null;

    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/

    /**
     * Contructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->init('oxaccessoire2article');
    }

    /**
     * getOxAccessoireToArticleData
     *
     * @param integer $oxArticleId ox article id
     * @return array result
     */
    public static function getOxAccessoireToArticleData($oxArticleId)
    {
        $result		= array();

        if(false === is_null($oxArticleId) && '' != $oxArticleId)
        {
            $accessoireToArticleListModel	= oxNew(AccessoireToArticleListModel::class);
            $accessoireToArticleListModel->loadArticleAssignments($oxArticleId);

            foreach($accessoireToArticleListModel as $accessoireToArticleModel)
            {
                $result[$accessoireToArticleModel->getFieldData('oxobjectid')] = array(
                    self::OXID		=> $accessoireToArticleModel->getFieldData('oxid'),
                    self::OXSORT	=> $accessoireToArticleModel->getFieldData('oxsort'),
                );
            }
        }
        return $result;
    }

    /**
     * getExistingOxArticleIds.
     *
     * @return array existing ox article ids
     */
    public static function getExistingOxArticleIds()
    {
        $oxArticlesIDs = array();
        $viewNameGenerator = Oxid\Core\Registry::get(Oxid\Core\TableViewNameGenerator::class);

        $objectTable = $viewNameGenerator->getViewName('oxaccessoire2article');
        $articlesTable = $viewNameGenerator->getViewName('oxarticles');

        $sqlStatement			= sprintf(
            'SELECT DISTINCT %s FROM %s INNER JOIN %s ON %s = %s WHERE %s = \'%s\' ;',
            $objectTable . '.' . self::OXARTICLENID,
            //FROM + INNER JOIN
            $objectTable,
            $articlesTable,
            $objectTable . '.' . self::OXARTICLENID,
            $articlesTable . '.' . self::OXID,
            //WHERE
            $articlesTable . '.' . self::OXSHOPID,
            Utils\OxidRegistry::getActiveShopId()
        );

        $dB = Oxid\Core\DatabaseProvider::getDb();
        $dB->setFetchMode(Oxid\Core\Database\Adapter\DatabaseInterface::FETCH_MODE_ASSOC);

        $resultSet = $dB->select($sqlStatement);

        if ($resultSet != false && $resultSet->count() > 0) {
            while (!$resultSet->EOF) {
                $row = $resultSet->getFields();
                $oxArticlesIDs[$row[self::OXARTICLENID]] = $row[self::OXARTICLENID];
                $resultSet->fetchRow();
            }
        }

        return $oxArticlesIDs;
    }

    /**
     * deleteByOxArticleId.
     *
     * @param string $oxarticleid ox article id
     */
    public function deleteByOxArticleId($oxarticleid)
    {
        $deleteQuery = sprintf(
            'DELETE FROM %s WHERE %s = \'%s\';',
            $this->getCoreTableName(),
            self::OXARTICLENID,
            $oxarticleid
        );

        Oxid\Core\DatabaseProvider::getDb()->execute($deleteQuery);
    }

    /**
     * getOxObjectIdByBfObjectId.
     *
     * @param integer $bfObjectId bf object id
     * @return string ox object id
     */
    public function getOxObjectIdByBfObjectId($bfObjectId)
    {
        $result			= null;
        $mappingModel	= oxNew(MappingModel::class);
        $mappingModel->loadByBfId($bfObjectId, MappingModel::KEY_TYPE_PRODUCTS);

        if(true === $mappingModel->isLoaded())
        {
            $result = $mappingModel->getSystemId();
        }
        return $result;
    }

    /**
     * save.
     */
    public function save()
    {
        if(true === is_null($this->getOxid()))
        {
            $this->setOxid(Oxid\Core\UtilsObject::getInstance()->generateUID());
        }

        $this->assign(
            array(
                'oxaccessoire2article__oxid'			=> $this->getOxid(),
                'oxaccessoire2article__oxobjectid'		=> $this->getOxObjectId(),
                'oxaccessoire2article__oxarticlenid'	=> $this->getOxArticleId(),
                'oxaccessoire2article__oxsort'			=> $this->getOxSort(),
            )
        );
        parent::save();
    }

    /**
     * getOxid.
     *
     * @return integer oxid
     */
    public function getOxid()
    {
        return $this->oxid;
    }

    /**
     * setOxid.
     *
     * @param integer $oxid oxid
     */
    public function setOxid($oxid)
    {
        $this->oxid = $oxid;
    }

    /**
     * getOxObjectId.
     *
     * @return string ox object id
     */
    public function getOxObjectId()
    {
        return $this->oxObjectId;
    }

    /**
     * setOxid.
     *
     * @param string $oxObjectId ox object id
     */
    public function setOxObjectId($oxObjectId)
    {
        $this->oxObjectId = $oxObjectId;
    }

    /**
     * getOxArticleId.
     *
     * @return string ox article id
     */
    public function getOxArticleId()
    {
        return $this->oxArticleId;
    }

    /**
     * setOxArticleId.
     *
     * @param string $oxArticleId ox article id
     */
    public function setOxArticleId($oxArticleId)
    {
        $this->oxArticleId = $oxArticleId;
    }

    /**
     * getOxSort.
     *
     * @return integer ox sort
     */
    public function getOxSort()
    {
        return $this->oxSort;
    }

    /**
     * setOxSort.
     *
     * @param integer $oxSort ox sort
     */
    public function setOxSort($oxSort)
    {
        $this->oxSort = $oxSort;
    }
}