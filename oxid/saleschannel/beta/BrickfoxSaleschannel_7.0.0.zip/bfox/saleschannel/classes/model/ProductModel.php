<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 31.01.19
 * Time: 14:32
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\exception as Exceptions;
use bfox\saleschannel\classes\controller\transfer\import\attributes as Attributes;
use bfox\saleschannel\classes\util as Utils;
use \OxidEsales\Eshop as Oxid;
use OxidEsales\Eshop\Core\Registry;

class ProductModel extends \OxidEsales\Eshop\Application\Model\Article
{
    /**
     * ###################################################################
     *              CONSTANTS
     * ###################################################################
     */
    /**
     * image connection timeout
     */
    const IMAGE_CONNECTION_TIMEOUT		= 15,
        IMAGE_EXECUTION_TIMEOUT		= 60;

    /**
     * media connection timeout
     */
    const MEDIA_CONNECTION_TIMEOUT		= 15,
        MEDIA_EXECUTION_TIMEOUT		    = 120;

    /**
     * default max scale price to amount
     */
    const MAX_SCALE_PRICE_AMOUNT_TO		= 9999;

    /**
     * image product directory
     */
    const IMAGE_PRODUCT_DIRECTORY		= 'product';

    /**
     * article language data
     */
    const ARTICLE_LANGUAGE_DATA             = 'articleLanguageData',
        ARTICLE_LANGUAGE_EXTENDS_DATA     = 'articleLanguageExtendsData';

    /**
     * attribute value separator
     */
    const ATTRIBUTE_VALUE_SEPARATOR		= ', ';



    /**
     * ###################################################################
     *              PROPERTIES
     * ###################################################################
     */


    /**
     * mapping model
     * @var MappingModel
     */
    private $mappingModel = null;

    /**
     * article attributes data
     * @var array article attributes data
     */
    private $articleAttributesData = [];

    /**
     * article categories data
     * @var array article categories data
     */
    public $articleCategoriesData = [];

    /**
     * article images data
     * @var array article images data
     */
    private $articleImagesData = [];

    /**
     * article media data
     * @var array article media data
     */
    private $articleMediaData = [];

    /**
     * article language data
     * @var array article language data
     */
    private $articleLanguageData = [];


    /**
     * article objects data
     * @var array article objects data
     */
    private $articleObjectsData = [];

    /**
     * article accessoires data
     * @var array article accessoires data
     */
    private $articleAccessoiresData = [];


    /**
     * article scale prices data
     * @var array article scale prices data
     */
    private $articleScalePricesData = [];

    /**
     * article field to shop data
     * @var array article field to shop data
     */
    private $articleFieldToShopData = [];

    /**
     * shop model
     * @var ShopModel
     */
    private $shopModel = null;



    /**
     * ###################################################################
     *              GETTERS AND SETTERS
     * ###################################################################
     */

    /**
     * getBfProductsId.
     *
     * @return integer bf products id
     */
    public function getBfProductsId()
    {
        $result			= null;
        $mappingModel	= oxNew(MappingModel::class);
        $oxParentId		= $this->getFieldData('oxparentid');

        if(false === is_null($oxParentId) && '' != $oxParentId)
        {
            $mappingModel->loadBySystemId($oxParentId, MappingModel::KEY_TYPE_PRODUCTS);
        }
        else
        {
            $mappingModel->loadBySystemId($this->getId(), MappingModel::KEY_TYPE_PRODUCTS);
        }

        if(true === $mappingModel->isLoaded())
        {
            $result = $mappingModel->getBfId();
        }

        return $result;
    }


    /**
     * getArticleDataByKey.
     *
     * @param string $key key
     */
    public function getArticleDataByKey($key)
    {
        return $this->getFieldData($key);
    }

    /**
     * setArticleDataEntry.
     *
     * @param string $key key
     * @param mixed $value value
     */
    public function setArticleDataEntry($key, $value)
    {
        $this->$key = oxNew(
            Oxid\Core\Field::class,
            $value,
            Oxid\Core\Field::T_RAW
        );
    }

    /**
     * getMappingModel.
     *
     * @return MappingModel mapping model
     */
    public function getMappingModel()
    {
        return $this->mappingModel;
    }

    /**
     * setMappingModel.
     *
     * @param MappingModel $mappingModel mapping model
     */
    public function setMappingModel($mappingModel)
    {
        $this->mappingModel = $mappingModel;
    }

    /**
     * getShopModel.
     * @return ShopModel shop model
     */
    public function getShopModel()
    {
        return $this->shopModel;
    }

    /**
     * setShopModel.
     */
    private function setShopModel()
    {
        $oShop = oxNew(ShopModel::class);
        $oShop->load(Utils\OxidRegistry::getActiveShopId());
        $this->shopModel = $oShop;
    }

    /**
     * getCurrentArticleImageCounter.
     *
     * @return integer current article image counter
     */
    public function getCurrentArticleImageCounter()
    {
        $result = 0;
        if(0 < count($this->articleImagesData['images']))
        {
            ksort($this->articleImagesData['images']);
            $result			= str_replace('oxpic', '', array_search(end($this->articleImagesData['images']), $this->articleImagesData['images']));
        }
        return $result;
    }

    /**
     * setArticleImageDeleteFlag.
     *
     * @param boolean $delete article imagedelete flag
     */
    public function setArticleImageDeleteFlag($delete)
    {
        $this->articleImagesData['delete'] = $delete;
    }

    /**
     * getArticleImageDeleteFlag.
     *
     * @return boolean article image delete flag
     */
    public function getArticleImageDeleteFlag()
    {
        return $this->articleImagesData['delete'];
    }

    /**
     * getArticleMediaDeleteFlag.
     *
     * @return boolean article media delete flag
     */
    public function getArticleMediaDeleteFlag()
    {
        return $this->articleMediaData['delete'];
    }

    /**
     * setArticleMediaDeleteFlag.
     *
     * @param boolean $delete article media delete flag
     */
    public function setArticleMediaDeleteFlag($delete)
    {
        $this->articleMediaData['delete'] = $delete;
    }

    /**
     * setParentOxImages.
     *
     * @param array $parentOxImages parent ox images
     */
    public function setParentOxImages($parentOxImages)
    {
        $this->articleImagesData['parentOxImages'] = $parentOxImages;
    }

    /**
     * getParentOxImages.
     *
     * @return array parent ox images
     */
    public function getParentOxImages()
    {
        return $this->articleImagesData['parentOxImages'];
    }

    /**
     * getOxImages.
     *
     * Oxid will automatically store parent article images to variation article images.
     * As result only return variation images and ignore parent article images.
     *
     * @return array images
     */
    public function getOxImages()
    {
        $result		 = [];

        if(true === $this->isLoaded())
        {
            $picGallery			= $this->getPictureGallery();
            $result = $picGallery['Pics'];
        }

        return $result;
    }


    /**
     * getUseMediaUpload.
     *
     * @return bool use media upload
     */
    private function getUseMediaUpload()
    {
        return true;
    }

    /**
     * setArticleLanguageData.
     *
     * @param integer $languageId language id
     * @param string $key key
     * @param mixed $value value
     */
    public function setArticleLanguageData($languageId, $key, $value)
    {
        $this->setArticleLanguageDataEntry($languageId, $key, $value);
    }


    /**
     * setArticleLanguageExtendsData.
     *
     * @param integer $languageId language id
     * @param string $key key
     * @param mixed $value value
     */
    public function setArticleLanguageExtendsData($languageId, $key, $value)
    {
        $this->setArticleLanguageDataEntry($languageId, $key, $value, self::ARTICLE_LANGUAGE_EXTENDS_DATA);
    }

    /**
     * setArticleLanguageDataEntry.
     *
     * @param integer $languageId language id
     * @param string $key key
     * @param mixed $value value
     * @param string $storageKey storage
     */
    private function setArticleLanguageDataEntry($languageId, $key, $value, $storageKey = self::ARTICLE_LANGUAGE_DATA)
    {
        if(false === array_key_exists($languageId, $this->articleLanguageData))
        {
            $this->articleLanguageData[$languageId] = array();
        }

        if(false === array_key_exists($storageKey, $this->articleLanguageData[$languageId]))
        {
            $this->articleLanguageData[$languageId][$storageKey] = array();
        }

        $this->articleLanguageData[$languageId][$storageKey][$key] = $value;
    }

    /**
     * getMaxScalePriceAmount.
     *
     * @param float $amount amount
     * @return float max amount
     */
    private function getMaxScalePriceAmount($amount)
    {
        $maxAmount = 0.0;

        foreach($this->articleScalePricesData as $articleScalePriceData)
        {
            $scalePriceMaxAmount = $articleScalePriceData[PriceToArticleModel::OXAMOUNT];
            if($scalePriceMaxAmount > $amount && (0 == $maxAmount || $maxAmount > $scalePriceMaxAmount))
            {
                $maxAmount = $scalePriceMaxAmount - 1;
            }
        }

        if(0 == $maxAmount)
        {
            $maxAmount = self::MAX_SCALE_PRICE_AMOUNT_TO;
        }

        return $maxAmount;
    }

    /**
     * @return array
     */
    public function getArticleAttributesData()
    {
        return $this->articleAttributesData;
    }


    public function setArticleAttributesData($articleAttributeData)
    {
        $this->articleAttributesData = $articleAttributeData;
    }


    /**
     * ###################################################################
     *            ADD METHODS (COLLECTING DATA IN ARRAYS)
     * ###################################################################
     */


    /**
     * addArticleCategoryData.
     *
     * @param integer $bfCategoryId bf category id
     * @param integer $sortOrder
     */
    public function addArticleCategoryData($bfCategoryId, $sortOrder = 0)
    {
        $this->articleCategoriesData[$bfCategoryId] = $sortOrder;
    }


    /**
     * addArticleImagesData.
     *
     * @param string $imageKey images number (oxpic)
     * @param string $imagePath path to the image
     */
    public function addArticleImageData($imageKey, $imagePath)
    {
        $this->articleImagesData['images']['oxpic' . $imageKey] = $imagePath;
    }

    /**
     * addArticleMediaData.
     *
     * @param string $mediaURL media url
     * @param string $mediaDescription media description
     */
    public function addArticleMediaData($mediaURL, $mediaDescription)
    {
        $this->articleMediaData['media'][$mediaURL] = $mediaDescription;
    }

    /**
     * addArticleScalePriceData.
     *
     * @param float $bfPrice bf object data
     * @param float $bfAmount bf amount
     * @param float $bfPercentage bf percentage
     */
    public function addArticleScalePriceData($bfPrice, $bfAmount, $bfPercentage)
    {
        $this->articleScalePricesData[] = array(
            PriceToArticleModel::OXADDABS			=> $bfPrice,
            PriceToArticleModel::OXADDPERC			=> $bfPercentage,
            PriceToArticleModel::OXAMOUNT			=> $bfAmount
        );
    }

    /**
     * addArticleFieldToShopData.
     *
     * @param string $field field
     * @param float $price price
     */
    public function addArticleFieldToShopData($field, $price)
    {
        $this->articleFieldToShopData[$field] = $price;
    }

    /**
     * addAdditionalNonCopyParentFields.
     *
     * By default, oxid will copy parent article images to variation articles.
     */
    private function addAdditionalNonCopyParentFields()
    {
        $additionalNonParent	= [];
        $pictureCount			=  Registry::getConfig()->getConfigParam('iPicCount');

        for($pictureCounter = 1; $pictureCounter <= $pictureCount; $pictureCounter++)
        {
            $additionalNonParent[] = 'oxarticles__oxpic' . $pictureCounter;
        }
        $this->_aNonCopyParentFields = array_merge($this->_aNonCopyParentFields, $additionalNonParent);
    }


    /**
     * addArticleObjectData.
     *
     * @param string $bfObjectId bf object data
     * @param integer $bfSort bf sort
     */
    public function addArticleObjectData($bfObjectId, $bfSort)
    {
        $this->articleObjectsData[] = array(
            ObjectToArticleModel::OXOBJECTID	=> $bfObjectId,
            ObjectToArticleModel::OXSORT		=> $bfSort
        );
    }

    /**
     * addArticleAccessoireData.
     *
     * @param string $bfObjectId bf object data
     * @param integer $bfSort bf sort
     */
    public function addArticleAccessoireData($bfObjectId, $bfSort)
    {
        $this->articleAccessoiresData[] = array(
            AccessoireToArticleModel::OXOBJECTID	=> $bfObjectId,
            AccessoireToArticleModel::OXSORT		=> $bfSort
        );
    }



    /**
     * ###################################################################
     *              METHODS
     * ###################################################################
     */

    /**
     * __construct.
     *
     * @param array $aParams parameters
     */
    public function __construct( $aParams = null)
    {
        parent::__construct($aParams);

    }

    public function __clone()
    {
        $this->setShopModel();

        $this->initArticleImagesData();
        $this->initArticleMediaData();
        $this->initArticleLanguageData();
        $this->addAdditionalNonCopyParentFields();
    }

    /**
     * initOxArticle.
     *
     * Oxid will throw a lot of notices, when storing the article.
     * As result it's necessary to set default values.
     *
     */
    public function initOxArticle()
    {
        $oxid = Oxid\Core\UtilsObject::getInstance()->generateUID();

        $this->_sOXID = $oxid;
        $this->_iShopId = Utils\OxidRegistry::getActiveShopId();

        $this->setArticleDataEntry('oxarticles__oxissearch', 1);
        $this->setArticleDataEntry('oxarticles__oxparentid', "");
        $this->setArticleDataEntry('oxarticles__oxactive', 0);
        $this->setArticleDataEntry('oxarticles__oxhidden', 0);
        $this->setArticleDataEntry('oxarticles__oxartnum', "");
        $this->setArticleDataEntry('oxarticles__oxean', '');
        $this->setArticleDataEntry('oxarticles__oxdistean', '');
        $this->setArticleDataEntry('oxarticles__oxmpn', '');
        $this->setArticleDataEntry('oxarticles__oxtitle', "");
        $this->setArticleDataEntry('oxarticles__oxshortdesc', "");
        $this->setArticleDataEntry('oxarticles__oxprice', 0);
        $this->setArticleDataEntry('oxarticles__oxblfixedprice', 0);
        $this->setArticleDataEntry('oxarticles__oxpricea', 0);
        $this->setArticleDataEntry('oxarticles__oxpriceb', 0);
        $this->setArticleDataEntry('oxarticles__oxpricec', 0);
        $this->setArticleDataEntry('oxarticles__oxbprice', 0);
        $this->setArticleDataEntry('oxarticles__oxtprice', 0);
        $this->setArticleDataEntry('oxarticles__oxunitname', '');
        $this->setArticleDataEntry('oxarticles__oxunitquantity', '');
        $this->setArticleDataEntry('oxarticles__oxexturl', "");
        $this->setArticleDataEntry('oxarticles__oxurldesc', "");
        $this->setArticleDataEntry('oxarticles__oxurlimg', "");
        $this->setArticleDataEntry('oxarticles__oxvat', "");
        $this->setArticleDataEntry('oxarticles__oxweight', 0);
        $this->setArticleDataEntry('oxarticles__oxstock', 0);
        $this->setArticleDataEntry('oxarticles__oxstockflag', 1);
        $this->setArticleDataEntry('oxarticles__oxinsert', strftime('%Y-%m-%d'));
        $this->setArticleDataEntry('oxarticles__oxtimestamp', strftime('%Y-%m-%d %H:%M:%S'));
        $this->setArticleDataEntry('oxarticles__oxvarcount', 0);
        $this->setArticleDataEntry('oxarticles__oxthumb', '');
        $this->setArticleDataEntry('oxarticles__oxicon', '');
        $this->setArticleDataEntry('oxarticles__oxvarname', '');
        $this->setArticleDataEntry('oxarticles__oxvarselect', '');
        $this->setArticleDataEntry('oxarticles__oxquestionemail', '');
        $this->setArticleDataEntry('oxarticles__oxskipdiscounts', 0);

        for ($i= 1; $i <= 12; $i++){
            $this->setArticleDataEntry('oxarticles__oxpic'.$i , "");
        }

    }

    /**
     * initArticleImagesData.
     */
    private function initArticleImagesData()
    {
        $this->articleImagesData =array(
            'images'			=> array(),
            'parentOxImages'	=> array(),
            'delete'			=> false,
        );
    }


    /**
     * initArticleMediaData.
     */
    private function initArticleMediaData()
    {
        $this->articleMediaData = array(
            'media'     => array(),
            'delete'    => false
        );
    }

    /**
     * initArticleLanguageData.
     */
    private function initArticleLanguageData()
    {
        $defaultLanguageId              = Utils\OxidRegistry::getDefaultLanguageId();
        $this->articleLanguageData      = array(
            $defaultLanguageId  => array()
        );
    }

    /**
     * loadByMappingModel.
     *
     * @param MappingModel $mappingModel mapping model
     */
    public function loadWithMappingModel(MappingModel $mappingModel)
    {
        if(true === $mappingModel->isLoaded())
        {
            $this->setLanguage(Utils\OxidRegistry::getDefaultLanguageId());
            $this->load($mappingModel->getSystemId());

            // article reference is broken
            $mappingModel->setValidSystemId($this->isLoaded());
        }
        $this->setMappingModel($mappingModel);

        // article not found
        if($this->isLoaded() === false)
        {
            $this->initOxArticle();
        }
    }

    /**
     * isShopArticle.
     *
     * @return bool is shop article
     */
    public function isShopArticle()
    {
        #return $this->getShopId() == $this->getShopModel()->getId();
        return $this->_iShopId == $this->getShopModel()->getId();
    }


    /**
     * ###################################################################
     *              IMAGES AND MEDIA METHODS
     * ###################################################################
     */


    /**
     * storeImages.
     */
    private function storeImages()
    {
        $existingImages			= $this->getOxImages();
        $existingImagesCount	= count($existingImages);
        $newImagesCount			= count($this->articleImagesData['images']);

        // workaround to remove dead pictures database entries
        if(0 == $existingImagesCount)
        {
            $this->resetImageDBEntries();
        }

        if(true === $this->articleImagesData['delete'] || $existingImagesCount != $newImagesCount)
        {
            // delete old images
            if(0 < $existingImagesCount)
            {
                $this->deleteImages();
            }

            // create new images
            if(0 < $newImagesCount)
            {
                $this->createImages();
            }
        }
    }

    /**
     * resetImageDBEntries.
     */
    private function resetImageDBEntries()
    {
        $pictureCount = Registry::getConfig()->getConfigParam('iPicCount');

        for($pictureCounter = 1; $pictureCounter <= $pictureCount; $pictureCounter++)
        {
            $pictureKey = 'oxarticles__oxpic' . $pictureCounter;
            $pictureEntry = $this->getFieldData($pictureKey);
            if(true === is_null($pictureEntry) || '' != $pictureEntry)
            {
                $this->setArticleDataEntry($pictureKey, '');
            }
        }
        $this->setArticleDataEntry('oxarticles__oxthumb', '');
        $this->setArticleDataEntry('oxarticles__oxicon', '');
    }

    /**
     * deleteImages.
     */
    private function deleteImages()
    {
        $deleteThumbAndIcon		= true;
        $images					= $this->getOxImages();
        $imagesCount			= count($images);

        if(0 < $imagesCount)
        {
            $parentPictures		= $this->getParentOxImages();
            $pictureHandler		= Oxid\Core\Registry::get('oxPictureHandler');

            foreach($images as $imageKey => $imageUrl)
            {
                if(false === array_key_exists($imageKey, $parentPictures) || (true === array_key_exists($imageKey, $parentPictures) && $parentPictures[$imageKey] != $imageUrl))
                {
                    // delete picture assignments
                    if(true === $deleteThumbAndIcon)
                    {
                        // deleting icon picture
                        $pictureHandler->deleteMainIcon($this);
                        $this->setArticleDataEntry('oxarticles__oxicon', '');

                        // deleting thumbnail picture
                        $pictureHandler->deleteThumbnail($this);
                        $this->setArticleDataEntry('oxarticles__oxthumb', '');
                    }

                    // deleting master picture
                    $pictureHandler->deleteArticleMasterPicture($this, $imageKey);

                    // deleting zoom picture
                    $oxZoomKey	= 'oxarticles__oxzoom' . $imageKey;
                    $oxZoom		= $this->$oxZoomKey;
                    if(true === is_null($oxZoom))
                    {
                        $this->setArticleDataEntry($oxZoomKey, null);
                    }
                }
                $this->setArticleDataEntry('oxarticles__oxpic' . $imageKey, '');
                $deleteThumbAndIcon = false;
            }
        }
    }

    /**
     * createImages.
     */
    private function createImages()
    {
        $oxUtilsFile		= Oxid\Core\Registry::get('oxUtilsFile');
        $createThumbAndIcon	= true;
        $aFiles			= array(
            'myfile'	=> array(
                'name'		=> null,
                'tmp_name'	=> null,
                'error'		=> null,
            ),
        );

        ksort($this->articleImagesData['images']);

        foreach($this->articleImagesData['images'] as $imageKey => $imagePath)
        {
            $imageCounter	= str_replace('oxpic', '', $imageKey);
            $imageFile		= $this->getImage($imagePath, $imageCounter);

            if(file_exists($imageFile))
            {
                $imageName	= basename($imageFile);

                // main product picture
                $this->setArticleDataEntry('oxarticles__' . $imageKey, $imageName);

                if(true === $createThumbAndIcon)
                {
                    // generate thumbnail
                    $thumbnailName					= Oxid\Core\Str::getStr()->preg_replace('/(\.jpg|\.jpeg|\.gif|\.png)$/i', '_th\\1', $imageName);
                    $sType							= 'TH@oxarticles__oxthumb';
                    $aFiles['myfile']['name']		= array($sType => $thumbnailName);
                    $aFiles['myfile']['tmp_name']	= array($sType => $imageFile);
                    $oxUtilsFile->processFiles($this, $aFiles, true, false);

                    // generate icon
                    $iconName						= Oxid\Core\Str::getStr()->preg_replace('/(\.jpg|\.jpeg|\.gif|\.png)$/i', '_ico\\1', $imageName);
                    $sType							= 'ICO@oxarticles__oxicon';
                    $aFiles['myfile']['name']		= array($sType => $iconName);
                    $aFiles['myfile']['tmp_name']	= array($sType => $imageFile);
                    $oxUtilsFile->processFiles($this, $aFiles, true, false);
                    $createThumbAndIcon = false;
                }
            }
        }
    }

    /**
     * getImage.
     *
     * @param string $remoteImageURL remote image url
     * @param integer $imageCounter image counter
     * @return string image file
     */
    private function getImage($remoteImageURL, $imageCounter)
    {
        $imageFile			= $this->getTargetImageLocationPath($remoteImageURL, $imageCounter);
        $downloadFile = $this->downloadMedia($remoteImageURL, $imageFile);

        if($downloadFile === '')
        {
            Utils\LogManager::getInstance()->error('Error while fetching image: ' . $remoteImageURL . '!');
            return null;
        }

        return $downloadFile;
    }

    /**
     * getTargetImageLocationPath.
     *
     * @param string $remoteImageURL remote image url
     * @param integer $imageCounter image counter
     * @return string temp file path location
     */
    private function getTargetImageLocationPath($remoteImageURL, $imageCounter)
    {
        // oxid changes thumbnail and icon image names automatically to lower case. For that reason lower case main image name
        $imageName	= strtolower(pathinfo($remoteImageURL, PATHINFO_BASENAME));

        // oxid will generate cropped images based on the master picture. The generation of cropped images will not work with special characters
        $imageName  = Oxid\Core\Str::getStr()->preg_replace( '/[^a-zA-Z0-9()_\.-]/', '', $imageName);

        // set oxid and _ before real file name to guarantee uniqueness of filename
        $oxid		= $this->getArticleDataByKey('oxarticles__oxid');
        if(false === strpos($imageName, $oxid))
        {
            $imageName = $oxid . '_' . $imageName;
        }

        return \OxidEsales\Eshop\Core\Registry::getConfig()->getMasterPictureDir() . self::IMAGE_PRODUCT_DIRECTORY . DIRECTORY_SEPARATOR . $imageCounter . DIRECTORY_SEPARATOR . $imageName;
    }

    /**
     * storeMedia.
     */
    private function storeMedia()
    {
        if(true === $this->isShopArticle())
        {
            $mediaURLsData	    = MediaURLModel::getMediaURLs($this->getId());

            $existingMediaCount = count($mediaURLsData);
            $newMediaCount      = count($this->articleMediaData['media']);

            if(true === $this->getArticleMediaDeleteFlag() || $existingMediaCount != $newMediaCount)
            {
                if(0 < $existingMediaCount)
                {
                    $this->deleteMedia();
                }

                if(0 < $newMediaCount)
                {
                    $this->createMedia();
                }
            }
        }
    }

    /**
     * deleteMedia.
     */
    private function deleteMedia()
    {
        $mediaURLsData	= MediaURLModel::getMediaURLs($this->getId());

        // delete old media urls assignments
        foreach(array_keys($mediaURLsData) as $oxid)
        {
            $mediaURLModel	= oxNew(MediaURLModel::class);
            $mediaURLModel->load($oxid);
            $mediaURLModel->delete();
        }
    }


    /**
     * createMedia.
     */
    private function createMedia()
    {
        $useMediaUpload = $this->getUseMediaUpload();
        $languagesData = Utils\OxidRegistry::getOxidLanguageArray();

        foreach($this->articleMediaData['media'] as $mediaURL => $mediaDescription)
        {
            /** @var MediaURLModel $mediaURLModel */
            $mediaURLModel	= oxNew(MediaURLModel::class);
            $mediaURLModel->setOxObjectId($this->getId());

            $validAssignment = true;
            if(true === $useMediaUpload)
            {
                $mediaURLModel->setOxIsUploaded(MediaURLModel::OXISUPLOADED_ACTIVE);

                $mediaFile		= $this->getMedia($mediaURL);

                if(false === is_null($mediaFile) && true === file_exists($mediaFile))
                {
                    $mediaURLModel->setOxURL(basename($mediaFile));
                }
                else
                {
                    $validAssignment = false;
                }
            }
            else
            {
                $mediaURLModel->setOxIsUploaded(MediaURLModel::OXISUPLOADED_INACTIVE);
                $mediaURLModel->setOxURL($mediaURL);
            }

            if(true === $validAssignment)
            {
                // brickfox has only one description - so save description in default language column
                $mediaURLModel->setLanguage(Utils\OxidRegistry::getDefaultLanguageId());

                $mediaURLModel->setOxDesc($mediaDescription);
                $mediaURLModel->save();

                foreach($languagesData as $languageData)
                {
                    if($languageData->id != $this->getLanguage())
                    {
                        $mediaURLModel->loadInLang($languageData->id, $mediaURLModel->getOxid());
                        $mediaURLModel->setLanguage($languageData->id);

                        $mediaURLModel->setOxDesc($mediaDescription);
                        $mediaURLModel->save();
                    }
                }
            }

        }
    }

    /**
     * getMedia.
     *
     * @param string $remoteMediaURL remote media url
     * @return string media file
     */
    private function getMedia($remoteMediaURL)
    {
        $mediaFile	    =  $this->getTargetMediaLocationPath($remoteMediaURL);
        $downloadFile = $this->downloadMedia($remoteMediaURL, $mediaFile);

        // image is available http status code = 200 (ok) or 304 (not modified)
        if($downloadFile === '')
        {
            Utils\LogManager::getInstance()->error('Error while fetching media: ' . $remoteMediaURL . '!');
            return null;
        }

        return $downloadFile;
    }

    private function downloadMedia(string $remoteUrl, string $localFilename): string
    {
        $success = true;
        $remoteUrl = $this->customUrlEncode($remoteUrl);
        $fp = fopen($localFilename, 'w+');

        $ch				= curl_init($remoteUrl);

        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_HEADER, 0);

        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects if any
        curl_setopt($ch, CURLOPT_FAILONERROR, true);    // Stop on HTTP errors

        if(!curl_exec($ch)){
            $success = false;
        }

        fclose($fp);

        $httpcode		= curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);

        // image is available http status code = 200 (ok) or 304 (not modified)
        if(!(200 == $httpcode || 304 == $httpcode) || !is_file($localFilename))
        {
            $success = false;
        }

        if (!$success) {
            if (is_file($localFilename)) {
                unlink($localFilename);
            }
            return '';
        }

        return $localFilename;
    }

    private function customUrlEncode($url): string
    {
       $arrUrl = explode('/', $url);

       $filename = end($arrUrl);
       $encodedFilename =  rawurlencode($filename);

       $url = str_replace($filename, $encodedFilename, $url);

        return $url;
    }

    /**
     * getTargetMediaLocationPath.
     *
     * @param string $remoteMediaURL remote media url
     * @return string temp file path location
     */
    private function getTargetMediaLocationPath($remoteMediaURL)
    {
        $mediaName = md5($this->getArticleDataByKey('oxid') . '_' . $remoteMediaURL) . '.' . pathinfo($remoteMediaURL, PATHINFO_EXTENSION);

        return \OxidEsales\Eshop\Core\Registry::getConfig()->getConfigParam('sShopDir') . 'out/media/' . $mediaName;
    }



    /**
     * ###################################################################
     *              SAVE OBJECTS AND DEPENDENCIES
     * ###################################################################
     */

    /**
     * saveAll.
     */
    public function saveAll()
    {
        // store images
        $this->storeImages();

        // store products media
        $this->storeMedia();

        // store ox article data
        $this->save();

        // store attributes data
        $this->storeAttributes();

        // store category assignments
        $this->storeCategoryAssignments();
    }

    /**
     * save.
     *
     * Pay attention:
     * After storing article data container (non language sensible data) will be resetted.
     * The article language data container (language sensible data) will be unchanged => necessary for restoring.
     */
    public function save()
    {
        $this->parentSave();

        // store mapping entry for new articles
        if(false === $this->getMappingModel()->isLoaded() || false === $this->getMappingModel()->hasValidSystemId())
        {
            $this->getMappingModel()->setSystemId(
                $this->oxarticles__oxid->value
            );
            $this->getMappingModel()->save();
            $this->_isLoaded = true;
        }

        $this->saveLanguageData();

        // store scale prices
        $this->storeScalePrices();
        $this->storeChildShopPrices();
    }

    /**
     * parentSave - direct Call to save method from OxidEsales\Eshop\Application\Model\Article
     */
    public function parentSave()
    {
        parent::save();
    }


    protected function saveLanguageData()
    {
        // store ox article data
        foreach($this->articleLanguageData as $languageId => $articleLanguageDataStorage)
        {
            if($languageId != $this->getLanguage())
            {
                $this->loadInLang($languageId, $this->getFieldData('oxid'));
                $this->setLanguage($languageId);
            }

            // article language data
            if(true === array_key_exists(self::ARTICLE_LANGUAGE_DATA, $articleLanguageDataStorage))
            {
                $this->assign($articleLanguageDataStorage[self::ARTICLE_LANGUAGE_DATA]);
            }

            // article language extends data
            if(true === array_key_exists(self::ARTICLE_LANGUAGE_EXTENDS_DATA, $articleLanguageDataStorage))
            {
                $this->assignArticleExtends($articleLanguageDataStorage[self::ARTICLE_LANGUAGE_EXTENDS_DATA]);
            }

            $this->parentSave();
        }
    }


    /**
     * saveAssignments.
     */
    public function saveAssignments()
    {
        // crossellings
        $this->storeObjectAssignments();

        // accessoires
        $this->storeAccessoireAssignments();
    }


    /**
     * storeObjectAssignments.
     */
    private function storeObjectAssignments()
    {
        if(true === $this->isShopArticle())
        {
            // get all existing object to article assignments
            $objectToArticlesData = ObjectToArticleModel::getOxObjectToArticleData($this->getId());

            foreach ($this->articleObjectsData as $articleObjectData) {
                /** @var ObjectToArticleModel $objectToArticleModel */
                $objectToArticleModel = oxNew(ObjectToArticleModel::class);
                $bfObjectId = $articleObjectData[ObjectToArticleModel::OXOBJECTID];
                $oxObjectId = $objectToArticleModel->getOxObjectIdByBfObjectId($bfObjectId);

                // mapping for bf object id found
                if (false === is_null($oxObjectId)) {
                    // object to article assignment already exists
                    if (true === array_key_exists($oxObjectId, $objectToArticlesData)) {
                        $objectToArticleModel->setOxid($objectToArticlesData[$oxObjectId][ObjectToArticleModel::OXID]);
                        unset($objectToArticlesData[$oxObjectId]);
                    }

                    // create or update object to article assignment
                    $objectToArticleModel->setOxArticleId($this->getId());
                    $objectToArticleModel->setOxObjectId($oxObjectId);
                    $objectToArticleModel->setOxSort($articleObjectData[ObjectToArticleModel::OXSORT]);
                    $objectToArticleModel->save();
                }
                else
                {
                    Utils\LogManager::getInstance()->error('Missing object id mapping! Object id: ' . $bfObjectId);
                }
            }

            // delete old object to article assignments
            foreach ($objectToArticlesData as $objectToArticleData)
            {
                $objectToArticleModel = oxNew(ObjectToArticleModel::class);
                $objectToArticleModel->delete($objectToArticleData[ObjectToArticleModel::OXID]);
            }
        }
    }

    /**
     * storeAccessoireAssignments.
     */
    private function storeAccessoireAssignments()
    {
        if(true === $this->isShopArticle())
        {
            // get all existing accessoire to article assignments
            $accessoireToArticlesData = AccessoireToArticleModel::getOxAccessoireToArticleData($this->getId());

            foreach ($this->articleAccessoiresData as $articleAccessoireData)
            {
                /** @var AccessoireToArticleModel $accessoireToArticleModel */
                $accessoireToArticleModel = oxNew(AccessoireToArticleModel::class);
                $bfObjectId = $articleAccessoireData[AccessoireToArticleModel::OXOBJECTID];
                $oxObjectId = $accessoireToArticleModel->getOxObjectIdByBfObjectId($bfObjectId);

                // mapping for bf accessoire id found
                if (false === is_null($oxObjectId))
                {
                    // accessoire to article assignment already exists
                    if (true === array_key_exists($oxObjectId, $accessoireToArticlesData))
                    {
                        $accessoireToArticleModel->setOxid($accessoireToArticlesData[$oxObjectId][AccessoireToArticleModel::OXID]);
                        unset($accessoireToArticlesData[$oxObjectId]);
                    }

                    // create or update accessoire to article assignment
                    $accessoireToArticleModel->setOxArticleId($this->getId());
                    $accessoireToArticleModel->setOxObjectId($oxObjectId);
                    $accessoireToArticleModel->setOxSort($articleAccessoireData[AccessoireToArticleModel::OXSORT]);
                    $accessoireToArticleModel->save();
                }
                else
                {
                    Utils\LogManager::getInstance()->error('Missing object id mapping! Object id: ' . $bfObjectId);
                }
            }

            // delete old accessoire to article assignments
            foreach ($accessoireToArticlesData as $accessoireToArticleData)
            {
                $accessoireToArticleModel = oxNew(AccessoireToArticleModel::class);
                $accessoireToArticleModel->delete($accessoireToArticleData[AccessoireToArticleModel::OXID]);
            }
        }
    }


    /**
     * assignArticleExtends.
     *
     * @param array $articleExtendsData article extends data
     */
    private function assignArticleExtends($articleExtendsData)
    {
        if(true === array_key_exists('oxarticles__oxlongdesc', $articleExtendsData))
        {
            $this->setArticleLongDesc($articleExtendsData['oxarticles__oxlongdesc']);
        }
    }


    /**
     * storeAttributes.
     */
    private function storeAttributes()
    {
        if(true === $this->isShopArticle())
        {
            /** @var Attributes\ImportAttributes $importArticleAttributes */
            $importArticleAttributes = oxNew(Attributes\ImportAttributes::class, "");

            $oxArticlePropertySet = $importArticleAttributes->store($this);

            if ($oxArticlePropertySet === true) {
                $this->save();
            }
        }
        else
        {
            Utils\LogManager::getInstance()->debug("The check for Shop conditions failed when saving Attributes, Oxid:" . $this->getId());
        }
    }


    /**
     * storeCategoryAssignments.
     */
    private function storeCategoryAssignments()
    {
        // get all oxid categories
        /** @var ObjectToCategoryModel $objectToCategoryModel */
        $objectToCategoryModel		= oxNew(ObjectToCategoryModel::class);
        $objectToCategoriesData	= $objectToCategoryModel->getObjectToCategoriesData($this->getId());

        foreach($this->articleCategoriesData as $bfCategoryId => $sortOrder)
        {
            $objectToCategoryModel	= oxNew(ObjectToCategoryModel::class, $this->getShopModel()->getId());
            $aCategoryMapping		= $objectToCategoryModel->getOxCategoryMappingDataByBfCategoryId($bfCategoryId);

            //mapping for bf category id found
            if(empty($aCategoryMapping) === false)
            {
                $oxCategoryId   = $aCategoryMapping['oxsystemid'];

                // ox article to ox category assignment already exists
                if(true === array_key_exists($oxCategoryId, $objectToCategoriesData))
                {
                    $objectToCategoryModel->setOxid($objectToCategoriesData[$oxCategoryId][ObjectToCategoryModel::OXID]);
                    unset($objectToCategoriesData[$oxCategoryId]);
                }
                else
                {
                    $objectToCategoryModel->setOxTime(time());
                }

                // create new ox article to ox category assignment
                $objectToCategoryModel->setOxArticleId($this->getId());
                $objectToCategoryModel->setOxCategoryId($oxCategoryId);
                $objectToCategoryModel->setOxPosition($sortOrder);
                $objectToCategoryModel->save();

            }
            else
            {
                Utils\LogManager::getInstance()->error('Missing category id mapping! Category id: ' . $bfCategoryId);
            }
        }

        // delete old ox object to ox category assignments
        foreach($objectToCategoriesData as $objectToCategoryData)
        {
            $objectToCategoryModel->delete($objectToCategoryData[ObjectToCategoryModel::OXID]);
        }
    }


    /**
     * storeScalePrices.
     */
    private function storeScalePrices()
    {
        // get all existing scale prices
        $priceToArticlesData	= PriceToArticleModel::getOxPriceToArticleData($this->getId());
        $defaultShopId			= oxNew(Oxid\Application\Model\Shop::class)->getShopId();

        foreach($this->articleScalePricesData as $articleScalePriceData)
        {
            $amountTo	= $this->getMaxScalePriceAmount($articleScalePriceData[PriceToArticleModel::OXAMOUNT]);
            $key		= $articleScalePriceData[PriceToArticleModel::OXAMOUNT] . '_' . $amountTo;

            $priceToArticleModel	= oxNew(PriceToArticleModel::class);

            // price to article assignment already exists
            if(true === array_key_exists($key, $priceToArticlesData))
            {
                $priceToArticleModel->setOxid($priceToArticlesData[$key][PriceToArticleModel::OXID]);
                unset($priceToArticlesData[$key]);
            }

            $priceToArticleModel->setOxShopId($defaultShopId);
            $priceToArticleModel->setOxArtId($this->getId());

            if(0 < $articleScalePriceData[PriceToArticleModel::OXADDPERC])
            {
                $priceToArticleModel->setOxAddPerc(100 - $articleScalePriceData[PriceToArticleModel::OXADDPERC]);
            }
            else
            {
                $priceToArticleModel->setOxAddAbs($articleScalePriceData[PriceToArticleModel::OXADDABS]);
            }

            $priceToArticleModel->setOxAmount($articleScalePriceData[PriceToArticleModel::OXAMOUNT]);
            $priceToArticleModel->setOxAmountTo($amountTo);
            $priceToArticleModel->save();
        }

        // delete old price to article assignments
        foreach($priceToArticlesData as $priceToArticleData)
        {
            $priceToArticleModel	= oxNew(PriceToArticleModel::class);
            $priceToArticleModel->delete($priceToArticleData[PriceToArticleModel::OXID]);
        }
    }

    /**
     * storeChildShopPrices.
     */
    private function storeChildShopPrices()
    {
        if(false === $this->isShopArticle())
        {
            /** @var FieldToShopModel $fieldToShopModel */
            $fieldToShopModel	= oxNew(FieldToShopModel::class);
            $fieldToShopModel->setOxArtId($this->getId());
            $fieldToShopModel->setOxShopId($this->getShopModel()->getId());

            $fieldToShopModel->loadByArtIdAndShopId();


            if(0 < count($this->articleFieldToShopData))
            {
                foreach($this->articleFieldToShopData as $field => $price)
                {
                    $fieldToShopModel->setPrice($field, $price);
                }
            }

            if(true === $fieldToShopModel->hasValidPrices())
            {
                $fieldToShopModel->save();
            }
            else
            {
                $fieldToShopModel->delete();
            }
        }
    }
}
