<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 11.01.19
 * Time: 18:29
 */

namespace bfox\saleschannel\classes\model;


use bfox\saleschannel\classes\util as Utils;

class ShopModel extends \OxidEsales\Eshop\Application\Model\Shop
{
    /*****************************************************************************
     *
     * Class properties
     *
     *****************************************************************************/

    /**
     * sub shop list model
     *
     * @var ShopListModel
     */
    private $subShopListModel = null;

    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/


    public function getShopIdByBfShopId($bfShopId)
    {
        $bfShopIdToShopIdMapping    = $this->getBfShopIdToShopIdMapping();

        if(true === array_key_exists($bfShopId, $bfShopIdToShopIdMapping))
        {
            return $bfShopIdToShopIdMapping[$bfShopId];
        }
    }


    /**
     * isSuperShop.
     *
     * @return bool is super shop
     */
    public function isSuperShop()
    {
        return (bool) $this->getFieldData('oxissupershop');
    }

    /**
     * getParentShopId.
     *
     * @return int ox parent shop id
     */
    public function getParentShopId()
    {
        return $this->getFieldData('oxparentid');
    }

    /*****************************************************************************
     *
     * helper functions
     *
     *****************************************************************************/

    /**
     * getShopShopListModel.
     * @return ShopListModel
     */
    private function getShopShopListModel()
    {
        if(true === is_null($this->subShopListModel))
        {
            $shopListModel = oxNew('ShopListModel');
            $shopListModel->loadSubShops($this->getId());
            $this->setShopShopListModel($shopListModel);
        }
        return $this->subShopListModel;
    }

    /**
     * setShopShopListModel.
     * @param ShopListModel $subShopListModel subshop list model
     */
    private function setShopShopListModel(ShopListModel $subShopListModel)
    {
        $this->subShopListModel = $subShopListModel;
    }

    private function getBfShopIdToShopIdMapping()
    {
        return Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_BF_SHOP_ID_TO_SHOP_ID_MAPPING);
    }


}
