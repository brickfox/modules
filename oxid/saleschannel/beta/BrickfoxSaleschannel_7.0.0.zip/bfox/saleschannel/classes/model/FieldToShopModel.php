<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 14.02.19
 * Time: 15:57
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\util as Utils;
use bfox\saleschannel\classes\model\oxid\BaseModel;
use \OxidEsales\Eshop as Oxid;

class FieldToShopModel extends BaseModel
{
    /**
     * table fields
     * @var string
     */
    const OXARTID			= 'OXARTID',
        OXSHOPID			= 'OXSHOPID';




    /**
     * valid price fields
     */
    private $validPriceFields = null;




    /**
     * Constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->init('oxfield2shop');
    }

    /**
     * loadByArtIdAndShopId.
     *
     * @return bool is loaded
     */
    public function loadByArtIdAndShopId()
    {
        $selectStatement = $this->buildSelectString(
            array(
                $this->getViewName() . '.' . self::OXARTID     => $this->getOxArtId(),
                $this->getViewName() . '.' . self::OXSHOPID    => $this->getOxShopId()
            )
        );
        return $this->_isLoaded = $this->assignRecord($selectStatement);
    }

    /**
     * setPrice.
     *
     * @param string $field field
     * @param float $price price
     */
    public function setPrice($field, $price)
    {
        $fieldSplit = explode('__', $field);
        $fieldName = $fieldSplit[count($fieldSplit) - 1];

        $validPriceFields = $this->getValidPriceFields();

        if(true === in_array(strtoupper($fieldName), $validPriceFields))
        {
            $propertyName = "oxfield2shop__{$fieldName}";

            $this->$propertyName = new Oxid\Core\Field($price);
        }
    }

    /**
     * hasPrices.
     *
     * @return bool has prices
     */
    public function hasValidPrices()
    {
        $hasValidPrices     = false;
        $validPriceFields   = $this->getValidPriceFields();

        foreach($validPriceFields as $field)
        {
            $price = $this->getFieldData($field);
            if(false === is_null($price) && 0 < $price)
            {
                $hasValidPrices = true;
                break;
            }
        }
        return $hasValidPrices;
    }

    /**
     * getOxShopId.
     *
     * @return string ox shop id
     */
    public function getOxShopId()
    {
        return $this->oxfield2shop__oxshopid;
    }

    /**
     * setOxShopId.
     *
     * @param string $oxShopId ox shop id
     */
    public function setOxShopId($oxShopId)
    {
        $this->_iShopId = $oxShopId;
        $this->oxfield2shop__oxshopid = $oxShopId;
    }

    /**
     * getOxArtId.
     *
     * @return string ox article id
     */
    public function getOxArtId()
    {
        return $this->oxfield2shop__oxartid;
    }

    /**
     * setOxArtId.
     *
     * @param string $oxArtId ox article id
     */
    public function setOxArtId($oxArtId)
    {
        $this->oxfield2shop__oxartid = $oxArtId;
    }

    /**
     * getValidPriceFields,
     *
     * @return array valid price fields
     */
    private function getValidPriceFields()
    {
        if(true === is_null($this->validPriceFields))
        {
            $this->setValidPriceFields(Utils\OxidRegistry::getMultishopArticleFields());
        }
        return $this->validPriceFields;
    }

    /**
     * setValidPriceFields.
     *
     * @param array $validPriceFields valid price fields
     */
    private function setValidPriceFields($validPriceFields)
    {
        $this->validPriceFields = $validPriceFields;
    }
}