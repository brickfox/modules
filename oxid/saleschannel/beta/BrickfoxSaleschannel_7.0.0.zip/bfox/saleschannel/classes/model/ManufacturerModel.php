<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 22.01.19
 * Time: 11:12
 */

namespace bfox\saleschannel\classes\model;
use bfox\saleschannel\classes\controller\transfer as Transfers;
use bfox\saleschannel\classes\util as Utils;
use \OxidEsales\Eshop as Oxid;


  class ManufacturerModel extends \OxidEsales\Eshop\Application\Model\Manufacturer
  {
      /*****************************************************************************
       *
       * Class properties
       *
       *****************************************************************************/

      /**
       * manufacturer language data
       * @var array manufacturer language data
       */
      private $manufacturerLanguageData = array();

      /*****************************************************************************
       *
       * Callable functions
       *
       *****************************************************************************/

      /**
       * __construct.
       */
      public function __construct()
      {
          parent::__construct();
      }

      /**
       * setManufacturerDataEntry.
       *
       * @param string $key key
       * @param mixed $value value
       */
      public function setManufacturerDataEntry($key, $value)
      {
          $this->$key = oxNew(
              Oxid\Core\Field::class,
              $value,
              Oxid\Core\Field::T_RAW
          );
      }

      /**
       * getManufacturerDataByKey.
       *
       * @param string $key key
       */
      public function getManufacturerDataByKey($key)
      {
          return $this->getFieldData($key);
      }

      /**
       * setManufacturerLanguageData.
       *
       * @param integer $languageId language id
       * @param string $key key
       * @param mixed $value value
       */
      public function setManufacturerLanguageData($languageId, $key, $value)
      {
          if(false === array_key_exists($languageId, $this->manufacturerLanguageData))
          {
              $this->manufacturerLanguageData[$languageId] = array();
          }

          $this->manufacturerLanguageData[$languageId][$key] = $value;
      }

      /**
       * save.
       */
      public function save()
      {
          foreach($this->manufacturerLanguageData as $languageId => $manufacturerLanguageData)
          {
              if($languageId != $this->getLanguage())
              {
                  $this->loadInLang($languageId, $this->getFieldData('oxid'));
                  $this->setLanguage($languageId);
              }

              $this->assign($manufacturerLanguageData);
              parent::save();
          }
      }

      /**
       * getBfManufacturersList.
       *
       * @return array manufacturer list
       */
      public function getBfManufacturersList()
      {
          $returnValue = array();
          $Language = oxNew(Oxid\Core\Language::class);

          $viewNameGenerator = Oxid\Core\Registry::get(Oxid\Core\TableViewNameGenerator::class, null, $Language);
          $shopId = Utils\OxidRegistry::getActiveShopId();

          $query = 'SELECT OXID as oxid, OXTITLE as oxtitle FROM '.$viewNameGenerator->getViewName('oxmanufacturers')
              . ' WHERE oxtitle <> "" AND OXSHOPID = '.$shopId;

          $dB = Oxid\Core\DatabaseProvider::getDb();
          $dB->setFetchMode(Oxid\Core\Database\Adapter\DatabaseInterface::FETCH_MODE_ASSOC);

          $resultSet = $dB->select($query);

          if ($resultSet != false && $resultSet->count() > 0)
          {
              while (!$resultSet->EOF)
              {
                  $row = $resultSet->getFields();
                  if($row['oxid'] != '' && $row['oxtitle'] != '')
                  {
                      $returnValue[$row['oxid']] = $row['oxtitle'];
                  }
                  $resultSet->fetchRow();
              }
          }
          return $returnValue;
      }

      /**
       */
      public function initOxManufacturer()
      {
          $oxid = Oxid\Core\UtilsObject::getInstance()->generateUID();
          $oxshopid = Utils\OxidRegistry::getActiveShopId();

          $this->_sOXID = $oxid;
          $this->_iShopId = $oxshopid;

          $this->setManufacturerDataEntry('oxmanufacturers__oxid', $oxid);
          $this->setManufacturerDataEntry('oxmanufacturers__oxactive', Transfers\AbstractTransfer::STATUS_ACTIVE_ID);
          $this->setManufacturerDataEntry('oxmanufacturers__oxshopid', $oxshopid);
          $this->setManufacturerDataEntry('oxmanufacturers__oxicon', '');
          $this->setManufacturerDataEntry('oxmanufacturers__oxshortdesc', '');
      }
  }