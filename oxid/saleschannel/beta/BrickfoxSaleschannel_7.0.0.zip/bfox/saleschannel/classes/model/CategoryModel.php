<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 23.01.19
 * Time: 15:03
 */

namespace bfox\saleschannel\classes\model;


use bfox\saleschannel\classes\controller\transfer as Transfers;
use bfox\saleschannel\classes\util as Utils;
use \OxidEsales\Eshop as Oxid;


class CategoryModel extends \OxidEsales\Eshop\Application\Model\Category
{
    /*****************************************************************************
     *
     * Class constants
     *
     *****************************************************************************/

    /**
     * hidden or visible
     * @var integer
     */
    const	STATUS_HIDDEN	= 1,
            STATUS_VISIBLE	= 0;

    /*****************************************************************************
     *
     * Class properties
     *
     *****************************************************************************/

    /**
     * category language data
     * @var array category language data
     */
    private $categoryLanguageData = array();

    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/

    /**
     * __construct.
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * setCategoryDataEntry.
     *
     * @param string $key key
     * @param mixed $value value
     */
    public function setCategoryDataEntry($key, $value)
    {
        $this->$key = oxNew(
            Oxid\Core\Field::class,
            $value,
            Oxid\Core\Field::T_RAW
        );
    }

    /**
     * getCategoryDataByKey.
     *
     * @param string $key key
     */
    public function getCategoryDataByKey($key)
    {
        return $this->getFieldData($key);
    }

    /**
     * setCategoryLanguageData.
     *
     * @param integer $languageId language id
     * @param string $key key
     * @param mixed $value value
     */
    public function setCategoryLanguageData($languageId, $key, $value)
    {
        if(false === array_key_exists($languageId, $this->categoryLanguageData))
        {
            $this->categoryLanguageData[$languageId] = array();
        }

        $this->categoryLanguageData[$languageId][$key] = $value;
    }

    /**
     * saveCategory.
     */
    public function saveCategory()
    {
        foreach($this->categoryLanguageData as $languageId => $categoryLanguageData)
        {
            if($languageId != $this->getLanguage())
            {
                parent::save();

                $this->loadInLang($languageId, $this->getFieldData('oxid'));
                $this->setLanguage($languageId);
            }

            $this->assign($categoryLanguageData);
            parent::save();
        }
    }

    /**
     * load.
     *
     * @param string $oxid oxid
     * @return bool is loaded
     */
    public function load($oxid)
    {
        $this->_isLoaded = parent::load($oxid);

        return $this->_isLoaded;
    }

    /**
     */
    public function initOxCategory()
    {
        $oxid = Oxid\Core\UtilsObject::getInstance()->generateUID();
        $oxshopid = Utils\OxidRegistry::getActiveShopId();

        $this->_sOXID = $oxid;
        $this->_iShopId = $oxshopid;

        $this->setCategoryDataEntry('oxcategories__oxid', $oxid);
        $this->setCategoryDataEntry('oxcategories__oxactive', Transfers\AbstractTransfer::STATUS_ACTIVE_ID);
        $this->setCategoryDataEntry('oxcategories__oxhidden', self::STATUS_VISIBLE);
        $this->setCategoryDataEntry('oxcategories__oxshopid', $oxshopid);
        $this->setCategoryDataEntry('oxcategories__oxextlink', '');
        $this->setCategoryDataEntry('oxcategories__oxtemplate', '');
        $this->setCategoryDataEntry('oxcategories__oxdefsort', '');
        $this->setCategoryDataEntry('oxcategories__oxicon', '');
        $this->setCategoryDataEntry('oxcategories__oxpromoicon', '');
        $this->setCategoryDataEntry('oxcategories__oxpricefrom', '');
        $this->setCategoryDataEntry('oxcategories__oxpriceto', '');
        $this->setCategoryDataEntry('oxcategories__oxdesc', '');
        $this->setCategoryDataEntry('oxcategories__oxlongdesc', '');
        $this->setCategoryDataEntry('oxcategories__oxthumb', '');
    }

}