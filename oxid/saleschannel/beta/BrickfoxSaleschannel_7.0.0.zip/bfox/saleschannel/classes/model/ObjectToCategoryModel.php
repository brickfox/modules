<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 06.02.19
 * Time: 16:35
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\model\oxid\BaseModel;
use bfox\saleschannel\classes\util\OxidRegistry;
use \OxidEsales\Eshop as Oxid;

class ObjectToCategoryModel extends BaseModel
{
    /**
     * ###################################################################
     *              CONSTANTS
     * ###################################################################
     */
    /**
     * table fields
     * @var string
     */
    const   OXID				= 'OXID',
            OXSHOPID            = 'OXSHOPID',
            OXPOS				= 'OXPOS',
            OXTIME			    = 'OXTIME';

    /**
     * ###################################################################
     *              PROPERTIES
     * ###################################################################
     */

    /**
     * oxid
     * @var string
     */
    private $oxid = null;

    /**
     * ox article id
     * @var string
     */
    private $oxArticleId = null;

    /**
     * ox category id
     * @var string
     */
    private $oxCategoryId = null;

    /**
     *  ox position
     * @var integer
     */
    private $oxPosition = null;

    /**
     * ox time
     *
     * OXTIME is the timestamp when you assign an article to a category.
     * The earliest OXTIME (i.e. smallest number) is the major category.
     * The major category is the canonical link for this article (relevant for SEO)
     * @var integer
     */
    private $oxTime = null;

    /**
     *  ox shop id
     * @var integer
     */
    private $oxShopId = null;

    private $_mappingModel;



    /**
     * ###################################################################
     *              GETTERS AND SETTERS
     * ###################################################################
     */

    /**
     * getOxid.
     *
     * @return integer oxid
     */
    public function getOxid()
    {
        return $this->oxid;
    }

    /**
     * setOxid.
     *
     * @param integer $oxid oxid
     * @return ObjectToCategoryModel
     */
    public function setOxid($oxid)
    {
        $this->oxid = $oxid;
        return $this;
    }

    /**
     * getOxArticleId.
     *
     * @return string ox article id
     */
    public function getOxArticleId()
    {
        return $this->oxArticleId;
    }

    /**
     * setOxArticleId.
     *
     * @param string $oxArticleId ox article id
     */
    public function setOxArticleId($oxArticleId)
    {
        $this->oxArticleId = $oxArticleId;
    }

    /**
     * getOxCategoryId.
     *
     * @return string ox category id
     */
    public function getOxCategoryId()
    {
        return $this->oxCategoryId;
    }

    /**
     * setOxCategoryId.
     *
     * @param string $oxCategoryId ox category id
     */
    public function setOxCategoryId($oxCategoryId)
    {
        $this->oxCategoryId = $oxCategoryId;
    }

    /**
     * setOxShopId.
     *
     * @param integer $oxShopId ox shopid
     */
    private function setOxShopId($oxShopId)
    {
        $this->oxShopId = $oxShopId;
    }

    /**
     * getOxShopId.
     *
     * @return integer ox shopid
     */
    private function getOxShopId()
    {
        return $this->oxShopId;
    }

    /**
     * getOxPosition.
     *
     * @return integer ox position
     */
    public function getOxPosition()
    {
        return $this->oxPosition;
    }

    /**
     * setOxPosition.
     *
     * @param integer $oxPosition ox position
     */
    public function setOxPosition($oxPosition)
    {
        $this->oxPosition = $oxPosition;
    }

    /**
     * getOxTime.
     *
     * @return integer ox time
     */
    public function getOxTime()
    {
        return $this->oxTime;
    }

    /**
     * setOxTime.
     *
     * @param integer $oxTime ox time
     */
    public function setOxTime($oxTime)
    {
        $this->oxTime = $oxTime;
    }


    /**
     * ###################################################################
     *              METHODS
     * ###################################################################
     */

    /**
     * Contructor.
     */
    public function __construct( $mappingModel = null)
    {
        parent::__construct();

        if (is_null($mappingModel))
        {
            $this->_mappingModel = oxNew(MappingModel::class);
        }
        else
        {
            $this->_mappingModel = $mappingModel;
        }

        $this->setOxShopId(OxidRegistry::getActiveShopId());
        $this->init('oxobject2category');
        $this->oxTime = time();
    }

    /**
     * getObjectToCategoriesData
     *
     * @param integer $oxArticleId ox article id
     * @return array result
     */
    public function getObjectToCategoriesData($oxArticleId)
    {
        $result		= [];

        if(false === is_null($oxArticleId) && '' != $oxArticleId)
        {
            $categoryListModel		= oxNew(CategoryListModel::class, $this->getOxShopId());
            $categoryListModel->loadCategoryAssignments($oxArticleId, $this);

            foreach($categoryListModel as $oxObject2CategoryModel)
            {
                $oxCategoryId = $oxObject2CategoryModel->getFieldData('oxcatnid');
                if(array_key_exists($oxCategoryId, $result))
                {
                    $this->delete($result[$oxCategoryId][self::OXID]);
                }
                $result[$oxCategoryId] = array(
                    self::OXID		=> $oxObject2CategoryModel->getFieldData('oxid'),
                    self::OXPOS		=> $oxObject2CategoryModel->getFieldData('oxpos'),
                    self::OXTIME	=> $oxObject2CategoryModel->getFieldData('oxtime'),
                );

                if ($this->checkForFieldInTable('oxshopid') === true)
                {
                    $result[$oxCategoryId][self::OXSHOPID] = $oxObject2CategoryModel->getFieldData('oxshopid');
                }
            }
        }

        return $result;
    }

    /**
     * getOxCategoryIdByBfCategoryId.
     *
     * @param integer $bfCategoryId cbf category id
     * @return string ox category id
     */
    public function getOxCategoryIdByBfCategoryId($bfCategoryId)
    {
        $result			= null;
        $mappingModel	= clone $this->_mappingModel;
        $mappingModel->loadByBfId($bfCategoryId, MappingModel::KEY_TYPE_CATEGORIES);

        if(true === $mappingModel->isLoaded())
        {
            $result['oxshopid'] = $mappingModel->getFieldData('oxshopid');
            $result['oxsystemid'] = $mappingModel->getSystemId();
        }
        return $result;
    }


    /**
     * getOxCategoryMappingDataByBfCategoryId.
     *
     * @param integer $bfCategoryId cbf category id
     * @return array  category mapping with systemid and shopid
     */
    public function getOxCategoryMappingDataByBfCategoryId($bfCategoryId)
    {
        $result			= array();
        $mappingModel	= oxNew(MappingModel::class);
        $mappingModel->loadByBfId($bfCategoryId, MappingModel::KEY_TYPE_CATEGORIES);

        if(true === $mappingModel->isLoaded())
        {
            $result['oxshopid'] = $mappingModel->getFieldData('oxshopid');
            $result['oxsystemid'] = $mappingModel->getSystemId();
        }
        return $result;
    }


    /**
     * save.
     */
    public function save()
    {
        if(true === is_null($this->getOxid()))
        {
            $this->setOxid(Oxid\Core\UtilsObject::getInstance()->generateUID());

            $record = array(
                'oxobject2category__oxid' => $this->getOxid(),
                'oxobject2category__oxobjectid' => $this->getOxArticleId(),
                'oxobject2category__oxcatnid' => $this->getOxCategoryId(),
                'oxobject2category__oxpos' => $this->getOxPosition(),
                'oxobject2category__oxtime' => $this->getOxTime(),
            );

            if ($this->checkForFieldInTable('oxshopid') === true)
            {
                $record['oxobject2category__oxshopid'] = $this->getOxShopId();
            }

            $this->assign($record);

            parent::save();
        }
        else
        {
            // removed 	OXPOS = "' . $this->getOxPosition() . '", to keep the current position

            if ($this->checkForFieldInTable('oxshopid') === true) {

                $query = 'UPDATE oxobject2category SET 
                OXOBJECTID = "' . $this->getOxArticleId() . '", 
                OXCATNID = "' . $this->getOxCategoryId() . '", 
                OXSHOPID = "' . $this->getOxShopId() . '"
                WHERE OXID = "' . $this->getOxid() . '"
			';
            }
            else{
                $query = 'UPDATE oxobject2category SET 
                OXOBJECTID = "' . $this->getOxArticleId() . '", 
                OXCATNID = "' . $this->getOxCategoryId() . '"
                WHERE OXID = "' . $this->getOxid() . '"
			';
            }

            Oxid\Core\DatabaseProvider::getDb()->execute($query);
        }
    }


}