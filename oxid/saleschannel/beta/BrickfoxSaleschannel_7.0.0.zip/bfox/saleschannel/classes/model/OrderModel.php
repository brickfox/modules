<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 26.02.19
 * Time: 10:08
 */

namespace bfox\saleschannel\classes\model;

 use bfox\saleschannel\classes\util as Utils;


class OrderModel extends OrderModel_parent
{
    /**
    * constants for orders status
    */
    const	IMPORT_ORDERS_STATUS_PAYED			= 'payed',
        IMPORT_ORDERS_STATUS_CANCELLED			= 'cancelled',
        IMPORT_ORDERS_STATUS_SHIPPED			= 'shipped',
        IMPORT_ORDERS_STATUS_PARTLY_RETURNED	= 'partlyReturned',
        IMPORT_ORDERS_STATUS_RETURNED			= 'returned';

    /**
    * constants for orders folders
    */
    const	IMPORT_ORDERS_FOLDER_NEW			= 'ORDERFOLDER_NEW',
        IMPORT_ORDERS_FOLDER_PROBLEMS			= 'ORDERFOLDER_PROBLEMS',
        IMPORT_ORDERS_FOLDER_FINISHED			= 'ORDERFOLDER_FINISHED';


    /**
     * loadByOxOrderNr
     *
     * @param integer $oxOrderNr ox order number
     * @return boolean is loaded
     */
    public function loadByOxOrderNr($oxOrderNr)
    {
        $sSelect = $this->buildSelectString(
            array($this->getViewName().'.oxordernr' => $oxOrderNr)
        );
        return $this->_isLoaded = $this->assignRecord($sSelect);
    }

    /**
     * cancelOrder
     *
     * @return null
     */
    public function cancel($updateStock = false)
    {
        if(!$this->isCancelled())
        {
            if((bool)$updateStock === true)
            {
                $this->cancelOrder();
            } else {
                $this->oxorder__oxstorno->setValue(1);
                $this->save();

                foreach ($this->getOrderArticles() as $oOrderArticle) {
                    $oOrderArticle->oxorderarticles__oxstorno->setValue(1);
                    $oOrderArticle->save();
                }
            }

            $this->setOxfolder(self::IMPORT_ORDERS_FOLDER_FINISHED);
            $this->save();
        }
    }

    /**
     * pay
     *
     * @param string $date optional
     * @return null
     */
    public function pay($date = null)
    {
        if(!$this->isPayed())
        {
            if(is_null($date))
            {
                $date = date('Y-m-d H:i:s');
            }
            $this->oxorder__oxpaid->setValue($date);
            $this->setOxfolder(self::IMPORT_ORDERS_FOLDER_NEW);
            $this->save();
        }
    }

    /**
     * ship
     *
     * @param string $trackingId tracking id
     * @param string $date optional
     */
    public function ship($trackingId, $date = null)
    {
        if(!$this->isShipped())
        {
            if(is_null($date))
            {
                $date = date('Y-m-d H:i:s');
            }
            $this->oxorder__oxsenddate->setValue($date);
            $this->setOxfolder(self::IMPORT_ORDERS_FOLDER_FINISHED);

            if($trackingId != '')
            {
                $this->oxorder__oxtrackcode->setValue($trackingId);
            }

            $this->save();
        }
    }

    /**
     * isCancelled
     *
     * @return boolean is cancelled
     */
    public function isCancelled()
    {
        return (bool) $this->getFieldData('oxstorno');
    }

    /**
     * isPayed
     *
     * @return boolean is payed
     */
    public function isPayed()
    {
        return $this->getFieldData('oxpaid') != '0000-00-00 00:00:00';
    }

    /**
     * isShipped
     *
     * @return boolean is shipped
     */
    public function isShipped()
    {
        return $this->getFieldData('oxsenddate') != '0000-00-00 00:00:00' && $this->getFieldData('oxsenddate') != '-';
    }

    /**
     * sendShippingConfirmation.
     *
     * @return OrderModel order model
     */
    public function sendShippingConfirmation()
    {
        if(Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_MAILINGS_SHIPPING_CONFIRMATION))
        {
            $notifierModel = oxNew(Utils\MessageManager::class);
            $notifierModel->notify($this);
        }
        return $this;
    }


    /**
     * setOxfolder
     *
     * @param string $folderName
     * @return OrderModel
     */
    private function setOxfolder($folderName)
    {
        $this->oxorder__oxfolder->setValue($folderName);
        return $this;
    }

}
