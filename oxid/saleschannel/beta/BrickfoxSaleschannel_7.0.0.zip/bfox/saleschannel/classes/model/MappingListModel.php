<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 21.01.19
 * Time: 17:51
 */

namespace bfox\saleschannel\classes\model;

use \OxidEsales\Eshop as Oxid;
use bfox\saleschannel\classes\model as Models;


class MappingListModel extends Models\oxid\ListModel
{

    /*****************************************************************************
     *
     * Class properties
     *
     *****************************************************************************/

    /**
     * mappings list
     *
     * @var array
     */
    private $mappingsList = array();

    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/

    /**
     * loadMappingsModelList.
     *
     * @param string $type type
     * @param string $oxshopid shop id
     * @param string $keyType key type
     * @return array mapping list
     */
    public function loadMappingsModelList($type, $oxshopid, $keyType = MappingModel::TABLE_FIELD_BFID)
    {
        $this->setMappingsList(array());

        $query = sprintf('SELECT %s, %s, %s, %s FROM bfmapping WHERE %s = ? AND %s = ? ;',
            MappingModel::TABLE_FIELD_OXID,
            MappingModel::TABLE_FIELD_BFID,
            MappingModel::TABLE_FIELD_SYSTEMID,
            MappingModel::TABLE_FIELD_OXSHOPID,
            MappingModel::TABLE_FIELD_TYPE,
            MappingModel::TABLE_FIELD_OXSHOPID
        );

        $dB = Oxid\Core\DatabaseProvider::getDb();
        $dB->setFetchMode(Oxid\Core\Database\Adapter\DatabaseInterface::FETCH_MODE_ASSOC);

        $resultSet = $dB->select($query, array($type, $oxshopid));

        if ($resultSet != false && $resultSet->count() > 0)
        {
            while (!$resultSet->EOF)
            {
                $row = $resultSet->getFields();
                $mappingModel = oxNew(MappingModel::class);
                $mappingModel->load($row[MappingModel::TABLE_FIELD_OXID]);

                $this->addMappingToMappingsList($row[$keyType], $mappingModel);
                $resultSet->fetchRow();
            }
        }

        return $this->getMappingsList();
    }

    /**
     * getMappingsList.
     *
     * @param string $key key
     * @param string $oxShopId shop id
     * @return mixed null/MappingModel
     */
    public function getMappingByKey($key, $oxShopId)
    {
        $returnValue = null;
        if($this->mappingsList && array_key_exists($key, $this->mappingsList[$oxShopId])){
            $returnValue = $this->mappingsList[$oxShopId][$key];
        }
        return $returnValue;
    }

    /**
     * addMappingToMappingsList.
     *
     * @param string $key key
     * @param MappingModel $mapping mapping model
     * @return MappingListModel mapping list model
     */
    public function addMappingToMappingsList($key, $mapping)
    {
        $oxShopId = $mapping->getOxShopId();
        $this->mappingsList[$oxShopId][$key] = $mapping;
        return $this;
    }

    /**
     * removeMappingFromMappingsList.
     *
     * @param string $key key
     * @param string $oxShopId shop id
     * @return MappingListModel mapping list model
     */
    public function removeMappingFromMappingsList($key, $oxShopId)
    {
        if(array_key_exists($key, $this->mappingsList[$oxShopId]))
        {
            unset($this->mappingsList[$oxShopId][$key]);
        }
        return $this;
    }

    /*****************************************************************************
     *
     * helper functions
     *
     *****************************************************************************/

    /**
     * getMappingsList
     *
     * @return array with mapping models
     */
    private function getMappingsList()
    {
        return $this->mappingsList;
    }

    /**
     * setMappingsList.
     *
     * @param $mappingsList array with mapping models
     * @return MappingListModel mapping list model
     */
    private function setMappingsList($mappingsList)
    {
        $this->mappingsList = $mappingsList;
        return $this;
    }

}
