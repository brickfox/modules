<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 08.02.19
 * Time: 19:10
 */

namespace bfox\saleschannel\classes\model;

use \OxidEsales\Eshop as Oxid;


class AttributeListModel extends Oxid\Application\Model\AttributeList
{

    /**
     * loadAttributes.
     */
    public function loadAttributesList()
    {
        $viewNameGenerator = Oxid\Core\Registry::get(Oxid\Core\TableViewNameGenerator::class);

        $statement			= sprintf(
            'SELECT * FROM %s;',
            $viewNameGenerator->getViewName('oxattribute')
        );

        $this->selectString($statement);
    }

}