<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 13.02.19
 * Time: 15:48
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\model\oxid as OxidModels;
use \OxidEsales\Eshop as Oxid;

class ObjectToAttributeModel extends OxidModels\MultiLanguageModel
{

    /*****************************************************************************
     *
     * Class properties
     *
     *****************************************************************************/

    /**
     * ox object to attribute assignments
     * @var array
     */
    private $oxObjectToAttributeAssignments = null;

    /**
     * oxid
     * @var string
     */
    private $oxid = null;

    /**
     * ox article id
     * @var string
     */
    private $oxArticleId = null;

    /**
     * ox attribute id
     * @var string
     */
    private $oxAttributeId = null;

    /**
     * ox value
     * @var string
     */
    private $oxValue = null;

    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/

    /**
     * Contructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->init('oxobject2attribute');
    }

    /**
     * reset.
     */
    private function reset()
    {
        $this->setOxAttributeId(null);
        $this->setOxid(null);
        $this->setOxValue(null);
    }

    /**
     * save.
     */
    public function save()
    {
        if(is_null($this->_sOXID) === true || strlen($this->_sOXID) === 0)
        {
            $this->setOxid(Oxid\Core\UtilsObject::getInstance()->generateUID());
        }

        $this->assign(
            array(
                'oxobject2attribute__oxid'			=> $this->getOxid(),
                'oxobject2attribute__oxobjectid'	=> $this->getOxArticleId(),
                'oxobject2attribute__oxattrid'		=> $this->getOxAttributeId(),
                'oxobject2attribute__oxvalue'		=> $this->getOxValue(),
            )
        );

        parent::save();

        $this->updateExistingAssignments();
    }

    public function loadByIndices($oxObjectId, $oxAttrId, $oxValue) {
        $query = $this->buildSelectString(
            array(
                'oxobjectid' => $oxObjectId,
                'oxattrid' => $oxAttrId,
                'oxvalue' => $oxValue
            ));

        $this->_isLoaded = $this->assignRecord($query);
        return $this->_isLoaded;
    }

    /**
     * deleteOldAssignments.
     */
    public function deleteOldAssignments()
    {
        $existingObjectToAttributeAssignments = $this->getOxObjectToAttributeAssignments();

        foreach($existingObjectToAttributeAssignments as $oxid => $assignmentData)
        {
            if(false === $assignmentData['modified'])
            {
                $this->delete($oxid);
                unset($this->oxObjectToAttributeAssignments[$oxid]);
            }
        }
    }

    /**
     * getOxid.
     *
     * @return string oxid
     */
    public function getOxid()
    {
        return $this->_sOXID;
    }

    /**
     * setOxid.
     *
     * @param string $oxid oxid
     */
    public function setOxid($oxid)
    {
        $this->oxid = $oxid;
    }

    /**
     * getOxArticleId.
     *
     * @return string ox article id
     */
    public function getOxArticleId()
    {
        return $this->oxArticleId;
    }

    /**
     * setOxArticleId.
     *
     * @param string $oxArticleId ox article id
     */
    public function setOxArticleId($oxArticleId)
    {
        $this->oxArticleId = $oxArticleId;
    }

    /**
     * getOxAttributeId.
     *
     * @return string ox attribute id
     */
    public function getOxAttributeId()
    {
        return $this->oxAttributeId;
    }

    /**
     * setOxAttributeId.
     *
     * @param string $oxAttributeId ox attribute id
     */
    public function setOxAttributeId($oxAttributeId)
    {
        $this->oxAttributeId = $oxAttributeId;
    }

    /**
     * getOxValue.
     *
     * @return string ox value
     */
    public function getOxValue()
    {
        return $this->oxValue;
    }

    /**
     * setOxValue.
     *
     * @param string $oxValue ox value
     */
    public function setOxValue($oxValue)
    {
        $this->oxValue = $oxValue;
    }

    /*****************************************************************************
     *
     * helper functions
     *
     *****************************************************************************/

    /**
     * getOxObjectToAttributeAssignments.
     *
     * @return array ox object to attribute assignments
     */
    private function getOxObjectToAttributeAssignments()
    {
        if(true === is_null($this->oxObjectToAttributeAssignments))
        {
            $this->initOxObjectToAttributeAssignments();
        }

        return $this->oxObjectToAttributeAssignments;
    }

    /**
     * setOxObjectToAttributeAssignments.
     *
     * @param array $oxObjectToAttributeAssignments ox object to attribute assignments
     */
    private function setOxObjectToAttributeAssignments($oxObjectToAttributeAssignments)
    {
        $this->oxObjectToAttributeAssignments = $oxObjectToAttributeAssignments;
    }

    /**
     * initOxObjectToAttributeAssignments.
     */
    private function initOxObjectToAttributeAssignments()
    {
        $oxArticleId						= $this->getOxArticleId();
        $oxObjectToAttributeAssignments		= array();

        if(false === is_null($oxArticleId) && '' != $oxArticleId)
        {
            $objectToAttributeListModel		= oxNew(ObjectToAttributeListModel::class);
            $objectToAttributeListModel->loadArticleAttributes($this->getOxArticleId());

            foreach($objectToAttributeListModel as $objectToAttributeModel)
            {
                $oxObjectToAttributeAssignments[$objectToAttributeModel->getFieldData('oxid')] = array(
                    'oxattrid'  => $objectToAttributeModel->getFieldData('oxattrid'),
                    'oxvalue'   => $objectToAttributeModel->getFieldData('oxvalue'),
                    'modified'  => false
                );
            }
        }
        $this->setOxObjectToAttributeAssignments($oxObjectToAttributeAssignments);
    }

    /**
     * getExistingAssignmentOxid.
     *
     * @return string existing assignment oxid
     */
    private function getExistingAssignmentOxid()
    {
        $result = null;
        $existingObjectToAttributeAssignments = $this->getOxObjectToAttributeAssignments();

        foreach($existingObjectToAttributeAssignments as $oxid => $objectToAttributeAssignmentData)
        {
            if(
                $objectToAttributeAssignmentData['oxattrid'] == $this->getOxAttributeId()
                && $objectToAttributeAssignmentData['oxvalue'] == $this->getOxValue()
            )
            {
                $result = $oxid;
                break;
            }
        }
        return $result;
    }

    /**
     * updateExistingAssignments.
     *
     * Will create a new array entry for new assignments.
     * All current ox attribute entries will be flaged as modified.
     * All non flaged ox attribute entries will be deleted later.
     */
    private function updateExistingAssignments()
    {
        $this->oxObjectToAttributeAssignments[$this->getOxid()] = array(
            'oxattrid'      => $this->getOxAttributeId(),
            'oxvalue'       => $this->getOxValue(),
            'modified'      => true
        );
    }

}