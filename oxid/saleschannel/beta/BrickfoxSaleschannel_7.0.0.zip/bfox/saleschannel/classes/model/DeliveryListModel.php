<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 23.01.19
 * Time: 16:15
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\util as Utils;


class DeliveryListModel extends \OxidEsales\Eshop\Application\Model\DeliveryList
{
    /*****************************************************************************
     *
     * Class properties
     *
     *****************************************************************************/

    /**
     * default delivery models list
     * @var array
     */
    private $defaultDeliveryModelsList = array();

    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/

    /**
     * getDefaultList
     *
     * @return array default list
     */
    public function getDefaultList()
    {
        if(sizeof($this->defaultDeliveryModelsList) == 0)
        {
            $this->initDefaultDeliveriesModelList();
        }
        return $this->defaultDeliveryModelsList;
    }

    /*****************************************************************************
     *
     * helper functions
     *
     *****************************************************************************/

    /**
     * addDefaultDeliveryModelsList
     *
     * @param string $deliveryId delivery id
     * @param DeliveryModel $deliveryModel delivery model
     * @return DeliveryListModel delivery list model
     */
    private function addDefaultDeliveryModelsList($deliveryId, DeliveryModel $deliveryModel)
    {
        $this->defaultDeliveryModelsList[$deliveryId] = $deliveryModel;
        return $this;
    }

    /**
     * initDefaultDeliveriesModelList.
     *
     * @return void
     */
    private function initDefaultDeliveriesModelList()
    {
        $configValue = Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_DEFAULT_DELIVERY_TO_CATEGORIES_MATCHING);

        if(strlen($configValue) > 0)
        {
            $deliveries = explode(',', $configValue);

            foreach($deliveries as $deliveryTitle)
            {
                $deliveryModel = oxNew(DeliveryModel::class);
                $deliveryModel->loadByTitle($deliveryTitle);
                if($deliveryModel->isLoaded())
                {
                    $this->addDefaultDeliveryModelsList($deliveryModel->getId(), $deliveryModel);
                }
            }
        }
    }
}
