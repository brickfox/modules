<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 23.01.19
 * Time: 10:14
 */

namespace bfox\saleschannel\classes\model\oxid;

use bfox\saleschannel\classes\model\MappingModel;

class Category extends Category_parent
{
    /**
     * @param null $sOXID
     * @return bool
     */
    public function delete($sOXID = null)
    {
        if (parent::delete($sOXID))
        {
            $this->deleteCategoryMapping($sOXID);

            return true;
        }

        return false;
    }


    /**
     * @param $oxid
     */
    private function deleteCategoryMapping($oxid)
    {
        /** @var MappingModel $mappingModel */
        $mappingModel =  oxNew(MappingModel::class);

        if ($mappingModel)
        {
            $mappingModel->loadBySystemId($oxid, MappingModel::KEY_TYPE_CATEGORIES);

            if ($mappingModel->isLoaded())
            {
                $mappingModel->delete();
            }
        }
    }
}