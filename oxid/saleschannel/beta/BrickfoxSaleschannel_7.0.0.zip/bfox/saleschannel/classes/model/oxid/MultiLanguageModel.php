<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 13.02.19
 * Time: 15:50
 */

namespace bfox\saleschannel\classes\model\oxid;


class MultiLanguageModel extends \OxidEsales\Eshop\Core\Model\MultiLanguageModel
{

}