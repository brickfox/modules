<?php
/**
 * Class ImportExportController
 */

namespace bfox\saleschannel\classes\controller;

use bfox\saleschannel\classes\exception as Exceptions;
use bfox\saleschannel\classes\model\AttributeModel;
use bfox\saleschannel\classes\model\oxid as OxidExtended;
use bfox\saleschannel\classes\util as Utils;
use bfox\saleschannel\classes\controller\transfer as Transfer;
use OxidEsales\EshopCommunity\Core\Request;


class TransferController
{
    const SETTING_NAME_CLASSES_NAMESPACE   = '\\' . __NAMESPACE__ . '\\transfer\\';

    const SETTING_NAME_MANUFACTURERSMAPPING = 'ImportManufacturersMapping';
    const SETTING_NAME_CATEGORIESMAPPING    = 'ImportCategoriesMapping';
    const SETTING_NAME_PRODUCTSMAPPING      = 'ImportProductsMapping';
    const SETTING_NAME_MANUFACTURERS        = 'ImportManufacturers';
    const SETTING_NAME_CATEGORIES           = 'ImportCategories';
    const SETTING_NAME_PRODUCTS             = 'ImportProducts';
    const SETTING_NAME_PRODUCTSUPDATE       = 'ImportProductsUpdate';
    const SETTING_NAME_PRODUCTSUPDATEBFAPI  = 'ImportProductsUpdateBFApi';
    const SETTING_NAME_PRODUCTSASSIGNMENTS  = 'ImportProductsAssignments';
    const SETTING_NAME_PRODUCTS_REPORTS     = 'ExportProductsReports';
    const SETTING_NAME_ORDERS               = 'ExportOrders';
    const SETTING_NAME_ORDERSSTATUS         = 'ImportOrdersStatus';

    const BFAPI_UPDATE_STOCK_CALL           = 'productsvariationsstock';



    /** @var Utils\FileManager $_fileManager */
    private $_fileManager = null;

    /** @var Utils\MessageManager $_messageManager */
    private $_messageManager = null;

    /** @var Utils\ScriptManager $_scriptManager */
    private $_scriptManager = null;

    /** @var Transfer\TransferSettings $transferSettings */
    private $transferSettings = null;

    /** @var null/int $shp Oxid shp parameter*/
    private $shp = null;



    public function __construct()
    {
        $oxidShp = oxNew(Request::class)->getRequestParameter("shp");

        if ($oxidShp === null || $oxidShp < 1)
        {
            Utils\LogManager::getInstance()->error("Export/Import failed: No shp parameter defined!");
            exit;
        }

        $this->shp = $oxidShp;
        $this->_fileManager = oxNew(Utils\FileManager::class);
        $this->_messageManager = oxNew(Utils\MessageManager::class);
        $this->transferSettings = oxNew(Transfer\TransferSettings::class, '', '', '');

        $hangingTime = Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_SL_CLEANUP_HANGING_IN_SECONDS);
        $removalTime = Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_SL_CLEANUP_REMOVAL_IN_DAYS);
        $this->_scriptManager = oxNew(Utils\ScriptManager::class, $hangingTime, $removalTime);

        // set standard language as base language
        Utils\OxidRegistry::setBaseLanguage(Utils\OxidRegistry::getDefaultLanguageId());

    }

    public function deleteAllProducts()
    {
        $deleteArticlesSetting['settings'] = $this->transferSettings->getImportProductsSetting();
        $deleteArticlesSetting['object'] = "oxArticle";
        $deleteArticlesSetting['table'] = "oxarticles";

        $this->delete(
            array(
                $deleteArticlesSetting
            ),
            new OxidExtended\Article()
        );
    }

    public function deleteAllCategories()
    {
        $deleteCategoriesSetting['settings'] = $this->transferSettings->getImportCategoriesSetting();
        $deleteCategoriesSetting['object'] = "oxCategory";
        $deleteCategoriesSetting['table'] = "oxcategories";

        $this->delete(
            array(
                $deleteCategoriesSetting
            ),
            new OxidExtended\Category()
        );
    }

    public function deleteAllManufacturers()
    {
        $deleteManufacturersSetting['settings'] = $this->transferSettings->getImportManufacturersSetting();
        $deleteManufacturersSetting['object'] = "oxManufacturer";
        $deleteManufacturersSetting['table'] = "oxmanufacturers";

        $this->delete(
            array(
                $deleteManufacturersSetting
            ),
            new OxidExtended\Manufacturer()
        );
    }


    public function deleteAllAttributes()
    {
        $deleteAttributesSetting['settings'] = $this->transferSettings->getImportAttributesSetting();
        $deleteAttributesSetting['object'] = "oxAttribute";
        $deleteAttributesSetting['table'] = "oxattribute";

        $this->delete(
            array(
                $deleteAttributesSetting
            ),
            new AttributeModel()
        );
    }

    /**
     * @throws Exceptions\ConfigurationException
     */
    public function exportOrders()
    {
        /** @var  $exportOrdersSetting Transfer\TransferSettings*/
        $exportOrdersSetting = $this->transferSettings->getExportOrdersSetting();

        $this->export($exportOrdersSetting);
    }

    /**
     * @throws Exceptions\ConfigurationException
     */
    public function importProductsMapping()
    {
        $this->import(
            array(
                $this->transferSettings->getImportProductsMappingSetting()
            )
        );
    }

    /**
     * @throws Exceptions\ConfigurationException
     */
    public function importCategoriesMapping()
    {
        $this->import(
            array(
                $this->transferSettings->getImportCategoriesMappingSetting()
            )
        );
    }
    /**
     * importManufacturersMapping.
     */
    public function importManufacturersMapping()
    {
        $this->import(
            array(
                $this->transferSettings->getImportManufacturersMappingSetting()
            )
        );
    }

    /**
     * @throws Exceptions\ConfigurationException
     */
    public function importOrdersStatus()
    {
        /** @var  $importOrdersStatusSetting Transfer\TransferSettings*/
        $importOrdersStatusSetting = $this->transferSettings->getImportOrderStatusSetting();

        $this->import(
            array(
                $importOrdersStatusSetting
            )
        );
    }

    /**
     * @throws Exceptions\ConfigurationException
     */
    public function importProducts()
    {
        /** @var  $importProductsSetting Transfer\TransferSettings*/
        $importProductsSetting = $this->transferSettings->getImportProductsSetting();
        $importProductsSetting->addScriptLoggerDependency($this->transferSettings->getImportManufacturersSetting());
        $importProductsSetting->addScriptLoggerDependency($this->transferSettings->getImportCategoriesSetting());
        $importProductsSetting->addScriptLoggerDependency($this->transferSettings->getImportProductsUpdateSetting());
        $importProductsSetting->addExecutionDependency($this->transferSettings->getImportManufacturersSetting());
        $importProductsSetting->addExecutionDependency($this->transferSettings->getImportCategoriesSetting());

        /** @var  $importProductsAssignmentsSetting Transfer\TransferSettings*/
        $importProductsAssignmentsSetting = $this->transferSettings->getImportProductsAssignmentsSetting();
        $importProductsAssignmentsSetting->addScriptLoggerDependency($this->transferSettings->getImportProductsSetting());
        $importProductsAssignmentsSetting->addExecutionDependency($this->transferSettings->getImportProductsSetting());

        $this->import(
            array(
                $this->transferSettings->getImportManufacturersSetting(),
                $this->transferSettings->getImportCategoriesSetting(),
                $importProductsSetting,
                $importProductsAssignmentsSetting
            )
        );
    }

    /**
     * @throws Exceptions\ConfigurationException
     */
    public function importCategories()
    {
        /** @var  $importCategoriesSetting Transfer\TransferSettings*/
        $importCategoriesSetting = $this->transferSettings->getImportCategoriesSetting();

        $this->import(
            array(
                $importCategoriesSetting
            )
        );
    }

    /**
     * @throws Exceptions\ConfigurationException
     */
    public function importManufacturers()
    {
        /** @var  $importManufacturersSetting Transfer\TransferSettings*/
        $importManufacturersSetting = $this->transferSettings->getImportManufacturersSetting();

        $this->import(
            array(
                $importManufacturersSetting
            )
        );
    }

    /**
     * @throws Exceptions\ConfigurationException
     */
    public function importProductsUpdate()
    {
        /** @var  $importProductsUpdateSetting Transfer\TransferSettings*/
        $importProductsUpdateSetting = $this->transferSettings->getImportProductsUpdateSetting();

        $importProductsUpdateSetting->addScriptLoggerDependency($this->transferSettings->getImportManufacturersSetting());
        $importProductsUpdateSetting->addScriptLoggerDependency($this->transferSettings->getImportCategoriesSetting());
        $importProductsUpdateSetting->addScriptLoggerDependency($this->transferSettings->getImportProductsSetting());

        $this->import(
            array(
                $importProductsUpdateSetting
            )
        );
    }



    /*****************************************************************************
     *
     * helper functions
     *
     *****************************************************************************/


    /**
     * @return array
     * @throws Exceptions\ConfigurationException
     */
    private function getImportFiles()
    {
        return $this->_fileManager->getImportFiles($this->transferSettings->getImportFilenameBases());
    }

    /**
     * getValidExchangeSubdirectories.
     *
     * @return array valid exchange subdirectories
     */
    private function getValidExchangeSubdirectories()
    {
        return $this->_fileManager->getValidExchangeSubdirectories($this->shp);
    }

    /**
     * @param \Exception $exception exception object
     */
    private function handleException(\Exception $exception)
    {
        Utils\LogManager::getInstance()->error($exception->__toString());

        $this->_messageManager->setNotificationRequired(false);
    }

    /**
     * @param array $importerSettings
     * @throws Exceptions\ConfigurationException
     */
    private function import(array $importerSettings)
    {
        $importSubdirectories = $this->getValidExchangeSubdirectories();

        // import subdirectory = oxshopid
        foreach($importSubdirectories as $oxshopid)
        {
            Utils\OxidRegistry::setActiveShopId($oxshopid);
            foreach($importerSettings as $importerSetting)
            {
                $this->handleImport($importerSetting);
            }
            Utils\OxidRegistry::setActiveShopId($oxshopid);
        }
    }

    /**
     * @param Transfer\TransferSettings $importSetting
     * @throws Exceptions\ConfigurationException
     */
    private function handleImport($importSetting)
    {
        $exchangeXMLImportFiles = $this->getImportFiles();

        if (true === array_key_exists($importSetting->getFilenameBase(), $exchangeXMLImportFiles)) {

            if (false === $importSetting->hasExecutionDependency($exchangeXMLImportFiles)) {

                $exchangeXMLImportFile = $exchangeXMLImportFiles[$importSetting->getFilenameBase()];

                try {
                    $deleteFile = true;

                    $logManager = Utils\LogManager::getInstance();
                    $logManager->debug('Start importing ' . $exchangeXMLImportFile);

                    try {
                        $scriptLoggerManager = $this->_scriptManager;

                        // throws an exception is case that script is already running
                        $scriptLoggerManager->check($importSetting->getPreparedScriptLoggerDependencies());

                        // insert script logger db entry - prevent a second execution
                        $scriptLoggerManager->start($importSetting->getName());

                        // do import
                        $className = $this->getFullQualifiedClassName($importSetting);

                        try {
                            $importer = new $className($exchangeXMLImportFile);
                            $importer->import();
                        } catch (\Exception $exception) {
                            $errorHandling = oxNew(Exceptions\ExceptionHandler::class);
                            $errorHandling->internalExceptionCatch($exception);
                        }

                        // update script logger db entries - so scripts can be executed again
                        $scriptLoggerManager->end();

                    } catch (Exceptions\ImportExportException $importException) {
                        // don't delete file after 'script is running' exception
                        if (Exceptions\ImportExportException::SCRIPT_RUNNING == $importException->getCode()) {
                            $deleteFile = false;
                        }
                        $this->handleException($importException);
                    } catch (\Exception $exception) {
                        $this->handleException($exception);
                    }

                    $logManager->debug('End importing ' . $exchangeXMLImportFile);

                    // delete file
                    if (true === $deleteFile) {
                        $this->_fileManager->deleteImportFile($exchangeXMLImportFile);
                        $this->handleImport($importSetting);
                    }
                } catch (\Exception $exception) {
                    $this->handleException($exception);
                }
            } else {

                Utils\LogManager::getInstance()->warn('Dependency detected! Script name: ' . $importSetting->getName());
            }

        }
    }

    /**
     * @param Transfer\TransferSettings $exporterSetting
     */
    private function export($exporterSetting)
    {
        $exportSubdirectories = $this->getValidExchangeSubdirectories();

        // export subdirectory = oxshopid
        foreach ($exportSubdirectories as $oxShopId)
        {
            Utils\OxidRegistry::setActiveShopId($oxShopId);

            $this->handleExport($exporterSetting);
        }
    }

    /**
     * @param Transfer\TransferSettings $exporterSetting export setting
     */
    private function handleExport($exporterSetting)
    {
        try {
            // do export
            $className = $this->getFullQualifiedClassName($exporterSetting);
            $exporter  = new $className();

            // only trigger export in case that data is available
            if (true === $exporter->isExporterDataAvailable())
            {
                $scriptLoggerManager = $this->_scriptManager;

                // throws an exception is case that script is already running
                $scriptLoggerManager->check($exporterSetting->getPreparedScriptLoggerDependencies());

                // insert script logger db entry - prevent a second execution
                $scriptLoggerManager->start($exporterSetting->getName());

                Utils\LogManager::getInstance()->debug('Start exporting ' . $exporterSetting->getName());

                $exchangeXMLExportFilename = $this->generateFullExportFilename($exporterSetting->getFilenameBase());

                // create export file using hash name
                $hashedExchangeXMLExportFilename = md5($exchangeXMLExportFilename);
                $exchangeXMLExportFile           = $this->_fileManager->createExportFile($hashedExchangeXMLExportFilename);

                $exporter->export($exchangeXMLExportFile);

                // after export rename file using real file name
                $this->_fileManager->renameExportFile($hashedExchangeXMLExportFilename, $exchangeXMLExportFilename);

                Utils\LogManager::getInstance()->debug('End exporting ' . $exporterSetting->getName());

                // update script logger db entries - so scripts can be executed again
                $scriptLoggerManager->end();
            }
        } catch (\Exception $exception) {
            $this->handleException($exception);
        }
    }



    private function delete($deletionSetting, $objectModel)
    {
        if ($this->shp === null || $this->shp === 0) {
            Utils\LogManager::getInstance()->error("Delete All operation failed: No shp parameter defined!");
            exit;
        }

        $exportSubdirectories = $this->getValidExchangeSubdirectories();

        // export subdirectory = oxshopid
        foreach ($exportSubdirectories as $oxShopId)
        {
            Utils\OxidRegistry::setActiveShopId($oxShopId);

            try {
                $class = $this->getFullQualifiedClassName($deletionSetting[0]["settings"]);
                $deleter = new $class("", null, $objectModel);
                $deleter->deleteAll($deletionSetting);
            }
            catch (\Exception $exception){
                $this->handleException($exception);
            }
        }
    }

    /**
     * @param $importSetting Transfer\TransferSettings
     * @return string
     */
    private function getFullQualifiedClassName($importSetting)
    {
        $fullName = self::SETTING_NAME_CLASSES_NAMESPACE . $importSetting->getAction() . '\\' ;
        $fullName = $fullName . $importSetting->getObjectNamespace($importSetting->getFilenameBase()) . '\\' . $importSetting->getName();

        return $fullName;
    }


    /**
     * @param string $exportFilenameBase export file name base
     * @return string full export file name
     */
    private function generateFullExportFilename($exportFilenameBase)
    {
        return $exportFilenameBase . '_' . date('Ymd_His') . '.xml';
    }
}
