<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 11.01.19
 * Time: 16:32
 */

namespace bfox\saleschannel\classes\controller\transfer;

use bfox\saleschannel\classes\util as Utils;
use bfox\saleschannel\classes\exception as Exceptions;


class TransferSettings
{

    /*****************************************************************************
     *
     * Class constants
     *
     *****************************************************************************/

    /**
     * setting names
     */
    const SETTING_NAME_PRODUCTSMAPPING    = 'ImportProductsMapping',
        SETTING_NAME_CATEGORIESMAPPING    = 'ImportCategoriesMapping',
        SETTING_NAME_MANUFACTURERS        = 'ImportManufacturers',
        SETTING_NAME_MANUFACTURERSMAPPING = 'ImportManufacturersMapping',
        SETTING_NAME_CATEGORIES           = 'ImportCategories',
        SETTING_NAME_PRODUCTS             = 'ImportProducts',
        SETTING_NAME_ATTRIBUTE            = 'ImportAttributes',
        SETTING_NAME_PRODUCTSUPDATE       = 'ImportProductsUpdate',
        SETTING_NAME_PRODUCTSSTOCKUPDATE  = 'ImportProductsStockUpdate',
        SETTING_NAME_PRODUCTSUPDATEBFAPI  = 'ImportProductsUpdateBFApi',
        SETTING_NAME_PRODUCTSASSIGNMENTS  = 'ImportProductsAssignments',
        SETTING_NAME_ORDERS               = 'ExportOrders',
        SETTING_NAME_PRODUCTS_REPORTS     = 'ExportProductsReports',
        SETTING_NAME_ORDERSSTATUS         = 'ImportOrdersStatus';

    const SETTING_NAME_NAMESPACE_IMPORT     = 'import',
        SETTING_NAME_NAMESPACE_EXPORT       = 'export';

    const SETTING_NAMESPACE_IMPORT_CLASSES  = ['products','categories','manufacturers','attributes','orders'];


    /**
     * name
     * @var string
     */
    private $name;

    /**
     * filename base
     * @var string
     */
    private $filenameBase;

    /**
     * action (import or export)
     * @var string
     */
    private $action;

    /**
     * script logger dependencies
     * @var array
     */
    private $scriptLoggerDependencies = array();

    /**
     * execution dependencies
     * @var array
     */
    private $executionDependencies = array();




    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/

    /**
     * TransferSettings constructor.
     * @param $name
     * @param $filenameBase
     * @param $action
     */
    public function __construct($name, $filenameBase, $action)
    {
        $this->setName($name);
        $this->setFilenameBase($filenameBase);
        $this->setAction($action);

        $this->addScriptLoggerDependency($this);
    }

    /**
     *
     * @return TransferSettings import manufacturers mapping setting
     * @throws Exceptions\ConfigurationException
     */
    public function getImportManufacturersMappingSetting()
    {
        return oxNew(TransferSettings::class,
            self::SETTING_NAME_MANUFACTURERSMAPPING,
            Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_STORAGE_FILENAME_MANUFACTURERSMAPPING),
            self::SETTING_NAME_NAMESPACE_IMPORT
        );
    }

    /**
     * @return TransferSettings
     * @throws Exceptions\ConfigurationException
     */
    public function getImportProductsMappingSetting()
    {
        return oxNew(TransferSettings::class,
            self::SETTING_NAME_PRODUCTSMAPPING,
            Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_STORAGE_FILENAME_PRODUCTSMAPPING),
            self::SETTING_NAME_NAMESPACE_IMPORT
        );
    }

    /**
     * @return TransferSettings
     * @throws Exceptions\ConfigurationException
     */
    public function getImportCategoriesMappingSetting()
    {
        return oxNew(TransferSettings::class,
            self::SETTING_NAME_CATEGORIESMAPPING,
            Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_STORAGE_FILENAME_CATEGORIESMAPPING),
            self::SETTING_NAME_NAMESPACE_IMPORT
        );
    }

    /**
     * @return TransferSettings
     * @throws Exceptions\ConfigurationException
     */
    public function getImportManufacturersSetting()
    {
        return oxNew(TransferSettings::class,
            self::SETTING_NAME_MANUFACTURERS,
            Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_STORAGE_FILENAME_MANUFACTURERS),
            self::SETTING_NAME_NAMESPACE_IMPORT
        );
    }

    /**
     * @return TransferSettings
     * @throws Exceptions\ConfigurationException
     */
    public function getImportAttributesSetting()
    {
        return oxNew(TransferSettings::class,
            self::SETTING_NAME_ATTRIBUTE,
            "Attributes",
            self::SETTING_NAME_NAMESPACE_IMPORT
        );
    }

    /**
     * @return TransferSettings
     * @throws Exceptions\ConfigurationException
     */
    public function getImportCategoriesSetting()
    {
        return oxNew(TransferSettings::class,
            self::SETTING_NAME_CATEGORIES,
            Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_STORAGE_FILENAME_CATEGORIES),
            self::SETTING_NAME_NAMESPACE_IMPORT
        );
    }

    /**
     * @return TransferSettings
     * @throws Exceptions\ConfigurationException
     */
    public function getImportProductsSetting()
    {
        return oxNew(TransferSettings::class,
            self::SETTING_NAME_PRODUCTS,
            Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_STORAGE_FILENAME_PRODUCTS),
            self::SETTING_NAME_NAMESPACE_IMPORT
        );
    }

    /**
     * @return TransferSettings
     * @throws Exceptions\ConfigurationException
     */
    public function getImportProductsUpdateSetting()
    {
        return oxNew(TransferSettings::class,
            self::SETTING_NAME_PRODUCTSUPDATE,
            Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_STORAGE_FILENAME_PRODUCTS_UPDATE),
            self::SETTING_NAME_NAMESPACE_IMPORT
        );
    }


    /**
     * @return TransferSettings import products stock update setting
     * @throws Exceptions\ConfigurationException
     */
    public function getImportProductsUpdateBFApiSetting()
    {
        return oxNew(TransferSettings::class,
            self::SETTING_NAME_PRODUCTSUPDATEBFAPI,
            "",
            self::SETTING_NAME_NAMESPACE_IMPORT
        );
    }

    /**
     * @return TransferSettings
     * @throws Exceptions\ConfigurationException
     */
    public function getImportProductsAssignmentsSetting()
    {
        return oxNew(TransferSettings::class,
            self::SETTING_NAME_PRODUCTSASSIGNMENTS,
            Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_STORAGE_FILENAME_PRODUCTS_ASSIGNMENTS),
            self::SETTING_NAME_NAMESPACE_IMPORT
        );
    }

    /**
     * @return TransferSettings
     * @throws Exceptions\ConfigurationException
     */
    public function getImportOrderStatusSetting()
    {
        return oxNew(TransferSettings::class,
            self::SETTING_NAME_ORDERSSTATUS,
            Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_STORAGE_FILENAME_ORDERSSTATUS),
            self::SETTING_NAME_NAMESPACE_IMPORT
        );
    }

    /**
     * @return TransferSettings
     * @throws Exceptions\ConfigurationException
     */
    public function getExportOrdersSetting()
    {
        return oxNew(TransferSettings::class,
            self::SETTING_NAME_ORDERS,
            Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_STORAGE_FILENAME_ORDERS),
            self::SETTING_NAME_NAMESPACE_EXPORT
        );
    }

    /**
     * getImportFilenameBases.
     *
     * @return array import filename bases
     */
    public function getImportFilenameBases()
    {
        return array(
            self::getImportProductsMappingSetting()->getFilenameBase(),
            self::getImportManufacturersSetting()->getFilenameBase(),
            self::getImportCategoriesSetting()->getFilenameBase(),
            self::getImportOrderStatusSetting()->getFilenameBase(),
            self::getImportProductsSetting()->getFilenameBase(),
            self::getImportProductsAssignmentsSetting()->getFilenameBase(),
            self::getImportProductsUpdateSetting()->getFilenameBase(),
            self::getImportCategoriesMappingSetting()->getFilenameBase(),
            self::getImportManufacturersMappingSetting()->getFilenameBase(),
        );
    }

    /**
     * getClassName.
     *
     * @return string class name
     */
    public function getClassName()
    {
        return $this->name;
    }

    /**
     * getName.
     *
     * @return string name
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * setName.
     *
     * @param string $name name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * getAction.
     *
     * @return string action
     */
    public function getAction()
    {
        return $this->action;
    }

    /**
     * setAction.
     *
     * @param string $action action
     */
    public function setAction($action)
    {
        $this->action = $action;
    }

    /**
     * getFilenameBase.
     *
     * @return string filename base
     */
    public function getFilenameBase()
    {
        return $this->filenameBase;
    }

    /**
     * setFilenameBase.
     *
     * @param string $filenameBase filename base
     */
    public function setFilenameBase($filenameBase)
    {
        $this->filenameBase = $filenameBase;
    }

    /**
     * Return the object-name-specific namespace for an import (e.g. categories)
     *
     * @param $fileBaseName
     * @return mixed|string
     */
    public function getObjectNamespace($fileBaseName)
    {
        $fileBaseNameToLower = strtolower($fileBaseName);

        $namespaceList = self::SETTING_NAMESPACE_IMPORT_CLASSES;

        foreach ($namespaceList as $classNamespace)
        {
            if (strpos($fileBaseNameToLower,$classNamespace) !== false)
            {
                return $classNamespace;
            }
        }
        return "";
    }

    /**
     * getScriptLoggerDependencies.
     *
     * @return array script logger dependencies
     */
    public function getPreparedScriptLoggerDependencies()
    {
        $result = array();

        foreach($this->getScriptLoggerDependencies() as $importExportSetting)
        {
            $result[] = $importExportSetting->getName();
        }
        return $result;
    }

    /**
     * addScriptLoggerDependency.
     *
     * @param TransferSettings $scriptLoggerDependency script logger dependency
     */
    public function addScriptLoggerDependency(TransferSettings $scriptLoggerDependency)
    {
        $this->scriptLoggerDependencies[] = $scriptLoggerDependency;
    }

    /**
     * hasExecutionDependency.
     *
     * @param array $exchangeFiles exchange files
     * @return boolean has execution dependency
     */
    public function hasExecutionDependency($exchangeFiles)
    {
        $result = false;
        foreach($this->getExecutionDependencies() as $importExportSetting)
        {
            if(true === array_key_exists($importExportSetting->getFilenameBase() , $exchangeFiles))
            {
                $result = true;
                break;
            }
        }

        return $result;
    }

    /**
     * addExecutionDependency.
     *
     * @param TransferSettings $executionDependency execution dependencies
     */
    public function addExecutionDependency(TransferSettings $executionDependency)
    {
        $this->executionDependencies[] = $executionDependency;
    }

    /*****************************************************************************
     *
     * helper functions
     *
     *****************************************************************************/

    /**
     * getScriptLoggerDependencies.
     *
     * @return array script logger dependencies
     */
    private function getScriptLoggerDependencies()
    {
        return $this->scriptLoggerDependencies;
    }

    /**
     * getExecutionDependencies.
     *
     * @return array execution dependencies
     */
    private function getExecutionDependencies()
    {
        return $this->executionDependencies;
    }
}