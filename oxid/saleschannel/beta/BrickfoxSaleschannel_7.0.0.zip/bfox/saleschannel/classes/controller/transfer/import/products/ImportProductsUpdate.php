<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 20.05.19
 * Time: 16:09
 */

namespace bfox\saleschannel\classes\controller\transfer\import\products;

use bfox\saleschannel\classes\model as Models;
use bfox\saleschannel\classes\util as Utils;

class ImportProductsUpdate extends ImportProducts
{

    private $exportProductsReports = null;

    protected function processImport(\SimpleXMLElement $productsUpdateData)
    {
        $bfProductsId			= $this->getIntegerValue($productsUpdateData->ProductId);

        // only import products having a valid products id
        if(0 < $bfProductsId)
        {
            // only import products having valid data
            if(true === $this->isValid($productsUpdateData))
            {
                try
                {
                    $productMapping = $this->loadProductMapping($bfProductsId, Models\MappingModel::KEY_TYPE_PRODUCTS, Models\MappingModel::TABLE_FIELD_BFID);

                    if ($productMapping->isLoaded() === true)
                    {
                        $productModel = clone $this->_emptyProductModel;
                        $productModel->loadWithMappingModel($productMapping);
                        $this->setProductModel($productModel);

                        // article found
                        if(false !== $this->getProductModel()->isLoaded())
                        {
                            $hasVariations = $this->getProductModel()->getArticleDataByKey('oxarticles__oxvarcount') > 0 ? true: false;

                            // products status
                            $this->handleStatus($productsUpdateData);

                            // enrich parent article data for non variation articles
                            if(false === $hasVariations)
                            {
                                $productsVariationsData = $productsUpdateData->Variations->Variation;

                                // products status
                                $this->handleStatus($productsVariationsData, 'VariationActive', true);

                                $this->handleVariationsData($productsVariationsData);
                            }

                            $this->getProductModel()->save();

                            if(true === $hasVariations)
                            {
                                $this->handleVariations($productsUpdateData);
                            }

                            $this->logRowEntry('Product with product id:' . $bfProductsId . ' imported!');
                        }
                    }
                    else if(false === $this->getShopModel()->isSuperShop())
                    {
                        #$this->addProductsReportsEntry(array(ExportProductsReports::PRODUCTS_REPORTS_DATA_PRODUCTS_ID_KEY => $bfProductsId));
                    }
                }
                catch(\Exception $exception)
                {
                    $this->handleException('Error while importing product with product id: ' . $bfProductsId. '! Exception: ' . $exception);
                }
            }
        }
        else
        {
            $this->handleException('Invalid products id found!');
        }
    }

    /**
     * preImport
     */
    protected function preImport()
    {
        $this->initExportProductsReports();
    }

    /**
     * postImport
     */
    protected function postImport()
    {
//        $exportProductsReports = $this->getExportProductsReports();
//
//        if(true === $exportProductsReports->isExporterDataAvailable())
//        {
//            $exchangeXMLExportFilename			= FileManager::generateFilename(ImportExportSettingManager::getExportProductsReportsSetting()->getFilenameBase());
//
//            // create export file using hash name
//            $hashedExchangeXMLExportFilename	= md5($exchangeXMLExportFilename);
//            $exchangeXMLExportFile				= FileManager::getInstance()->createExportFile($hashedExchangeXMLExportFilename);
//
//            $exportProductsReports->export($exchangeXMLExportFile);
//
//            // after export rename file using real file name
//            FileManager::getInstance()->renameExportFile($hashedExchangeXMLExportFilename, $exchangeXMLExportFilename);
//
//        }
    }

    /*****************************************************************************
     *
     * helper functions
     *
     *****************************************************************************/

    /**
     * addProductsReportsEntry.
     *
     * @param array $productsReportsData products reports data
     */
    private function addProductsReportsEntry($productsReportsData)
    {
        if(true === $this->isProductsReportsActivated())
        {
            $exportProductsReports = $this->getExportProductsReports();
            $exportProductsReports->addExportData($productsReportsData);
        }
    }

    /**
     * isProductsReportsActivated.
     * @return boolean is products reports activated
     */
    private function isProductsReportsActivated()
    {
//        return Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_PRODUCTS_REPORTS_ACTIVATION);
    }

    /**
     * getExportProductsReports.
     *
     * @return ExportProductsReports export products reports
     */
    private function getExportProductsReports()
    {
        return $this->exportProductsReports;
    }

    /**
     * initExportProductsReports.
     */
    private function initExportProductsReports()
    {
//        $this->exportProductsReports = oxNew('ExportProductsReports');
//        $this->exportProductsReports->setGeneralActions(array(ExportProductsReports::PRODUCTS_REPORTS_ACTION_UPDATE_PRODUCTS_LAST_UPDATE));
    }

    /**
     * isValid.
     *
     * Validates general xml product structure.
     *
     * @param \SimpleXMLElement $productsUpdateData products update data
     * @return boolean is valid products update data
     */
    private function isValid(\SimpleXMLElement $productsUpdateData)
    {
        $result			= true;
        $bfProductsId	= $this->getIntegerValue($productsUpdateData->ProductId);

        // first check variation structure
        if(true === empty($productsUpdateData->Variations) || true === empty($productsUpdateData->Variations->Variation))
        {
            $this->handleException('No Variations element found for products id: ' . $bfProductsId);
            $result = false;
        }
        return $result;
    }

    /**
     * handleVariationsData.
     *
     * @param \SimpleXMLElement $productsVariationsData products variations data
     */
    private function handleVariationsData(\SimpleXMLElement $productsVariationsData)
    {
        // products variations prices
        $this->handlePrices($productsVariationsData);

        // products variations unit data
        $this->handleUnitData($productsVariationsData);

        // products variations stock data
        $this->handleStockData($productsVariationsData);
    }

    /**
     * handleVariations.
     *
     * @param \SimpleXMLElement $productsUpdateData products update data
     */
    private function handleVariations(\SimpleXMLElement $productsUpdateData)
    {
        $parentArticleModel	= $this->getProductModel();
        $productsVariations = $productsUpdateData->Variations;
        $variationsStockSum	= 0;

        foreach($productsVariations->children() as $productsVariationsData)
        {
            $bfProductsVariationsId			= $this->getIntegerValue($productsVariationsData->VariationId);

            $productVariationMapping = $this->loadProductMapping($bfProductsVariationsId, Models\MappingModel::KEY_TYPE_PRODUCTS_VARIATIONS, Models\MappingModel::TABLE_FIELD_BFID);

            $productVariationModel = clone $this->_emptyProductModel;
            $productVariationModel->loadWithMappingModel($productVariationMapping);
            $this->setProductModel($productVariationModel);

            if(true === $this->getProductModel()->isLoaded())
            {
                // products variations status
                $this->handleStatus($productsVariationsData, 'VariationActive');

                $this->handleVariationsData($productsVariationsData);

                // save products variations
                $this->getProductModel()->save();

                $variationsStockSum += $this->getIntegerValue($this->getProductModel()->getArticleDataByKey('oxarticles__oxstock'));
            }
        }

        // save parent article changes
        $parentArticleModel->setArticleDataEntry('oxarticles__oxvarstock', $variationsStockSum);
        $parentArticleModel->save();

        unset($parentArticleModel);
    }

}