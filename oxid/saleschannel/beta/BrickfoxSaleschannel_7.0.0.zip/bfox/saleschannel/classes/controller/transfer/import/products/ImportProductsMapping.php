<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 19.02.19
 * Time: 15:55
 */

namespace bfox\saleschannel\classes\controller\transfer\import\products;

use bfox\saleschannel\classes\model as Models;

class ImportProductsMapping extends ImportProducts
{
    /**
     * @param \SimpleXMLElement $productsData products data
     */
    protected function processImport(\SimpleXMLElement $productsData)
    {
        $bfProductsId       = $this->getStringValue($productsData->ProductId);
        $bfExternProductsId = $this->getStringValue($productsData->ExternProductId);

        if ('' != $bfProductsId && '' != $bfExternProductsId) {
            $this->initProductModel();

            $this->getProductModel()->load($bfExternProductsId);

            if (true === $this->getProductModel()->isLoaded()) {
                // insert products mapping
                $this->insertMappingRecord($bfProductsId, $bfExternProductsId, Models\MappingModel::KEY_TYPE_PRODUCTS);

                // variations handling
                if (false === empty($productsData->Variations)) {
                    foreach ($productsData->Variations->children() as $productsVariationsData) {
                        $bfVariationsId       = $this->getStringValue($productsVariationsData->VariationId);
                        $bfExternVariationsId = $this->getStringValue($productsVariationsData->ExternVariationId);

                        if ('' != $bfVariationsId && '' != $bfExternVariationsId) {
                            $this->initProductModel();
                            $this->getProductModel()->load($bfExternVariationsId);

                            if (true === $this->getProductModel()->isLoaded()) {
                                // insert products variations mapping
                                $this->insertMappingRecord($bfVariationsId, $bfExternVariationsId, Models\MappingModel::KEY_TYPE_PRODUCTS_VARIATIONS);
                            } else {
                                $this->handleException('Product variation not found! Extern product id: ' . $bfExternProductsId . '. Extern products variations id: ' . $bfExternVariationsId);
                            }
                        } else {
                            $this->handleException('Invalid products variations id found! Extern product id: ' . $bfExternProductsId);
                        }
                    }
                }
            } else {
                $this->handleException('Product not found! Extern product id: ' . $bfExternProductsId);
            }
        } else {
            $this->handleException('Invalid products id found! Products id: ' . $bfProductsId . '. Extern products id: ' . $bfExternProductsId);
        }
    }

    /**
     * @param string $bfId bf id
     * @param string $systemId system id
     * @param string $type type
     */
    private function insertMappingRecord($bfId, $systemId, $type)
    {
        /** @var Models\MappingModel $mappingModel */
        $mappingModel = oxNew(Models\MappingModel::class);
        $mappingModel->loadByBfId($bfId, $type);

        // only insert entry to database in case that bf id doesn't exist there
        if (false === $mappingModel->isLoaded()) {
            $mappingModel->setBfId($bfId);
            $mappingModel->setSystemId($systemId);
            $mappingModel->setType($type);
            $mappingModel->save();
        }
    }
}