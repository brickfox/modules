<?php

/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 23.01.19
 * Time: 14:45
 */

namespace bfox\saleschannel\classes\controller\transfer\import\categories;

use bfox\saleschannel\classes\model as Models;
use bfox\saleschannel\classes\controller\transfer as Transfers;
use bfox\saleschannel\classes\util as Utils;
use \OxidEsales\Eshop as Oxid;

class ImportCategories extends Transfers\import\AbstractImport
{

    /** @var array */
    private $categoriesHierarchy = array();

    /** @var array */
    private $categoriesList = array();

    /** @var Models\MappingListModel */
    private $mappingListModel = null;

    /** @var int currentShopId Used for imports where several shops comes in a single XML */
    private $currentShopId = 0;

    /** @var Models\CategoryModel */
    private $_categoryModel = null;


    /**
     * ImportCategories constructor.
     * @param string $fileLocation
     * @param null $mappingModel
     * @param null $manufacturerModel
     */
    public function __construct($fileLocation, $mappingModel = null, $manufacturerModel = null)
    {
        parent::__construct($fileLocation, $mappingModel);

        if (is_null($manufacturerModel))
        {
            $this->_categoryModel = oxNew(Models\CategoryModel::class);
        }
        else
        {
            $this->_categoryModel = $manufacturerModel;
        }
    }

    /**
     */
    public function import()
    {
        $this->initMappingListModel();
        $this->initCategoriesList();

        parent::import();

        // delete/deactivate not listed categories
        $this->processNotTransmittedCategories();

        $this->updateCategoryTree();
    }

    /**
     * preImport
     */
    protected function preImport()
    {
        $this->currentShopId = Utils\OxidRegistry::getActiveShopId();
    }

    /**
     * postImport
     */
    protected function postImport()
    {
        Utils\OxidRegistry::setActiveShopId($this->currentShopId);
    }

    /**
     * @param \SimpleXMLElement $categoryData category data
     */
    protected function processImport(\SimpleXMLElement $categoryData)
    {
        $bfCategoryId = $this->getIntegerValue($categoryData->CategoryId);
        $bfParentId   = $this->getIntegerValue($categoryData->ParentId);

        if (0 < $bfCategoryId)
        {
            try
            {
                $this->prepareCategoriesHierarchy($bfParentId, $bfCategoryId);

                if (false === empty($categoryData->Translations))
                {
                    $shopId = $this->getCategoryShopId($categoryData);
                    Utils\OxidRegistry::setActiveShopId($shopId);

                    /** @var Models\CategoryModel $categoryModel */
                    $categoryModel   = clone $this->_categoryModel;
                    $categoryMapping = $this->getMappingListModel()->getMappingByKey($bfCategoryId, $shopId);


                    if (false === is_null($categoryMapping))
                    {
                        $categoryModel->load($categoryMapping->getSystemId());

                        if (false === $categoryModel->isLoaded())
                        {
                            $this->handleException('Couldn`t load Category. CategoriesId: ' . $bfCategoryId . ' shopid: ' . $shopId);
                        }

                        $this->removeFromCategoriesList($categoryMapping->getSystemId());
                    }
                    else
                    {
                        $categoryModel->initOxCategory();

                        $mappingModel = clone $this->_mappingModel;
                        $mappingModel->setBfId($bfCategoryId);
                        $mappingModel->setSystemId($categoryModel->getCategoryDataByKey('oxid'));
                        $mappingModel->setOxShopId(Utils\OxidRegistry::getActiveShopId());
                        $mappingModel->setType(Models\MappingModel::KEY_TYPE_CATEGORIES);
                        $mappingModel->save();

                        $this->getMappingListModel()->addMappingToMappingsList($bfCategoryId, $mappingModel);
                    }

                    $categoryModel->setCategoryDataEntry('oxcategories__oxsort', $this->getIntegerValue($categoryData->SortOrder));
                    $categoryModel->setCategoryDataEntry('oxcategories__oxrootid', $categoryModel->getCategoryDataByKey('oxid'));

                    if ($bfParentId > 0)
                    {
                        $categoryModel->setCategoryDataEntry('oxcategories__oxrootid', null);

                        $tempArray = explode('_', $this->categoriesHierarchy[$bfCategoryId]);
                        $bfRootId = array_shift($tempArray);

                        $rootMappingModel = $this->getMappingListModel()->getMappingByKey($bfRootId, $shopId);

                        if (false === is_null($rootMappingModel)) {
                            $categoryModel->setCategoryDataEntry('oxcategories__oxrootid', $rootMappingModel->getSystemId());
                        }
                    }

                    $categoryModel->setCategoryDataEntry('oxcategories__oxparentid', $this->getCategoryParentId($bfParentId));

                    foreach ($categoryData->Translations->children() as $translation)
                    {
                        $langCode = $this->getStringValue($translation['lang']);

                        if ('' != $langCode) {
                            if (true === $this->hasLanguageKey($langCode)) {
                                $languageData = $this->getLanguageByKey($langCode);
                                $languageId   = $languageData->id;

                                $categoryModel->setCategoryLanguageData(
                                    $languageId,
                                    'oxcategories__oxtitle',
                                    $this->getStringValue($translation->Name)
                                );

                                $categoryModel->setCategoryLanguageData(
                                    $languageId, 'oxcategories__oxactive',
                                    Transfers\AbstractTransfer::STATUS_ACTIVE_ID
                                );

                                $categoryModel->saveCategory();
                            }
                        } else {
                            $this->handleException('category title is invalid. CategoriesId: ' . $bfCategoryId);
                        }
                    }

                    // check and add default object2deliveries
                    $objectToDeliveryModel = oxNew(Models\ObjectToDeliveryModel::class);
                    $hasObjectToDeliveries = $objectToDeliveryModel->hasObjectToDeliveries($categoryModel->getId(),
                        Models\ObjectToDeliveryModel::OXTYPE_VALUE_CATEGORIES);

                    if ($hasObjectToDeliveries === false) {
                        $objectToDeliveryModel = oxNew(Models\ObjectToDeliveryModel::class);
                        $objectToDeliveryModel->saveDefaultCategoriesToDeliveries($categoryModel);
                    }

                    $this->logRowEntry('Category with category id:' . $bfCategoryId . ' imported!');
                } else {
                    $this->handleException('Translations are missing for manufacturer with categoriesId: ' . $bfCategoryId);
                }
            } catch (\Exception $exception) {
                $this->handleException('Error while importing category with categoriesId: ' . $bfCategoryId . '! Exception: ' . $exception);
            }
        } else {
            // ignore categories entry
            $this->handleException('Invalid category data. CategoriesId:' . $bfCategoryId);
        }
    }

    private function updateCategoryTree()
    {
        $sShopID       = $this->getShopModel()->getId();
        $blVerbose     = false;
        $oCategoryList = oxNew(Oxid\Application\Model\CategoryList::class);

        $oCategoryList->updateCategoryTree($blVerbose, $sShopID);
    }

    /**
     * @param int $bfParentId bf parent id
     * @param string $bfCategoryId bf category id
     * @return void
     */
    private function prepareCategoriesHierarchy($bfParentId, $bfCategoryId)
    {
        if (true === array_key_exists($bfParentId, $this->categoriesHierarchy)) {
            $this->categoriesHierarchy[$bfCategoryId] = $this->categoriesHierarchy[$bfParentId] . '_' . $bfCategoryId;
        } else {
            $this->categoriesHierarchy[$bfCategoryId] = $bfCategoryId;
        }
    }

    /**
     * @param integer $bfParentId bf parent id
     * @return string root category id
     */
    private function getCategoryParentId($bfParentId)
    {
        $returnValue = 'oxrootid';

        // check if root node
        if (0 < $bfParentId) {
            $parentMappingModel = $this->getMappingListModel()
                ->getMappingByKey($bfParentId, Utils\OxidRegistry::getActiveShopId());

            $returnValue        = null;

            if (!is_null($parentMappingModel)) {
                $returnValue = $parentMappingModel->getSystemId();
            }
        }

        return $returnValue;
    }


    /**
     * getCategoryShopId
     *
     * @param \SimpleXMLElement $categoryData - is one Category tag in the file,
     * if the XML have Categories for more than one shop (parent + child shops)
     * then the Category will contain a <Shops> tag, and the Category shop id
     * should be the one in that tag. If there is no tag then the shop id is the
     * current (active) one.
     *
     * @return integer oxshopid
     */
    private function getCategoryShopId(\SimpleXMLElement $categoryData)
    {
        $shopId = 1;

        if(false === empty($categoryData->Shops))
        {
            foreach($categoryData->Shops->children() as $shopData)
            {
                $shopStatus = $this->getIntegerValue($shopData->Status);

                if(Transfers\AbstractTransfer::STATUS_ACTIVE_ID == $shopStatus)
                {
                    $bfShopId   = $this->getStringValue($shopData['id']);
                    $bfShopIdToShopIdMapping   = $this->getShopModel()->getShopIdByBfShopId($bfShopId);

                    if(isset($bfShopIdToShopIdMapping))
                    {
                        $shopId = $bfShopIdToShopIdMapping;
                    }
                    break;
                }
            }

        }
        else
        {
            $shopId = Utils\OxidRegistry::getActiveShopId();
        }

        return $shopId;
    }

    /**
     */
    private function processNotTransmittedCategories()
    {
        if (sizeof($this->getCategoriesList()) > 0) {
            foreach ($this->getCategoriesList() as $categoryOxId) {
                $categoryModel = clone $this->_categoryModel;
                $categoryModel->load($categoryOxId);

                /** @var \stdClass $languagesData */
                $languagesData = Utils\OxidRegistry::getOxidLanguageArray();

                foreach ($languagesData as $languageData) {
                    $categoryModel->setCategoryLanguageData(
                        $languageData->id, 'oxcategories__oxactive',
                        Transfers\AbstractTransfer::STATUS_INACTIVE_ID
                    );
                    $categoryModel->saveCategory();
                }
            }
        }
    }

    /**
     * @return ImportCategories import categories
     */
    private function initCategoriesList()
    {
        $categoryListModel = oxNew(Models\CategoryListModel::class, Utils\OxidRegistry::getActiveShopId());
        $this->setCategoriesList($categoryListModel->getOxIdList(true));

        return $this;
    }

    /**
     * @return array categories list
     */
    private function getCategoriesList()
    {
        return $this->categoriesList;
    }

    /**
     * @param array $categoriesList categories list
     * @return ImportCategories import categories
     */
    private function setCategoriesList($categoriesList)
    {
        $this->categoriesList = $categoriesList;

        return $this;
    }

    /**
     * @param integer $oxid ox id
     * @return ImportCategories import categories
     */
    private function removeFromCategoriesList($oxid)
    {
        if (array_key_exists($oxid, $this->categoriesList)) {
            unset($this->categoriesList[$oxid]);
        }

        return $this;
    }

    /**
     */
    private function initMappingListModel()
    {
        /** @var Models\MappingListModel $mappingListModel */
        $mappingListModel = oxNew(Models\MappingListModel::class);
        $mappingListModel->loadMappingsModelList(Models\MappingModel::KEY_TYPE_CATEGORIES, Utils\OxidRegistry::getActiveShopId());

        $this->setMappingListModel($mappingListModel);
    }

    /**
     * @return Models\MappingListModel mapping list model
     */
    private function getMappingListModel()
    {
        return $this->mappingListModel;
    }

    /**
     * @param Models\MappingListModel $mappingListModel mapping list model
     */
    private function setMappingListModel(Models\MappingListModel $mappingListModel)
    {
        $this->mappingListModel = $mappingListModel;
    }

    public function deleteAll($deletionSetting)
    {
        $categoryListModel = new Oxid\Core\Model\ListModel();
        $categoryListModel->init($deletionSetting[0]["object"], $deletionSetting[0]["table"]);
        $categoryListModel->getList();

        foreach($categoryListModel->arrayKeys() as $categoryID)
        {
            $categoryModel   = clone $this->_categoryModel;
            $categoryModel->delete($categoryID);
        }
    }
}