<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 22.06.18
 * Time: 16:35
 */

namespace bfox\saleschannel\classes\controller;

    use bfox\saleschannel\classes\util as Utils;


class ApiRequestController
{
    /** @var Utils\ScriptManager $_scriptManager */
    private $_scriptManager = null;

    /** @var Transfer\TransferSettings $transferSettings */
    private $transferSettings = null;

    /**
     * @param $resource
     * @param $aParams
     * @return mixed
     */
    private function apiRequest($resource, $aParams)
    {
        $url = Utils\ConfigurationKeys::getInstance()->getConfig(Utils\ConfigurationKeys::CONFIG_KEY_BF_REST_API_URL);

        //Checks the trailing character in the url
        (substr($url, -1) === "/") ? : $url .= "/";

        $url .= $resource . '?' . implode("&", $aParams);

        $key = Utils\ConfigurationKeys::getInstance()->getConfig(Utils\ConfigurationKeys::CONFIG_KEY_BF_REST_API_KEY);

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'apiKey: '. $key
        ));

        $data = curl_exec($ch);

        if(!$data){
            Utils\LogManager::getInstance()->error('cURL Error: "' . curl_error($ch) . '" - Code: ' . curl_errno($ch));
        }

        curl_close($ch);

        return $data;
    }

    /**
     * @param $aMessage
     * @return mixed
     */
    public function validateMessageArray($aMessage){
        return $aMessage['success'];
    }

    /**
     * @param $aMessage
     * @return mixed
     */
    public function getCountMessageArray($aMessage){
        return $aMessage['totalCount'];
    }

    /**
     * @param $aMessage
     * @return mixed
     */
    public function getPagesMessageArray($aMessage){
        return $aMessage['pagesAvailable'];
    }

    public function getDataMessageArray($aMessage){
        return $aMessage['data'];
    }

    /**
     * @param $aMessage
     * @return mixed
     */
    public function getCurrentPageMessageArray($aMessage){
        return $aMessage['page'];
    }

    /**
     * @param $jsonMessage
     * @return bool|mixed
     */
    public function processJson($jsonMessage){

        $dataProcessed = json_decode($jsonMessage, true);

        if (json_last_error() === JSON_ERROR_NONE){
            return $dataProcessed;
        }
        else{
            return false;
        }
    }

    /**
     * @param $resource
     * @param $page
     * @param $lastRun
     * @return mixed
     */
    public function apiRequestListByLastUpdate ($resource, $page, $lastRun)
    {
        $aParams = array(
            'page='. $page,
            'filter=[{"property":"lastUpdate","value":"'.$lastRun.'","type":"greaterEqualThan"},{"property":"stockLocationsId","value":"1"}]',
            'sort=[{"property":"lastUpdate","direction":"ASC"}]',
        );

        return $this->apiRequest($resource, $aParams);
    }

    /**
     * @param $resource
     * @param $BfId
     * @return mixed
     */
    public function apiRequestByProductVariationId ($resource, $BfId)
    {
        $aParams = array(
            'filter=[{"property":"productsVariationsId","value":"'.$BfId.'","type":"greaterEqualThan"},{"property":"stockLocationsId","value":"1"}]',
            'sort=[{"property":"lastUpdate","direction":"DESC"}]',
        );

        return $this->apiRequest($resource, $aParams);
    }




    /**
     * importProductsUpdateBFApi.
     * update only the stock information for products using the Brickfox Rest API
     */
    public function importProductsUpdateBFApi()
    {
        $scriptLoggerManager	= $this->_scriptManager;

        /** @var  $importProductsUpdateSetting Transfer\TransferSettings*/
        $importProductsUpdateSetting = $this->transferSettings->getImportProductsUpdateBFApiSetting();
        $scriptLoggerManager->check($importProductsUpdateSetting->getPreparedScriptLoggerDependencies());
        $scriptLoggerManager->start($importProductsUpdateSetting->getName());

        $processingTime = date('Y-m-d H:i:s');
        $lastRun = Utils\LogManager::getInstance()->getLastRunDate(Utils\ConfigurationKeys::CONFIG_KEY_BF_REST_API_LAST_RUN);

        /** @var Imports\products\ImportProductsUpdateBFApi $importUpdateStockBFApi */
        $importUpdateStockBFApi = oxNew(Imports\products\ImportProductsUpdateBFApi::class);
        /** @var ApiRequestController $apiRequest */
        $apiRequest = oxNew(ApiRequestController::class);

        $pagesAvailable = 1;
        $nextPage = 1;

        do {

            $array_data =  false;

            $rest = $apiRequest->apiRequestListByLastUpdate(self::BFAPI_UPDATE_STOCK_CALL, $nextPage, $lastRun);
            $success = true;

            if ($rest){
                $array_data = $apiRequest->processJson($rest);
            }
            else{
                $this->handleException("Import Products Update : No data to proccess from request of REST service.");
                $success = false;
                break;
            }

            if (is_array($array_data)) {
                if (   $apiRequest->validateMessageArray($array_data) &&
                       $apiRequest->getCountMessageArray($array_data) > 0 )
                {
                    $pagesAvailable = $apiRequest->getPagesMessageArray($array_data);
                    $importUpdateStockBFApi->setImportData($apiRequest->getDataMessageArray($array_data));
                    $importUpdateStockBFApi->processImportData();

                    $nextPage = intval($apiRequest->getCurrentPageMessageArray($array_data)) + 1;
                }
                else
                {
                    echo 'the request returned no records';
                    $pagesAvailable = 0;
                }
            }
            else
            {
                $this->handleException("Import Products Update : Invalid json data.");
                $success = false;
                $pagesAvailable = 0;
            }
        } while ($nextPage <= $pagesAvailable);

        $processResults =  $importUpdateStockBFApi->getProcessedData();
        $importUpdateStockBFApi->resetProcessedData();

        Utils\LogManager::getInstance()->debug($processResults);

        if ($success){
            Utils\LogManager::getInstance()->setLastRunDate(Utils\ConfigurationKeys::CONFIG_KEY_BF_REST_API_LAST_RUN,
                                                                $processingTime);
        }

        $scriptLoggerManager->end();
    }



}