<?php

/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 21.01.19
 * Time: 17:22
 */
namespace bfox\saleschannel\classes\controller\transfer\import;

use bfox\saleschannel\classes\controller\transfer as Transfers;
use bfox\saleschannel\classes\exception as Exceptions;
use bfox\saleschannel\classes\model as Models;
use bfox\saleschannel\classes\util as Utils;

abstract class AbstractImport extends Transfers\AbstractTransfer
{
    /** @var array */
    private $languagesList = array();


    /**
     * @param \SimpleXMLElement $simpleXmlElementData simple xml element data
     */
    abstract protected function processImport(\SimpleXMLElement $simpleXmlElementData);

    /**
     * AbstractImport constructor.
     * @param $fileLocation
     * @param null $mappingModel
     */
    public function __construct($fileLocation, $mappingModel = null)
    {
        parent::__construct();

        if (is_null($mappingModel))
        {
            $this->_mappingModel = oxNew(Models\MappingModel::class);
        }
        else
        {
            $this->_mappingModel = $mappingModel;
        }

        $this->initLanguagesList();
        $this->setFileLocation($fileLocation);
    }

    /**
     * @throws \bfox\saleschannel\classes\exception\ConfigurationException
     */
    public function import()
    {
        $this->validateXml();

        /** @var \XMLReader $xmlReader */
        $xmlReader = oxNew(\XMLReader::class);
        $xmlReader->open($this->getFileLocation(), null, LIBXML_NOCDATA);

        $this->preImport();

        $domDocument = oxNew(\DomDocument::class);

        while (true === $xmlReader->read())
        {
//            if($xmlReader->depth === 0) {
//                $shopsId = $xmlReader->getAttribute('shopsId');
//
//                if ($shopsId > 0) {
//                    $shopsMappingConfig = $this->configManager->getConfig(Utils\ConfigManager::CONFIG_KEY_BF_SHOP_ID_TO_SHOP_ID_MAPPING);
//
//                    if (isset($shopsMappingConfig[$shopsId]) === true) {
//                        $shopsId = $shopsMappingConfig[$shopsId];
//                    }
//
//                    $this->setShopsId($shopsId);
//
//                    Utils\ConfigManager::getInstance()->setActiveShopId($shopsId);
//                }
//            }

            if (\XMLReader::ELEMENT == $xmlReader->nodeType && 1 == $xmlReader->depth) {
                $simpleXmlElement = simplexml_import_dom($domDocument->importNode($xmlReader->expand(), true));

                $this->processImport($simpleXmlElement);
            }
        }

        $xmlReader->close();

        $this->postImport();
    }

    /**
     * preImport
     */
    protected function preImport()
    {

    }

    /**
     * postImport
     */
    protected function postImport()
    {

    }

    /**
     */
    private function validateXml()
    {
        libxml_use_internal_errors(true);

        // read and validate xml file
        $xmlReader = oxNew(\XMLReader::class);
        $xmlReader->open($this->getFileLocation(), null, LIBXML_NOCDATA);

        while (true === $xmlReader->next()) {}

        $xmlReader->close();

        $errorMessage = '';

        foreach (libxml_get_errors() as $errorLine) {
            $errorMessage .= "\t" . $errorLine->message;
        }

        if ('' != $errorMessage) {
            throw oxNew(Exceptions\ImportExportException::class, 'No valid xml file! Reason: ' . $errorMessage, Exceptions\ImportExportException::INVALID_XML);
        }
    }

    /**
     * @param object $value
     * @return string value
     */
    protected function getStringValue($value)
    {
        $result = utf8_decode(utf8_encode(trim((string)$value)));

        return $result;
    }

    /**
     * @param object $value
     * @return float value
     */
    protected function getFloatValue($value)
    {
        return (float)trim($value);
    }

    /**
     * @param object $value
     * @return integer value
     */
    protected function getIntegerValue($value)
    {
        return (int)trim($value);
    }

    /**
     * @param object $value
     * @return boolean value
     */
    protected function getBooleanValue($value)
    {
        return (bool)trim($value);
    }

    /**
     * @param string $key key
     * @return mixed null/oxStdClass
     */
    protected function getLanguageByKey($key)
    {
        $returnValue = null;

        if (array_key_exists($key, $this->languagesList))
        {
            $returnValue = $this->languagesList[$key];
        }

        return $returnValue;
    }

    /**
     * @param string $key key
     * @return bool true/false
     */
    protected function hasLanguageKey($key)
    {
        return array_key_exists($key, $this->languagesList);
    }

    /**
     * @return array languages list
     */
    protected function getLanguagesList()
    {
        return $this->languagesList;
    }

    /**
     * @param string $languageCode language code
     * @return array language data
     */
    protected function getLanguageDataByLanguageCode($languageCode)
    {
        $result    = array();
        $languages = $this->getLanguagesList();

        if (true === array_key_exists($languageCode, $languages)) {
            $result = $languages[$languageCode];
        }

        return $result;
    }

    /**
     * @return AbstractImport
     */
    protected function initLanguagesList()
    {
        $languages = Utils\OxidRegistry::getOxidLanguageArray();

        if (is_array($languages) && sizeof($languages) > 0) {
            foreach ($languages as $language) {
                $this->languagesList[$language->oxid] = $language;
            }
        }

        return $this;
    }
}