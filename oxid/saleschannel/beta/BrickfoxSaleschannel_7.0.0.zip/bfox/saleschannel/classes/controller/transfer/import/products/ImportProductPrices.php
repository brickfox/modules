<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 05.02.19
 * Time: 15:52
 */

namespace bfox\saleschannel\classes\controller\transfer\import\products;

use bfox\saleschannel\classes\util as Utils;


class ImportProductPrices extends ImportProducts
{
    /**
     * ImportProductPrices constructor.
     * @param $fileLocation
     * @param null $mappingModel
     * @param null $productModel
     */
    public function __construct($fileLocation, $mappingModel = null, $productModel = null)
    {
        $this->_currentProductModel = $productModel;
        parent::__construct($fileLocation, $mappingModel, null);
    }

    /**
     * @param $productsVariationsData
     */
    public function processPricesImport($productsVariationsData)
    {

        if(true === $this->getProductModel()->isShopArticle())
        {
            $this->handleShopPrices($productsVariationsData);
        }
        else if(false === $this->getShopModel()->isSuperShop())
        {
            $this->handleChildShopPrices($productsVariationsData);
        }
        else
        {
            Utils\LogManager::getInstance()->debug("The check for Shop conditions failed when handling Prices, Oxid:" . $this->getProductModel()->getFieldData('oxid'));
        }
    }

    /**
     * @return mixed ProductModel or false
     */
    public function returnProcessedProductModel()
    {
        if(true === $this->getProductModel()->isLoaded())
        {
            return $this->getProductModel();
        }

        return false;
    }

    /**
     * @param \SimpleXMLElement $productsVariationsData product variations data
     */
    protected function handlePrices(\SimpleXMLElement $productsVariationsData)
    {
        if(true === $this->getProductModel()->isShopArticle())
        {
            $this->handleShopPrices($productsVariationsData);
        }
        else if(false === $this->getShopModel()->isSuperShop())
        {
            $this->handleChildShopPrices($productsVariationsData);
        }
        else
        {
            Utils\LogManager::getInstance()->debug("The check for Shop conditions failed when handling Prices, Oxid:" . $this->getProductModel()->getFieldData('oxid'));
        }
    }

    /**
     * handleShopPrices
     *
     * @param \SimpleXMLElement $productsVariationsData products variations data
     */
    private function handleShopPrices(\SimpleXMLElement $productsVariationsData)
    {
        $productsVariationsId = $this->getIntegerValue($productsVariationsData->VariationId);

        // buying price
        $cost	= $this->getFloatValue($productsVariationsData->PrimeCost);
        if('' != $cost)
        {
            $this->getProductModel()->setArticleDataEntry('oxarticles__oxbprice', $cost);
        }

        if(false === empty($productsVariationsData->Currencies))
        {
            foreach($productsVariationsData->Currencies->children() as $currencyData)
            {
                if(true === isset($currencyData['code']) && 0 < strlen($this->getStringValue($currencyData['code'])))
                {
                    $currencyCode = $this->getStringValue($currencyData['code']);

                    // price gross
                    $priceGrossField    = $this->getPriceStorageField(
                        Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_PRICE_GROSS_STORAGE_MAPPING),
                        $currencyCode
                    );

                    $priceGross	        = $this->getFloatValue($currencyData->PriceGross);
                    if('' != $priceGrossField && 0 < $priceGross)
                    {
                        $this->getProductModel()->setArticleDataEntry($priceGrossField, $priceGross);

                        // // recommended retail price
                        $this->handleShopRrpPrice($currencyData);

                        // scale prices
                        $this->handleShopScalePrices($currencyData, $productsVariationsId);

                        // special price
                        $this->handleShopSpecialPrice($currencyData, $productsVariationsData);
                    }
                    else
                    {
                        $this->handleException('Invalid prices or mapping found for products variations id: ' . $productsVariationsId);
                    }
                }
                else
                {
                    $this->handleException('Invalid currency code found for products variations id: ' . $productsVariationsId);
                }
            }
        }
        else
        {
            $this->handleException('No Currencies defined for products variations id: ' . $productsVariationsId);
        }

    }

    /**
     * handleChildShopPrices
     *
     * @param \SimpleXMLElement $productsVariationsData products variations data
     */
    private function handleChildShopPrices(\SimpleXMLElement $productsVariationsData)
    {
        $productsVariationsId = $this->getIntegerValue($productsVariationsData->VariationId);

        if(false === empty($productsVariationsData->Currencies))
        {
            foreach($productsVariationsData->Currencies->children() as $currencyData)
            {
                if(true === isset($currencyData['code']) && 0 < strlen($this->getStringValue($currencyData['code'])))
                {
                    $currencyCode = $this->getStringValue($currencyData['code']);

                    // price gross
                    $priceGrossField    = $this->getPriceStorageField(
                        Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_PRICE_GROSS_STORAGE_MAPPING),
                        $currencyCode
                    );

                    $priceGross	        = $this->getFloatValue($currencyData->PriceGross);
                    if('' != $priceGrossField && 0 < $priceGross)
                    {
                        $this->getProductModel()->addArticleFieldToShopData($priceGrossField, $priceGross);

                        // special price
                        $this->handleChildShopSpecialPrice($currencyData, $productsVariationsData);
                    }
                }
                else
                {
                    $this->handleException('Invalid prices or mapping found for products variations id: ' . $productsVariationsId);
                }
            }
        }
        else
        {
            $this->handleException('No Currencies defined for products variations id: ' . $productsVariationsId);
        }
    }

    /**
     * handleShopScalePrices.
     *
     * @param \SimpleXMLElement $currencyData currency data
     * @param int $productsVariationsId products variations id
     */
    private function handleShopScalePrices(\SimpleXMLElement $currencyData, $productsVariationsId)
    {
        $mainCurrency = $this->getBooleanValue($currencyData['mainCurrency']);

        if(true === $mainCurrency && false === empty($currencyData->ScalePrices))
        {
            foreach($currencyData->ScalePrices->children() as $scalePriceData)
            {
                $quantity		= $this->getFloatValue($scalePriceData->Quantity);
                $price			= $this->getFloatValue($scalePriceData->Price);
                $percentage		= $this->getFloatValue($scalePriceData->Percentage);

                if(0 < $quantity && 0 < $price)
                {
                    $this->getProductModel()->addArticleScalePriceData($price, $quantity, $percentage);
                }
                else
                {
                    $this->handleException('Invalid scale price data found for products variations id: ' . $productsVariationsId);
                }
            }
        }
    }

    /**
     * handleShopRrpPrice,
     *
     * @param \SimpleXMLElement $currencyData currency data
     */
    private function handleShopRrpPrice(\SimpleXMLElement $currencyData)
    {
        $mainCurrency = $this->getBooleanValue($currencyData['mainCurrency']);

        if(true === $mainCurrency)
        {
            $rrp	= $this->getFloatValue($currencyData->Rrp);
            $this->getProductModel()->setArticleDataEntry('oxarticles__oxtprice', $rrp);
        }
    }

    /**
     * handleShopSpecialPrice.
     *
     * @param \SimpleXMLElement $currencyData currency data
     * @param \SimpleXMLElement $productsVariationsData products variations data
     */
    private function handleShopSpecialPrice(\SimpleXMLElement $currencyData, \SimpleXMLElement $productsVariationsData)
    {
        $mainCurrency           = $this->getBooleanValue($currencyData['mainCurrency']);

        if(true === $mainCurrency)
        {
            $specialPriceField      = $this->getPriceStorageField(
                Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_SPECIAL_PRICE_STORAGE_MAPPING),
                $this->getStringValue($currencyData['code'])
            );
            if('' != $specialPriceField)
            {
                $specialPrice	        = $this->getSpecialPrice($currencyData, $productsVariationsData);

                if($specialPrice > 0) {
                    $this->getProductModel()->setArticleDataEntry($specialPriceField, $specialPrice);
                }
            }
            else
            {
                $this->handleException('Invalid special prices mapping found for products variations id: ' . $this->getIntegerValue($productsVariationsData->VariationId));
            }
        }
    }

    /**
     * handleChildShopSpecialPrice.
     *
     * @param \SimpleXMLElement $currencyData currency data
     * @param \SimpleXMLElement $productsVariationsData products variations data
     */
    private function handleChildShopSpecialPrice(\SimpleXMLElement $currencyData, $productsVariationsData)
    {
        $mainCurrency           = $this->getBooleanValue($currencyData['mainCurrency']);

        if(true === $mainCurrency)
        {
            $specialPriceField      = $this->getPriceStorageField(Utils\OxidRegistry::getModuleConfig(
                Utils\ConfigurationKeys::CONFIG_KEY_SPECIAL_PRICE_STORAGE_MAPPING),
                $this->getStringValue($currencyData['code'])
            );
            if('' != $specialPriceField)
            {
                $specialPrice	        = $this->getSpecialPrice($currencyData, $productsVariationsData);
                if($specialPrice > 0) {
                    $this->getProductModel()->addArticleFieldToShopData($specialPriceField, $specialPrice);
                }
            }
            else
            {
                $this->handleException('Invalid special prices mapping found for products variations id: ' . $this->getIntegerValue($productsVariationsData->VariationId));
            }
        }
    }

    /**
     * getPriceStorageField
     *
     * @param array $mappingData mapping data
     * @param string $currencyCode currency code
     * @return string price gross field
     */
    private function getPriceStorageField($mappingData, $currencyCode)
    {
        $priceField    = '';

        if(true === array_key_exists($currencyCode, $mappingData))
        {
            $priceField = strtolower($mappingData[$currencyCode]);
        }

        return $priceField;
    }

    /**
     * getSpecialPrice.
     *
     * @param \SimpleXMLElement $currencyData currency data
     * @param \SimpleXMLElement $productsVariationsData products variations data
     * @return string active special price
     */
    private function getSpecialPrice(\SimpleXMLElement $currencyData, \SimpleXMLElement $productsVariationsData)
    {
        $specialPrice	= $this->getFloatValue($currencyData->SpecialPrice);

        // has special price node
        if(0 < $specialPrice)
        {
            $currentTimestamp	        = strtotime('now');
            $specialPriceStart	        = $this->getStringValue($currencyData->SpecialPriceStart);
            $specialPriceEnd	        = $this->getStringValue($currencyData->SpecialPriceEnd);
            $specialPriceStockThreshold = $this->getIntegerValue($currencyData->SpecialPriceStockThreshold);
            $stock                      = $this->getIntegerValue($productsVariationsData->Stock);

            if('' != $specialPriceStart)
            {
                $startTimestamp = strtotime($specialPriceStart);

                if($startTimestamp > $currentTimestamp)
                {
                    $specialPrice			= 0.0;
                }
            }

            if('' != $specialPriceEnd)
            {
                $endTimestamp = strtotime($specialPriceEnd);

                if($currentTimestamp > $endTimestamp)
                {
                    $specialPrice			= 0.0;
                }
            }

            if($specialPriceStockThreshold > 0 && $specialPriceStockThreshold >= $stock)
            {
                $specialPrice			= 0.0;
            }

        }
        return $specialPrice;
    }

}