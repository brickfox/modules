<?php
/**
 * ProductSeoController.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2019 brickfox GmbH http://www.brickfox.de
 */

namespace bfox\saleschannel\classes\controller;

use bfox\saleschannel\classes\model\MappingModel;
use bfox\saleschannel\classes\model as Models;
use bfox\saleschannel\classes\util as Utils;

use \OxidEsales\Eshop as Oxid;

/**
 * @package bfox\saleschannel\classes\controller
 */
class ProductSeoController
{
    /** @var int */
    private $brickfoxId;

    /**
     * @param int $shopId
     * @param int $brickfoxId
     */
    public function __construct($shopId, $brickfoxId)
    {
        Utils\OxidRegistry::setActiveShopId($shopId);

        $this->brickfoxId = $brickfoxId;
    }

    /**
     */
    public function redirect()
    {
        $redirectUrl = $this->getRedirectUrl();

        if (strlen($redirectUrl) > 0) {
            header("Location: $redirectUrl", true, 301);

            exit();
        }
    }

    /**
     * @return string
     */
    private function getRedirectUrl()
    {
        $redirectUrl = '';

        /** @var MappingModel $mappingModel */
        $mappingModel = oxNew(MappingModel::class);
        $mappingModel->loadByBfId($this->brickfoxId, MappingModel::KEY_TYPE_PRODUCTS_VARIATIONS);

        /** @var \bfox\saleschannel\classes\model\ShopModel $shopModel */
        $shopModel = oxNew(Models\ShopModel::class);
        $shopModel->load(Utils\OxidRegistry::getActiveShopId());

        if ($mappingModel->isLoaded() && $shopModel->isLoaded()) {
            $shopUrl = $shopModel->getFieldData('oxurl');

            if (strpos($shopUrl, 'http') === false) {
                $shopUrl = 'https://' . $shopUrl;
            }

            /** @var \bfox\saleschannel\classes\model\ProductModel $productModel */
            $productModel = oxNew(Models\ProductModel::class);
            $productModel->load($mappingModel->getSystemId());

            if ($productModel->isLoaded()) {
                $seoEncoder  = oxNew(Oxid\Application\Model\SeoEncoderArticle::class);
                $redirectUrl = $shopUrl . DIRECTORY_SEPARATOR . $seoEncoder->getArticleUri($productModel, Utils\OxidRegistry::getDefaultLanguageId());
            }
        }

        return $redirectUrl;
    }
}