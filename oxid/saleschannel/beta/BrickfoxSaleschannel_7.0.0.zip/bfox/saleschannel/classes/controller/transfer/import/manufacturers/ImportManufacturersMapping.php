<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 19.02.19
 * Time: 15:52
 */

namespace bfox\saleschannel\classes\controller\transfer\import\manufacturers;

use bfox\saleschannel\classes\model as Models;
use bfox\saleschannel\classes\controller\transfer as Transfers;

class ImportManufacturersMapping extends Transfers\import\AbstractImport
{
    /**
     * processImport.
     *
     * @param \SimpleXMLElement $manufacturersData
     */
    protected function processImport(\SimpleXMLElement $manufacturersData)
    {
        $bfManufacturerId			= $this->getIntegerValue($manufacturersData->ManufacturerId);
        $bfExternManufacturerId		= $this->getStringValue($manufacturersData->ExternManufacturerId);

        if($bfManufacturerId != '' && $bfExternManufacturerId != '')
        {
            $ManufacturerModel = oxNew(Models\ManufacturerModel::class);
            $ManufacturerModel->load($bfExternManufacturerId);

            if($ManufacturerModel->isLoaded())
            {
                // insert manufacturers mapping
                $this->insertMappingRecord($bfManufacturerId, $bfExternManufacturerId);
            }
            else
            {
                $this->handleException('Manufacturer not found! Extern manufacturer id: ' . $bfExternManufacturerId);
            }
        }
        else
        {
            $this->handleException('Invalid manufacturers id found! Extern manufacturers id: ' . $bfExternManufacturerId);
        }
    }

    /**
     * insertMappingRecord.
     *
     * @param string $bfId
     * @param string $systemId
     */
    private function insertMappingRecord($bfId, $systemId)
    {
        $mappingModel = oxNew(Models\MappingModel::class);
        $mappingModel->loadByBfId($bfId, Models\MappingModel::KEY_TYPE_MANUFACTURERS);

        // only insert entry to database in case that bf id doesn't exist there
        if(false === $mappingModel->isLoaded())
        {
            $mappingModel->setBfId($bfId);
            $mappingModel->setSystemId($systemId);
            $mappingModel->setType(Models\MappingModel::KEY_TYPE_MANUFACTURERS);
            $mappingModel->save();
        }
    }
}