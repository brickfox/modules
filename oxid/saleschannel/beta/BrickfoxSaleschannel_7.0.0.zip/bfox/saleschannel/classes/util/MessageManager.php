<?php
/**
 * NotifierManager
 *

 *
 */


  namespace bfox\saleschannel\classes\util;

  use bfox\saleschannel\classes\model as Models;
  use bfox\saleschannel\classes\util as Utils;


class MessageManager
{
	/*****************************************************************************
	 *
	 * Class properties
	 *
	 *****************************************************************************/

	/**
	 * notification required
	 * @var boolean
	 */
	private $notificationRequired = null;

	/**
	 * notifier model
	 * @var Models\MessageModel
	 */
	private $notifierModel = null;


	/*****************************************************************************
	 *
	 * Callable functions
	 *
	 *****************************************************************************/

	/**
	 * Constructor.
	 */
	public function __construct()
	{
		$this->initNotifierModel();
	}

	/**
	 * isNotificationRequired.
	 *
	 * @return boolean is notification required
	 */
	public function isNotificationRequired()
	{
		return $this->notificationRequired;
	}

	/**
	 * setNotificationRequired.
	 *
	 * @param boolean $notificationRequired notification required
	 */
	public function setNotificationRequired($notificationRequired)
	{
		$this->notificationRequired = $notificationRequired;
	}

	/**
	 * notify.
	 *
	 * @param string $notifierMessage notifier message
	 */
	public function notify($notifierMessage = null)
	{
		if(true === $this->isNotificationRequired())
		{

			$this->setNotificationRequired(false);
			$this->notifierModel->isHtml(true);

			$this->notifierModel->setSubject(OxidRegistry::getModuleConfig(ConfigurationKeys::CONFIG_KEY_NOTIFIER_SUBJECT));
			$this->notifierModel->setRecipient(OxidRegistry::getModuleConfig(ConfigurationKeys::CONFIG_KEY_NOTIFIER_RECEIVER_EMAIL));
			$this->notifierModel->setFrom(OxidRegistry::getModuleConfig(ConfigurationKeys::CONFIG_KEY_NOTIFIER_SENDER_EMAIL), OxidRegistry::getModuleConfig(ConfigurationKeys::CONFIG_KEY_NOTIFIER_SENDER_NAME));
			$this->notifierModel->setReplyTo(OxidRegistry::getModuleConfig(ConfigurationKeys::CONFIG_KEY_NOTIFIER_SENDER_EMAIL), OxidRegistry::getModuleConfig(ConfigurationKeys::CONFIG_KEY_NOTIFIER_SENDER_NAME));

			$notifierMessage	= false === is_null($notifierMessage) ? $notifierMessage : $this->getDefaultNotificationMessage();
			$this->notifierModel->setBody($notifierMessage);
			$this->notifierModel->send();
		}
	}

	/*****************************************************************************
	 *
	 * helper functions
	 *
	 *****************************************************************************/

	/**
	 * initNotifierModel.
	 */
	private function initNotifierModel()
	{
		$this->notifierModel = oxNew(Models\MessageModel::class);
	}

    /**
    * getDefaultNotificationMessage.
    *
    * @return string default notification message
    */
    private function getDefaultNotificationMessage()
    {
        $logFileLocation = LogManager::getInstance()->getLogFileLocation();
        $result = sprintf(
            'Please check log file: %s for further information!',
            $logFileLocation
        );

        $appendLogfileLines = OxidRegistry::getModuleConfig(ConfigurationKeys::CONFIG_KEY_NOTIFIER_APPEND_LOGFILE_LINES);

        if(0 < $appendLogfileLines && true === is_numeric($appendLogfileLines))
        {
            $result				.= '<br /><br />Last ' . $appendLogfileLines . ' log file lines:<br />';
            $logFilePointer     = fopen($logFileLocation, 'r');

            $index              = 0;
            $logLines           = array();

            while(($line = fgets($logFilePointer)))
            {
                $logLines[$index]   = $line;
                $index              = ($index + 1) % $appendLogfileLines;
            }
            $result .= implode('<br />', array_merge(array_slice($logLines, $index), array_slice($logLines, 0, $index)));
            fclose($logFilePointer);
        }

        return $result;
    }

}