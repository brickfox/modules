<?php
/**
 * ConfigManager
 */

namespace bfox\saleschannel\classes\util;


class ConfigurationKeys
{
    const
        //logging
        CONFIG_KEY_LOGGING_FILENAME									= 'sLogFilename',
        CONFIG_KEY_LOGGING_CLEANUP_IN_DAYS							= 'sLogCleanupInDays',
        CONFIG_KEY_LOGGING_LEVEL									= 'sLogLevelBF',

        // email
        CONFIG_KEY_NOTIFIER_SUBJECT									= 'sNotifierSubject',
        CONFIG_KEY_NOTIFIER_RECEIVER_EMAIL							= 'sNotifierReceiverEmail',
        CONFIG_KEY_NOTIFIER_SENDER_EMAIL							= 'sNotifierSenderEmail',
        CONFIG_KEY_NOTIFIER_SENDER_NAME								= 'sNotifierSenderName',
        CONFIG_KEY_NOTIFIER_APPEND_LOGFILE_LINES					= 'sNotifierAppendLogfileLines',

        // storage
        CONFIG_KEY_STORAGE_DIRECTORY								= 'sStorageDirectory',
        CONFIG_KEY_STORAGE_FILENAME_ORDERS							= 'sStorageFilenameOrders',
        CONFIG_KEY_STORAGE_FILENAME_PRODUCTS_REPORTS				= 'sStorageFilenameProductsReports',
        CONFIG_KEY_STORAGE_FILENAME_ORDERSSTATUS					= 'sStorageFilenameOrdersStatus',
        CONFIG_KEY_STORAGE_FILENAME_MANUFACTURERS					= 'sStorageFilenameManufacturers',
        CONFIG_KEY_STORAGE_FILENAME_CATEGORIES						= 'sStorageFilenameCategories',
        CONFIG_KEY_STORAGE_FILENAME_PRODUCTS						= 'sStorageFilenameProducts',
        CONFIG_KEY_STORAGE_FILENAME_PRODUCTS_UPDATE					= 'sStorageFilenameProductsUpdate',
        CONFIG_KEY_STORAGE_FILENAME_PRODUCTS_ASSIGNMENTS			= 'sStorageFilenameProductsAssign',
        CONFIG_KEY_STORAGE_FILENAME_PRODUCTSMAPPING					= 'sStorageFilenameProductsMap',
        CONFIG_KEY_STORAGE_FILENAME_CATEGORIESMAPPING				= 'sStorageFilenameCategoriesMap',
        CONFIG_KEY_STORAGE_FILENAME_MANUFACTURERSMAPPING			= 'sStorageFilenameManufacturersMap',

        // scriptLogger
        CONFIG_KEY_SL_CLEANUP_HANGING_IN_SECONDS					= 'sScriptLoggerCleanupDBHanging',
        CONFIG_KEY_SL_CLEANUP_REMOVAL_IN_DAYS						= 'sScriptLoggerCleanupDBRemoval',

        // tax
        CONFIG_KEY_TAX_REDUCED										= 'sTaxReduced',

        // mailings
        CONFIG_KEY_MAILINGS_SHIPPING_CONFIRMATION					= 'bSendShippingConfirmationMail',

        // delivery to category matching
        CONFIG_KEY_DEFAULT_DELIVERY_TO_CATEGORIES_MATCHING			= 'sDefaultDelToCatMatching',

        // bf attributes
        CONFIG_KEY_BF_ATTRIBUTES_TO_ARTICLE_MAPPING					= 'aBfAttributesToArticleMapping',

        // prices
        CONFIG_KEY_PRICE_GROSS_STORAGE_MAPPING                      = 'aPriceGrossStorageMapping',
        CONFIG_KEY_SPECIAL_PRICE_STORAGE_MAPPING                    = 'aSpecialPriceStorageMapping',

        // products reports
        CONFIG_KEY_PRODUCTS_REPORTS_ACTIVATION                      = 'bProductsReportsActivation',

        // shops
        CONFIG_KEY_BF_SHOP_ID_TO_SHOP_ID_MAPPING                    = 'aBfShopIdToShopIdMapping',
        CONFIG_KEY_LOOP_SHOPS_OVERRIDE_DEFAULT                      = 'blnOverrideShopsLoopDefault',
        CONFIG_KEY_LOOP_SHOPS_ID_VALUES                             = 'aShopsToLoop',

        // categories
        CONFIG_KEY_IMPORT_PRIMARY_CATEGORIES                        = 'bImportPrimaryCategories',
        CONFIG_KEY_IMPORT_SECONDARY_CATEGORIES                      = 'bImportSecondaryCategories',

        // orders
        CONFIG_KEY_OVERWRITE_CUST_NR                                = 'sOverwriteCustNr',
        CONFIG_KEY_EXPORT_BIRTHDATE                                 = 'bExportBirthdate',
        CONFIG_KEY_EXPORT_TARGETGROUP                               = 'bExportTargetgroup',
        CONFIG_KEY_ORDER_STATUS_UPDATE_STOCKS                       = 'blUpdateStockOnCanceledOrders',


        //payments
        CONFIG_KEY_PAYMENT_CLASS_MAPPING                              = 'aaPaymentClassMapping',

        // Import / Export settings
        CONFIG_KEY_IMPORTEXPORT_MANUFACTURERS_ACTION                  = 'selImportManufacturerAction',
        CONFIG_KEY_IMPORTEXPORT_MANUFACTURERS_DELETE_VALUE            = 'Delete',

        // brickfox api
        CONFIG_KEY_BF_REST_API_URL                                    = 'sBfRestApiUrl',
        CONFIG_KEY_BF_REST_API_KEY                                    = 'sBfRestApiKey',
        CONFIG_KEY_BF_REST_API_LAST_RUN                               = 'sBfRestApiLastRun',

        // media
        CONFIG_KEY_USE_MEDIA_UPLOAD                                   = 'bUseMediaUpload';


}