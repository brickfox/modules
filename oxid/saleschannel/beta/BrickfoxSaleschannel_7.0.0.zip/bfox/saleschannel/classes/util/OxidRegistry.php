<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 07.01.19
 * Time: 17:09
 */

namespace bfox\saleschannel\classes\util;

use bfox\saleschannel\classes\exception as Exceptions;
use \OxidEsales\Eshop as Oxid;
use OxidEsales\EshopCommunity\Core\Di\ContainerFacade;
use OxidEsales\EshopCommunity\Internal\Framework\Module\Facade\ModuleSettingServiceInterface;


class OxidRegistry
{

    /**
     * #####################
     *  STATIC METHODS
     * #####################
     */

    /**
     * @return integer default language id
     */
    public static function getDefaultLanguageId()
    {
        return Oxid\Core\Registry::getConfig()->getConfigParam('sDefaultLang');
    }


    /**
     * @return array default language id
     */
    public static function getOxidLanguageArray()
    {
        return Oxid\Core\Registry::getLang()->getLanguageArray();
    }

    public static function setBaseLanguage($languageOxidId)
    {
        return Oxid\Core\Registry::getLang()->setBaseLanguage($languageOxidId);
    }

    /**
     * @return string shop directory
     */
    public static function getShopDirectory()
    {
        return Oxid\Core\Registry::getConfig()->getConfigParam('sShopDir');
    }

    /**
     * @return string shop url
     */
    public static function getShopURL()
    {
        return Oxid\Core\Registry::getConfig()->getConfigParam('sShopURL');
    }

    public static function getLogsDir()
    {
        return Oxid\Core\Registry::getConfig()->getLogsDir();
    }

    /**
     * @return int shopId
     */
    public static function getActiveShopId()
    {
        return Oxid\Core\Registry::getConfig()->getShopId();
    }


    /**
     * @param int $oxshopid
     *
     */
    public static function setActiveShopId($oxshopid)
    {
        Oxid\Core\Registry::getSession()->initNewSession();
        Oxid\Core\Registry::getConfig()->setShopId($oxshopid);

        Oxid\Core\Registry::getSession()->setVariable("shp", $oxshopid);
        Oxid\Core\Registry::getSession()->setVariable("actshop", $oxshopid);
        Oxid\Core\Registry::getSession()->setVariable('currentadminshop', $oxshopid);

        /**
         * This works to reload the Config values when switching shops...
         * Currently we cant make it to the Languages (for each shop)
         */
        #Oxid\Core\Registry::getConfig()->reinitialize();
    }


    public static function getOxidConfig($configKey)
    {
        $result = Oxid\Core\Registry::getConfig()->getConfigParam($configKey);

        if (true === is_null($result)) {
            throw oxNew(Exceptions\ConfigurationException::class, 'Invalid configuration key: ' . $configKey . ' for shop id: ' . self::getActiveShopId());
        }

        return $result;
    }

    /**
     * @param string $configKey configuration key
     * @param string $moduleName module name
     * @return mixed configuration value
     * @throws Exceptions\ConfigurationException configuration exception
     */
    public static function getModuleConfig($configKey, $moduleName = 'saleschannel')
    {
        $settingType = self::getSettingType($moduleName, $configKey);
        $moduleSettingService = ContainerFacade::get(ModuleSettingServiceInterface::class);

        $result = match ($settingType) {
            'bool' => $moduleSettingService->getBoolean($configKey, $moduleName),
            'aarr', 'array', 'arr' => $moduleSettingService->getCollection($configKey, $moduleName),
            'int' => $moduleSettingService->getInteger($configKey, $moduleName),
            default => $moduleSettingService->getString($configKey, $moduleName)->toString(),
        };

        if (true === is_null($result)) {
            echo PHP_EOL . oxNew(Exceptions\ConfigurationException::class, 'Invalid configuration key: ' . $configKey . ' for shop id: ' . self::getActiveShopId()) . PHP_EOL;
        }

        return $result;
    }

    /**
     * @param string $configKey configuration key
     * @param mixed $configValue configuration value
     * @param string $configType config type
     * @param string $moduleName module name
     */
    public static function saveModuleConfig($configKey, $configValue, $configType, $moduleName = 'saleschannel')
    {
        $moduleSettingService = ContainerFacade::get(ModuleSettingServiceInterface::class);
        $moduleSettingService->saveString($configKey, $configValue, $moduleName);
    }


    public static function getMultishopArticleFields()
    {
        return Oxid\Core\Registry::getConfig()->getConfigParam('aMultishopArticleFields');
    }

    private static function getSettingType(string $moduleId, string $configKey)
    {
        // Gehe 3 Ebenen nach oben von `classes/util/` zu `modules/bfox/saleschannel/`
        $metadataPath = realpath(__DIR__ . '/../../metadata.php');

        if (!$metadataPath || !file_exists($metadataPath)) {
            throw new \RuntimeException("metadata.php not found for module: $moduleId");
        }

        // aModule wird durch include gesetzt
        $aModule = [];
        include $metadataPath;

        $settingTypes = [];

        if (!empty($aModule['settings']) && is_array($aModule['settings'])) {
            foreach ($aModule['settings'] as $setting) {
                $name = $setting['name'] ?? null;
                $type = $setting['type'] ?? 'str';
                if ($name) {
                    $settingTypes[$name] = $type;
                }
            }
        }

        return $settingTypes[$configKey] ?? 'str';
    }



}
