<?php
/**
 * Class FileManager
 */

namespace bfox\saleschannel\classes\util;

use bfox\saleschannel\classes\model as Models;

class FileManager
{
    const FILENAME_DELIMITER = '_';



    public function __construct()
    {
    }

    /**
     * generateFilename.
     *
     * @param string $filenameBase file name base
     * @return string full file name
     */
    public static function generateFilename($filenameBase)
    {
        return $filenameBase . '_' . date('Ymd_His') . '.xml';
    }

    /**
     * @param array $importFilenameBases
     * @return array
     * @throws \bfox\saleschannel\classes\exception\ConfigurationException
     */
    public function getImportFiles($importFilenameBases)
    {
        $result           = array();
        $exchangeXMLFiles = $this->getExchangeXMLFiles();


        if (true === is_array($exchangeXMLFiles))
        {
            foreach ($exchangeXMLFiles as $exchangeXMLFile)
            {
                $exchangeXMLFilename = pathinfo($exchangeXMLFile, PATHINFO_FILENAME);
                list($exchangeXMLFilenameBase, $exchangeXMLFilenameCreation) = explode(self::FILENAME_DELIMITER, $exchangeXMLFilename, 2);

                foreach ($importFilenameBases as $importFilenameBase)
                {
                    if ($exchangeXMLFilenameBase == $importFilenameBase)
                    {
                        $useFile = true;

                        // more than one files found, so compare dates and use oldest
                        if (true === isset($result[$importFilenameBase]))
                        {
                            $exchangeXMLFileCreationDate = $this->getTimestamp($exchangeXMLFilenameCreation);
                            $exchangeXMLFilenameCompare  = pathinfo($result[$importFilenameBase], PATHINFO_FILENAME);
                            list(, $exchangeXMLFilenameCreationCompare) = explode(self::FILENAME_DELIMITER, $exchangeXMLFilenameCompare, 2);
                            $exchangeXMLFileCreationDateCompare = $this->getTimestamp($exchangeXMLFilenameCreationCompare);

                            $useFile = $exchangeXMLFileCreationDate < $exchangeXMLFileCreationDateCompare ? true : false;
                        }

                        if (true === $useFile)
                        {
                            $result[$importFilenameBase] = $exchangeXMLFile;
                        }

                        break;
                    }
                }
            }
        }

        return $result;
    }

    /**
     * @param string $filename
     * @return string
     * @throws \bfox\saleschannel\classes\exception\ConfigurationException
     */
    public function createExportFile($filename)
    {
        $fileLocation = $this->getExchangeShopDirectoryLocation() . $filename;
        $fileHandle   = fopen($fileLocation, 'w');

        fclose($fileHandle);

        return $fileLocation;
    }

    /**
     * @param string $oldFilename
     * @param string $newFilename
     * @throws \bfox\saleschannel\classes\exception\ConfigurationException
     */
    public function renameExportFile($oldFilename, $newFilename)
    {
        $oldFileLocation = $this->getExchangeShopDirectoryLocation() . $oldFilename;
        $newFileLocation = $this->getExchangeShopDirectoryLocation() . $newFilename;

        if (true === file_exists($oldFileLocation)) {
            rename($oldFileLocation, $newFileLocation);
        }
    }

    /**
     * @param string $fileLocation file location
     */
    public function deleteImportFile($fileLocation)
    {
        if (true === file_exists($fileLocation)) {
            unlink($fileLocation);
        }
    }

    /**
     * @return array
     * @throws \bfox\saleschannel\classes\exception\ConfigurationException
     */
    private function getExchangeXMLFiles()
    {
        $exchangeDirectoryLocation = $this->getExchangeShopDirectoryLocation();

        return glob($exchangeDirectoryLocation . '*.xml');
    }

    /**
     * @return string
     * @throws \bfox\saleschannel\classes\exception\ConfigurationException
     */
    private function getExchangeDirectoryLocation()
    {
        $exchangeDirectory = $this->getExchangeDirectory();

        if(DIRECTORY_SEPARATOR == substr($exchangeDirectory, 0, 1))
        {
            $exchangeDirectory =  substr($exchangeDirectory, 1);
        }

        // oxid will deliver a shop dir path with a trailing "/"
        $exchangeDirectoryLocation  = OxidRegistry::getShopDirectory() . $exchangeDirectory;

        if(DIRECTORY_SEPARATOR != substr($exchangeDirectoryLocation, -1))
        {
            $exchangeDirectoryLocation .= DIRECTORY_SEPARATOR;
        }

        return $exchangeDirectoryLocation;
    }


    /**
     * getExchangeShopDirectoryLocation.
     * @return string exchange shop directory location
     */
    private function getExchangeShopDirectoryLocation()
    {
        $exchangeShopDirectoryLocation  = $this->getExchangeDirectoryLocation();
        $exchangeShopDirectory          = $this->getExchangeShopDirectory();

        if(false === is_null($exchangeShopDirectory) && 0 < strlen($exchangeShopDirectory))
        {
            $exchangeShopDirectoryLocation .=  $exchangeShopDirectory . DIRECTORY_SEPARATOR;
        }

        return $exchangeShopDirectoryLocation;
    }

    /**
     * @return int
     */
    private function getExchangeShopDirectory()
    {
        return OxidRegistry::getActiveShopId();
    }

    /**
     * @param  string $shp Oxid shop Id to be used (no loop through all)
     * @return array
     * @throws \bfox\saleschannel\classes\exception\ConfigurationException
     */
    public function getValidExchangeSubdirectories($shp = null)
    {
        $validExchangeSubdirectories = [];

        if ($shp === null)
        {
            $changeDefault = OxidRegistry::getModuleConfig(ConfigurationKeys::CONFIG_KEY_LOOP_SHOPS_OVERRIDE_DEFAULT);

            if ($changeDefault === false)
            {
                $shopListModel = oxNew(Models\ShopListModel::class);
                $shopListModel->loadShopList();

                foreach ($shopListModel as $oxShop) {
                    $oxShopId = $oxShop->getId();
                    $exchangeShopDirectoryLocation = $this->getExchangeDirectoryLocation() . $oxShopId;

                    if (true === file_exists($exchangeShopDirectoryLocation)) {
                        $validExchangeSubdirectories[$oxShopId] = $oxShopId;
                    }
                }
            }
            else
            {
                $aShops = OxidRegistry::getModuleConfig(ConfigurationKeys::CONFIG_KEY_LOOP_SHOPS_ID_VALUES);
                $shopsIds = explode(',', $aShops[0]);

                foreach ($shopsIds as $oxShopId) {
                    $exchangeShopDirectoryLocation = $this->getExchangeDirectoryLocation() . $oxShopId;

                    if (true === file_exists($exchangeShopDirectoryLocation)) {
                        $validExchangeSubdirectories[$oxShopId] = $oxShopId;
                    }
                }
            }
        }
        else
        {
            array_push($validExchangeSubdirectories, $shp);
        }

        return $validExchangeSubdirectories;
    }

    /**
     * getExchangeDirectory.
     *
     * @return string exchange directory
     */
    private function getExchangeDirectory()
    {
        return OxidRegistry::getModuleConfig(ConfigurationKeys::CONFIG_KEY_STORAGE_DIRECTORY);
    }


    /**
     * IF PHP version 5.2.6 is in use, it's not possible to use:
     * DateTime::createFromFormat('Ymd_His', $timestampString)
     *
     * @param string $timestampString timestamp string
     * @return integer timestamp
     */
    private function getTimestamp($timestampString)
    {
        // check if there's "_1" appended, add 1 second to timestamp to force
        // correct order
        $iAdd = 0;
        $iLength = strlen($timestampString);
        if ($iLength == 17 && substr($timestampString, $iLength - 2) == "_1") {
            $timestampString = substr($timestampString, 0, 15);
            $iAdd = 1;
        }

        // try to parse string as date time object
        $oDateTime = \DateTime::createFromFormat("Ymd_His", $timestampString);
        if ($oDateTime) {
            return intval($oDateTime->format("U")) + $iAdd;
        }

        return 0;
    }
}
