<?php
/**
 * migration
 *

 *
 */


  namespace bfox\saleschannel\classes;

  use bfox\saleschannel\classes\controller as Controllers;



// load oxid framework
require_once '../bootstrap.php';

$validActions	= array('productsMapping', 'categoriesMapping');
$action			= \OxidEsales\Eshop\Core\Registry::getRequest()->getRequestParameter('action');

if(true === isset($action) && '' != $action && true === in_array($action, $validActions))
{
	$importExportAction = '';
	switch($action)
	{
		case 'productsMapping':
			$importExportAction = 'importProductsMapping';
			break;

		case 'categoriesMapping':
			$importExportAction = 'importCategoriesMapping';
			break;
	}

	if('' != $importExportAction)
	{
		$controller = oxNew(Controllers\TransferController::class);
		$controller->{$importExportAction}();
	}
}
