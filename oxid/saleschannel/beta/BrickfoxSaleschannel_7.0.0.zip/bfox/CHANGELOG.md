## Changelog

### 7.0.0

- Update getModule Config to new Config System
- Replace getConfig with getRequest
- Update method with updated version
