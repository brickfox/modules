<?php
/**
 * execute.php - the entry point
 *
 */

    namespace bfox\saleschannel;

    use bfox\saleschannel\classes\controller as Controllers;
    use bfox\saleschannel\classes\util as Utils;

    use \OxidEsales\Eshop as Oxid;

    #ini_set('max_execution_time', 300);

    callOxidBootstrap();

    checkOutputDebug();

    /**
     * Parameter sent by Querystring with requested action to perform
     */
    $action			= Oxid\Core\Registry::getConfig()->getRequestParameter('action');

    /**
     * Array of valid actions to call
     * Keep the delete actions commented out for production
     */
    $validActions	= array(
        'categories',
        'manufacturers',
        'ordersStatus', 'orders',
        'products', 'productsUpdate',
        ### 'deleteAttributes', 'deleteCategories', 'deleteManufacturers','deleteProducts',
        'categoriesMapping', 'manufacturersMapping', 'productsMapping',
        'showVersion'
    );

    start($action, $validActions);


    /**
     * @param string $action Taken from query string request
     * @param array $validActions
     */
    function start($action, $validActions){
        if(true === isset($action) && '' != $action && true === in_array($action, $validActions))
        {
            $importExportAction = '';
            switch($action)
            {
                case 'ordersStatus':
                    $importExportAction = 'importOrdersStatus';
                    break;

                case 'orders':
                    $importExportAction = 'exportOrders';
                    break;

                case 'deleteAttributes':
                    $importExportAction = 'deleteAllAttributes';
                    break;

                case 'categories':
                    $importExportAction = 'importCategories';
                    break;

                case 'categoriesMapping':
                    $importExportAction = 'importCategoriesMapping';
                    break;

                case 'deleteCategories':
                    $importExportAction = 'deleteAllCategories';
                    break;

                case 'manufacturers':
                    $importExportAction = 'importManufacturers';
                    break;

                case 'manufacturersMapping':
                    $importExportAction = 'importManufacturersMapping';
                    break;

                case 'deleteManufacturers':
                    $importExportAction = 'deleteAllManufacturers';
                    break;

                case 'products':
                    $importExportAction = 'importProducts';
                    break;

                case 'productsMapping':
                    $importExportAction = 'importProductsMapping';
                    break;

                case 'deleteProducts':
                    $importExportAction = 'deleteAllProducts';
                    break;

                case 'productsUpdate':
                    $importExportAction = 'importProductsUpdate';
                    break;

                case 'productsUpdateApi':
                    $importExportAction = 'importProductsUpdateBFApi';
                    break;


                case 'showVersion':
                    outputVersionInfo();
                    break;
            }

            callRequestedAction($importExportAction);
        }
    }



    /**
     * Calls the Oxid bootstrap file to load all the Oxid framework and its contents
     */
    function callOxidBootstrap(){
        $dir = dirname(__FILE__);
        $pathArray = explode("modules", $dir);
        $bootstrapPath = array_shift($pathArray);
        require_once $bootstrapPath . 'bootstrap.php';
    }


    /**
     *  Use the debug_mode for Exceptions and Errors description.
     *  Here we change how to handle exceptions as for PHP 7 they are Errors instances.
     */
    function checkOutputDebug()
    {
        $debug_mode		= Oxid\Core\Registry::getConfig()->getRequestParameter('debug_mode');

        if(true === isset($debug_mode) && $debug_mode === 'j')
        {
            echo "<h2>debug function ON</h2>";

            set_exception_handler(
                [
                    new classes\exception\ExceptionHandler(),
                    'handleUncaughtException'
                ]
            );

            set_error_handler(
                [
                    new classes\exception\ExceptionHandler(),
                    'handleUncaughtError'
                ]
            );
        }
    }


    /**
     * @param $importExportAction string Name of the method that should be called by the controller
     */
    function callRequestedAction($importExportAction)
    {
        if('' != $importExportAction)
        {
            $controller = oxNew(Controllers\TransferController::class);
            $controller->{$importExportAction}();
        }
    }


    /**
     * Return information about the Oxid version Installed and some of its features
     */
    function outputVersionInfo()
    {
        echo "<h2>Brickfox plugin for Oxid e-sales</h2>";
        echo "<h3>Oxid details:</h3>";

        $config = oxNew(Utils\OxidCompatibility::class);

        echo "LogFileLocation " . Utils\LogManager::getInstance()->getLogFileLocation();
        echo "<br>";
        Utils\LogManager::getInstance()->debug("outputVersionInfo");
        echo "Version: " . $config->getVersionDescription();
        echo "<br>";
        echo "Multiple Shops support: ";
        echo $config->getSupportShops() ? "true" : "false";
        echo "<br>";
        echo "Singleton (getInstance method) support: ";
        echo $config->getSupportGetInstance() ? "true" : "false";
        echo "<br>";

        echo phpinfo() . " <br>";
    }
