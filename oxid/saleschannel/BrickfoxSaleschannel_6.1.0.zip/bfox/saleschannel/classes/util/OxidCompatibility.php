<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 24.08.17
 * Time: 12:27
 *
 * Class to provide control for the functionalities and compatibilities to groups of oxid versions
 * to check for more look at https://oxidforge.org/en/source-code-documentation-overview
 */


  namespace bfox\saleschannel\classes\util;

  use \OxidEsales\Eshop as Oxid;


class OxidCompatibility
{
    /**
     *   Class Properties
     */

    private $supportGetInstance     = true;

    private $supportShops           = true;

    private $versionDescription;


    /**
     *   Class Methods
     */
    public function __construct()
    {

        $config = oxNew(Oxid\Core\Config::class);

        $version    = $config->getVersion ();
        $edition    = $config->getEdition ();

        $this->versionDescription = $version . $edition;

        /**
         * All checks for EE and PE
         */
        if ($edition === 'EE' || $edition === 'PE'){


            if (version_compare($version, '5.0.0', '>='))
            {
                $this->supportGetInstance = false;
            }
        }

        /**
         * All checks for CE
         */
        if ($edition === 'CE'){

            $this->supportShops = false;

            if (version_compare($version, '4.7.0', '>='))
            {
                $this->supportGetInstance = false;
            }
        }

    }


    /**
     *   Class getters and setters
     */

    public function getVersionDescription(){
        return $this->versionDescription;
    }

    public function getSupportShops(){
        return $this->supportShops;
    }

    public function getSupportGetInstance(){
        return $this->supportGetInstance;
    }

}