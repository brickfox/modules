<?php
/**
 * ImportExportException
 *

 *
 */


  namespace bfox\saleschannel\classes\exception;


class ImportExportException extends \Exception
{

	/**
	 * exception codes
	 */
	const GENERAL							= 1,
		  NO_XML_ELEMENTS					= 2,
		  INVALID_XML						= 3,
		  SCRIPT_RUNNING					= 4;

}