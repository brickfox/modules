<?php
/**
 * ConfigurationException
 *
 *
 */


  namespace bfox\saleschannel\classes\exception;


class ConfigurationException extends \Exception
{
}
