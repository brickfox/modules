<?php
/**
 * PaymentKlarna
 *

 *
 */


namespace bfox\saleschannel\classes\payment;


class PaymentKlarna extends AbstractPayment
{
	/**
	 * getPaymentMethodValues
	 *
	 * @return array payment method values
	 */
	public function getPaymentMethodValues()
	{
		$result							= array();

		$oxOrderModel					= $this->getOxOrderModel();

		// pclass
		$result['pClass']				= $oxOrderModel->getFieldData('klpclassid');

		// personal number
		$result['personalNumber']		= $this->getBirthdate() . $this->getSalutationId();

		// eid
		$result['eId']					= $oxOrderModel->getFieldData('tcklarna_orderid');

		// reservation number
		$result['reservationNumber']	= $oxOrderModel->getFieldData('klinvoiceno');

		// order status
		$result['orderStatus']			= $oxOrderModel->getFieldData('klstatus');

		return $result;
	}

	/*****************************************************************************
	 *
	 * helper functions
	 *
	 **************************************************************************** */

	/**
	* getBirthdate.
	*
	* @return string birthdate
	*/
	private function getBirthdate()
	{
		$result							= '';
		$oxPaymentType					= $this->getOxOrderModel()->getFieldData('oxpaymenttype');
		$additionalPaymentData			= $this->getAdditionalPaymentData();

		$yearKey						= $oxPaymentType . '_byear';
		$monthKey						= $oxPaymentType . '_bmonth';
		$dayKey							= $oxPaymentType . '_bday';

		if(true === array_key_exists($yearKey, $additionalPaymentData) && true === array_key_exists($monthKey, $additionalPaymentData) && true === array_key_exists($dayKey, $additionalPaymentData))
		{
			$result = date('dmY', strtotime($additionalPaymentData[$yearKey] . '-' . $additionalPaymentData[$monthKey] . '-' . $additionalPaymentData[$dayKey]));
		}

		return $result;
	}

	/**
	* getSalutationId.
	*
	* @return string salutation id
	*/
	private function getSalutationId()
	{
		$result				= '0';
		$validSalutations	= array('mr', 'herr');
		$salutation			= $this->getOxOrderModel()->getFieldData('oxbillsal');

		if(false === is_null($salutation) && true === in_array(strtolower($salutation), $validSalutations))
		{
			$result = '1';
		}

		return $result;
	}
}