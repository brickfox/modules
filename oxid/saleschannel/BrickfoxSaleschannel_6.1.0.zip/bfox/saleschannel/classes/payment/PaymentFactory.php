<?php
/**
 * PaymentFactory
 *
 */


namespace bfox\saleschannel\classes\payment;

 use bfox\saleschannel\classes\model as Models;
 use bfox\saleschannel\classes\util\ConfigurationKeys;
 use bfox\saleschannel\classes\util\OxidRegistry;


 class PaymentFactory
{

    /**
     * create.
     *
     * @param string $paymentMethod payment method
     * @param Models\OrderModel $oxOrderModel ox order model
     * @return IPayment payment model
     */
    public static function create($paymentMethod, Models\OrderModel $oxOrderModel)
    {
        $paymentModelConfiguration = self::getPaymentModelConfiguration($paymentMethod);

        $className =  __NAMESPACE__ . '\\' . $paymentModelConfiguration[$paymentMethod];

        return new $className($oxOrderModel);
    }



    /**
     * getPaymentModelConfiguration.
     *
     * @param string $paymentMethod payment method
     * @return array payment model configuration
     */
    private static function getPaymentModelConfiguration($paymentMethod)
    {
        $result                     = null;

        $paymentModelsConfiguration = OxidRegistry::getModuleConfig(ConfigurationKeys::CONFIG_KEY_PAYMENT_CLASS_MAPPING);

        if (count($paymentModelsConfiguration) === 0)
        {
            $paymentModelsConfiguration = array(
                'oxidbarzahlen'             => 'PaymentBarzahlen',
                'oxidcashondel'             => 'PaymentStandard',
                'oxidcreditcard'            => 'PaymentHeidelpay',
                'oxiddebitnote'             => 'PaymentBanktransfer',
                'oxidinvoice'               => 'PaymentStandard',
                'oxidpayadvance'            => 'PaymentStandard',
                'oxidpaypal'                => 'PaymentPaypal',
                'standard'                  => 'PaymentStandard',
            );
        }

        if(true === array_key_exists($paymentMethod, $paymentModelsConfiguration))
        {
            $result = [$paymentMethod => $paymentModelsConfiguration[$paymentMethod]];
        }
        else
        {
            $result = [$paymentMethod => $paymentModelsConfiguration['standard']];
        }

        return $result;
    }

}