<?php
/**
 * PaymentHeidelpay
 *
 *
 */


namespace bfox\saleschannel\classes\payment;


class PaymentHeidelpay extends AbstractPayment
{
	/*****************************************************************************
	 *
	 * Callable functions
	 *
	 *****************************************************************************/

	/**
	 * getPaymentMethodValues
	 *
	 * @return array payment method values
	 */
	public function getPaymentMethodValues()
	{
        $result							= array();

        $oxOrderModel					= $this->getOxOrderModel();
        $oxPayId						= $oxOrderModel->getFieldData('oxpayid');
        $oxTransId						= $oxOrderModel->getFieldData('oxtransid');
        $nfcCcExpiry					= $oxOrderModel->getFieldData('nfcccexpiry');
        $nfcCcBrand						= $oxOrderModel->getFieldData('nfcccbrand');
        $oxXId		    				= $oxOrderModel->getFieldData('oxxid');

        if(false === is_null($oxPayId) && '' != $oxPayId)
        {
            $result['cardAuthorization'] = $oxPayId;
        }

        if(false === is_null($oxTransId) && '' != $oxTransId)
        {
            $result['transactionId'] = $oxTransId;
        }

        if(false === is_null($nfcCcExpiry) && '' != $nfcCcExpiry)
        {
            $result['CCExpiry'] = $nfcCcExpiry;
        }

        if(false === is_null($nfcCcBrand) && '' != $nfcCcBrand)
        {
            #$result['CCBrand'] = $nfcCcBrand;

            $nfcCcBrandArray = explode('||', $nfcCcBrand);
            $result['CCBrand'] = $nfcCcBrandArray[0];
            $result['PCNr'] = $nfcCcBrandArray[1];

        }

        if(false === is_null($oxXId) && '' != $oxXId)
        {
            $result['shortId'] = $oxXId;
        }

        return $result;
	}
}