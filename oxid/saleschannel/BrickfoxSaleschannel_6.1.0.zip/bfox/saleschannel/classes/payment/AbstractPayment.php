<?php
/**
 * AbstractPayment
 *
 * @author Benjamin Steiner <benjamin.steiner@brickfox.de>
 * @abstract
 *
 * Last commit information:
 *
 */


namespace bfox\saleschannel\classes\payment;

  use bfox\saleschannel\classes\exception as Exceptions;
  use \OxidEsales\Eshop as Oxid;


abstract class AbstractPayment implements IPayment
{
	/*****************************************************************************
	 *
	 * Class properties
	 *
	 *****************************************************************************/

	/**
	 * ox order model
	 *
	 * @var Oxid\Application\Model\Order
	 */
	private $oxOrderModel = null;

	/*****************************************************************************
	 *
	 * Callable functions
	 *
	 *****************************************************************************/

	/**
	 * Constructor.
	 *
	 * @param Oxid\Application\Model\Order  $oxOrderModel ox order model
	 */
	public function __construct(Oxid\Application\Model\Order $oxOrderModel)
	{
		$this->setOxOrderModel($oxOrderModel);
	}

	/**
	 * getOxOrderModel.
	 *
	 * @return Oxid\Application\Model\Order  ox order model
	 */
	protected function getOxOrderModel()
	{
		return $this->oxOrderModel;
	}

	/**
	 * setOxOrderModel.
	 *
	 * @param Oxid\Application\Model\Order  $oxOrderModel ox order model
	 */
	protected function setOxOrderModel(Oxid\Application\Model\Order $oxOrderModel)
	{
		$this->oxOrderModel = $oxOrderModel;
	}

	/**
	 * getAdditionalPaymentData.
	 *
	 * @return array additional payment data
	 */
	protected function getAdditionalPaymentData()
	{
		$result			= array();
		$oxPaymentId	= $this->getOxOrderModel()->getFieldData('oxpaymentid');

		if(false === is_null($oxPaymentId) && '' != $oxPaymentId)
		{
			$oxUserPaymentModel = oxNew(Oxid\Application\Model\UserPayment::class);
			$oxUserPaymentModel->load($oxPaymentId);

			$oxUserPaymentsValue = $oxUserPaymentModel->getFieldData('oxvalue');

			if(false === is_null($oxUserPaymentsValue) && '' != $oxUserPaymentsValue)
			{
				$additionalPaymentData = Oxid\Core\Registry::getUtils()->assignValuesFromText($oxUserPaymentsValue);

				foreach($additionalPaymentData as $oxStandardModel)
				{
					$result[$oxStandardModel->name] = $oxStandardModel->value;
				}
			}
		}
		else
		{
			throw oxNew(Exceptions\ImportExportException::class,
                'Invalid user payment id! Ox order id: ' . $this->getOxOrderModel()->getId(),
                Exceptions\ImportExportException::GENERAL);
		}
		return $result;
	}
}