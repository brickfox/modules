<?php
/**
 * PaymentPaypal
 *

 *
 */


namespace bfox\saleschannel\classes\payment;


class PaymentPaypal extends AbstractPayment
{
    /*****************************************************************************
    *
    * Callable functions
    *
    *****************************************************************************/

    /**
    * getPaymentMethodValues
    *
    * @return array payment method values
    */
    public function getPaymentMethodValues()
    {
        $result							= array();

        $oxOrderModel					= $this->getOxOrderModel();
        $oxTransactionId				= $oxOrderModel->getFieldData('oxtransid');

        if(false === is_null($oxTransactionId) && '' != $oxTransactionId)
        {
            $result['transactionId'] = $oxTransactionId;
        }

        return $result;
    }
}