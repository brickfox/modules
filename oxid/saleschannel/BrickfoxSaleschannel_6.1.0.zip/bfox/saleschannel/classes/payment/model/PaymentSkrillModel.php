<?php

/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 27.02.19
 * Time: 13:17
 */

namespace bfox\saleschannel\classes\payment\model;

use bfox\saleschannel\classes\model\oxid as OxidModels;

class PaymentSkrillModel extends OxidModels\BaseModel
{
    /**
     * Constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->init('d3object2mb');
    }

    /**
     * loadByPaymentIdAndShopId.
     *
     * @param string $paymentId payment id
     * @param string $shopId shop id
     * @return boolean is loaded
     */
    public function loadByPaymentIdAndShopId($paymentId, $shopId)
    {
        $sSelect = $this->buildSelectString(
            array(
                $this->getViewName().'.oxpaymentid' => $paymentId,
                $this->getViewName().'.oxshopId' => $shopId,
            )
        );

        return $this->_isLoaded = $this->assignRecord($sSelect);
    }
}