<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 23.01.19
 * Time: 15:45
 */

namespace bfox\saleschannel\classes\model;

use \OxidEsales\Eshop as Oxid;

class CategoryListModel extends \OxidEsales\Eshop\Application\Model\CategoryList
{
    /**
     *  ox shop id
     * @var integer
     */
    private $oxShopId = null;


    public function __construct($oxShopId = 0)
    {
        parent::__construct();
        $this->setOxShopId($oxShopId);
    }

    /**
     * getOxIdList
     *
     * @param boolean $blReverse
     * @return array ox id list
     */
    public function getOxIdList($blReverse = false)
    {
        $returnValue	= array();
        $sViewName		= $this->getBaseObject()->getViewName();
        $sFieldList		= 'OXID as oxid';
        $sOrdDir		= $blReverse ? 'DESC' : 'ASC';

        $query = sprintf('SELECT %s FROM %s ORDER BY oxrootid %s , oxleft %s;',
            $sFieldList,
            $sViewName,
            $sOrdDir,
            $sOrdDir
        );

        $dB = Oxid\Core\DatabaseProvider::getDb();
        $dB->setFetchMode(Oxid\Core\Database\Adapter\DatabaseInterface::FETCH_MODE_ASSOC);

        $resultSet = $dB->select($query);

        if ($resultSet != false && $resultSet->count() > 0)
        {
            while (!$resultSet->EOF) {
                $row = $resultSet->getFields();
                $returnValue[$row['oxid']] = $row['oxid'];
                $resultSet->fetchRow();
            }
        }
        return $returnValue;
    }

    /**
     * loadCategoryAssignments.
     *
     * @param string $oxArticleId ox article id
     * @param ObjectToCategoryModel $objectToCategoryModel
     */
    public function loadCategoryAssignments($oxArticleId, $objectToCategoryModel)
    {
        if('' != $oxArticleId)
        {
            $viewNameGenerator = Oxid\Core\Registry::get(Oxid\Core\TableViewNameGenerator::class);

            //Check if object have oxshopid field
            if ($objectToCategoryModel->checkForFieldInTable('oxshopid') === true){
                $sqlStatement			= sprintf(
                    'SELECT * FROM %s WHERE OXOBJECTID = \'%s\' AND OXSHOPID = \'%s\';',
                    $viewNameGenerator->getViewName('oxobject2category'),
                    $oxArticleId,
                    $this->getOxShopId()
                );
            }
            else{
                $sqlStatement			= sprintf(
                    'SELECT * FROM %s WHERE OXOBJECTID = \'%s\';',
                    $viewNameGenerator->getViewName('oxobject2category'),
                    $oxArticleId
                );
            }

            $this->selectString($sqlStatement);
        }
    }

    /**
     * setOxShopId.
     *
     * @param integer $oxShopId ox shopid
     */
    private function setOxShopId($oxShopId)
    {
        $this->oxShopId = $oxShopId;
    }

    /**
     * getOxShopId.
     *
     * @return integer ox shopid
     */
    private function getOxShopId()
    {
        return $this->oxShopId;
    }

}