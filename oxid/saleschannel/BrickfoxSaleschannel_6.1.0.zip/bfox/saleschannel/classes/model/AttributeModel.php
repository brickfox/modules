<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 08.02.19
 * Time: 19:08
 */


  namespace bfox\saleschannel\classes\model;

  use \OxidEsales\Eshop as Oxid;


  class AttributeModel extends Oxid\Application\Model\Attribute
  {
      /*****************************************************************************
       *
       * Class properties
       *
       *****************************************************************************/

      /**
       * attributes
       * @var array
       */
      private static $attributes = null;

      /**
       * attribute code
       */
      private $attributeCode = null;


      /*****************************************************************************
       *
       * Callable functions
       *
       *****************************************************************************/

      /**
       * getAttributes.
       *
       * @param int $oxShopId ox shopId
       * @return array attributes
       */
      public static function getAttributes($oxShopId)
      {
          $result = array();

          if(true === is_null(self::$attributes) || false === array_key_exists($oxShopId, self::$attributes))
          {
              if(true === is_null(self::$attributes))
              {
                  self::$attributes = array();
              }

              /** @var AttributeListModel $attributeListModel */
              $attributeListModel = oxNew(AttributeListModel::class);
              $attributeListModel->loadAttributesList();

              foreach($attributeListModel as $attributeModel)
              {
                  $result[$attributeModel->oxattribute__oxtitle->getRawValue()]
                      = $attributeModel->oxattribute__oxid->getRawValue();
              }
              self::$attributes = $result;
          }
          else
          {
              $result = self::$attributes[$oxShopId];
          }

          return $result;
      }

      /**
       * save.
       */
      public function save($generatedId = null)
      {
          $title = $this->getTitle();

          if(false === is_null($title) && '' != $title)
          {
              $isNewAttribute = false;
              $oxid			= $this->_sOXID;

              if(true === is_null($oxid))
              {
                  $oxid			= $generatedId;
                  $isNewAttribute = true;
              }

              $this->assign(
                  array(
                      'oxattribute__oxid'			=> $oxid,
                      'oxattribute__oxtitle'		=> $title,
                      'oxattribute__oxshopid'		=> $this->getShopId(),
                  )
              );

              $attributeCode = $this->getAttributeCode();
              if(false === is_null($attributeCode) && 0 < strlen($attributeCode))
              {
                  $attributeData['oxattribute__bfattributecode'] = $attributeCode;
              }

              $this->assign($attributeData);

              parent::save();

              if(true === $isNewAttribute)
              {
                  self::updateAttributes($oxid, $title, $this->getShopId());
              }
          }
      }


      /**
       * setAttributeCode.
       *
       * @param string $attributeCode attribute code
       */
      public function setAttributeCode($attributeCode)
      {
          $this->attributeCode = $attributeCode;
      }

      /**
       * getAttributeCode.
       *
       * @@return string attribute code
       */
      public function getAttributeCode()
      {
          return $this->attributeCode;
      }


      /*****************************************************************************
       *
       * helper functions
       *
       *****************************************************************************/

      /**
       * updateAttributes.
       *
       * @param string $oxid oxid
       * @param string $oxTitle ox title
       * @param int $oxShopId ox shopId
       */
      private static function updateAttributes($oxid, $oxTitle, $oxShopId)
      {
          if(false === is_null(self::$attributes))
          {
              self::$attributes[$oxShopId][$oxTitle] = $oxid;
          }
      }

  }
