<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 07.01.19
 * Time: 21:14
 */

namespace bfox\saleschannel\classes\model\oxid;

use bfox\saleschannel\classes\util as Utils;


class BaseModel extends \OxidEsales\Eshop\Core\Model\BaseModel
{
    public function __construct()
    {
        parent::__construct();

        $this->setShopId(Utils\OxidRegistry::getActiveShopId());
    }

    public function checkForFieldInTable($fieldName)
    {
        if (in_array($fieldName,$this->getFieldNames()))
        {
            return true;
        }
        return false;
    }

}
