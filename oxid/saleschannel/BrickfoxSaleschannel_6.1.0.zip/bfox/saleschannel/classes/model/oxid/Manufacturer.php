<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 23.01.19
 * Time: 10:11
 */

namespace bfox\saleschannel\classes\model\oxid;


use bfox\saleschannel\classes\model\MappingModel;

/**
 * Class Manufacturer
 * @package bfox\saleschannel\classes\model\oxid
 *
 *  This class extends the Manufacturer class in oxid in a way that changes teh behaviour
 *for oxid, but also for all plugins installed in that oxid.
 *  The intention here is to coordinate the deletion of the mapping whenever a Manufacturer
 *is deleted in oxid (even in the GUI)
 */

class Manufacturer extends Manufacturer_parent
{
    /**
     * @param null $sOXID
     * @return bool
     */
    public function delete($sOXID = null)
    {
        if (parent::delete($sOXID))
        {
            $this->deleteManufacturerMapping($sOXID);

            return true;
        }

        return false;
    }
    

    /**
     * @param $oxid
     */
    private function deleteManufacturerMapping($oxid)
    {
        /** @var MappingModel $mappingModel */
        $mappingModel =  oxNew(MappingModel::class);

        if ($mappingModel)
        {
            $mappingModel->loadBySystemId($oxid, MappingModel::KEY_TYPE_MANUFACTURERS);

            if ($mappingModel->isLoaded())
            {
                $mappingModel->delete();
            }
        }
    }

}