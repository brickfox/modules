<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 26.02.19
 * Time: 15:15
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\model\oxid as OxidModels;

class VoucherListModel extends OxidModels\ListModel
{

    const TABLE_FIELD_OXORDERID	= 'OXORDERID';



    public function __construct()
    {
        parent::__construct('bfox\saleschannel\classes\model\VoucherModel');
    }


    /**
     * loadByOrderId.
     *
     * @param string $oxOrderId ox order id
     */
    public function loadByOrderId($oxOrderId)
    {
        $sqlStatement			= sprintf(
            'SELECT * FROM %s WHERE %s = \'%s\';',
            $this->getBaseObject()->getViewName(),
            self::TABLE_FIELD_OXORDERID,
            $oxOrderId
        );
        $this->selectString($sqlStatement);
    }
}