<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 20.02.19
 * Time: 11:57
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\model\oxid as OxidModels;
use \OxidEsales\Eshop as Oxid;

class AccessoireToArticleListModel extends OxidModels\ListModel
{
    /**
     * loadArticleAssignments.
     *
     * @param string $oxArticleId ox article id
     */
    public function loadArticleAssignments($oxArticleId)
    {
        if('' != $oxArticleId)
        {
            $viewNameGenerator = Oxid\Core\Registry::get(Oxid\Core\TableViewNameGenerator::class);

            $sqlStatement			= sprintf(
                'SELECT * FROM %s WHERE OXARTICLENID = \'%s\';',
                $viewNameGenerator->getViewName('oxaccessoire2article'),
                $oxArticleId
            );
            $this->selectString($sqlStatement);
        }
    }
}