<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 26.02.19
 * Time: 10:08
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\model\oxid as OxidModels;
use bfox\saleschannel\classes\util as Utils;

class OrderListModel extends OxidModels\ListModel
{
    const TABLE_FIELD_BFEXPORTDATE       = 'BFEXPORTDATE';
    const TABLE_FIELD_OXSENDDATE         = 'OXSENDDATE';
    const TABLE_FIELD_OXFOLDER           = 'OXFOLDER';
    const TABLE_FIELD_OXTRANSSTATUS      = 'OXTRANSSTATUS';
    const TABLE_FIELD_OXORDERDATE        = 'OXORDERDATE';
    const TABLE_FIELD_OXSHOPID           = 'OXSHOPID';
    const TRANSSTATUS_OK                 = 'OK';
    const TRANSSTATUS_AMZ_AUTHORIZE_OPEN = 'AMZ-Authorize-Open';

    /**
     */
    public function __construct()
    {
        parent::__construct(OrderModel::class);
    }

    /**
     */
    public function loadExportOrders()
    {
        $sqlStatement = sprintf(
            'SELECT * FROM %s WHERE %s = %s AND (%s IS NULL OR %s = \'%s\') AND %s = \'%s\' AND (%s = \'%s\' OR %s = \'%s\') AND %s = \'%s\' ORDER BY %s;',
            $this->getBaseObject()->getViewName(),
            self::TABLE_FIELD_OXSHOPID,
            Utils\OxidRegistry::getActiveShopId(),
            self::TABLE_FIELD_BFEXPORTDATE,
            self::TABLE_FIELD_BFEXPORTDATE,
            '0000-00-00 00:00:00',
            self::TABLE_FIELD_OXSENDDATE,
            '0000-00-00 00:00:00',
            self::TABLE_FIELD_OXTRANSSTATUS,
            self::TRANSSTATUS_OK,
            self::TABLE_FIELD_OXTRANSSTATUS,
            self::TRANSSTATUS_AMZ_AUTHORIZE_OPEN,
            self::TABLE_FIELD_OXFOLDER,
            OrderModel::IMPORT_ORDERS_FOLDER_NEW,
            self::TABLE_FIELD_OXORDERDATE
        );

        $this->selectString($sqlStatement);
    }
}