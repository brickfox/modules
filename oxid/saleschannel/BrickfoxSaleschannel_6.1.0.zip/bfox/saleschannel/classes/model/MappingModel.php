<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 21.01.19
 * Time: 17:49
 */

namespace bfox\saleschannel\classes\model;

use \OxidEsales\Eshop as Oxid;
use bfox\saleschannel\classes\util as Utils;
use bfox\saleschannel\classes\model as Models;

class MappingModel extends Models\oxid\BaseModel
{
    /**
     * key type constants
     *
     * @var string
     */
    const   KEY_TYPE_MANUFACTURERS       = 'TYPE_MANUFACTURERS';
    const   KEY_TYPE_CATEGORIES          = 'TYPE_CATEGORIES';
    const   KEY_TYPE_PRODUCTS            = 'TYPE_PRODUCTS';
    const   KEY_TYPE_PRODUCTS_VARIATIONS = 'TYPE_PRODUCTS_VARIATIONS';

    /**
     * table fields
     *
     * @var string
     */
    const   TABLE_FIELD_OXID     = 'OXID';
    const   TABLE_FIELD_BFID     = 'BFID';
    const   TABLE_FIELD_SYSTEMID = 'SYSTEMID';
    const   TABLE_FIELD_OXSHOPID = 'OXSHOPID';
    const   TABLE_FIELD_TYPE     = 'TYPE';

    /** @var bool */
    private $validSystemId = true;

    /** @var Models\ShopModel  */
    private $_shopModel = true;


    public function __construct($shopModel = null)
    {
        if (is_null($shopModel)){
            $this->_shopModel = oxNew(Models\ShopModel::class);
        }
        else{
            $this->_shopModel = $shopModel;
        }

        parent::__construct();

        $this->init('bfmapping');
        $this->setCreatedate();
    }

    /**
     * @param integer $bfId bf id
     * @param string $mappingType mapping type
     * @return boolean is loaded
     */
    public function loadByBfId($bfId, $mappingType)
    {
        return $this->loadById($bfId, $mappingType);
    }

    /**
     * @param string $systemId system id
     * @param string $mappingType mapping type
     * @return boolean is loaded
     */
    public function loadBySystemId($systemId, $mappingType)
    {
        return $this->loadById($systemId, $mappingType, self::TABLE_FIELD_SYSTEMID);
    }

    /**
     * @param string $bfId bf id
     * @param string $systemId system id
     * @param string $type type
     */
    public function store($bfId, $systemId, $type, $shopId = null)
    {
        if ($shopId === null) {
            $shopId = Utils\OxidRegistry::getActiveShopId();
        }

        /** @var MappingModel $mappingModel */
        $mappingModel = oxNew(MappingModel::class);
        $mappingModel->loadByBfId($bfId, $type);

        if (false === $mappingModel->isLoaded() || $systemId != $mappingModel->getSystemId())
        {
            $mappingModel->setBfId($bfId);
            $mappingModel->setType($type);
            $mappingModel->setSystemId($systemId);
            $mappingModel->setOxShopId($shopId);
            $mappingModel->save();
        }
    }

    /**
     * @return string oxid
     */
    public function getOxid()
    {
        return $this->bfmapping__oxid->value;
    }

    /**
     * @param string $oxid oxid
     * @return MappingModel
     */
    public function setOxid($oxid)
    {
        $this->oxid = oxNew(Oxid\Core\Field::class,
            $oxid, Oxid\Core\Field::T_RAW
        );

        return $this;
    }

    /**
     * @return integer bfid
     */
    public function getBfId()
    {
        return $this->getFieldData('bfid');
    }

    /**
     * @param integer $bfId bf id
     * @return MappingModel
     */
    public function setBfId($bfId)
    {
        $this->bfmapping__bfid = oxNew(Oxid\Core\Field::class,
            $bfId, Oxid\Core\Field::T_RAW
        );

        return $this;
    }

    /**
     * @return integer system id
     */
    public function getSystemId()
    {
        return $this->getFieldData('systemid');
    }

    /**
     * @param integer $systemId system id
     * @return MappingModel
     */
    public function setSystemId($systemId)
    {
        $this->bfmapping__systemid = oxNew(Oxid\Core\Field::class,
            $systemId, Oxid\Core\Field::T_RAW
        );

        return $this;
    }

    /**
     * @return integer
     */
    public function getOxShopId()
    {
        return $this->getFieldData('oxshopid');
    }

    /**
     * @param integer $oxShopId
     * @return MappingModel
     */
    public function setOxShopId($oxShopId)
    {
        //Set the Oxid BaseModel object property
        $this->setShopId($oxShopId);

        $this->bfmapping__oxshopid = oxNew(Oxid\Core\Field::class,
            $oxShopId, Oxid\Core\Field::T_RAW
        );

        return $this;
    }

    /**
     * @return string type
     */
    public function getType()
    {
        return $this->getFieldData('type');
    }

    /**
     * @param string $type type
     * @return MappingModel
     */
    public function setType($type)
    {
        $this->bfmapping__type = oxNew(Oxid\Core\Field::class,
            $type, Oxid\Core\Field::T_RAW
        );

        return $this;
    }

    /**
     */
    private function setCreatedate()
    {
        $this->bfmapping__createdate = oxNew(Oxid\Core\Field::class,
            date('Y-m-d H:i:s'), Oxid\Core\Field::T_RAW
        );
    }

    /**
     * @return boolean has valid system id
     */
    public function hasValidSystemId()
    {
        return $this->validSystemId;
    }

    /**
     * @param boolean $validSystemId valid system id
     */
    public function setValidSystemId($validSystemId)
    {
        $this->validSystemId = $validSystemId;
    }

    /**
     * @param integer $id id
     * @param string $mappingType mapping type
     * @param string $idColumn id database column
     * @return boolean is loaded
     */
    private function loadById($id, $mappingType, $idColumn = self::TABLE_FIELD_BFID)
    {
        $oxShopId   = Utils\OxidRegistry::getActiveShopId();

        $shopModel = $this->_shopModel;
        $shopModel->load($oxShopId);

        if($shopModel->isSuperShop() === false && $mappingType != self::KEY_TYPE_CATEGORIES)
        {
            $parentShopId = $shopModel->getParentShopId();
            if (!is_null($parentShopId) && $parentShopId > 0) $oxShopId = $parentShopId;
        }

        $this->_addField('oxid', 0);

        if($mappingType != self::KEY_TYPE_CATEGORIES)
        {
            $query = $this->buildSelectString(
                array(
                    $this->getViewName() . '.' . $idColumn => $id,
                    $this->getViewName() . '.' . self::TABLE_FIELD_OXSHOPID => $oxShopId,
                    $this->getViewName() . '.' . self::TABLE_FIELD_TYPE     => $mappingType
                )
            );
        }
        else
        {
            $query = $this->buildSelectString(
                array(
                    $this->getViewName() . '.' . $idColumn => $id,
                    $this->getViewName() . '.' . self::TABLE_FIELD_OXSHOPID => Utils\OxidRegistry::getActiveShopId(),
                    $this->getViewName() . '.' . self::TABLE_FIELD_TYPE     => $mappingType
                )
            );
        }

        return $this->_isLoaded = $this->assignRecord($query);
    }
}