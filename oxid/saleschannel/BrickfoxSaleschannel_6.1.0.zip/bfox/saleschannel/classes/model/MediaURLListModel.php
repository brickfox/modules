<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 06.02.19
 * Time: 15:13
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\model\oxid\ListModel;
use \OxidEsales\Eshop as Oxid;

class MediaURLListModel extends ListModel
{
    /**
     * loadAssignments.
     *
     * @param string $oxObjectId ox object id
     */
    public function loadAssignments($oxObjectId)
    {
        if('' != $oxObjectId)
        {
            $viewNameGenerator = Oxid\Core\Registry::get(Oxid\Core\TableViewNameGenerator::class);
            $sViewName		= $viewNameGenerator->getViewName('oxmediaurls');

            $sqlStatement			= sprintf(
                'SELECT * FROM %s WHERE %s = \'%s\';',
                $sViewName,
                MediaURLModel::OXOBJECTID,
                $oxObjectId
            );
            $this->selectString($sqlStatement);
        }
    }
}