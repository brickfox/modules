<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 07.01.19
 * Time: 23:29
 */

namespace bfox\saleschannel\classes\model;

class ShopListModel extends \OxidEsales\Eshop\Application\Model\ShopList
{
    /**
     */
    public function loadShopList()
    {
        $sqlStatement = sprintf(
            'SELECT * FROM %s;',
            $this->getBaseObject()->getViewName()
        );

        $this->selectString($sqlStatement);
    }
}
