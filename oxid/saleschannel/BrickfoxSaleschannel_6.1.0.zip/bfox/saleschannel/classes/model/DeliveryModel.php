<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 23.01.19
 * Time: 16:16
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\util as Utils;


class DeliveryModel extends \OxidEsales\Eshop\Application\Model\Delivery
{
    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/

    /**
     * loadByTitle.
     *
     * @param string $title title
     * @param integer $languageId languages id
     * @return boolean is loaded
     */
    public function loadByTitle($title, $languageId = null)
    {
        if(is_null($languageId) === true)
        {
            $languageId = Utils\OxidRegistry::getDefaultLanguageId();
        }

        $this->_addField('oxid', 0);
        $this->setLanguage($languageId);
        $query = $this->buildSelectString(
            array(
                $this->getViewName() . '.OXTITLE' => $title
            ));

        $this->_isLoaded = $this->assignRecord($query);
        return $this->_isLoaded;
    }
}