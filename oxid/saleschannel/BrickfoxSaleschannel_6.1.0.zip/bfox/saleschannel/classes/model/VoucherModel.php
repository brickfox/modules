<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 26.02.19
 * Time: 15:12
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\model as Models;

class VoucherModel extends \OxidEsales\Eshop\Application\Model\Voucher
{

    const	FIELD_ARTICLEID							= 'articleId',
        FIELD_PRICE									= 'price',
        FIELD_AMOUNT								= 'amount',
        FIELD_DISCOUNT								= 'discount';

    const VOUCHER_TYPE_CAMPAIGN						= 'CAMPAIGN';


    const BF_REDUCE_TYPE_ABSOLUTE					= 'ABSOLUTE',
        BF_REDUCE_TYPE_RELATIVE						= 'RELATIVE';



    /**
     * getVoucherOrderLinesData.
     *
     * @param Models\OrderModel $oxOrderModel ox order model
     * @return array order lines
     */
    public function getVoucherOrderLinesData(Models\OrderModel $oxOrderModel)
    {
        $result							= array();
        $discountModel					= $this->_getSerieDiscount();

        $specificVoucherArticles		= $this->getSpecificVoucherArticles($oxOrderModel);
        $specificVoucherArticlesCount	= count($specificVoucherArticles);

        foreach($oxOrderModel->getOrderArticles(true) as $orderArticleModel)
        {
            if(false === $orderArticleModel->skipDiscounts()
                && (0 == $specificVoucherArticlesCount || true === in_array($orderArticleModel->getFieldData('oxid'), $specificVoucherArticles)))
            {
                $result[$orderArticleModel->getId()] = array(
                    self::FIELD_ARTICLEID	=> $orderArticleModel->getProductId(),
                    self::FIELD_PRICE		=> $orderArticleModel->getFieldData('oxprice'),
                    self::FIELD_AMOUNT		=> $orderArticleModel->getFieldData('oxamount'),
                    self::FIELD_DISCOUNT	=> $discountModel->getAbsValue($orderArticleModel->getFieldData('oxbprice'))
                );
            }
        }
        return $result;
    }

    /**
     * getVoucherType.
     *
     * @return string voucher type
     */
    public function getVoucherType()
    {
        return self::VOUCHER_TYPE_CAMPAIGN;
    }

    /**
     * getVoucherReduceType.
     *
     * @return string voucher reduce type
     */
    public function getVoucherReduceType()
    {
        $result = null;

        // percent or absolute
        $reduceType			= $this->getSerie()->getFieldData('oxdiscounttype');

        $reduceTypeMapping	= $this->getReduceTypeMapping();

        if(true === array_key_exists($reduceType, $reduceTypeMapping))
        {
            $result = $reduceTypeMapping[$reduceType];
        }

        return $result;
    }



    /**
     * getReduceTypeMapping.
     *
     * @return array reduce type mapping
     */
    private function getReduceTypeMapping()
    {
        return array(
            'percent'	=> self::BF_REDUCE_TYPE_RELATIVE,
            'absolute'	=> self::BF_REDUCE_TYPE_ABSOLUTE
        );
    }

    /**
     * getSpecificVoucherArticles.
     *
     * @param Models\OrderModel $oxOrderModel ox order model
     * @return array specific voucher articles
     */
    private function getSpecificVoucherArticles(Models\OrderModel $oxOrderModel)
    {
        $result			= array();
        $discountModel	= $this->_getSerieDiscount();

        foreach($oxOrderModel->getOrderArticles(true) as $orderArticleModel)
        {
            if(false === $orderArticleModel->skipDiscounts() && true === $discountModel->isForBasketItem($orderArticleModel))
            {
                $result[] = $orderArticleModel->getFieldData('oxid');
            }
        }
        return $result;
    }
}