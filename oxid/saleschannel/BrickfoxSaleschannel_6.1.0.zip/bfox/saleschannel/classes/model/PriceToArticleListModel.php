<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 06.02.19
 * Time: 13:36
 */

namespace bfox\saleschannel\classes\model;

use bfox\saleschannel\classes\model\oxid\ListModel;
use \OxidEsales\Eshop as Oxid;


class PriceToArticleListModel extends ListModel
{

    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/

    /**
     * loadArticleAssignments.
     *
     * @param string $oxArticleId ox article id
     */
    public function loadArticleAssignments($oxArticleId)
    {
        if('' != $oxArticleId)
        {
            $viewNameGenerator = Oxid\Core\Registry::get(Oxid\Core\TableViewNameGenerator::class);

            $sqlStatement			= sprintf(
                'SELECT * FROM %s WHERE %s = \'%s\';',
                $viewNameGenerator->getViewName('oxprice2article'),
                PriceToArticleModel::OXARTID,
                $oxArticleId
            );
            $this->selectString($sqlStatement);
        }
    }

}