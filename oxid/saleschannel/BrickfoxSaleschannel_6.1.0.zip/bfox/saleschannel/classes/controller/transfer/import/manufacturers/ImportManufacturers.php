<?php

/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 21.01.19
 * Time: 17:15
 */
namespace bfox\saleschannel\classes\controller\transfer\import\manufacturers;

use bfox\saleschannel\classes\model as Models;
use bfox\saleschannel\classes\util as Utils;
use bfox\saleschannel\classes\controller\transfer as Transfers;
use \OxidEsales\Eshop as Oxid;

class ImportManufacturers extends Transfers\import\AbstractImport
{
    /*****************************************************************************
     *
     * Class properties
     *
     *****************************************************************************/

    /**
     * manufacturers list
     *
     * @var array
     */
    private $manufacturersList = array();

    /**
     * mapping list model
     *
     * @var Models\MappingListModel
     */
    private $_mappingListModel = null;

    /** @var Models\ManufacturerModel */
    private $_manufacturerModel = null;



    /*****************************************************************************
     *
     * Callable functions
     *
     *****************************************************************************/

    /**
     * ImportManufacturers constructor.
     * @param string $fileLocation
     * @param null $mappingModel
     * @param null $manufacturerModel
     * @param null $mappingListModel
     */
    public function __construct($fileLocation, $mappingModel = null, $manufacturerModel = null, $mappingListModel = null)
    {
        parent::__construct($fileLocation, $mappingModel);

        if (is_null($manufacturerModel))
        {
            $this->_manufacturerModel = oxNew(Models\ManufacturerModel::class);
        }
        else
        {
            $this->_manufacturerModel = $manufacturerModel;
        }

        if (is_null($mappingListModel))
        {
            $this->_mappingListModel = oxNew(Models\MappingListModel::class);
        }
        else
        {
            $this->_mappingListModel = $mappingListModel;
        }
    }


    /**
     * import.
     */
    public function import()
    {
        $this->initManufacturersList();

        $this->initMappingListModel();

        parent::import();

        // delete not listed manufacturers
        $this->processNotTransmittedManufacturers();
    }

    /**
     * processImport.
     *
     * @param \SimpleXMLElement $manufacturerData manufacturers data
     */
    protected function processImport(\SimpleXMLElement $manufacturerData)
    {
        $bfManufacturersId = $this->getIntegerValue($manufacturerData->ManufacturerId);

        if (0 < $bfManufacturersId)
        {
            try
            {
//                if (false === empty($manufacturerData->Shops))
//                {
//                    var_dump($manufacturerData->Shops);
//                    echo "<hr>";
//                }

                if (false === empty($manufacturerData->Translations))
                {
                    /** @var Models\ManufacturerModel $manufacturerModel */
                    $manufacturerModel = clone $this->_manufacturerModel;

                    $mappingModel      = $this->getMappingListModel()
                        ->getMappingByKey($bfManufacturersId, Utils\OxidRegistry::getActiveShopId());

                    // for each mapping in the database the matching manufacturer is necessary!
                    if (false === is_null($mappingModel))
                    {
                        // update manufacturers
                        $manufacturerModel->load($mappingModel->getSystemId());
                        $this->removeFromManufacturersListByOxid($mappingModel->getSystemId());
                    }
                    else
                    {
                        $firstTitle        = $this->getDefaultLanguageTitle($manufacturerData);
                        $manufacturersOxid = $this->getOxManufacturerIdByTitle($firstTitle);

                        if (false === is_null($manufacturersOxid) && '' != $manufacturersOxid)
                        {
                            // manufacturer name already exists
                            $manufacturerModel->load($manufacturersOxid);
                            $this->removeFromManufacturersListByOxid($manufacturersOxid);
                        }
                        else
                        {
                            // insert manufacturers
                            $manufacturerModel->initOxManufacturer();
                        }

                        // add mapping entry
                        $mappingModel = clone $this->_mappingModel;
                        $mappingModel->store($bfManufacturersId,
                            $manufacturerModel->getManufacturerDataByKey('oxmanufacturers__oxid'),
                            Models\MappingModel::KEY_TYPE_MANUFACTURERS);
                    }

                    foreach ($manufacturerData->Translations->children() as $translation)
                    {
                        $langCode = $this->getStringValue($translation['lang']);
                        if ('' != $langCode)
                        {
                            if (true === $this->hasLanguageKey($langCode))
                            {
                                $languageData = $this->getLanguageByKey($langCode);
                                $languageId   = $languageData->id;

                                $manufacturerModel->setManufacturerLanguageData($languageId, 'oxmanufacturers__oxtitle', $this->getStringValue($translation->Name));
                                $manufacturerModel->save();
                            }
                        }
                        else
                        {
                            $this->handleException('Manufacturer title is invalid. BfManfacturerId: ' . $bfManufacturersId);
                        }
                    }
                    $this->logRowEntry('Manufacturer with extern manufacturer id:' . $bfManufacturersId . ' imported!');
                }
                else
                {
                    $this->handleException('Translations are missing for manufacturer with manufacturer id: ' . $bfManufacturersId);
                }
            }
            catch (\Exception $exception)
            {
                $this->handleException('Error while importing manufacturer with manufacturer id: ' . $bfManufacturersId . '! Exception: ' . $exception);
            }
        }
        else
        {
            // ignore manufacturer entry
            $this->handleException('Invalid manufacturer data. ManufacturersId:' . $bfManufacturersId);
        }
    }

    /*****************************************************************************
     *
     * helper functions
     *
     *****************************************************************************/

    /**
     * getDefaultLanguageTitle.
     *
     * @param \SimpleXMLElement $manufacturerData
     * @return string default language manufacturer title
     */
    private function getDefaultLanguageTitle(\SimpleXMLElement $manufacturerData)
    {
        $result            = '';
        $defaultLanguageId = Utils\OxidRegistry::getDefaultLanguageId();

        foreach ($manufacturerData->Translations->children() as $translation)
        {
            $languageCode = $this->getStringValue($translation['lang']);
            $languageData = $this->getLanguageDataByLanguageCode($languageCode);

            if ($defaultLanguageId == $languageData->id)
            {
                $result = $this->getStringValue($translation->Name);
                break;
            }
        }

        return $result;
    }

    /**
     * @throws \bfox\saleschannel\classes\exception\ConfigurationException
     */
    private function processNotTransmittedManufacturers()
    {
        $action            = Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_IMPORTEXPORT_MANUFACTURERS_ACTION);
        $actionDeleteValue = Utils\ConfigurationKeys::CONFIG_KEY_IMPORTEXPORT_MANUFACTURERS_DELETE_VALUE;

        foreach (array_keys($this->getManufacturersList()) as $oxid) {
            $manufacturerModel = clone $this->_manufacturerModel;
            $manufacturerModel->load($oxid);

            if ($action === $actionDeleteValue) {
                $manufacturerModel->delete();

                $mappingModel = clone $this->_mappingModel;
                $mappingModel->loadBySystemId($oxid, Models\MappingModel::KEY_TYPE_MANUFACTURERS);
                $mappingModel->delete();
            } else {
                $languagesData = Utils\OxidRegistry::getOxidLanguageArray();
                foreach ($languagesData as $languageData) {
                    $manufacturerModel->setManufacturerLanguageData(
                        $languageData->id,
                        'oxmanufacturers__oxactive',
                        Transfers\AbstractTransfer::STATUS_INACTIVE_ID
                    );
                    $manufacturerModel->save();
                }
            }
        }
    }

    /**
     * initManufacturersList
     *
     * @return ImportManufacturers import manufacturers
     */
    private function initManufacturersList()
    {
        $manufacturerModel = clone $this->_manufacturerModel;
        $this->setManufacturersList($manufacturerModel->getBfManufacturersList());

        return $this;
    }

    /**
     * initMappingListModel.
     */
    private function initMappingListModel()
    {
        $mappingListModel = clone $this->_mappingListModel;
        $mappingListModel->loadMappingsModelList(Models\MappingModel::KEY_TYPE_MANUFACTURERS, Utils\OxidRegistry::getActiveShopId());
        $this->setMappingListModel($mappingListModel);
    }

    /**
     * getOxManufacturerIdByTitle
     *
     * @param string $title title
     * @return mixed array/null
     */
    private function getOxManufacturerIdByTitle($title)
    {
        $returnValue = array_search($title, $this->manufacturersList);
        if ($returnValue === false) {
            $returnValue = null;
        }

        return $returnValue;
    }

    /**
     * removeFromManufacturersListByOxid.
     *
     * @param string $oxid ox id
     * @return ImportManufacturers import manufacturers
     */
    private function removeFromManufacturersListByOxid($oxid)
    {
        if (array_key_exists($oxid, $this->manufacturersList)) {
            unset($this->manufacturersList[$oxid]);
        }

        return $this;
    }

    /**
     * getManufacturersList
     *
     * @return array manufacturers list
     */
    private function getManufacturersList()
    {
        return $this->manufacturersList;
    }

    /**
     * setManufacturersList.
     *
     * @param array $manufacturersList manufacturers list
     */
    private function setManufacturersList($manufacturersList)
    {
        $this->manufacturersList = $manufacturersList;
    }

    /**
     * getMappingListModel.
     *
     * @return Models\MappingListModel mapping list model
     */
    private function getMappingListModel()
    {
        return $this->_mappingListModel;
    }

    /**
     * setMappingListModel
     *
     * @param Models\MappingListModel $mappingListModel mapping list model
     */
    private function setMappingListModel(Models\MappingListModel $mappingListModel)
    {
        $this->_mappingListModel = $mappingListModel;
    }


    public function deleteAll($deletionSetting)
    {
        $manufacturerListModel = new Oxid\Core\Model\ListModel();
        $manufacturerListModel->init($deletionSetting[0]["object"], $deletionSetting[0]["table"]);
        $manufacturerListModel->getList();

        foreach($manufacturerListModel->arrayKeys() as $manufacturerID)
        {
            $manufacturerModel   = clone $this->_manufacturerModel;
            $manufacturerModel->delete($manufacturerID);
        }
    }
}