<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 19.02.19
 * Time: 15:54
 */

namespace bfox\saleschannel\classes\controller\transfer\import\categories;

use bfox\saleschannel\classes\model as Models;
use bfox\saleschannel\classes\controller\transfer as Transfers;

class ImportCategoriesMapping extends Transfers\import\AbstractImport
{
    /**
     * @param \SimpleXMLElement $categoriesData categories data
     */
    protected function processImport(\SimpleXMLElement $categoriesData)
    {
        $bfCategoryId       = $this->getStringValue($categoriesData->CategoryId);
        $bfExternCategoryId = $this->getStringValue($categoriesData->ExternCategoryId);

        if ('' != $bfCategoryId && '' != $bfExternCategoryId) {
            $categoryModel = oxNew(Models\CategoryModel::class);
            $categoryModel->load($bfExternCategoryId);

            if ($categoryModel->isLoaded()) {
                // insert categories mapping
                $this->insertMappingRecord($bfCategoryId, $bfExternCategoryId);
            } else {
                $this->handleException('Category not found! Extern category id: ' . $bfExternCategoryId);
            }
        } else {
            $this->handleException('Invalid categories id found! Categories id: ' . $bfCategoryId . '. Extern categories id: ' . $bfExternCategoryId);
        }
    }

    /**
     * @param string $bfId bf id
     * @param string $systemId system id
     */
    private function insertMappingRecord($bfId, $systemId)
    {
        $mappingModel = oxNew(Models\MappingModel::class);
        $mappingModel->loadByBfId($bfId, Models\MappingModel::KEY_TYPE_CATEGORIES);

        // only insert entry to database in case that bf id doesn't exist there
        if (false === $mappingModel->isLoaded()) {
            $mappingModel->setBfId($bfId);
            $mappingModel->setSystemId($systemId);
            $mappingModel->setType(Models\MappingModel::KEY_TYPE_CATEGORIES);
            $mappingModel->save();
        }
    }
}