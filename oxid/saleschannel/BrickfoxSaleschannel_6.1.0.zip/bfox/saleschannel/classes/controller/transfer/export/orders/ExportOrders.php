<?php

/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 26.02.19
 * Time: 10:57
 */

namespace bfox\saleschannel\classes\controller\transfer\export\orders;


use bfox\saleschannel\classes\model as Models;
use bfox\saleschannel\classes\util as Utils;
use \OxidEsales\Eshop as Oxid;


class ExportOrders extends AbstractExportOrders
{
    /**
     * ###################################################################
     *              CONSTANTS
     * ###################################################################
     */

    const PARTY_TYPE_BILL     = 'oxbill';
    const PARTY_TYPE_DELIVERY = 'oxdel';





    /**
     * ###################################################################
     *              GETTERS & SETTERS
     * ###################################################################
     */

    /**
     * getExporterData.
     *
     * @return mixed exporter data
     */
    protected function getExporterData()
    {
        if(false === isset($this->exporterData))
        {
            $this->initExporterData();
        }
        return $this->exporterData;
    }

    /**
     * setExporterData.
     *
     * @param mixed $exporterData exporter data
     */
    protected function setExporterData($exporterData)
    {
        $this->exporterData = $exporterData;
    }



    /**
     * ###################################################################
     *              METHODS
     * ###################################################################
     */

    /**
     */
    protected function initExporterData()
    {
        $orderListModel = oxNew(Models\OrderListModel::class);
        $orderListModel->loadExportOrders();

        $this->setExporterData($orderListModel);
    }


    /**
     * @return boolean exporter data available
     */
    public function isExporterDataAvailable()
    {
        return 0 < sizeof($this->getExporterData());
    }




    /**
     * @param string $fileLocation file location
     */
    public function export($fileLocation)
    {
        $this->setFileLocation($fileLocation);

        $orderListModel = $this->getExporterData();
        $ordersCount    = sizeof($orderListModel);

        $this->initXmlWriter();

        // root element
        $this->writeStartElement('Orders');
        $this->writeAttribute('count', $ordersCount);

        if ($ordersCount > 0) {

            $orderCounter = 1;

            /* @var Models\OrderModel $oxOrderModel */
            foreach ($orderListModel as $oxOrderModel)
            {
                $oxOrderId = $oxOrderModel->getId();

                try
                {
                    // only export orders having items
                    $orderArticleListModel = $oxOrderModel->getOrderArticles();

                    if (sizeof($orderArticleListModel) > 0)
                    {
                        $this->writeStartElement('Order');
                        $this->writeAttribute('num', $orderCounter);

                        $this->writeElement('OrderId', $this->getModelValue($oxOrderModel, 'oxordernr'));
                        $this->writeElement(
                            'OrderDate',
                            Oxid\Core\Registry::get('oxUtilsDate')->formatDBDate($this->getModelValue($oxOrderModel, 'oxorderdate'), true)
                        );

                        $this->addCustomerId($oxOrderModel);

                        $this->writeElement('TotalAmountProducts', $this->formatPrice($this->calculateTotalAmountProducts($oxOrderModel)));
                        $this->writeElement('TotalAmountProductsNetto', $this->formatPrice($this->getModelValue($oxOrderModel, 'oxtotalnetsum')));
                        $this->writeElement('TotalAmountVat', $this->formatPrice($this->calculateTotalVatAmount($oxOrderModel)));
                        $this->writeElement('TotalAmount', $this->formatPrice($oxOrderModel->getTotalOrderSum()));
                        $this->writeElement('Comment', $this->getModelValue($oxOrderModel, 'oxremark', true), true);

                        // orders costs changings data
                        $this->addCostsChangingsData($oxOrderModel);

                        // payment
                        $this->addPaymentData($oxOrderModel);

                        // shipment
                        $this->addShipmentData($oxOrderModel);

                        // billing party
                        $this->writeStartElement('BillingParty');
                        $this->addPartyData($oxOrderModel, self::PARTY_TYPE_BILL);
                        $this->writeEndElement();

                        // delivery party
                        $this->writeStartElement('DeliveryParty');

                        // delivery data set
                        if ('' != $this->getModelValue($oxOrderModel, 'oxdellname'))
                        {
                            $this->addPartyData($oxOrderModel, self::PARTY_TYPE_DELIVERY);
                        }
                        else
                        {
                            $this->addPartyData($oxOrderModel, self::PARTY_TYPE_BILL);
                        }

                        $this->writeEndElement();

                        // coupons
                        $this->addCouponsData($oxOrderModel);

                        // order lines
                        $this->addOrderLinesData($oxOrderModel);

                        $this->writeEndElement();

                        // set export date
                        $oxOrderModel->assign(array('oxorder__bfexportdate' => date('Y-m-d H:i:s')));
                        $oxOrderModel->save();

                        $this->logRowEntry('Order with ox orders id:' . $oxOrderId . ' exported!');
                    }
                    else
                    {
                        $this->handleException('No order articles found for order oxid: ' . $oxOrderId);
                    }
                    $orderCounter++;
                }
                catch (\Exception $exception)
                {
                    $this->handleException('Error while exporting order with order oxid: ' . $oxOrderId . '! Exception: ' . $exception);
                }
            }
        }

        $this->endXmlWriter();
    }


    /**
     * @param Models\OrderModel $oxOrderModel ox order model
     * @return float total vat amount
     */
    private function calculateTotalVatAmount(Models\OrderModel $oxOrderModel)
    {
        $result       = 0.0;
        $productsVats = $oxOrderModel->getProductVats();

        foreach ($productsVats as $productVat) {
            $result += str_replace(',', '.', $productVat);
        }

        return $result;
    }

    /**
     * @param Models\OrderModel $oxOrderModel ox order model
     * @return float total amounts products
     */
    private function calculateTotalAmountProducts(Models\OrderModel $oxOrderModel)
    {
        $result            = $this->getModelValue($oxOrderModel, 'oxtotalbrutsum');
        $oxVoucherDiscount = $this->getModelValue($oxOrderModel, 'oxvoucherdiscount');

        if (0 < $oxVoucherDiscount) {
            $result -= $oxVoucherDiscount;
        }

        return $result;
    }


    /**
     * @param Models\OrderModel $oxOrderModel ox order model
     * @param string $type type
     */
    private function addPartyData(Models\OrderModel $oxOrderModel, $type)
    {
        // saluation
        $validSalutations = array('mr', 'mrs');
        $salutation       = $this->getModelValue($oxOrderModel, $type . 'sal');

        if (false === is_null($salutation) && true === in_array(strtolower($salutation), $validSalutations))
        {
            // translates MR => Herr and MRS => Frau
            $salutation = Oxid\Core\Registry::getLang()->translateString($salutation, Utils\OxidRegistry::getDefaultLanguageId());
            $this->writeElement('Title', $salutation);
        }

        // company
        $this->writeElement('Company', $this->getModelValue($oxOrderModel, $type . 'company', true), true);

        // name
        $this->writeElement('FirstName', $this->getModelValue($oxOrderModel, $type . 'fname', true), true);
        $this->writeElement('LastName', $this->getModelValue($oxOrderModel, $type . 'lname', true), true);

        // address
        $this->writeElement('Address', $this->getModelValue($oxOrderModel, $type . 'street', true), true);
        $this->writeElement('Number', $this->getModelValue($oxOrderModel, $type . 'streetnr', true), true);
        $this->writeElement('AddressAdd', $this->getModelValue($oxOrderModel, $type . 'addinfo', true), true);
        $this->writeElement('PostalCode', $this->getModelValue($oxOrderModel, $type . 'zip', true), true);
        $this->writeElement('City', $this->getModelValue($oxOrderModel, $type . 'city', true), true);

        $oxCountryId = $this->getModelValue($oxOrderModel, $type . 'countryid');

        if ('' != $oxCountryId)
        {
            $oxCountryModel = oxNew(Oxid\Application\Model\Country::class);
            $oxCountryModel->load($oxCountryId);

            if (true === $oxCountryModel->isLoaded())
            {
                $this->writeElement('Country', $this->getModelValue($oxCountryModel, 'oxtitle', true), true);
            }
            else
            {
                $this->handleException('Error while exporting order with order oxid: ' . $oxOrderModel->getId() . '! Could not load country with oxid: ' . $oxCountryId);
            }
        }

        $oxStateId = $this->getModelValue($oxOrderModel, $type . 'stateid');

        if ('' != $oxStateId)
        {
            $oxStateModel = oxNew(Oxid\Application\Model\State::class);
            $oxStateModel->load($oxStateId);

            if (true === $oxStateModel->isLoaded())
            {
                $this->writeElement('State', $this->getModelValue($oxStateModel, 'oxtitle'), true);
            }
            else
            {
                $this->handleException('Error while exporting order with order oxid: ' . $oxOrderModel->getId() . '! Could not load state with oxid: ' . $oxStateId);
            }
        }

        // contact information
        $this->writeElement('PhonePrivate', $this->getModelValue($oxOrderModel, $type . 'fon', true), true);
        $this->writeElement('EmailAddress', $this->getModelValue($oxOrderModel, $type . 'email', true), true);

        $this->addVatId($oxOrderModel, $type);
    }



    /**
     * @param Models\OrderModel $oxOrderModel ox order model
     * @param string $type type
     */
    private function addVatId(Models\OrderModel $oxOrderModel, $type)
    {
        if ($type === self::PARTY_TYPE_BILL)
        {
            $oxUstId = $this->getModelValue($oxOrderModel, $type . 'ustid', true);

            if (false === is_null($oxUstId) && '' != $oxUstId)
            {
                $this->writeElement('VatId', $oxUstId);
            }
        }
    }


}