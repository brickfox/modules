<?php

/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 31.01.19
 * Time: 14:19
 */

namespace bfox\saleschannel\classes\controller\transfer\import\products;

use bfox\saleschannel\classes\exception\ImportExportException;
use bfox\saleschannel\classes\model as Models;
use bfox\saleschannel\classes\controller\transfer as Transfers;
use bfox\saleschannel\classes\util as Utils;

use \OxidEsales\Eshop as Oxid;

class ImportProducts extends Transfers\import\AbstractImport
{
    /**
     * stock flag ids
     */
    const STOCKFLAG_STANDARD   = 1;
    const STOCKFLAG_THIRDPARTY = 4;

    /**
     * tax id
     */
    const TAXID_REDUCED = 2;


    /** @var Models\MappingListModel */
    private $mappingListModel = null;

    /** @var int currentShopId Used for imports where several shops comes in a single XML */
    private $currentShopId = 0;

    /** @var Models\ProductModel */
    protected $_emptyProductModel = null;

    /** @var Models\ProductModel  Product currently being imported */
    protected $_currentProductModel = null;

    /** @var Transfers\import\attributes\ImportAttributes  */
    protected $_importAttributes = null;

    public function __construct($fileLocation, $mappingModel = null, $productModel = null, $importAttributes = null)
    {
        parent::__construct($fileLocation, $mappingModel);

        if (is_null($productModel))
        {
            $this->_emptyProductModel = oxNew(Models\ProductModel::class);
        }
        else
        {
            $this->_emptyProductModel = $productModel;
        }

        if (is_null($importAttributes))
        {
            $this->_importAttributes = oxNew(Transfers\import\attributes\ImportAttributes::class, $fileLocation);
        }
        else
        {
            $this->_importAttributes = $importAttributes;
        }
    }

    protected function processImport(\SimpleXMLElement $productsData)
    {
        $bfProductsId = $this->getIntegerValue($productsData->ProductId);

        // only import products having a valid products id
        if ($bfProductsId > 0){
            // only import products having valid data
            if (true === $this->isValid($productsData)) {
                try {
                    $hasVariations = $this->getIntegerValue($productsData->HasVariations) == 1 ? true : false;
                    $productMapping = $this->loadProductMapping($bfProductsId, Models\MappingModel::KEY_TYPE_PRODUCTS, Models\MappingModel::TABLE_FIELD_BFID);

                    $productModel = clone $this->_emptyProductModel;
                    $productModel->loadWithMappingModel($productMapping);
                    $this->setProductModel($productModel);

                    // product oxshopid
                    $this->getProductModel()->setArticleDataEntry('oxarticles__oxshopid', Utils\OxidRegistry::getActiveShopId());

                    // products status
                    $this->handleStatus($productsData);

                    // product tax Class
                    $this->handleTax($productsData);

                    // products sku
                    $this->handleSku($productsData);

                    // products attributes
                    $this->handleCustomAttributes($productsData, false);

                    // products to categories assignments
                    $this->handleCategories($productsData);

                    // manufacturer
                    $this->handleManufacturer($productsData);

                    // products descriptions
                    $this->handleDescriptions($productsData);

                    // variation data for non-variation articles goes in the same object
                    if ($hasVariations === false) {
                        $productsVariationsData = $productsData->Variations->Variation;

                        // products status
                        $this->handleStatus($productsVariationsData, 'VariationActive', true);

                        $this->handleVariationsData($productsVariationsData, true);

                        // products images
                        $this->handleImages($productsData, 'Images', true);

                    }
                    else {
                        // products images
                        $this->handleImages($productsData);

                        // products media
                        $this->handleMedia($productsData);
                    }

                    $this->getProductModel()->saveAll();

                    $this->logRowEntry('Product with product id:' . $bfProductsId . ' imported!');


                    // add mapping entry for variation, only for non-variant Articles
                    if ($hasVariations === false) {
                        $bfProductsVariationsId = $this->getIntegerValue($productsVariationsData->VariationId);
                        $mappingModel           = clone $this->_mappingModel;

                        $mappingModel->store(
                            $bfProductsVariationsId, $this->getProductModel()->getId(),
                            Models\MappingModel::KEY_TYPE_PRODUCTS_VARIATIONS
                        );
                    }

                    if($hasVariations === true)
                    {
                        $this->handleVariations($productsData);
                        $this->logRowEntry('Variations for product id:' . $bfProductsId . ' imported!', false);
                    }

                }
                catch (\Exception $exception){
                    $this->handleException('Error while importing product with product id: ' . $bfProductsId . '! Exception: ' . $exception);
                }
            }
        }
        else
        {
            $this->handleException('Invalid products id found!');
        }

    }


    /**
     * @param $fieldValue
     * @param $mappingType
     * @param string $loadByFieldName
     * @return Models\MappingModel
     */
    protected function loadProductMapping($fieldValue, $mappingType, $loadByFieldName = 'BFID')
    {
        /** @var Models\MappingModel $mappingModel */
        $mappingModel	= clone $this->_mappingModel;

        if ($loadByFieldName === 'BFID')
        {
            $mappingModel->loadByBfId($fieldValue, $mappingType);
        }

        if ($loadByFieldName === 'SYSTEMID')
        {
            $mappingModel->loadBySystemId($fieldValue, $mappingType);
        }

        if(false === $mappingModel->isLoaded())
        {
            ($loadByFieldName === 'BFID') ? $mappingModel->setBfId($fieldValue) : "";
            ($loadByFieldName === 'SYSTEMID') ? $mappingModel->setSystemId($fieldValue) : "";
            $mappingModel->setType($mappingType);
            $mappingModel->setOxShopId(Utils\OxidRegistry::getActiveShopId());
        }

        return $mappingModel;
    }


    /**
     * @param \SimpleXMLElement $data product data
     * @param string $nodeName node name
     * @param boolean $checkCurrentValue check current value
     */
    protected function handleStatus(\SimpleXMLElement $data, $nodeName = 'Active', $checkCurrentValue = false)
    {
        $status = self::STATUS_INACTIVE_ID;

        if (self::STATUS_ACTIVE_ID == $this->getIntegerValue($data->$nodeName)) {
            $status = self::STATUS_ACTIVE_ID;
        }

        if (true === $checkCurrentValue && self::STATUS_INACTIVE_ID == $this->getProductModel()->getArticleDataByKey('oxarticles__oxactive')) {
            $status = self::STATUS_INACTIVE_ID;
        }

        $this->getProductModel()->setArticleDataEntry('oxarticles__oxactive', $status);
    }


    /**
     * @param \SimpleXMLElement $productsData
     * @throws \bfox\saleschannel\classes\exception\ConfigurationException
     */
    private function handleTax(\SimpleXMLElement $productsData)
    {
        $tax   = null;
        $taxId = $this->getIntegerValue($productsData->TaxId);

        // reduced tax
        if (self::TAXID_REDUCED == $taxId) {
            $tax = Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_TAX_REDUCED);
        }

        $this->getProductModel()->setArticleDataEntry('oxarticles__oxvat', $tax);
    }


    /**
     * @param \SimpleXMLElement $productsData product data
     * @param string $nodeName node name
     */
    private function handleSku(\SimpleXMLElement $productsData, $nodeName = 'ItemNumber')
    {
        $itemNumber = $this->getStringValue($productsData->$nodeName);
        $this->getProductModel()->setArticleDataEntry('oxarticles__oxartnum', $itemNumber);
    }

    /**
     * @param \SimpleXMLElement $productsData products data
     */
    private function handleManufacturer(\SimpleXMLElement $productsData)
    {
        $manufacturerId          = '';
        $bfExternManufacturersId = $this->getIntegerValue($productsData->ManufacturerId);

        if (0 < $bfExternManufacturersId) {
            $mappingModel = clone $this->_mappingModel;
            $mappingModel->loadByBfId($bfExternManufacturersId, Models\MappingModel::KEY_TYPE_MANUFACTURERS);

            if (true === $mappingModel->isLoaded()) {
                $manufacturerId = $mappingModel->getSystemId();
            } else {
                $this->handleException('Manufacturer mapping not found! Products id: ' . $this->getIntegerValue($productsData->ProductId));
            }
        }

        $this->getProductModel()->setArticleDataEntry('oxarticles__oxmanufacturerid', $manufacturerId);
    }


    /**
     * @param \SimpleXMLElement $productsData products data
     */
    private function handleCategories(\SimpleXMLElement $productsData)
    {
        if (false === empty($productsData->Categories) && false === empty($productsData->Categories->Category))
        {
            foreach ($productsData->Categories->Category as $categoryData)
            {
                $bfCategoryId = $this->getIntegerValue($categoryData->CategoryId);

                if ($bfCategoryId > 0)
                {
                    $sortOrder = 0;

                    if((bool) $categoryData->CategoryProductsSorting)
                    {
                        $sortOrder = $this->getIntegerValue($categoryData->CategoryProductsSorting) + 1;
                    }

                    $this->getProductModel()->addArticleCategoryData($bfCategoryId, $sortOrder);
                }
                else
                {
                    $this->handleException('Category id is missing! Products id: ' . $this->getIntegerValue($productsData->ProductId));
                }
            }
        }
    }

    /**
     * @param \SimpleXMLElement $productsData products data
     * @param bool $isVariationData is variation data
     */
    private function handleCustomAttributes(\SimpleXMLElement $productsData, $isVariationData = true, $mergeWithExistingAttributes = false)
    {
        $collectedAttributesData = $this->_importAttributes->handleAttributes($productsData, $isVariationData);

        if($mergeWithExistingAttributes === true) {
            $arr = array_merge($this->getProductModel()->getArticleAttributesData(), $collectedAttributesData);
            $this->getProductModel()->setArticleAttributesData($arr);
        } else {
            $this->getProductModel()->setArticleAttributesData($collectedAttributesData);
        }
    }


    /**
     * @param \SimpleXMLElement $productsData product data
     */
    private function handleDescriptions(\SimpleXMLElement $productsData)
    {
        if (empty($productsData->Descriptions) === false)
        {
            foreach ($productsData->Descriptions->children() as $productsDescription)
            {
                $languageCode = $this->getStringValue($productsDescription['lang']);

                // only import oxid known language code descriptions
                if ($this->hasLanguageKey($languageCode) === true) {
                    $languageData = $this->getLanguageByKey($languageCode);
                    $languageId   = $languageData->id;

                    // title
                    $this->getProductModel()->setArticleLanguageData($languageId, 'oxarticles__oxtitle', $this->getStringValue($productsDescription->Title));

                    // short description
                    $this->getProductModel()->setArticleLanguageData($languageId, 'oxarticles__oxshortdesc', $this->getStringValue($productsDescription->ShortDescription));

                    // long description
                    $this->getProductModel()->setArticleLanguageExtendsData($languageId, 'oxarticles__oxlongdesc', $this->getStringValue($productsDescription->LongDescription));

                    // search keys
                    $this->getProductModel()->setArticleLanguageData($languageId, 'oxarticles__oxsearchkeys', $this->getStringValue($productsDescription->SearchKeys));

                    // url
                    $this->getProductModel()->setArticleLanguageData($languageId, 'oxarticles__oxurldesc', $this->getStringValue($productsDescription->ProductUrl));
                }
            }
        } else {
            $this->handleException('No descriptions found for products id: ' . $this->getIntegerValue($productsData->ProductId));
        }
    }


    /**
     * @param \SimpleXMLElement $productsData products data
     * @param string $imageNodeName image node name
     * @param boolean $resetCurrentArticleImageCounter
     */
    private function handleImages(\SimpleXMLElement $productsData, $imageNodeName = 'Images', $resetCurrentArticleImageCounter = false)
    {
        $hasChanged = false;

        if (false === empty($productsData->$imageNodeName)) {
            $imageCounter = 0;

            if (false === $resetCurrentArticleImageCounter) {
                $imageCounter = $this->getProductModel()->getCurrentArticleImageCounter();
            }

            foreach ($productsData->$imageNodeName->children() as $imageData) {
                $imageCounter++;

                $changed = $this->getIntegerValue($imageData['changed']);

                if (1 == $changed) {
                    $hasChanged = true;
                }

                $imagePath = $this->getStringValue($imageData->Path);

                $this->getProductModel()->addArticleImageData($imageCounter, $imagePath);
            }
        }

        if (true === $hasChanged) {
            $this->getProductModel()->setArticleImageDeleteFlag(true);
        }
    }

    /**
     * handleMedia.
     *
     * @param \SimpleXMLElement $productsData products data
     * @param string $mediaNodeName media node name
     */
    private function handleMedia(\SimpleXMLElement $productsData, $mediaNodeName = 'Media')
    {
        $hasChanged					= false;

        if(false === empty($productsData->$mediaNodeName))
        {
            foreach($productsData->$mediaNodeName->children() as $mediaEntryData)
            {
                $mediaPath	= $this->getStringValue($mediaEntryData->Path);
                $mediaName  = $this->getStringValue($mediaEntryData->Name);

                if('' != $mediaPath && '' != $mediaName)
                {
                    $changed = $this->getIntegerValue($mediaEntryData['changed']);
                    if(1 == $changed)
                    {
                        $hasChanged	= true;
                    }

                    $this->getProductModel()->addArticleMediaData($mediaPath, $mediaName);
                }
                else
                {
                    $this->handleException('Media entry data is missing!');
                }
            }
        }

        $this->getProductModel()->setArticleMediaDeleteFlag($hasChanged);
    }


    /**
     * @param \SimpleXMLElement $productsVariationsData products variations data
     */
    private function handleVariationsData(\SimpleXMLElement $productsVariationsData, $mergeWithExistingAttributes = false)
    {
        // products variations ean
        $this->handleEan($productsVariationsData);

        // products variations prices
        $this->handlePrices($productsVariationsData);

        // products variations unit data
        $this->handleUnitData($productsVariationsData);

        // products variations package data
        $this->handlePackageData($productsVariationsData);

        // products variations attributes
        $this->handleCustomAttributes($productsVariationsData, true, $mergeWithExistingAttributes);

        // products variations stock data
        $this->handleStockData($productsVariationsData);

        // products variations delivery time data
        $this->handleDeliveryTime($productsVariationsData);

        // product variations images
        $this->handleImages($productsVariationsData, 'VariationImages');

        // products media
        $this->handleMedia($productsVariationsData, 'VariationMedia');
        $this->handleManufacturerItemNumber($productsVariationsData);
    }

    public function handleManufacturerItemNumber(\SimpleXMLElement $productsVariationsData) {
        $manufacturerItemNumber = $this->getStringValue($productsVariationsData->ManufacturerItemNumber);

        if(strlen($manufacturerItemNumber) > 0) {
            $this->getProductModel()->setArticleDataEntry('oxarticles__oxmpn', $manufacturerItemNumber);
        }
    }


    /**
     * @param \SimpleXMLElement $productsVariationsData products variations data
     */
    private function handleEan(\SimpleXMLElement $productsVariationsData)
    {
        $ean = $this->getStringValue($productsVariationsData->EAN);

        $this->getProductModel()->setArticleDataEntry('oxarticles__oxean', $ean);
    }


    /**
     * @param \SimpleXMLElement $productsVariationsData product variations data
     */
    protected function handlePrices(\SimpleXMLElement $productsVariationsData)
    {
        $productModel = $this->getProductModel();

        /** @var ImportProductPrices $importProductPrices */
        $importProductPrices = new ImportProductPrices( "", null, $productModel);

        $importProductPrices->processPricesImport($productsVariationsData);
        $return = $importProductPrices->returnProcessedProductModel();

        if ($return !== false) {
            $this->setProductModel($return);
        }
    }


    /**
     * @param \SimpleXMLElement $productsVariationsData product variations data
     */
    protected function handleUnitData(\SimpleXMLElement $productsVariationsData)
    {
        $unitQuantity = $this->getFloatValue($productsVariationsData->ContentQuantity);
        $unitName     = $this->getUnitName($productsVariationsData);

        if(0 < $unitQuantity && '' != $unitName)
        {
            $this->getProductModel()->setArticleDataEntry('oxarticles__oxunitquantity', $unitQuantity);
            $this->getProductModel()->setArticleDataEntry('oxarticles__oxunitname', $unitName);
        }
        else
        {
            $this->getProductModel()->setArticleDataEntry('oxarticles__oxunitquantity', 0);
            $this->getProductModel()->setArticleDataEntry('oxarticles__oxunitname', '');
        }
    }

    /**
     * @param \SimpleXMLElement $productsVariationsData products variations data
     * @return string unit name
     */
    private function getUnitName(\SimpleXMLElement $productsVariationsData)
    {
        $result = '';

        if (false === empty($productsVariationsData->Descriptions)) {
            $defaultLanguageId = Utils\OxidRegistry::getDefaultLanguageId();

            foreach ($productsVariationsData->Descriptions->children() as $productsVariationsDescription) {
                $languageCode = $this->getStringValue($productsVariationsDescription['lang']);
                $languageData = $this->getLanguageDataByLanguageCode($languageCode);
                $languageId   = $languageData->id;

                if ($languageId == $defaultLanguageId) {
                    $result = $this->getStringValue($productsVariationsDescription->ContentUnit);
                    break;
                }
            }
        }

        return $result;
    }

    /**
     * @param \SimpleXMLElement $productsVariationsData products variations data
     */
    private function handlePackageData(\SimpleXMLElement $productsVariationsData)
    {
        foreach ($this->getPackageSettings() as $packageItemName => $packageUnitFactor) {
            $packageValue = 0;

            if (false === empty($productsVariationsData->Package)) {
                $packageValue = $this->getFloatValue($productsVariationsData->Package->$packageItemName);
            }

            $this->getProductModel()->setArticleDataEntry('oxarticles__ox' . strtolower($packageItemName), $packageValue * $packageUnitFactor);
        }
    }

    /**
     * @return array package settings
     */
    private function getPackageSettings()
    {
        return array(
            'Weight' => 0.001,
            'Width'  => 0.001,
            'Height' => 0.001,
            'Length' => 0.001
        );
    }


    /**
     * @param \SimpleXMLElement $productsVariationsData products variations data
     */
    protected function handleStockData(\SimpleXMLElement $productsVariationsData)
    {
        $stock = $this->getIntegerValue($productsVariationsData->Stock);

        $this->getProductModel()->setArticleDataEntry('oxarticles__oxstock', $stock);
    }

    /**
     * Pay attention:
     * Currently BF only delivers one delivery text. As result this text is used as stocktext for the default language.
     *
     * @param \SimpleXMLElement $productsVariationsData products variations data
     */
    protected function handleDeliveryTime(\SimpleXMLElement $productsVariationsData)
    {
        $deliveryTime = $this->getStringValue($productsVariationsData->DeliveryTime);

        $this->getProductModel()->setArticleLanguageData(Utils\OxidRegistry::getDefaultLanguageId(), 'oxarticles__oxstocktext', $deliveryTime);
    }


    /**
     * @param \SimpleXMLElement $productsData products data
     */
    private function handleVariations(\SimpleXMLElement $productsData)
    {
        $productsVariations = $productsData->Variations;
        $parentArticleModel = $this->getProductModel();
        $variationsCounter  = 0;
        $variationsStockSum = 0;


        foreach ($productsVariations->children() as $productsVariationsData)
        {
            try
            {
                $bfProductsVariationsId = $this->getIntegerValue($productsVariationsData->VariationId);

                $productMapping = $this->loadProductMapping($bfProductsVariationsId, Models\MappingModel::KEY_TYPE_PRODUCTS_VARIATIONS, Models\MappingModel::TABLE_FIELD_BFID);

                $productModel = clone $this->_emptyProductModel;
                $productModel->loadWithMappingModel($productMapping);
                $this->setProductModel($productModel);

                if ($this->getProductModel()->getId() === $parentArticleModel->getId())
                {
                    $this->getProductModel()->initOxArticle();
                    $this->getProductModel()->getMappingModel()->setValidSystemId(false);

                    $this->logRowEntry(
                        'Reseted Variation ' . $productsVariationsData->VariationId . ' for duplicate OXID ' . $this->getProductModel()->getId(), false
                    );
                }

                // product oxshopid
                $this->getProductModel()->setArticleDataEntry('oxarticles__oxshopid', Utils\OxidRegistry::getActiveShopId());

                // set parent ox images
                $this->getProductModel()->setParentOxImages($parentArticleModel->getOxImages());

                // set parent article relation
                $this->getProductModel()->setArticleDataEntry('oxarticles__oxparentid', $parentArticleModel->getId());

                // products variations sorting
                $this->handleSorting($productsVariationsData);

                // products variations sku
                $this->handleSku($productsVariationsData, 'VariationItemNumber');

                // products variations status
                $this->handleStatus($productsVariationsData, 'VariationActive');

                // products variations options
                $this->handleOptions($productsVariationsData, $parentArticleModel);

                $this->handleVariationsData($productsVariationsData);

                // products variations descriptions
                $this->handleDescriptions($productsData);

                $this->handleManufacturer($productsData);

                // save products variations
                $this->getProductModel()->saveAll();

                $variationsStockSum += $this->getIntegerValue($this->getProductModel()->getArticleDataByKey('oxarticles__oxstock'));
                $variationsCounter++;

            }
            catch(ImportExportException $exception)
            {
                $this->handleException('Error while importing variation with variations id: ' . $productsVariationsData->VariationId. '! Exception: ' . $exception);
            }
        }

        // save parent article changes
        $parentArticleModel->setArticleDataEntry('oxarticles__oxvarcount', $variationsCounter);
        $parentArticleModel->setArticleDataEntry('oxarticles__oxvarstock', $variationsStockSum);
        $parentArticleModel->setArticleDataEntry('oxarticles__oxstock', 0);

        $parentArticleModel->save();

        unset($parentArticleModel);
    }


    /**
     * @param \SimpleXMLElement $productsVariationsData product variations data
     * @param Models\ProductModel $parentArticleModel parent article model
     */
    private function handleOptions(\SimpleXMLElement $productsVariationsData, Models\ProductModel $parentArticleModel)
    {
        $collectedOptions = array();

        foreach ($productsVariationsData->Options->children() as $optionData)
        {
            if (false === empty($optionData->Translations))
            {
                foreach ($optionData->Translations->children() as $translationData)
                {
                    $firstLanguageEntry = false;
                    $languageCode       = $this->getStringValue($translationData['lang']);
                    $optionName         = $this->getStringValue($translationData->OptionName);
                    $optionValue        = $this->getStringValue($translationData->OptionValue);

                    $languageData = $this->getLanguageDataByLanguageCode($languageCode);

                    if ($languageData) {
                        if (false === array_key_exists($languageData->id, $collectedOptions))
                        {
                            $collectedOptions[$languageData->id] = array(
                                'optionNames'  => '',
                                'optionValues' => ''
                            );

                            $firstLanguageEntry = true;
                        }

                        if (false === $firstLanguageEntry)
                        {
                            $collectedOptions[$languageData->id]['optionNames']  .= ' | ';
                            $collectedOptions[$languageData->id]['optionValues'] .= ' | ';
                        }

                        $collectedOptions[$languageData->id]['optionNames']  .= $optionName;
                        $collectedOptions[$languageData->id]['optionValues'] .= $optionValue;
                    }
                }
            }
        }

        foreach ($collectedOptions as $languageId => $optionData) {
            $parentArticleModel->setArticleLanguageData($languageId, 'oxarticles__oxvarname', $optionData['optionNames']);

            $this->getProductModel()->setArticleLanguageData($languageId, 'oxarticles__oxvarselect', $optionData['optionValues']);
        }
    }


    /**
     * @param \SimpleXMLElement $productsData product data
     */
    private function handleSorting(\SimpleXMLElement $productsData)
    {
        $sort = $this->getIntegerValue($productsData['sort']);

        $this->getProductModel()->setArticleDataEntry('oxarticles__oxsort', $sort);
    }


    /**
     * Validates general xml product structure.
     *
     * @param \SimpleXMLElement $productsData products data
     * @return boolean is valid product data
     */
    private function isValid(\SimpleXMLElement $productsData)
    {
        $result       = true;
        $bfProductsId = $this->getIntegerValue($productsData->ProductId);

        // first check variation structure
        if (true === empty($productsData->Variations) || true === empty($productsData->Variations->Variation)) {
            $this->handleException('No Variations element found for products id: ' . $bfProductsId);

            $result = false;
        } else {
            // check description structure
            if (true === empty($productsData->Descriptions)
                || true === empty($productsData->Descriptions->Description)) {
                $this->handleException('Invalid description structure found for products id: ' . $bfProductsId);

                $result = false;
            }
        }

        return $result;
    }

    /**
     * @param $productModel
     */
    protected function setProductModel($productModel)
    {
        $this->_currentProductModel = $productModel;
    }


    /**
     * @return Models\ProductModel
     */
    protected function getProductModel()
    {
        return $this->_currentProductModel;
    }


    protected function initProductModel()
    {
        $this->_currentProductModel = clone $this->_emptyProductModel;
    }

    /**
     * @param $deletionSetting
     */
    public function deleteAll($deletionSetting)
    {
        $articleListModel = new Oxid\Core\Model\ListModel();
        $articleListModel->init($deletionSetting[0]["object"], $deletionSetting[0]["table"]);
        $articleListModel->getList();

        foreach($articleListModel->arrayKeys() as $articleID)
        {
            $articleModel   = clone $this->_emptyProductModel;
            $articleModel->delete($articleID);
        }
    }
}