<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 17.12.18
 * Time: 21:18
 */

namespace bfox\saleschannel\classes\controller\transfer;

use bfox\saleschannel\classes\util as Utils;
use bfox\saleschannel\classes\model as Models;

class AbstractTransfer
  {


    /**
     * status id
     */
    const STATUS_ACTIVE_ID		= 1,
        STATUS_INACTIVE_ID		= 0;


    /** @var Models\MappingModel */
    protected $_mappingModel;

    /**  @var string */
    protected $fileLocation = null;

    /** @var Models\ShopModel */
    private $shopModel = null;

    /** @var integer */
    private $transferCounter = 0;



      /**
       * Constructor.
       */
      public function __construct()
      {
          $shopModel = oxNew(Models\ShopModel::class);
          $shopModel->load(Utils\OxidRegistry::getActiveShopId());
          $this->setShopModel($shopModel);
      }



    /**
     * handleException.
     *
     * @param string $logMessage log message
     */
    protected function handleException($logMessage)
    {
        Utils\LogManager::getInstance()->error($logMessage);
    }

    /**
     * logRowEntry.
     *
     * @param string $logMessage log message
     * @param boolean $increaseCounter increase counter
     */
    protected function logRowEntry($logMessage, $increaseCounter = true)
    {
        if(true === $increaseCounter)
        {
            $this->transferCounter++;
        }

        Utils\LogManager::getInstance()->debug(
            sprintf('[%s]>(%d) %s',
                get_class($this),
                $this->transferCounter,
                $logMessage
            )
        );
    }

    /**
     * getFileLocation.
     *
     * @return string file location
     */
    protected function getFileLocation()
    {
        return $this->fileLocation;
    }

    /**
     * setFileLocation.
     *
     * @param string $fileLocation file location
     */
    protected function setFileLocation($fileLocation)
    {
        $this->fileLocation			= $fileLocation;
    }

    /**
     * getShopModel.
     *
     * @return Models\ShopModel $shopModel shops model
     */
    protected function getShopModel()
    {
        return $this->shopModel;
    }

    /**
     * setShopModel.
     *
     * @param Models\ShopModel $shopModel shops model
     */
    private function setShopModel(Models\ShopModel $shopModel)
    {
        $this->shopModel = $shopModel;
    }

}