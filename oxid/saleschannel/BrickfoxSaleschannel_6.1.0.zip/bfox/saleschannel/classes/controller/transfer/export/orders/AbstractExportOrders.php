<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 26.02.19
 * Time: 13:03
 */

namespace bfox\saleschannel\classes\controller\transfer\export\orders;

use bfox\saleschannel\classes\controller\transfer\export as Exports;
use bfox\saleschannel\classes\model as Models;
use bfox\saleschannel\classes\payment as Payments;
use bfox\saleschannel\classes\util as Utils;
use \OxidEsales\Eshop as Oxid;

abstract class AbstractExportOrders extends Exports\AbstractExport
{
    const ORDERS_COSTS_CHANGING_TYPE_ABSOLUTE = 0;

    /**
     * ###################################################################
     *              PROPERTIES
     * ###################################################################
     */

    /**
     * Additional Infos for order export
     * @var array
     */
    protected $orderAddInfos = [];



    /**
     * ###################################################################
     *              METHODS
     * ###################################################################
     */


    /**
     * Oxid will create for all orders an oxuser database record.
     * All oxuser database records have an oxcustnr value.
     * Only records having an oxpassword value are valid customer accounts.
     * Here all customer id's will be exported.
     *
     * @param Models\OrderModel $oxOrderModel ox order model
     */
    protected function addCustomerId(Models\OrderModel $oxOrderModel)
    {
        $oxUserId = $this->getModelValue($oxOrderModel, 'oxuserid');
        if (false === is_null($oxUserId) && '' != $oxUserId)
        {
            $oxUserModel = oxNew(Oxid\Application\Model\User::class);
            $oxUserModel->load($oxUserId);

            if (true === $oxUserModel->isLoaded())
            {
                if ($this->getOverwriteCustNr() && strlen(trim($this->getModelValue($oxUserModel, $this->getOverwriteCustNr()))) > 0) {
                    $this->writeElement('CustomerId', $this->getModelValue($oxUserModel, $this->getOverwriteCustNr()));
                }
                else {
                    $this->writeElement('CustomerId', $this->getModelValue($oxUserModel, 'oxcustnr'));
                }

//                if ($this->getOverwriteCustNr()) {
//                    $this->addAdditionalInfo('ShopNumber', str_pad($this->getModelValue($oxUserModel, 'oxcustnr'), 14, '0', STR_PAD_LEFT));
//                }

                if ($this->getExportTargetgroup()) {
                    $customerGroup = str_pad(trim($this->getModelValue($oxUserModel, 'nfctargetgroup')), 2, '0', STR_PAD_LEFT);
                    $this->addAdditionalInfo('CustomerGroup', $customerGroup);
                }

                $this->writeAdditionalInfos();
            }
        }
    }

    /**
     * getOverwriteCustNr.
     *
     * @return bool|string overwrite customer number with field name
     */
    private function getOverwriteCustNr()
    {
        $fieldName = Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_OVERWRITE_CUST_NR);

        if (strlen(trim($fieldName)) > 0) {
            return trim($fieldName);
        }
        else {
            return false;
        }
    }

    /**
     * getExportTargetgroup.
     *
     * @return bool export customer target group
     */
    private function getExportTargetgroup()
    {
        return (bool) Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_EXPORT_TARGETGROUP);
    }

    protected function addAdditionalInfo($key, $value) {
        $this->orderAddInfos[$key] = $value;
    }

    protected function clearAdditionalInfos() {
        $this->orderAddInfos = [];
    }

    protected function writeAdditionalInfos()
    {
        if (count($this->orderAddInfos) > 0)
        {
            $this->writeStartElement('OrderAddInfos');
            ksort($this->orderAddInfos);
            foreach ($this->orderAddInfos as $key => $value) {
                $this->writeStartElement('OrderAddInfo');
                $this->writeElement('Key', $key);
                $this->writeElement('Value', $value);
                $this->writeEndElement();
            }
            $this->writeEndElement();
        }
        $this->clearAdditionalInfos();
    }


    /**
     * @param Models\OrderModel $oxOrderModel order model
     */
    protected function addCostsChangingsData(Models\OrderModel $oxOrderModel)
    {
        $discount = $this->getModelValue($oxOrderModel, 'oxdiscount');
        $paymentCost = $this->getModelValue($oxOrderModel, 'oxpaycost');

        if ($discount > 0 || $paymentCost > 0)
        {
            $this->writeStartElement('CostsChangings');
            $this->addDiscount($discount);
            $this->addPaymentCosts($oxOrderModel, $paymentCost);
            $this->writeEndElement();
        }
    }

    private function addDiscount($discount)
    {
        $this->writeStartElement('CostsChanging');
        $this->writeElement('Type', self::ORDERS_COSTS_CHANGING_TYPE_ABSOLUTE);
        $this->writeElement('TypeValue', $this->formatPrice($discount));
        $this->writeElement('Value', $this->formatPrice($discount));
        $this->writeEndElement();
    }

    private function addPaymentCosts(Models\OrderModel $oxOrderModel, $paymentCost)
    {
        $oxPaymentType = $this->getModelValue($oxOrderModel, 'oxpaymenttype');

        $paymentModel = oxNew(Models\PaymentModel::class);
        $paymentModel->load($oxPaymentType);

        if (true === $paymentModel->isLoaded()) {
            $this->writeStartElement('CostsChanging');
            $this->writeElement('Type', $paymentModel->getPaymentType());
            $this->writeElement('TypeValue', $this->formatPrice($this->getModelValue($paymentModel, 'oxaddsum')));
            $this->writeElement('Value', $this->formatPrice($paymentCost));
            $this->writeEndElement();
        } else {
            $this->handleException(
                'Error while exporting order with order oxid: ' . $oxOrderModel->getId()
                . '! Could not load oxpayment with oxid: ' . $oxPaymentType
            );
        }
    }

    /**
     * @param Models\OrderModel $oxOrderModel ox order model
     */
    protected function addShipmentData(Models\OrderModel $oxOrderModel)
    {
        $shippingCost = $this->getModelValue($oxOrderModel, 'oxdelcost');

        if (0 < $shippingCost)
        {
            $this->writeElement('ShippingCost', $this->formatPrice($this->getModelValue($oxOrderModel, 'oxdelcost')));
        }

        $deliveryId = $this->getModelValue($oxOrderModel, 'oxdeltype');

        if (false === is_null($deliveryId) && '' != $deliveryId)
        {
            $oxDeliverySetModel = oxNew(Oxid\Application\Model\DeliverySet::class);
            $oxDeliverySetModel->load($deliveryId);

            if (true === $oxDeliverySetModel->isLoaded())
            {
                $this->writeElement('ShippingMethod', $this->getModelValue($oxDeliverySetModel, 'oxid'));
            }
            else
            {
                $this->handleException('Error while exporting order with order oxid: ' . $oxOrderModel->getId() . '! Could not load oxdeliveryset with oxid: ' . $deliveryId);
            }
        }
        else
        {
            $this->handleException('Error while exporting order with order oxid: ' . $oxOrderModel->getId() . '! oxdeltype is not set!');
        }
    }


    /**
     * @param Models\OrderModel $oxOrderModel ox order model
     */
    protected function addCouponsData(Models\OrderModel $oxOrderModel)
    {
        $voucherListModel = oxNew(Models\VoucherListModel::class);
        $voucherListModel->loadByOrderId($oxOrderModel->getId());

        // order has vouchers
        if (0 < sizeof($voucherListModel)) {
            $this->writeStartElement('Coupons');

            foreach ($voucherListModel as $voucherModel)
            {
                $oxVoucherSerieModel = $voucherModel->getSerie();

                if (true === $oxVoucherSerieModel->isLoaded())
                {
                    $voucherReduceType = $voucherModel->getVoucherReduceType();

                    if (false === is_null($voucherReduceType))
                    {
                        $this->writeStartElement('Coupon');

                        // voucher extern id
                        $this->writeElement('ExternId', $voucherModel->getId());

                        // voucher code
                        $this->writeElement('Code', $this->getModelValue($voucherModel, 'oxvouchernr'));

                        // voucher type
                        $this->writeElement('Type', $voucherModel->getVoucherType());

                        // voucher reduce type
                        $this->writeElement('ReduceType', $voucherReduceType);

                        // rebate
                        $this->writeElement('Rebate', $this->getModelValue($oxVoucherSerieModel, 'oxdiscount'));

                        // voucher serie title
                        $this->writeElement('Title', $this->getModelValue($oxVoucherSerieModel, 'oxserienr'));

                        // voucher discount
                        $this->writeElement('CalculatedRebate', $this->getModelValue($voucherModel, 'oxdiscount'));

                        // voucher group
                        $this->addCouponGroupData($oxVoucherSerieModel);

                        // voucher order lines
                        $this->addCouponOrderLinesData($oxOrderModel, $voucherModel);

                        $this->writeEndElement();
                    }
                    else
                    {
                        $this->handleException('Invalid voucher reduce type for voucher' . $voucherModel->getId() . '! Order id: ' . $oxOrderModel->getId());
                    }
                }
                else
                {
                    $this->handleException('No voucher serie found for voucher: ' . $voucherModel->getId() . '! Order id: ' . $oxOrderModel->getId());
                }
            }

            $this->xmlWriter->endElement();
        }
    }


    /**
     * @param Oxid\Application\Model\VoucherSerie $oxVoucherSerieModel ox voucher serie model
     */
    private function addCouponGroupData(Oxid\Application\Model\VoucherSerie $oxVoucherSerieModel)
    {
        // voucher series name
        $this->writeStartElement('Group');

        // extern id
        $this->writeElement('ExternId', $oxVoucherSerieModel->getId());

        // voucher serie title
        $this->writeElement('Title', $this->getModelValue($oxVoucherSerieModel, 'oxserienr', true), true);

        $this->writeEndElement();
    }


    /**
     * @param Models\OrderModel $oxOrderModel Order
     * @param Models\VoucherModel $voucherModel ox voucher serie model
     */
    private function addCouponOrderLinesData(Models\OrderModel $oxOrderModel, Models\VoucherModel $voucherModel)
    {
        $orderLinesData = $voucherModel->getVoucherOrderLinesData($oxOrderModel);

        if (0 < count($orderLinesData))
        {
            $voucherReduceType = $voucherModel->getVoucherReduceType();

            $this->writeStartElement('OrderLineReferences');

            foreach ($orderLinesData as $oxOrderLineId => $oxCouponOrderLineData)
            {
                $this->writeStartElement('OrderLineReference');
                $this->writeElement('OrderLineId', $oxOrderLineId);

                // export for percent vouchers calculated rebate
                if (Models\VoucherModel::BF_REDUCE_TYPE_RELATIVE == $voucherReduceType)
                {
                    $this->writeElement('CalculatedRebate', $oxCouponOrderLineData[Models\VoucherModel::FIELD_DISCOUNT]);
                }

                $this->writeEndElement();
            }
            $this->writeEndElement();
        }
    }


    /**
     * @param Models\OrderModel $oxOrderModel ox order model
     */
    protected function addOrderLinesData(Models\OrderModel $oxOrderModel)
    {
        $orderArticleListModel = $oxOrderModel->getOrderArticles();
        $orderItemsCount       = sizeof($orderArticleListModel);

        $this->writeStartElement('OrderLines');
        $this->writeAttribute('count', $orderItemsCount);

        $orderItemCounter = 1;

        foreach ($orderArticleListModel as $orderArticleModel)
        {
            /** @var Models\ProductModel $productModel */
            $productModel = oxNew(Models\ProductModel::class);

            $productId = $orderArticleModel->oxorderarticles__oxartid->value;

            $mappingModel =  clone $this->_mappingModel;
            $mappingModel->loadBySystemId($productId, Models\MappingModel::KEY_TYPE_PRODUCTS_VARIATIONS);

            $productModel->loadWithMappingModel($mappingModel);

            if ($productModel->isLoaded() === true)
            {
                $bfProductsVariationsId = $productModel->getMappingModel()->getBfId();
                $bfProductsId           = $productModel->getBfProductsId();

                if (false === is_null($bfProductsVariationsId) && false === is_null($bfProductsId))
                {
                    $this->writeStartElement('OrderLine');
                    $this->writeAttribute('num', $orderItemCounter);

                    $this->writeElement('OrderLineId', $orderArticleModel->getId());
                    $this->writeElement('ProductId', $bfProductsId);
                    $this->writeElement('ProductName', $this->getModelValue($orderArticleModel, 'oxtitle', true), true);
                    $this->writeElement('ItemNumber', $this->getModelValue($orderArticleModel, 'oxartnum'));
                    $this->writeElement('EAN', $this->getModelValue($productModel, 'oxean'));

                    $this->writeElement('VariationId', $bfProductsVariationsId);
                    $this->writeElement('QuantityOrdered', $this->round($this->getModelValue($orderArticleModel, 'oxamount')));
                    $this->writeElement('ProductsPriceTotal', $this->formatPrice($this->getModelValue($orderArticleModel, 'oxbrutprice')));
                    $this->writeElement('ProductsPriceTotalNetto', $this->formatPrice($this->getModelValue($orderArticleModel, 'oxnetprice')));

                    $this->writeElement('VatPriceTotal', $this->formatPrice($this->getModelValue($orderArticleModel, 'oxvatprice')));
                    $this->writeElement('ProductsPrice', $this->formatPrice($this->getModelValue($orderArticleModel, 'oxbprice')));
                    $this->writeElement('ProductsPriceNetto', $this->formatPrice($this->getModelValue($orderArticleModel, 'oxnprice')));
                    $this->writeElement('TaxRate', $this->formatPrice($this->getModelValue($orderArticleModel, 'oxvat')));

                    $oxpersparamSerialized = $this->getModelValue($orderArticleModel, 'oxpersparam');

                    if(strlen($oxpersparamSerialized) > 0)
                    {
                        $oxPersParams = unserialize($oxpersparamSerialized);

                        if (count($oxPersParams) > 0) {
                            $this->writeStartElement('OrderLineAddInfos');

                            foreach ($oxPersParams as $key => $value) {
                                $this->writeStartElement('OrderLineAddInfo');
                                $this->writeElement('Key', $key);
                                $this->writeElement('Value', $value);
                                $this->writeEndElement();
                            }

                            $this->writeEndElement();
                        }
                    }

                    $this->writeEndElement();

                    $orderItemCounter++;
                }
                else
                {
                    $this->handleException('Error while exporting order with order oxid: ' . $oxOrderModel->getId() . ' and order item oxid: ' . $orderArticleModel->getId() . '! Could not find mapping. Product id: ' . $productId);
                }
            }
            else
            {
                $this->handleException('Error while exporting order with order oxid: ' . $oxOrderModel->getId() . ' and order item oxid: ' . $orderArticleModel->getId() . '! Product id: ' . $productId . ' not found!');
            }
        }

        $this->writeEndElement();
    }



    /**
     * @param Models\OrderModel $oxOrderModel order model
     */
    protected function addPaymentData(Models\OrderModel $oxOrderModel)
    {
        $paymentMethod = $this->getModelValue($oxOrderModel, 'oxpaymenttype');

        // payment method
        $this->writeElement('PaymentMethod', $paymentMethod);

        // payment cost
        $paymentCost = $this->getModelValue($oxOrderModel, 'oxpaycost');

        if (0 < $paymentCost)
        {
            $this->writeElement('PaymentCost', $this->formatPrice($paymentCost));
        }

        // payment method values
        $paymentHelper       = Payments\PaymentFactory::create($paymentMethod, $oxOrderModel);
        $paymentMethodValues = $paymentHelper->getPaymentMethodValues();

        if (0 < count($paymentMethodValues))
        {
            $this->writeStartElement('PaymentMethodValues');

            foreach ($paymentMethodValues as $key => $value)
            {
                $this->writeStartElement('PaymentMethodValue');
                $this->writeAttribute('key', $key);
                $this->writeAttribute('value', $value);
                $this->writeEndElement();
            }

            $this->writeEndElement();
        }
    }

}