<?php
/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 20.02.19
 * Time: 11:45
 */

namespace bfox\saleschannel\classes\controller\transfer\import\products;


use bfox\saleschannel\classes\model as Models;
use bfox\saleschannel\classes\controller\transfer\import as Imports;

class ImportProductsAssignments extends Imports\products\ImportProducts
{
    const ASSIGNMENT_TYPE_CROSSELLING = 'crossselling';
    const ASSIGNMENT_TYPE_ACCESSOIRES = 'accessories';
    const ASSIGNMENT_TYPE_KEY_MODEL = 'model';
    const ASSIGNMENT_TYPE_KEY_ARTICLESETTER = 'articleSetter';

    /** @var array */
    private $deletionList = array();

    /**
     */
    public function import()
    {
        $this->initDeletionList();

        parent::import();

        $this->deleteByDeletionList();
    }

    /**
     * @param \SimpleXMLElement $productsAssignmentsData products assignments data
     */
    protected function processImport(\SimpleXMLElement $productsAssignmentsData)
    {
        $bfProductsId = $this->getIntegerValue($productsAssignmentsData->ProductId);

        // only import products having a valid products id
        if (0 < $bfProductsId) {
            try {

                $productMapping = $this->loadProductMapping($bfProductsId, Models\MappingModel::KEY_TYPE_PRODUCTS, Models\MappingModel::TABLE_FIELD_BFID);
                $productModel = clone $this->_emptyProductModel;
                $productModel->loadWithMappingModel($productMapping);
                $this->setProductModel($productModel);

                // article found
                if (true === $this->getProductModel()->isLoaded()) {
                    if (false === empty($productsAssignmentsData->Assignments)) {
                        foreach ($productsAssignmentsData->Assignments->children() as $assignmentData) {
                            $bfProductOptionId = $this->getIntegerValue($assignmentData->ProductId);

                            if (0 < $bfProductOptionId) {
                                $assignmentType = $this->getStringValue($assignmentData['type']);
                                if (true === $this->isValidAssignmentType($assignmentType)) {
                                    $articleSetter = $this->getAssignmentTypeValueByKey($assignmentType, self::ASSIGNMENT_TYPE_KEY_ARTICLESETTER);

                                    $this->getProductModel()->{$articleSetter}($bfProductOptionId, $this->getIntegerValue($assignmentData['sort']));
                                    $this->removeFromDeletionList($assignmentType, $this->getProductModel()->getFieldData('oxid'));
                                } else {
                                    $this->handleException('Invalid assignment type: ' . $assignmentType);
                                }
                            } else {
                                $this->handleException('Object id is missing! Products id: ' . $bfProductsId);
                            }
                        }

                        $this->getProductModel()->saveAssignments();
                        $this->logRowEntry('Product with product id:' . $bfProductsId . ' imported!');
                    }
                }
            } catch (\Exception $exception) {
                $this->handleException('Error while importing product with product id: ' . $bfProductsId . '! Exception: ' . $exception);
            }
        } else {
            $this->handleException('Invalid products id found!');
        }
    }

    /**
     * @param string $assignmentType assignment type
     * @return boolean is valid assignment type
     */
    private function isValidAssignmentType($assignmentType)
    {
        return '' != $assignmentType && true === array_key_exists($assignmentType, $this->getValidAssignmentTypes());
    }

    /**
     * @return array valid assignment types
     */
    private function getValidAssignmentTypes()
    {
        return array(
            self::ASSIGNMENT_TYPE_CROSSELLING => array(
                self::ASSIGNMENT_TYPE_KEY_MODEL => 'ObjectToArticleModel',
                self::ASSIGNMENT_TYPE_KEY_ARTICLESETTER => 'addArticleObjectData'
            ),
            self::ASSIGNMENT_TYPE_ACCESSOIRES => array(
                self::ASSIGNMENT_TYPE_KEY_MODEL => 'AccessoireToArticleModel',
                self::ASSIGNMENT_TYPE_KEY_ARTICLESETTER => 'addArticleAccessoireData'
            )
        );
    }

    /**
     * @param string $assignmentType assignment type
     * @param string $key key
     * @return string assignment type value
     */
    private function getAssignmentTypeValueByKey($assignmentType, $key)
    {
        $assignmentTypes = $this->getValidAssignmentTypes();

        return $assignmentTypes[$assignmentType][$key];
    }

    /**
     * @return array deletion list
     */
    private function getDeletionList()
    {
        return $this->deletionList;
    }

    /**
     */
    private function initDeletionList()
    {
        $deletionList = array();
        $assignmentTypes = $this->getValidAssignmentTypes();

        foreach ($assignmentTypes as $assignmentType => $assignmentData) {

            switch ($assignmentData[self::ASSIGNMENT_TYPE_KEY_MODEL]) {
                case "ObjectToArticleModel":
                    $obj = new Models\ObjectToArticleModel();
                    $deletionList[$assignmentType] = call_user_func(array($obj, 'getExistingOxArticleIds'));
                    break;
                case "AccessoireToArticleModel":
                    $obj = new Models\AccessoireToArticleModel();
                    $deletionList[$assignmentType] = call_user_func(array($obj, 'getExistingOxArticleIds'));
                    break;
            }
        }

        $this->deletionList = $deletionList;
    }

    /**
     * @param string $deletionType deletion type
     * @param string $oxArticleId ox article id
     */
    private function removeFromDeletionList($deletionType, $oxArticleId)
    {
        if (!is_array($this->deletionList)) {
            echo "deletionList no array for deletionType \"$deletionType\" and oxArticleId \"$oxArticleId\"" . PHP_EOL;
        }
        if (!is_array($this->deletionList[$deletionType])) {
            echo "deletionList[deletionType] no array for deletionType \"$deletionType\" and oxArticleId \"$oxArticleId\"" . PHP_EOL;
        }

        if (true === array_key_exists($deletionType, $this->deletionList) && true === array_key_exists($oxArticleId, $this->deletionList[$deletionType])) {
            unset($this->deletionList[$deletionType][$oxArticleId]);
        }
    }

    /**
     * deleteByDeletionList.
     */
    private function deleteByDeletionList()
    {
        $deletionList = $this->getDeletionList();

        foreach ($deletionList as $assignmentType => $deleteAssignmentTypeData) {
            $referenceModelName = $this->getAssignmentTypeValueByKey($assignmentType, self::ASSIGNMENT_TYPE_KEY_MODEL) . '';

            switch ($referenceModelName) {
                case "ObjectToArticleModel":
                    $obj = new Models\ObjectToArticleModel();
                    break;
                case "AccessoireToArticleModel":
                    $obj = new Models\AccessoireToArticleModel();
                    break;
            }

            if (is_object($obj)) {
                foreach ($deleteAssignmentTypeData as $oxarticleId) {
                    $obj->deleteByOxArticleId($oxarticleId);
                }
            }

        }
    }
}