<?php

/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 04.03.19
 * Time: 13:10
 */
namespace bfox\saleschannel\classes\controller\transfer\import\orders;

use bfox\saleschannel\classes\model as Models;
use bfox\saleschannel\classes\util as Utils;
use bfox\saleschannel\classes\controller\transfer as Transfers;
use \OxidEsales\Eshop as Oxid;


class ImportOrdersStatus extends Transfers\import\AbstractImport
{

    /** @var Models\OrderModel */
    private $orderModel = null;

    /** @var bool */
    private $updateStocks = false;


    public function __construct($fileLocation, $mappingModel = null)
    {
        parent::__construct($fileLocation, $mappingModel);

        $this->updateStocks = Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_ORDER_STATUS_UPDATE_STOCKS);
    }


    /**
     * @return Models\OrderModel order model
     */
    private function getOrderModel()
    {
        return $this->orderModel;
    }

    /**
     * @param Models\OrderModel $orderModel order model
     * @return ImportOrdersStatus import order status
     */
    private function setOrderModel(Models\OrderModel $orderModel)
    {
        $this->orderModel = $orderModel;

        return $this;
    }



    /**
     * @param \SimpleXMLElement $ordersStatusData orders status data
     */
    protected function processImport(\SimpleXMLElement $ordersStatusData)
    {
        $ordersId = $this->getStringValue($ordersStatusData->OrderId);

        if (false === is_null($ordersId) && '' != $ordersId)
        {
            try
            {
                $orderModel = oxNew(Models\OrderModel::class);
                $orderModel->loadByOxOrderNr($ordersId);

                $ordersStatus = $this->getStringValue($ordersStatusData->OrderStatus);

                if ($orderModel->isLoaded() && $ordersStatus != '')
                {
                    $this->setOrderModel($orderModel);

                    switch ($ordersStatus)
                    {
                        case Models\OrderModel::IMPORT_ORDERS_STATUS_CANCELLED:
                            $this->handleCancelled();
                            break;

                        case Models\OrderModel::IMPORT_ORDERS_STATUS_PARTLY_RETURNED:
                            $this->handlePartlyReturned($ordersStatusData);
                            break;

                        case Models\OrderModel::IMPORT_ORDERS_STATUS_PAYED:
                            $this->handlePayed($ordersStatusData);
                            break;

                        case Models\OrderModel::IMPORT_ORDERS_STATUS_RETURNED:
                            $this->handleReturned($ordersStatusData);
                            break;

                        case Models\OrderModel::IMPORT_ORDERS_STATUS_SHIPPED:
                            $this->handleShipped($ordersStatusData);
                            break;

                        default:
                            $this->handleException('Undefined orders status! OrdersId ' . $ordersId . ' OrdersStatus: ' . $ordersStatus);
                            break;
                    }

                    $this->logRowEntry('Orderstatus with orders id:' . $ordersId . ' and orders status id: ' . $ordersStatus . ' imported!');
                }
                else
                {
                    $this->handleException('Error while importing orders status with ordersId: ' . $ordersId);
                }
            }
            catch (\Exception $exception)
            {
                $this->handleException('Error while importing orders status with ordersId: ' . $ordersId . ' Exception: ' . $exception);
            }
        }
        else
        {
            // ignore categories entry
            $this->handleException('Invalid orders status data. OrdersId:' . $ordersId);
        }
    }


    /**
     * cancelled = folder: finished & cancel order
     *
     * @return void
     */
    private function handleCancelled()
    {
        $this->handleException('Cancelling order. Order number: ' . $this->getOrderModel()->getId());
        $this->getOrderModel()->cancel($this->updateStocks);
    }


    /**
     * @param \SimpleXMLElement $ordersStatusData orders status data
     * @return void
     */
    private function handlePartlyReturned(\SimpleXMLElement $ordersStatusData)
    {
        if (false === empty($ordersStatusData->OrderLines) && false === empty($ordersStatusData->OrderLines->OrderLine))
        {
            foreach ($ordersStatusData->OrderLines->children() as $orderLine)
            {
                $orderArticleOxid = $this->getStringValue($orderLine->OrderLineId);

                $quantityShipped  = $this->getIntegerValue($orderLine->QuantityShipped);
                $quantityReturned = $this->getIntegerValue($orderLine->QuantityReturned);
                $quantity         = $quantityShipped - $quantityReturned;

                if ($quantity >= 0)
                {
                    $ordersLinesStatus = $this->getStringValue($orderLine->OrderLineStatus);
                    if ($ordersLinesStatus == Models\OrderModel::IMPORT_ORDERS_STATUS_PARTLY_RETURNED
                        || $ordersLinesStatus == Models\OrderModel::IMPORT_ORDERS_STATUS_RETURNED)
                    {
                        $this->updateOrderArticleAmount($orderArticleOxid, $quantity);
                    }
                }
                else
                {
                    $this->handleException('Quantity cannot be less than 0! (OrderId: ' . $this->getOrderModel()->getId() . ' OrderArticleOxid: ' . $orderArticleOxid . ' Quantity: ' . $quantity . ')');
                }
            }
            // important for new calculated prices...
            $this->getOrderModel()->recalculateOrder();
        }
        else
        {
            $this->handleException('Xml not correct. No ordersLines found for order ' . $this->getOrderModel()->getId());
        }
    }


    /**
     * payed = folder: new & set payed date
     *
     * @param \SimpleXMLElement $ordersStatusData orders status data
     * @return void
     */
    private function handlePayed(\SimpleXMLElement $ordersStatusData)
    {
        $this->getOrderModel()->pay($this->getStringValue($ordersStatusData->OrderStatusChanged));
    }


    /**
     * shipped = folder: finished & set tracking code & (if neccesary) set payed date
     *
     * @param \SimpleXMLElement $ordersStatusData orders status data
     * @return void
     */
    private function handleShipped(\SimpleXMLElement $ordersStatusData)
    {
        if (!$this->getOrderModel()->isCancelled())
        {
            $ordersStatusChanged = $this->getStringValue($ordersStatusData->OrderStatusChanged);

            $this->getOrderModel()->pay($ordersStatusChanged);

            if (false === empty($ordersStatusData->OrderLines) && false === empty($ordersStatusData->OrderLines->OrderLine))
            {
                foreach ($ordersStatusData->OrderLines->children() as $orderLine)
                {
                    $orderArticleOxid  = $this->getStringValue($orderLine->OrderLineId);
                    $ordersLinesStatus = $this->getStringValue($orderLine->OrderLineStatus);

                    switch ($ordersLinesStatus)
                    {
                        case Models\OrderModel::IMPORT_ORDERS_STATUS_SHIPPED:
                            $quantityShipped = $this->getIntegerValue($orderLine->QuantityShipped);
                            $this->updateOrderArticleAmount($orderArticleOxid, $quantityShipped);
                            break;

                        case Models\OrderModel::IMPORT_ORDERS_STATUS_CANCELLED:
                            $quantityOrdered   = $this->getIntegerValue($orderLine->QuantityOrdered);
                            $quantityCancelled = $this->getIntegerValue($orderLine->QuantityCancelled);
                            $quantity          = $quantityOrdered - $quantityCancelled;

                            if ($quantityCancelled > 0)
                            {
                                $this->cancelOrderArticle($orderArticleOxid, $quantity);
                            }
                            else
                            {
                                $this->handleException('Quantity cancelled cannot be null or less than 0! (OrderId: ' . $this->getOrderModel()->getId() . ' OrderArticleOxid: ' . $orderArticleOxid . ' Quantity: ' . $quantity . ')');
                            }
                            break;

                        default:
                            Utils\LogManager::getInstance()->warn('No possible ordersLines status found (OrderId: ' . $this->getOrderModel()->getId() . ' OrderArticleOxid: ' . $orderArticleOxid . ')');
                            break;
                    }
                }

                $trackingId = $this->getStringValue($ordersStatusData->ShippingTrackingId);
                $this->getOrderModel()->ship($trackingId, $ordersStatusChanged);

                // important for new calculated prices...
                $this->getOrderModel()->recalculateOrder();

                // send oxid shipping mail
                $this->getOrderModel()->sendShippingConfirmation();
            }
            else
            {
                $this->handleException('Xml not correct. No ordersLines found for order ' . $this->getOrderModel()->getId());
            }
        }
        else
        {
            $this->handleException('Order already cancelled. Cannot update. OrderId: ' . $this->getOrderModel()->getId());
        }
    }

    /**
     * Beim reduzieren der quantityOrdered auf 0 wird die MwSt nicht korrekt berechnet -> Oxid bug
     *
     * @param \SimpleXMLElement $ordersStatusData orders status data
     * @return void
     */
    private function handleReturned(\SimpleXMLElement $ordersStatusData)
    {
        if (false === empty($ordersStatusData->OrderLines) && false === empty($ordersStatusData->OrderLines->OrderLine))
        {
            foreach ($ordersStatusData->OrderLines->children() as $orderLine)
            {
                $orderArticleOxid = $this->getStringValue($orderLine->OrderLineId);
                $this->updateOrderArticleAmount($orderArticleOxid, 0);
            }
            // important for new calculated prices...
            $this->getOrderModel()->recalculateOrder();
        }
        else
        {
            $this->handleException('Xml not correct. No ordersLines found for order ' . $this->getOrderModel()->getId());
        }
    }


    /**
     * @param string $orderArticleOxid order article ox id
     * @param integer $amount amount
     * @return void
     */
    private function updateOrderArticleAmount($orderArticleOxid, $amount)
    {
        if($this->updateStocks === true)
        {
            $oxOrderArticleModel = $this->getOxOrderArticleModel($orderArticleOxid);

            if (false === is_null($oxOrderArticleModel)) {
                $oxOrderArticleModel->setNewAmount($amount);
            }
        }
    }

    /**
     * @param string $orderArticleOxid order article ox id
     * @param integer $amount amount
     * @return void
     */
    private function cancelOrderArticle($orderArticleOxid, $amount)
    {
        if($amount > 0)
        {
            $this->updateOrderArticleAmount($orderArticleOxid, $amount);
        }
    }

    /**
     * @param string $orderArticleOxid order article oxid
     * @return Oxid\Application\Model\OrderArticle ox order article model
     */
    private function getOxOrderArticleModel($orderArticleOxid)
    {
        $result = null;

        if ($orderArticleOxid != '')
        {
            $oxOrderArticleModel = oxNew(Oxid\Application\Model\OrderArticle::class);
            $oxOrderArticleModel->load($orderArticleOxid);

            if (true === $oxOrderArticleModel->isLoaded())
            {
                $result = $oxOrderArticleModel;
            }
            else
            {
                $this->handleException('oxOrderArticle cannot be loaded. Oxid: ' . $orderArticleOxid);
            }
        }

        return $result;
    }

}