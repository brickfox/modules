<?php

namespace bfox\saleschannel\classes\controller\transfer\import\attributes;

use bfox\saleschannel\classes\controller\transfer as Transfers;
use bfox\saleschannel\classes\exception as Exceptions;
use bfox\saleschannel\classes\model as Models;
use bfox\saleschannel\classes\util as Utils;

use \OxidEsales\Eshop as Oxid;


/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 08.02.19
 * Time: 18:42
 */
class ImportAttributes extends Transfers\import\AbstractImport
{


    /**
     * attribute value separator
     */
    const ATTRIBUTE_VALUE_SEPARATOR		= '#!#';

    /**
     * article attributes data
     * @var array article attributes data
     */
    private $articleAttributesData = array();

    /**
     * @var Models\AttributeModel
     */
    private $_attributeModel;




    public function __construct($fileLocation, $mappingModel = null, $attributeModel = null)
    {
        parent::__construct($fileLocation, $mappingModel);

        if (is_null($attributeModel))
        {
            $this->_attributeModel = oxNew(Models\AttributeModel::class);
        }
        else
        {
            $this->_attributeModel = $attributeModel;
        }
    }

    public function handleAttributes(\SimpleXMLElement $productsData, $isVariationData = true)
    {
        $attributesDataResult = [];
        $collectedAttributesData = [];

        if (false === empty($productsData->Attributes))
        {
            foreach ($productsData->Attributes as $attributeTypesData)
            {
                foreach ($attributeTypesData as $attributeTypeData)
                {
                    $attributeIsHidden = false;

                    if (false === empty($attributeTypeData['hidden']) && 1 == $this->getIntegerValue($attributeTypeData['hidden']))
                    {
                        $attributeIsHidden = true;
                    }

                    if (false === empty($attributeTypeData->Translations))
                    {
                        if (isset($collectedAttributesData[$this->getStringValue($attributeTypeData['id'])]) === false) {
                            $collectedAttributesData[$this->getStringValue($attributeTypeData['id'])] = [
                                'attributeIsHidden' => $attributeIsHidden,
                                'attributeId' => $this->getStringValue($attributeTypeData['id']),
                                'attributeCode' => $this->getStringValue($attributeTypeData['code']),
                                'attributeOxid' => $this->generateAttributeOxId(
                                    $this->getStringValue($attributeTypeData['id']), $this->getStringValue($attributeTypeData['code'])
                                ),
                                'languages' => [],
                                'isVariationData' => $isVariationData
                            ];
                        }

                        // collect attribute data
                        foreach ($attributeTypeData->Translations->children() as $translationData)
                        {
                            $languageCode  = $this->getStringValue($translationData['lang']);
                            $attributeName = $this->getStringValue($translationData->Name);

                            // only import oxid known language code descriptions
                            if (true === $this->hasLanguageKey($languageCode))
                            {
                                $languageData = $this->getLanguageDataByLanguageCode($languageCode);

                                if (false === empty($translationData->Value))
                                {
                                    $attributeValue = $this->getStringValue($translationData->Value);
                                }
                                else
                                {
                                    $attributeValue = $this->getStringValue($attributeTypeData->Value);
                                }

                                // only import attributes having a value
                                if ('' != $attributeValue)
                                {
                                    if (isset($collectedAttributesData[$this->getStringValue($attributeTypeData['id'])]['languages'][$languageData->id])) {
                                        $collectedAttributesData[$this->getStringValue($attributeTypeData['id'])]['languages'][$languageData->id]['attributeValue']
                                            .= self::ATTRIBUTE_VALUE_SEPARATOR . $attributeValue;
                                    } else {
                                        $collectedAttributesData[$this->getStringValue($attributeTypeData['id'])]['languages'][$languageData->id] = [
                                            'attributeName' => $attributeName,
                                            'attributeValue' => $attributeValue
                                        ];
                                    }
                                }
                            }
                        }
                    }
                }
            }

            foreach ($collectedAttributesData as $collectedAttributesDataItem) {
                if(0 < count($collectedAttributesDataItem['languages'])) {

                }
                array_push($attributesDataResult, $this->addArticleAttributeData($collectedAttributesDataItem));
            }
        }

        return $attributesDataResult;
    }


    protected function addArticleAttributeData($attributeData)
    {
        $isMultiAssignmentAttribute     = false;
        $defaultLanguageAttributeData   = $this->getDefaultLanguageArticleAttributeData($attributeData);
        $countCollectedAttributeData    = count($this->articleAttributesData);

        // merge multi assignment attributes
        for($collectedAttributeDataCounter = 0;$collectedAttributeDataCounter < $countCollectedAttributeData; $collectedAttributeDataCounter++)
        {
            $collectedAttributeData = $this->articleAttributesData[$collectedAttributeDataCounter];

            $collectedDefaultLanguageAttributeData = $this->getDefaultLanguageArticleAttributeData($collectedAttributeData);

            if($collectedDefaultLanguageAttributeData['attributeName'] == $defaultLanguageAttributeData['attributeName'])
            {
                $isMultiAssignmentAttribute = true;

                if(true === array_key_exists('languages', $attributeData) && true === array_key_exists('isVariationData', $attributeData))
                {
                    $overwrite = false;

                    if($attributeData['isVariationData'] != $this->articleAttributesData[$collectedAttributeDataCounter]['isVariationData'])
                    {
                        $overwrite = true;
                        $this->articleAttributesData[$collectedAttributeDataCounter]['isVariationData']
                            = $attributeData['isVariationData'];
                    }

                    foreach($attributeData['languages'] as $languageId => $languageData)
                    {
                        if(false === array_key_exists($languageId, $this->articleAttributesData[$collectedAttributeDataCounter]['languages'])
                            || true === $overwrite)
                        {
                            $this->articleAttributesData[$collectedAttributeDataCounter]['languages'][$languageId]  = $languageData;
                        }
                        else
                        {
                            $this->articleAttributesData[$collectedAttributeDataCounter]['languages'][$languageId]['attributeValue'] .= self::ATTRIBUTE_VALUE_SEPARATOR . $languageData['attributeValue'];
                        }
                    }
                }
                break;
            }
        }

        if (false === $isMultiAssignmentAttribute)
        {
             return $attributeData;
        }

        return [];
    }


    public function processImport(\SimpleXMLElement $simpleXmlElementData)
    {
        /**
         * Reserved for if/when we have an Attributes Xml file to import from
         */
    }


    /**
     * @param Models\ProductModel $productModel
     * @return bool
     */
    public function store(Models\ProductModel &$productModel)
    {
        $articleAttributesData = $productModel->getArticleAttributesData();
        $attributeToArticleOxids = [];
        $oxArticlePropertySet = false;

        $bfAttributesToArticleMapping = $this->getBfAttributesToArticleMapping();
        $bfAttributesToArticleMappingReset = $bfAttributesToArticleMapping;

        //get current attribute to Products connections
        $objectToAttributeListModel = oxNew(Models\ObjectToAttributeListModel::class);
        $objectToAttributeListModel->loadArticleAttributes($productModel->getId());

        foreach($objectToAttributeListModel as $objectToAttributeModel)
        {
            $attributeToArticleOxids[$objectToAttributeModel->getFieldData('oxid')] = $objectToAttributeModel->getFieldData('oxattrid');
        }

        foreach ($articleAttributesData as $attributeData)
        {
            if ($attributeData['attributeIsHidden'] === false)
            {
                // creates new attribute if necessary
                $oxAttributeId = $this->storeOxAttribute($attributeData);

                foreach ($attributeData['languages'] as $languageId => $languageData) {
                    // product to attribute assignments
                    $isMultiValue = $this->storeOxObjectToAttribute($attributeToArticleOxids, $productModel->getId(), $oxAttributeId, $languageId, $languageData, $attributeToArticleOxids);

                    $oxid = array_search($oxAttributeId, $attributeToArticleOxids);

                    if ($isMultiValue === false && $oxid !== false) {
                        unset($attributeToArticleOxids[$oxid]);
                    }
                }
            }
            else
            {
                // special handle for hidden attributes -> bf attributes will be stored as oxarticle properties
                foreach ($attributeData['languages'] as $languageId => $languageData)
                {
                    $bfAttributeTitle = $languageData['attributeName'];

                    if (array_key_exists($bfAttributeTitle, $bfAttributesToArticleMapping) === true)
                    {
                        $oxAttributeName = strtolower($bfAttributesToArticleMapping[$bfAttributeTitle]);

                        $productModel->setArticleLanguageData($languageId, 'oxarticles__' . $oxAttributeName, $languageData['attributeValue']);
                        $oxArticlePropertySet = true;
                        unset($bfAttributesToArticleMappingReset[$bfAttributeTitle]);
                    }
                }
            }
        }

        // reset non transfered hidden attributes
        if (count($bfAttributesToArticleMappingReset) > 0)
        {
            $languagesData = Utils\OxidRegistry::getOxidLanguageArray();

            foreach ($bfAttributesToArticleMappingReset as $oxAttributeName)
            {
                foreach ($languagesData as $languageData)
                {
                    $productModel->setArticleLanguageData($languageData->id, 'oxarticles__' . strtolower($oxAttributeName), null);
                    $oxArticlePropertySet = true;
                }
            }
        }

        //delete connections with attributes not transferred
        foreach ($attributeToArticleOxids as $obj2attOxid => $obj2attAttributeId)
        {
            $oxObjectToAttributeModel = oxNew(Models\ObjectToAttributeModel::class);
            $deletion = $oxObjectToAttributeModel->delete($obj2attOxid);

            if ($deletion === false)
            {
                Utils\LogManager::getInstance()->debug("Error deleting Object2Attribute, Oxid: {$obj2attOxid}");
            }
        }

        return $oxArticlePropertySet;

    }


    private function generateAttributeOxId ($id, $code)
    {
        $oxid = "id_" . $id . "_code_" . strtolower($code);

        if (strlen($oxid) > 32)
        {
            $oxid = substr($oxid, 0, 32);
        }

        return $oxid;
    }

    /**
     * storeOxAttribute.
     *
     * @param array $attributeData attributes data
     * @return string ox attribute id
     */
    private function storeOxAttribute($attributeData)
    {
        $baseAttributeTitle = "";

        try
        {
            /** @var Models\AttributeModel $attributeModel */
            $attributeModel		= oxNew(Models\AttributeModel::class);
            $attributeModel->load($attributeData['attributeOxid']);

            if(false === $attributeModel->isLoaded())
            {
                $defaultLanguageId	= Utils\OxidRegistry::getDefaultLanguageId();
                $baseAttributeTitle	= $attributeData['languages'][$defaultLanguageId]['attributeName'];

                // create base attribute
                $attributeModel->setTitle($baseAttributeTitle);
                $attributeModel->setAttributeCode($attributeData['attributeCode']);
                $attributeModel->save($attributeData['attributeOxid']);

                unset($attributeData['languages'][$defaultLanguageId]);
            }

            // save additional titles
            foreach($attributeData['languages'] as $languageId => $languageData)
            {
                $attributeModel->loadInLang($languageId, $attributeModel->getFieldData('oxid'));
                $attributeModel->setLanguage($languageId);
                $attributeModel->setTitle($languageData['attributeName']);
                $attributeModel->save($attributeData['attributeOxid']);
            }

            return $attributeModel->getFieldData('oxid');
        }
        catch (\Exception $exception)
        {
            $this->handleException('Could not load attribute with attribute title: ' . $baseAttributeTitle
                                    . ' and Attribute Oxid: ' . $attributeData['attributeOxid']);
            return "";
        }
    }


    /**
     * @param $attributeToArticleIds
     * @param $oxArticleId
     * @param $oxAttributeId
     * @param $languageId
     * @param $languageData
     */
    private function storeOxObjectToAttribute($attributeToArticleIds, $oxArticleId, $oxAttributeId, $languageId, $languageData, &$current)
    {
        $value = utf8_encode(utf8_decode($languageData['attributeValue']));

        if (strpos($value, self::ATTRIBUTE_VALUE_SEPARATOR) !== false) {
            foreach(explode(self::ATTRIBUTE_VALUE_SEPARATOR, $value) as $valuePart) {
                /** @var Models\ObjectToAttributeModel $oxObjectToAttributeModel */
                $oxObjectToAttributeModel = oxNew(Models\ObjectToAttributeModel::class);
                $oxObjectToAttributeModel->loadByIndices($oxArticleId, $oxAttributeId, substr($valuePart, 0, 255));

                $oxid = array_search($oxAttributeId, $attributeToArticleIds);

                $oxObjectToAttributeModel->setLanguage($languageId);
                $oxObjectToAttributeModel->setOxArticleId($oxArticleId);
                $oxObjectToAttributeModel->setOxAttributeId($oxAttributeId);
                $oxObjectToAttributeModel->setOxValue(substr($valuePart, 0, 255));

                $oxObjectToAttributeModel->save();
                unset($current[$oxObjectToAttributeModel->oxobject2attribute__oxid->value]);
            }

            return true;
        }

        /** @var Models\ObjectToAttributeModel $oxObjectToAttributeModel */
        $oxObjectToAttributeModel = oxNew(Models\ObjectToAttributeModel::class);
        $oxObjectToAttributeModel->loadByIndices($oxArticleId, $oxAttributeId, substr(substr($value, 0, 255), 0, 255));
        $oxObjectToAttributeModel->setOxArticleId($oxArticleId);
        $oxObjectToAttributeModel->setOxAttributeId($oxAttributeId);
        $oxObjectToAttributeModel->setOxValue(substr($value, 0, 255));
        $oxObjectToAttributeModel->save();

        return false;
    }


    /**
     * getDefaultLanguageArticleAttributeData.
     *
     * @param array $attributeData attribute data
     * @return mixed default language article attribute data
     */
    private function getDefaultLanguageArticleAttributeData($attributeData)
    {
        $result             = '';
        $defaultLanguagesId = Utils\OxidRegistry::getDefaultLanguageId();

        if(true === array_key_exists('languages', $attributeData) && true === array_key_exists($defaultLanguagesId, $attributeData['languages']))
        {
            $result = $attributeData['languages'][$defaultLanguagesId];
        }

        return $result;
    }

    /**
     * @return array
     */
    public function getArticleAttributesData()
    {
        return $this->articleAttributesData;
    }


    /**
     * getBfAttributesToArticleMapping.
     *
     * @return array bf attributes to article mapping
     */
    private function getBfAttributesToArticleMapping()
    {
        return Utils\OxidRegistry::getModuleConfig(Utils\ConfigurationKeys::CONFIG_KEY_BF_ATTRIBUTES_TO_ARTICLE_MAPPING);
    }


    /**
     * @param $deletionSetting
     */
    public function deleteAll($deletionSetting)
    {
        $attributeListModel = new Oxid\Core\Model\ListModel();
        $attributeListModel->init($deletionSetting[0]["object"], $deletionSetting[0]["table"]);
        $attributeListModel->getList();

        foreach($attributeListModel->arrayKeys() as $attributeID)
        {
            $articleModel   = clone $this->_attributeModel;
            $articleModel->delete($attributeID);
        }
    }

}