<?php

/**
 * Created by PhpStorm.
 * User: doellerer
 * Date: 26.02.19
 * Time: 10:56
 */
namespace bfox\saleschannel\classes\controller\transfer\export;

use bfox\saleschannel\classes\controller\transfer as Transfers;
use bfox\saleschannel\classes\model as Models;

abstract class AbstractExport extends Transfers\AbstractTransfer
{

    /**
     * exporter data
     * @var mixed
     */
    protected $exporterData = null;

    /**
     * xml writer
     * @var \XMLWriter
     */
    protected $xmlWriter = null;





    /**
     * initExporterData
     */
    abstract protected function initExporterData();




    /**
     * AbstractImport constructor.
     * @param null $mappingModel
     */
    public function __construct($mappingModel = null)
    {
        parent::__construct();

        if (is_null($mappingModel))
        {
            $this->_mappingModel = oxNew(Models\MappingModel::class);
        }
        else
        {
            $this->_mappingModel = $mappingModel;
        }

    }

    /**
     * isExporterDataAvailable.
     *
     * @return boolean exporter data available
     */
    public function isExporterDataAvailable()
    {
        return 0 < sizeof($this->getExporterData());
    }


    /**
     * getExporterData.
     *
     * @return mixed exporter data
     */
    protected function getExporterData()
    {
        if(false === isset($this->exporterData))
        {
            $this->initExporterData();
        }
        return $this->exporterData;
    }

    /**
     * setExporterData.
     *
     * @param mixed $exporterData exporter data
     */
    protected function setExporterData($exporterData)
    {
        $this->exporterData = $exporterData;
    }

    /**
     * getModelValue.
     *
     * @param mixed $model model
     * @param string $fieldName field name
     * @param bool $useRawValue use raw value
     * @return string model value
     */
    protected function getModelValue($model, $fieldName, $useRawValue = false)
    {
        $result = '';

        if(true === $useRawValue)
        {
            $key    = $model->getClassName() . '__' . $fieldName;

            if(true === isset($model->$key))
            {
                $result = $model->$key->getRawValue();
            }
        }

        if('' == $result)
        {
            $result = $model->getFieldData($fieldName);
        }

        return $result;
    }

    /**
     * initXmlWriter.
     */
    protected function initXmlWriter()
    {
        $this->xmlWriter = oxNew(\XMLWriter::class);
        $this->xmlWriter->openUri($this->getFileLocation());

        //Only for debug purposes
        ##$this->xmlWriter->openMemory();

        $this->xmlWriter->startDocument('1.0','UTF-8');
        $this->xmlWriter->setIndent(true);
        $this->xmlWriter->setIndentString('  ');
    }

    /**
     * writeStartElement.
     *
     * @param string $elementName element name
     */
    protected function writeStartElement($elementName)
    {
        $this->xmlWriter->startElement($elementName);
    }

    /**
     * writeEndElement.
     */
    protected function writeEndElement()
    {
        $this->xmlWriter->endElement();
    }

    /**
     * writeElement.
     *
     * @param string $elementName element name
     * @param mixed $elementValue element value
     * @param bool $addCData add cdata block
     */
    protected function writeElement($elementName, $elementValue, $addCData = false)
    {
        $preparedValue = $this->prepareOutput($elementValue);

        if(true === $addCData)
        {
            $this->xmlWriter->startElement($elementName);
            $this->xmlWriter->writeCData($preparedValue);
            $this->xmlWriter->endElement();
        }
        else
        {
            $this->xmlWriter->writeElement($elementName, $preparedValue);
        }
    }

    /**
     * writeAttribute.
     *
     * @param string $attributeName attribute name
     * @param mixed $attributeValue attribute value
     */
    protected function writeAttribute($attributeName, $attributeValue)
    {
        $this->xmlWriter->writeAttribute($attributeName, $this->prepareOutput($attributeValue));
    }

    /**
     * prepareOutput.
     *
     * @param string $value value
     * @return string prepared value
     */
    protected function prepareOutput($value)
    {
        return $value;
    }

    /**
     * endXmlWriter.
     */
    protected function endXmlWriter()
    {
        $this->xmlWriter->endDocument();
        $result = $this->xmlWriter->flush();

        //Only for debug purposes
        ##echo $result;
    }

    /**
     * round.
     *
     * @param mixed $value value
     * @return string rounded value
     */
    protected function round($value)
    {
        return round($value, 0);
    }

    /**
     * formatPrice.
     *
     * @param string $price price
     * @return string formatted price
     */
    protected function formatPrice($price)
    {
        return number_format((float)$price, 2, '.', '');
    }

}