<?php
use Bf\Saleschannel\Components\ImportController;
use \Bf\Saleschannel\Components\ExportController;
use Bf\Saleschannel\Components\Process;
use Bf\Saleschannel\Components\Util\Cleaner;
use Bf\Saleschannel\Components\Util\ConfigManager;
use \Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\ScriptLogger;
use Shopware\Components\CSRFWhitelistAware;

/**
 * Brickfox
 *
 * @package Controllers\Backend
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2015 brickfox GmbH http://www.brickfox.de
 */
class Shopware_Controllers_Backend_Brickfox extends \Enlight_Controller_Action implements CSRFWhitelistAware
{
    public function getWhitelistedCSRFActions()
    {
        return [
            'importSuppliers',
            'importCategories',
            'importProducts',
            'importProductsAssignment',
            'importProductsUpdate',
            'importOrdersStatus',
            'importMultiShops',
            'importProductsBundles',
            'process',
            'exportOrders',
            'installUploadDirectory',
            'showScriptLoggerMessageById',
            'showCronList',
            'scanUnknownDirectory',
            'fixArticleTranslation',
            'exportSeoUrls',
            'calculateSpecialPrices',
            'showDuplicateImgDeleteQuery',
            'createThumbnailsByArticleNumber',
            'listOfMediaWithNoImages',
            'createMissingThumbs'
        ];
    }

    public function indexAction()
    {
        echo 'foo';
        exit;
    }

    public function init()
    {
        Shopware()->Plugins()->Backend()->Auth()->setNoAuth();
        Shopware()->Plugins()->Controller()->ViewRenderer()->setNoRender();

        $scriptLoggerModelRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\Scriptlogger');
        $scriptLoggerModel = $scriptLoggerModelRepository->findBy(array('scriptStatus' => 'running'));

        if(count($scriptLoggerModel) > 0) {
            /** @var \Shopware\CustomModels\BfSaleschannel\Scriptlogger $scriptLogger */
            foreach($scriptLoggerModel as $scriptLogger) {
                $startDate                   = $scriptLogger->getDateStart()->format('Y-m-d H:i:s');
                $startDate                   = strtotime($startDate);
                $timeNow                     = time();
                $scriptLoggerConfigResetTime = (int) Helper::getConfigurationByKey('scriptLogger')->getConfigurationValue() * 60 * 60;

                if(($timeNow - $startDate) > $scriptLoggerConfigResetTime)
                {
                    $scriptLogger->setScriptStatus('reset by script')->setDateEnd(date('Y-m-d H:i:s', time()));
                    Shopware()->Models()->persist($scriptLogger);
                    Shopware()->Models()->flush($scriptLogger);
                    Shopware()->Models()->clear();
                }
            }
        }
    }

    public function createThumbnailsByArticleNumberAction()
    {
        $articleNumber = (string) $this->Request()->getParam('ordernumber', '');
        
        if (strlen($articleNumber) > 0) {
            $mainArticleDetailsModel = Shopware()->Models()->getRepository('Shopware\Models\Article\Detail');
            /** @var \Shopware\Models\Article\Detail $mainArticleDetails */
            $mainArticleDetails = $mainArticleDetailsModel->findOneBy(array('number' => $articleNumber));
            
            if ($mainArticleDetails !== null) {
                /** @var \Shopware\Components\Thumbnail\Manager $generator */
                $generator = Shopware()->Container()->get('thumbnail_manager');
                
                /** @var \Shopware\Models\Article\Image $images */
                foreach($mainArticleDetails->getArticle()->getImages() as $images) {
                    try {
                        $success = $generator->createMediaThumbnail($images->getMedia(), array(), true);
                        
                        if ($success === false) {
                            echo '<pre>';
                            print_r($images->getPath());
                            echo '</pre>';
                        }
                    } catch (\Exception $e) {
                        echo '<pre>';
                        print_r($e->getTraceAsString());
                        echo '</pre>';
                    }
                }
            }
        }
    }

    public function createMissingThumbsAction()
    {
        ScriptLogger::getInstance()->run('createThumbnails');
        $limit = (int)$this->Request()->getParam('limit', 1);
        $count = 1;

        /** @var \Shopware\Bundle\MediaBundle\MediaService $mediaService */
        $mediaService = Shopware()->Container()->get('shopware_media.media_service');

        /** @var \Shopware\Components\Thumbnail\Manager $thumbnailManager */
        $thumbnailManager = Shopware()->Container()->get('thumbnail_manager');

        $mediaRepository = Shopware()->Models()->getRepository('Shopware\Models\Media\Media');
        $mediaModels = $mediaRepository->findBy(array('albumId' => -1));

        if (count($mediaModels) > 0) {
            /** @var \Shopware\Models\Media\Media $mediaModel */
            foreach ($mediaModels as $mediaModel) {
                try {
                    if ($mediaService->has($mediaModel->getPath()) === true) {
                        if (count($mediaModel->getThumbnails()) === 0) {
                            $thumbnailManager->createMediaThumbnail($mediaModel);
                            echo '<pre>';
                            print_r("Created Thumbnail for: {$mediaModel->getPath()}");
                            echo '</pre>';
                        }

                        if ($limit === $count) {
                            break;
                        }
                        $count++;
                    }
                } catch (\Exception $e) {
                    echo '<pre>';
                    print_r($e->getMessage());
                    echo '</pre>';
                }
            }
        }

    }

    public function listOfMediaWithNoImagesAction()
    {
        /** @var \Shopware\Bundle\MediaBundle\MediaService $mediaService */
        $mediaService = Shopware()->Container()->get('shopware_media.media_service');

        $mediaRepository = Shopware()->Models()->getRepository('Shopware\Models\Media\Media');
        $mediaModels = $mediaRepository->findBy(array('albumId' => -1));

        if (count($mediaModels) > 0) {
            /** @var \Shopware\Models\Media\Media $media */
            foreach($mediaModels as $media) {
                if ($mediaService->has($media->getPath()) === false) {
                    echo '<pre>';
                    print_r($media->getPath());
                    echo '</pre>';
                }
            }
        }
    }

    public function showDuplicateImgDeleteQueryAction()
    {
        $cleanerClass = new \Bf\Saleschannel\Components\Util\Cleaner();
        $cleanerClass->showDuplicateRemoveImgQuery();
    }

    public function scanUnknownDirectoryAction()
    {
        $result = $this->dirToArray(Shopware()->DocPath('media_unknown'));

        echo '<pre>';
        print_r($result);
        echo '</pre>';
    }

    /**
     * @param $dir
     *
     * @return array
     */
    public function dirToArray($dir)
    {
        $result = array();

        $cdir = scandir($dir);
        foreach ($cdir as $key => $value)
        {
            if (!in_array($value,array(".","..")))
            {
                if (is_dir($dir . DIRECTORY_SEPARATOR . $value))
                {
                    $result[$value] = $this->dirToArray($dir . DIRECTORY_SEPARATOR . $value);
                }
                else
                {
                    $result[] = $value;
                }
            }
        }

        return $result;
    }

    public function fixArticleTranslationAction()
    {
        try
        {
            $fixArticleTranslationClass = new \Bf\Saleschannel\Components\Resources\Translation\FixTranslation();
            $fixArticleTranslationClass->prepareFixTranslation();
        }
        catch(Exception $e)
        {
            ScriptLogger::getInstance()->errorHandler($e->getCode(), $e->getTraceAsString(), $e->getFile(), $e->getLine());
        }
    }

    public function importSuppliersAction()
    {
        $importer = new ImportController();
        $importer->importManufacturers();
        $this->removeIncorrectCreatedCacheFiles();
    }

    public function importCategoriesAction()
    {
        $importer = new ImportController();
        $importer->importCategories();
        $this->removeIncorrectCreatedCacheFiles();
    }

    public function importProductsAction()
    {
        $importer = new ImportController();
        $importer->importProducts();
        $this->removeIncorrectCreatedCacheFiles();
    }

    public function importProductsAssignmentAction()
    {
        $importer = new ImportController();
        $importer->importProductsAssignment();
        $this->removeIncorrectCreatedCacheFiles();
    }

    public function importProductsUpdateAction()
    {
        $importer = new ImportController();
        $importer->importProductsUpdate();
        $this->removeIncorrectCreatedCacheFiles();
    }

    public function importOrdersStatusAction()
    {
        $importer = new ImportController();
        $importer->importOrdersStatus();
        $this->removeIncorrectCreatedCacheFiles();
    }

    public function importMultiShopsAction()
    {
        $importer = new ImportController();
        $importer->importMultiShops();
        $this->removeIncorrectCreatedCacheFiles();
    }

    public function importProductsBundlesAction()
    {
        $importer = new ImportController();
        $importer->importProductsBundle();
        $this->removeIncorrectCreatedCacheFiles();
    }

    public function calculateSpecialPricesAction()
    {
        $importer = new ImportController();
        $importer->calculateSpecialPrices();
    }

    public function processAction()
    {
        $processType = $this->Request()->getParam('importType', null);

        if($processType === ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS)
        {
            ConfigManager::getInstance()->setInitialImport((bool) $this->Request()->getParam('initialImport', false));
        }

        if($processType !== null)
        {
            $process = new Process();
            $process->prepareProcess($processType);
            (new Cleaner(array(), null))->cleanDbEntries();
        }
    }

    public function exportOrdersAction()
    {
        $exporter = new ExportController();
        $exporter->exportOrders();
    }

    public function exportSeoUrlsAction()
    {
        $exporter = new ExportController();
        $exporter->exportSeoUrls();
    }

    public function installUploadDirectoryAction()
    {
        $installDirectories = array(
            './uploads/brickfox/in',
            './uploads/brickfox/out',
            './uploads/brickfox/failure',
            './uploads/brickfox/success',
            './uploads/brickfox/processed',
            './uploads/brickfox/processedError',
            './uploads/brickfox/logs',
            './uploads/brickfox/image'
        );

        foreach($installDirectories as $directoryPath)
        {
            Helper::checkPath($directoryPath, true);
        }
    }

    public function showScriptLoggerMessageByIdAction()
    {
        $id = $this->Request()->getParam('scriptLoggerId', null);

        $repository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Scriptlogger');
        /** @var Shopware\CustomModels\BfSaleschannel\ScriptLogger $scriptLoggerModel */
        $scriptLoggerModel = $repository->find((int) $id);

        echo '<pre>';
        print_r($scriptLoggerModel->getScriptMessage());
        echo '</pre>';
    }

    public function removeIncorrectCreatedCacheFiles()
    {

        if(is_dir(Shopware()->DocPath('cache')) === true)
        {
            $dir = Shopware()->DocPath('cache');
        }
        elseif(is_dir(Shopware()->DocPath('web_cache')) === true)
        {
            $dir = Shopware()->DocPath('web_cache');
        }
        else
        {
            throw new Exception('Cannot find cache dir');
        }

        if(substr($dir, -1) !== DIRECTORY_SEPARATOR)
        {
            $dir .= DIRECTORY_SEPARATOR;
        }

        $d = new RecursiveDirectoryIterator($dir) or die ("getFileList: Failed opening directory $dir for reading");

        foreach(new RecursiveIteratorIterator($d) as $file)
        {
            if($file->getFileName() === '.' || $file->getFileName() === '..')
            {
                continue;
            }
            else
            {
                if($file->getFileName() === '.php')
                {
                    unlink($file->getPathName());
                }
            }
        }
    }

    public function showCronListAction()
    {
        $shopwareBackendCronPath = 'www.domain.de/backend/Brickfox/';
        $processPart             = 'process/importType/';

        echo '<strong>Cron-Aufrufe f&uuml;r das Importieren der XMl: </strong><br /><br />';
        echo $shopwareBackendCronPath . 'importProducts<br />';
        echo $shopwareBackendCronPath . 'importCategories<br />';
        echo $shopwareBackendCronPath . 'importSuppliers<br />';
        echo $shopwareBackendCronPath . 'importProductsAssignment<br />';
        echo $shopwareBackendCronPath . 'importProductsUpdate<br />';
        echo $shopwareBackendCronPath . 'importOrdersStatus<br />';
        echo $shopwareBackendCronPath . 'importMultiShops<br /><br /><br />';
        echo $shopwareBackendCronPath . 'importProductsBundles<br /><br /><br />';

        echo '<strong>Cron-Aufrufe f&uuml;r das Importieren der Daten:</strong><br /><br />';
        echo $shopwareBackendCronPath . $processPart . ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS . '<br />';
        echo $shopwareBackendCronPath . $processPart . ConfigManager::PROCESS_TYPE_IMPORT_CATEGORIES . '<br />';
        echo $shopwareBackendCronPath . $processPart . ConfigManager::PROCESS_TYPE_IMPORT_MANUFACTURERS . '<br />';
        echo $shopwareBackendCronPath . $processPart . ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS_ASSIGNMENTS . '<br />';
        echo $shopwareBackendCronPath . $processPart . ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS_UPDATE . '<br />';
        echo $shopwareBackendCronPath . $processPart . ConfigManager::PROCESS_TYPE_IMPORT_ORDER_STATUS . '<br />';
        echo $shopwareBackendCronPath . $processPart . ConfigManager::PROCESS_TYPE_IMPORT_MULTI_SHOPS . '<br />';
        echo $shopwareBackendCronPath . $processPart . ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS_BUNDLE . '<br />';
    }
}
