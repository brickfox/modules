// {namespace name=backend/BrickfoxUiLog/view}
// {block name=backend/BrickfoxUiLog/view/LogImportWindow}
Ext.define('Shopware.apps.BrickfoxUiLog.view.LogImportWindow', {

    extend: 'Ext.window.Window',

    title: '{s name="BrickfoxUi/view/Log/Import/Window/Title"}Log-Detail{/s}',

    width: 900,

    height: 500,

    autoScroll: false,

    modal: true,

    jobId: '-',

    processed: '-',

    errorCodes: '-',

    errorMessage: '-',

    xmlData: null,

    processDate: '-',

    initComponent: function () {
        var me = this;

        me.items = me.buildItems();

        me.callParent(arguments);
    },

    buildItems: function () {
        var me = this;

        return [
            {
                height: 500,
                width:  900,
                layout: {
                    type:  'hbox',
                    align: 'stretch'
                },
                items:  [
                    {
                        title: 'Xml-Datensatz',
                        flex:  1,
                        items: [
                            {
                                xtype:    'fieldset',
                                border:   false,
                                defaults: {
                                    anchor:     '100%',
                                    labelWidth: '33%',
                                    xtype:      'displayfield'
                                },
                                items:    [
                                    {
                                        fieldLabel:       '{s name="BrickfoxUiLog/view/log/import/window"}XML{/s}',
                                        xtype:            'htmleditor',
                                        height:           400,
                                        value:            me.xmlData,
                                        enableAlignments: false,
                                        enableColors:     false,
                                        enableFont:       false,
                                        enableLinks:      false,
                                        enableLists:      false,
                                        enableSourceEdit: false,
                                        enableFormat:     false,
                                        enableFontSize:   false,
                                        editable:         false,
                                        frame:            false,
                                        border:           0,
                                        listeners:        {
                                            render: function (element) {
                                                element.setReadOnly(true);
                                            }
                                        }
                                    }
                                ]
                            },
                            {}
                        ]
                    },
                    {
                        title: 'Information',
                        flex:  1,
                        items: [
                            {
                                xtype:    'fieldset',
                                border:   false,
                                defaults: {
                                    anchor:     '100%',
                                    labelWidth: '33%',
                                    xtype:      'displayfield'
                                },
                                items:    [
                                    {
                                        fieldLabel: '{s name="BrickfoxUiLog/view/Log/Products/Column/JobId"}Verarbeitungs-ID{/s}',
                                        value:      me.jobId
                                    },
                                    {
                                        fieldLabel: '{s name="BrickfoxUiLog/view/Log/Products/Column/Processed"}Verarbeitungs-Status{/s}',
                                        value:      me.processed
                                    },
                                    {
                                        fieldLabel: '{s name="BrickfoxUiLog/view/Log/Products/Column/process_date"}Verarbeitungs Datum{/s}',
                                        value:      me.processDate
                                    },
                                    {
                                        fieldLabel: '{s name="BrickfoxUiLog/view/Log/Products/Column/error_codes"}Fehler-Codes{/s}',
                                        value:      me.errorCodes
                                    },
                                    {
                                        xtype:            'htmleditor',
                                        height:           290,
                                        fieldLabel:       '{s name="BrickfoxUiLog/view/Log/Products/Column/error_message"}Fehlermeldung{/s}',
                                        value:            me.errorMessage,
                                        enableAlignments: false,
                                        enableColors:     false,
                                        enableFont:       false,
                                        enableLinks:      false,
                                        enableLists:      false,
                                        enableSourceEdit: false,
                                        enableFormat:     false,
                                        enableFontSize:   false,
                                        editable:         false,
                                        frame:            false,
                                        border:           0,
                                        listeners:        {
                                            render: function (element) {
                                                element.setReadOnly(true);
                                            }
                                        }
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ];
    }

});
// {/block}