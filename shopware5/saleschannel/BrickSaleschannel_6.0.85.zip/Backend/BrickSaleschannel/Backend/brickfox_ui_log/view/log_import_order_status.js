// {namespace name=backend/BrickfoxUiLog/view}
// {block name=backend/rickfoxUi/view/LogImportOrderStatus}
Ext.define('Shopware.apps.BrickfoxUiLog.view.LogImportOrderStatus', {

    extend: 'Ext.grid.Panel',

    alias: 'widget.BrickfoxUiLog-view-LogImportOrderStatus',

    title: '{s name="BrickfoxUiLog/view/Log/Products/Import/Order/Status/Log"}Bestellstatus-Import{/s}',

    layout: 'border',

    autoScroll: true,

    border: false,

    selType: 'checkboxmodel',

    selModel: {
        mode: 'MULTI'
    },

    viewConfig: {
        stripeRows:  false,
        getRowClass: function (record) {
            var returnVal = null,
                processed = null,
                errorCodes = null;

            processed = record.get('processed');
            errorCodes = record.get('error_codes');

            if (processed === '0') {
                returnVal = 'error-row';
            } else if (processed === '1' && errorCodes !== '') {
                returnVal = 'warning-row';
            } else {
                returnVal = 'warning-row';
            }

            return returnVal;
        }
    },

    isBuilt: false,

    init: function () {
        var me = this;

        if (me.isBuilt === true) {
            me.store.load({
                params: {
                    logType: 'importOrdersStatus'
                }
            });
        }
    },

    initComponent: function () {
        var me = this;

        me.registerEvents();
        me.store = Ext.create('Shopware.apps.BrickfoxUiLog.store.LogImport', {
            logTypeList: 'importOrdersStatus'
        });
        me.columns = me.buildColumns();
        me.tbar = me.buildToolbar();
        me.dockedItems = me.buildToolbarBottom();

        me.callParent(arguments);

        me.isBuilt = true;
    },

    registerEvents: function () {
        var me = this;

        me.addEvents('reloadLog', 'delete');
    },

    buildColumns: function () {
        return [
            {
                header:    '{s name="BrickfoxUiLog/view/Log/Products/Column/Id"}Id{/s}',
                dataIndex: 'id',
                hidden:    true,
                width:     25
            },
            {
                header:    '{s name="BrickfoxUiLog/view/Log/Products/Column/JobId"}Verarbeitungs-ID{/s}',
                dataIndex: 'job_id',
                flex:      1
            },
            {
                header:    '{s name="BrickfoxUiLog/view/Log/Products/Column/Processed"}Verarbeitungs-Status{/s}',
                dataIndex: 'processed',
                flex:      1,
                renderer:  function (value) {
                    var icon = '';

                    if (value === '1') {
                        icon += '<span style="display:block; margin: 0 auto; height:25px; width:25px;" class="sprite-ui-check-box">';
                    }
                    else {
                        icon += '<span style="display:block; margin: 0 auto; height:25px; width:25px;" class="sprite-ui-check-box-uncheck">';
                    }

                    return icon;
                },
                editor:    {
                    xtype: 'checkbox'
                }
            },
            {
                header:    '{s name="BrickfoxUiLog/view/Log/Products/Column/error_codes"}Fehler-Codes{/s}',
                dataIndex: 'error_codes',
                flex:      1
            },
            {
                header:    '{s name="BrickfoxUiLog/view/Log/Products/Column/error_message"}Fehlermeldung{/s}',
                dataIndex: 'errorMessageShort',
                flex:      1
            },
            {
                header:    '{s name="BrickfoxUiLog/view/Log/Products/Column/process_date"}Verarbeitugns Datum{/s}',
                dataIndex: 'process_date',
                flex:      1
            }
        ];
    },

    buildToolbar: function () {
        var me = this,
            buttons = [];

        buttons.push({
            xtype: 'tbfill'
        });

        buttons.push({
            xtype:             'textfield',
            name:              'searchfield',
            width:             170,
            cls:               'searchfield',
            enableKeyEvents:   true,
            checkChangeBuffer: 500,
            emptyText:         '{s name=BrickfoxUiLog/view/Log/Toolbar/Search}Suchen..{/s}',
            listeners:         {
                'change': function (field, value) {
                    console.log(value);
                    var store = me.store,
                        searchString = Ext.String.trim(value);

                    //scroll the store to first page
                    store.currentPage = 1;

                    //if the search-value is empty, reset the filter
                    if (searchString.length === 0) {
                        store.filters.clear();
                        store.filter('logType', 'importOrdersStatus');
                    } else {
                        //this won't reload the store
                        store.filters.clear();

                        //
                        ////loads the store with a special filter
                        store.filter(
                            [
                                {
                                    property: 'search',
                                    value:    searchString
                                },
                                {
                                    property: 'logType',
                                    value:    'importOrdersStatus'
                                }
                            ]
                        );
                    }
                }
            }
        });

        buttons.push({
            xtype: 'tbspacer',
            width: 6
        });

        return Ext.create('Ext.toolbar.Toolbar', {
            ui:    'shopware-ui',
            items: buttons
        });
    },

    buildToolbarBottom: function () {
        var me = this;

        return Ext.create('Ext.toolbar.Toolbar', {
            cls:   'shopware-toolbar',
            dock:  'bottom',
            ui:    'shopware-ui',
            items: [
                Ext.create('Ext.PagingToolbar', {
                    store:       me.store,
                    displayInfo: true
                }),
                {
                    xtype: 'tbfill'
                },
                {
                    xtype: 'tbspacer',
                    width: 6
                }
            ]
        });
    }
});
// {/block}