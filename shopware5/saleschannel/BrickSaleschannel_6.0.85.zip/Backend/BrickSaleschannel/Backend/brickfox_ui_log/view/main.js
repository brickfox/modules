// {namespace name=backend/BrickfoxUiLog/view}
// {block name=backend/BrickfoxUiLog/view/Main}
Ext.define('Shopware.apps.BrickfoxUiLog.view.Main', {

    extend: 'Enlight.app.Window',

    alias: 'widget.BrickfoxUiLog-view-main',

    layout: 'fit',

    width: 900,

    height: '90%',

    autoShow: true,

    stateful: true,

    stateId: 'BrickfoxUiLog-view-main',

    title: '{s name=main/Window/title/Log}Connector Log{/s}',

    iconCls: 'bf_icon_log',

    initComponent: function () {
        var me = this;

        me.callParent(arguments);
    },

    createTabPanel: function () {
        var me = this;

        me.start = Ext.widget('BrickfoxUiLog-view-LogImport', {
            logImport: me.logImport,
            main:      me
        });
        me.start.on('activate', me.start.init);

        me.updateLog = Ext.widget('BrickfoxUiLog-view-LogImportProductsUpdate', {
            updateLog: me.updateLog,
            main:      me
        });
        me.updateLog.on('activate', me.updateLog.init);

        me.categorieLog = Ext.widget('BrickfoxUiLog-view-LogImportCategories', {
            categoriesLog: me.categorieLog,
            main:          me
        });
        me.categorieLog.on('activate', me.categorieLog.init);

        me.suppliersLog = Ext.widget('BrickfoxUiLog-view-LogImportSuppliers', {
            suppliersLog: me.suppliersLog,
            main:         me
        });
        me.suppliersLog.on('activate', me.suppliersLog.init);

        me.productsAssignmentsLog = Ext.widget('BrickfoxUiLog-view-LogImportProductsAssignments', {
            productsAssignmentsLog: me.productsAssignmentsLog,
            main:                   me
        });
        me.productsAssignmentsLog.on('activate', me.productsAssignmentsLog.init);

        me.orderStatusLog = Ext.widget('BrickfoxUiLog-view-LogImportOrderStatus', {
            orderStatusLog: me.orderStatusLog,
            main:           me
        });
        me.orderStatusLog.on('activate', me.orderStatusLog.init);

        me.multiShopLog = Ext.widget('BrickfoxUiLog-view-LogImportMultiShop', {
            multiShopLog: me.multiShopLog,
            main:         me
        });
        me.multiShopLog.on('activate', me.multiShopLog.init);

        me.tabpanel = Ext.create('Ext.tab.Panel', {
            items: [me.start, me.updateLog, me.categorieLog, me.suppliersLog, me.productsAssignmentsLog, me.orderStatusLog, me.multiShopLog]
        });

        me.add(me.tabpanel);
    }
});
// {/block}