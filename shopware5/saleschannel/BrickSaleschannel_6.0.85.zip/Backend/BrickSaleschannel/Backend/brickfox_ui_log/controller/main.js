// {namespace name=backend/BrickfoxUiLog/controller}
// {block name=backend/BrickfoxUiLog/controller/main}
Ext.define('Shopware.apps.BrickfoxUiLog.controller.Main', {

    extend: 'Ext.app.Controller',

    mainWindow: null,

    init: function () {
        var me = this;

        me.mainWindow = me.subApplication.getView('Main').create().show();
        me.mainWindow.createTabPanel();

        me.callParent(arguments);
    }
});
// {/block}