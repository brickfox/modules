// {namespace name=backend/BrickfoxUiLog/controller}
// {block name=backend/BrickfoxUiLog/controller/Log}
Ext.define('Shopware.apps.BrickfoxUiLog.controller.Log', {

    extend: 'Ext.app.Controller',

    init: function () {
        var me = this;

        me.control({
            'BrickfoxUiLog-view-LogImport':                    {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            },
            'BrickfoxUiLog-view-LogImportCategories':          {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            },
            'BrickfoxUiLog-view-LogImportMultiShop':           {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            },
            'BrickfoxUiLog-view-LogImportOrderStatus':         {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            },
            'BrickfoxUiLog-view-LogImportProductsAssignments': {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            },
            'BrickfoxUiLog-view-LogImportProductsUpdate':      {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            },
            'BrickfoxUiLog-view-LogImportSuppliers':           {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            }
        });

        me.callParent(arguments);
    },

    onRowDbClick: function (dv, record) {
        Ext.create('Shopware.apps.BrickfoxUiLog.view.LogImportWindow', {
            jobId:        record.data.job_id,
            processed:    record.data.processed,
            errorCodes:   record.data.error_codes,
            errorMessage: record.data.error_message,
            xmlData:      record.data.data,
            processDate:  record.data.process_date
        }).show();
    },

    onReloadLog: function (view) {
        view.setLoading(true);

        view.store.load({
            callback: function () {
                view.setLoading(false);
            }
        });
    },

    onDeleteRow: function (view) {
        var selectedRows = view.getSelectionModel().getSelection();

        if (selectedRows.length) {
            Ext.MessageBox.confirm('Info', 'Sind Sie sicher das Sie diesen Datensatz löschen wollen?', function (btn) {
                if (btn === 'yes') {
                    view.store.remove(selectedRows);
                    view.store.suspendAutoSync();
                    view.store.destroy(selectedRows);
                    view.store.resumeAutoSync();
                    Shopware.Notification.createSuccessMessage('Löschen erfolgreich.', 'Daten konnten gelöscht werden.');
                }
            });
        } else {
            Shopware.Notification.createNoticeMessage('Info', 'Bitte wählen Sie ein Datensatz aus das Sie löschen möchten.');
        }
    }
});
// {/block}