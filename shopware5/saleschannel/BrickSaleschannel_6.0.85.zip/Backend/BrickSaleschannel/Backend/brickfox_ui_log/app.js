// {namespace name=backend/BrickfoxUiLog}
// {block name=backend/BrickfoxUiLog/application}
Ext.define('Shopware.apps.BrickfoxUiLog', {

    name: 'Shopware.apps.BrickfoxUiLog',

    extend: 'Enlight.app.SubApplication',

    loadPath: '{url action=load}',

    bulkLoad: true,

    controllers: [
        'Main',
        'Log'
    ],

    views: [
        'Main',
        'LogImport',
        'LogImportCategories',
        'LogImportMultiShop',
        'LogImportOrderStatus',
        'LogImportProductsAssignments',
        'LogImportProductsUpdate',
        'LogImportSuppliers',
        'LogImportWindow'
    ],

    stores: [
        'LogImport'
    ],

    models: [
        'LogImport'
    ],

    launch: function () {
        var me = this,
            mainController = me.getController('Main');

        return mainController.mainWindow;
    }
});
// {/block}
