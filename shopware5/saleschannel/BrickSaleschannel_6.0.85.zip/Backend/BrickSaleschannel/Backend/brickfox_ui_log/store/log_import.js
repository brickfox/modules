// {namespace name=backend/BrickfoxUiLog/store}
// {block name=backend/BrickfoxUiLog/store/LogImport}
Ext.define('Shopware.apps.BrickfoxUiLog.store.LogImport', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUiLog-store-LogImport',

    model: 'Shopware.apps.BrickfoxUiLog.model.LogImport',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    logTypeList: null,

    proxy: {
        type:        'ajax',
        api:         {
            read:    '{url action=getImportLogList}',
            destroy: '{url action=deleteLog}'
        },
        reader:      {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        },
        extraParams: {
            logType: this.logTypeList
        }
    },

    listeners: {
        beforeload: function (store, foo, bar) {
            store.getProxy().setExtraParam('logType', store.logTypeList);
        }
    }
});
// {/block}