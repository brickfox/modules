// {namespace name=backend/BrickfoxUiLog/model}
// {block name=backend/BrickfoxUiLog/model/LogImport}
Ext.define('Shopware.apps.BrickfoxUiLog.model.LogImport', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/LogImport"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'job_id',
            type: 'string'
        },
        {
            name: 'data',
            type: 'string'
        },
        {
            name: 'dataShort',
            type: 'string'
        },
        {
            name: 'processed',
            type: 'string'
        },
        {
            name: 'error_codes',
            type: 'string'
        },
        {
            name: 'error_message',
            type: 'string'
        },
        {
            name: 'errorMessageShort',
            type: 'string'
        },
        {
            name: 'process_date',
            type: 'string'
        }
    ]
});
// {/block}