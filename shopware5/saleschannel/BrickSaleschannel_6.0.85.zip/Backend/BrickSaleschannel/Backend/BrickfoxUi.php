<?php

use Bf\Saleschannel\Components\Gui\GuiOverview;
use Bf\Saleschannel\Components\Gui\Logging;
use Bf\Saleschannel\Components\Gui\Mapping;
use Bf\Saleschannel\Components\Gui\MappingAbstract;
use Bf\Saleschannel\Components\Gui\MappingCurrencies;
use Bf\Saleschannel\Components\Gui\MappingCustomized;
use Bf\Saleschannel\Components\Gui\MappingShops;
use Bf\Saleschannel\Components\Gui\MappingTax;
use Bf\Saleschannel\Components\Gui\MappingTranslation;
use Bf\Saleschannel\Components\Gui\PaymentMapping;
use Bf\Saleschannel\Components\Gui\PaymentStatusMapping;
use Bf\Saleschannel\Components\Gui\PluginConfigurations;
use Bf\Saleschannel\Components\Gui\ShippingMapping;
use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\Helper;
use Shopware\Models\Order\Status;

/**
 * Shopware_Controllers_Backend_BrickfoxUI
 * This file is part of brickfox.
 *
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2020 brickfox GmbH http://www.brickfox.de
 */
class Shopware_Controllers_Backend_BrickfoxUi extends Shopware_Controllers_Backend_ExtJs
{
    const REST_CALL_CONFIGURATION           = 'bfconfiguration/';
    const REST_CALL_ATTRIBUTES              = 'attributes/';
    const REST_CALL_CURRENCIES_FALLBACK     = 'currencies/';
    const REST_CALL_SHIPPING_STATUS         = 'ordersstatus/';
    const REST_CALL_SHOPS                   = 'slaveshops/';
    const REST_CALL_LANGUAGES_FALLBACK      = 'languages/';
    const REST_CALL_TAX                     = 'tax/';
    const REST_CALL_PARAM_CONFIGURATION_KEY = 'configurationKey';

    /**
     */
    public function indexAction()
    {
    }

    /**
     */
    public function getSettingsListAction()
    {
        $config = [];

        $GuiOverviewClass = new GuiOverview();

        $config['phpVersion']          = $GuiOverviewClass->getPhpVersion();
        $config['phpMemoryLimit']      = $GuiOverviewClass->getMemoryLimit();
        $config['phpMaxExecutionTime'] = $GuiOverviewClass->getMaxExecutionTime();

        $pluginConfiguration = $GuiOverviewClass->ConvertPluginConfigurationForOverviewDisplayFields();

        $config['masterShopName']                         = $pluginConfiguration['masterShopName'];
        $config['brickfoxCustomerUrl']                    = $pluginConfiguration['brickfoxCustomerUrl'];
        $config['brickfoxApiKey']                         = $pluginConfiguration['brickfoxApiKey'];
        $config['incomingPath']                           = $pluginConfiguration['incomingPath'];
        $config['outgoingPath']                           = $pluginConfiguration['outgoingPath'];
        $config['imagePath']                              = $pluginConfiguration['imagePath'];
        $config['logging']                                = $pluginConfiguration['logging'];
        $config['logPath']                                = $pluginConfiguration['logPath'];
        $config['scriptLogger']                           = $pluginConfiguration['scriptLogger'];
        $config['serverProtocol']                         = $pluginConfiguration['serverProtocol'];
        $config['variationTemplateId']                    = $pluginConfiguration['variationTemplateId'];
        $config['useOnlyVariationsItemNumbers']           = $pluginConfiguration['useOnlyVariationsItemNumbers'];
        $config['multiAttributesSymbol']                  = $pluginConfiguration['multiAttributesSymbol'];
        $config['orderStatusMultiSelectIdDescription']    = $pluginConfiguration['orderStatusMultiSelectIdDescription'];
        $config['ignoreOrdersByShopsIds']                 = $pluginConfiguration['ignoreOrdersByShopsIds'];
        $config['overWriteMetaElements']                  = $pluginConfiguration['overWriteMetaElements'];
        $config['mainLanguagesCode']                      = $pluginConfiguration['mainLanguagesCode'];
        $config['sendPendingMail']                        = $pluginConfiguration['sendPendingMail'];
        $config['sendMail']                               = $pluginConfiguration['sendMail'];
        $config['defaultCustomerGroup']                   = $pluginConfiguration['defaultCustomerGroup'];
        $config['urlDescriptionActive']                   = $pluginConfiguration['urlDescriptionActive'];
        $config['imageUrlWithoutExtension']               = $pluginConfiguration['imageUrlWithoutExtension'];
        $config['ignoreImagesImport']                     = $pluginConfiguration['ignoreImagesImport'];
        $config['keepMissingImagesInImport']              = $pluginConfiguration['keepMissingImagesInImport'];
        $config['ignoreCategoriesImportFromMultiShop']    = $pluginConfiguration['ignoreCategoriesImportFromMultiShop'];
        $config['cleanApiAfterDays']                      = $pluginConfiguration['cleanApiAfterDays'];
        $config['cleanBfLogAfterDays']                    = $pluginConfiguration['cleanBfLogAfterDays'];
        $config['cleanBfScriptloggerAfterDays']           = $pluginConfiguration['cleanBfScriptloggerAfterDays'];
        $config['categoryDenormalization']                = $pluginConfiguration['categoryDenormalization'];
        $config['releaseDateFromAttribute']               = $pluginConfiguration['releaseDateFromAttribute'];
        $config['shippingFreeFromAttribute']              = $pluginConfiguration['releaseDateFromAttribute'];
        $config['carrierAttributeFieldName']              = $pluginConfiguration['carrierAttributeFieldName'];
        $config['costChangingAsCoupon']                   = $pluginConfiguration['costChangingAsCoupon'];
        $config['sortOrderAttributes']                    = $pluginConfiguration['sortOrderAttributes'];
        $config['imageMappingDiffsOptionsStatus']         = $pluginConfiguration['imageMappingDiffsOptionsStatus'];
        $config['imageMappingDiffsOptions']               = $pluginConfiguration['imageMappingDiffsOptions'];
        $config['packageOrMeasurementId']                 = $pluginConfiguration['packageOrMeasurementId'];
        $config['commentId']                              = $pluginConfiguration['commentId'];
        $config['strikeThroughPriceRulesId']              = $pluginConfiguration['strikeThroughPriceRulesId'];
        $config['ignoreDelivery']                         = $pluginConfiguration['ignoreDelivery'];
        $config['createDateCode']                         = $pluginConfiguration['createDateCode'];
        $config['emailNotificationCode']                  = $pluginConfiguration['emailNotificationCode'];
        $config['keepAttributesOnImport']                 = $pluginConfiguration['keepAttributesOnImport'];
        $config['lastProductsImport']                     = $GuiOverviewClass->getLastImportExportTimeFromScriptLoggerByScriptName('process/' .
            ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS);
        $config['lastProductsUpdateImport']               = $GuiOverviewClass->getLastImportExportTimeFromScriptLoggerByScriptName('process/' .
            ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS_UPDATE);
        $config['lastMultiShopImport']                    = $GuiOverviewClass->getLastImportExportTimeFromScriptLoggerByScriptName('process/' .
            ConfigManager::PROCESS_TYPE_IMPORT_MULTI_SHOPS);
        $config['lastCategoriesImport']                   = $GuiOverviewClass->getLastImportExportTimeFromScriptLoggerByScriptName('process/' .
            ConfigManager::PROCESS_TYPE_IMPORT_CATEGORIES);
        $config['lastSuppliersImport']                    = $GuiOverviewClass->getLastImportExportTimeFromScriptLoggerByScriptName('process/' .
            ConfigManager::PROCESS_TYPE_IMPORT_MANUFACTURERS);
        $config['lastOrderStatusImport']                  = $GuiOverviewClass->getLastImportExportTimeFromScriptLoggerByScriptName('process/' .
            ConfigManager::PROCESS_TYPE_IMPORT_ORDER_STATUS);
        $config['lastOrderExport']                        = $GuiOverviewClass->getLastImportExportTimeFromScriptLoggerByScriptName('export/Orders');
        $config['importedArticle']                        = $GuiOverviewClass->getCountOfImportedItems('Shopware\CustomModels\BfSaleschannel\MappingArticles');
        $config['importedCategories']                     = $GuiOverviewClass->getCountOfImportedItems('Shopware\CustomModels\BfSaleschannel\MappingCategories');
        $config['importedSuppliers']                      = $GuiOverviewClass->getCountOfImportedItems('Shopware\CustomModels\BfSaleschannel\MappingSuppliers');
        $config['exportTaxesForNetOrders']                = $pluginConfiguration['exportTaxesForNetOrders'];
        $config['disableBfPriceUpdates']                  = $pluginConfiguration['disableBfPriceUpdates'];
        $config['imageDescriptionAttributeName']          = $pluginConfiguration['imageDescriptionAttributeName'];
        $config['excludeCustomerGroupAttributeFieldCode'] = $pluginConfiguration['excludeCustomerGroupAttributeFieldCode'];
        $config['enableEmailNotificationsOnError']        = $pluginConfiguration['enableEmailNotificationsOnError'];
        $config['emailNotificationErrorCodes']            = $pluginConfiguration['emailNotificationErrorCodes'];
        $config['emailNotificationReceivers']             = $pluginConfiguration['emailNotificationReceivers'];
        $config['ignoreLongDescription']                  = $pluginConfiguration['ignoreLongDescription'];
        $config['surchargeCodes']                         = $pluginConfiguration['surchargeCodes'];
        $config['preventPriceModelsRewrite']              = $pluginConfiguration['preventPriceModelsRewrite'];
        $config['savingOptionCodeAttributeFieldName']     = $pluginConfiguration['savingOptionCodeAttributeFieldName'];

        $this->View()->assign([
            'success' => true,
            'data'    => $config
        ]);
    }

    /**
     */
    public function getPluginModesListAction()
    {
        $pluginConfigurationClass = new PluginConfigurations();

        $this->View()->assign([
            'success' => true,
            'data'    => $pluginConfigurationClass->getPluginModesAsArray()
        ]);
    }

    /**
     */
    public function getYesOrNoComboListValuesAction()
    {
        $pluginConfigurationClass = new PluginConfigurations();

        $this->View()->assign([
            'success' => true,
            'data'    => $pluginConfigurationClass->getYesOrNoAnswer()
        ]);
    }

    /**
     */
    public function getMainConfigurationAction()
    {
        $pluginConfigurationClass = new PluginConfigurations();

        $this->View()->assign([
            'data' => $pluginConfigurationClass->loadPluginConfiguration()
        ]);
    }

    /**
     */
    public function saveMainConfigurationAction()
    {
        $pluginConfigurationClass = new PluginConfigurations();

        $this->View()->assign([
            'success' => $pluginConfigurationClass->savePluginConfiguration((array)json_decode($this->Request()->getParam('formData', [])))
        ]);
    }

    /**
     */
    public function getAttributesListAction()
    {
        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::ATTRIBUTES_MAPPING_MODEL_Attributes_NAMESPACE);

        $result = $mappingClass->loadMappings(
            $this->Request()->getParam('start', 0),
            $this->Request()->getParam('limit', 25),
            $this->Request()->getParam('filter')
        );

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);
    }

    /**
     */
    public function setNewAttributesAction()
    {
        $getter = MappingAbstract::getNewAttributesMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::ATTRIBUTES_MAPPING_MODEL_Attributes_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getNewAttributesMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->saveMapping()
        ]);
    }

    /**
     */
    public function getCommentMultiSelectComboAction()
    {
        $commentFields = [
            ['commentId' => 'getComment', 'commentName' => 'Kommentar'],
            ['commentId' => 'getCustomerComment', 'commentName' => 'Kunden-Kommentar'],
            ['commentId' => 'getInternalComment', 'commentName' => 'Interne-Kommentar']
        ];

        $this->View()->assign(['data' => $commentFields]);
    }

    /**
     */
    public function getBrickfoxAttributesMappingDropDownAction()
    {
        if ($this->Request()->has('filter') === true) {
            $param['attributesFilter'] = MappingAbstract::getFilter($this->Request()->getParam('filter'), 'productsAttributesCode');
        }

        $param['start'] = $this->Request()->getParam('start', 0);
        $param['limit'] = $this->Request()->getParam('limit', 25);

        $data = MappingAbstract::getBrickfoxMappingFieldKeys(self::REST_CALL_ATTRIBUTES, $param);

        $this->View()->assign([
            'count' => $data['count'],
            'data'  => $data['data']
        ]);
    }

    /**
     */
    public function deleteAttributesAction()
    {
        $getter = MappingAbstract::getNewAttributesMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::ATTRIBUTES_MAPPING_MODEL_Attributes_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getNewAttributesMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->deleteMappings()
        ]);
    }

    /**
     */
    public function getLogListAction()
    {
        $loggingClass = new Logging();
        $result       = $loggingClass->loadLogs(
            $this->Request()->getParam('start', 0),
            $this->Request()->getParam('limit', 25),
            $this->Request()->getParam('filter')
        );

        $this->View()->assign([
            'success' => true,
            'count'   => $result['count'],
            'data'    => $result['data']
        ]);
    }

    /**
     */
    public function deleteLogsAction()
    {
        $loggingClass = new Logging();

        $this->View()->assign([
            'success' => $loggingClass->removeLoggingEntry($this->Request()->getParams())
        ]);
    }

    /**
     */
    public function getCustomizedMappingListAction()
    {
        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::CUSTOMIZED_MAPPING_MODEL_CUSTOMIZED_NAMESPACE);

        $result = $mappingClass->loadMappings(
            $this->Request()->getParam('start', 0),
            $this->Request()->getParam('limit', 25),
            $this->Request()->getParam('filter')
        );

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);
    }

    /**
     */
    public function getCustomizedMappingDropDownAction()
    {
        $customizedMappingClass = new MappingCustomized();

        $this->View()->assign([
            'data' => $customizedMappingClass->getCustomizedMappingFieldKeys()
        ]);
    }

    /**
     */
    public function getVariationTemplateDropDownAction()
    {
        $pluginConfigurationClass = new PluginConfigurations();

        $this->View()->assign([
            'data' => $pluginConfigurationClass->getVariationTemplateDropDownValues()
        ]);
    }

    /**
     */
    public function getPackageOrMeasurementDropDownAction()
    {
        $pluginConfigurationClass = new PluginConfigurations();
        $result                   = $pluginConfigurationClass->getPackageOrMeasurementDropDownValues();

        $this->View()->assign(['data' => $result, 'count' => count($result)]);
    }

    /**
     */
    public function getStrikeThroughPriceRulesDropDownAction()
    {
        $pluginConfigurationClass = new PluginConfigurations();
        $result                   = $pluginConfigurationClass->getStrikeThroughPriceRulesDropDownValues();

        $this->View()->assign(['data' => $result, 'count' => count($result)]);
    }

    /**
     */
    public function saveCustomizedMappingAction()
    {
        $getter = MappingAbstract::getCustomizedMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::CUSTOMIZED_MAPPING_MODEL_CUSTOMIZED_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getCustomizedMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->saveMapping()
        ]);
    }

    /**
     */
    public function deleteCustomizedMappingAction()
    {
        $getter = MappingAbstract::getCustomizedMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::CUSTOMIZED_MAPPING_MODEL_CUSTOMIZED_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getCustomizedMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->deleteMappings()
        ]);
    }

    /**
     */
    public function getCurrenciesMappingListAction()
    {
        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::CURRENCIES_MAPPING_MODEL_NAMESPACE);

        $result = $mappingClass->loadMappings(
            $this->Request()->getParam('start', 0),
            $this->Request()->getParam('limit', 25),
            $this->Request()->getParam('filter')
        );

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);
    }

    /**
     */
    public function saveCurrenciesMappingAction()
    {
        $getter = MappingAbstract::getCurrenciesMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::CURRENCIES_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getCurrenciesMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->saveMapping()
        ]);
    }

    /**
     */
    public function deleteCurrenciesMappingAction()
    {
        $getter = MappingAbstract::getCurrenciesMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::CURRENCIES_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getCurrenciesMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->deleteMappings()
        ]);
    }

    /**
     */
    public function getBrickfoxCurrenciesMappingDropDownAction()
    {
        $data = MappingAbstract::getBrickfoxConfigurationMappingFieldKeys(self::REST_CALL_CONFIGURATION, [self::REST_CALL_PARAM_CONFIGURATION_KEY => 'currenciesList']);

        if (count($data) === 0) {
            $data = MappingAbstract::getBrickfoxConfigurationMappingFieldKeys(
                self::REST_CALL_CURRENCIES_FALLBACK,
                [self::REST_CALL_PARAM_CONFIGURATION_KEY => 'defaultCurrencyId'],
                'currencies'
            );
        }

        $this->View()->assign([
            'data' => $data
        ]);
    }

    /**
     */
    public function getCurrenciesMappingDropDownAction()
    {
        $this->View()->assign([
            'data' => (new MappingCurrencies())->getCurrenciesMappingFieldKeys()
        ]);
    }

    /**
     */
    public function getTranslationMappingListAction()
    {
        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::TRANSLATION_MAPPING_MODEL_NAMESPACE);

        $result = $mappingClass->loadMappings(
            $this->Request()->getParam('start', 0),
            $this->Request()->getParam('limit', 25),
            $this->Request()->getParam('filter')
        );

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);
    }

    /**
     */
    public function deleteTranslationMappingAction()
    {
        $getter = MappingAbstract::getTranslationMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::TRANSLATION_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getTranslationMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->deleteMappings()
        ]);
    }

    /**
     */
    public function getTranslationMappingDropDownAction()
    {
        $translationMappingClass = new MappingTranslation();

        $this->View()->assign([
            'data' => $translationMappingClass->getTranslationMappingFieldKeys()
        ]);
    }

    /**
     */
    public function saveTranslationMappingAction()
    {
        $getter = MappingAbstract::getTranslationMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::TRANSLATION_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getTranslationMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->saveMapping()
        ]);
    }

    /**
     */
    public function getShopsMappingListAction()
    {
        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::SHOPS_MAPPING_MODEL_NAMESPACE);

        $result = $mappingClass->loadMappings(
            $this->Request()->getParam('start', 0),
            $this->Request()->getParam('limit', 25),
            $this->Request()->getParam('filter')
        );

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);
    }

    /**
     */
    public function saveShopsMappingAction()
    {
        $getter = MappingAbstract::getShopsMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::SHOPS_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getShopsMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->saveMapping()
        ]);
    }

    /**
     */
    public function deleteShopsMappingAction()
    {
        $getter = MappingAbstract::getShopsMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::SHOPS_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getShopsMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->deleteMappings()
        ]);
    }

    /**
     */
    public function getShopsMappingDropDownAction()
    {
        $this->View()->assign([
            'data' => (new MappingShops())->getShopsMappingFieldKeys()
        ]);
    }

    /**
     */
    public function getShopsMappingMasterShopDropDownAction()
    {
        $this->View()->assign([
            'data' => (new MappingShops())->getShopMappingMasterShop()
        ]);
    }

    /**
     */
    public function getShopsMappingBrickfoxDropDownAction()
    {
        if ($this->Request()->has('filter') === true) {
            $param['shopsFilter'] = MappingAbstract::getFilter($this->Request()->getParam('filter'), 'shopsName');
        }

        $param['start']          = $this->Request()->getParam('start', 0);
        $param['limit']          = $this->Request()->getParam('limit', 25);
        $param['masterShopName'] = Helper::getConfigurationByKey('masterShopName')->getConfigurationValue();

        $data = MappingAbstract::getBrickfoxMappingFieldKeys(self::REST_CALL_SHOPS, $param);

        $this->View()->assign([
            'count' => $data['count'],
            'data'  => $data['data']
        ]);
    }

    /**
     */
    public function getLanguageMappingBrickfoxDropDownAction()
    {
        $data = MappingAbstract::getBrickfoxConfigurationMappingFieldKeys(self::REST_CALL_CONFIGURATION, [self::REST_CALL_PARAM_CONFIGURATION_KEY => 'languagesList']);

        if (count($data) === 0) {
            $data = MappingAbstract::getBrickfoxConfigurationMappingFieldKeys(
                self::REST_CALL_LANGUAGES_FALLBACK,
                [self::REST_CALL_PARAM_CONFIGURATION_KEY => 'defaultLanguageId'],
                'languages'
            );
        }

        $this->View()->assign([
            'data' => $data
        ]);
    }

    /**
     */
    public function getFilterListAction()
    {
        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::FILTERS_MAPPING_MODEL_FILTERS_NAMESPACE);

        $result = $mappingClass->loadMappings(
            $this->Request()->getParam('start', 0),
            $this->Request()->getParam('limit', 25),
            $this->Request()->getParam('filter')
        );

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);
    }

    /**
     */
    public function setNewFilterAction()
    {
        $getter = MappingAbstract::getNewFiltersMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::FILTERS_MAPPING_MODEL_FILTERS_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getNewFiltersMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->saveMapping()
        ]);
    }

    /**
     */
    public function deleteFilterAction()
    {
        $getter = MappingAbstract::getNewFiltersMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::FILTERS_MAPPING_MODEL_FILTERS_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getNewFiltersMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'data' => $mappingClass->deleteMappings()
        ]);
    }

    /**
     */
    public function getOrderStatusMultiSelectDropDownAction()
    {
        $orderStatusArr  = [];
        $orderStatusList = Shopware()->Models()->getRepository('Shopware\Models\Order\Status')->findBy(['group' => 'state']);

        if (count($orderStatusList) > 0) {
            /** @var Status $orderStatus */
            foreach ($orderStatusList as $orderStatus) {
                $orderStatusArr[] = [
                    'orderStatusMultiSelectId'           => $orderStatus->getId(),
                    'exportOrderStatusWithIdDescription' => $orderStatus->getName()
                ];
            }
        }

        $this->View()->assign([
            'data' => $orderStatusArr
        ]);
    }

    /**
     */
    public function getTaxMappingDropDownAction()
    {
        $this->View()->assign([
            'data' => (new MappingTax())->getTaxMappingFieldKeys()
        ]);
    }

    /**
     */
    public function getBrickfoxTaxMappingDropDownAction()
    {
        $data = MappingAbstract::getBrickfoxMappingFieldKeys(self::REST_CALL_TAX, []);

        $this->View()->assign([
            'count' => $data['count'],
            'data'  => $data['data']
        ]);
    }

    /**
     */
    public function getTaxListAction()
    {
        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::TAX_MAPPING_MODEL_NAMESPACE);

        $result = $mappingClass->loadMappings(
            $this->Request()->getParam('start', 0),
            $this->Request()->getParam('limit', 25),
            $this->Request()->getParam('filter')
        );

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);
    }

    /**
     */
    public function setNewTaxAction()
    {
        $getter = MappingAbstract::getTaxMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::TAX_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getTaxMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->saveMapping()
        ]);
    }

    /**
     */
    public function deleteTaxAction()
    {
        $getter = MappingAbstract::getTaxMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::TAX_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getTaxMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->deleteMappings()
        ]);
    }

    /**
     */
    public function getShippingStatusMappingListAction()
    {
        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::SHIPPING_STATUS_MAPPING_MODEL_NAMESPACE);

        $result = $mappingClass->loadMappings(
            $this->Request()->getParam('start', 0),
            $this->Request()->getParam('limit', 25),
            $this->Request()->getParam('filter')
        );

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);
    }

    /**
     */
    public function setNewShippingStatusMappingAction()
    {
        $getter = MappingAbstract::getShippingStatusMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::SHIPPING_STATUS_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getShippingStatusMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->saveMapping()
        ]);
    }

    /**
     */
    public function deleteShippingStatusMappingAction()
    {
        $getter = MappingAbstract::getShippingStatusMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::SHIPPING_STATUS_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getShippingStatusMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->deleteMappings()
        ]);
    }

    /**
     */
    public function getBrickfoxShippingMappingDropDownAction()
    {
        if ($this->Request()->has('filter') === true) {
            $param['ordersStatusFilter'] = MappingAbstract::getFilter($this->Request()->getParam('filter'), 'ordersStatusName');
        }

        $param['start'] = $this->Request()->getParam('start', 0);
        $param['limit'] = $this->Request()->getParam('limit', 25);

        $data = MappingAbstract::getBrickfoxMappingFieldKeys(self::REST_CALL_SHIPPING_STATUS, $param);

        $this->View()->assign([
            'count' => $data['count'],
            'data'  => $data['data']
        ]);
    }

    /**
     */
    public function getShippingMappingDropDownAction()
    {
        $this->View()->assign([
            'data' => (new ShippingMapping())->getShippingMappingFieldKeys()
        ]);
    }

    /**
     */
    public function getOrderAttributesMappingListAction()
    {
        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::ORDER_ATTRIBUTES_MAPPING_MODEL_NAMESPACE);

        $result = $mappingClass->loadMappings(
            $this->Request()->getParam('start', 0),
            $this->Request()->getParam('limit', 25),
            $this->Request()->getParam('filter')
        );

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);
    }

    /**
     */
    public function getImageAttributesMappingListAction()
    {
        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::IMAGES_ATTRIBUTES_MAPPING_MODEL_NAMESPACE);

        $result = $mappingClass->loadMappings(
            $this->Request()->getParam('start', 0),
            $this->Request()->getParam('limit', 25),
            $this->Request()->getParam('filter')
        );

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);
    }

    /**
     */
    public function setNewOrderAttributesMappingAction()
    {
        $getter = MappingAbstract::getOrderAttributesMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::ORDER_ATTRIBUTES_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getOrderAttributesMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->saveMapping()
        ]);
    }

    /**
     */
    public function setNewImageAttributesMappingAction()
    {
        $getter = MappingAbstract::getImageAttributesMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::IMAGES_ATTRIBUTES_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getImageAttributesMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->saveMapping()
        ]);
    }

    /**
     */
    public function deleteOrderAttributesMappingAction()
    {
        $getter = MappingAbstract::getOrderAttributesMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::ORDER_ATTRIBUTES_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getOrderAttributesMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->deleteMappings()
        ]);
    }

    /**
     */
    public function deleteImageAttributesMappingAction()
    {
        $getter = MappingAbstract::getImageAttributesMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::IMAGES_ATTRIBUTES_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getImageAttributesMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->deleteMappings()
        ]);
    }

    /**
     */
    public function getPaymentMappingDropDownAction()
    {
        $this->View()->assign([
            'data' => (new PaymentMapping())->getPaymentMappingFieldKeys()
        ]);
    }

    /**
     */
    public function getPaymentStatusMappingDropDownAction()
    {
        $this->View()->assign([
            'data' => (new PaymentStatusMapping())->getPaymentStatusMappingFieldKeys()
        ]);
    }

    /**
     */
    public function getPaymentMethodToPaymentStatusMappingListAction()
    {
        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::PAYMENT_TO_PAYMENT_STATUS_MODEL_NAMESPACE);

        $result = $mappingClass->loadMappings(
            $this->Request()->getParam('start', 0),
            $this->Request()->getParam('limit', 25),
            $this->Request()->getParam('filter')
        );

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);
    }

    /**
     */
    public function setPaymentMethodToPaymentStatusMappingAction()
    {
        $getter = MappingAbstract::getPaymentMethodToPaymentStatusMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::PAYMENT_TO_PAYMENT_STATUS_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getPaymentMethodToPaymentStatusSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->saveMapping()
        ]);
    }

    /**
     */
    public function deletePaymentMethodToPaymentStatusMappingAction()
    {
        $getter = MappingAbstract::getPaymentMethodToPaymentStatusMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::PAYMENT_TO_PAYMENT_STATUS_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getPaymentMethodToPaymentStatusSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->deleteMappings()
        ]);
    }

    /**
     */
    public function getOrderLinesAttributesMappingListAction()
    {
        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::ORDER_LINES_ATTRIBUTES_MAPPING_MODEL_NAMESPACE);

        $result = $mappingClass->loadMappings(
            $this->Request()->getParam('start', 0),
            $this->Request()->getParam('limit', 25),
            $this->Request()->getParam('filter')
        );

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);
    }

    /**
     */
    public function setNewOrderLinesAttributesMappingAction()
    {
        $getter = MappingAbstract::getOrderLinesAttributesMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::ORDER_LINES_ATTRIBUTES_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getOrderLinesAttributesMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->saveMapping()
        ]);
    }

    /**
     */
    public function deleteOrderLinesAttributesMappingAction()
    {
        $getter = MappingAbstract::getOrderLinesAttributesMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::ORDER_LINES_ATTRIBUTES_MAPPING_MODEL_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getOrderLinesAttributesMappingSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->deleteMappings()
        ]);
    }

    /**
     */
    public function getOrderExportByPaymentStatusListAction()
    {
        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::ORDER_EXPORT_BY_PAYMENT_STATUS_NAMESPACE);

        $result = $mappingClass->loadMappings(
            $this->Request()->getParam('start', 0),
            $this->Request()->getParam('limit', 25),
            $this->Request()->getParam('filter')
        );

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);
    }

    /**
     */
    public function saveOrderExportByPaymentStatusAction()
    {
        $getter = MappingAbstract::getOrderExportByPaymentStatusMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::ORDER_EXPORT_BY_PAYMENT_STATUS_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getOrderExportByPaymentStatusSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->saveMapping()
        ]);
    }

    /**
     */
    public function deleteOrderExportByPaymentStatusAction()
    {
        $getter = MappingAbstract::getOrderExportByPaymentStatusMappingGetter();

        $mappingClass = new Mapping();
        $mappingClass->setMappingModel(MappingAbstract::ORDER_EXPORT_BY_PAYMENT_STATUS_NAMESPACE);
        $mappingClass->setMappingGetter($getter);
        $mappingClass->setMappingSetter($mappingClass->setMappingKeyFields(MappingAbstract::getOrderExportByPaymentStatusSetter())->getOneOrMoreMappings($this->Request()->getParams()));
        $mappingClass->setUniqueKey($getter['preLoad']['uniqueKey']);

        $this->View()->assign([
            'success' => $mappingClass->deleteMappings()
        ]);
    }
}