// {namespace name=backend/BrickfoxUi/model/combo}
// {block name=backend/BrickfoxUi/model/combo/CustomizedMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.CustomizedMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/Customized"}{/block}
        {
            name: 'mappingFieldKeyName',
            type: 'string'
        },
        {
            name: 'mappingFieldKeyCode',
            type: 'string'
        }
    ]
});
// {/block}