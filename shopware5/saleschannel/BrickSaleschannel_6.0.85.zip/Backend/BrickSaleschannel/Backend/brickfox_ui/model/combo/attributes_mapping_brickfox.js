// {namespace name=backend/BrickfoxUi/model/combo}
// {block name=backend/BrickfoxUi/model/combo/AttributesMappingBrickfox}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.AttributesMappingBrickfox', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/Attributes"}{/block}
        {
            name: 'brickfoxFieldKeyName',
            type: 'string'
        },
        {
            name: 'brickfoxFieldKeyCode',
            type: 'string'
        }
    ]

});
// {/block}