// {namespace name=backend/BrickfoxUi/model}
// {block name=backend/BrickfoxUi/model/ShopsMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.ShopsMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/Shops"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'brickfoxId',
            type: 'string'
        },
        {
            name: 'shopwareId',
            type: 'string'
        },
        {
            name: 'isMasterShop',
            type: 'string'
        }
    ]
});
// {/block}