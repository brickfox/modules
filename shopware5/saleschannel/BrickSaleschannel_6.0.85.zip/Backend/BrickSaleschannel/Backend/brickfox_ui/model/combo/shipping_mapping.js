// {namespace name=backend/BrickfoxUi/model/combo}
// {block name=backend/BrickfoxUi/model/combo/ShippingMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.ShippingMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/Bfsaleschannel/model/combo/ShippingMapping"}{/block}
        {
            name: 'shopwareFieldKeyName',
            type: 'string'
        },
        {
            name: 'shopwareFieldKeyCode',
            type: 'string'
        }
    ]
});
// {/block}