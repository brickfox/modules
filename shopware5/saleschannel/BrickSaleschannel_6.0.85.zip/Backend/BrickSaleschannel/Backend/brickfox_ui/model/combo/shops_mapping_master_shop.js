// {namespace name=backend/BrickfoxUi/model/combo}
// {block name=backend/BrickfoxUi/model/combo/ShopsMappingMasterShop}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.ShopsMappingMasterShop', {
    extend: 'Ext.data.Model',

    fields: [
        //  {block name="backend/BfSaleschannel/model/combo/ShopsBf"}{/block}
        {
            name: 'masterFieldKeyCode',
            type: 'string'
        },
        {
            name: 'masterFieldKeyName',
            type: 'string'
        }
    ]
});
// {/block}