// {namespace name=backend/BrickfoxUi/model}
// {block name=backend/BrickfoxUi/model/FilterMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.FilterMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name=backend/BfSaleschannel/model/FilterMapping}{/block}
        {
            name: 'attributesCode',
            type: 'string'
        },
        {
            name: 'id',
            type: 'string'
        }
    ]
});
// {/block}