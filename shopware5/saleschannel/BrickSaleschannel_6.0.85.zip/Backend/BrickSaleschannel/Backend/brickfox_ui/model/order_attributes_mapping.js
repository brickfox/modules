// {namespace name=backend/BrickfoxUi/model}
// {block name=backend/BrickfoxUi/model/OrderAttributesMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.OrderAttributesMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BrickSaleschannel/model/OrderAttributesMapping"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'brickfoxExportName',
            type: 'string'
        },
        {
            name: 'shopwareColumnName',
            type: 'string'
        }
    ]
});
// {/block}