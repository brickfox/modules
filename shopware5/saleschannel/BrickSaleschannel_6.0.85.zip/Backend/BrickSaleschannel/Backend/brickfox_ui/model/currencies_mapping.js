// {namespace name=backend/BrickfoxUi/model}
// {block name=backend/BrickfoxUi/model/CurrenciesMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.CurrenciesMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/Currencies"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'brickfoxCurrenciesCode',
            type: 'string'
        },
        {
            name: 'mappingFieldKey',
            type: 'string'
        }
    ]
});
// {/block}