// {namespace name=backend/BrickfoxUi/model/combo}
// {block name=backend/BrickfoxUi/model/combo/OrderStatusMultiSelect}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.OrderStatusMultiSelect', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/OrderStatus/MultiSelect"}{/block}
        {
            name: 'exportOrderStatusWithIdDescription',
            type: 'string'
        },
        {
            name: 'orderStatusMultiSelectId',
            type: 'string'
        }
    ]
});
// {/block}