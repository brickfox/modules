Ext.define('Shopware.apps.BrickfoxUi.model.combo.CommentMultiSelect', {
    extend: 'Ext.data.Model',
    fields: [
        {
            name: 'commentName',
            type: 'string'
        },
        {
            name: 'commentId',
            type: 'string'
        }
    ]
});