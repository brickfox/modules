// {namespace name=backend/BrickfoxUi/model}
// {block name=backend/BrickfoxUi/model/TranslationMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.TranslationMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/Translation"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'brickfoxIsoCode',
            type: 'string'
        },
        {
            name: 'mappingFieldKey',
            type: 'string'
        }
    ]
});
// {/block}