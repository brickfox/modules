// {namespace name=backend/BrickfoxUi/model}
// {block name=backend/BrickfoxUi/model/TaxMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.TaxMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name=backend/BfSaleschannel/model/TaxMapping}{/block}
        {
            name: 'brickfoxTaxId',
            type: 'string'
        },
        {
            name: 'mappingFieldKey',
            type: 'string'
        },
        {
            name: 'id',
            type: 'string'
        }
    ]
});
// {/block}