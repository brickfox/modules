// {namespace name=backend/BrickfoxUi/model/combo}
// {block name=backend/BrickfoxUi/model/combo/VariationTemplate}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.VariationTemplate', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/Variation/Template"}{/block}
        {
            name: 'variationTemplateName',
            type: 'string'
        },
        {
            name: 'variationTemplateId',
            type: 'string'
        }
    ]
});
// {/block}