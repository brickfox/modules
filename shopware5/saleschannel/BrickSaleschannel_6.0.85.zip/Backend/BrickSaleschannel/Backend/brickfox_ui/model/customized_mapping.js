// {namespace name=backend/BrickfoxUi/model}
// {block name=backend/BrickfoxUi/model/CustomizedMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.CustomizedMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/CustomizedMapping"}{/block}
        {
            name: 'xmlTag',
            type: 'string'
        },
        {
            name: 'mappingFieldKey',
            type: 'string'
        },
        {
            name: 'id',
            type: 'string'
        }
    ]
});
// {/block}