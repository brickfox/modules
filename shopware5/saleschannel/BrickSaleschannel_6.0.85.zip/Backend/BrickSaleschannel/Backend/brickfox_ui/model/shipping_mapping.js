// {namespace name=backend/BrickfoxUi/model}
// {block name=backend/BrickfoxUi/model/ShippingMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.ShippingMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/ShippingMapping"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'brickfoxShippingStatusCode',
            type: 'string'
        },
        {
            name: 'shippingCode',
            type: 'string'
        },
        {
            name: 'mappingFieldKey',
            type: 'string'
        }
    ]

});
// {/block}