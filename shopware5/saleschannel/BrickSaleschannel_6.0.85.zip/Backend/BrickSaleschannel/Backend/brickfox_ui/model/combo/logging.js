// {namespace name=backend/BrickfoxUi/model/combo}
// {block name=backend/BrickfoxUi/model/combo/logging}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.Logging', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/Logging"}{/block}
        {
            name: 'logging',
            type: 'string'
        },
        {
            name: 'name',
            type: 'string'
        }
    ]
});
// {/block}