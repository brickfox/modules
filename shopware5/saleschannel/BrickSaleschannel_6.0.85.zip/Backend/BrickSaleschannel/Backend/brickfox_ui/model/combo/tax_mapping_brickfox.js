// {namespace name=backend/BrickfoxUi/model/combo}
// {block name=backend/BrickfoxUi/model/combo/TaxMappingBrickfox}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.TaxMappingBrickfox', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/TaxMappingBrickfox"}{/block}
        {
            name: 'brickfoxFieldKeyName',
            type: 'string'
        },
        {
            name: 'brickfoxFieldKeyCode',
            type: 'string'
        }
    ]
});
// {/block}