// {namespace name=backend/BrickfoxUi/model/combo}
// {block name=backend/BrickfoxUi/model/combo/ShippingMappingBrickfox}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.ShippingMappingBrickfox', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/Shipping"}{/block}
        {
            name: 'brickfoxFieldKeyName',
            type: 'string'
        },
        {
            name: 'brickfoxFieldKeyCode',
            type: 'string'
        }
    ]
});
// {/block}