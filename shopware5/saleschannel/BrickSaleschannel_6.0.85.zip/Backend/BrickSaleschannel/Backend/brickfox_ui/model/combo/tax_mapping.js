// {namespace name=backend/BrickfoxUi/model/combo}
// {block name=backend/BrickfoxUi/model/combo/TaxMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.TaxMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/Tax"}{/block}
        {
            name: 'shopwareFieldKeyName',
            type: 'string'
        },
        {
            name: 'shopwareFieldKeyCode',
            type: 'string'
        }
    ]
});
// {/block}