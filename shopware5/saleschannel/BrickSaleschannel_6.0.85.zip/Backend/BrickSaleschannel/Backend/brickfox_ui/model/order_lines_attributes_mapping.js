// {namespace name=backend/BrickfoxUi/model}
// {block name=backend/BrickfoxUi/model/OrderLinesAttributesMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.OrderLinesAttributesMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BrickSaleschannel/model/OrderLinesAttributesMapping"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'brickfoxExportName',
            type: 'string'
        },
        {
            name: 'shopwareColumnName',
            type: 'string'
        }
    ]
});
// {/block}