// {namespace name=backend/BrickfoxUi/model}
// {block name=backend/BrickfoxUi/model/overview}
Ext.define('Shopware.apps.BrickfoxUi.model.Overview', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/Overview/fields"}{/block}
        {
            name: 'phpVersion',
            type: 'string'
        },
        {
            name: 'phpMemoryLimit',
            type: 'string'
        },
        {
            name: 'phpMaxExecutionTime',
            type: 'string'
        },
        {
            name: 'masterShopName',
            type: 'string'
        },
        {
            name: 'brickfoxCustomerUrl',
            type: 'string'
        },
        {
            name: 'brickfoxApiKey',
            type: 'string'
        },
        {
            name: 'incomingPath',
            type: 'string'
        },
        {
            name: 'outgoingPath',
            type: 'string'
        },
        {
            name: 'imagePath',
            type: 'string'
        },
        {
            name: 'logging',
            type: 'string'
        },
        {
            name: 'logPath',
            type: 'string'
        },
        {
            name: 'scriptLogger',
            type: 'int'
        },
        {
            name: 'serverProtocol',
            type: 'string'
        },
        {
            name: 'variationTemplateId',
            type: 'string'
        },
        {
            name: 'useOnlyVariationsItemNumbers',
            type: 'string'
        },
        {
            name: 'lastProductsImport',
            type: 'string'
        },
        {
            name: 'lastProductsUpdateImport',
            type: 'string'
        },
        {
            name: 'lastMultiShopImport',
            type: 'string'
        },
        {
            name: 'lastSuppliersImport',
            type: 'string'
        },
        {
            name: 'lastOrderStatusImport',
            type: 'string'
        },
        {
            name: 'lastOrderExport',
            type: 'string'
        },
        {
            name: 'importedArticle',
            type: 'string'
        },
        {
            name: 'importedCategories',
            type: 'string'
        },
        {
            name: 'importedSuppliers',
            type: 'string'
        },
        {
            name: 'lastCategoriesImport',
            type: 'string'
        },
        {
            name: 'multiAttributesSymbol',
            type: 'string'
        },
        {
            name: 'orderStatusMultiSelectIdDescription',
            type: 'string'
        },
        {
            name: 'ignoreOrdersByShopsIds',
            type: 'string'
        },
        {
            name: 'overWriteMetaElements',
            type: 'string'
        },
        {
            name: 'mainLanguagesCode',
            type: 'string'
        },
        {
            name: 'sendPendingMail',
            type: 'string'
        },
        {
            name: 'sendMail',
            type: 'string'
        },
        {
            name: 'defaultCustomerGroup',
            type: 'string'
        },
        {
            name: 'urlDescriptionActive',
            type: 'string'
        },
        {
            name: 'imageUrlWithoutExtension',
            type: 'string'
        },
        {
            name: 'ignoreImagesImport',
            type: 'string'
        },
        {
            name: 'keepMissingImagesInImport',
            type: 'string'
        },
        {
            name: 'imageMappingDiffsOptionsStatus',
            type: 'string'
        },
        {
            name: 'imageMappingDiffsOptions',
            type: 'string'
        },
        {
            name: 'ignoreCategoriesImportFromMultiShop',
            type: 'string'
        },
        {
            name: 'cleanApiAfterDays',
            type: 'string'
        },
        {
            name: 'cleanBfLogAfterDays',
            type: 'string'
        },
        {
            name: 'cleanBfScriptloggerAfterDays',
            type: 'string'
        },
        {
            name: 'categoryDenormalization',
            type: 'string'
        },
        {
            name: 'releaseDateFromAttribute',
            type: 'string'
        },
        {
            name: 'shippingFreeFromAttribute',
            type: 'string'
        },
        {
            name: 'carrierAttributeFieldName',
            type: 'string'
        },
        {
            name: 'costChangingAsCoupon',
            type: 'string'
        },
        {
            name: 'sortOrderAttributes',
            type: 'string'
        },
        {
            name: 'packageOrMeasurementId',
            type: 'string'
        },
        {
            name: 'strikeThroughPriceRulesId',
            type: 'string'
        },
        {
            name: 'ignoreDelivery',
            type: 'string'
        },
        {
            name: 'createDateCode',
            type: 'string'
        },
        {
            name: 'emailNotificationCode',
            type: 'string'
        },
        {
            name: 'keepAttributesOnImport',
            type: 'string'
        },
        {
            name: 'exportTaxesForNetOrders',
            type: 'string'
        },
        {
            name: 'disableBfPriceUpdates',
            type: 'string'
        },
        {
            name: 'imageDescriptionAttributeName',
            type: 'string'
        },
        {
            name: 'excludeCustomerGroupAttributeFieldCode',
            type: 'string'
        },
        {
            name: 'enableEmailNotificationsOnError',
            type: 'string'
        },
        {
            name: 'emailNotificationErrorCodes',
            type: 'string'
        },
        {
            name: 'emailNotificationReceivers',
            type: 'string'
        },
        {
            name: 'ignoreLongDescription',
            type: 'string'
        },
        {
            name: 'surchargeCodes',
            type: 'string'
        },
        {
            name: 'preventPriceModelsRewrite',
            type: 'string'
        },
        {
            name: 'savingOptionCodeAttributeFieldName',
            type: 'string'
        }
    ]
});
// {/block}