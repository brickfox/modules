// {namespace name=backend/BrickfoxUi/model/combo}
// {block name=backend/BrickfoxUi/model/combo/PaymentStatusMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.PaymentStatusMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/Bfsaleschannel/model/combo/PaymentStatusMapping"}{/block}
        {
            name: 'shopwareFieldKeyName',
            type: 'string'
        },
        {
            name: 'shopwareFieldKeyCode',
            type: 'string'
        }
    ]
});
// {/block}