// {namespace name=backend/BrickfoxUi/model}
// {block name=backend/BrickfoxUi/model/AttributesMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.AttributesMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name=backend/BfSaleschannel/model/AttributesMapping}{/block}
        {
            name: 'attributesCode',
            type: 'string'
        },
        {
            name: 'mappingFieldKey',
            type: 'string'
        },
        {
            name: 'id',
            type: 'string'
        }
    ]
});
// {/block}