// {namespace name=backend/BrickfoxUi/model/combo}
// {block name=backend/BrickfoxUi/model/combo/PackageOrMeasurement}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.PackageOrMeasurement', {
    extend: 'Ext.data.Model',
    fields: [
        // {block name="backend/BfSaleschannel/model/combo/Measurement"}{/block}
        {
            name: 'packageOrMeasurementId',
            type: 'string'
        },
        {
            name: 'packageOrMeasurementName',
            type: 'string'
        }
    ]
});
// {/block}