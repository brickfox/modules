// {namespace name=backend/BrickfoxUi/model/combo}
// {block name=backend/BrickfoxUi/model/combo/StrikeThroughPriceRules}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.StrikeThroughPriceRules', {
    extend: 'Ext.data.Model',
    fields: [
        // {block name="backend/BfSaleschannel/model/combo/StrikeThroughPriceRules"}{/block}
        {
            name: 'strikeThroughPriceRulesId',
            type: 'string'
        },
        {
            name: 'strikeThroughPriceRulesName',
            type: 'string'
        }
    ]
});
// {/block}