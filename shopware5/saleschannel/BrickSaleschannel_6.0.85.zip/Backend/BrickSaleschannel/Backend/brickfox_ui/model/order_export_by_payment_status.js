// {namespace name=backend/BrickfoxUi/model}
// {block name=backend/BrickfoxUi/model/OrderExportByPaymentStatus}
Ext.define('Shopware.apps.BrickfoxUi.model.OrderExportByPaymentStatus', {
    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/OrderExportByPaymentStatus"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'paymentId',
            type: 'string'
        },
        {
            name: 'paymentStatusId',
            type: 'string'
        }
    ]
});
// {/block}