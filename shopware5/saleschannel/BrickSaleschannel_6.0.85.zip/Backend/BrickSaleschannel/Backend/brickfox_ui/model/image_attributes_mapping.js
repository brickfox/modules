// {namespace name=backend/BrickfoxUi/model}
// {block name=backend/BrickfoxUi/model/ImageAttributesMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.ImageAttributesMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BrickSaleschannel/model/ImageAttributesMapping"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'attributesCode',
            type: 'string'
        },
        {
            name: 'mappingFieldKey',
            type: 'string'
        }
    ]
});
// {/block}