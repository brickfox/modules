// {namespace name=backend/BrickfoxUi/model}
// {block name=backend/BrickfoxUi/model/PaymentMethodToPaymentStatusMapping}
Ext.define('Shopware.apps.BrickfoxUi.model.PaymentMethodToPaymentStatusMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/PaymentMethodToPaymentStatusMapping"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'paymentId',
            type: 'string'
        },
        {
            name: 'paymentStatusId',
            type: 'string'
        }
    ]

});
// {/block}