// {namespace name=backend/BrickfoxUi/controller}
// {block name=backend/BrickfoxUi/controller/configuration}
Ext.define('Shopware.apps.BrickfoxUi.controller.Configuration', {

    extend: 'Ext.app.Controller',

    saveConfigurationUrl:  'BrickfoxUi/saveMainConfiguration',
    checkFtpConnectionUrl: 'BrickfoxUi/verifyFtpConnection',

    init: function () {
        var me = this;

        me.control({
            'BrickfoxUi-view-Configuration': {
                save: me.onSave
            },
            'BrickfoxUi-view-Overview':      {
                check: me.onCheck
            }
        });
    },

    onCheck: function (view) {
        view.setLoading(true);

        view.store.load({
            callback: function (records) {
                view.loadRecord(records[0]);
            }
        });

        view.setLoading(false);
    },

    onSave: function (view) {
        var me = this,
            form = view.getForm();

        if (form.isValid()) {
            view.setLoading(true);

            Ext.Ajax.request({
                method:  'POST',
                url:     me.saveConfigurationUrl,
                success: function (res) {
                    var response = Ext.JSON.decode(res.responseText);

                    if (response.success === true) {
                        Shopware.Notification.createSuccessMessage('Einstellungen gespeichert', 'Ihre Einstellungen wurden gespeichert.');
                    } else {
                        Shopware.Notification.createNoticeMessage('Einstellungen nicht gespeichert', 'Ihre Einstellungen konnten nicht gespeichert werden, bitte versuchen Sie es noch einmal.')
                    }
                },
                params:  {
                    formData: JSON.stringify(form.getValues())
                }
            });

            view.setLoading(false);
        } else {
            Shopware.Notification.createErrorMessage('Einstellungen nicht gespeichert', 'Bitte füllen Sie alle Pflichtfelder aus.');
        }
    },
});
// {/block}