// {namespace name=backend/BrickfoxUi/controller}
// {block name=backend/BrickfoxUi/controller/main}
Ext.define('Shopware.apps.BrickfoxUi.controller.Main', {

    extend: 'Ext.app.Controller',

    mainWindow: null,

    init: function () {
        var me = this;

        me.mainWindow = me.subApplication.getView('Main').create().show();
        me.mainWindow.createTabPanel();

        me.control({
            'BrickfoxUi-view-AttributesMapping':      {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-CustomizedMapping':      {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-CurrenciesMapping':      {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-TranslationMapping':     {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-ShopsMapping':           {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-FilterMapping':          {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-TaxMapping':             {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-ShippingMapping':        {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-OrderAttributesMapping': {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-PaymentMethodToPaymentStatusMapping': {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-OrderLinesAttributesMapping': {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-OrderExportByPaymentStatus': {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-ImageAttributesMapping': {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            }
        });

        me.callParent(arguments);
    },

    onValidateUniqueReference: function (view, editor, e, url, uniqueConstraintKey) {
        if (e.newValues[uniqueConstraintKey] !== undefined) {
            if (
                e.newValues.mappingFieldKey !== e.originalValues.mappingFieldKey && (e.newValues[uniqueConstraintKey] !== e.originalValues[uniqueConstraintKey]
                || e.newValues[uniqueConstraintKey] == e.originalValues[uniqueConstraintKey])
            ) {
                Ext.Ajax.request({
                    method:  'POST',
                    url:     url,
                    success: function (res) {
                        var response = Ext.JSON.decode(res.responseText),
                            i;

                        for (i = 0; i < response.data.length; i++) {
                            if (response.data[i].mappingFieldKey === e.newValues.mappingFieldKey && e.newValues.mappingFieldKey !== e.originalValues.mappingFieldKey) {
                                e.record.set('mappingFieldKey', e.originalValues.mappingFieldKey);
                                e.newValues.mappingFieldKey = e.originalValues.mappingFieldKey;
                                e.record.data.mappingFieldKey = e.originalValues.mappingFieldKey;

                                Shopware.Notification.createGrowlMessage('Fehler', 'Das von Ihnen angegebene Shopware-Model Feld wurde bereits gemapped.', 'Brickfox Connector');
                                break;
                            } else if (response.data[i][uniqueConstraintKey] === e.newValues[uniqueConstraintKey] && uniqueConstraintKey !== 'mappingFieldKey') {
                                e.record.set(uniqueConstraintKey, e.originalValues[uniqueConstraintKey]);
                                e.newValues[uniqueConstraintKey] = e.originalValues[uniqueConstraintKey];
                                e.record.data[uniqueConstraintKey] = e.originalValues[uniqueConstraintKey];

                                Shopware.Notification.createGrowlMessage('Fehler', 'Das von Ihnen angegebene Feld mit dem Wert ' + uniqueConstraintKey + ' existiert bereits.', 'Brickfox Connector');
                            }
                        }
                    },
                    failure: function () {
                        Shopware.Notification.createGrowlMessage('Fehler', 'Fehler beim prüfen des Mapping-Keys', 'Brickfox Connector')
                    },
                    params:  {
                        start: 0,
                        limit: 0
                    }
                })
            }
        }
    },

    onReloadMapping: function (view) {
        view.store.load();
    },

    onAddRow: function (view) {
        var model = Ext.create(view.store.model.modelName);

        switch (view.$className) {
        case 'Shopware.apps.BrickfoxUi.view.CustomizedMapping':
            model.set('xmlTag', 'Xml-Knoten');
            model.set('mappingFieldKey', '');
            break;

        case 'Shopware.apps.BrickfoxUi.view.AttributesMapping' :
            model.set('attributesCode', '');
            model.set('mappingFieldKey', '');
            break;

        case 'Shopware.apps.BrickfoxUi.view.CurrenciesMapping':
            model.set('brickfoxCurrenciesCode', '');
            model.set('mappingFieldKey', '');
            break;

        case 'Shopware.apps.BrickfoxUi.view.TranslationMapping':
            model.set('brickfoxIsoCode', '');
            model.set('mappingFieldKey', '');
            break;

        case 'Shopware.apps.BrickfoxUi.view.ShopsMapping':
            model.set('brickfoxShop', '');
            model.set('mappingFieldKey', '');
            break;

        case 'Shopware.apps.BrickfoxUi.view.FilterMapping':
            model.set('attributesCode', '');
            break;

        case 'Shopware.apps.BrickfoxUi.view.TaxMapping':
            model.set('taxCode', '');
            break;

        case 'Shopware.apps.BrickfoxUi.view.ShippingMapping':
            model.set('brickfoxShippingStatusCode', '');
            model.set('mappingFieldKey', '');
            break;

        case 'Shopware.apps.BrickfoxUi.view.OrderAttributesMapping':
            model.set('brickfoxExportName', '');
            model.set('shopwareColumnName', '');
            break;

        case 'Shopware.apps.BrickfoxUi.view.OrderLinesAttributesMapping':
            model.set('brickfoxExportName', '');
            model.set('shopwareColumnName', '');
            break;

        case 'BrickfoxUi-view-PaymentMethodToPaymentStatusMapping':
            model.set('payment', '');
            model.set('paymentStatus', '');
            break;

        case 'Shopware.apps.BrickfoxUi.view.OrderExportByPaymentStatus':
            model.set('payment', '');
            model.set('paymentStatus', '');
            break;

        case 'Shopware.apps.BrickfoxUi.view.ImageAttributesMapping':
            model.set('attributesCode', '');
            model.set('mappingFieldKey', '');
            break;
        }

        view.store.add(model);
        view.editingPlugin.startEdit(model, 1);
    },

    onDeleteRow: function (view) {
        var selectedRows = view.getSelectionModel().getSelection();

        if (selectedRows.length) {
            Ext.MessageBox.confirm('Info', 'Sind Sie sicher das Sie diesen Datensatz löschen wollen?', function (btn) {
                if (btn === 'yes') {
                    view.store.remove(selectedRows);
                    view.store.suspendAutoSync();
                    view.store.destroy(selectedRows);
                    view.store.resumeAutoSync();
                    Shopware.Notification.createSuccessMessage('Löschen erfolgreich.', 'Daten konnten gelöscht werden.');
                }
            });
        } else {
            Shopware.Notification.createNoticeMessage('Info', 'Bitte wählen Sie ein Attribut aus das Sie löschen möchten.');
        }
    },

    onSaveMapping: function (view) {
        view.store.save({
            success: function (batch, eOpts) {
                Shopware.Notification.createSuccessMessage('Speichern erfolgreich.', 'Daten konnten gespeichert werden.');
            },
            failure: function (batch, eOpts) {
                Shopware.Notification.createErrorMessage('Speichern fehlgeschlagen.', 'Daten konnten nicht gespeichert werden.');
            }
        });

        view.store.load();
    }
});
// {/block}