// {namespace name=backend/BrickfoxUi/view}
// {block name=backend/BrickfoxUi/view/Main}
Ext.define('Shopware.apps.BrickfoxUi.view.Main', {

    extend: 'Enlight.app.Window',

    alias: 'widget.BrickfoxUi-view-main',

    layout: 'fit',

    width: 900,

    height: '90%',

    autoShow: true,

    stateful: true,

    stateId: 'BrickfoxUi-view-main',

    title: '{s name=main/Window/title}Connector Konfiguration{/s}',

    iconCls: 'bf_icon_settings',

    initComponent: function () {
        var me = this;

        me.callParent(arguments);
    },

    createTabPanel: function () {
        var me = this;

        me.start = Ext.widget('BrickfoxUi-view-Overview', {
            overview: me.overview,
            main:     me
        });
        me.start.on('activate', me.start.init);

        me.configuration = Ext.widget('BrickfoxUi-view-Configuration', {
            configuration: me.configuration,
            main:          me
        });

        me.attributesMapping = Ext.widget('BrickfoxUi-view-AttributesMapping', {
            attributesMapping: me.attributesMapping,
            main:              me
        });
        me.attributesMapping.on('activate', me.attributesMapping.init);

        me.filterMapping = Ext.widget('BrickfoxUi-view-FilterMapping', {
            filterMapping: me.filterMapping,
            main:          me
        });
        me.filterMapping.on('activate', me.filterMapping.init);

        /*me.customizedMapping = Ext.widget('BrickfoxUi-view-CustomizedMapping', {
         customizedMapping: me.customizedMapping,
         main: me
         });
         me.customizedMapping.on('activate', me.customizedMapping.init);*/

        me.translationMapping = Ext.widget('BrickfoxUi-view-TranslationMapping', {
            translationMapping: me.translationMapping,
            main:               me
        });
        me.translationMapping.on('activate', me.translationMapping.init);

        me.currenciesMapping = Ext.widget('BrickfoxUi-view-CurrenciesMapping', {
            currenciesMapping: me.currenciesMapping,
            main:              me
        });
        me.currenciesMapping.on('activate', me.currenciesMapping.init);

        me.shippingMapping = Ext.widget('BrickfoxUi-view-ShippingMapping', {
            shippingMapping: me.shippingMapping,
            main:            me
        });
        me.shippingMapping.on('activate', me.shippingMapping.init);

        me.taxMapping = Ext.widget('BrickfoxUi-view-TaxMapping', {
            taxMapping: me.taxMapping,
            main:       me
        });
        me.taxMapping.on('activate', me.taxMapping.init);

        me.shopsMapping = Ext.widget('BrickfoxUi-view-ShopsMapping', {
            shopsMapping: me.shopsMapping,
            main:         me
        });
        me.shopsMapping.on('activate', me.shopsMapping.init);

        me.orderAttributesMapping = Ext.widget('BrickfoxUi-view-OrderAttributesMapping', {
            orderAttributesMapping: me.orderAttributesMapping,
            main:                   me
        });

        me.imagesAttributesMapping = Ext.widget('BrickfoxUi-view-ImageAttributesMapping', {
            imagesAttributesMapping: me.imagesAttributesMapping,
            main:                   me
        });

        me.orderLinesAttributesMapping = Ext.widget('BrickfoxUi-view-OrderLinesAttributesMapping', {
            orderLinesAttributesMapping: me.orderLinesAttributesMapping,
            main:                        me
        });

        me.paymentMethodToPaymentStatusMapping = Ext.widget('BrickfoxUi-view-PaymentMethodToPaymentStatusMapping', {
            paymentMethodToPaymentStatusMapping: me.paymentMethodToPaymentStatusMapping,
            main:                                me
        });

        me.orderExportByPaymentStatus = Ext.widget('BrickfoxUi-view-OrderExportByPaymentStatus', {
            orderExportByPaymentStatus: me.orderExportByPaymentStatus,
            main:                       me
        });
        me.orderExportByPaymentStatus.on('activate', me.orderExportByPaymentStatus.init);

        me.tabpanel = Ext.create('Ext.tab.Panel', {
            items: [
                me.start,
                me.configuration,
                me.attributesMapping,
                me.imagesAttributesMapping,
                me.filterMapping,
                me.currenciesMapping,
                me.shippingMapping,
                me.taxMapping,
                me.translationMapping,
                me.shopsMapping,
                me.orderAttributesMapping,
                me.orderLinesAttributesMapping,
                me.paymentMethodToPaymentStatusMapping,
                me.orderExportByPaymentStatus
            ]
        });

        me.add(me.tabpanel);
    }

});
// {/block}