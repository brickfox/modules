Ext.define('Shopware.apps.BrickfoxUi.view.PaymentMethodToPaymentStatusMapping', {
    extend: 'Ext.grid.Panel',

    alias: 'widget.BrickfoxUi-view-PaymentMethodToPaymentStatusMapping',

    title: '{s name=BrickfoxUi/view/payment/method/to/payment/status/Mapping/title}Zahlstatus zu Zahlungsart mappen, bei erfolgreichem Versand{/s}',

    layout: 'border',

    autoScroll: true,

    border: false,

    store: Ext.create('Shopware.apps.BrickfoxUi.store.PaymentMethodToPaymentStatusMapping'),

    selType: 'checkboxmodel',

    selModel: {
        mode: 'MULTI'
    },

    viewConfig: {
        stripeRows: true
    },

    isBuilt: false,

    comboStorePayment: Ext.create('Shopware.apps.BrickfoxUi.store.combo.PaymentMapping'),

    comboStorePaymentStatus: Ext.create('Shopware.apps.BrickfoxUi.store.combo.PaymentStatusMapping'),

    init: function () {
        var me = this;

        me.getView().setLoading(true);
        if (me.isBuilt === true) {
            me.fireEvent('reloadMapping', me);
        }
        me.getView().setLoading(false);

    },

    initComponent: function () {
        var me = this;

        me.registerEvents();
        me.store.load();
        me.columns = me.buildColumns();
        me.plugins = me.buildEditingPlugin();
        me.tbar = me.buildToolbar();
        me.dockedItems = me.buildToolbarBottom();

        me.callParent(arguments);

        me.isBuilt = true;
    },

    registerEvents: function () {
        var me = this;

        me.addEvents('add', 'delete', 'save', 'reloadMapping', 'validateUniqueReference');
    },

    buildEditingPlugin: function () {
        return Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToEdit: 2
        });
    },

    buildColumns: function () {
        var me = this;

        return [
            {
                header: '{s name=BrickfoxUi/view/paymentMethodToPaymentStatus/Mapping/Column/Id}Id{/s}',
                dataIndex: 'id',
                hidden: true,
                width: 35
            },
            {
                header: '{s name=BrickfoxUi/view/paymentMethodToPaymentStatus/Mapping/Column/SwPayment}Zahlungsart{/s}',
                dataIndex: 'paymentId',
                flex: 1,
                editor:    {
                    xtype:        'combobox',
                    displayField: 'shopwareFieldKeyName',
                    valueField:   'shopwareFieldKeyCode',
                    allowBlank:   false,
                    queryMode:    'local',
                    store:        me.comboStorePayment
                },
                renderer:  function (val) {
                    var index = me.comboStorePayment.findExact('shopwareFieldKeyCode', val),
                        rs,
                        result = '';

                    if (index != -1) {
                        rs = me.comboStorePayment.getAt(index).data;
                        result = rs.shopwareFieldKeyName;
                    } else {
                        result = val;
                    }

                    return result;
                }
            },
            {
                header: '{s name=BrickfoxUi/view/paymentMethodToPaymentStatus/Mapping/Column/SwPaymentStatus}Zahlungsstatus-Bestellung{/s}',
                dataIndex: 'paymentStatusId',
                flex: 1,
                editor:    {
                    xtype:        'combobox',
                    displayField: 'shopwareFieldKeyName',
                    valueField:   'shopwareFieldKeyCode',
                    allowBlank:   false,
                    queryMode:    'local',
                    store:        me.comboStorePaymentStatus
                },
                renderer:  function (val) {
                    var index = me.comboStorePaymentStatus.findExact('shopwareFieldKeyCode', val),
                        rs,
                        result = '';

                    if (index != -1) {
                        rs = me.comboStorePaymentStatus.getAt(index).data;
                        result = rs.shopwareFieldKeyName;
                    } else {
                        result = val;
                    }

                    return result;
                }
            }
        ];
    },

    buildToolbar: function () {
        var me = this,
            buttons = [];


        buttons.push(
            Ext.create('Ext.button.Button', {
                text:    '{s name=BrickfoxUi/view/shipping/Mapping/Toolbar/Add/Title}Hinzufügen{/s}',
                iconCls: 'sprite-plus-circle-frame',
                handler: function () {
                    me.fireEvent('add', me)
                }
            })
        );

        buttons.push(
            Ext.create('Ext.button.Button', {
                text:    '{s name=BrickfoxUi/view/shipping/Mapping/Toolbar/Delete/Title}Löschen{/s}',
                iconCls: 'sprite-minus-circle-frame',
                handler: function () {
                    me.fireEvent('delete', me);
                }
            })
        );

        buttons.push({
            xtype: 'tbfill'
        });

        buttons.push({
            xtype:             'textfield',
            name:              'searchfield',
            width:             170,
            cls:               'searchfield',
            enableKeyEvents:   true,
            checkChangeBuffer: 500,
            emptyText:         '{s name=BrickfoxUi/view/shipping/Mapping/Toolbar/Search}Suchen..{/s}',
            listeners:         {
                'change': function (field, value) {
                    var store = me.store,
                        searchString = Ext.String.trim(value);

                    //scroll the store to first page
                    store.currentPage = 1;

                    //if the search-value is empty, reset the filter
                    if (searchString.length === 0) {
                        store.clearFilter();
                    } else {
                        //this won't reload the store
                        store.filters.clear();

                        //loads the store with a special filter
                        store.filter('search', searchString);
                    }
                }
            }
        });

        buttons.push({
            xtype: 'tbspacer',
            width: 6
        });

        return Ext.create('Ext.toolbar.Toolbar', {
            ui:    'shopware-ui',
            items: buttons
        });
    },

    buildToolbarBottom: function () {
        var me = this;

        return Ext.create('Ext.toolbar.Toolbar', {
            cls:   'shopware-toolbar',
            dock:  'bottom',
            ui:    'shopware-ui',
            items: [
                Ext.create('Ext.PagingToolbar', {
                    store:       me.store,
                    displayInfo: true
                }),
                {
                    xtype: 'tbfill'
                },
                {
                    xtype: 'tbspacer',
                    width: 6
                },
                {
                    xtype:   'button',
                    text:    '{s name=BrickfoxUi/view/configuration/button/save}Speichern{/s}',
                    cls:     'primary',
                    handler: function () {
                        me.fireEvent('saveAttribute', me);
                    }
                }
            ]
        });
    }
});