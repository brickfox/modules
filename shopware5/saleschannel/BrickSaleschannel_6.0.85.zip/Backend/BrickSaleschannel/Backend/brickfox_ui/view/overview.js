// {namespace name=backend/BrickfoxUi/view}
// {block name=backend/BrickfoxUi/view/Overview}
Ext.define('Shopware.apps.BrickfoxUi.view.Overview', {

    extend: 'Ext.form.Panel',

    alias: 'widget.BrickfoxUi-view-Overview',

    title: '{s name=BrickfoxUi/view/start/title}Übersicht{/s}',

    autoScroll: true,

    cls: 'shopware-form',

    layout: 'anchor',

    border: false,

    store: Ext.create('Shopware.apps.BrickfoxUi.store.Overview'),

    isBuilt: false,

    default: {
        anchor:     '100%',
        margin:     10,
        labelWidth: '33%'
    },

    init: function () {
        var me = this;

        if (me.isBuilt === false) {
            me.buildItems();

            me.store.load({
                callback: function (records) {
                    me.loadRecord(records[0]);
                }
            });
        } else {
            me.fireEvent('check', me);
        }
    },

    initComponent: function () {
        var me = this;
        me.registerEvents();
        me.callParent(arguments);
    },

    registerEvents: function () {
        var me = this;

        me.addEvents('check');
    },

    buildItems: function () {
        var me = this;

        me.add([
            {
                xtype:    'fieldset',
                title:    'Server - Konfiguration',
                defaults: {
                    anchor:     '100%',
                    labelWidth: '33%',
                    xtype:      'displayfield'
                },
                items:    [
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/PhpVersion}PHP-Version{/s}',
                        name:       'phpVersion'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/MemoryLimit}Memory-Limit{/s}',
                        name:       'phpMemoryLimit'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/MaxExecutionTime}Script-Laufzeit{/s}',
                        name:       'phpMaxExecutionTime'
                    }
                ]
            },
            {
                xtype:    'fieldset',
                title:    'Gespeicherte Plugin - Konfiguration',
                defaults: {
                    anchor:     '100%',
                    labelWidth: '33%',
                    xtype:      'displayfield'
                },
                items:    [
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/pluginMode}Modus{/s}',
                        value:      'Brickfox ist PIM'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUio/view/overview/displayField/masterShopsName}Master - Shop{/s}',
                        name:       'masterShopName'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/configuration/textfield/brickfoxCustomerUrl}Brickfox - Mandanten URL{/s}',
                        name:       'brickfoxCustomerUrl'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/configuration/textfield/brickfoxApiKey}Brickfox REST API - KEY{/s}',
                        name:       'brickfoxApiKey'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUio/view/overview/displayField/incomingPath}Pfad für eingehende XML Dateien{/s}',
                        name:       'incomingPath'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUio/view/overview/displayField/outgoingPath}Pfad für ausgehende XML Dateien{/s}',
                        name:       'outgoingPath'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUio/view/overview/displayField/imagePath}Bild - Pfad für initiale Importe{/s}',
                        name:       'imagePath'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/logging}Logging aktiv{/s}',
                        name:       'logging'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/logPath}Pfad für Logfiles{/s}',
                        name:       'logPath'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/overview/displayField/scriptLogger}Zurücksetzen des Script-Logger{/s}',
                        name:       'scriptLogger'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/overview/displayField/httpsProtocol}Server-Protokoll https{/s}',
                        name:       'serverProtocol'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/combobox/variationTemplate}Varianten - Template{/s}',
                        name:       'variationTemplateId'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/combobox/ItemNumber}Brickfox Varianten-Artikelnummern sind Shopware Artikelnummern{/s}',
                        name:       'useOnlyVariationsItemNumbers'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuiration/combobox/MultiAttributes}Brickfox Mehrfach-Attribut Trennzeichen{/s}',
                        name:       'multiAttributesSymbol'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuiration/combobox/OrderStatusExport}Bestellungen mit Status exportieren{/s}',
                        name:       'orderStatusMultiSelectIdDescription'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/ignoreOrdersByShopsIds}Bestellungen für Shops ignorieren{/s}',
                        name:       'ignoreOrdersByShopsIds'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/checkbox/overWriteMetaElements}Meta-Daten überschreiben{/s}',
                        name:       'overWriteMetaElements'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/mainLanguagesCode}Hauptsprachen ISO-Code{/s}',
                        name:       'mainLanguagesCode'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/sendPendingMail}Automatische Bestellstatus-Mail versenden (In Bearbeitung){/s}',
                        name:       'sendPendingMail'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/sendMail}Automatische Bestellstatus-Mail versenden (Komplett abgeschlossen){/s}',
                        name:       'sendMail'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/defaultCustomerGroupKeys}Standard Kundengruppen Key{/s}',
                        name:       'defaultCustomerGroup'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/urlDescriptionActive}Bild-Url als Bildbeschreibung verwenden{/s}',
                        name:       'urlDescriptionActive'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/imageUrlWithoutExtension}Bilder ohne Dateiendung importieren{/s}',
                        name:       'imageUrlWithoutExtension'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/ignoreImagesImport}Bild - Informationen ignorieren{/s}',
                        name:       'ignoreImagesImport'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/keepMissingImagesInImport}Fehlende Bilder beim Import beibehalten{/s}',
                        name:       'keepMissingImagesInImport'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/imageMappingDiffsOptionsCheckBox}Varianten-Bilder-Mapping aktivieren{/s}',
                        name:       'imageMappingDiffsOptionsStatus'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuiration/combobox/imageMappingDiffsOptions}Variantenmerkmale für Bilder-Mapping auswählen{/s}',
                        name:       'imageMappingDiffsOptions'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/ignoreCategoriesImportFromMultiShop}Kategorie import bei Multishop ignorieren{/s}',
                        name:       'ignoreCategoriesImportFromMultiShop'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/cleanApiAfterDays}Import-Daten nach X-Tage(n) bereinigen{/s}',
                        name:       'cleanApiAfterDays'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/cleanBfLogAfterDays}Log-Daten nach X-Tage(n) bereinigen{/s}',
                        name:       'cleanBfLogAfterDays',
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/cleanBfScriptloggerAfterDays}Scriptlogger-Daten nach X-Tage(n) bereinigen{/s}',
                        name:       'cleanBfScriptloggerAfterDays',
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/categoryDenormalization}Kategorien nach Import neu aufbauen{/s}',
                        name:       'categoryDenormalization'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/releaseDateFromAttribute}Erscheinungsdatum = Attributwert aus brickfox{/s}',
                        name:       'releaseDateFromAttribute'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/shippingFreeFromAttribute}Versandkostenfrei = Attributwert aus brickfox{/s}',
                        name:       'shippingFreeFromAttribute'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/costChangingAsCoupons}Warenkorb-Rabatt als Gutschein-Exportieren{/s}',
                        name:       'costChangingAsCoupon'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/sortOrderAttributes}Attribut-Sortierung aus brickfox übernehmen{/s}',
                        name:       'sortOrderAttributes'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/packageOrMeasurement}Verpackungsmaße / Artikelmaße{/s}',
                        name:       'packageOrMeasurementId'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/strikeThroughPriceRules}Streichpreis-Regeln{/s}',
                        name:       'strikeThroughPriceRulesId'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/ignoreDelivery}Lieferzeit ignorieren{/s}',
                        name:       'ignoreDelivery'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/createDateCode}Anlage-Datum Attr-Code{/s}',
                        name:       'createDateCode'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/emailNotificationCode}Email-Benachrichtigung Attr-Code{/s}',
                        name:       'emailNotificationCode'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/keepAttributesOnImport}Attribute bei Import beibehalten{/s}',
                        name:       'keepAttributesOnImport'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/exportTaxesForNetOrders}Mehrwertsteuer für Nettobestellungen exportieren:{/s}',
                        name:       'exportTaxesForNetOrders'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/checkbox/disableBfPriceUpdates}Preisaktualisierung deaktivieren{/s}',
                        name:       'disableBfPriceUpdates'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/checkbox/imageDescriptionAttributeName}Bildattribut für Bildbeschreibung{/s}',
                        name:       'imageDescriptionAttributeName'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/carrierAttributeFieldName}Bestellung-Attribut-Feld für Versender{/s}',
                        name: 'carrierAttributeFieldName'
                    },
                    {
                        name: 'excludeCustomerGroupAttributeFieldCode',
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/excludeCustomerGroupAttributeFieldCode}Attributscode Kundengruppen aus BF-Attribut ausschließen{/s}',
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/checkbox/enableEmailNotificationsOnError}E-Mailbenachrichtigungen für Fehler aktivieren{/s}',
                        name: 'enableEmailNotificationsOnError',
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/emailNotificationErrorCodes}E-Mailbenachrichtigungen für Fehlercodes{/s}',
                        name: 'emailNotificationErrorCodes',
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/emailNotificationReceivers}E-Mailbenachrichtigungsempfänger{/s}',
                        name: 'emailNotificationReceivers',
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/ignoreLongDescription}Produktbeschreibung ignorieren{/s}',
                        name: 'ignoreLongDescription',
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/surchargeCodes}Preisaufschläge Artikelnummern{/s}',
                        name: 'surchargeCodes',
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/preventPriceModelsRewrite}Preise beim Import nicht neu schreiben{/s}',
                        name: 'preventPriceModelsRewrite'
                    },
                    {
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/savingOptionCodeAttributeFieldName}Feld Name der Wert aus dem "code"-Attribute gespeichert werden soll{/s}',
                        name: 'savingOptionCodeAttributeFieldName'
                    }
                ]
            },
            {
                xtype:    'fieldset',
                title:    'Letzte Importe',
                defaults: {
                    anchor:     '100%',
                    labelWidth: '33%',
                    xtype:      'displayfield'
                },
                items:    [
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/lastProductsImport}Letzter Produkt-Import{/s}',
                        name:       'lastProductsImport'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/lastProductsUpdateImport}Letzter Produkt Aktualisierung{/s}',
                        name:       'lastProductsUpdateImport'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/lastCategoriesImport}Letzter Kategorie-Import{/s}',
                        name:       'lastCategoriesImport'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/lastSuppliersImport}Letzter Hersteller-Import{/s}',
                        name:       'lastSuppliersImport'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/lastMultiShopImport}Letzter Multishop-Import{/s}',
                        name:       'lastMultiShopImport'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/lastOrderStatusImport}Letzter Bestellstatus-Import{/s}',
                        name:       'lastOrderStatusImport'
                    }
                ]
            },
            {
                xtype:    'fieldset',
                title:    'Letzte Exporte',
                defaults: {
                    anchor:     '100%',
                    labelWidth: '33%',
                    xtype:      'displayfield'
                },
                items:    [
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/lastOrderStatusExport}Letzter Bestell-Export{/s}',
                        name:       'lastOrderExport'
                    }
                ]
            },
            {
                xtype:    'fieldset',
                title:    'Sonstiges',
                defaults: {
                    anchor:     '100%',
                    labelWidth: '33%',
                    xtype:      'displayfield'
                },
                items:    [
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/importedArticleCount}Importierte Artikel{/s}',
                        name:       'importedArticle'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/importedCategories}Importierte Kategorien{/s}',
                        name:       'importedCategories'
                    },
                    {
                        fieldLabel: '{s name=BrickfoxUi/view/overview/displayField/importedSuppliers}Importierte Hersteller{/s}',
                        name:       'importedSuppliers'
                    }
                ]
            }
        ]);
        me.isBuilt = true;
    }
});
//{/block}