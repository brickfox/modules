// {namespace name=backend/BrickfoxUi/view}
// {block name=backend/BrickfoxUi/view/ImageAttributesMapping}
Ext.define('Shopware.apps.BrickfoxUi.view.ImageAttributesMapping', {

    extend: 'Ext.grid.Panel',

    alias: 'widget.BrickfoxUi-view-ImageAttributesMapping',

    title: '{s name=BrickfoxUi/view/order/Image/Attributes/Mapping/title}Bild-Attribut Mapping brickfox zu Shopware{/s}',

    layout: 'border',

    autoScroll: true,

    border: false,

    store: Ext.create('Shopware.apps.BrickfoxUi.store.ImageAttributesMapping'),

    selType: 'checkboxmodel',

    selModel: {
        mode: 'MULTI'
    },

    viewConfig: {
        stripeRows: true
    },

    isBuilt: false,

    // validateListUrl: 'BrickfoxUi/getShippingStatusMappingList',

    listeners: {
        delay:          1, //time for render
        'validateedit': function (editor, e) {
            //this.fireEvent('validateUniqueReference', this, editor, e, this.validateListUrl, 'mappingFieldKey');
        }
    },

    initComponent: function () {
        var me = this;

        me.registerEvents();

        me.columns = me.buildColumns();
        me.plugins = me.buildEditingPlugin();
        me.tbar = me.buildToolbar();
        me.dockedItems = me.buildToolbarBottom();

        me.callParent(arguments);

        me.isBuilt = true;
    },

    registerEvents: function () {
        var me = this;

        me.addEvents('add', 'delete', 'save', 'reloadMapping', 'validateUniqueReference');
    },

    buildEditingPlugin: function () {
        return Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToEdit: 2
        });
    },

    buildColumns: function () {
        return [
            {
                header:    '{s name=BrickfoxUi/view/order/Attributes/Mapping/Column/Id}Id{/s}',
                dataIndex: 'id',
                hidden:    true,
                width:     15
            },
            {
                header:    '{s name=BrickfoxUi/view/image/Attributes/Mapping/Column/bfImageCode}Bild-Attribut-Code{/s}',
                dataIndex: 'attributesCode',
                flex:      1,
                editor:    {
                    xtype:      'textfield',
                    allowBlank: false
                }
            },
            {
                header:    '{s name=BrickfoxUi/view/order/Attributes/Mapping/Column/ShopwareColumnName}Attribut - Spaltenname {/s}',
                dataIndex: 'mappingFieldKey',
                flex:      1,
                editor:    {
                    xtype:      'textfield',
                    allowBlank: false
                }
            }
        ];
    },

    buildToolbar: function () {
        var me = this,
            buttons = [];


        buttons.push(
            Ext.create('Ext.button.Button', {
                text:    '{s name=BrickfoxUi/view/shipping/Mapping/Toolbar/Add/Title}Hinzufügen{/s}',
                iconCls: 'sprite-plus-circle-frame',
                handler: function () {
                    me.fireEvent('add', me)
                }
            })
        );

        buttons.push(
            Ext.create('Ext.button.Button', {
                text:    '{s name=BrickfoxUi/view/shipping/Mapping/Toolbar/Delete/Title}Löschen{/s}',
                iconCls: 'sprite-minus-circle-frame',
                handler: function () {
                    me.fireEvent('delete', me);
                }
            })
        );

        buttons.push({
            xtype: 'tbfill'
        });

        buttons.push({
            xtype:             'textfield',
            name:              'searchfield',
            width:             170,
            cls:               'searchfield',
            enableKeyEvents:   true,
            checkChangeBuffer: 500,
            emptyText:         '{s name=BrickfoxUi/view/shipping/Mapping/Toolbar/Search}Suchen..{/s}',
            listeners:         {
                'change': function (field, value) {
                    var store = me.store,
                        searchString = Ext.String.trim(value);

                    //scroll the store to first page
                    store.currentPage = 1;

                    //if the search-value is empty, reset the filter
                    if (searchString.length === 0) {
                        store.clearFilter();
                    } else {
                        //this won't reload the store
                        store.filters.clear();

                        //loads the store with a special filter
                        store.filter('search', searchString);
                    }
                }
            }
        });

        buttons.push({
            xtype: 'tbspacer',
            width: 6
        });

        return Ext.create('Ext.toolbar.Toolbar', {
            ui:    'shopware-ui',
            items: buttons
        });
    },

    buildToolbarBottom: function () {
        var me = this;

        return Ext.create('Ext.toolbar.Toolbar', {
            cls:   'shopware-toolbar',
            dock:  'bottom',
            ui:    'shopware-ui',
            items: [
                Ext.create('Ext.PagingToolbar', {
                    store:       me.store,
                    displayInfo: true
                }),
                {
                    xtype: 'tbfill'
                },
                {
                    xtype: 'tbspacer',
                    width: 6
                },
                {
                    xtype:   'button',
                    text:    '{s name=BrickfoxUi/view/configuration/button/save}Speichern{/s}',
                    cls:     'primary',
                    handler: function () {
                        me.fireEvent('saveAttribute', me);
                    }
                }
            ]
        });
    }
});
// {/block}