// {namespace name=backend/BrickfoxUi/view}
// {block name=backend/BrickfoxUi/view/Configuration}
Ext.define('Shopware.apps.BrickfoxUi.view.Configuration', {

    extend: 'Ext.form.Panel',

    alias: 'widget.BrickfoxUi-view-Configuration',

    title: '{s name=BrickfoxUi/view/configuration/title}Plugin-Konfiguration{/s}',

    autoScroll: true,

    cls: 'shopware-form',

    layout: 'anchor',

    border: false,

    initComponent: function () {
        var me    = this,
            store = Ext.create('Shopware.apps.BrickfoxUi.store.Configuration');

        me.items = me.buildItems();
        me.dockedItems = me.buildToolbar();
        me.registerEvents();

        me.callParent(arguments);

        store.load({
            callback: function (records) {
                me.loadRecord(records[0]);
                me.getForm().getFields().get('orderStatusMultiSelectId').setValue(records[0].raw.orderStatusMultiSelectId, true);
            }
        });
    },

    registerEvents: function () {
        var me = this;

        me.addEvents('save');
    },

    buildItems:   function () {
        var me = this;

        return [
            {
                xtype:    'fieldset',
                title:    'Konfiguration',
                defaults: {
                    anchor:     '100%',
                    labelWidth: '33%'
                },
                id:       'configurationForm',
                items:    [
                    {
                        xtype:      'displayfield',
                        fieldLabel: '{s name=BrickfoxUi/view/configuration/combobox/pluginMode}Modus{/s}',
                        value:      'Brickfox ist PIM'
                    },
                    {
                        xtype:      'textfield',
                        name:       'masterShopName',
                        fieldLabel: '{s name=BrickfoxUi/view/configuration/textfield/masterShopsName}Name des Master - Shop{/s}',
                        allowBlank: false,
                        value:      ''
                    },
                    {
                        xtype:      'textfield',
                        name:       'brickfoxCustomerUrl',
                        fieldLabel: '{s name=BrickfoxUi/view/configuration/textfield/brickfoxCustomerUrl}Brickfox - Mandanten URL{/s}',
                        allowBlank: false,
                        value:      ''
                    },
                    {
                        xtype:      'textfield',
                        inputType:  'password',
                        name:       'brickfoxApiKey',
                        fieldLabel: '{s name=BrickfoxUi/view/configuration/textfield/brickfoxApiKey}Brickfox REST API - KEY Passwort{/s}',
                        allowBlank: false,
                        value:      ''
                    },
                    {
                        xtype:      'textfield',
                        name:       'incomingPath',
                        fieldLabel: '{s name=BrickfoxUio/view/configuration/textfield/incomingPath}Pfad für eingehende XML Dateien{/s}',
                        allowBlank: false,
                        value:      ''
                    },
                    {
                        xtype:      'textfield',
                        name:       'outgoingPath',
                        fieldLabel: '{s name=BrickfoxUio/view/configuration/textfield/outgoingPath}Pfad für ausgehende XML Dateien{/s}',
                        allowBlank: false
                    },
                    {
                        xtype:      'textfield',
                        name:       'imagePath',
                        fieldLabel: '{s name=BrickfoxUio/view/overview/displayField/imagePath}Bild - Pfad für initiale Importe{/s}',
                        allowBlank: false
                    },
                    {
                        xtype:        'combobox',
                        editable:     false,
                        name:         'logging',
                        fieldLabel:   '{s name=BrickfoxUi/view/configuration/combobox/logging}Logging aktivieren{/s}',
                        allowBlank:   false,
                        queryMode:    'local',
                        displayField: 'name',
                        valueField:   'logging',
                        store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.Logging').load(),
                        id:           'comboLogging'
                    },
                    {
                        xtype:      'textfield',
                        name:       'logPath',
                        fieldLabel: '{s name=BrickfoxUi/view/configuration/textfield/logPath}Pfad für Logfiles{/s}',
                        allowBlank: false
                    },
                    {
                        xtype:         'numberfield',
                        name:          'scriptLogger',
                        fieldLabel:    '{s name=Brickfox/view/overview/displayField/scriptLogger}Zurücksetzen des Script-Logger{/s}',
                        allowBlank:    false,
                        allowDecimals: false
                    },
                    {
                        xtype:       'checkbox',
                        name:        'serverProtocol',
                        fieldLabel:  '{s name=Brickfox/view/overview/displayField/httpsProtocol}Server-Protokoll https{/s}',
                        supportText: 'Wenn aktiv, wird als Server Protokoll https verwendet'
                    },
                    {
                        xtype:        'combobox',
                        editable:     false,
                        name:         'variationTemplateId',
                        fieldLabel:   '{s name=Brickfox/view/configuration/combobox/variationTemplate}Varianten - Template{/s}',
                        allowBlank:   false,
                        queryMode:    'local',
                        displayField: 'variationTemplateName',
                        valueField:   'variationTemplateId',
                        store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.VariationTemplate').load(),
                        id:           'comboVariationTemplate'
                    },
                    {
                        xtype:       'checkbox',
                        name:        'useOnlyVariationsItemNumbers',
                        fieldLabel:  '{s name=Brickfox/view/configuration/combobox/ItemNumber}brickfox Varianten-Artikelnummern{/s}',
                        supportText: 'Wenn Sie diese Option aktivieren, werden die in brickfox hinterlegten Varianten - Artikelnummern als Shopware Artikelnummern verwendet. Ansonsten wird die brickfox Stamm - Artikelnummer Systemintern verwendet (Shopware - Standard).'
                    },
                    {
                        xtype:       'textfield',
                        name:        'multiAttributesSymbol',
                        fieldLabel:  '{s name=Brickfox/view/configuiration/combobox/MultiAttributes}Brickfox Mehrfach-Attribut Trennzeichen{/s}',
                        allowBlank:  false,
                        supportText: 'Bitte geben Sie das Trennzeichen ein mit dem Merfach-Attribute getrennt werden sollen.'
                    },
                    {
                        xtype:        'combobox',
                        fieldLabel:   '{s name=Brickfox/view/configuiration/combobox/OrderStatusExport}Bestellungen mit Status exportieren{/s}',
                        multiSelect:  true,
                        valueField:   'orderStatusMultiSelectId',
                        displayField: 'exportOrderStatusWithIdDescription',
                        store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.OrderStatusMultiSelect').load(),
                        queryMode:    'local',
                        name:         'orderStatusMultiSelect',
                        id:           'orderStatusMultiSelectId',
                        supportText:  'Bestimmen Sie hier den Bestellstatus mit dem die Bestellungen zu Brickfox übertragen werden sollen.'
                    },
                    {
                        xtype:       'textfield',
                        name:        'ignoreOrdersByShopsIds',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/ignoreOrdersByShopsIds}Bestellungen für Shops ignorieren{/s}',
                        supportText: 'Geben Sie eine kommagetrennte Liste von Shopware internen IDs der (Sub-)Shops an, für die Sie keine Bestellungen verarbeiten wollen.'
                    },
                    {
                        xtype:       'checkbox',
                        name:        'overWriteMetaElements',
                        fieldLabel:  '{s name=Brickfox/view/configuration/checkbox/overWriteMetaElements}Meta-Daten überschreiben{/s}',
                        supportText: 'Aktivieren damit Meta-Elemente wie bsp.: Meta-Keywords überschrieben werde.'
                    },
                    {
                        xtype:       'textfield',
                        name:        'mainLanguagesCode',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/mainLanguagesCode}Hauptsprachen ISO-Code{/s}',
                        supportText: 'Tragen Sie hier den ISO-Code Ihres Hauptshops ein.'
                    },
                    {
                        xtype:       'checkbox',
                        name:        'sendPendingMail',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/sendPendingMail}Automatische Bestellstatus-Mail versenden (In Bearbeitung){/s}',
                        supportText: 'Wenn aktiviert, werden bei Bestellstatus "In Bearbeitung" Emails automatisch an den Kunden versendet.'
                    },
                    {
                        xtype:       'checkbox',
                        name:        'sendMail',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/sendMail}Automatische Bestellstatus-Mail versenden{/s}',
                        supportText: 'Wenn aktiviert, werden bei Bestellstatus "Komplett abgeschlossen" Emails automatisch an den Kunden versendet.'
                    },
                    {
                        xtype:      'textfield',
                        name:       'defaultCustomerGroup',
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/defaultCustomerGroupKeys}Standard Kundengruppen Key{/s}',
                        value:      'EK'
                    },
                    {
                        xtype:       'checkbox',
                        name:        'urlDescriptionActive',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/urlDescriptionActive}Bild-Url als Bildbeschreibung verwenden{/s}',
                        supportText: 'Wenn aktiviert, werden bei Bild Anlage die Bild - Url\'s als Beschreibung verwendet wenn keien vorhanden ist.'
                    },
                    {
                        xtype:       'checkbox',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/imageUrlWithoutExtension}Bilder ohne Dateiendung importieren{/s}',
                        name:        'imageUrlWithoutExtension',
                        supportText: 'Wenn aktiv, werden Bilder auch ohne korrekte Bildendung importiert.'
                    },
                    {
                        xtype:       'checkbox',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/ignoreImagesImport}Bild - Informationen ignorieren{/s}',
                        name:        'ignoreImagesImport',
                        supportText: 'Wenn aktiviert, werden keine Bild - Informationen verarbeitet.'
                    },
                    {
                        xtype:       'checkbox',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/keepMissingImagesInImport}Fehlende Bilder beim Import beibehalten{/s}',
                        name:        'keepMissingImagesInImport',
                        supportText: 'Wenn aktiviert, werden Bilder die im Import fehlen, nicht in Shopware gelöscht.'
                    },
                    {
                        xtype:       'checkbox',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/imageMappingDiffsOptionsCheckBox}Varianten-Bilder-Mapping aktivieren{/s}',
                        name:        'imageMappingDiffsOptionsStatus',
                        supportText: 'Wenn aktiviert, werden gleiche Variantenbilder anhand der Merkmale zusammen gemapped und nicht einzeln angelegt.'
                    },
                    {
                        xtype:       'textfield',
                        fieldLabel:  '{s name=Brickfox/view/configuiration/combobox/imageMappingDiffsOptions}Variantenmerkmale für Bilder-Mapping auswählen{/s}',
                        name:        'imageMappingDiffsOptions',
                        supportText: 'Trgen Sie hier die Variantenmerkmal-Codes aus brickfox ein damit nur diese dann an den Variantenbildern gemapped werden.'
                    },
                    {
                        xtype:       'checkbox',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/ignoreCategoriesImportFromMultiShop}Kategorie import bei Multishop ignorieren{/s}',
                        name:        'ignoreCategoriesImportFromMultiShop',
                        supportText: 'Wenn aktiv, werden Kategoien aus dem Multishop beim importieren ignoriert.'
                    },
                    {
                        xtype:         'numberfield',
                        name:          'cleanApiAfterDays',
                        fieldLabel:    '{s name=Brickfox/view/configuration/textfield/cleanApiAfterDays}Import-Daten nach X-Tage(n) bereinigen{/s}',
                        value:         14,
                        allowDecimals: false
                    },
                    {
                        xtype:         'numberfield',
                        name:          'cleanBfLogAfterDays',
                        fieldLabel:    '{s name=Brickfox/view/configuration/textfield/cleanBfLogAfterDays}Log-Daten nach X-Tage(n) bereinigen{/s}',
                        value:         60,
                        allowDecimals: false
                    },
                    {
                        xtype:         'numberfield',
                        name:          'cleanBfScriptloggerAfterDays',
                        fieldLabel:    '{s name=Brickfox/view/configuration/textfield/cleanBfScriptloggerAfterDays}Scriptlogger-Daten nach X-Tage(n) bereinigen{/s}',
                        value:         14,
                        allowDecimals: false
                    },
                    {
                        xtype:       'checkbox',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/categoryDenormalization}Kategorien nach Import neu aufbauen{/s}',
                        name:        'categoryDenormalization',
                        supportText: 'Wenn aktiv, werden Kategorien und die Zuweisungen der Kategorien nach dem Import neu aufgebaut. < br/> Dies kann zu folge haben das' +
                                         'Produkte kurzezeit nicht im Shop aufrufbar sind.'
                    },
                    {
                        xtype:        'combobox',
                        fieldLabel:   '{s name=Brickfox/view/configuration/textfield/releaseDateFromAttribute}Erscheinungsdatum = Attributwert aus brickfox{/s}',
                        multiSelect:  false,
                        valueField:   'brickfoxFieldKeyCode',
                        displayField: 'brickfoxFieldKeyName',
                        store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.AttributesMappingBrickfox').load(),
                        queryMode:    'local',
                        name:         'releaseDateFromAttribute',
                        id:           'brickfoxFieldKeyCode',
                        supportText:  'Bestimmen Sie hier welches Attribut als Erscheinungsdatum gesetzt werden soll.'
                    },
                    {
                        xtype:        'combobox',
                        fieldLabel:   '{s name=Brickfox/view/configuration/textfield/shippingFreeFromAttribute}Versandkostenfrei = Attributwert aus brickfox{/s}',
                        multiSelect:  false,
                        valueField:   'brickfoxFieldKeyCode',
                        displayField: 'brickfoxFieldKeyName',
                        store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.AttributesMappingBrickfox').load(),
                        queryMode:    'local',
                        name:         'shippingFreeFromAttribute',
                        id:           'brickfoxFieldKeyCode',
                        supportText:  'Bestimmen Sie hier welches Attribut als Versandkostenfrei gesetzt werden soll.'
                    },
                    {
                        xtype:       'checkbox',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/costChangingAsCoupons}Warenkorb-Rabatt als Gutschein-Exportieren{/s}',
                        name:        'costChangingAsCoupon',
                        supportText: 'Wenn aktiv, werden Warenkorb-Rabatte als Gutschein-Positionen exportiert.'
                    },
                    {
                        xtype:       'checkbox',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/sortOrderAttributes}Attribut-Sortierung aus brickfox übernehmen{/s}',
                        name:        'sortOrderAttributes',
                        supportText: 'Wenn aktiv, wird die Sortierung für die Attribute/Eigenschaften aus brickfox übernommen.'
                    },
                    {
                        xtype:        'combobox',
                        fieldLabel:   '{s name=Brickfox/view/configuration/textfield/packageOrMeasurement}Verpackungsmaße / Artikelmaße{/s}',
                        multiSelect:  false,
                        valueField:   'packageOrMeasurementId',
                        displayField: 'packageOrMeasurementName',
                        store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.PackageOrMeasurement').load(),
                        queryMode:    'local',
                        name:         'packageOrMeasurementId',
                        id:           'packageOrMeasurement',
                        editable:     false,
                        supportText:  'Bestimmen Sie welche Maße an dem Produkt aus brickfox hinterlegt werden sollen Maße oder Verpackungsmaße (Gewicht, Breite, Länge, Höhe)'
                    },
                    {
                        xtype:        'combobox',
                        fieldLabel:   '{s name=Brickfox/view/configuration/textfield/commentField}Kommentar-Feld für Bestellexport{/s}',
                        multiSelect:  false,
                        valueField:   'commentId',
                        displayField: 'commentName',
                        store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.CommentMultiSelect').load(),
                        queryMode:    'local',
                        name:         'commentId',
                        id:           'commentId',
                        editable:     false
                    },
                    {
                        xtype:        'combobox',
                        fieldLabel:   '{s name=Brickfox/view/configuration/textfield/strikeThroughPriceRules}Streichpreis-Regeln{/s}',
                        multiSelect:  false,
                        valueField:   'strikeThroughPriceRulesId',
                        displayField: 'strikeThroughPriceRulesName',
                        store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.StrikeThroughPriceRules').load(),
                        queryMode:    'local',
                        name:         'strikeThroughPriceRulesId',
                        id:           'strikeThroughPriceRulesId',
                        editable:     false
                    },
                    {
                        xtype:       'checkbox',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/ignoreDelivery}Lieferzeit ignorieren{/s}',
                        name:        'ignoreDelivery',
                        supportText: 'Wenn aktiv, werden die Lierferzeit beim import ignoriert.'
                    },
                    {
                        xtype:       'textfield',
                        fieldLabel:  '{s name=Brickfox/view/configuiration/combobox/createDateCode}Anlage-Datum Attr-Code{/s}',
                        name:        'createDateCode',
                        supportText: 'Wenn Attribut-Code hinterlegt ist, wird geprüft ob das Attribut mit dem Code in der XMl enthalten ist und falls ja wird das Anlage-Datum anhand von diesem gesetzt.'
                    },
                    {
                        xtype:       'textfield',
                        fieldLabel:  '{s name=Brickfox/view/configuiration/combobox/emailNotificationCode}Email-Benachrichtigung Attr-Code{/s}',
                        name:        'emailNotificationCode',
                        supportText: 'Wenn Attribut-Code hinterlegt ist, wird geprüft ob das Attribut mit dem Code in der XMl enthalten ist und falls ja wird die Checkbox Email-Benachrichtigung anhand von diesem gesetzt.'
                    },
                    {
                        xtype:       'textfield',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/keepAttributesOnImport}Attribute bei Import beibehalten{/s}',
                        name:        'keepAttributesOnImport',
                        supportText: 'Attribute-Komma getrennt eintragen bspw.: attr1,attr2'
                    },
                    {
                        xtype:       'checkbox',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/exportTaxesForNetOrders}Mehrwertsteuer für Nettobestellungen exportieren{/s}',
                        name:        'exportTaxesForNetOrders',
                        supportText: 'sofern vorhanden'
                    },
                    {
                        xtype:       'checkbox',
                        name:        'disableBfPriceUpdates',
                        fieldLabel:  '{s name=Brickfox/view/configuration/checkbox/disableBfPriceUpdates}Preisaktualisierung deaktivieren{/s}',
                        supportText: 'Wenn aktiv, werden von Brickfox übertragene Preise nach der Produktanlage nicht mehr aktualisiert'
                    },
                    {
                        xtype:       'textfield',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/imageDescriptionAttributeName}Bildattribut für Bildbeschreibung{/s}',
                        name:        'imageDescriptionAttributeName',
                        supportText: 'z.B. attribute1, attribute2 order attribute3'
                    },
                    {
                        xtype:       'textfield',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/carrierAttributeFieldName}Bestellung-Attribut-Feld für Versender{/s}',
                        name:        'carrierAttributeFieldName',
                        supportText: 'z.B. attribute1, attribute2 order attribute3'
                    },
                    {
                        xtype:       'textfield',
                        fieldLabel:  '{s name=Brickfox/view/configuration/textfield/excludeCustomerGroupAttributeFieldCode}Attributscode Kundengruppen aus BF-Attribut ausschließen{/s}',
                        name:        'excludeCustomerGroupAttributeFieldCode',
                        supportText: 'Wenn gesetzt, können für Produkte durch ein Attribut bestimmte Kundengruppen ausgeschlossen werden z.B. via Attributscode "exclude_customer_group" in brickfox'
                    },
                    {
                        xtype: 'checkbox',
                        fieldLabel: '{s name=Brickfox/view/configuration/checkbox/enableEmailNotificationsOnError}E-Mailbenachrichtigungen für Fehler aktivieren{/s}',
                        name: 'enableEmailNotificationsOnError',
                        supportText: 'Wenn aktiv, wird für definierte Fehlercodes eine E-Mail an den/die definierten Empfänger gesendet'
                    },
                    {
                        xtype: 'textfield',
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/emailNotificationErrorCodes}E-Mailbenachrichtigungen für Fehlercodes{/s}',
                        name: 'emailNotificationErrorCodes',
                        supportText: 'Kommagetrennte Liste der numerischen Fehlercodes, für welche ein E-Mailversand erfolgen soll'
                    },
                    {
                        xtype: 'textfield',
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/emailNotificationReceivers}E-Mailbenachrichtigungsempfänger{/s}',
                        name: 'emailNotificationReceivers',
                        supportText: 'Kommagetrennte Liste von E-Mailempfängern, welche über definierte Fehler informiert werden sollen'
                    },
                    {
                        xtype: 'checkbox',
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/ignoreLongDescription}Produkt Beschreibung ignorieren{/s}',
                        name: 'ignoreLongDescription',
                        supportText: 'Wenn aktiv wird die Produktbeschreibung beim import ignoriert.'
                    },
                    {
                        xtype: 'textfield',
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/surchargeCodes}Preisaufschläge Artikelnummern{/s}',
                        name: 'surchargeCodes',
                        supportText: 'Wenn Sie Aufschläge für Versand- oder Zahlungsarten verwenden, können Sie hier die Artikelnummern dieser Positionen explizit, mit Komma getrennt, angeben (zusätzlich zu "*-surcharge" Endungen)'
                    },
                    {
                        xtype: 'checkbox',
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/preventPriceModelsRewrite}Preise beim Import nicht neu schreiben{/s}',
                        name: 'preventPriceModelsRewrite',
                        supportText: 'Wenn diese Konfiguration aktiviert ist, werden die Preise für Produkte in der Tabelle "s_articles_prices" beim Import nicht neu geschrieben. Dadurch bleiben auch die Preisattribute der Tabelle "s_articles_prices_attributes" erhalten.'
                    },
                    {
                        xtype: 'textfield',
                        fieldLabel: '{s name=Brickfox/view/configuration/textfield/savingOptionCodeAttributeFieldName}Feld Name der Wert aus dem "code"-Attribute gespeichert werden soll{/s}',
                        name: 'savingOptionCodeAttributeFieldName',
                        supportText: 'Wie das Attribut-Feld in s_article_configurator_options_attributes heißt, in das der Wert aus dem "code"-Attribute gespeichert werden soll.'
                    }
                ]
            }
        ];
    },
    buildToolbar: function () {
        var me = this;

        return Ext.create('Ext.toolbar.Toolbar', {
            cls:   'shopware-toolbar',
            dock:  'bottom',
            ui:    'shopware-ui',
            items: [
                '->',
                {
                    xtype:   'button',
                    text:    '{s name=BrickfoxUi/view/configuration/button/save}Speichern{/s}',
                    cls:     'primary',
                    handler: function () {
                        me.fireEvent('save', me);
                    }
                }
            ]
        });
    }
});
// {/block}