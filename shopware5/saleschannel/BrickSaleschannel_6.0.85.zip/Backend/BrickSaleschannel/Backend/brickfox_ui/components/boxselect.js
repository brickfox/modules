/**
 * Created by NF\kurz on 20.04.15.
 */
Ext.define('Shopware.apps.Base.view.element.BfBoxSelect', {
    extend: 'Ext.ux.form.field.BoxSelect',
    alias:  [
        'widget.BfBoxSelect'
    ],

    initComponent: function (config) {
        var me = this;

        if (me.controller && me.action) {
            //me.value = parseInt(me.value);
            me.store = new Ext.data.Store({
                url:      '{url controller=index}/' + me.controller + '/' + me.action,
                autoLoad: true,
                reader:   new Ext.data.JsonReader({
                    root:          me.root || 'data',
                    totalProperty: me.count || 'total',
                    fields:        me.fields
                })
            });
            // Remove value field for reasons of compatibility
            me.valueField = me.displayField;
        }
        // Eval the store string if it contains a statement.
        if (typeof(me.store) == 'string' && me.store.indexOf('new ') !== -1) {
            //me.value = parseInt(me.value);
            eval('me.store = ' + me.store + ';');
            // Remove value field for reasons of compatibility
            // me.valueField = me.displayField;
        }

        me.callParent(arguments);
    },

    setValue: function (value) {
        var me = this;

        if (value !== null && !me.store.loading && me.store.getCount() == 0) {
            me.store.load({
                callback: function () {
                    if (me.store.getCount() > 0) {
                        me.setValue(value);
                    } else {
                        me.setValue(null);
                    }
                }
            });
            return;
        }

        me.callParent(arguments);
    }
});