// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/PaymentMethodToPaymentStatusMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.PaymentMethodToPaymentStatusMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-PaymentMethodToPaymentStatusMapping',

    model: 'Shopware.apps.BrickfoxUi.model.PaymentMethodToPaymentStatusMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getPaymentMethodToPaymentStatusMappingList}',
            create:  '{url action=setPaymentMethodToPaymentStatusMapping}',
            update:  '{url action=setPaymentMethodToPaymentStatusMapping}',
            destroy: '{url action=deletePaymentMethodToPaymentStatusMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }

});
// {/block}