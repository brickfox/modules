// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/TranslationMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.TranslationMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-TranslationMapping',

    model: 'Shopware.apps.BrickfoxUi.model.combo.TranslationMapping',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getTranslationMappingDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}