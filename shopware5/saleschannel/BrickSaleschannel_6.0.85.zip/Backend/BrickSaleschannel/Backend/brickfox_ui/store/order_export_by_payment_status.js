// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/OrderExportByPaymentStatus}
Ext.define('Shopware.apps.BrickfoxUi.store.OrderExportByPaymentStatus', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-OrderExportByPaymentStatus',

    model: 'Shopware.apps.BrickfoxUi.model.OrderExportByPaymentStatus',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getOrderExportByPaymentStatusList}',
            create:  '{url action=saveOrderExportByPaymentStatus}',
            update:  '{url action=saveOrderExportByPaymentStatus}',
            destroy: '{url action=deleteOrderExportByPaymentStatus}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}