// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/overview}
Ext.define('Shopware.apps.BrickfoxUi.store.Overview', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-overview',

    model: 'Shopware.apps.BrickfoxUi.model.Overview',

    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getSettingsList}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}