// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/ShippingMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.ShippingMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-ShippingMapping',

    model: 'Shopware.apps.BrickfoxUi.model.combo.ShippingMapping',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getShippingMappingDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}