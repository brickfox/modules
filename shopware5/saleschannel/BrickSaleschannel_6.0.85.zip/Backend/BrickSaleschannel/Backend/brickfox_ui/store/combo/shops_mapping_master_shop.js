// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/ShopsMappingMasterShop}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.ShopsMappingMasterShop', {
    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-ShopsMappingMasterShop',

    model: 'Shopware.apps.BrickfoxUi.model.combo.ShopsMappingMasterShop',

    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getShopsMappingMasterShopDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}