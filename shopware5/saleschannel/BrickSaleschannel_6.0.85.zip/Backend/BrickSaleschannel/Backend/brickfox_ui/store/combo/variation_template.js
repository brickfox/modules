// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/VariationTemplate}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.VariationTemplate', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-VariationTemplate',

    model: 'Shopware.apps.BrickfoxUi.model.combo.VariationTemplate',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getVariationTemplateDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}