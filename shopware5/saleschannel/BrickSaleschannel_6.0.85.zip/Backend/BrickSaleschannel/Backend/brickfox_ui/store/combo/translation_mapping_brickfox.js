// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/TranslationMappingBrickfox}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.TranslationMappingBrickfox', {

    extend: 'Ext.data.Store',

    model: 'Shopware.apps.BrickfoxUi.model.combo.TranslationMappingBrickfox',

    storeId: 'BrickfoxUi-store-combo-TranslationMappingBrickfox',

    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getLanguageMappingBrickfoxDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}