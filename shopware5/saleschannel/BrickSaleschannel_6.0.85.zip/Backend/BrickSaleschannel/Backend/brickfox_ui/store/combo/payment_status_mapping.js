// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/PaymentStatusMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.PaymentStatusMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-PaymentStatusMapping',

    model: 'Shopware.apps.BrickfoxUi.model.combo.PaymentStatusMapping',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getPaymentStatusMappingDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}