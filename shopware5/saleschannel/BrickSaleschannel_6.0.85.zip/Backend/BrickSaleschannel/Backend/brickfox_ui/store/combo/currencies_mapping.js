// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/CurrenciesMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.CurrenciesMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-CurrenciesMapping',

    model: 'Shopware.apps.BrickfoxUi.model.combo.CurrenciesMapping',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getCurrenciesMappingDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}