// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/TranslationMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.TranslationMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-TranslationMapping',

    model: 'Shopware.apps.BrickfoxUi.model.TranslationMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getTranslationMappingList}',
            create:  '{url action=saveTranslationMapping}',
            update:  '{url action=saveTranslationMapping}',
            destroy: '{url action=deleteTranslationMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}