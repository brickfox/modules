// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/ShippingMappingBrickfox}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.ShippingMappingBrickfox', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-ShippingMappingBrickfox',

    model: 'Shopware.apps.BrickfoxUi.model.combo.ShippingMappingBrickfox',

    autoLoad: false,

    pageSize: 10,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getBrickfoxShippingMappingDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}