// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/CustomizedMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.CustomizedMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-CustomizedMapping',

    model: 'Shopware.apps.BrickfoxUi.model.combo.CustomizedMapping',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getCustomizedMappingDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}