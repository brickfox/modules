// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/OrderLinesAttributesMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.OrderLinesAttributesMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-OrderLinesAttributesMapping',

    model: 'Shopware.apps.BrickfoxUi.model.OrderLinesAttributesMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getOrderLinesAttributesMappingList}',
            create:  '{url action=setNewOrderLinesAttributesMapping}',
            update:  '{url action=setNewOrderLinesAttributesMapping}',
            destroy: '{url action=deleteOrderLinesAttributesMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}