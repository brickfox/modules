// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/CurrenciesMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.CurrenciesMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-CurrenciesMapping',

    model: 'Shopware.apps.BrickfoxUi.model.CurrenciesMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getCurrenciesMappingList}',
            create:  '{url action=saveCurrenciesMapping}',
            update:  '{url action=saveCurrenciesMapping}',
            destroy: '{url action=deleteCurrenciesMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}