// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/PaymentMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.PaymentMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-PaymentMapping',

    model: 'Shopware.apps.BrickfoxUi.model.combo.PaymentMapping',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getPaymentMappingDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}