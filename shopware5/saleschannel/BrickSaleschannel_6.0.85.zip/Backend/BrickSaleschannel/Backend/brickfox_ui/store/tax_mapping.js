// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/TaxMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.TaxMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-TaxMapping',

    model: 'Shopware.apps.BrickfoxUi.model.TaxMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getTaxList}',
            create:  '{url action=setNewTax}',
            update:  '{url action=setNewTax}',
            destroy: '{url action=deleteTax}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}