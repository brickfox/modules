// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/TaxMappingBrickfox}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.TaxMappingBrickfox', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-TaxMappingBrickfox',

    model: 'Shopware.apps.BrickfoxUi.model.combo.TaxMappingBrickfox',

    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getBrickfoxTaxMappingDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}