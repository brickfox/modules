// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/CurrenciesMappingBrickfox}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.CurrenciesMappingBrickfox', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-CurrenciesMappingBrickfox',

    model: 'Shopware.apps.BrickfoxUi.model.combo.CurrenciesMappingBrickfox',

    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getBrickfoxCurrenciesMappingDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}