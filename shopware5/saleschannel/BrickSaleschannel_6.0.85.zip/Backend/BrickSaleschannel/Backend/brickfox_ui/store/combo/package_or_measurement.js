// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/PackageOrMeasurement}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.PackageOrMeasurement', {
    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-PackageOrMeasurement',

    model: 'Shopware.apps.BrickfoxUi.model.combo.PackageOrMeasurement',

    autoLoad: false,

    proxy: {
        type: 'ajax',
        api: {
            read: '{url action=getPackageOrMeasurementDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data',
            totalProperty: 'count'
        }
    }

});
// {/block}