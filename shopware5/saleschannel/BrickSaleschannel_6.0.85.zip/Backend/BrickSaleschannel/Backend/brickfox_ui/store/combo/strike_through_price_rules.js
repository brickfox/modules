// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/StrikeThroughPriceRules}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.StrikeThroughPriceRules', {
    extend:   'Ext.data.Store',
    storeId:  'BrickfoxUi-store-combo-StrikeThroughPriceRules',
    model:    'Shopware.apps.BrickfoxUi.model.combo.StrikeThroughPriceRules',
    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getStrikeThroughPriceRulesDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}