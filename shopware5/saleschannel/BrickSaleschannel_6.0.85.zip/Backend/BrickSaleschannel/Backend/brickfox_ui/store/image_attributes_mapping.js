// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/ImageAttributesMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.ImageAttributesMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-ImageAttributesMapping',

    model: 'Shopware.apps.BrickfoxUi.model.ImageAttributesMapping',

    autoLoad: true,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getImageAttributesMappingList}',
            create:  '{url action=setNewImageAttributesMapping}',
            update:  '{url action=setNewImageAttributesMapping}',
            destroy: '{url action=deleteImageAttributesMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}