// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/ShopsMappingBrickfox}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.ShopsMappingBrickfox', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-ShopsMappingBrickfox',

    model: 'Shopware.apps.BrickfoxUi.model.combo.ShopsMappingBrickfox',

    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getShopsMappingBrickfoxDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }

});
// {/block}