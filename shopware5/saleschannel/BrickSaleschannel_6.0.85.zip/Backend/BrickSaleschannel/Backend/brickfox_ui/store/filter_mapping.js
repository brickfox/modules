// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/FilterMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.FilterMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-FilterMapping',

    model: 'Shopware.apps.BrickfoxUi.model.FilterMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getFilterList}',
            create:  '{url action=setNewFilter}',
            update:  '{url action=setNewFilter}',
            destroy: '{url action=deleteFilter}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}