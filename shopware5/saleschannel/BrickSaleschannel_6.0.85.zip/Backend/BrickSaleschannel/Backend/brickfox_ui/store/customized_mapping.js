// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/CustomizedMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.CustomizedMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-CustomizedMapping',

    model: 'Shopware.apps.BrickfoxUi.model.CustomizedMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getCustomizedMappingList}',
            create:  '{url action=saveCustomizedMapping}',
            update:  '{url action=saveCustomizedMapping}',
            destroy: '{url action=deleteCustomizedMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}