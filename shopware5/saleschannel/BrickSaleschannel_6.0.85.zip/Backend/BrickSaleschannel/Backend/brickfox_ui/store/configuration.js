// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/overview}
Ext.define('Shopware.apps.BrickfoxUi.store.Configuration', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-configuation',

    model: 'Shopware.apps.BrickfoxUi.model.Configuration',

    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getMainConfiguration}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}