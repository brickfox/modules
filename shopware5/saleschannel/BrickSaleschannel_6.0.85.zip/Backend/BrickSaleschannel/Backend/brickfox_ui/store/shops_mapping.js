// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/ShopsMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.ShopsMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-ShopsMapping',

    model: 'Shopware.apps.BrickfoxUi.model.ShopsMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getShopsMappingList}',
            create:  '{url action=saveShopsMapping}',
            update:  '{url action=saveShopsMapping}',
            destroy: '{url action=deleteShopsMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}