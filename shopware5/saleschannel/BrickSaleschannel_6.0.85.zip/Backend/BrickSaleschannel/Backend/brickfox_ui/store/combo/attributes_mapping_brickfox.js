// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/AttributesMappingBrickfox}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.AttributesMappingBrickfox', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-AttributesMappingBrickfox',

    model: 'Shopware.apps.BrickfoxUi.model.combo.AttributesMappingBrickfox',

    autoLoad: false,

    pageSize: 10,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getBrickfoxAttributesMappingDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}