// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/TaxMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.TaxMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-TaxMapping',

    model: 'Shopware.apps.BrickfoxUi.model.combo.TaxMapping',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getTaxMappingDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}