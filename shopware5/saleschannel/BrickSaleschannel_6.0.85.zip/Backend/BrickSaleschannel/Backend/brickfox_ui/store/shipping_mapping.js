// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/ShippingMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.ShippingMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-ShippingMapping',

    model: 'Shopware.apps.BrickfoxUi.model.ShippingMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getShippingStatusMappingList}',
            create:  '{url action=setNewShippingStatusMapping}',
            update:  '{url action=setNewShippingStatusMapping}',
            destroy: '{url action=deleteShippingStatusMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }

});
// {/block}