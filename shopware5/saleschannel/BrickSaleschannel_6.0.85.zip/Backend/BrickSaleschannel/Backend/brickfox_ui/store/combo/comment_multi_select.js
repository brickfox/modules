Ext.define('Shopware.apps.BrickfoxUi.store.combo.CommentMultiSelect', {
    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-CommentMultiSelect',

    model: 'Shopware.apps.BrickfoxUi.model.combo.CommentMultiSelect',

    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getCommentMultiSelectCombo}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});