// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/ShopsMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.ShopsMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-ShopsMapping',

    model: 'Shopware.apps.BrickfoxUi.model.combo.ShopsMapping',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getShopsMappingDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}