// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/AttributesMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.AttributesMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-AttributesMapping',

    model: 'Shopware.apps.BrickfoxUi.model.AttributesMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getAttributesList}',
            create:  '{url action=setNewAttributes}',
            update:  '{url action=setNewAttributes}',
            destroy: '{url action=deleteAttributes}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}