// {namespace name=backend/BrickfoxUi/store}
// {block name=backend/BrickfoxUi/store/OrderAttributesMapping}
Ext.define('Shopware.apps.BrickfoxUi.store.OrderAttributesMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-OrderAttributesMapping',

    model: 'Shopware.apps.BrickfoxUi.model.OrderAttributesMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getOrderAttributesMappingList}',
            create:  '{url action=setNewOrderAttributesMapping}',
            update:  '{url action=setNewOrderAttributesMapping}',
            destroy: '{url action=deleteOrderAttributesMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}