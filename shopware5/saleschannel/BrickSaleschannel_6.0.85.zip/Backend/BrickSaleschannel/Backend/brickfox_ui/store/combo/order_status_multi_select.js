// {namespace name=backend/BrickfoxUi/store/combo}
// {block name=backend/BrickfoxUi/store/combo/OrderStatusMultiSelect}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.OrderStatusMultiSelect', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-OrderStatusMultiSelect',

    model: 'Shopware.apps.BrickfoxUi.model.combo.OrderStatusMultiSelect',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getOrderStatusMultiSelectDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}