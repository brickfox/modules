// {namespace name=backend/BrickfoxUi}
// {block name=backend/BrickfoxUi/application}
Ext.define('Shopware.apps.BrickfoxUi', {

    name: 'Shopware.apps.BrickfoxUi',

    extend: 'Enlight.app.SubApplication',

    loadPath: '{url action=load}',

    bulkLoad: true,

    controllers: [
        'Configuration',
        'Main'
    ],

    views: [
        'AttributesMapping',
        'FilterMapping',
        'Configuration',
        'CustomizedMapping',
        'CurrenciesMapping',
        'ShippingMapping',
        'OrderAttributesMapping',
        'OrderLinesAttributesMapping',
        'Main',
        'Overview',
        'ShopsMapping',
        'TranslationMapping',
        'TaxMapping',
        'PaymentMethodToPaymentStatusMapping',
        'OrderExportByPaymentStatus',
        'ImageAttributesMapping'
    ],

    stores: [
        'AttributesMapping',
        'FilterMapping',
        'CustomizedMapping',
        'CurrenciesMapping',
        'ShippingMapping',
        'OrderAttributesMapping',
        'OrderLinesAttributesMapping',
        'PaymentMethodToPaymentStatusMapping',
        'OrderExportByPaymentStatus',
        'ImageAttributesMapping',
        'combo.AttributesMappingBrickfox',
        'combo.CustomizedMapping',
        'combo.CurrenciesMapping',
        'combo.CurrenciesMappingBrickfox',
        'combo.VariationTemplate',
        'combo.TranslationMapping',
        'combo.ShopsMapping',
        'combo.ShopsMappingBrickfox',
        'combo.TranslationMappingBrickfox',
        'combo.OrderStatusMultiSelect',
        'combo.TaxMapping',
        'combo.TaxMappingBrickfox',
        'combo.ShippingMappingBrickfox',
        'combo.ShippingMapping',
        'combo.PaymentMapping',
        'combo.PaymentStatusMapping',
        'combo.PackageOrMeasurement',
        'Overview',
        'ShopsMapping',
        'TranslationMapping',
        'TaxMapping'
    ],

    models: [
        'AttributesMapping',
        'FilterMapping',
        'CustomizedMapping',
        'CurrenciesMapping',
        'ShippingMapping',
        'OrderAttributesMapping',
        'OrderLinesAttributesMapping',
        'PaymentMethodToPaymentStatusMapping',
        'OrderExportByPaymentStatus',
        'ImageAttributesMapping',
        'combo.AttributesMappingBrickfox',
        'combo.CustomizedMapping',
        'combo.CurrenciesMapping',
        'combo.CurrenciesMappingBrickfox',
        'combo.VariationTemplate',
        'combo.TranslationMapping',
        'combo.ShopsMapping',
        'combo.ShopsMappingBrickfox',
        'combo.TranslationMappingBrickfox',
        'combo.OrderStatusMultiSelect',
        'combo.TaxMapping',
        'combo.TaxMappingBrickfox',
        'combo.ShippingMappingBrickfox',
        'combo.ShippingMapping',
        'combo.PaymentMapping',
        'combo.PaymentStatusMapping',
        'combo.PackageOrMeasurement',
        'Overview',
        'ShopsMapping',
        'TranslationMapping',
        'TaxMapping'
    ],

    launch: function () {
        var me = this,
            mainController = me.getController('Main');

        return mainController.mainWindow;
    }
});
// {/block}
