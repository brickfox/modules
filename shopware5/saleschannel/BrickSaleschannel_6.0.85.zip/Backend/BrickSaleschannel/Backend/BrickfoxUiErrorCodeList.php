<?php
use Bf\Saleschannel\Components\Util\ErrorCodes;

/**
 * BrickfoxUiErrorCodeList
 * This file is part of brickfox.
 *
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */
class Shopware_Controllers_Backend_BrickfoxUiErrorCodeList extends Shopware_Controllers_Backend_ExtJs
{
    public function indexAction()
    {
    }

    public function getErrorListAction()
    {
        $list = array(
            'count' => 0,
            'data'  => array(
                array(
                    'error_code'    => ErrorCodes::CAN_NOT_FIND_CATEGORY_BY_ID_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::CAN_NOT_FIND_CATEGORY_BY_ID)
                ),
                array(
                    'error_code'    => ErrorCodes::NO_PROPERTY_VALUE_WAS_GIVEN_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::NO_PROPERTY_VALUE_WAS_GIVEN)
                ),
                array(
                    'error_code'    => ErrorCodes::NO_PROPERTY_OPTION_WAS_GIVEN_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::NO_PROPERTY_VALUE_WAS_GIVEN)
                ),
                array(
                    'error_code'    => ErrorCodes::CAN_NOT_DELETE_MEDIA_FILE_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::CAN_NOT_DELETE_MEDIA_FILE)
                ),
                array(
                    'error_code'    => ErrorCodes::VARIATION_ADDITIONAL_TEXT_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::VARIATION_ADDITIONAL_TEXT)
                ),
                array(
                    'error_code'    => ErrorCodes::READING_LOG_LIST_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::READING_LOG_LIST)
                ),
                array(
                    'error_code'    => ErrorCodes::DELETING_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::DELETING)
                ),
                array(
                    'error_code'    => ErrorCodes::CATEGORIES_MAIN_CATEGORY_EMPTY_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::CATEGORIES_MAIN_CATEGORY_EMPTY)
                ),
                array(
                    'error_code'    => ErrorCodes::CATEGORIES_LOCALE_ID_EMPTY_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::CATEGORIES_LOCALE_ID_EMPTY)
                ),
                array(
                    'error_code'    => ErrorCodes::CATEGORIES_ISO_CODE_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::CATEGORIES_ISO_CODE)
                ),
                array(
                    'error_code'    => ErrorCodes::CATEGORIES_DELETE_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::CATEGORIES_DELETE)
                ),
                array(
                    'error_code'    => ErrorCodes::ORDERS_STATUS_CAN_NOT_FIND_ORDER_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::ORDER_STATUS_CAN_NOT_FIND_ORDER)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_ASSIGNMENT_CAN_NOT_FIND_RELATE_PRODUCT_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_ASSIGNMENT_CAN_NOT_FIND_RELATE_PRODUCT)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_UPDATE_CAN_NOT_FIND_PRODUCT_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_UPDATE_CAN_NOT_FIND_PRODUCT)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_CAN_NOT_LOAD_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_CAN_NOT_LOAD)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_MISSING_DESCRIPTION_ELEMENT_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_MISSING_DESCRIPTION)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_ASSIGNMENTS_WRONG_TYPE_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_ASSIGNMENTS_WRONG_TYPE)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_ASSIGNMENTS_CAN_NOT_FIND_RESOURCE_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_ASSIGNMENT_CAN_NOT_FIND_RESOURCE)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_PROPERTY_GROUP_NOT_FOUND_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_PROPERTY_GROUP_NOT_FOUND)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_ATTRIBUTES_MODEL_NOT_FOUND_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_ATTRIBUTES_MODEL_NOT_FOUND)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_ATTRIBUTES_CAN_NOT_FIND_ATTRIBUTE_NO_UNIQUE_KEY_WAS_GIVEN_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_ATTRIBUTES_CAN_NOT_FIND_ATTRIBUTE_NO_UNIQUE_KEY_WAS_GIVEN)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_VARIATIONS_CONFIGURATOR_ITEM_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_VARIATIONS_CONFIGURATOR_ITEM)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_VARIATIONS_CONFIGURATOR_SET_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_VARIATIONS_CONFIGURATOR_SET)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_VARIATIONS_CONFIGURATOR_SET_MISSING_NODE_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_VARIATIONS_CONFIGURATOR_SET_MISSING_NODE)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_VARIATIONS_DELIVERY_TIME_MAXIMUM_CHARACTERS_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_VARIATIONS_DELIVERY_TIME_MAXIMUM_CHARACTERS)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_VARIATIONS_DELIVERY_TIME_MISSING_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCT_VARIATIONS_DELIVERY_TIME_MISSING)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_MISSING_ITEM_NUMBER_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_MISSING_ITEM_NUMBER)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_DUPLICATE_ENTRY_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_DUPLICATE_ENTRY)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_VARIATION_NO_VARIATION_ITEM_NUMBER_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_VARIATION_NO_VARIATION_ITEM_NUMBER)
                ),
                array(
                    'error_code'    => ErrorCodes::MEDIA_IS_WRITABLE_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::MEDIA_IS_WRITABLE)
                ),
                array(
                    'error_code'    => ErrorCodes::MEDIA_COULD_NOT_OPEN_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::MEDIA_COULD_NOT_OPEN)
                ),
                array(
                    'error_code'    => ErrorCodes::MEDIA_COULD_NOT_OPEN_FOR_READING_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::MEDIA_COULD_NOT_OPEN_FOR_READING)
                ),
                array(
                    'error_code'    => ErrorCodes::MEDIA_UNSUPPORTED_SCHEME_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::MEDIA_UNSUPPORTED_SCHEME)
                ),
                array(
                    'error_code'    => ErrorCodes::ALBUM_ID_NOT_FOUND_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::ALBUM_ID_NOT_FOUND)
                ),
                array(
                    'error_code'    => ErrorCodes::MEDIA_COULD_NOT_DETECT_FILE_NAME_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::MEDIA_COULD_NOT_DETECT_FILE_NAME)
                ),
                array(
                    'error_code'    => ErrorCodes::ORDERS_STATUS_CAN_NOT_LOAD_BY_ID_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::ORDERS_STATUS_CAN_NOT_LOAD_BY_ID)
                ),
                array(
                    'error_code'    => ErrorCodes::ORDERS_CAN_NOT_LOAD_DEFAULT_CUSTOMER_GROUP_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::ORDERS_CAN_NOT_LOAD_DEFAULT_CUSTOMER_GROUP)
                ),
                array(
                    'error_code'    => ErrorCodes::ORDERS_CAN_NOT_LOAD_CUSTOMER_GROUP_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::ORDERS_CAN_NOT_LOAD_CUSTOMER_GROUP)
                ),
                array(
                    'error_code'    => ErrorCodes::ORDERS_CURRENCY_CODE_IS_EMPTY_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::ORDERS_CURRENCY_CODE_IS_EMPTY)
                ),
                array(
                    'error_code'    => ErrorCodes::SUPPLIERS_CAN_NOT_ASSIGN_TO_PRODUCT_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::SUPPLIERS_CAN_NOT_ASSIGN_TO_PRODUCT)
                ),
                array(
                    'error_code'    => ErrorCodes::PRODUCTS_MISSING_LANGUAGE_ATTRIBUTE_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::PRODUCTS_MISSING_LANGUAGE_ATTRIBUTE)
                ),
                array(
                    'error_code'    => ErrorCodes::MULTI_SHOP_CORRUPT_PRICES_ERROR_CODE,
                    'error_message' => strip_tags(ErrorCodes::MULTI_SHOP_CORRUPT_PRICES)
                )
            )
        );

        $this->View()->assign(
            $list
        );
    }
}
