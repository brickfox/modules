// {namespace name=backend/BrickfoxUiErrorCodeList/controller}
// {block name=backend/BrickfoxUiErrorCodeList/controller/main}
Ext.define('Shopware.apps.BrickfoxUiErrorCodeList.controller.Main', {

    extend: 'Ext.app.Controller',

    mainWindow: null,

    init: function () {
        var me = this;

        me.mainWindow = me.subApplication.getView('Main').create().show();
        me.mainWindow.createPanel();

        me.callParent(arguments);
    }
});
// {/block}