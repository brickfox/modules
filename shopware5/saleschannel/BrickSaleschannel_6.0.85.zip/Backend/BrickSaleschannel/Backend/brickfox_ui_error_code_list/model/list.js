// {namespace name=backend/BrickfoxUIErrorCodeList/model}
// {block name=backend/BrickfoxUIErrorCodeList/model/LogImport}
Ext.define('Shopware.apps.BrickfoxUiErrorCodeList.model.List', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/Error/CodeList"}{/block}
        {
            name: 'error_code',
            type: 'string'
        },
        {
            name: 'error_message',
            type: 'string'
        }
    ]
});
// {/block}