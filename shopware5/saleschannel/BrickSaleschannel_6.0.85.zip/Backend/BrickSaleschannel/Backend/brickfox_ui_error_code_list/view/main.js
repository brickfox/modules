// {namespace name=backend/BrickfoxUiErrorCodeList/view}
// {block name=backend/BrickfoxUiErrorCodeList/view/Main}
Ext.define('Shopware.apps.BrickfoxUiErrorCodeList.view.Main', {

    extend: 'Enlight.app.Window',

    alias: 'widget.BrickfoxUiErrorCodeList-view-main',

    layout: 'fit',

    width: 900,

    height: '90%',

    autoShow: true,

    stateful: true,

    stateId: 'BrickfoxUiErrorCodeList-view-main',

    title: '{s name=main/Window/title/Log/Overview/Error/Codes}Fehler-Code übersicht{/s}',

    iconCls: 'bf_icon_error_code_list',

    initComponent: function () {
        var me = this;

        me.callParent(arguments);
    },

    createPanel: function () {
        var me = this;

        me.panel =
            Ext.create('Ext.panel.Panel', {
                layout: 'border',
                items:  [
                    Ext.create('Ext.grid.Panel', {
                        region:     'center',
                        store:      Ext.create('Shopware.apps.BrickfoxUiErrorCodeList.store.List').load(),
                        columns:    [
                            {
                                header:    'Fehler-Code',
                                dataIndex: 'error_code'
                            },
                            {
                                header:    'Fehlermeldung',
                                dataIndex: 'error_message',
                                flex:      1
                            }
                        ],
                        stripeRows: false
                    })
                ]
            });

        me.add(me.panel);
    }
});
// {/block}