<?php
/**
 * CalculateSpecialPrices.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Import;

use Bf\Saleschannel\Components\Resources\Prices\SpecialPrices;
use Exception;
use Bf\Saleschannel\Components\Util\ConfigManager;

class CalculateSpecialPrices
{
    /** @var int */
    private $specialPriceMode = 1;

    /**
     * @return array
     */
    public function getSpecialPriceList()
    {
        $specialPriceList = Shopware()->Db()->fetchAll(
            "
             select id, brickfoxID, special_price_start, special_price_end, price, special_price, active, currency_code, uvp
             from bf_special_prices
            "
        );

        return $specialPriceList;
    }

    /**
     * @param array $specialPriceCalculationList
     *
     * @throws Exception
     */
    public function calculate(array $specialPriceCalculationList = array())
    {
        if(count($specialPriceCalculationList) > 0)
        {
            foreach($specialPriceCalculationList as $specialPriceData)
            {
                $specialPriceStart = $specialPriceData['special_price_start'];
                $specialPriceEnd   = $specialPriceData['special_price_end'];
                $activateSpecialPrice = $this->calculateSpecialPriceDate($specialPriceStart, $specialPriceEnd);
                $lastUpdate = date('Y-m-d H:i:s', time());

                try
                {
                    $shopwareDetailsId = Shopware()->Db()->fetchOne("select shopwareID from bf_mapping_details where brickfoxID = ?", array($specialPriceData['brickfoxID']));

                    if($shopwareDetailsId !== null && $shopwareDetailsId > 0)
                    {
                        if($activateSpecialPrice === 1 && (int) $specialPriceData['active'] === 0)
                        {
                            $strikeThroughPriceForSpecialPrice = $specialPriceData['price'];

                            if($hasUvp = $specialPriceData["uvp"] > 0 &&
                                ConfigManager::getInstance()->getStrikeThroughPriceRules() == '2') {
                                $strikeThroughPriceForSpecialPrice = $specialPriceData["uvp"];
                            }

                            Shopware()->Db()->query(
                                "
                                 update s_articles_prices set price = ?, pseudoprice = ? where articledetailsID = ? and pricegroup = ? and `from` = 1
                                ",array($specialPriceData['special_price'], $strikeThroughPriceForSpecialPrice, $shopwareDetailsId, $specialPriceData['currency_code'])
                            );

                            Shopware()->Db()->query(
                                "
                                 update bf_special_prices set active = ?, last_update = ? where id = ?
                                ",array($activateSpecialPrice, $lastUpdate, $specialPriceData['id'])
                            );
                        }
                        elseif($activateSpecialPrice === 0 && (int) $specialPriceData['active'] === 1)
                        {
                            Shopware()->Db()->query(
                                "
                                 update bf_special_prices set active = ?, last_update = ? where id = ?
                                ",array($activateSpecialPrice, $lastUpdate, $specialPriceData['id'])
                            );

                            if($hasUvp = $specialPriceData["uvp"] > 0)
                            {
                                Shopware()->Db()->query(
                                    "
                                 update s_articles_prices set price = ?, pseudoprice = ? where articledetailsID = ? and pricegroup = ? and `from` = 1
                                ",array($specialPriceData["price"], $specialPriceData['uvp'], $shopwareDetailsId, $specialPriceData['currency_code'])
                                );
                            }
                            else
                            {
                                Shopware()->Db()->query(
                                    "
                                 update s_articles_prices set price = ?, pseudoprice = ? where articledetailsID = ? and pricegroup = ? and `from` = 1
                                ",array($specialPriceData['price'], 0, $shopwareDetailsId, $specialPriceData['currency_code'])
                                );
                            }
                        }
                    }
                }
                catch(Exception $e)
                {
                    throw new Exception($e->getMessage());
                }
            }
        }
    }

    /**
     * @param $specialPriceStart
     * @param $specialPriceEnd
     *
     * @return int
     */
    private function calculateSpecialPriceDate($specialPriceStart, $specialPriceEnd)
    {
        $activateSpecialPrice = 0;
        $this->prepareSpecialPriceMode($specialPriceStart, $specialPriceEnd);

        if($this->getSpecialPriceMode() === SpecialPrices::SPECIAL_PRICE_START_AND_END_GIVEN)
        {
            if(strtotime($specialPriceStart) < time() && strtotime($specialPriceEnd) > time())
            {
                $activateSpecialPrice = 1;
            }
        }
        elseif($this->getSpecialPriceMode() === SpecialPrices::SPECIAL_PRICE_START_GIVEN)
        {
            if(strtotime($specialPriceStart) < time())
            {
                $activateSpecialPrice = 1;
            }
        }
        elseif($this->getSpecialPriceMode() === SpecialPrices::SPECIAL_PRICE_END_GIVEN)
        {
            if(strtotime($specialPriceEnd) > time())
            {
                $activateSpecialPrice = 1;
            }
        }
        elseif($this->getSpecialPriceMode() === SpecialPrices::SPECIAL_PRICE_START_AND_END_NOT_GIVEN)
        {
            $activateSpecialPrice = 1;
        }

        return $activateSpecialPrice;
    }

    /**
     * @param $specialPriceStart
     * @param $specialPriceEnd
     *
     * @return void
     */
    public function prepareSpecialPriceMode($specialPriceStart, $specialPriceEnd)
    {
        if($specialPriceStart !== null && $specialPriceEnd !== null)
        {
            $this->setSpecialPriceMode(SpecialPrices::SPECIAL_PRICE_START_AND_END_GIVEN);
        }
        elseif($specialPriceStart !== null && $specialPriceEnd === null)
        {
            $this->setSpecialPriceMode(SpecialPrices::SPECIAL_PRICE_START_GIVEN);
        }
        elseif($specialPriceStart === null && $specialPriceEnd !== null)
        {
            $this->setSpecialPriceMode(SpecialPrices::SPECIAL_PRICE_END_GIVEN);
        }
        else
        {
            $this->setSpecialPriceMode(SpecialPrices::SPECIAL_PRICE_START_AND_END_NOT_GIVEN);
        }
    }

    /**
     * @return int
     */
    public function getSpecialPriceMode()
    {
        return $this->specialPriceMode;
    }

    /**
     * @param int $specialPriceMode
     */
    public function setSpecialPriceMode($specialPriceMode)
    {
        $this->specialPriceMode = $specialPriceMode;
    }
}