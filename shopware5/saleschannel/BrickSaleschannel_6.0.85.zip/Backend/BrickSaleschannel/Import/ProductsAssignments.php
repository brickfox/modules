<?php
namespace Bf\Saleschannel\Components\Import;

use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Resources\Article\Assignments as BfAssignments;
use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract;
use Bf\Saleschannel\Components\Util\LogManager;
use Shopware\CustomModels\BfSaleschannel\Log;
use SimpleXMLElement;

/**
 * ProductsAssignments
 *
 * @package Bf\Saleschannel\Components\Import
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class ProductsAssignments
{
    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param $logEntity
     *
     * @throws \Exception
     * @return mixed|void
     */
    public function process(SimpleXMLElement $simpleXMLElement, $logEntity)
    {
        /** @var \Shopware\CustomModels\BfSaleschannel\MappingArticles $mappingModel */
        $mappingModel = Helper::getMappingByValue((int) $simpleXMLElement->ProductId, 'brickfoxId', ArticleAbstract::MAPPING_NAMESPACE_MODEL);

        if($mappingModel !== null)
        {
            $article = $mappingModel->getArticle();

            (new BfAssignments($article, $simpleXMLElement))->prepareProductsAssignment();

            Helper::doModelOperation($article);
        }
        else
        {
            LogManager::getInstance()->writeLogForGui(
                Log::LOG_STATUS_ERROR,
                __METHOD__,
                str_replace(
                    '{$productId}',
                    (string) $simpleXMLElement->ProductId,
                    ErrorCodes::PRODUCTS_ASSIGNMENT_CAN_NOT_FIND_RELATE_PRODUCT
                ),
                Helper::getUserName(),
                Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                (string) $simpleXMLElement->ProductId,
                ErrorCodes::PRODUCTS_ASSIGNMENT_CAN_NOT_FIND_RELATE_PRODUCT_ERROR_CODE
            );
        }
    }
}
