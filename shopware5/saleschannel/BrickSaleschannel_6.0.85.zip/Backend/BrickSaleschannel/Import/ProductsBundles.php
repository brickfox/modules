<?php
namespace Bf\Saleschannel\Components\Import;

use Bf\Saleschannel\Components\Gui\Logging;
use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract;
use Bf\Saleschannel\Components\Resources\Bundle\Bundle;
use Bf\Saleschannel\Components\Resources\Detail\DetailAbstract;
use Shopware\CustomModels\Bundle\Price as SwBundlePrice;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Shopware\Models\Article\Article as SwArticle;
use Exception;
use Shopware\CustomModels\BfSaleschannel\Log;
use SimpleXMLElement;

/**
 * ProductsBundles
 *
 * @package Bf\Saleschannel\Components\Import
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class ProductsBundles
{
    const ENTITY_NAME = 'Bundles';
    const LOG_DEBUG   = 'Successful created or updated products bundle with ordernumber: {$ordernumber}';

    /** @var array */
    private $deleteListBundleArticle = array();

    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param $logEntity
     */
    public function process(\SimpleXMLElement $simpleXMLElement, $logEntity)
    {
        /** @var \Shopware\CustomModels\BfSaleschannel\MappingArticles $mappingModel */
        $mappingModel = Helper::getMappingByValue((int) $simpleXMLElement->ProductsId, 'brickfoxId', ArticleAbstract::MAPPING_NAMESPACE_MODEL);

        if($mappingModel !== null)
        {
            try
            {
                $articleModel = $mappingModel->getArticle();

                $this->setDeleteListBundleArticle($articleModel, null);

                if((bool) $simpleXMLElement->ProductsBundleItem === true)
                {
                    $resourceBundle = new Bundle($simpleXMLElement, $articleModel);
                    $bundleModel    = $resourceBundle->prepareArticleBundle();

                    foreach($simpleXMLElement->ProductsBundleItem as $productsBundleInformation)
                    {
                        /** @var \Shopware\CustomModels\BfSaleschannel\MappingDetails $mappingModelDetail */
                        $mappingModelDetail = Helper::getMappingByValue(
                            (int) $productsBundleInformation->ProductsVariationsId,
                            'brickfoxId',
                            DetailAbstract::MAPPING_NAMESPACE_MODEL_DETAIL
                        );

                        if($mappingModelDetail !== null)
                        {
                            $quantity = 0;

                            if((bool) $productsBundleInformation->Quantity === true)
                            {
                                $quantity = (int) $productsBundleInformation->Quantity;
                            }

                            $articleDetailModel = $mappingModelDetail->getDetail();
                            $resourceBundle->prepareArticleDetailBundle($articleDetailModel, $quantity);
                            $resourceBundle->prepareBundlePrices();
                            
                            if($bundleModel->getId() !== null && $bundleModel->getId() !== false && method_exists($bundleModel, 'getId') === true)
                            {
                                $this->removeBundleArticleFromDeleteList($articleModel, $mappingModelDetail->getShopwareId());
                            }
                            
                            Shopware()->Models()->flush();
                        }
                        else
                        {
                            LogManager::getInstance()->writeLogForGui(
                                Log::LOG_STATUS_ERROR,
                                __METHOD__,
                                str_replace(
                                    array('{$productId}', '{$variationsId}'),
                                    array($mappingModel->getBrickfoxId(), (string) $productsBundleInformation->ProductsVariationsId),
                                    ErrorCodes::BUNDLE_PRODUCTS_ASSIGNMENT_NOT_FOUND
                                ),
                                Helper::getUserName(),
                                Log::TYPE_OF_LOG_IMPORT_BUNDLE,
                                (string) $mappingModel->getBrickfoxId(),
                                ErrorCodes::BUNDLE_PRODUCTS_ASSIGNMENT_NOT_FOUND_ERROR_CODE
                            );
                        }
                    }

                    foreach($resourceBundle->getBundlePrices() as $customerGroupKey => $element)
                    {
                        $isNew             = false;
                        $repository        = Shopware()->Models()->getRepository(Bundle::BUNDLE_MODEL_PATH_PRICE);
                        $bundlePricesModel = $repository->findOneBy(array('bundleId' => $resourceBundle->getBundleModel()->getId(), 'customerGroupId' => $element['customerGroupId']));

                        if($bundlePricesModel === null)
                        {
                            $isNew             = true;
                            $bundlePricesModel = new SwBundlePrice();
                        }

                        if($isNew === true)
                        {
                            $bundlePricesModel->setBundle($resourceBundle->getBundleModel());

                            $repositoryGroup    = Shopware()->Models()->getRepository('Shopware\Models\Customer\Group');
                            $customerGroupModel = $repositoryGroup->findOneBy(array('key' => $customerGroupKey));

                            $bundlePricesModel->setCustomerGroup($customerGroupModel);
                        }

                        $bundlePricesModel->setPrice($element['totalPrice']);

                        Shopware()->Models()->persist($bundlePricesModel);
                    }

                    if($bundleModel->getId() !== null && $bundleModel->getId() !== false && method_exists($bundleModel, 'getId') === true)
                    {
                        $this->cleanUpBundles($bundleModel->getId());
                    }
                }
            }
            catch(Exception $e)
            {
                echo $e->getTraceAsString();
            }

            LogManager::getInstance()->logDebug(
                str_replace('{$ordernumber}', $articleModel->getMainDetail()->getNumber(), self::LOG_DEBUG),
                $logEntity
            );
        }
        else
        {
            LogManager::getInstance()->writeLogForGui(
                Log::LOG_STATUS_ERROR,
                __METHOD__,
                str_replace(
                    '{$productId}',
                    (string) $simpleXMLElement->ProductsId,
                    ErrorCodes::BUNDLE_PRODUCT_NOT_FOUND
                ),
                Helper::getUserName(),
                Log::TYPE_OF_LOG_IMPORT_BUNDLE,
                (string) $simpleXMLElement->ProductsId,
                ErrorCodes::BUNDLE_PRODUCT_NOT_FOUND_ERROR_CODE
            );
        }
    }

    /**
     * @param $bundleId
     *
     * @return void
     */
    public function cleanUpBundles($bundleId)
    {
        if(count($this->getDeleteListBundleArticle()) > 0)
        {
            foreach($this->getDeleteListBundleArticle() as $articleDetailId)
            {
                Shopware()->Db()->query("delete from s_articles_bundles_articles where bundle_id = ? and article_detail_id = ?", array($bundleId, $articleDetailId));
            }
        }
    }

    /**
     * @param SwArticle $articleModel
     * @param $articleDetailId
     *
     * @return void
     */
    private function removeBundleArticleFromDeleteList(SwArticle $articleModel, $articleDetailId)
    {
        if($articleDetailId > 0)
        {
            try
            {
                $deleteListBundleArticles = $this->getDeleteListBundleArticle();
                $deleteListBundleArticles = array_flip($deleteListBundleArticles);
                unset($deleteListBundleArticles[$articleDetailId]);
                $deleteListBundleArticles = array_flip($deleteListBundleArticles);

                $this->setDeleteListBundleArticle($articleModel, $deleteListBundleArticles);
            }
            catch(Exception $e)
            {
                LogManager::getInstance()->logException($e, self::ENTITY_NAME);
                Helper::fromArray(
                    new Log(),
                    array(
                        Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                        Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                        Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                        Logging::SETTER_ALIAS_LOG_MESSAGE => Helper::convertExceptionMessageIntoGuiFormat($e),
                        Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                    )
                );
            }
        }
    }

    /**
     * @param SwArticle $articleModel
     * @param array|null $deleteListBundleArticle
     *
     * @return ProductsBundles
     */
    public function setDeleteListBundleArticle(SwArticle $articleModel, $deleteListBundleArticle)
    {
        if($deleteListBundleArticle === null)
        {
            try
            {
                $bundleId = Shopware()->Db()->fetchOne("select id from s_articles_bundles where articleID = ?", array($articleModel->getId()));

                if($bundleId > 0 && $bundleId !== null && $bundleId !== false)
                {
                    $deleteListBundleArticleTemp = Shopware()->Db()->fetchAll("select article_detail_id from s_articles_bundles_articles where bundle_id = ?", array($bundleId));

                    if(count($deleteListBundleArticleTemp) > 0)
                    {
                        foreach($deleteListBundleArticleTemp as $deleteListBundleArticle)
                        {
                            $this->deleteListBundleArticle[] = $deleteListBundleArticle['article_detail_id'];
                        }
                    }
                }
            }
            catch(Exception $e)
            {
                LogManager::getInstance()->logException($e, self::ENTITY_NAME);
                Helper::fromArray(
                    new Log(),
                    array(
                        Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_ERROR,
                        Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                        Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                        Logging::SETTER_ALIAS_LOG_MESSAGE => Helper::convertExceptionMessageIntoGuiFormat($e),
                        Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                    )
                );
            }
        }
        else
        {
            $this->deleteListBundleArticle = $deleteListBundleArticle;
        }

        return $this;
    }

    /**
     * @return array
     */
    public function getDeleteListBundleArticle()
    {
        return $this->deleteListBundleArticle;
    }
}
