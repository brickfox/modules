<?php

namespace Bf\Saleschannel\Components\Import;

use Bf\Saleschannel\Components\Gui\Logging;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Exception;
use Shopware\CustomModels\BfSaleschannel\Log;
use Shopware\CustomModels\BfSaleschannel\MappingCategories;
use Shopware\Models\Category\Category;
use SimpleXMLElement;

/**
 * Categories
 *
 * @package Bf\Saleschannel\Components\Import
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Categories
{
    const MAPPING_NAMESPACE_MODEL = 'Shopware\CustomModels\BfSaleschannel\MappingCategories';
    const LOG_DEBUG               = '{$mode} Category {$categoryName}(BfId: {$bfId}) successful';
    const ENTITY_NAME             = 'Categories';

    /** @var array */
    private $deleteList = [];

    private $simpleXmlElement = null;

    /**
     * @param SimpleXMLElement $simpleXmlElement
     * @param $logEntity
     *
     * @return mixed|void
     */
    public function process(SimpleXMLElement $simpleXmlElement, $logEntity)
    {
        try {
            $this->setSimpleXmlElement($simpleXmlElement);
            $bfShopsId = (string)$simpleXmlElement['shopsId'];

            foreach ($simpleXmlElement->Translations->Translation as $translation) {
                $languagesCode = strtolower($translation['lang']);

                $mappingCategoriesRepository   = Helper::getRepository(self::MAPPING_NAMESPACE_MODEL);
                $mappingModel = $mappingCategoriesRepository->findOneBy([
                    'brickfoxId' => (int)$simpleXmlElement->CategoryId,
                    'shopsId' => $bfShopsId,
                    'languagesCode' => $languagesCode
                ]);

                if ($mappingModel === null) {
                    /**
                     * @param $category Category
                     * @param $mappingModel MappingCategories
                     */
                    [$category, $mappingModel] = $this->createNewCategoryAndMappingModel($simpleXmlElement, $languagesCode, $bfShopsId);
                    $mode = LogManager::MODE_NEW;
                } else {
                    /**
                     * @param $category Category
                     * @param $mappingModel MappingCategories
                     */
                    [$category, $mappingModel] = $this->getCategoryAndMappingModelToUpdate($mappingModel, $bfShopsId);
                    $mode = LogManager::MODE_UPDATE;
                }

                $category
                    ->setName((string)$translation->Name)
                    ->setPosition((int)$simpleXmlElement->SortOrder)
                    ->setActive(true);

                $categoriesParent = $this->setCategoriesParent($simpleXmlElement, $category, $bfShopsId, $languagesCode);

                if ($categoriesParent === false) {
                    Shopware()->Models()->detach($category);
                    continue;
                }

                // bugfx for error (non-persisted entities in association graph)
                $entitiesToPersist = [$category, $mappingModel];
                $categoryAttribute = $category->getAttribute();
                if($categoryAttribute !== null) {
                    $categoryAttribute->setCategory($category);
                    $category->setAttribute($categoryAttribute);
                    $entitiesToPersist[] = $categoryAttribute;
                }

                $this->persistEntities($entitiesToPersist);

                LogManager::getInstance()->logDebug(str_replace(['{$mode}', '{$categoryName}', '{$bfId}'], [$mode, $category->getName(), $mappingModel->getBrickfoxId()],
                    self::LOG_DEBUG), $logEntity);
            }

            $this->deleteCategoryFromDeleteList((int)$simpleXmlElement->CategoryId);
        } catch (Exception $e) {
            // BFSERVICE-22116 - if an exception is thrown, we must make an update into the delete List
            $this->deleteCategoryFromDeleteList((int)$simpleXmlElement->CategoryId);
            echo '<pre>';
            print_r($e->getMessage());
            echo '</pre>';

            LogManager::getInstance()->logException($e, $logEntity);
            Helper::fromArray(new Log(), [
                Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                Logging::SETTER_ALIAS_LOG_MESSAGE => Helper::convertExceptionMessageIntoGuiFormat($e),
                Logging::SETTER_ALIAS_USER        => Helper::getUserName()
            ]);
        }
    }

    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param Category $category
     * @param $shopsId
     * @param $languageCode
     * @return bool
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    private function setCategoriesParent(SimpleXMLElement $simpleXMLElement, Category $category, $shopsId, $languageCode): bool
    {
        $shopsMappingModelRepository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingShops');

        /** @var array $shopsMappingModel */
        $shopsMappingModel = $shopsMappingModelRepository->findBy([
            'brickfoxId' => $shopsId
        ]);

        if($shopsMappingModel === null || count($shopsMappingModel) <= 0) {

            return false;

        } elseif(count($shopsMappingModel) === 1) {

            /** @var \Shopware\CustomModels\BfSaleschannel\MappingShops $shopsMappingModel */
            $shopsMappingModel = $shopsMappingModelRepository->findOneBy([
                'brickfoxId' => $shopsId
            ]);

            if ($shopsMappingModel === null) {
                return false;
            }

            $swShopsModelRepository = Helper::getRepository('Shopware\Models\Shop\Shop');
            /** @var \Shopware\Models\Shop\Shop $swShopsModel */
            $swShopsModel = $swShopsModelRepository->findOneBy([
                'id' => $shopsMappingModel->getShopwareId()
            ]);

            if ($swShopsModel === null) {
                return false;
            }

            if ((bool)$simpleXMLElement->ParentId === false) {
                // no parent id set - use the root category of the shop
                $category->setParent(
                    $swShopsModel->getCategory()
                );
                return true;
            }

            $mappingCategoriesRepository   = Helper::getRepository(self::MAPPING_NAMESPACE_MODEL);
            $mappingModel = $mappingCategoriesRepository->findOneBy([
                'brickfoxId' => (int)$simpleXMLElement->ParentId,
                'shopsId' => $shopsId
            ]);

            if ($mappingModel === null) {
                return false;
            }

            // set the category from the mapping model as parent
            $category->setParent(
                $mappingModel->getCategory()
            );

            return true;

        } else {
            $categoriesParentFound = true;

            // count($shopsMappingModel) > 1
            $mappingTranslationRepository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingTranslation');

            /** @var \Shopware\CustomModels\BfSaleschannel\MappingShops $shopMapping */
            foreach ($shopsMappingModel as $shopMapping) {
                $mainLanguage            = null;
                $mappingTranslationModel = $mappingTranslationRepository->findOneBy([
                    'brickfoxIsoCode' => $languageCode,
                    'mappingFieldKey' => $shopMapping->getShop()->getLocale()->getLocale()
                ]);

                if ($mappingTranslationModel === null) {
                    if (in_array($languageCode, Helper::getMainLanguagesCode()) === true) {
                        $key = array_search($languageCode, Helper::getMainLanguagesCode());

                        if ($key !== false) {
                            $mainLanguage = Helper::getMainLanguagesCode()[$key];
                        }
                    }
                }

                if ($mappingTranslationModel !== null || $mainLanguage !== null) {

                    if ((bool)$simpleXMLElement->ParentId === false) {
                        // no parent id set - use the root category of the shop
                        $category->setParent(
                            $shopMapping->getShop()->getCategory()
                        );
                        $categoriesParentFound = true;
                        break;
                    } else {
                        $mappingCategoriesRepository   = Helper::getRepository(self::MAPPING_NAMESPACE_MODEL);
                        $mappingModel = $mappingCategoriesRepository->findOneBy([
                            'brickfoxId' => (int)$simpleXMLElement->ParentId,
                            'languagesCode' => $languageCode,
                            'shopsId' => $shopsId
                        ]);

                        if($mappingModel !== null) {
                            $category->setParent(
                                $mappingModel->getCategory()
                            );
                            $categoriesParentFound = true;
                            break;
                        }
                    }
                } else {
                    $categoriesParentFound = false;
                }
            }

            return $categoriesParentFound;
        }
    }

    /**
     * @param int $brickfoxId
     */
    public function deleteCategoryFromDeleteList(int $brickfoxId)
    {
        try {
            $deleteList = $this->getDeleteList();

            unset($deleteList[$brickfoxId]);

            $this->setDeleteList($deleteList);
        } catch (Exception $e) {
            LogManager::getInstance()->logException($e, self::ENTITY_NAME);
            Helper::fromArray(new Log(), [
                Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                Logging::SETTER_ALIAS_LOG_MESSAGE => Helper::convertExceptionMessageIntoGuiFormat($e),
                Logging::SETTER_ALIAS_USER        => Helper::getUserName()
            ]);
        }
    }

    /**
     * @return array
     */
    public function getDeleteList(): array
    {
        return $this->deleteList;
    }

    /**
     * @param array|null $deleteList
     * @param string|null $languageIsoCode
     * @param string|null $shopsId
     *
     * @return Categories
     */
    public function setDeleteList(?array $deleteList, ?string $languageIsoCode = null, ?string $shopsId = null): Categories
    {
        if($deleteList === null && $languageIsoCode === null && $shopsId === null) {
            return $this;
        }

        if ($deleteList !== null) {
            $this->deleteList = $deleteList;
        }

        if ($deleteList === null) {
            try {
                $repository = Helper::getRepository(self::MAPPING_NAMESPACE_MODEL);
                $model      = $repository->findBy(['shopsId' => $shopsId]);

                if ($model === null) {
                    $model = $repository->findBy(['languagesCode' => $languageIsoCode]);
                }

                if ($model !== null) {
                    /** @var \Shopware\CustomModels\BfSaleschannel\MappingCategories $item */
                    foreach ($model as $item) {
                        $this->deleteList[$item->getBrickfoxId()] = 1;
                    }
                }
            } catch (Exception $e) {
                LogManager::getInstance()->logException($e, self::ENTITY_NAME);
                Helper::fromArray(new Log(), [
                    Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_ERROR,
                    Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                    Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                    Logging::SETTER_ALIAS_LOG_MESSAGE => Helper::convertExceptionMessageIntoGuiFormat($e),
                    Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                ]);
            }
        }

        return $this;
    }

    /**
     * @return void
     */
    public function cleanUpCategories()
    {
        $categoryRepositoryMappingModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingCategories');

        foreach (array_keys($this->getDeleteList()) as $brickfoxId) {
            $models = $categoryRepositoryMappingModel->findBy([
                'brickfoxId' => $brickfoxId
            ]);

            if (count($models) > 0) {

                /** @var \Shopware\CustomModels\BfSaleschannel\MappingCategories $mappingModel */
                foreach ($models as $mappingModel) {
                    /** @var \Shopware\Models\Category\Category $category */
                    $category = $mappingModel->getCategory();

                    try {
                        $categoryArticles = $category->getAllArticles();

                        if($category->getParentId() !== null){
                            /** @var \Shopware\Models\Article\Article $articleModel */
                            foreach ($categoryArticles as $articleModel){
                                Helper::doModelOperation($articleModel->addCategory($category->getParent()));
                            }
                        }
                        Shopware()->Models()->remove($mappingModel);
                        Shopware()->Models()->remove($category);

                        LogManager::getInstance()->logDebug(str_replace(['{$mode}', '{$categoryName}', '{$bfId}'],
                            [LogManager::MODE_DISABLE, $category->getName(), $brickfoxId], self::LOG_DEBUG), self::ENTITY_NAME);
                    } catch (Exception $e) {
                        LogManager::getInstance()->logException($e, self::ENTITY_NAME);
                        Helper::fromArray(new Log(), [
                            Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                            Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                            Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                            Logging::SETTER_ALIAS_LOG_MESSAGE => Helper::convertExceptionMessageIntoGuiFormat($e),
                            Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                        ]);
                    }
                }
            } else {
                LogManager::getInstance()
                    ->writeLogForGui(Log::LOG_STATUS_WARNING, __METHOD__, str_replace('{brickfoxId}', $brickfoxId, ErrorCodes::CATEGORIES_DELETE), Helper::getUserName(),
                        Log::TYPE_OF_LOG_IMPORT_CATEGORIES, (string)self::getSimpleXmlElement()->CategoryId, ErrorCodes::CATEGORIES_DELETE_ERROR_CODE);
            }
        }
    }

    /**
     * @return SimpleXMLElement|null
     */
    public function getSimpleXmlElement(): ?SimpleXMLElement
    {
        return $this->simpleXmlElement;
    }

    /**
     * @param \SimpleXMLElement|null $simpleXmlElement
     *
     * @return Categories
     */
    public function setSimpleXmlElement(SimpleXMLElement $simpleXmlElement): Categories
    {
        $this->simpleXmlElement = $simpleXmlElement;

        return $this;
    }/**
 * @param \SimpleXMLElement $simpleXmlElement
 * @param string $languagesCode
 * @param string $bfShopsId
 * @return array
 */
    private function createNewCategoryAndMappingModel(SimpleXMLElement $simpleXmlElement, string $languagesCode, string $bfShopsId): array
    {
        $category = new Category();

        $mappingModel = (new MappingCategories())
            ->setBrickfoxId((int)$simpleXmlElement->CategoryId)
            ->setCategory($category)
            ->setLanguagesCode($languagesCode)
            ->setShopsId($bfShopsId);

        return [$category, $mappingModel];
    }

    /**
     * @param \Shopware\CustomModels\BfSaleschannel\MappingCategories|object $mappingModel
     * @param string $bfShopsId
     * @return array
     */
    private function getCategoryAndMappingModelToUpdate(object $mappingModel, string $bfShopsId): array
    {
        $mappingModel->setShopsId($bfShopsId);

        /** @var \Shopware\Models\Category\Category $category */
        $category = $mappingModel->getCategory();

        //don't overwrite the seo descriptions
        $category->setMetaKeywords($category->getMetaKeywords());
        $category->setMetaDescription($category->getMetaDescription());
        $category->setCmsHeadline($category->getCmsHeadline());
        $category->setCmsText($category->getCmsText());
        $category->setMetaTitle($category->getMetaTitle());

        return [$category, $mappingModel];
    }

    /**
     * @param array $entities
     * @return void
     */
    private function persistEntities(array $entities): void
    {
        Helper::doModelOperation(null, $entities);
        Helper::doModelOperation(null, $entities, Helper::OPERATION_FLUSH);
    }
}
