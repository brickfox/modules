<?php
namespace Bf\Saleschannel\Components\Import;

use Bf\Saleschannel\Components\ImportAbstract;
use Bf\Saleschannel\Components\Resources\Orders\OrderStatus;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Shopware\CustomModels\BfSaleschannel\Log;
use SimpleXMLElement;

/**
 * OrdersStatus
 *
 * @package Bf\Saleschannel\Components\Import
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class OrdersStatus
{
    const ENTITY_NAME = 'OrderStatus';
    const LOG_DEBUG   = 'Updated order status with orderNumber: {$orderNumber} (orderId: {$orderId}) successful';

    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param $logEntity
     *
     * @throws \Exception
     * @return mixed|void
     */
    public function process(SimpleXMLElement $simpleXMLElement, $logEntity)
    {
        /** @var \Shopware\Models\Order\Order $ordersModel */
        $ordersModel = Helper::getMappingByValue((string) $simpleXMLElement->OrderId, 'number', 'Shopware\Models\Order\Order');

        if($ordersModel === null)
        {
            LogManager::getInstance()->writeLogForGui(
                Log::LOG_STATUS_ERROR,
                __METHOD__,
                str_replace(
                    '{$orderId}',
                    (string) $simpleXMLElement->OrderId,
                    ErrorCodes::ORDER_STATUS_CAN_NOT_FIND_ORDER
                ),
                Helper::getUserName(),
                Log::TYPE_OF_LOG_IMPORT_ORDERS_STATUS,
                (string) $simpleXMLElement->OrderId,
                ErrorCodes::ORDERS_STATUS_CAN_NOT_FIND_ORDER_ERROR_CODE
            );
        }

        (new OrderStatus($simpleXMLElement, $ordersModel))->prepareOrderStatusItem();

        LogManager::getInstance()->logDebug(
            str_replace(array('{$orderNumber}', '{$orderId}'), array($ordersModel->getNumber(), $ordersModel->getId()), self::LOG_DEBUG),
            $logEntity
        );
    }
}
