<?php
namespace Bf\Saleschannel\Components\Import;

use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract;
use Bf\Saleschannel\Components\Resources\Article\ArticleUpdate;
use Bf\Saleschannel\Components\Util\LogManager;
use Shopware\CustomModels\BfSaleschannel\Log;
use SimpleXMLElement;

/**
 * ProductsUpdate
 *
 * @package Bf\Saleschannel\Components\Import
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class ProductsUpdate
{
    const LOG_DEBUG = '{$mode} Article {$ordernumber}(BfId: {$bfId}) successful';

    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param $logEntity
     *
     * @return mixed|void
     */
    public function process(SimpleXMLElement $simpleXMLElement, $logEntity)
    {
        /** @var \Shopware\CustomModels\BfSaleschannel\MappingArticles $mappingModel */
        $mappingModel = Helper::getMappingByValue((int) $simpleXMLElement->ProductId, 'brickfoxId', ArticleAbstract::MAPPING_NAMESPACE_MODEL);

        if($mappingModel !== null)
        {
            (new ArticleUpdate($simpleXMLElement, $mappingModel->getArticle()))->prepareArticleUpdate();

            if ($mappingModel->getArticle()->getMainDetail() !== null) {
                LogManager::getInstance()->logDebug(
                    str_replace(
                        array('{$mode}', '{$ordernumber}', '{$bfId}'),
                        array(LogManager::MODE_UPDATE, $mappingModel->getArticle()->getMainDetail()->getNumber(), (int) $simpleXMLElement->ProductId),
                        self::LOG_DEBUG
                    ),
                    $logEntity
                );
            } else {
                LogManager::getInstance()->logDebug(
                    str_replace(
                        array('{$mode}', '{$ordernumber}', '{$bfId}'),
                        array(LogManager::MODE_UPDATE, $mappingModel->getArticle()->getName(), (int) $simpleXMLElement->ProductId),
                        self::LOG_DEBUG
                    ),
                    $logEntity
                );
            }
        }
        else
        {
            LogManager::getInstance()->writeLogForGui(
                Log::LOG_STATUS_ERROR,
                __METHOD__,
                str_replace(
                    '{$brickfoxId}',
                    (string) $simpleXMLElement->ProductId,
                    ErrorCodes::PRODUCTS_UPDATE_CAN_NOT_FIND_PRODUCT
                ),
                Helper::getUserName(),
                Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                (string) $simpleXMLElement->ProductId,
                ErrorCodes::PRODUCTS_UPDATE_CAN_NOT_FIND_PRODUCT
            );
        }
    }
}
