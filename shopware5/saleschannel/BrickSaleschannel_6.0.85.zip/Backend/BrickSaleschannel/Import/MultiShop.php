<?php
namespace Bf\Saleschannel\Components\Import;

use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Shopware\CustomModels\BfSaleschannel\Log;

/**
 * MultiShop
 *
 * @package Bf\Saleschannel\Components\Import
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class MultiShop
{
    const LOG_ENTITY = 'MultiShop';
    const LOG_DEBUG  = '{$mode} Article {$ordernumber} (BfId: {$bfId}) successful';

    /** @var array */
    private $processedArticleIds = [];

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     *
     * @return bool|mixed
     */
    public function process(\SimpleXMLElement $simpleXMLElement)
    {
        /** @var \Shopware\CustomModels\BfSaleschannel\MappingArticles $articleMappingModel */
        $articleMappingModel = Helper::getMappingByValue((int) $simpleXMLElement->ProductId, 'brickfoxId', ArticleAbstract::MAPPING_NAMESPACE_MODEL);

        if($articleMappingModel !== null)
        {
            $this->processedArticleIds[] = $articleMappingModel->getShopwareId();

            if((int) $simpleXMLElement->Active === 0)
            {
                (
                new \Bf\Saleschannel\Components\Resources\MultiShop\MultiShop(
                    $simpleXMLElement, $articleMappingModel->getArticle(), (string) $simpleXMLElement->ShopsId
                )
                )->removeArticleFromMultiShop();

                LogManager::getInstance()->logDebug(
                    str_replace(
                        array('{$mode}', '{$ordernumber}', '{$bfId}'),
                        array('Removing', (string) $simpleXMLElement->ItemNumber, (string) $simpleXMLElement->ProductId),
                        self::LOG_DEBUG
                    ),
                    self::LOG_ENTITY
                );

            }
            else
            {
                (
                new \Bf\Saleschannel\Components\Resources\MultiShop\MultiShop(
                    $simpleXMLElement, $articleMappingModel->getArticle(), (string) $simpleXMLElement->ShopsId
                )
                )->prepareMultiShop();

                LogManager::getInstance()->logDebug(
                    str_replace(
                        array('{$mode}', '{$ordernumber}', '{$bfId}'),
                        array('Translate', (string) $simpleXMLElement->ItemNumber, (string) $simpleXMLElement->ProductId),
                        self::LOG_DEBUG
                    ),
                    self::LOG_ENTITY
                );
            }
        }
        else
        {
            LogManager::getInstance()->writeLogForGui(
                Log::LOG_STATUS_ERROR,
                __METHOD__,
                str_replace(
                    array('{$brickfoxId}', '{$orderNumber}', '{$shopsType}'),
                    array((string) $simpleXMLElement->ProductId, (string) $simpleXMLElement->ItemNumber, 'Multishop'),
                    ErrorCodes::PRODUCTS_CAN_NOT_LOAD
                ),
                Helper::getUserName(),
                Log::TYPE_OF_LOG_IMPORT_SUB_SHOP,
                (string) $simpleXMLElement->ProductId,
                ErrorCodes::PRODUCTS_CAN_NOT_LOAD_ERROR_CODE
            );
        }

        return true;
    }

    /**
     * @return array
     */
    public function getProcessedArticleIds(): array
    {
        return $this->processedArticleIds;
    }
}
