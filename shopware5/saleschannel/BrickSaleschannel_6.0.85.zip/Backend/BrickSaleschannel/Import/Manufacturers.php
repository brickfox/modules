<?php
namespace Bf\Saleschannel\Components\Import;

use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Shopware\CustomModels\BfSaleschannel\MappingSuppliers;
use Shopware\Models\Article\Supplier;

/**
 * Manufacturers
 *
 * @package Bf\Saleschannel\Components\Import
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Manufacturers
{
    const MAPPING_NAMESPACE_MODEL = 'Shopware\CustomModels\BfSaleschannel\MappingSuppliers';
    const LOG_DEBUG               = '{$mode} Supplier {$supplierName} (BfId: {$bfId}) successsful';

    /**
     * @param \SimpleXmlElement $simpleXmlElement
     * @param $logEntity
     *
     * @return mixed|void
     */
    public function process(\SimpleXMLElement $simpleXmlElement, $logEntity)
    {
        $mappingModel = Helper::getMappingByValue((int) $simpleXmlElement->ManufacturerId, 'brickfoxId', self::MAPPING_NAMESPACE_MODEL);

        if($mappingModel === null)
        {
            $supplier = new Supplier();

            $mappingModel = new MappingSuppliers();
            $mappingModel->setBrickfoxId((int) $simpleXmlElement->ManufacturerId);
            $mappingModel->setSupplier($supplier);
            $mode = LogManager::MODE_NEW;
        }
        else
        {
            $supplier = $mappingModel->getSupplier();
            $mode     = LogManager::MODE_UPDATE;
        }

        foreach($simpleXmlElement->Translations->Translation as $translation)
        {
            if (in_array((string) $translation['lang'], Helper::getMainLanguagesCode()) === true) {
                $supplier->setName((string) $translation->Name);
            }
        }

        Helper::doModelOperation(null, array($supplier, $mappingModel));

        LogManager::getInstance()->logDebug(
            str_replace(array('{$mode}', '{$supplierName}', '{$bfId}'), array($mode, $supplier->getName(), (int) $simpleXmlElement->ManufacturerId), self::LOG_DEBUG),
            $logEntity
        );
    }
}
