<?php
namespace Bf\Saleschannel\Components\Import;

use Bf\Saleschannel\Components\Resources\Article\Article as BfArticle;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Shopware\CustomModels\BfSaleschannel\MappingArticles;
use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract;
use Shopware\Models\Article\Article as SwArticle;

/**
 * Products
 *
 * @package Bf\Saleschannel\Components\Import
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Products
{
    const ENTITY_NAME = 'Products';
    const LOG_DEBUG   = '{$mode} Article {$ordernumber}(BfId: {$bfId}) successful';

    /**
     * Validates the incoming product node to not have duplicate variations item numbers (ordernumbers)
     *
     * @param \SimpleXMLElement $productSimpleXMLElement
     * @throws \Exception
     */
    private function preProcess(\SimpleXMLElement $productSimpleXMLElement) {

        $variationItemNumbers = [];

        if(isset($productSimpleXMLElement->{"Variations"}) === true && $productSimpleXMLElement->count() > 1) {
            foreach ($productSimpleXMLElement->{"Variations"}->{"Variation"} as $variation) {
                if(isset($variation->{"VariationItemNumber"}) === true) {
                    $itemNumber = (string) $variation->{"VariationItemNumber"};
                    if(in_array($itemNumber, $variationItemNumbers) === true) {
                        throw new \Exception('Duplicate itemNumber on variation found. Product will be skipped. VariationItemNumber: '.$itemNumber);
                    }
                    $variationItemNumbers[] = $itemNumber;
                }
            }
        }
    }

    /**
     * @param \SimpleXmlElement $simpleXmlElement
     * @param $logEntity
     *
     * @return mixed|void
     * @throws \Exception
     */
    public function process(\SimpleXMLElement $simpleXmlElement, $logEntity)
    {
        $this->preProcess($simpleXmlElement);

        $mappingModel = Helper::getMappingByValue((int) $simpleXmlElement->ProductId, 'brickfoxId', ArticleAbstract::MAPPING_NAMESPACE_MODEL);

        if($mappingModel === null)
        {
            $article = new SwArticle();

            $mappingModel = new MappingArticles();
            $mappingModel->setBrickfoxId((int) $simpleXmlElement->ProductId);
            $mappingModel->setArticle($article);
            $mode = LogManager::MODE_NEW;
        }
        else
        {
            $article = $mappingModel->getArticle();
            $mode    = LogManager::MODE_UPDATE;

        }

        $resourceArticle = new BfArticle($simpleXmlElement, $article, $mode);
        $resourceArticle->prepareArticleItem();

        Helper::doModelOperation(null, array($article, $mappingModel));

        if(is_object($article->getMainDetail()) === true)
        {
            $replace = array($mode, $article->getMainDetail()->getNumber(), $mappingModel->getBrickfoxId());
        }
        else
        {
            $replace = array($mode, $article->getId(), $mappingModel->getBrickfoxId());
        }

        LogManager::getInstance()->logDebug(
            str_replace(array('{$mode}', '{$ordernumber}', '{$bfId}'), $replace, self::LOG_DEBUG),
            $logEntity
        );
    }
}
