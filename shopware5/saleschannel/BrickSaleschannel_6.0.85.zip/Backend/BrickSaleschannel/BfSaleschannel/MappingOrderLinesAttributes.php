<?php
/**
 * MappingOrderLinesAttributes.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfSaleschannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_order_lines_attr", uniqueConstraints={@UniqueConstraint(name="shopware_column_name", columns={"shopware_column_name"})})
 */
class MappingOrderLinesAttributes extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $brickfoxExportName
     * @ORM\Column(name="brickfox_export_name", type="string", nullable=false)
     */
    private $brickfoxExportName;

    /**
     * @var string $shopwareColumnName
     * @ORM\Column(name="shopware_column_name", type="string", nullable=false)
     */
    private $shopwareColumnName;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return MappingOrderLinesAttributes
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return string
     */
    public function getBrickfoxExportName()
    {
        return $this->brickfoxExportName;
    }

    /**
     * @param string $brickfoxExportName
     *
     * @return MappingOrderLinesAttributes
     */
    public function setBrickfoxExportName($brickfoxExportName)
    {
        $this->brickfoxExportName = $brickfoxExportName;

        return $this;
    }

    /**
     * @return string
     */
    public function getShopwareColumnName()
    {
        return $this->shopwareColumnName;
    }

    /**
     * @param string $shopwareColumnName
     *
     * @return MappingOrderLinesAttributes
     */
    public function setShopwareColumnName($shopwareColumnName)
    {
        $this->shopwareColumnName = $shopwareColumnName;

        return $this;
    }
}