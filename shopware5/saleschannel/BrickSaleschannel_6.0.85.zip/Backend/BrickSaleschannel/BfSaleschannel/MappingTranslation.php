<?php
/**
 * MappingTranslation
 *
 * @package Shopware\CustomModels\BfSaleschannel
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfSaleschannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_translation", uniqueConstraints={@UniqueConstraint(name="brickfox_iso_code", columns={"brickfox_iso_code"})})
 */
class MappingTranslation extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $brickfoxIsoCode
     * @ORM\Column(name="brickfox_iso_code", type="string", nullable=false)
     */
    private $brickfoxIsoCode;

    /**
     * @var string $mappingFieldKey
     * @ORM\Column(name="mapping_field_key", type="string", nullable=false)
     */
    private $mappingFieldKey;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return MappingTranslation
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return string
     */
    public function getBrickfoxIsoCode()
    {
        return $this->brickfoxIsoCode;
    }

    /**
     * @param string $brickfoxIsoCode
     *
     * @return MappingTranslation
     */
    public function setBrickfoxIsoCode($brickfoxIsoCode)
    {
        $this->brickfoxIsoCode = $brickfoxIsoCode;

        return $this;
    }

    /**
     * @return string
     */
    public function getMappingFieldKey()
    {
        return $this->mappingFieldKey;
    }

    /**
     * @param string $mappingFieldKey
     *
     * @return MappingTranslation
     */
    public function setMappingFieldKey($mappingFieldKey)
    {
        $this->mappingFieldKey = $mappingFieldKey;

        return $this;
    }
}
