<?php

/**
 * Scriptlogger
 *
 * @package Shopware\CustomModels\BfSaleschannel
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2015 brickfox GmbH http://www.brickfox.de
 */
namespace Shopware\CustomModels\BfSaleschannel;

use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_scriptlogger")
 */
class Scriptlogger extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @ORM\Column(name="script_name", type="string", nullable=false)
     */
    private $scriptName;

    /**
     * @ORM\Column(name="script_status", type="string", nullable=false)
     */
    private $scriptStatus;

    /**
     * @ORM\Column(name="script_message", type="text", nullable=true)
     */
    private $scriptMessage;

    /**
     * @ORM\Column(name="date_start", type="datetime", nullable=false)
     */
    private $dateStart;

    /**
     * @ORM\Column(name="date_end", type="datetime", nullable=true)
     */
    private $dateEnd = null;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return Scriptlogger
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getScriptName()
    {
        return $this->scriptName;
    }

    /**
     * @param mixed $scriptName
     *
     * @return Scriptlogger
     */
    public function setScriptName($scriptName)
    {
        $this->scriptName = $scriptName;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getScriptStatus()
    {
        return $this->scriptStatus;
    }

    /**
     * @param mixed $scriptStatus
     *
     * @return Scriptlogger
     */
    public function setScriptStatus($scriptStatus)
    {
        $this->scriptStatus = $scriptStatus;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getDateStart()
    {
        return $this->dateStart;
    }

    /**
     * @param mixed $dateStart
     *
     * @return Scriptlogger
     */
    public function setDateStart($dateStart)
    {
        $this->dateStart = $dateStart;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getDateEnd()
    {
        return $this->dateEnd;
    }

    /**
     * @param mixed $dateEnd
     *
     * @return Scriptlogger
     */
    public function setDateEnd($dateEnd)
    {
        $this->dateEnd = $dateEnd;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getScriptMessage()
    {
        return $this->scriptMessage;
    }

    /**
     * @param mixed $scriptMessage
     *
     * @return Scriptlogger
     */
    public function setScriptMessage($scriptMessage)
    {
        $this->scriptMessage = $scriptMessage;

        return $this;
    }
}
