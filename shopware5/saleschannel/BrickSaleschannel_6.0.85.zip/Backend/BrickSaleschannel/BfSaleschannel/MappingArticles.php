<?php

/**
 * MappingArticles
 *
 * @package Shopware\CustomModels\BfSaleschannel
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2015 brickfox GmbH http://www.brickfox.de
 */
namespace Shopware\CustomModels\BfSaleschannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Doctrine\ORM\Mapping\Index;
use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_articles", uniqueConstraints={@UniqueConstraint(name="brickfoxID", columns={"brickfoxID"})}, indexes={@Index(name="search_idx",
 *     columns={"brickfoxID"})})
 */
class MappingArticles extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $brickfoxId
     * @ORM\Column(name="brickfoxID", type="integer", nullable=false)
     */
    private $brickfoxId;

    /**
     * @var integer $shopwareId
     * @ORM\Column(name="shopwareID", type="integer", nullable=false)
     */
    private $shopwareId;

    /**
     * @var \Shopware\Models\Article\Article $article
     * @ORM\OneToOne(targetEntity="Shopware\Models\Article\Article", orphanRemoval=true)
     * @ORM\JoinColumn(name="shopwareID", referencedColumnName="id")
     */
    private $article;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return MappingArticles
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return int
     */
    public function getBrickfoxId()
    {
        return $this->brickfoxId;
    }

    /**
     * @param int $brickfoxId
     *
     * @return MappingArticles
     */
    public function setBrickfoxId($brickfoxId)
    {
        $this->brickfoxId = $brickfoxId;

        return $this;
    }

    /**
     * @return int
     */
    public function getShopwareId()
    {
        return $this->shopwareId;
    }

    /**
     * @param int $shopwareId
     *
     * @return MappingArticles
     */
    public function setShopwareId($shopwareId)
    {
        $this->shopwareId = $shopwareId;

        return $this;
    }

    /**
     * @return \Shopware\Models\Article\Article
     */
    public function getArticle()
    {
        return $this->article;
    }

    /**
     * @param \Shopware\Models\Article\Article $article
     *
     * @return MappingArticles
     */
    public function setArticle($article)
    {
        $this->article = $article;

        return $this;
    }
}
