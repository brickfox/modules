<?php
/**
 * ApiImportDataDetail
 *
 * @package Shopware\CustomModels\BfSaleschannel
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfSaleschannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Doctrine\ORM\Mapping\Index;
use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_api_import_data_detail", indexes={@Index(name="search_idx", columns={"job_id", "processed", "date_insert", "last_update", "process_date"})})
 */
class ApiImportDataDetail extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $jobId
     * @ORM\Column(name="job_id", type="string", nullable=false)
     */
    private $jobId;

    /**
     * @var resource $data
     * @ORM\Column(name="data", type="blob", nullable=false)
     */
    private $data;

    /**
     * @var bool $processed
     * @ORM\Column(name="processed", type="integer", nullable = false)
     */
    private $processed;

    /**
     * @var string $errorCodes
     * @ORM\Column(name="error_codes", type="string", nullable=true)
     */
    private $errorCodes;

    /**
     * @var  string $error
     * @ORM\Column(name="error_message", type="text", nullable=true)
     */
    private $errorMessage;

    /**
     * @var integer $brickfoxId
     * @ORM\Column(name="brickfox_id", type="integer", nullable=true)
     */
    private $brickfoxId;

    /**
     * @var \DateTime $dateInsert
     * @ORM\Column(name="date_insert", type="datetime", nullable=false)
     */
    private $dateInsert;

    /**
     * @var \DateTime $lastUpdate
     * @ORM\Column(name="last_update", type="datetime", nullable=false)
     */
    private $lastUpdate;

    /**
     * @var \DateTime $processDate
     * @ORM\Column(name="process_date", type="datetime", nullable=true)
     */
    private $processDate;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return ApiImportDataDetail
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return string
     */
    public function getJobId()
    {
        return $this->jobId;
    }

    /**
     * @param string $jobId
     *
     * @return ApiImportDataDetail
     */
    public function setJobId($jobId)
    {
        $this->jobId = $jobId;

        return $this;
    }

    /**
     * @return resource
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * @param resource $data
     */
    public function setData($data)
    {
        $this->data = $data;
    }

    /**
     * @return boolean
     */
    public function getProcessed()
    {
        return $this->processed;
    }

    /**
     * @param boolean $processed
     *
     * @return ApiImportDataDetail
     */
    public function setProcessed($processed)
    {
        $this->processed = $processed;

        return $this;
    }

    /**
     * @return string
     */
    public function getErrorCodes()
    {
        return $this->errorCodes;
    }

    /**
     * @param string $errorCodes
     *
     * @return ApiImportDataDetail
     */
    public function setErrorCodes($errorCodes)
    {
        $this->errorCodes = $errorCodes;

        return $this;
    }

    /**
     * @return string
     */
    public function getErrorMessage()
    {
        return $this->errorMessage;
    }

    /**
     * @param string $errorMessage
     *
     * @return ApiImportDataDetail
     */
    public function setErrorMessage($errorMessage)
    {
        $this->errorMessage = $errorMessage;

        return $this;
    }

    /**
     * @return int
     */
    public function getBrickfoxId()
    {
        return $this->brickfoxId;
    }

    /**
     * @param int $brickfoxId
     *
     * @return ApiImportDataDetail
     */
    public function setBrickfoxId($brickfoxId)
    {
        $this->brickfoxId = $brickfoxId;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getDateInsert()
    {
        return $this->dateInsert;
    }

    /**
     * @param \DateTime $dateInsert
     *
     * @return ApiImportDataDetail
     */
    public function setDateInsert($dateInsert)
    {
        $this->dateInsert = $dateInsert;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getLastUpdate()
    {
        return $this->lastUpdate;
    }

    /**
     * @param \DateTime $lastUpdate
     *
     * @return ApiImportDataDetail
     */
    public function setLastUpdate($lastUpdate)
    {
        $this->lastUpdate = $lastUpdate;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getProcessDate()
    {
        return $this->processDate;
    }

    /**
     * @param \DateTime $processDate
     *
     * @return ApiImportDataDetail
     */
    public function setProcessDate($processDate)
    {
        $this->processDate = $processDate;

        return $this;
    }
}
