<?php

/**
 * Suppliers
 *
 * @package Bf\Saleschannel\Models
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2015 brickfox GmbH http://www.brickfox.de
 */
namespace Shopware\CustomModels\BfSaleschannel;

use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_suppliers")
 */
class MappingSuppliers extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $brickfoxId
     * @ORM\Column(name="brickfoxID", type="integer", nullable=false, unique=true)
     */
    private $brickfoxId;

    /**
     * @var integer $shopwareId
     * @ORM\Column(name="shopwareID", type="integer", nullable=false)
     */
    private $shopwareId;

    /**
     * OWNING SIDE
     *
     * @var \Shopware\Models\Article\Supplier $supplier
     * @ORM\OneToOne(targetEntity="Shopware\Models\Article\Supplier", orphanRemoval=true)
     * @ORM\JoinColumn(name="shopwareID", referencedColumnName="id")
     */
    private $supplier;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return MappingSuppliers
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return int
     */
    public function getBrickfoxId()
    {
        return $this->brickfoxId;
    }

    /**
     * @param int $brickfoxId
     *
     * @return MappingSuppliers
     */
    public function setBrickfoxId($brickfoxId)
    {
        $this->brickfoxId = $brickfoxId;

        return $this;
    }

    /**
     * @return int
     */
    public function getShopwareId()
    {
        return $this->shopwareId;
    }

    /**
     * @param int $shopwareId
     *
     * @return MappingSuppliers
     */
    public function setShopwareId($shopwareId)
    {
        $this->shopwareId = $shopwareId;

        return $this;
    }

    /**
     * @return \Shopware\Models\Article\Supplier
     */
    public function getSupplier()
    {
        return $this->supplier;
    }

    /**
     * @param \Shopware\Models\Article\Supplier $supplier
     *
     * @return MappingSuppliers
     */
    public function setSupplier($supplier)
    {
        $this->supplier = $supplier;

        return $this;
    }
}
