<?php
/**
 * SpecialPrices.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfSaleschannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Doctrine\ORM\Mapping\Index;
use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_special_prices", indexes={@Index(name="search_idx", columns={"special_price_start", "special_price_end", "active", "shops_id"})})
 */
class SpecialPrices extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $shopsId
     * @ORM\Column(name="shops_id", type="integer", nullable=true)
     */
    private $shopsId;

    /**
     * @var integer $brickfoxId
     * @ORM\Column(name="brickfoxID", type="integer", nullable=false)
     */
    private $brickfoxId;

    /**
     * @var \DateTime $specialPriceStart
     * @ORM\Column(name="special_price_start", type="datetime", nullable=true)
     */
    private $specialPriceStart;

    /**
     * @var \DateTime $specialPriceEnd
     * @ORM\Column(name="special_price_end", type="datetime", nullable=true)
     */
    private $specialPriceEnd;

    /**
     * @ORM\Column(name="special_price", type="float", nullable=false)
     */
    private $specialPrice;

    /**
     * @ORM\Column(name="price", type="float", nullable=false)
     */
    private $price;

    /**
     * @ORM\Column(name="uvp", type="float", nullable=false)
     */
    private $uvp;

    /**
     * @var integer $active
     * @ORM\Column(name="active", type="integer", nullable=false)
     */
    private $active;

    /**
     * @var string $currencyCode
     * @ORM\Column(name="currency_code", type="string", nullable=true)
     */
    private $currencyCode;

    /**
     * @ORM\Column(name="date_insert", type="datetime", nullable=true)
     */
    private $dateInsert;

    /**
     * @ORM\Column(name="last_update", type="datetime", nullable=true)
     */
    private $lastUpdate;

    /**
     * @var bool
     */
    private $loaded = false;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return \DateTime
     */
    public function getSpecialPriceStart()
    {
        return $this->specialPriceStart;
    }

    /**
     * @param $specialPriceStart
     */
    public function setSpecialPriceStart($specialPriceStart)
    {
        $this->specialPriceStart = $specialPriceStart;
    }

    /**
     * @return \DateTime
     */
    public function getSpecialPriceEnd()
    {
        return $this->specialPriceEnd;
    }

    /**
     * @param $specialPriceEnd
     */
    public function setSpecialPriceEnd($specialPriceEnd)
    {
        $this->specialPriceEnd = $specialPriceEnd;
    }

    /**
     * @return int
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * @param int $active
     */
    public function setActive($active)
    {
        $this->active = $active;
    }

    /**
     * @return \DateTime
     */
    public function getDateInsert()
    {
        return $this->dateInsert;
    }

    /**
     * @param $dateInsert
     */
    public function setDateInsert($dateInsert)
    {
        $this->dateInsert = $dateInsert;
    }

    /**
     * @return \DateTime
     */
    public function getLastUpdate()
    {
        return $this->lastUpdate;
    }

    /**
     * @param $lastUpdate
     */
    public function setLastUpdate($lastUpdate)
    {
        $this->lastUpdate = $lastUpdate;
    }

    /**
     * @return int
     */
    public function getShopsId()
    {
        return $this->shopsId;
    }

    /**
     * @param int $shopsId
     */
    public function setShopsId($shopsId)
    {
        $this->shopsId = $shopsId;
    }

    /**
     * @return int
     */
    public function getBrickfoxId()
    {
        return $this->brickfoxId;
    }

    /**
     * @param int $brickfoxId
     */
    public function setBrickfoxId($brickfoxId)
    {
        $this->brickfoxId = $brickfoxId;
    }

    /**
     * @return string
     */
    public function getCurrencyCode()
    {
        return $this->currencyCode;
    }

    /**
     * @param string $currencyCode
     */
    public function setCurrencyCode($currencyCode)
    {
        $this->currencyCode = $currencyCode;
    }

    /**
     * @return mixed
     */
    public function getSpecialPrice()
    {
        return $this->specialPrice;
    }

    /**
     * @param mixed $specialPrice
     */
    public function setSpecialPrice($specialPrice)
    {
        $this->specialPrice = $specialPrice;
    }

    /**
     * @return mixed
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * @param mixed $price
     */
    public function setPrice($price)
    {
        $this->price = $price;
    }

    /**
     * @return bool
     */
    public function isLoaded()
    {
        return $this->loaded;
    }

    /**
     * @return mixed
     */
    public function getUvp()
    {
        return $this->uvp;
    }

    /**
     * @param mixed $uvp
     */
    public function setUvp($uvp)
    {
        $this->uvp = $uvp;
    }

    /**
     * @param array $array
     *
     * @return null|object|ModelEntity|SpecialPrices
     */
    public function loadByAndSet(array $array = array())
    {
        $bfSpecialPriceModel = null;

        if(count($array) > 0)
        {
            $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\SpecialPrices');
            $bfSpecialPriceModel = $repository->findOneBy($array);

            if($bfSpecialPriceModel === null)
            {
                $bfSpecialPriceModel = $this->fromArray($array);
                Shopware()->Models()->persist($bfSpecialPriceModel);
            }
            else
            {
                $bfSpecialPriceModel->loaded = true;
            }
        }

        return $bfSpecialPriceModel;
    }

    public function calculateSpecialPrice($brickfoxId, $specialPriceStart, $specialPriceEnd, $specialPrice, $price, $nowDate)
    {
        $calculatedSpecialPrice = array(
            'price' => $price,
            'specialPrice' => '',
            'active' => 0
        );

        return $calculatedSpecialPrice;
    }
}