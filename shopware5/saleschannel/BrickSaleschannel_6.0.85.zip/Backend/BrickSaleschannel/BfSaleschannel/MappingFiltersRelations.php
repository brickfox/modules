<?php
/**
 * MappingFiltersRelations
 *
 * @package Shopware\CustomModels\BfSaleschannel
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfSaleschannel;

use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_filters_relations")
 */
class MappingFiltersRelations extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var int $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var int $mappingFiltersId
     * @ORM\Column(name="mappingFiltersID", type="integer", nullable=false)
     */
    private $mappingFiltersId;

    /**
     * @var int $optionId
     * @ORM\Column(name="optionID", type="integer")
     */
    private $optionId;

    /**
     * @var int $valueId
     * @ORM\Column(name="valueID", type="integer")
     */
    private $valueId;

    /**
     * @var int $brickfoxId
     * @ORM\Column(name="brickfoxValuesID", type="string")
     */
    private $brickfoxId;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return MappingFiltersRelations
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return int
     */
    public function getMappingFiltersId()
    {
        return $this->mappingFiltersId;
    }

    /**
     * @param int $mappingFiltersId
     *
     * @return MappingFiltersRelations
     */
    public function setMappingFiltersId($mappingFiltersId)
    {
        $this->mappingFiltersId = $mappingFiltersId;

        return $this;
    }

    /**
     * @return int
     */
    public function getOptionId()
    {
        return $this->optionId;
    }

    /**
     * @param int $optionId
     *
     * @return MappingFiltersRelations
     */
    public function setOptionId($optionId)
    {
        $this->optionId = $optionId;

        return $this;
    }

    /**
     * @return int
     */
    public function getValueId()
    {
        return $this->valueId;
    }

    /**
     * @param int $valueId
     *
     * @return MappingFiltersRelations
     */
    public function setValueId($valueId)
    {
        $this->valueId = $valueId;

        return $this;
    }

    /**
     * @return string|int
     */
    public function getBrickfoxId()
    {
        return $this->brickfoxId;
    }

    /**
     * @param int $brickfoxId
     *
     * @return MappingFiltersRelations
     */
    public function setBrickfoxId($brickfoxId)
    {
        $this->brickfoxId = $brickfoxId;

        return $this;
    }

}
