<?php

/**
 * MappingCategories
 *
 * @package Shopware\CustomModels\BfSaleschannel
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2015 brickfox GmbH http://www.brickfox.de
 */
namespace Shopware\CustomModels\BfSaleschannel;

use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_categories")
 */
class MappingCategories extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $brickfoxId
     * @ORM\Column(name="brickfoxID", type="integer", nullable=false)
     */
    private $brickfoxId;

    /**
     * @var integer $shopwareId
     * @ORM\Column(name="shopwareID", type="integer", nullable=false)
     */
    private $shopwareId;

    /**
     * @var string $languagesCode
     * @ORM\Column(name="languages_code", type="string", nullable=false)
     */
    private $languagesCode;

    /**
     * @var string $shopsId
     * @ORM\Column(name="shops_id", type="integer", nullable=false)
     */
    private $shopsId;

    /**
     * OWNING SIDE
     *
     * @var \Shopware\Models\Category\Category $category
     * @ORM\OneToOne(targetEntity="Shopware\Models\Category\Category", orphanRemoval=true)
     * @ORM\JoinColumn(name="shopwareID", referencedColumnName="id")
     */
    private $category;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return MappingCategories
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return int
     */
    public function getBrickfoxId()
    {
        return $this->brickfoxId;
    }

    /**
     * @param int $brickfoxId
     *
     * @return MappingCategories
     */
    public function setBrickfoxId($brickfoxId)
    {
        $this->brickfoxId = $brickfoxId;

        return $this;
    }

    /**
     * @return int
     */
    public function getShopwareId()
    {
        return $this->shopwareId;
    }

    /**
     * @param int $shopwareId
     *
     * @return MappingCategories
     */
    public function setShopwareId($shopwareId)
    {
        $this->shopwareId = $shopwareId;

        return $this;
    }

    /**
     * @return \Shopware\Models\Category\Category
     */
    public function getCategory()
    {
        return $this->category;
    }

    /**
     * @param \Shopware\Models\Category\Category $category
     *
     * @return MappingCategories
     */
    public function setCategory($category)
    {
        $this->category = $category;

        return $this;
    }

    /**
     * @return string
     * @deprecated
     */
    public function getLanguagesCode()
    {
        return $this->languagesCode;
    }

    /**
     * @param string $languagesCode
     * @return MappingCategories
     */
    public function setLanguagesCode($languagesCode)
    {
        $this->languagesCode = $languagesCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getShopsId()
    {
        return $this->shopsId;
    }

    /**
     * @param mixed $shopsId
     * @return MappingCategories
     */
    public function setShopsId($shopsId)
    {
        $this->shopsId = $shopsId;

        return $this;
    }
}
