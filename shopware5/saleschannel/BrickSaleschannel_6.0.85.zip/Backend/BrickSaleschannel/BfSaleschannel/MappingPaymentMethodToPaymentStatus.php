<?php
/**
 * MappingPaymentMethodToPaymentStatus.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfSaleschannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_payment_to_payment_status", uniqueConstraints={@UniqueConstraint(name="paymentID", columns={"paymentID"})})
 */
class MappingPaymentMethodToPaymentStatus extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $paymentId
     * @ORM\Column(name="paymentID", type="integer", nullable=false)
     */
    private $paymentId;

    /**
     * @var integer $paymentStatusId
     * @ORM\Column(name="paymentStatusID", type="integer", nullable=false)
     */
    private $paymentStatusId;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return int
     */
    public function getPaymentId()
    {
        return $this->paymentId;
    }

    /**
     * @param int $paymentId
     */
    public function setPaymentId($paymentId)
    {
        $this->paymentId = $paymentId;
    }

    /**
     * @return int
     */
    public function getPaymentStatusId()
    {
        return $this->paymentStatusId;
    }

    /**
     * @param int $paymentStatusId
     */
    public function setPaymentStatusId($paymentStatusId)
    {
        $this->paymentStatusId = $paymentStatusId;
    }
}