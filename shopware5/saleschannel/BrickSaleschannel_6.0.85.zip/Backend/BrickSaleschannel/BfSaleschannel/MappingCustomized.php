<?php
/**
 * MappingCustomized
 *
 * @package Shopware\CustomModels\BfSaleschannel
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfSaleschannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_customized", uniqueConstraints={@UniqueConstraint(name="mapping_field_key", columns={"mapping_field_key"})})
 */
class MappingCustomized extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $xmlTag
     * @ORM\Column(name="xml_tag", type="string", nullable=false)
     */
    private $xmlTag;

    /**
     * @var string $mappingFieldKey
     * @ORM\Column(name="mapping_field_key", type="string", nullable=false)
     */
    private $mappingFieldKey;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return MappingCustomized
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return string
     */
    public function getXmlTag()
    {
        return $this->xmlTag;
    }

    /**
     * @param string $xmlTag
     *
     * @return MappingCustomized
     */
    public function setXmlTag($xmlTag)
    {
        $this->xmlTag = $xmlTag;

        return $this;
    }

    /**
     * @return string
     */
    public function getMappingFieldKey()
    {
        return $this->mappingFieldKey;
    }

    /**
     * @param string $mappingFieldKey
     *
     * @return MappingCustomized
     */
    public function setMappingFieldKey($mappingFieldKey)
    {
        $this->mappingFieldKey = $mappingFieldKey;

        return $this;
    }
}
