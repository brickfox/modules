<?php
/**
 * MappingShops
 *
 * @package Shopware\CustomModels\BfSaleschannel
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfSaleschannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_shops")
 */
class MappingShops extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $brickfoxShopsId
     * @ORM\Column(name="brickfoxID", type="integer", nullable=false)
     */
    private $brickfoxId;

    /**
     * @var integer $shopwareId
     * @ORM\Column(name="shopwareID", type="integer", nullable=false)
     */
    private $shopwareId;

    /**
     * @var  integer $isMasterShop
     * @ORM\Column(name="is_master_shop", type="integer")
     */
    private $isMasterShop;

    /**
     * @var \Shopware\Models\Shop\Shop $shop
     * @ORM\OneToOne(targetEntity="Shopware\Models\Shop\Shop", orphanRemoval=true)
     * @ORM\JoinColumn(name="shopwareID", referencedColumnName="id")
     */
    private $shop;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return MappingShops
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return int
     */
    public function getBrickfoxId()
    {
        return $this->brickfoxId;
    }

    /**
     * @param int $brickfoxId
     *
     * @return MappingShops
     */
    public function setBrickfoxId($brickfoxId)
    {
        $this->brickfoxId = $brickfoxId;

        return $this;
    }

    /**
     * @return int
     */
    public function getShopwareId()
    {
        return $this->shopwareId;
    }

    /**
     * @param int $shopwareId
     *
     * @return MappingShops
     */
    public function setShopwareId($shopwareId)
    {
        $this->shopwareId = $shopwareId;

        return $this;
    }

    /**
     * @return \Shopware\Models\Shop\Shop
     */
    public function getShop()
    {
        return $this->shop;
    }

    /**
     * @param \Shopware\Models\Shop\Shop $shop
     *
     * @return MappingShops
     */
    public function setShop($shop)
    {
        $this->shop = $shop;

        return $this;
    }

    /**
     * @return int
     */
    public function getisMasterShop()
    {
        return $this->isMasterShop;
    }

    /**
     * @param int $isMasterShop
     */
    public function setIsMasterShop($isMasterShop)
    {
        $this->isMasterShop = $isMasterShop;
    }
}
