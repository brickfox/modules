<?php
/**
 * MappingCurrencies
 *
 * @package Shopware\CustomModels\BfSaleschannel
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfSaleschannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_currencies", uniqueConstraints={@UniqueConstraint(name="mapping_field_key", columns={"mapping_field_key"})})
 */
class MappingCurrencies extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $brickfoxCurrenciesCode
     * @ORM\Column(name="brickfox_currencies_code", type="string", nullable=false)
     */
    private $brickfoxCurrenciesCode;

    /**
     * @var string $shopwareCustomerGroupId
     * @ORM\Column(name="mapping_field_key", type="string", nullable=false)
     */
    private $mappingFieldKey;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return MappingCurrencies
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return string
     */
    public function getBrickfoxCurrenciesCode()
    {
        return $this->brickfoxCurrenciesCode;
    }

    /**
     * @param string $brickfoxCurrenciesCode
     *
     * @return MappingCurrencies
     */
    public function setBrickfoxCurrenciesCode($brickfoxCurrenciesCode)
    {
        $this->brickfoxCurrenciesCode = $brickfoxCurrenciesCode;

        return $this;
    }

    /**
     * @return string
     */
    public function getMappingFieldKey()
    {
        return $this->mappingFieldKey;
    }

    /**
     * @param string $mappingFieldKey
     *
     * @return MappingCurrencies
     */
    public function setMappingFieldKey($mappingFieldKey)
    {
        $this->mappingFieldKey = $mappingFieldKey;

        return $this;
    }
}
