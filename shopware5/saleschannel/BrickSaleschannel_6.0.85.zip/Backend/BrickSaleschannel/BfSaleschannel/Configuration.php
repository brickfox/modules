<?php
/**
 * Configuration
 *
 * @package Shopware\CustomModels\BfSaleschannel
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfSaleschannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_configuration", uniqueConstraints={@UniqueConstraint(name="configuration_key", columns={"configuration_key"})})
 */
class Configuration extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $configurationKey
     * @ORM\Column(name="configuration_key", type="string", nullable=false)
     */
    private $configurationKey;

    /**
     * @var string $configurationValue
     * @ORM\Column(name="configuration_value", type="text", nullable=true)
     */
    private $configurationValue;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return Configuration
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getConfigurationKey()
    {
        return $this->configurationKey;
    }

    /**
     * @param mixed $configurationKey
     *
     * @return Configuration
     */
    public function setConfigurationKey($configurationKey)
    {
        $this->configurationKey = $configurationKey;

        return $this;
    }

    /**
     * @return string
     */
    public function getConfigurationValue()
    {
        return $this->configurationValue;
    }

    /**
     * @param string $configurationValue
     *
     * @return Configuration
     */
    public function setConfigurationValue($configurationValue)
    {
        $this->configurationValue = $configurationValue;

        return $this;
    }
}
