<?php

namespace Shopware\CustomModels\BfSaleschannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Doctrine\ORM\Mapping\Index;
use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_api_export_seo_urls", indexes={@Index(name="search_idx", columns={"brickfoxID", "shopwareID", "shopwareDetailsID", "subshopID", "date_insert", "last_update"})})
 */
class ApiExportSeoUrls
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $brickfoxExternId
     * @ORM\Column(name="brickfoxID", type="integer", nullable=false)
     */
    private $brickfoxId;

    /**
     * @var integer $shopwareId
     * @ORM\Column(name="shopwareID", type="integer", nullable=true)
     */
    private $shopwareId;

    /**
     * @var integer $shopwareDetailsId
     * @ORM\Column(name="shopwareDetailsID", type="integer", nullable=true)
     */
    private $shopwareDetailsId;

    /**
     * @var string $originalPath
     * @ORM\Column(name="original_path", type="string", nullable=false)
     */
    private $originalPath;

    /**
     * @var string $seoPath
     * @ORM\Column(name="seo_path", type="string", nullable=false)
     */
    private $seoPath;

    /**
     * @var integer $subSop
     * @ORM\Column(name="subshopID", type="integer", nullable=false)
     */
    private $subShopId;

    /**
     * @var \DateTime $dateInsert
     * @ORM\Column(name="date_insert", type="datetime", nullable=true)
     */
    private $dateInsert;

    /**
     * @var \DateTime $lastUpdate
     * @ORM\Column(name="last_update", type="datetime", nullable=true)
     */
    private $lastUpdate;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return int
     */
    public function getBrickfoxId()
    {
        return $this->brickfoxId;
    }

    /**
     * @param int $brickfoxId
     */
    public function setBrickfoxId($brickfoxId)
    {
        $this->brickfoxId = $brickfoxId;
    }

    /**
     * @return int
     */
    public function getShopwareId()
    {
        return $this->shopwareId;
    }

    /**
     * @param int $shopwareId
     */
    public function setShopwareId($shopwareId)
    {
        $this->shopwareId = $shopwareId;
    }

    /**
     * @return int
     */
    public function getShopwareDetailsId()
    {
        return $this->shopwareDetailsId;
    }

    /**
     * @param int $shopwareDetailsId
     */
    public function setShopwareDetailsId($shopwareDetailsId)
    {
        $this->shopwareDetailsId = $shopwareDetailsId;
    }

    /**
     * @return string
     */
    public function getOriginalPath()
    {
        return $this->originalPath;
    }

    /**
     * @param string $originalPath
     */
    public function setOriginalPath($originalPath)
    {
        $this->originalPath = $originalPath;
    }

    /**
     * @return string
     */
    public function getSeoPath()
    {
        return $this->seoPath;
    }

    /**
     * @param string $seoPath
     */
    public function setSeoPath($seoPath)
    {
        $this->seoPath = $seoPath;
    }

    /**
     * @return \DateTime
     */
    public function getDateInsert()
    {
        return $this->dateInsert;
    }

    /**
     * @param \DateTime $dateInsert
     */
    public function setDateInsert($dateInsert)
    {
        $this->dateInsert = $dateInsert;
    }

    /**
     * @return \DateTime
     */
    public function getLastUpdate()
    {
        return $this->lastUpdate;
    }

    /**
     * @param \DateTime $lastUpdate
     */
    public function setLastUpdate($lastUpdate)
    {
        $this->lastUpdate = $lastUpdate;
    }

    /**
     * @return int
     */
    public function getSubShopId()
    {
        return $this->subShopId;
    }

    /**
     * @param int $subShopId
     */
    public function setSubShopId($subShopId)
    {
        $this->subShopId = $subShopId;
    }
}