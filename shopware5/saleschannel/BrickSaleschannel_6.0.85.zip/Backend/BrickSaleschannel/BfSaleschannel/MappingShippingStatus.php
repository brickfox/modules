<?php
/**
 * MappingShippingStatus
 *
 * @package Shopware\CustomModels\BfSaleschannel
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfSaleschannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_shipping_status", uniqueConstraints={@UniqueConstraint(name="mapping_field_key", columns={"mapping_field_key"})})
 */
class MappingShippingStatus extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $shippingStatusCode
     * @ORM\Column(name="brickfox_shipping_status_code", type="string", nullable=false)
     */
    private $brickfoxShippingStatusCode;

    /**
     * @var string $mappingFieldKey
     * @ORM\Column(name="mapping_field_key", type="string", nullable=false)
     */
    private $mappingFieldKey;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return MappingShippingStatus
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return string
     */
    public function getMappingFieldKey()
    {
        return $this->mappingFieldKey;
    }

    /**
     * @param string $mappingFieldKey
     *
     * @return MappingShippingStatus
     */
    public function setMappingFieldKey($mappingFieldKey)
    {
        $this->mappingFieldKey = $mappingFieldKey;

        return $this;
    }

    /**
     * @return string
     */
    public function getBrickfoxShippingStatusCode()
    {
        return $this->brickfoxShippingStatusCode;
    }

    /**
     * @param string $brickfoxShippingStatusCode
     *
     * @return MappingShippingStatus
     */
    public function setBrickfoxShippingStatusCode($brickfoxShippingStatusCode)
    {
        $this->brickfoxShippingStatusCode = $brickfoxShippingStatusCode;

        return $this;
    }
}
