<?php
/**
 * sArticleConfiguratorOptionRelations
 *
 * @package Shopware\CustomModels\BfSaleschannel
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfSaleschannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="s_article_configurator_option_relations", uniqueConstraints={@UniqueConstraint(name="articleID", columns={"article_id", "option_id"})})
 */
class sArticleConfiguratorOptionRelations
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $articleID
     * @ORM\Column(name="article_id", type="integer", nullable=false)
     */
    private $articleID;

    /**
     * @var integer $optionId
     * @ORM\Column(name="option_id", type="integer", nullable=false)
     */
    private $optionID;

    /**
     * @var \Shopware\Models\Article\Detail $detail
     * @ORM\OneToOne(targetEntity="Shopware\Models\Article\Detail")
     * @ORM\JoinColumn(name="article_id", referencedColumnName="id")
     */
    private $detail;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return sArticleConfiguratorOptionRelations
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return int
     */
    public function getArticleID()
    {
        return $this->articleID;
    }

    /**
     * @param int $articleID
     *
     * @return sArticleConfiguratorOptionRelations
     */
    public function setArticleID($articleID)
    {
        $this->articleID = $articleID;

        return $this;
    }

    /**
     * @return int
     */
    public function getOptionID()
    {
        return $this->optionID;
    }

    /**
     * @param int $optionID
     *
     * @return sArticleConfiguratorOptionRelations
     */
    public function setOptionID($optionID)
    {
        $this->optionID = $optionID;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getDetail()
    {
        return $this->detail;
    }

    /**
     * @param mixed $detail
     *
     * @return sArticleConfiguratorOptionRelations
     */
    public function setDetail($detail)
    {
        $this->detail = $detail;

        return $this;
    }
}
