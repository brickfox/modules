<?php
namespace Shopware\CustomModels\BfSaleschannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Doctrine\ORM\Mapping\Index;
use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping as ORM;

/**
 * MappingConfiguratorOptions
 *
 * @package Shopware\CustomModels\BfSaleschannel
 *
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 *
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_configurator_options", uniqueConstraints={@UniqueConstraint(name="brickfoxID", columns={"brickfoxID"})}, indexes={@Index(name="search_idx", columns={"brickfoxID"})})
 */
class MappingConfiguratorOptions extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $brickfoxId
     * @ORM\Column(name="brickfoxID", type="integer", nullable=false)
     */
    private $brickfoxId;

    /**
     * @var integer $shopwareId
     * @ORM\Column(name="shopwareID", type="integer", nullable=false)
     */
    private $shopwareId;

    /**
     * @var string $brickfoxDiffsOptionsCode
     * @ORM\Column(name="brickfox_diffs_options_code", type="string", length=60)
     */
    private $brickfoxDiffsOptionsCode;

    /**
     * @var \DateTime $dateInsert
     * @ORM\Column(name="date_insert", type="datetime", nullable=false)
     */
    private $dateInsert;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return MappingConfiguratorOptions
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return int
     */
    public function getBrickfoxId()
    {
        return $this->brickfoxId;
    }

    /**
     * @param int $brickfoxId
     *
     * @return MappingConfiguratorOptions
     */
    public function setBrickfoxId($brickfoxId)
    {
        $this->brickfoxId = $brickfoxId;

        return $this;
    }

    /**
     * @return int
     */
    public function getShopwareId()
    {
        return $this->shopwareId;
    }

    /**
     * @param int $shopwareId
     *
     * @return MappingConfiguratorOptions
     */
    public function setShopwareId($shopwareId)
    {
        $this->shopwareId = $shopwareId;

        return $this;
    }

    /**
     * @return \Shopware\Models\Article\Configurator\Option
     */
    public function getConfiguratorOption()
    {
        return $this->configuratorOption;
    }

    /**
     * @param \Shopware\Models\Article\Configurator\Option $configuratorOption
     *
     * @return MappingConfiguratorOptions
     */
    public function setConfiguratorOption($configuratorOption)
    {
        $this->configuratorOption = $configuratorOption;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getDateInsert()
    {
        return $this->dateInsert;
    }

    /**
     * @param \DateTime $dateInsert
     *
     * @return MappingConfiguratorOptions
     */
    public function setDateInsert($dateInsert)
    {
        $this->dateInsert = $dateInsert;

        return $this;
    }

    /**
     * @return string
     */
    public function getBrickfoxDiffsOptionsCode()
    {
        return $this->brickfoxDiffsOptionsCode;
    }

    /**
     * @param string $brickfoxDiffsOptionsCode
     */
    public function setBrickfoxDiffsOptionsCode($brickfoxDiffsOptionsCode)
    {
        $this->brickfoxDiffsOptionsCode = $brickfoxDiffsOptionsCode;
    }
}
