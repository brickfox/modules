<?php
/**
 * Log
 *
 * @package Shopware\CustomModels\BfSaleschannel
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfSaleschannel;

use DateTime;
use Doctrine\ORM\Mapping\Index;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\HasLifecycleCallbacks
 * @ORM\Table(name="bf_log", indexes={@Index(name="search_idx", columns={"log_status", "error_code", "action", "type_of_log"})})
 */
class Log extends ModelEntity
{
    const IDENTIFIER_PRODUCTS              = 'article-';
    const IDENTIFIER_SUPPLIERS             = 'supplier-';
    const IDENTIFIER_CATEGORIES            = 'categorie-';
    const IDENTIFIER_ORDERS                = 'order-';
    const IDENTIFIER_ORDERS_STATUS         = 'orderstatus-';
    const TYPE_OF_LOG_IMPORT_PRODUCTS      = 'Produkt import';
    const TYPE_OF_LOG_IMPORT_CATEGORIES    = 'Kategorie import';
    const TYPE_OF_LOG_IMPORT_SUPPLIERS     = 'Hersteller import';
    const TYPE_OF_LOG_IMPORT_SUB_SHOP      = 'Multishop import';
    const TYPE_OF_LOG_EXPORT_ORDERS        = 'Bestell export';
    const TYPE_OF_LOG_IMPORT_ORDERS_STATUS = 'Bestellstatus Import';
    const TYPE_OF_LOG_READING_LIST         = 'Datensatz';
    const TYPE_OF_LOG_IMPORT_BUNDLE        = 'Bundle import';
    const LOG_MODEL                        = 'Shopware\CustomModels\BfSaleschannel\Log';
    const LOG_STATUS_FATAL                 = 'Fatal Error';
    const LOG_STATUS_WARNING               = 'Warning';
    const LOG_STATUS_ERROR                 = 'Error';
    const LOG_STATUS_SUCCESS               = 'Success';
    const SETTER_ALIAS_LOG_STATUS          = 'logStatus';
    const SETTER_ALIAS_ERROR_CODE          = 'errorCode';
    const SETTER_ALIAS_LOG_MESSAGE         = 'logMessage';
    const SETTER_ALIAS_ACTION              = 'action';
    const SETTER_ALIAS_USER                = 'userName';

    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $logStatus
     * @ORM\Column(name="log_status", type="string", nullable=false)
     */
    private $logStatus;

    /**
     * @var string $action
     * @ORM\Column(name="action", type="string", nullable=true)
     */
    private $action;

    /**
     * @var string $errorCode
     * @ORM\Column(name="error_code", type="string", nullable=true)
     */
    private $errorCode;

    /**
     * @var string $logMessage
     * @ORM\Column(name="log_message", type="text", length=1000)
     */
    private $logMessage;

    /**
     * @var string $userId
     * @ORM\Column(name="user_name", type="string", nullable=true)
     */
    private $userName;

    /**
     * @var string $typeOfLog
     * @ORM\Column(name="type_of_log", type="string", nullable=true)
     */
    private $typeOfLog;

    /**
     * @var string $identifierLog
     * @ORM\Column(name="identifier_log", type="string", nullable=true)
     */
    private $identifierLog;

    /**
     * @var datetime $dateInsert
     * @ORM\Column(name="date_insert", type="datetime", nullable=false)
     */
    private $dateInsert;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return Log
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return string
     */
    public function getLogStatus()
    {
        return $this->logStatus;
    }

    /**
     * @param string $logStatus
     *
     * @return Log
     */
    public function setLogStatus($logStatus)
    {
        $this->logStatus = $logStatus;

        return $this;
    }

    /**
     * @return int
     */
    public function getErrorCode()
    {
        return $this->errorCode;
    }

    /**
     * @param int $errorCode
     *
     * @return Log
     */
    public function setErrorCode($errorCode)
    {
        $this->errorCode = $errorCode;

        return $this;
    }

    /**
     * @return string
     */
    public function getLogMessage()
    {
        return $this->logMessage;
    }

    /**
     * @param string $logMessage
     *
     * @return Log
     */
    public function setLogMessage($logMessage)
    {
        $this->logMessage = $logMessage;

        return $this;
    }

    /**
     * @return datetime
     */
    public function getDateInsert()
    {
        return $this->dateInsert;
    }

    /**
     * @param datetime $dateInsert
     *
     * @return Log
     */
    public function setDateInsert($dateInsert)
    {
        $this->dateInsert = $dateInsert;

        return $this;
    }

    /**
     * @return string
     */
    public function getAction()
    {
        return $this->action;
    }

    /**
     * @param string $action
     *
     * @return Log
     */
    public function setAction($action)
    {
        $this->action = $action;

        return $this;
    }

    /**
     * @return string
     */
    public function getUserName()
    {
        return $this->userName;
    }

    /**
     * @param string $userName
     *
     * @return Log
     */
    public function setUserName($userName)
    {
        $this->userName = $userName;

        return $this;
    }

    /**
     * @return string
     */
    public function getTypeOfLog()
    {
        return $this->typeOfLog;
    }

    /**
     * @param string $typeOfLog
     *
     * @return Log
     */
    public function setTypeOfLog($typeOfLog)
    {
        $this->typeOfLog = $typeOfLog;

        return $this;
    }

    /**
     * @return string
     */
    public function getIdentifierLog()
    {
        return $this->identifierLog;
    }

    /**
     * @param string $identifier
     *
     * @return Log
     */
    public function setIdentifierLog($identifier)
    {
        $this->identifierLog = $identifier;

        return $this;
    }
}
