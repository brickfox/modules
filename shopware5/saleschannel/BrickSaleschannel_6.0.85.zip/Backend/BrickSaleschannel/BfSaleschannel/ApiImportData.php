<?php
/**
 * ApiImportData
 *
 * @package Shopware\CustomModels\BfSaleschannel
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfSaleschannel;

use Bf\Saleschannel\Components\Util\ConfigManager;
use Doctrine\ORM\Mapping\UniqueConstraint;
use Doctrine\ORM\Mapping\Index;
use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_api_import_data", indexes={@Index(name="search_idx", columns={"import_type", "date_insert", "last_update"})})
 */
class ApiImportData extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $importType
     * @ORM\Column(name="import_type", type="string", nullable=false)
     */
    private $importType;

    /**
     * @var bool $processed
     * @ORM\Column(name="processed", type="integer", nullable = false)
     */
    private $processed;

    /**
     * @var integer $shopsId
     * @ORM\Column(name="shops_id", type="integer", nullable=false)
     */
    private $shopsId;

    /**
     * @var string $jobId
     * @ORM\Column(name="job_id", type="string", nullable= false)
     */
    private $jobId;

    /**
     * @var integer $countedErrors
     * @ORM\Column(name="counted_errors", type="integer", nullable=true)
     */
    private $countedErrors;

    /**
     * @var \DateTime $dateInsert
     * @ORM\Column(name="date_insert", type="datetime", nullable=false)
     */
    private $dateInsert;

    /**
     * @var \DateTime $lastUpdate
     * @ORM\Column(name="last_update", type="datetime", nullable=false)
     */
    private $lastUpdate;

    /**
     * @var \DateTime $processDate
     * @ORM\Column(name="process_date", type="datetime", nullable=true)
     */
    private $processDate;

    /**
     * @var \Shopware\CustomModels\BfSaleschannel\ApiImportDataDetail
     * @ORM\OneToOne(targetEntity="Shopware\CustomModels\BfSaleschannel\ApiImportDataDetail")
     * @ORM\JoinColumn(name="job_id", referencedColumnName="job_id", onDelete="CASCADE")
     */
    private $apiImportDataDetail;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return ApiImportData
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return string
     */
    public function getImportType()
    {
        return $this->importType;
    }

    /**
     * @param string $importType
     *
     * @return ApiImportData
     */
    public function setImportType($importType)
    {
        $this->importType = $importType;

        return $this;
    }

    /**
     * @return boolean
     */
    public function getProcessed()
    {
        return $this->processed;
    }

    /**
     * @param boolean $processed
     *
     * @return ApiImportData
     */
    public function setProcessed($processed)
    {
        $this->processed = $processed;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getDateInsert()
    {
        return $this->dateInsert;
    }

    /**
     * @param \DateTime $dateInsert
     *
     * @return ApiImportData
     */
    public function setDateInsert($dateInsert)
    {
        $this->dateInsert = $dateInsert;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getLastUpdate()
    {
        return $this->lastUpdate;
    }

    /**
     * @param \DateTime $lastUpdate
     *
     * @return ApiImportData
     */
    public function setLastUpdate($lastUpdate)
    {
        $this->lastUpdate = $lastUpdate;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getProcessDate()
    {
        return $this->processDate;
    }

    /**
     * @param \DateTime $processDate
     *
     * @return ApiImportData
     */
    public function setProcessDate($processDate)
    {
        $this->processDate = $processDate;

        return $this;
    }

    /**
     * @return ApiImportDataDetail
     */
    public function getApiImportDataDetail()
    {
        return $this->apiImportDataDetail;
    }

    /**
     * @param ApiImportDataDetail $apiImportDataDetail
     *
     * @return ApiImportData
     */
    public function setApiImportDataDetail($apiImportDataDetail)
    {
        $this->apiImportDataDetail = $apiImportDataDetail;

        return $this;
    }

    /**
     * @return string
     */
    public function getJobId()
    {
        return $this->jobId;
    }

    /**
     * @param string $jobId
     *
     * @return ApiImportData
     */
    public function setJobId($jobId)
    {
        $this->jobId = $jobId;

        return $this;
    }

    /**
     * @return int
     */
    public function getCountedErrors()
    {
        return $this->countedErrors;
    }

    /**
     * @param int $countedErrors
     *
     * @return ApiImportData
     */
    public function setCountedErrors($countedErrors)
    {
        $this->countedErrors = $countedErrors;

        return $this;
    }

    /**
     * @return int
     */
    public function getShopsId()
    {
        return $this->shopsId;
    }

    /**
     * @param int $shopsId
     */
    public function setShopsId($shopsId)
    {
        $this->shopsId = $shopsId;
    }


    /**
     * @return string
     */
    public function nextJobIsProductsOrProductsUpdate()
    {
        $result = ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS;

        $apiDataResult = Shopware()->Db()->fetchRow(
            "
                select id, import_type from bf_api_import_data
                where processed = ? and (import_type = ? or import_type = ?)
                order by date_insert asc limit 1
            ",array(0, ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS, ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS_UPDATE)
        );

        if(!empty($apiDataResult) && isset($apiDataResult['import_type']))
        {
            $result = $apiDataResult['import_type'];
        }

        return $result;
    }

    /**
     * @param $processTyp
     *
     * @return \Shopware\CustomModels\BfSaleschannel\ApiImportData|null
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    public function getOldestJobToProcess($processTyp)
    {
        $result = null;

        $qb = Shopware()->Models()->createQueryBuilder();
        $qb->select(array('apiData'))->from('Shopware\CustomModels\BfSaleschannel\ApiImportData', 'apiData')->where('apiData.processed = :processed')->andWhere(
            'apiData.importType = :importType'
        )->orderBy('apiData.dateInsert')->setMaxResults(1)->setParameters(
            array(
                'processed'  => 0,
                'importType' => $processTyp
            )
        );

        $sql = $qb->getQuery();

        $result = $sql->getOneOrNullResult();

        return $result;
    }

    /**
     * @param string $processType
     *
     * @return array
     */
    public function getProcessListByProcessTyp($processType)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\ApiImportData');

        return $repository->findBy(array('importType' => $processType, 'processed' => 0));
    }
}
