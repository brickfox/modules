ALTER TABLE `bf_mapping_articles` ADD INDEX `search_idx` (`brickfoxID`);
ALTER TABLE `bf_mapping_details` ADD INDEX `search_idx` (`brickfoxID`);