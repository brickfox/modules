INSERT INTO `bf_configuration`
  (`configuration_key`, `configuration_value`)
VALUES
  ('imageMappingDiffsOptionsStatus', 'false'),
  ('imageMappingDiffsOptions', '');

ALTER TABLE `bf_mapping_configurator_options` ADD `brickfox_diffs_options_code` VARCHAR(60) AFTER `shopwareID`;