INSERT INTO `bf_configuration` (`configuration_key`, `configuration_value`)
VALUES ('enableEmailNotificationsOnError', 'false');
INSERT INTO `bf_configuration` (`configuration_key`, `configuration_value`)
VALUES ('emailNotificationErrorCodes', '');
INSERT INTO `bf_configuration` (`configuration_key`, `configuration_value`)
VALUES ('emailNotificationReceivers', '');