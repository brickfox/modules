INSERT INTO `bf_configuration` (`configuration_key`, `configuration_value`)
VALUES ('keepAttributesOnImport', '');