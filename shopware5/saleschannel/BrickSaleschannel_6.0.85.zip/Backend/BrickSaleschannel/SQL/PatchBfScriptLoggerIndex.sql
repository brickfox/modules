CREATE INDEX `bf_scriptlogger_search_index`
ON bf_scriptlogger (`date_start`);