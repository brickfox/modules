ALTER TABLE bf_special_prices
ADD uvp DOUBLE NOT NULL;