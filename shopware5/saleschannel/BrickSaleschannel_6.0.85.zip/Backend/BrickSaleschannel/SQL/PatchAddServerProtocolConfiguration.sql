INSERT INTO `bf_configuration` (`configuration_key`, `configuration_value`)
VALUES ('serverProtocol', 'false');

ALTER TABLE `bf_api_import_data_detail` MODIFY `data` LONGBLOB NOT NULL;