CREATE INDEX `bf_api_import_search_index`
ON bf_api_import_data_detail (`process_date`, `last_update`);