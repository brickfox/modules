SELECT count(*)
INTO @exist
FROM information_schema.columns
WHERE table_schema = database()
AND COLUMN_NAME  = 'brickfoxValuesID'
AND TABLE_NAME  = 'bf_mapping_filters_relations';

SET @query = IF(@exist <= 0, 'alter table bf_mapping_filters_relations add column brickfoxValuesID INT(11)', 'select \' Column Exists \' status');

PREPARE stmt from @query;

EXECUTE stmt;