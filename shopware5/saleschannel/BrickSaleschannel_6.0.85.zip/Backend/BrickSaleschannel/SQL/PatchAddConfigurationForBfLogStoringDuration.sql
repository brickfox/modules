INSERT INTO `bf_configuration` (`configuration_key`, `configuration_value`)
VALUES ('cleanBfLogAfterDays', '60');
INSERT INTO `bf_configuration` (`configuration_key`, `configuration_value`)
VALUES ('cleanBfScriptloggerAfterDays', '14');