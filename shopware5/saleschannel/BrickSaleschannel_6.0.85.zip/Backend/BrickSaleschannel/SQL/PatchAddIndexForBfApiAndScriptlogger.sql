ALTER TABLE `bf_api_import_data` ADD INDEX `process_date_idx` (`process_date`);
ALTER TABLE `bf_api_import_data_detail` ADD INDEX `process_date_idx` (`process_date`);
ALTER TABLE `bf_scriptlogger` ADD INDEX `date_start_idx` (`date_start`);
ALTER TABLE `bf_scriptlogger` ADD INDEX `script_status_idx` (`script_status`);
ALTER TABLE `bf_log` ADD INDEX `date_insert_idx` (`date_insert`);
