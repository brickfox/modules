SET @lastInsertId := (SELECT `id` FROM s_core_states ORDER BY `id` DESC LIMIT 1);

INSERT INTO s_core_states (`id`, `description`, `position`, `group`, `mail`)
VALUES
(
	@lastInsertId + 1,
	'Fehler bei Übertragung zu ERP',
	10,
	'state',
	0
);