alter table `bf_mapping_shops` add column `is_master_shop` INT(1) after `shopwareID`;
alter table `bf_api_import_data` add column `shops_id` INT(7) after `processed`;