CREATE TABLE IF NOT EXISTS bf_mapping_attr like bf_mapping_attributes;
INSERT INTO bf_mapping_attr SELECT * FROM bf_mapping_attributes;
DROP TABLE IF EXISTS bf_mapping_attributes;