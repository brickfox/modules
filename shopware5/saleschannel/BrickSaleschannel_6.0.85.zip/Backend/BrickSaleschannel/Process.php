<?php
namespace Bf\Saleschannel\Components;

use Bf\Saleschannel\Components\Import\OrdersStatus;
use Bf\Saleschannel\Components\Import\Products;
use Bf\Saleschannel\Components\Import\Categories;
use Bf\Saleschannel\Components\Import\ProductsUpdate;
use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract;
use Bf\Saleschannel\Components\Resources\Orders\OrdersStatusMail;
use Bf\Saleschannel\Components\Resources\Translation\FixTranslation;
use Bf\Saleschannel\Components\Util\Cleaner;
use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\FileManager;
use Bf\Saleschannel\Components\Util\Iterator;
use Bf\Saleschannel\Components\Util\LogManager;
use Bf\Saleschannel\Components\Util\ProcessAbstract;
use Bf\Saleschannel\Components\Util\ProcessingException;
use Bf\Saleschannel\Components\Util\ScriptLogger;
use Exception;
use Bf\Saleschannel\Components\Util\ImageHelper;
use Bf\Saleschannel\Components\Resources\Configurator\Configurator as BfConfigurator;

/**
 * Process
 *
 * @package Bf\Saleschannel\Components
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Process extends ProcessAbstract
{
    /**
     * @return void
     */
    public function preProcess()
    {
    }

    /**
     * @param $processType
     *
     * @return void
     * @throws \Doctrine\ORM\ORMException
     * @throws \Doctrine\ORM\OptimisticLockException
     * @throws \Exception
     * @throws \Zend_Db_Adapter_Exception
     */
    public function prepareProcess($processType)
    {
        //lowers the memory peek
        $conn = Shopware()->Models()->getConnection();
        $conn->getConfiguration()->setSQLLogger(null);
        ScriptLogger::getInstance()->run('process/' . $processType);

        $this->preProcess();

        $processListModels = $this->prepareProcessListByProcessTyp($processType);

        if(count($processListModels) > 0)
        {
            self::$jobId = $this->getProcessJob()->getJobId();
            ConfigManager::getInstance()->getIsMasterShopByShopsMapping($this->getProcessJob()->getShopsId());
            $iterator    = new Iterator($processListModels);
            $iterator->rewind();

            while($iterator->valid() === true)
            {
                try
                {
                    self::$bfApiImportDataDetail = $iterator->current()->getId();
                    $processModel = $iterator->current();
                    $processModelId = $processModel->getId();
                    $this->process($processModel, $processType);
                }
                catch(Exception $e)
                {
                    if($e instanceof ProcessingException && ConfigManager::getInstance()->getEnableEmailNotificationsOnError() === true) {
                        $this->handleEmailNotificationOnError($e, (isset($processModelId) ? $processModelId : null));
                    }

                    BfConfigurator::getInstance()->resetGroupIds();
                    BfConfigurator::getInstance()->resetOptionIds();
                    $this->setCountedErrors($this->getCountedErrors() + 1);

                    ScriptLogger::getInstance()->errorHandler($e->getCode(), $e->getMessage(), $e->getFile(), $e->getLine());
                    LogManager::getInstance()->logException($e, $processType);
                    Shopware()->Models()->clear();

                    if(Shopware()->Models()->isOpen() === false)
                    {
                        Shopware()->Container()->get('bootstrap')->resetResource('Models');
                        Shopware()->Models()->create(
                            Shopware()->Models()->getConnection(),
                            Shopware()->Models()->getConfiguration()
                        );

                        Shopware()->Db()->query(
                            "
                                update bf_api_import_data_detail set processed = ?, error_codes = ?, error_message = ?, process_date = ?
                                where id = ?
                            ",
                            array(0, ErrorCodes::ENTITY_MANAGER_CLOSED_ERROR_CODE, ErrorCodes::ENTITY_MANAGER_CLOSED, date('Y-m-d H:i:s', time()), $processModelId)
                        );
                    }
                }

                ImageHelper::getInstance()->resetPreSave();
                $iterator->next();
            }
        }

        $this->postProcess();
        $this->setProcessFlag(self::$jobId);

        if(Shopware()->Models()->isOpen() === true)
        {
            Shopware()->Models()->flush();
            Shopware()->Models()->clear();

            try
            {
                if($processType === ConfigManager::PROCESS_TYPE_IMPORT_MULTI_SHOPS)
                {
                    $fixTranslationClass = new FixTranslation();
                    $fixTranslationClass->prepareFixTranslation($this->getProcessor()->getProcessedArticleIds());
                }
            }
            catch(Exception $e)
            {
                ScriptLogger::getInstance()->errorHandler($e->getCode(), $e->getTraceAsString(), $e->getFile(), $e->getLine());
            }
        }
        else
        {
            exit;
        }
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function postProcess()
    {
        if($this->getProcessor() instanceof Categories)
        {
            $this->getProcessor()->cleanUpCategories();
        }

        if($this->getProcessor() instanceof OrdersStatus)
        {
            OrdersStatusMail::getInstance()->sendStatusMail();
        }

        if ($this->getProcessor() instanceof ProductsUpdate) {
            FileManager::getInstance()->recursiveDeleteFiles();
        }

        if($this->getProcessor() instanceof Products)
        {
            (new Cleaner(array(), ArticleAbstract::IMPORT_CLEAR_CATEGORIES_ASSIGNMENTS))->prepareCleanUp();
        }

        if (count(ImageHelper::getInstance()->getThumbnailsToGenerate()) > 0) {
            /** @var \Shopware\Components\Thumbnail\Manager $generator */
            $generator = Shopware()->Container()->get('thumbnail_manager');

            /** @var \Shopware\Bundle\MediaBundle\MediaService $mediaService */
            $mediaService = Shopware()->Container()->get('shopware_media.media_service');

            /** @var \Shopware\Models\Media\Media $media */
            foreach (ImageHelper::getInstance()->getThumbnailsToGenerate() as $media) {
                if ($mediaService->has($media->getPath()) === true) {
                    $generator->createMediaThumbnail($media, array(), true);
                } elseif (file_exists(Shopware()->DocPath('media_temp') . $media->getName()) === true) {
                    $mediaService->write($media->getPath(), file_get_contents(Shopware()->DocPath('media_temp') . $media->getName()));
                    if ($mediaService->has($media->getPath()) === true) {
                        unlink(Shopware()->DocPath('media_temp') . $media->getName());
                    }

                    if ($mediaService->has($media->getPath()) === true) {
                        unlink(Shopware()->DocPath('media_temp') . $media->getName());
                        $generator->createMediaThumbnail($media, array(), true);
                    }
                }
            }
        }
    }

    /**
     * @param \Bf\Saleschannel\Components\Util\ProcessingException $e
     * @param string|null $processId
     */
    private function handleEmailNotificationOnError(ProcessingException $e, $processId = null)
    {
        $configuredErrorCodes = ConfigManager::getInstance()->getEmailNotificationErrorCodes();
        $configuredEmailReceivers = ConfigManager::getInstance()->getEmailNotificationReceivers();

        if(in_array($e->getCode(), $configuredErrorCodes) === true && count($configuredEmailReceivers) > 0) {
            $subject = "[brickfox Shopware 5 Plugin] Fehler " . $e->getCode() . " aufgetreten";
            $body = "Sehr geehrtes Team von " . Shopware()->Config()->Shopname. ", <br><br>";
            $body .= "hiermit möchten wir Sie darüber informieren, dass der eingestellte Fehlerfall ".$e->getCode() . " am " . date('c') . " ";
            if($processId !== null) {
                $body .= "während der Verarbeitung des Prozesses " . $processId . " ";
            }
            $body .= "aufgetreten ist.<br>";
            $body .= "Die Fehlermeldung lautet: ". $e->getMessage() . "<br><br>";
            $body .= "Mit freundlichen Grüßen<br>";
            $body .= "Ihr brickfox Team";

            $mailObj = Shopware()->Mail();
            $mailObj->IsHTML(1);
            $mailObj->From     = Shopware()->Config()->Mail;
            $mailObj->FromName = Shopware()->Config()->Mail;
            $mailObj->Subject  =  $subject;
            $mailObj->Body = $body;
            $mailObj->ClearAddresses();

            /** @var string $recipient */
            foreach ($configuredEmailReceivers as $recipient) {
                $mailObj->AddAddress($recipient, $recipient);
            }

            $mailObj->Send();
        }
    }
}