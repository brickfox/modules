<?php
namespace Bf\Saleschannel\Install;

use Shopware_Components_Plugin_Bootstrap;

/**
 * InstallAbstract
 *
 * @package Bf\Saleschannel\Install
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class InstallAbstract
{
    /** @var Shopware_Components_Plugin_Bootstrap */
    private $shopwarePluginBootstrapClass = null;

    /**
     * @param Shopware_Components_Plugin_Bootstrap $shopwarePluginBootstrapClass
     */
    public function __construct($shopwarePluginBootstrapClass)
    {
        $this->shopwarePluginBootstrapClass = $shopwarePluginBootstrapClass;
    }

    /**
     * @return Shopware_Components_Plugin_Bootstrap
     */
    public function getShopwarePluginBootstrapClass()
    {
        return $this->shopwarePluginBootstrapClass;
    }

    /**
     * @param Shopware_Components_Plugin_Bootstrap $shopwarePluginBootstrapClass
     *
     * @return InstallAbstract
     */
    public function setShopwarePluginBootstrapClass($shopwarePluginBootstrapClass)
    {
        $this->shopwarePluginBootstrapClass = $shopwarePluginBootstrapClass;

        return $this;
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->shopwarePluginBootstrapClass = null;
    }
}
