<?php
/**
 * CreateDatabase
 *
 * @package Bf\Saleschannel\Install
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Install;

use Bf\Saleschannel\Components\Gui\PluginConfigurations;
use Doctrine\ORM\Tools\SchemaTool as SchemaTool;

class CreateDatabase extends InstallAbstract
{
    /**
     * @param \Shopware_Components_Plugin_Bootstrap $shopwarePluginBootstrapClass
     */
    public function __construct($shopwarePluginBootstrapClass)
    {
        parent::__construct($shopwarePluginBootstrapClass);
    }

    /**
     * @throws \Doctrine\ORM\Tools\ToolsException
     * @return void
     */
    public function executeCreateDatabase()
    {
        $modelManager = Shopware()->Models();

        $schemaTool = new SchemaTool($modelManager);
        $schemaTool->createSchema(
            array(
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingArticles'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingDetails'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingSuppliers'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingCategories'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\Configuration'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\Scriptlogger'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingAttributes'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingCustomized'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingCurrencies'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingTranslation'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\Log'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingShops'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingFilters'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingFiltersRelations'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\ApiImportDataDetail'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\ApiImportData'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingTax'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingShippingStatus'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\ApiImportPriceHash'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingOrderAttributes'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\ApiExportOrdersHistory'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingConfiguratorGroups'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingConfiguratorOptions'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\ApiExportSeoUrls'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\SpecialPrices'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingPaymentMethodToPaymentStatus'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingOrderLinesAttributes'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingOrderExportByPaymentStatus'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingImageAttributes')
            )
        );

        /**
         * add constraint because two combined unique key dont work
         * at doctrine at the moment.
         */
        $sql = "alter table bf_mapping_categories add constraint categories_mapping unique (brickfoxID, languages_code)";
        Shopware()->Db()->query($sql);

        $pluginConfigurationClass = new PluginConfigurations();
        $pluginConfigurationClass->installDefaultPluginConfiguration();
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        parent::__destruct();
    }
}
