<?php
namespace Bf\Saleschannel\Components\Util;

/**
 * ImageHelper
 *
 * @package Bf\Saleschannel\Components\Util
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class ImageHelper
{
    /** @var ImageHelper */
    private static $instance = null;

    /** @var array */
    private $preSaveImages = array();

    /** @var bool */
    private static $preSaveIsActive = false;

    /** @var array */
    private $imageCache = array();

    /** @var array */
    private $mediaRemoveList = array();

    /** @var array */
    private $thumbnailsToGenerate = array();

    /** @var array */
    private $savedImageCache = array();

    /** @var array */
    private $savedMediaCache = array();

    private function __construct()
    {
    }

    private function __clone()
    {
    }

    /**
     * @return ImageHelper
     */
    public static function getInstance()
    {
        if(self::$instance === null)
        {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * @param $imgName
     *
     * @return null|\Shopware\Models\Article\Image
     */
    public static function imageWillBeExistsIfArticleIsSave($imgName)
    {
        $return = null;

        if(array_key_exists($imgName, self::getInstance()->getPreSaveImages()) === true)
        {
            $return = self::getInstance()->getPreSaveImages()[$imgName];
        }

        return $return;
    }

    /**
     * @return array
     */
    public function getPreSaveImages()
    {
        return $this->preSaveImages;
    }

    /**
     * @param \Shopware\Models\Article\Image $preSaveImages
     * @param \Shopware\Models\Media\Media $preSaveMedia
     * @param string $imgName
     *
     * @return ImageHelper
     */
    public function setPreSaveImages($preSaveImages, $preSaveMedia, $imgName)
    {
        $this->preSaveImages[$imgName] = array(
            0 => $preSaveImages,
            1 => $preSaveMedia
        );

        return $this;
    }

    /**
     * @return void
     */
    public function resetPreSave()
    {
        $this->preSaveImages   = array();
        self::$preSaveIsActive = false;
    }

    /**
     * @return boolean
     */
    public static function getPreSaveIsActive()
    {
        return self::$preSaveIsActive;
    }

    /**
     * @param boolean $preSaveIsActive
     *
     * @return ImageHelper
     */
    public static function setPreSaveIsActive($preSaveIsActive)
    {
        self::$preSaveIsActive = $preSaveIsActive;
    }

    /**
     * @return array
     */
    public function getImageCache()
    {
        return $this->imageCache;
    }

    /**
     * @param array $imageCache
     */
    public function setImageCache($imageCache)
    {
        $this->imageCache = $imageCache;
    }

    /**
     * @param $key
     * @param $media
     * @param $img
     *
     */
    public function addImageCacheItem($key, $media, $img) {
        $this->imageCache[$key] = array('media' => $media, 'img' => $img);
    }

    /**
     * @return array
     */
    public function getMediaRemoveList()
    {
        return $this->mediaRemoveList;
    }

    /**
     * @param array $mediaRemoveList
     */
    public function setMediaRemoveList($mediaRemoveList)
    {
        $this->mediaRemoveList = $mediaRemoveList;
    }

    public function addMediaRemoveItem($removeItem) {
        $this->mediaRemoveList[] = $removeItem;
    }

    /**
     * @return array
     */
    public function getThumbnailsToGenerate()
    {
        return $this->thumbnailsToGenerate;
    }

    /**
     * @param array $thumbnailsToGenerate
     */
    public function setThumbnailsToGenerate($thumbnailsToGenerate)
    {
        $this->thumbnailsToGenerate = $thumbnailsToGenerate;
    }

    /**
     * @param $item
     */
    public function addThumbnailsToGenerate($item) {
        $this->thumbnailsToGenerate[] = $item;
    }

    /**
     * @return array
     */
    public function getSavedImageCache()
    {
        return $this->savedImageCache;
    }

    /**
     * @param array $savedImageCache
     */
    public function setSavedImageCache($savedImageCache)
    {
        $this->savedImageCache = $savedImageCache;
    }

    /**
     * @param $item
     * @param $id
     */
    public function addSavedImageCache($id, $item) {
        $this->savedImageCache[$id] = $item;
    }

    /**
     * @return array
     */
    public function getSavedMediaCache()
    {
        return $this->savedMediaCache;
    }

    /**
     * @param array $savedMediaCache
     */
    public function setSavedMediaCache($savedMediaCache)
    {
        $this->savedMediaCache = $savedMediaCache;
    }

    /**
     * @param $id
     * @param $item
     */
    public function addSavedMediaCache($id, $item)
    {
        $this->savedMediaCache[$id] = $item;
    }
}
