<?php
namespace Bf\Saleschannel\Components\Util;

use Bf\Saleschannel\Components\Import\OrdersStatus;
use Bf\Saleschannel\Components\Import\Products;
use Bf\Saleschannel\Components\Import\Categories;
use Doctrine\ORM\ORMException;
use Exception;
use Shopware\CustomModels\BfSaleschannel\ApiImportData;
use Bf\Saleschannel\Components\Import\Manufacturers;
use Bf\Saleschannel\Components\Import\MultiShop;
use Bf\Saleschannel\Components\Import\ProductsAssignments;
use Bf\Saleschannel\Components\Import\ProductsBundles;
use Bf\Saleschannel\Components\Import\ProductsUpdate;

/**
 * ProcessAbstract
 *
 * @package Bf\Saleschannel\Components\Util
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class ProcessAbstract
{
    private $processor;

    public static $jobId;

    public static $bfApiImportDataDetail;

    public $processJob;

    /** @var int */
    public $countedErrors = 0;

    /**
     * @return void
     */
    protected function preProcess()
    {
    }

    /**
     * @return void
     */
    protected function postProcess()
    {
    }

    /**
     * @param $processType
     *
     * @return array
     */
    protected function prepareProcessListByProcessTyp($processType)
    {
        $processList        = array();
        $apiImportDataModel = new ApiImportData();
        $processOrderProductsOrProductsUpdate = ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS;

        if($processType === ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS || $processType === ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS_UPDATE)
        {
            $processOrderProductsOrProductsUpdate = $apiImportDataModel->nextJobIsProductsOrProductsUpdate();
        }

        if(strlen($processType) > 0)
        {
            switch($processType)
            {
                case ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS:
                    if($processOrderProductsOrProductsUpdate === $processType)
                    {
                        $this->setProcessJob($apiImportDataModel->getOldestJobToProcess(ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS));
                        $this->setProcessor(new Products());
                        //workaround to fix image issue
                        Shopware()->Db()->query("delete sai from s_articles_img sai left join s_media sm on sm.id = sai.media_id where sm.id is null;");
                    }

                    break;

                case ConfigManager::PROCESS_TYPE_IMPORT_MANUFACTURERS:
                    $this->setProcessJob($apiImportDataModel->getOldestJobToProcess(ConfigManager::PROCESS_TYPE_IMPORT_MANUFACTURERS));
                    $this->setProcessor(new Manufacturers());
                    break;

                case ConfigManager::PROCESS_TYPE_IMPORT_CATEGORIES:
                    $this->setProcessJob($apiImportDataModel->getOldestJobToProcess(ConfigManager::PROCESS_TYPE_IMPORT_CATEGORIES));
                    $this->setProcessor(new Categories());
                    break;

                case ConfigManager::PROCESS_TYPE_IMPORT_MULTI_SHOPS:
                    $this->setProcessJob($apiImportDataModel->getOldestJobToProcess(ConfigManager::PROCESS_TYPE_IMPORT_MULTI_SHOPS));
                    $this->setProcessor(new MultiShop());
                    break;

                case ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS_ASSIGNMENTS:
                    $this->setProcessJob($apiImportDataModel->getOldestJobToProcess(ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS_ASSIGNMENTS));
                    $this->setProcessor(new ProductsAssignments());
                    break;

                case ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS_UPDATE:
                    if($processOrderProductsOrProductsUpdate === $processType)
                    {
                        $this->setProcessJob($apiImportDataModel->getOldestJobToProcess(ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS_UPDATE));
                        $this->setProcessor(new ProductsUpdate());
                    }

                    break;

                case ConfigManager::PROCESS_TYPE_IMPORT_ORDER_STATUS:
                    $this->setProcessJob($apiImportDataModel->getOldestJobToProcess(ConfigManager::PROCESS_TYPE_IMPORT_ORDER_STATUS));
                    $this->setProcessor(new OrdersStatus());
                    break;

                case ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS_BUNDLE:
                    $this->setProcessJob($apiImportDataModel->getOldestJobToProcess(ConfigManager::PROCESS_TYPE_IMPORT_PRODUCTS_BUNDLE));
                    $this->setProcessor(new ProductsBundles());
                    break;

                default:
                    break;
            }

            if($this->getProcessJob() !== null)
            {
                $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\ApiImportDataDetail');
                /** @var array $processList */
                $processList = $repository->findBy(array('jobId' => $this->getProcessJob()->getJobId(), 'processed' => 0));

                if(count($processList) <= 0)
                {
                    $repositoryImportDataModel = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\ApiImportData');
                    /** @var \Shopware\CustomModels\BfSaleschannel\ApiImportData $importDataModel */
                    $importDataModel = $repositoryImportDataModel->findOneBy(array('jobId' => $this->getProcessJob()->getJobId()));

                    /*
                     * Fix issues with not import data who was processed but the main job is still processed 0
                     * Set this main job to processed 1 and get the new oldest Job.
                     */
                    if($importDataModel !== null)
                    {
                        $importDataModel->setProcessed(1);
                        $importDataModel->setProcessDate(date('Y-m-d H:i:s', time()));

                        Shopware()->Models()->persist($importDataModel);
                        Shopware()->Models()->flush($importDataModel);
                        Shopware()->Models()->clear();

                        $processList = $this->prepareProcessListByProcessTyp($processType);
                    }
                }

                if($processType === ConfigManager::PROCESS_TYPE_IMPORT_CATEGORIES)
                {
                    if(array_key_exists(0, $processList) === true)
                    {
                        $arrayObject = new \ArrayObject($processList);
                        $streamCopy  = $arrayObject->getArrayCopy();

                        //stream_copy_to_stream($processList[0]->getData(), $streamCopy);
                        $stream     = (string) gzuncompress(stream_get_contents($streamCopy[0]->getData()));
                        $xmlElement = simplexml_load_string($stream);
                        $this->getProcessor()->setDeleteList(null, (string) $xmlElement->Translations->Translation['lang'], (string) $xmlElement['shopsId']);
                    }
                }
            }
        }
        else
        {
            echo 'process typ needed';
        }

        return $processList;
    }

    /**
     * @param \Shopware\CustomModels\BfSaleschannel\ApiImportDataDetail $processModel
     * @param $processType
     *
     * @throws Exception
     */
    protected function process($processModel, $processType)
    {
        rewind($processModel->getData());
        $stream           = (string) gzuncompress(stream_get_contents($processModel->getData()));
        $simpleXmlElement = simplexml_load_string($stream);

        if($stream !== null && $stream !== false && strlen($stream) > 0 && $simpleXmlElement !== false)
        {
            try {
                $this->getProcessor()->process($simpleXmlElement, $processType);
            } catch (ProcessingException $processingException) {
                Shopware()->Db()->query(
                    "UPDATE bf_api_import_data_detail set processed = ?, error_codes = ?, error_message = ?, process_date = ? WHERE id = ?",
                    [
                        1,
                        $processingException->getCode(),
                        $processingException->getMessage(),
                        date('Y-m-d H:i:s'),
                        $processModel->getId()
                    ]
                );

                throw $processingException;
            }

            $processModel = $this->reloadActiveProcessModel($processModel->getId());

            if($processModel instanceof \Shopware\CustomModels\BfSaleschannel\ApiImportDataDetail)
            {
                $processModel->setProcessed(1);
                $processModel->setProcessDate(new \DateTime());
                Shopware()->Models()->persist($processModel);
            }

            try
            {
                Shopware()->Models()->flush();
                Shopware()->Models()->clear();
            }
            catch(ORMException $e)
            {
                throw new Exception($e);
            }
        }
        else
        {
            Shopware()->Db()->query(
                "
                    update bf_api_import_data_detail set processed = ?, error_codes = ?, error_message = ?, process_date = ?
                    where id = ?
                ",
                array(1, ErrorCodes::XML_INCORRECT_XML_SCHEMA_ERROR_CODE, ErrorCodes::XML_INCORRECT_XML_SCHEMA, date('Y-m-d H:i:s', time()), $processModel->getId())
            );

            throw new ProcessingException(ErrorCodes::XML_INCORRECT_XML_SCHEMA, ErrorCodes::XML_INCORRECT_XML_SCHEMA_ERROR_CODE);
        }
    }

    /**
     * @param $activeProcessId
     *
     * @return mixed
     */
    private function reloadActiveProcessModel($activeProcessId)
    {
        $repository   = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\ApiImportDataDetail');
        $processModel = $repository->findOneBy(array('id' => $activeProcessId));

        return $processModel;
    }

    /**
     * @param $jobId
     */
    protected function setProcessFlag($jobId)
    {
        if(Shopware()->Models()->isOpen() === true)
        {
            $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\ApiImportData');

            /** @var \Shopware\CustomModels\BfSaleschannel\ApiImportData $apiImportDataModel */
            $apiImportDataModel = $repository->findOneBy(array('jobId' => $jobId));

            if($apiImportDataModel !== null)
            {
                $apiImportDataModel->setProcessed(1);
                $apiImportDataModel->setProcessDate(new \DateTime());
                $apiImportDataModel->setCountedErrors($this->getCountedErrors());

                Shopware()->Models()->persist($apiImportDataModel);
                Shopware()->Models()->flush();
                Shopware()->Models()->clear();
            }
        }
        else
        {
            Shopware()->Db()->query(
                "
                    update bf_api_import_data set processed = ?, process_date = ?
                    where job_id = ?
                ",
                array(1, date('Y-m-d H:i:s', time()), $jobId)
            );

            Shopware()->Db()->query(
                "
                    update bf_api_import_data_detail set processed = ?, error_codes = ?, error_message = ?, process_date = ?
                    where job_id = ?
                ",
                array(0, ErrorCodes::ENTITY_MANAGER_CLOSED_ERROR_CODE, ErrorCodes::ENTITY_MANAGER_CLOSED, date('Y-m-d H:i:s', time()), $jobId)
            );

            Shopware()->Db()->query(
                "
                    update bf_scriptlogger set script_status = ? where id = ?
                ",
                array('error', ScriptLogger::getInstance()->getScriptLoggerModel()->getId())
            );
        }
    }

    /**
     * @return mixed
     */
    public function getProcessor()
    {
        return $this->processor;
    }

    /**
     * @param mixed $processor
     *
     * @return ProcessAbstract
     */
    public function setProcessor($processor)
    {
        $this->processor = $processor;

        return $this;
    }

    /**
     * @return mixed
     */
    public static function getJobId()
    {
        return self::$jobId;
    }

    /**
     * @param mixed $jobId
     *
     * @return ProcessAbstract
     */
    public static function setJobId($jobId)
    {
        self::$jobId = $jobId;
    }

    /**
     * @return mixed
     */
    public static function getBfApiImportDataDetail()
    {
        return self::$bfApiImportDataDetail;
    }

    /**
     * @param mixed $bfApiImportDataDetail
     *
     * @return ProcessAbstract
     */
    public static function setBfApiImportDataDetail($bfApiImportDataDetail)
    {
        self::$bfApiImportDataDetail = $bfApiImportDataDetail;
    }

    /**
     * @return mixed
     */
    public function getProcessJob()
    {
        return $this->processJob;
    }

    /**
     * @param mixed $processJob
     *
     * @return ProcessAbstract
     */
    public function setProcessJob($processJob)
    {
        $this->processJob = $processJob;

        return $this;
    }

    /**
     * @return int
     */
    public function getCountedErrors()
    {
        return $this->countedErrors;
    }

    /**
     * @param int $countedErrors
     *
     * @return ProcessAbstract
     */
    public function setCountedErrors($countedErrors)
    {
        $this->countedErrors = $countedErrors;

        return $this;
    }

    /**
     * @param $processType
     *
     * @return mixed
     */
    abstract public function prepareProcess($processType);
}
