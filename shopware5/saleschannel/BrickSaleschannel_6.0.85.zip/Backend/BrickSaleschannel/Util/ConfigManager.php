<?php

namespace Bf\Saleschannel\Components\Util;

use Shopware\CustomModels\BfSaleschannel\Configuration;
use Shopware\CustomModels\BfSaleschannel\MappingShops;

/**
 * ConfigManager
 *
 * @package Bf\Saleschannel\Components\Util
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2020 brickfox GmbH http://www.brickfox.de
 */
class ConfigManager
{
    const PROCESS_TYPE_IMPORT_PRODUCTS             = 'importProducts';
    const PROCESS_TYPE_IMPORT_CATEGORIES           = 'importCategories';
    const PROCESS_TYPE_IMPORT_MANUFACTURERS        = 'importManufacturers';
    const PROCESS_TYPE_IMPORT_PRODUCTS_ASSIGNMENTS = 'importProductsAssignment';
    const PROCESS_TYPE_IMPORT_PRODUCTS_UPDATE      = 'importProductsUpdate';
    const PROCESS_TYPE_IMPORT_ORDER_STATUS         = 'importOrdersStatus';
    const PROCESS_TYPE_IMPORT_MULTI_SHOPS          = 'importMultiShops';
    const PROCESS_TYPE_IMPORT_PRODUCTS_BUNDLE      = 'importProductsBundle';
    const UPLOADS_DIRECTORY                        = 'uploads/brickfox';

    /** @var ConfigManager */
    private static $instance = null;

    /** @var int */
    private $shopwareVersion;

    /** @var bool */
    private $initialImport = false;

    /** @var null */
    private static $useOnlyVariationsItemNumbers = null;

    /** @var string */
    private static $multiAttributesExplodeCharacter = ',';

    /**
     */
    private function __construct()
    {
    }

    /**
     */
    private function __clone()
    {
    }

    /**
     * @return ConfigManager
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance                        = new self;
            self::$useOnlyVariationsItemNumbers    = Helper::getConfigurationByKey('useOnlyVariationsItemNumbers')->getConfigurationValue();
            self::$multiAttributesExplodeCharacter = Helper::getConfigurationByKey('multiAttributesSymbol')->getConfigurationValue();
        }

        return self::$instance;
    }

    /**
     * @return null
     */
    public function getActiveShopId()
    {
        return null;
    }

    /**
     * @param bool $onlyExchange
     * @return string
     */
    public function getExchangeDirectory($onlyExchange = false)
    {
        $exchangeDirectory  = self::UPLOADS_DIRECTORY;
        $configurationModel = $this->getIncomingPath();

        if ($configurationModel !== null && $onlyExchange === false) {
            $exchangeDirectory = $configurationModel->getConfigurationValue();
            $exchangeDirectory = rtrim($exchangeDirectory, DIRECTORY_SEPARATOR);
            $exchangeDirectory = substr($exchangeDirectory, 0, strripos($exchangeDirectory, DIRECTORY_SEPARATOR));
        }

        return Shopware()->DocPath() . $exchangeDirectory . DIRECTORY_SEPARATOR;
    }

    /**
     * @return string
     */
    public function getIncomingDestinationDirectory()
    {
        $destinationPath    = 'in';
        $configurationModel = $this->getIncomingPath();

        if ($configurationModel !== null) {
            $destinationPath = $configurationModel->getConfigurationValue();
            $destinationPath = rtrim($destinationPath, DIRECTORY_SEPARATOR);
            $destinationPath = substr(strrchr($destinationPath, DIRECTORY_SEPARATOR), 1);
        }

        return $destinationPath . DIRECTORY_SEPARATOR;
    }

    /**
     * @return string
     */
    public function getImagesPathDirectory()
    {
        $destinationPath    = 'image';
        $configurationModel = $this->getImagePath();

        if ($configurationModel !== null) {
            $destinationPath = $configurationModel->getConfigurationValue();
            $destinationPath = rtrim($destinationPath, DIRECTORY_SEPARATOR);
        }

        return $destinationPath . DIRECTORY_SEPARATOR;
    }

    /**
     * @return string
     */
    public function getOutgoingDestinationDirectory()
    {
        $destinationPath    = 'out';
        $configurationModel = $this->getOutgoingPath();

        if ($configurationModel !== null) {
            $destinationPath = $configurationModel->getConfigurationValue();
            $destinationPath = rtrim($destinationPath, DIRECTORY_SEPARATOR);
            $destinationPath = substr(strrchr($destinationPath, DIRECTORY_SEPARATOR), 1);
        }

        return $destinationPath . DIRECTORY_SEPARATOR;
    }

    /**
     * @return bool
     */
    public function getlogIsActive()
    {
        return $this->getBoolConfigurationByKey('logging');
    }

    /**
     * @return string
     */
    public function getLogPath()
    {
        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'logPath']);

        return Shopware()->DocPath() . $configurationModel->getConfigurationValue();
    }

    /**
     * @return Configuration
     */
    private function getIncomingPath()
    {
        return Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'incomingPath']);
    }

    /**
     * @return Configuration
     */
    private function getOutgoingPath()
    {
        return Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'outgoingPath']);
    }

    /**
     * @return string
     */
    public function getCommentField()
    {
        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'commentId']);

        return $configurationModel->getConfigurationValue();
    }

    /**
     * @return string
     */
    public function getEmailNotificationCode()
    {
        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'emailNotificationCode']);

        return $configurationModel->getConfigurationValue();
    }

    /**
     * @return string
     */
    public function getCreateDateCode()
    {
        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'createDateCode']);

        return $configurationModel->getConfigurationValue();
    }

    /**
     * @return string
     */
    public function getStrikeThroughPriceRules()
    {
        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'strikeThroughPriceRulesId']);

        return $configurationModel->getConfigurationValue();
    }

    /**
     * @return string
     */
    public function getKeepOnImportAttributes()
    {
        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'keepAttributesOnImport']);

        return $configurationModel->getConfigurationValue();
    }

    /**
     * @return string
     */
    public function getCarrierAttributeFieldName()
    {
        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'carrierAttributeFieldName']);

        return $configurationModel->getConfigurationValue();
    }

    /**
     * @return string
     */
    public function getIgnoreDelivery()
    {
        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'ignoreDelivery']);

        return $configurationModel->getConfigurationValue();
    }

    /**
     * @return Configuration
     */
    private function getImagePath()
    {
        return Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'imagePath']);
    }

    /**
     * @return Configuration
     */
    public function getCleanTimer()
    {
        return Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'cleanApiAfterDays']);
    }

    /**
     * @return Configuration
     */
    public function getLogCleanTimer()
    {
        return Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'cleanBfLogAfterDays']);
    }

    /**
     * @return Configuration
     */
    public function getScriptloggerCleanTimer()
    {
        return Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'cleanBfScriptloggerAfterDays']);
    }

    /**
     * @return Configuration
     */
    public function getReleaseDateFromAttribute()
    {
        return Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'releaseDateFromAttribute']);
    }

    /**
     * @return Configuration
     */
    public function getShippingFreeFromAttribute()
    {
        return Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'shippingFreeFromAttribute']);
    }

    /**
     * @return bool
     */
    public function getIgnoreImportMultiShopCategories()
    {
        return $this->getBoolConfigurationByKey('ignoreCategoriesImportFromMultiShop');
    }

    /**
     * @return string
     */
    public function getPackageOrMeasurementsNode()
    {
        $return = 'Package';

        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'packageOrMeasurementId']);

        if ((int)$configurationModel->getConfigurationValue() === 1) {
            $return = 'ItemMeasurements';
        }

        return $return;
    }

    /**
     * @return bool
     */
    public function getCategoryDenormalization()
    {
        return $this->getBoolConfigurationByKey('categoryDenormalization');
    }

    /**
     * @return bool
     */
    public function getIgnoreImageInformation()
    {
        return $this->getBoolConfigurationByKey('ignoreImagesImport');
    }

    /**
     * @return bool
     */
    public function keepMissingImagesInImport()
    {
        return $this->getBoolConfigurationByKey('keepMissingImagesInImport');
    }

    /**
     * @return bool
     */
    public function getImageMappingDiffsOptionsStatus()
    {
        return $this->getBoolConfigurationByKey('imageMappingDiffsOptionsStatus');
    }

    /**
     * @return array
     */
    public function getImageMappingDiffsOptions()
    {
        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'imageMappingDiffsOptions']);

        return explode(',', $configurationModel->getConfigurationValue());
    }

    /**
     * @return bool
     */
    public function isReleaseDateFromAttribute()
    {
        $return = false;

        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'releaseDateFromAttribute']);

        if (strlen($configurationModel->getConfigurationValue()) > 0 && $configurationModel->getConfigurationValue() !== null) {
            $return = true;
        }

        return $return;
    }

    /**
     * @return bool
     */
    public function isShippingFreeFromAttribute()
    {
        $return = false;

        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'shippingFreeFromAttribute']);

        if (strlen($configurationModel->getConfigurationValue()) > 0 && $configurationModel->getConfigurationValue() !== null) {
            $return = true;
        }

        return $return;
    }

    /**
     * @return bool
     */
    public function getReAssignVariationsAllowed()
    {
        return $this->getBoolConfigurationByKey('allowedReAssignVariations');
    }

    /**
     * @return bool
     */
    public function getSortOrderAttributes()
    {
        return $this->getBoolConfigurationByKey('sortOrderAttributes');
    }

    /**
     * @return bool
     */
    public function getCostChangingAsCoupon()
    {
        return $this->getBoolConfigurationByKey('costChangingAsCoupon');
    }

    /**
     * @return string
     */
    public function getServerProtocol()
    {
        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'serverProtocol']);

        return $configurationModel->getConfigurationValue() === 'true' ? 'https://' : 'http://';
    }

    /**
     * @param $shopsId
     */
    public function getIsMasterShopByShopsMapping($shopsId)
    {
        $isMasterShop = false;
        $swShopsId    = 0;

        if ($shopsId !== null) {
            /** @var MappingShops $mappingShopsModel */
            $mappingShopsModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingShops')->findOneBy(['brickfoxId' => $shopsId, 'isMasterShop' => 1]);

            if ($mappingShopsModel !== null) {
                $isMasterShop = true;
                $swShopsId    = $mappingShopsModel->getShopwareId();
            }
        }

        Helper::$isMasterShop  = $isMasterShop;
        Helper::$masterShopsId = $swShopsId;
    }

    /**
     * @return string
     */
    public function getExportTaxesForNetOrders()
    {
        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'exportTaxesForNetOrders']);

        return $configurationModel->getConfigurationValue();
    }

    /**
     * @return string
     */
    public function getImageDescriptionAttributeName()
    {
        /** @var Configuration $configurationModel */
        $configurationModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration')->findOneBy(['configurationKey' => 'imageDescriptionAttributeName']);

        return $configurationModel->getConfigurationValue();
    }

    /**
     * @return int
     */
    public function getShopwareVersion()
    {
        return $this->shopwareVersion;
    }

    /**
     * @param int $shopwareVersion
     * @return ConfigManager
     */
    public function setShopwareVersion($shopwareVersion)
    {
        $this->shopwareVersion = $shopwareVersion;

        return $this;
    }

    /**
     * @return string
     */
    public static function getUseOnlyVariationsItemNumbers()
    {
        return self::$useOnlyVariationsItemNumbers;
    }

    /**
     * @return string
     */
    public static function getMultiAttributesExplodeCharacter()
    {
        return self::$multiAttributesExplodeCharacter;
    }

    /**
     * @return boolean
     */
    public function getInitialImport()
    {
        return $this->initialImport;
    }

    /**
     * @param boolean $initialImport
     * @return ConfigManager
     */
    public function setInitialImport($initialImport)
    {
        $this->initialImport = $initialImport;

        return $this;
    }

    /**
     * @return bool
     */
    public function getDisableBfPriceUpdates()
    {
        return $this->getBoolConfigurationByKey('disableBfPriceUpdates');
    }

    /**
     * @return string|null
     */
    public function getExcludeCustomerGroupAttributeFieldCode() {
        return $this->getStringConfigurationByKey('excludeCustomerGroupAttributeFieldCode');
    }


    /**
     * @return bool
     */
    public function getEnableEmailNotificationsOnError()
    {
        return $this->getBoolConfigurationByKey('enableEmailNotificationsOnError');
    }

    /**
     * @return array
     */
    public function getEmailNotificationErrorCodes()
    {
        $repository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration');

        /** @var \Shopware\CustomModels\BfSaleschannel\Configuration $configurationModel */
        $configurationModel = $repository->findOneBy(['configurationKey' => 'emailNotificationErrorCodes']);

        if(isset($configurationModel)) {
            return array_map(function ($item) {
                return trim($item);
            }, explode(',', $configurationModel->getConfigurationValue()));
        }

        return [];
    }

    /**
     * @return array
     */
    public function getEmailNotificationReceivers()
    {
        $repository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration');

        /** @var \Shopware\CustomModels\BfSaleschannel\Configuration $configurationModel */
        $configurationModel = $repository->findOneBy(['configurationKey' => 'emailNotificationReceivers']);

        if(isset($configurationModel)) {
            return array_map(function ($item) {
                return trim($item);
            }, explode(',', $configurationModel->getConfigurationValue()));
        }

        return [];
    }

    /**
     * @return bool
     */
    public function getIgnoreLongDescription()
    {
        return $this->getBoolConfigurationByKey('ignoreLongDescription');
    }

    /**
     * @return array|string[]
     */
    public function getSurchargeCodes()
    {
        $surchargeCodes = [];
        $repository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration');

        /** @var \Shopware\CustomModels\BfSaleschannel\Configuration $configurationModel */
        $configurationModel = $repository->findOneBy(['configurationKey' => 'surchargeCodes']);

        if (isset($configurationModel) === true) {
            if(empty($configurationModel->getConfigurationValue()) === false) {
                $surchargeCodes = array_map(function ($code) {
                    return trim($code);
                }, explode(',', $configurationModel->getConfigurationValue()));
            }
        }

        return $surchargeCodes;
    }

    /**
     * @return bool
     */
    public function getPreventPriceModelsRewrite()
    {
        return $this->getBoolConfigurationByKey('preventPriceModelsRewrite');
    }

    /**
     * @return string
     */
    public function getSavingOptionCodeAttributeFieldName()
    {
        return $this->getStringConfigurationByKey('savingOptionCodeAttributeFieldName');
    }

    /**
     * @param string $configurationKey
     * @return string
     */
    private function getStringConfigurationByKey($configurationKey)
    {
        $repository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration');

        /** @var \Shopware\CustomModels\BfSaleschannel\Configuration $configurationModel */
        $configurationModel = $repository->findOneBy(['configurationKey' => $configurationKey]);

        if($configurationModel !== null) {
            return $configurationModel->getConfigurationValue();
        }

        return '';
    }

    /**
     * @return bool
     */
    private function getBoolConfigurationByKey($configurationKey)
    {
        $repository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\Configuration');

        /** @var \Shopware\CustomModels\BfSaleschannel\Configuration $configurationModel */
        $configurationModel = $repository->findOneBy(['configurationKey' => $configurationKey]);

        if (isset($configurationModel) === true) {
            return filter_var($configurationModel->getConfigurationValue(), FILTER_VALIDATE_BOOLEAN);
        }

        return false;
    }
}