<?php
namespace Bf\Saleschannel\Components\Util;

/**
 * Iterator
 *
 * @package Bf\Saleschannel\Components\Util
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Iterator implements \Iterator, \Countable
{
    /** @var null */
    protected $dataStore = null;

    /**
     * Iterator constructor.
     *
     * @param array $data
     */
    public function __construct(array $data)
    {
        if(count($data) > 0)
        {
            $this->dataStore = $data;
        }
    }

    /**
     * @return mixed
     */
    public function key()
    {
        return key($this->dataStore);
    }

    /**
     * @return mixed
     */
    public function current()
    {
        return current($this->dataStore);
    }

    /**
     * @return mixed
     */
    public function next()
    {
        return next($this->dataStore);
    }

    /**
     * @return mixed
     */
    public function rewind()
    {
        return reset($this->dataStore);
    }

    /**
     * @return int
     */
    public function count()
    {
        return count($this->dataStore);
    }

    /**
     * @return bool
     */
    public function valid()
    {
        return (bool) $this->current();
    }

    /**
     * @param $key
     *
     * @return mixed|null
     */
    public function remove($key)
    {
        if(!isset($this->dataStore[$key]) && !array_key_exists($key, $this->dataStore))
        {
            return null;
        }

        $removed = $this->dataStore[$key];
        unset($this->dataStore[$key]);

        return $removed;
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->dataStore = null;
    }

    /**
     * @return null|array
     */
    public function getDataStore()
    {
        return $this->dataStore;
    }

    /**
     * @param null $dataStore
     *
     * @return Iterator
     */
    public function setDataStore($dataStore)
    {
        $this->dataStore = $dataStore;

        return $this;
    }
}
