<?php

namespace Bf\Saleschannel\Components\Util;

use ZipArchive;

/**
 * FileManager
 *
 * @package Bf\Saleschannel\Components\Util
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class FileManager
{
    const WAITING_TIME_IMPORT                = 120;
    const FILENAME_BASE_CATEGORIES           = 'Categories';
    const FILENAME_BASE_MANUFACTURERS        = 'Manufacturers';
    const FILENAME_BASE_PRODUCTS             = 'Products';
    const FILENAME_BASE_PRODUCTS_UPDATE      = 'ProductsUpdate';
    const FILENAME_BASE_PRODUCTS_ASSIGNMENTS = 'ProductsAssignments';
    const FILENAME_BASE_PRODUCTS_BUNDLES     = 'ProductsBundles';
    const FILENAME_BASE_ORDERS               = 'Orders';
    const FILENAME_BASE_ORDERS_STATUS        = 'Orderstatus';
    const FILENAME_BASE_SUB_MULTI_SHOP       = 'Multishop';

    const FILENAME_DELIMITER = '_';

    const GZ_FILE_EXTENSION        = '.gz';
    const PROCESSED_DIRECTORY_NAME = 'processed';
    const SUCCESS_DIRECTORY_NAME   = 'success';

    /** @var FileManager */
    private static $instance = null;

    private function __construct()
    {
    }

    private function __clone()
    {
    }

    /**
     * getInstance.
     *
     * @return FileManager
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * @param string $filenameBase
     *
     * @return string
     */
    public static function generateFilename($filenameBase)
    {
        return $filenameBase . '_' . date('Ymd_His') . '.xml';
    }

    /**
     * @param string $importFilenameBase
     *
     * @return array
     */
    public function getImportFiles($importFilenameBase)
    {
        $result           = array();
        $exchangeXMLFiles = $this->getExchangeXMLFiles();

        if (is_array($exchangeXMLFiles) === true) {
            foreach ($exchangeXMLFiles as $exchangeXMLFile) {
                $exchangeXMLFilename = pathinfo($exchangeXMLFile, PATHINFO_FILENAME);
                list($exchangeXMLFilenameBase, $exchangeXMLFilenameCreation) = explode(self::FILENAME_DELIMITER, $exchangeXMLFilename, 2);

                if ($exchangeXMLFilenameBase == $importFilenameBase) {
                    if ($importFilenameBase === self::FILENAME_BASE_ORDERS_STATUS) {
                        if (filemtime($exchangeXMLFile) <= (time() - self::WAITING_TIME_IMPORT)) {
                            $useFile = true;
                        } else {
                            $useFile = false;
                        }
                    } else {
                        $useFile = true;
                    }

                    //                    // more than one files found, so compare dates and use oldest
                    //                    if(isset($result[$importFilenameBase]) === true)
                    //                    {
                    //                        $exchangeXMLFileCreationDate = $this->getTimestamp($exchangeXMLFilenameCreation);
                    //                        $exchangeXMLFilenameCompare  = pathinfo($result[$importFilenameBase], PATHINFO_FILENAME);
                    //                        list(, $exchangeXMLFilenameCreationCompare) = explode(self::FILENAME_DELIMITER, $exchangeXMLFilenameCompare, 2);
                    //                        $exchangeXMLFileCreationDateCompare = $this->getTimestamp($exchangeXMLFilenameCreationCompare);
                    //
                    //                        $useFile = $exchangeXMLFileCreationDate < $exchangeXMLFileCreationDateCompare ? true : false;
                    //                    }

                    if ($useFile === true) {
                        $result[$importFilenameBase] = $exchangeXMLFile;
                    } else {
                        continue;
                    }

                    break;
                }
            }
        }

        return $result;
    }

    /**
     * createExportFile.
     *
     * @param string $filename file name
     *
     * @return string file location
     */
    public function createExportFile($filename)
    {
        $fileLocation = $this->getExchangeShopPath() . $filename;
        $fileHandle   = fopen($fileLocation, 'w');
        fclose($fileHandle);

        return $fileLocation;
    }

    /**
     * renameExportFile.
     *
     * @param string $oldFilename old filename
     * @param string $newFilename new filename
     */
    public function renameExportFile($oldFilename, $newFilename)
    {
        $oldFileLocation = $this->getExchangeShopPath() . $oldFilename;
        $newFileLocation = $this->getExchangeShopPath() . $newFilename;
        if (true === file_exists($oldFileLocation)) {
            rename($oldFileLocation, $newFileLocation);
        }
    }

    /**
     * @param $fileLocation
     * @param string $destinationDirectory
     *
     * @return void
     */
    public function moveImportFile($fileLocation, $destinationDirectory = self::PROCESSED_DIRECTORY_NAME)
    {
        $extendedDestinationPath = date('Y', time()) . DIRECTORY_SEPARATOR . date('m', time()) . DIRECTORY_SEPARATOR . date('d', time());
        $destinationPath         = ConfigManager::getInstance()->getExchangeDirectory() . $destinationDirectory . DIRECTORY_SEPARATOR . $extendedDestinationPath;

        if (file_exists($fileLocation) === true) {
            Helper::checkPath($destinationPath, true);
        }

        $fileName = substr(strrchr($fileLocation, DIRECTORY_SEPARATOR), 1);
        $this->zipper($destinationPath, true, $fileLocation, $fileName);

    }

    /**
     * @param $fileLocation
     * @param string $destinationDirectory
     *
     * @return void
     */
    public function moveExportFile($fileLocation, $destinationDirectory = self::SUCCESS_DIRECTORY_NAME)
    {
        $extendedDestinationPath = date('Y', time()) . DIRECTORY_SEPARATOR . date('m', time()) . DIRECTORY_SEPARATOR . date('d', time());
        $destinationPath         = ConfigManager::getInstance()->getExchangeDirectory(true) . $destinationDirectory . DIRECTORY_SEPARATOR . $extendedDestinationPath;

        if (file_exists($fileLocation) === true) {
            Helper::checkPath($destinationPath, true);
        }

        $fileName = substr(strrchr($fileLocation, DIRECTORY_SEPARATOR), 1);
        $this->zipper($destinationPath, false, $fileLocation, $fileName);

    }

    /**
     * @param $shopName
     *
     * @return string
     */
    public function getExportDestinationPath($shopName)
    {
        /** @var \Shopware\CustomModels\BfSaleschannel\Configuration $configurationModel */
        $configurationModel = Helper::getConfigurationByKey('outgoingPath');
        $destinationPath    = $configurationModel->getConfigurationValue() . DIRECTORY_SEPARATOR . $shopName . DIRECTORY_SEPARATOR . 'Orders_' . date('Ymd_His', time()) . '.xml';

        return $destinationPath;
    }

    /**
     * @param $destinationPath
     * @param bool $deleteAfterZip
     * @param $fileLocation
     * @param $fileName
     *
     * @return void
     */
    public function zipper($destinationPath, $deleteAfterZip = false, $fileLocation = null, $fileName = null)
    {
        if ($fileLocation !== null && $fileName !== null) {
            $gzFile = $destinationPath . DIRECTORY_SEPARATOR . $fileName . self::GZ_FILE_EXTENSION;
        } else {
            $gzFile       = $destinationPath . self::GZ_FILE_EXTENSION;
            $fileLocation = $destinationPath;
        }

        $fp = gzopen($gzFile, 'w9');
        gzwrite($fp, file_get_contents($fileLocation));
        gzclose($fp);

        if ($deleteAfterZip === true) {
            if (file_exists($fileLocation) === true) {
                unlink($fileLocation);
            }
        }
    }

    /**
     * @return array
     */
    private function getExchangeXMLFiles()
    {
        $importDir = $this->getImportDirectory();

        return glob($importDir . '*.xml');
    }

    /**
     * @return string
     */
    private function getImportDirectory()
    {
        $importDirectory = $this->getExchangeShopPath() . $this->getIncomingDestinationDirectory();
        $this->checkDir($importDirectory);

        return $importDirectory;
    }

    /**
     * getExchangeShopDirectoryLocation.
     *
     * @return string exchange shop directory location
     */
    private function getExchangeShopPath()
    {
        $exchangeShopDirectoryLocation = $this->getExchangeDirectory();
        $exchangeShopDirectory         = $this->getExchangeShopDirectory();

        if (is_null($exchangeShopDirectory) === false && strlen($exchangeShopDirectory) > 0) {
            $exchangeShopDirectoryLocation .= $exchangeShopDirectory . DIRECTORY_SEPARATOR;
        }

        return $exchangeShopDirectoryLocation;
    }

    /**
     * getExchangeDirectory.
     *
     * @return string exchange directory
     */
    private function getExchangeDirectory()
    {
        return ConfigManager::getInstance()->getExchangeDirectory();
    }

    /**
     * getExchangeShopDirectory,
     *
     * @return string exchange shop directory
     */
    private function getExchangeShopDirectory()
    {
        return ConfigManager::getInstance()->getActiveShopId();
    }

    /**
     * @return string
     */
    private function getIncomingDestinationDirectory()
    {
        return ConfigManager::getInstance()->getIncomingDestinationDirectory();
    }

    /**
     * getTimestamp.
     * Pay attention:
     * Currently PHP version 5.2.6 is in use.
     * For that reason it's not possible to use:
     * DateTime::createFromFormat('Ymd_His', $timestampString)
     *
     * @param string $timestampString timestamp string
     *
     * @return integer timestamp
     */
    private function getTimestamp($timestampString)
    {
        $ftime = strptime($timestampString, 'Ymd_His');

        return mktime($ftime['tm_hour'], $ftime['tm_min'], $ftime['tm_sec'], 1, $ftime['tm_yday'] + 1, $ftime['tm_year'] + 1900);
    }

    private function checkDir($importDirectory)
    {
        if (is_dir($importDirectory) === false) {
            mkdir($importDirectory, 0777, true);
        }
    }

    /**
     * @param int $countOfMonth
     */
    public function recursiveDeleteFiles($countOfMonth = 2)
    {
        $root        = Shopware()->DocPath();
        $destination = 'uploads/brickfox/';

        $fileDirs = array(
            'success/',
            'processed/',
            'processedError/',
            'failure/',
            'logs/'
        );

        foreach ($fileDirs as $dir) {
            $targetPath = $root . $destination . $dir . date('Y', time());

            Helper::checkPath($targetPath, true);

            $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($targetPath));

            /** @var \SplFileInfo $item */
            foreach ($iterator as $item) {
                if ($item->isFile() && $item->getMTime() < strtotime(date('Y-m', strtotime('-' . $countOfMonth . ' month')) . '-01')) {
                    unlink($item->getPath() . DIRECTORY_SEPARATOR . $item->getFilename());
                }
            }
        }
    }
}
