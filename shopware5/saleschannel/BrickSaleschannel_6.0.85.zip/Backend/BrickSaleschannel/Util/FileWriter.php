<?php
namespace Bf\Saleschannel\Components\Util;

use Exception;

/**
 * Class FileWriter
 *
 * @package Bf\Saleschannel\Components\Util
 */
class FileWriter
{
    /** @var FileWriter */
    private static $instance = null;

    /** @var array */
    public static $xmlElements = array();

    /** @var int */
    public static $internalArrayKeyCounter = 0;

    public function __construct()
    {
    }

    public function __clone()
    {
    }

    /**
     * @return FileWriter
     */
    public static function getInstance()
    {
        if(self::$instance === null)
        {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * @param \XMLWriter $xmlWriter
     * @param array      $array
     * @param string     $nodeName
     *
     * @throws Exception
     */
    public static function fromArray(\XMLWriter $xmlWriter, array $array = array(), $nodeName = '')
    {
        if(self::isValidBeginTagName($nodeName) === true)
        {
            $tag = preg_replace('/[-0-9]*/', '', $nodeName);
            $xmlWriter->startElement($tag);
        }
        elseif(strlen($nodeName) > 0)
        {
            $xmlWriter->startElement($nodeName);
        }

        if($nodeName === 'Currencies')
        {
            $xmlWriter->writeAttribute('net', 'false');
        }

        if(is_array($array) === true)
        {
            //attribtues first
            if(array_key_exists('@attributes', $array) === true)
            {
                foreach($array['@attributes'] as $attributesName => $attributeValue)
                {
                    if(self::isValidTagName($attributesName) === false)
                    {
                        echo 'in valid Attributes Name: ' . $attributesName;
                        throw new Exception('Can not write XML-File with illegal characters. Please contact brickfox GmbH.');
                    }
                    $xmlWriter->writeAttribute($attributesName, self::bool2str($attributeValue));
                }
                unset($array['@attributes']); // remove the key from the array once done.
            }

            if(array_key_exists('@value', $array) === true)
            {
                if(strlen($array['@value']) > 0)
                {
                    $xmlWriter->text(self::bool2str($array['@value']));
                }
                unset($array['@value']);
            }
            elseif(array_key_exists('@cdata', $array) === true)
            {
                if(strlen($array['@cdata']) > 0)
                {
                    $xmlWriter->writeCdata(self::bool2str($array['@cdata']));
                }
                unset($array['@cdata']);
            }
        }

        if(is_array($array) === true)
        {
            foreach($array as $node => $value)
            {
                if(self::isValidTagName($node) === false)
                {
                    echo 'in valid Node Name: ' . $node;
                    throw new Exception('Can not write XML-File with illegal characters. Please contact brickfox GmbH.');
                }

                if(is_array($value) === true && is_numeric(key($value)))
                {
                    $xmlWriter->startElement($node);

                    if($node === 'Currencies')
                    {
                        $xmlWriter->writeAttribute('net', self::bool2str(false));
                    }

                    // MORE THAN ONE NODE OF ITS KIND;
                    // if the new array is numeric index, means it is array of nodes of the same kind
                    // it should follow the parent key name
                    foreach($value as $n => $v)
                    {
                        self::getInstance()->fromArray($xmlWriter, $v);
                    }
                }
                else
                {
                    // ONLY ONE NODE OF ITS KIND
                    self::getInstance()->fromArray($xmlWriter, $value, $node);
                }

                unset($array[$node]);
                $xmlWriter->endElement();
            }
        }

        self::$xmlElements = array();
    }

    /**
     * @return array
     */
    public static function getXmlElements()
    {
        return self::$xmlElements;
    }

    /**
     * @param array $xmlElements
     *
     * @return FileWriter
     */
    public static function setXmlElements($xmlElements)
    {
        self::$xmlElements = $xmlElements;
    }

    /**
     * Get string representation of boolean value
     *
     * @param $v
     *
     * @return string
     */
    private static function bool2str($v)
    {
        //convert boolean to text value.
        $v = $v === true ? 'true' : $v;
        $v = $v === false ? 'false' : $v;

        return $v;
    }

    /**
     * Check if the tag name or attribute name contains illegal characters
     * Ref: http://www.w3.org/TR/xml/#sec-common-syn
     *
     * @param $tag
     *
     * @return bool
     */
    public static function isValidTagName($tag)
    {
        $pattern = '/^[a-z_]+[a-z0-9\:\-\.\_]*[^:]*$/i';

        return preg_match($pattern, $tag, $matches) && $matches[0] == $tag;
    }

    /**
     * @param $tag
     *
     * @return bool
     */
    public static function isValidBeginTagName($tag)
    {
        $pattern = '/[A-Za-z-]*[0-9]*/';

        return preg_match($pattern, $tag, $matches) && $matches[0] == $tag;
    }
}
