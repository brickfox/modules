<?php

namespace Bf\Saleschannel\Components\Util;

class ProcessingException extends \Exception
{
}