<?php
namespace Bf\Saleschannel\Components\Util;

use Bf\Saleschannel\Components\Process;
use Shopware\CustomModels\BfSaleschannel\Log;
use SimpleXMLElement;

/**
 * LogManager
 *
 * @package Bf\Saleschannel\Components\Util
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class LogManager
{
    CONST LEVEL_DEBUG       = 1;
    CONST LEVEL_INFO        = 2;
    CONST LEVEL_WARNING     = 3;
    CONST LEVEL_ERROR       = 4;
    const MODE_NEW          = 'Added';
    const MODE_UPDATE       = 'Update';
    const MODE_DISABLE      = 'Deactivate';
    const CLEAR_LOG_ENTRIES = 'LOG_ENTRIES';

    /** @var LogManager */
    private static $instance = null;

    /** @var null */
    private static $fileName = null;

    /** @var null */
    public static $destinationPathWithFileName = null;

    /** @var bool */
    public static $hasError = false;

    private function __construct()
    {
    }

    private function __clone()
    {
    }

    /**
     * @return LogManager
     */
    public static function getInstance()
    {
        if(self::$instance === null)
        {
            self::$instance = new self;
            self::$fileName = '_Log_' . date('Ymd_His', time()) . '.txt';
        }

        return self::$instance;
    }

    /**
     * @param $status
     * @param $action
     * @param $message
     * @param $user
     * @param $type
     * @param $internalId
     * @param string $errorCode
     * @param bool $exception
     * @param bool $clearEntity
     *
     * @throws \Exception
     * @return void
     */
    public static function writeLogForGui($status, $action, $message, $user, $type, $internalId, $errorCode = '000', $exception = true, $clearEntity = true)
    {
        //lowers the memory peek
        $conn = Shopware()->Models()->getConnection();
        $conn->getConfiguration()->setSQLLogger(null);

        $result = Shopware()->Db()->fetchRow(
            "
            select * from `bf_api_import_data_detail`
            where `job_id` = ? and `id` = ?
            ",
            array(Process::$jobId, Process::$bfApiImportDataDetail)
        );

        $errorCode = $result['error_codes'] . ' , ' . $errorCode;
        $errorMsg  = $result['error_message'] . '' . $message;

        Shopware()->Db()->query(
            "
                update `bf_api_import_data_detail`
                set `error_codes` = ?, `error_message` = ?, `brickfox_id` = ?, `processed` = ?, `process_date` = ?
                where `job_id` = ? and `id` = ?
            ",
            array($errorCode, $errorMsg, $internalId, 1, date('Y-m-d H:i:s', time()), Process::$jobId, Process::$bfApiImportDataDetail)
        );

        if($clearEntity === true)
        {
            Shopware()->Models()->clear();
        }

        if($exception === true)
        {
            Exceptions::throwException($message);
        }
    }

    /**
     * @param string $message
     * @param null $entity
     *
     * @return bool
     */
    public static function logDebug($message, $entity = null)
    {
        return self::writeLog($message, self::LEVEL_DEBUG, $entity);
    }

    /**
     * @param string $message
     *
     * @return bool
     */
    public static function logWarning($message)
    {
        return self::writeLog($message, self::LEVEL_WARNING);
    }

    /**
     * @param string $message
     *
     * @return bool
     */
    public static function logError($message)
    {
        return self::writeLog($message, self::LEVEL_ERROR);
    }

    /**
     * @param \Exception $e
     * @param null $entity
     *
     * @return bool
     */
    public static function logException(\Exception $e, $entity = null)
    {
        return self::writeLog($e->getMessage(), self::LEVEL_ERROR, $entity);
    }

    /**
     * @param string $message
     * @param int $level
     * @param string $entity
     *
     * @return bool
     */
    private static function writeLog($message, $level, $entity = 'Default')
    {
        if(ConfigManager::getInstance()->getlogIsActive() === true)
        {
            if(self::$fileName === null)
            {
                self::$fileName = '_Log_' . date('Ymd_His', time()) . '.txt';
            }

            if($entity !== null)
            {
                $destinationPath = ConfigManager::getInstance()->getLogPath() . DIRECTORY_SEPARATOR . date('Y', time()) . DIRECTORY_SEPARATOR . date('m', time()) .
                                   DIRECTORY_SEPARATOR . date('d', time()) . DIRECTORY_SEPARATOR;

                Helper::checkPath($destinationPath, true);
                file_put_contents($destinationPath . $entity . self::$fileName, $message . "\r\n", FILE_APPEND);

                if(self::getInstance()->getDestinationPathWithFileName() === null)
                {
                    self::$destinationPathWithFileName = $destinationPath . $entity . self::$fileName;
                }
            }
        }

        return true;
    }

    /**
     * @return void
     */
    public static function zipLogFiles()
    {
        FileManager::getInstance()->zipper(self::getInstance()->getDestinationPathWithFileName(), true);
    }

    /**
     * @return null|string
     */
    public static function getDestinationPathWithFileName()
    {
        return self::$destinationPathWithFileName;
    }

    /**
     * @return boolean
     */
    public static function getHasError()
    {
        return self::$hasError;
    }

    /**
     * @param boolean $hasError
     *
     * @return LogManager
     */
    public static function setHasError($hasError)
    {
        self::$hasError = $hasError;
    }
}
