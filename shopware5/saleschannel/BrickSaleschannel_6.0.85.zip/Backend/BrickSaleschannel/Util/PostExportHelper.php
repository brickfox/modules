<?php
/**
 * PostExportHelper
 *
 * @package Bf\Saleschannel\Components\Util
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Util;

use Exception;

class PostExportHelper
{
    private $simpleXmlElement;
    private $xmlReader;

    /** @var string */
    private $pathToFile = '';

    /**
     * PostExportHelper constructor.
     *
     * @param $pathToExportFile
     */
    public function __construct($pathToExportFile)
    {
        if(strlen($pathToExportFile) > 0)
        {
            $this->pathToFile = $pathToExportFile;
            $this->xmlReader  = new \XMLReader();
        }
    }

    public function postProcessExportFile()
    {
        //todo xml reader implemantation
        $this->getXmlReader()->open($this->getPathToFile(), null, LIBXML_NOCDATA);

        while($this->getXmlReader()->read() === true)
        {
            try
            {
                if($this->getXmlReader()->nodeType === \XMLReader::ELEMENT && $this->getXmlReader()->depth === 1)
                {
                    
                }
            }
            catch(Exception $e)
            {
                echo '<pre>';
                print_r($e->getTraceAsString());
                echo '</pre>';
            }
        }
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->simpleXmlElement = null;
        $this->pathToFile       = null;
        $this->xmlReader        = null;
    }

    /**
     * @return mixed
     */
    public function getSimpleXmlElement()
    {
        return $this->simpleXmlElement;
    }

    /**
     * @param mixed $simpleXmlElement
     *
     * @return PostExportHelper
     */
    public function setSimpleXmlElement($simpleXmlElement)
    {
        $this->simpleXmlElement = $simpleXmlElement;

        return $this;
    }

    /**
     * @return \XMLReader
     */
    public function getXmlReader()
    {
        return $this->xmlReader;
    }

    /**
     * @param \XMLReader $xmlReader
     *
     * @return PostExportHelper
     */
    public function setXmlReader($xmlReader)
    {
        $this->xmlReader = $xmlReader;

        return $this;
    }

    /**
     * @return string
     */
    public function getPathToFile()
    {
        return $this->pathToFile;
    }

    /**
     * @param string $pathToFile
     *
     * @return PostExportHelper
     */
    public function setPathToFile($pathToFile)
    {
        $this->pathToFile = $pathToFile;

        return $this;
    }
}
