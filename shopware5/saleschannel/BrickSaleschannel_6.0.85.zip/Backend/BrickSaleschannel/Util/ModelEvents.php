<?php
/**
 * ModelEvents
 *
 * @package Bf\Saleschannel\Components\Util
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Util;

use Exception;
use Bf\Saleschannel\Components\Resources\Configurator\Configurator as BfConfigurator;

class ModelEvents
{
    /** @var null */
    private $entity = null;

    /**
     * @param $entity
     *
     * @throws Exception
     */
    public function __construct($entity)
    {
        if($entity !== null)
        {
            $this->setEntity($entity);
        }
        else
        {
            Exceptions::throwException('Cannot execute model event logic. Entity was NULL.');
        }
    }

    public function preRemoveArticleEvent()
    {
        $shopwareArticle        = $this->getEntity();
        $shopwareArticleDetails = $shopwareArticle->getDetails();

        try
        {
            foreach($shopwareArticleDetails as $detail)
            {
                $qb = Shopware()->Models()->createQueryBuilder();
                $qb->delete('Shopware\CustomModels\BfSaleschannel\MappingDetails', array('shopwareId' => $detail->getId()));
                $qb->getQuery()->execute();
            }

            $qb = Shopware()->Models()->createQueryBuilder();
            $qb->delete('Shopware\CustomModels\BfSaleschannel\MappingArticles', array('shopwareId' => $shopwareArticle->getId()));
            $qb->getQuery()->execute();
        }
        catch(Exception $e)
        {
            Exceptions::throwException($e->getMessage());
        }
    }

    public function prePersistLogEvent()
    {
        $this->getEntity()->setDateInsert(date('Y-m-d H:i:s', time()));
    }

    /**
     * @return null|\Shopware\CustomModels\BfSaleschannel\Log|\Shopware\Models\Article\Article|\Shopware\CustomModels\BfSaleschannel\MappingDetails
     */
    public function getEntity()
    {
        return $this->entity;
    }

    /**
     * @param null $entity
     *
     * @return ModelEvents
     */
    public function setEntity($entity)
    {
        $this->entity = $entity;

        return $this;
    }
}
