<?php
namespace Bf\Saleschannel\Components\Util\Patches;

use Shopware_Components_Plugin_Bootstrap;

/**
 * PatchAbstract
 *
 * @package Bf\Saleschannel\Components\Util\Patches
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class PatchAbstract implements PatchesInterface
{
    const SQL_FILE_NAME_EXTENSION = '.sql';
    const SQL_FILE_PATH           = '/Patches/SQL/';

    private $sqlFilePatchName;

    private $shopwarePluginBootstrapClass;

    /**
     * @param null $sqlFilePatchName
     */
    public function __construct($sqlFilePatchName = null)
    {
        $this->sqlFilePatchName = ($sqlFilePatchName !== null) ? $sqlFilePatchName . self::SQL_FILE_NAME_EXTENSION : null;
    }

    /**
     * @param null $fileName
     *
     * @return string
     */
    public function getSqlPatches($fileName = null)
    {
        $sqlContent = '';

        if($fileName !== null)
        {
            $sqlContent = file_get_contents(Shopware()->DocPath('engine_Shopware_Plugins_Community_Backend_BfSaleschannel_Patches_SQL') . $fileName);
        }

        return $sqlContent;
    }

    abstract public function preparePatch();

    /**
     * @return mixed
     */
    public function getSqlFilePatchName()
    {
        return $this->sqlFilePatchName;
    }

    /**
     * @param mixed $sqlFilePatchName
     *
     * @return PatchAbstract
     */
    public function setSqlFilePatchName($sqlFilePatchName)
    {
        $this->sqlFilePatchName = $sqlFilePatchName;

        return $this;
    }

    /**
     * @return Shopware_Components_Plugin_Bootstrap
     */
    public function getShopwarePluginBootstrapClass()
    {
        return $this->shopwarePluginBootstrapClass;
    }

    /**
     * @param mixed $shopwarePluginBootstrapClass
     *
     * @return PatchAbstract
     */
    public function setShopwarePluginBootstrapClass($shopwarePluginBootstrapClass)
    {
        $this->shopwarePluginBootstrapClass = $shopwarePluginBootstrapClass;

        return $this;
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->sqlFilePatchName = null;
    }
}