<?php

namespace Bf\Saleschannel\Components\Util;

use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract;
use Shopware\Components\Model\CategoryDenormalization;
use Shopware\CustomModels\BfSaleschannel\Log;

/**
 * Cleaner
 *
 * @package Bf\Saleschannel\Components\Util
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Cleaner
{
    /** @var array */
    private $deleteItemList = [];

    /** @var string */
    private $typeOfDeleting = 'IMAGE_MAPPING';

    /**
     * @param array|object $deleteItemList
     * @param $typeOfDeleting
     */
    public function __construct($deleteItemList = [], $typeOfDeleting = null)
    {
        $this->setDeleteItemList($deleteItemList);
        $this->setTypeOfDeleting($typeOfDeleting);
    }

    /**
     * @return void
     */
    public function prepareCleanUp()
    {
        switch ($this->getTypeOfDeleting()) {
            case ArticleAbstract::IMPORT_CLEAR_TYPE_IMAGE_MAPPING:
                $this->cleanUpImageMappings();
                break;

            case LogManager::CLEAR_LOG_ENTRIES:
                $this->cleanUpLogEntries();
                break;

            case ArticleAbstract::IMPORT_CLEAR_CATEGORIES_ASSIGNMENTS:
                $this->categoryDenormalization();
                break;
        }
    }

    /**
     * @return string
     */
    public function getTypeOfDeleting()
    {
        return $this->typeOfDeleting;
    }

    /**
     * @param string $typeOfDeleting
     *
     * @return Cleaner
     */
    public function setTypeOfDeleting($typeOfDeleting)
    {
        $this->typeOfDeleting = $typeOfDeleting;

        return $this;
    }

    /**
     * @return void
     */
    private function cleanUpImageMappings()
    {
        foreach ($this->getDeleteItemList() as $imageId => $mapping) {
            foreach ($mapping as $mappingId => $rules) {
                foreach ($rules as $ruleId) {
                    $repository = Helper::getRepository('Shopware\Models\Article\Image\Rule');
                    /** @var \Shopware\Models\Article\Image\Rule $ruleModel */
                    $ruleModel = $repository->findOneBy(['id' => $ruleId]);

                    if ($ruleModel !== null) {
                        Shopware()->Db()->query("delete from s_article_img_mapping_rules where id = ?", [$ruleModel->getId()]);
                    }
                }

                $mappingExists = Shopware()->Db()->fetchOne(
                    "select COUNT(mapping_id) as `nums_mapping_id` from s_article_img_mapping_rules where `mapping_id` = ?",
                    [$mappingId]
                );

                if ((int)$mappingExists === 0) {
                    Shopware()->Db()->query("delete from s_article_img_mappings where id = ? ", [$mappingId]);
                }
            }
        }
    }

    /**
     * @return array|\SimpleXMLElement
     */
    public function getDeleteItemList()
    {
        return $this->deleteItemList;
    }

    /**
     * @param array $deleteItemList
     *
     * @return Cleaner
     */
    public function setDeleteItemList($deleteItemList)
    {
        $this->deleteItemList = $deleteItemList;

        return $this;
    }

    /**
     * @return void
     */
    private function cleanUpLogEntries()
    {
        $identifier = Log::IDENTIFIER_PRODUCTS;
        if ((bool)$this->getDeleteItemList()->ProductId === true) {
            $identifier = $identifier . (string)$this->getDeleteItemList()->ProductId;
        } elseif ((bool)$this->getDeleteItemList()->CategoryId === true) {
            $identifier = $identifier . (string)$this->getDeleteItemList()->CategoryId;
        } elseif ((bool)$this->getDeleteItemList()->ManufacturerId === true) {
            $identifier = $identifier . (string)$this->getDeleteItemList()->ManufacturerId;
        }

        //no delete by model need
        Shopware()->Db()->query(
            "delete from bf_log where identifier_log = ?",
            [$identifier]
        );
    }

    /**
     * @return void
     */
    private function categoryDenormalization()
    {
        if (ConfigManager::getInstance()->getCategoryDenormalization() === true) {
            $component = Shopware()->CategoryDenormalization();
            $component->rebuildCategoryPath();
            $component->removeAllAssignments();
            $component->rebuildAllAssignments(null, 0);
        }
    }

    public function showDuplicateRemoveImgQuery()
    {
        $result = Shopware()->Db()->fetchAll(
            "select sai.img as 'imgName'
                 from s_articles_img sai 
                 inner join ( select articleID, img from s_articles_img group by articleID, img having count(id) > 1 ) 
                 dup on sai.articleID = dup.articleID and sai.img = dup.img limit 100;"
        );

        if (count($result) > 0) {
            foreach ($result as $element) {
                $res = Shopware()->Db()->fetchOne(
                    "SELECT id FROM `s_articles_img` WHERE `img` LIKE ? order by id asc limit 1", [$element['imgName']]
                );

                if ($res !== null && $res !== null) {
                    $removeVariationChildSQL = "delete from s_articles_img where parent_id = " . $res;
                    $removeVariationMainSql  = "delete from s_articles_img where id = " . $res;

                    echo '<pre>';
                    echo $removeVariationChildSQL;
                    echo '</pre>';

                    echo '<pre>';
                    echo $removeVariationMainSql;
                    echo '</pre>';
                }
            }
        }
    }

    /**l
     *
     * @return void
     */
    public function cleanDbEntries()
    {
        $cleanApiAfterDaysConfiguration = ConfigManager::getInstance()->getCleanTimer()->getConfigurationValue();

        Shopware()->Db()->query(
            "delete from bf_api_import_data where process_date < DATE_SUB(now(), INTERVAL ? DAY) and process_date != '0000-00-00 00:00:00'",
            [(int)$cleanApiAfterDaysConfiguration]
        );

        Shopware()->Db()->query(
            "delete from bf_api_import_data_detail
              where
                (process_date < DATE_SUB(now(), INTERVAL ? DAY) and process_date != '0000-00-00 00:00:00')
              or
                (last_update < DATE_SUB(now(), INTERVAL ? DAY) and process_date is null)",
            [(int)$cleanApiAfterDaysConfiguration, (int)$cleanApiAfterDaysConfiguration]
        );

        // 14 days
        $cleanBfScriptloggerAfterDaysConfiguration = ConfigManager::getInstance()->getScriptloggerCleanTimer()->getConfigurationValue();
        Shopware()->Db()->query(
            "delete from bf_scriptlogger where date_start < DATE_SUB(now(), INTERVAL ? DAY)",
            [(int)$cleanBfScriptloggerAfterDaysConfiguration]
        );

        // 60 days
        $cleanBfLogAfterDaysConfiguration = ConfigManager::getInstance()->getLogCleanTimer()->getConfigurationValue();
        Shopware()->Db()->query(
            "delete from bf_log where date_insert < DATE_SUB(now(), INTERVAL ? DAY) and date_insert != '0000-00-00 00:00:00'",
            [(int)$cleanBfLogAfterDaysConfiguration]
        );
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->setDeleteItemList([]);
        $this->setTypeOfDeleting(null);
    }
}
