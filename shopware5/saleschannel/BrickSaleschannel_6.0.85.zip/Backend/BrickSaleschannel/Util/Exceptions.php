<?php
namespace Bf\Saleschannel\Components\Util;

use Exception;
use Shopware\CustomModels\BfSaleschannel\Log;

/**
 * Exceptions
 *
 * @package Bf\Saleschannel\Components\Util
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Exceptions
{
    /**
     * @param array $container
     *
     * @throws Exception
     * @return void
     */
    public static function instanceOfException(array $container = array())
    {
        $total = count($container);

        if($total > 0)
        {
            $fileName = isset($container['fileName']) ? $container['fileName'] : null;

            for($i = 0; $i < $total - 1; $i++)
            {
                $param = isset($container[$i]['param']) ? $container[$i]['param'] : null;
                $obj   = isset($container[$i]['obj']) ? $container[$i]['obj'] : null;

                if($param !== null && $obj !== null)
                {
                    if($param instanceof $obj === false)
                    {
                        throw new Exception('no instance of ' . $obj . ' found on ' . $fileName);
                    }
                }
                else
                {
                    throw new Exception('class name cannot be null');
                }
            }
        }
    }

    /**
     * @param $msg
     * @param array $search
     * @param array $replaces
     * @param int $code
     *
     * @throws Exception
     * @return void
     */
    public static function throwException($msg, array $search = array(), array $replaces = array(), $code = 0)
    {
        if(count($replaces) > 0 && count($search) > 0)
        {
            throw new Exception(str_replace($search, $replaces, $msg), $code);
        }
        else
        {
            throw new Exception($msg);
        }
    }
}
