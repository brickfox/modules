<?php
namespace Bf\Saleschannel\Components\Util;

use Bf\Saleschannel\Components\Gui\Logging;
use Doctrine\ORM\Query;
use Exception;
use Shopware\CustomModels\BfSaleschannel\Log;
use SimpleXMLElement;
use SplFileInfo;
use Zend_Auth;
use Bf\Saleschannel\Components\Util\ConfigManager as BfConfigManager;

/**
 * Helper
 *
 * @package Bf\Saleschannel\Components\Util
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Helper
{
    const DO_NOT_SET_UNIQUE_ID = 'setId';
    const OPERATION_FLUSH      = 'flush';
    const OPERATION_CLEAR      = 'clear';
    const OPERATION_REMOVE     = 'remove';

    /** @var bool */
    public static $isMainShop = true;

    public static $languageIsoCode;

    /** @var array */
    public static $mappingFiltersRelations = array();

    /** @var bool */
    public static $mainImageBaseProductsIsSet = false;

    /** @var bool */
    public static $isMasterShop = false;

    /** @var int */
    public static $masterShopsId = 0;

    /**
     * @return array
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    public static function getMainLanguagesCode()
    {
        $locale = Helper::getConfigurationByKey('mainLanguagesCode')->getConfigurationValue();
        $locale = explode(',', $locale);

        return $locale;
    }

    /**
     * @return int
     */
    public static function getShopsId() {
        $shopsId = self::getDefaultShopsId();

        if (self::$isMasterShop === true && self::$masterShopsId !== null && self::$masterShopsId > 0) {
            $shopsId = self::$masterShopsId;
        }

        return $shopsId;
    }

    /**
     * @return mixed
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    public static function getDefaultShopsId()
    {
        $builder = Shopware()->Models()->createQueryBuilder();
        $builder->select('shop.id')->from('Shopware\Models\Shop\Shop', 'shop')->where('shop.default = 1');
        $shopsId = $builder->getQuery()->getOneOrNullResult(Query::HYDRATE_SINGLE_SCALAR);

        return $shopsId;
    }

    /**
     * @param string $key
     *
     * @return null|\Shopware\CustomModels\BfSaleschannel\Configuration
     */
    public static function getConfigurationByKey($key = '')
    {
        $configurationModel = self::getMappingByValue($key, 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

        return $configurationModel;
    }

    /**
     * @param $value
     * @param $searchField
     * @param string $modelNamespace
     *
     * @return null|object
     */
    public static function getMappingByValue($value, $searchField, $modelNamespace = '')
    {
        $model = null;

        try
        {
            $repository = Shopware()->Models()->getRepository($modelNamespace);

            if(strlen($value) > 0 && strlen($searchField) > 0)
            {
                $model = $repository->findOneBy(array($searchField => $value));
            }
        }
        catch(Exception $e)
        {
            self::fromArray(
                new Log(),
                array(
                    Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_ERROR,
                    Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                    Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                    Logging::SETTER_ALIAS_LOG_MESSAGE => $e->getMessage(),
                    Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                )
            );
        }

        return $model;
    }

    /**
     * @param array $condition
     * @param $modelNamespace
     *
     * @return array
     */
    public static function getMappingByCondition(array $condition = array(), $modelNamespace)
    {
        $sql = null;

        $qb = Shopware()->Models()->createQueryBuilder();

        $qb->select('mapping')->from($modelNamespace, 'mapping');

        try
        {
            if(count($condition) > 0)
            {
                reset($condition);
                $first = key($condition);
                foreach($condition as $modelKey => $value)
                {
                    if($modelKey === $first)
                    {
                        $qb->where('mapping' . $modelKey . ':' . $modelKey);
                    }
                    else
                    {
                        $qb->andWhere('mapping' . $modelKey . ':' . $modelKey);
                    }

                    $qb->setParameter($modelKey, $value);
                }
            }

            $sql = $qb->getQuery();
        }
        catch(Exception $e)
        {
            self::fromArray(
                new Log(),
                array(
                    Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_ERROR,
                    Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                    Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::MAPPING_CONDITION_ERROR_CODE,
                    Logging::SETTER_ALIAS_LOG_MESSAGE => $e->getMessage(),
                    Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                )
            );
        }

        return $sql->getArrayResult();
    }

    /**
     * @param string $modelNamespace
     * @param null $id
     *
     * @return null|object
     */
    public static function getMappingById($modelNamespace = '', $id = null)
    {
        $model = null;

        try
        {
            $repository = Shopware()->Models()->getRepository($modelNamespace);

            if(is_numeric($id) === true)
            {
                $model = $repository->find($id);

                if($model === null)
                {
                    self::fromArray(
                        new Log(),
                        array(
                            Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_ERROR,
                            Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                            Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::CAN_NOT_FIND_MODEL_BY_ID_ERROR_CODE,
                            Logging::SETTER_ALIAS_LOG_MESSAGE => str_replace('{$id}', $id, ErrorCodes::CAN_NOT_FIND_MODEL_BY_ID),
                            Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                        )
                    );
                }
            }
        }
        catch(Exception $e)
        {
            self::fromArray(
                new Log(),
                array(
                    Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_ERROR,
                    Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                    Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::CAN_NOT_FIND_MODEL_BY_ID_ERROR_CODE,
                    Logging::SETTER_ALIAS_LOG_MESSAGE => $e->getMessage(),
                    Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                )
            );
        }

        return $model;
    }

    /**
     * @param $entity
     * @param array $array
     * @param bool $flush
     */
    public static function fromArray($entity, array $array = array(), $flush = true)
    {
        //lowers the memory peek
        $conn = Shopware()->Models()->getConnection();
        $conn->getConfiguration()->setSQLLogger(null);

        if(count($array) > 0)
        {
            foreach($array as $methodAlias => $value)
            {
                $setter = ucfirst($methodAlias);
                $setter = 'set' . $setter;

                try
                {
                    if(method_exists($entity, $setter) === true)
                    {
                        if($setter !== self::DO_NOT_SET_UNIQUE_ID)
                        {
                            $entity->$setter($value);
                        }
                    }
                }
                catch(Exception $e)
                {
                    self::fromArray(
                        new Log(),
                        array(
                            Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                            Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                            Logging::SETTER_ALIAS_LOG_MESSAGE => $e->getMessage()
                        )
                    );
                }
            }

            self::doModelOperation($entity);

            if($flush === true)
            {
                self::doModelOperation($entity, array(), 'flush');
            }
        }
    }

    /**
     * @return int
     */
    public static function getUserId()
    {
        return 0;
    }

    /**
     * @return string
     */
    public static function getUserName()
    {
        return 'Api-Import';
    }

    /**
     * @param $nameSpace
     *
     * @return \Shopware\Components\Model\ModelRepository
     */
    public static function getRepository($nameSpace)
    {
        return Shopware()->Models()->getRepository($nameSpace);
    }

    /**
     * @param $model
     * @param array $models
     * @param string $operation
     */
    public static function doModelOperation($model = null, array $models = array(), $operation = 'persist')
    {
        try
        {
            if(is_object($model) === true)
            {
                self::getEntityManager()->$operation($model);
            }

            if(count($models) > 0)
            {
                foreach($models as $model)
                {
                    if(is_object($model) === true)
                    {
                        self::getEntityManager()->$operation($model);
                    }
                }
            }
        }
        catch(Exception $e)
        {
            Exceptions::throwException($e->getMessage());
        }
    }

    /**
     * @param null $entity
     *
     * @return void
     */
    public static function flush($entity = null)
    {
        self::getEntityManager()->flush($entity);
    }

    /**
     * @return \Shopware\Components\Model\ModelManager
     * @throws \Doctrine\ORM\ORMException
     */
    private static function getEntityManager()
    {
        if(Shopware()->Models()->isOpen() === false)
        {
        }

        return Shopware()->Models();
    }

    /**
     * @param $exception
     *
     * @return string
     */
    public static function convertExceptionMessageIntoGuiFormat(Exception $exception)
    {
        return '<strong>' . $exception->getMessage() . '</strong>';
    }

    /**
     * @param $importDirectory
     *
     * @return void
     */
    public static function checkDir($importDirectory)
    {
        if(is_dir($importDirectory) === false)
        {
            mkdir($importDirectory, 0777, true);
        }
    }

    /**
     * @param $input
     *
     * @return float
     */
    public static function toFloat($input)
    {
        return (float) str_replace(',', '.', trim($input));
    }

    /**
     * Creates $filePath if not exists
     *
     * @param string $filePath directory with filename appended
     * @param bool $onlyPath
     */
    public static function checkPath($filePath, $onlyPath = false)
    {
        $dirPath       = "";
        $directoryList = explode(DIRECTORY_SEPARATOR, $filePath);
        $dirCount      = count($directoryList);
        if($onlyPath === false)
        {
            $dirCount = $dirCount - 1;
        }

        for($dirCounter = 0; $dirCounter < $dirCount; $dirCounter++)
        {
            $dirPath .= $directoryList[$dirCounter] . DIRECTORY_SEPARATOR;

            if(false === file_exists($dirPath))
            {
                mkdir($dirPath, 0755);
                chmod($dirPath, 0755);
            }
        }
    }

    /**
     * @param $version1
     * @param $version2
     * @param $operator
     *
     * @return mixed
     */
    public static function versionCompare($version1, $version2, $operator)
    {
        return version_compare($version1, $version2, $operator);
    }

    /**
     * @param int $countOfMonth
     *
     * @return void
     */
    public static function recursiveDeleteArchiveLogFiles($countOfMonth = 1)
    {
        $targetPath = ConfigManager::getInstance()->getLogPath() . date('Y', time());

        Helper::checkPath($targetPath, true);

        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($targetPath));

        /** @var SplFileInfo $item */
        foreach($iterator as $item)
        {
            if($item->isFile() && $item->getMTime() < strtotime(date('Y-m', strtotime('-' . $countOfMonth . ' month')) . '-01'))
            {
                unlink($item->getPath() . DIRECTORY_SEPARATOR . $item->getFilename());
            }
        }
    }

    /**
     * @param string $pluginName
     *
     * @return bool
     */
    public static function assertRequiredPluginsPresent($pluginName)
    {
        $pluginInstalledAndActive = false;

        $sql  = 'SELECT 1 FROM s_core_plugins WHERE name = ? AND active = 1';
        $test = Shopware()->Db()->fetchOne($sql, array($pluginName));

        if(empty($test) === false)
        {
            $pluginInstalledAndActive = true;
        }

        return $pluginInstalledAndActive;
    }

    /**
     * @param string $type
     * @param SimpleXMLElement $attribute
     *
     * @return array
     */
    public static function getPropertyNameByAttributesType(SimpleXMLElement $attribute, $type = '')
    {
        $return = array(
            'name'      => '',
            'value'     => '',
            'id'        => '',
            'sortOrder' => 0
        );

        switch ($type) {
            case 'String':
            case 'Array':
                $return['name']      = ((bool)$attribute->Translations->Translation->Name) ? (string)$attribute->Translations->Translation->Name : '';
                $return['value']     = ((bool)$attribute->Translations->Translation->Value) ? (string)$attribute->Translations->Translation->Value : '';
                $return['id']        = (int)$attribute->Translations->Translation->Value['id'];
                $return['sortOrder'] = (int)$attribute->Translations->Translation->Value['sortOrder'];
                break;

            case 'Integer':
            case 'Float':
            case 'Boolean':
            case 'DateTime':
                $return['name']  = ((bool)$attribute->Translations->Translation->Name) ? (string)$attribute->Translations->Translation->Name : '';
                $return['value'] = ((bool)$attribute->Value) ? (string)$attribute->Value : '';
                $return['id']    = (string)$attribute['code'] . '-' .(string)$attribute['id'];
                break;
        }

        return $return;
    }
}
