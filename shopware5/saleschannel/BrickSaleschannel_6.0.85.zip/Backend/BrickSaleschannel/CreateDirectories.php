<?php
/**
 * CreateDirectories
 *
 * @package Bf\Saleschannel\Install
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Install;

use Bf\Saleschannel\Components\Util\Helper as BfHelper;

/**
 * CreateDirectories
 *
 * @package Bf\Saleschannel\Install
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class CreateDirectories extends InstallAbstract
{
    /**
     * CreateDirectories constructor.
     *
     * @param \Shopware_Components_Plugin_Bootstrap $shopwarePluginBootstrapClass
     */
    public function __construct($shopwarePluginBootstrapClass)
    {
        parent::__construct($shopwarePluginBootstrapClass);
    }

    /**
     * @return void
     */
    public function executeCreateDirectories()
    {
        $installDirectories = array(
            './uploads/brickfox/in',
            './uploads/brickfox/out',
            './uploads/brickfox/failure',
            './uploads/brickfox/success',
            './uploads/brickfox/processed',
            './uploads/brickfox/processedError',
            './uploads/brickfox/logs',
            './uploads/brickfox/image'
        );

        foreach($installDirectories as $directoryPath)
        {
            BfHelper::checkPath($directoryPath, true);
        }
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        parent::__destruct();
    }
}
