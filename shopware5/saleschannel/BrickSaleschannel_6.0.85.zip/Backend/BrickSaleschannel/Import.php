<?php
namespace Bf\Saleschannel\Components;

use Shopware\CustomModels\BfSaleschannel\ApiImportData;
use Shopware\CustomModels\BfSaleschannel\ApiImportDataDetail;

/**
 * Import
 *
 * @package Bf\Saleschannel\Components
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Import
{
    private $fileToImport;

    private $methodName;

    private $jobId = null;

    /**
     * @param $fileToImport
     * @param $methodName
     */
    public function __construct($fileToImport, $methodName)
    {
        $this->fileToImport = $fileToImport;
        $this->methodName   = $methodName;
        $this->jobId        = $this->randomToken();
    }

    /**
     * @return void
     */
    public function preImport()
    {
    }

    /**
     * @return void
     */
    public function import()
    {
        $this->preImport();
        $elementWasWritten = false;

        $xmlReader = new \XMLReader();
        $xmlReader->open($this->getFileToImport(), null, LIBXML_NOCDATA);


        $apiImportDataModel = new ApiImportData();
        $apiImportDataModel->setProcessed(0);
        $apiImportDataModel->setImportType($this->getMethodName());
        $apiImportDataModel->setJobId($this->getJobId());
        $apiImportDataModel->setDateInsert(new \DateTime());
        $apiImportDataModel->setLastUpdate(new \DateTime());
        $apiImportDataModel->setProcessDate(new \DateTime('0000-00-00 00:00:00'));
        Shopware()->Models()->persist($apiImportDataModel);

        while($xmlReader->read() === true)
        {
            try
            {
                if ($xmlReader->name === 'Products') {
                    $apiImportDataModel->setShopsId((int) $xmlReader->getAttribute('shopsId'));
                    Shopware()->Models()->persist($apiImportDataModel);
                } else {
                    $apiImportDataModel->setShopsId(0);
                    Shopware()->Models()->persist($apiImportDataModel);
                }

                if($xmlReader->nodeType === \XMLReader::ELEMENT && $xmlReader->depth === 1)
                {
                    $elementWasWritten = true;
                    $simpleXmlElement  = $xmlReader->readOuterXml();

                    $apiImportDataDetailModel = new ApiImportDataDetail();
                    $apiImportDataDetailModel->setJobId($this->getJobId());
                    $apiImportDataDetailModel->setData(gzcompress((string) $simpleXmlElement));
                    $apiImportDataDetailModel->setProcessed(0);
                    $apiImportDataDetailModel->setDateInsert(new \DateTime());
                    $apiImportDataDetailModel->setLastUpdate(new \DateTime());
                    Shopware()->Models()->persist($apiImportDataDetailModel);
                }
            }
            catch(\Exception $e)
            {
                echo '<pre>';
                print_r($e->getTrace());
                echo '</pre>';
                continue;
            }
        }

        if($elementWasWritten === true)
        {
            Shopware()->Models()->flush();
        }

        Shopware()->Models()->clear();

        $this->postImport();
    }

    /**
     * @return void
     */
    public function postImport()
    {
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->fileToImport = null;
        $this->methodName   = null;
    }

    /**
     * @return mixed
     */
    public function getFileToImport()
    {
        return $this->fileToImport;
    }

    /**
     * @param mixed $fileToImport
     *
     * @return Import
     */
    public function setFileToImport($fileToImport)
    {
        $this->fileToImport = $fileToImport;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getMethodName()
    {
        return $this->methodName;
    }

    /**
     * @param mixed $methodName
     *
     * @return Import
     */
    public function setMethodName($methodName)
    {
        $this->methodName = $methodName;

        return $this;
    }

    /**
     * @return bool|null|string
     */
    public function getJobId()
    {
        return $this->jobId;
    }

    /**
     * @param bool|null|string $jobId
     *
     * @return Import
     */
    public function setJobId($jobId)
    {
        $this->jobId = $jobId;

        return $this;
    }

    /**
     * @param int $len
     *
     * @return string
     */
    final private function randomToken($len = 15)
    {
        return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $len);
    }
}
