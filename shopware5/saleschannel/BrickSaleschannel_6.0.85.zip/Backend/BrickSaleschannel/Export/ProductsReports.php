<?php
namespace Bf\Saleschannel\Components\Export;

use Bf\Saleschannel\Components\ExportAbstract;
use Bf\Saleschannel\Components\Util\FileWriter;
use Bf\Saleschannel\Components\Util\Helper;
use Exception;
use XMLWriter;

/**
 * Class ProductsReports
 *
 * @package Bf\Saleschannel\Components\Export
 */
class ProductsReports extends ExportAbstract
{
    const ORG_PATH_PART = 'sViewport=detail&sArticle=';

    /**
     * @param mixed $item
     * @param XMLWriter $XMLWriter
     * @param null $shopsId
     *
     * @throws Exception
     *
     * @return void
     */
    protected function processExport($item, XMLWriter $XMLWriter, $shopsId = null)
    {
        try
        {
            $bfMappingArticlesRepository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingArticles');
            /** @var \Shopware\CustomModels\BfSaleschannel\MappingArticles $bfMappingArticlesModel */
            $bfMappingArticlesModel      = $bfMappingArticlesRepository->findOneBy(array('shopwareId' => $item));

            if($bfMappingArticlesModel !== null)
            {
                $sCoreRewriteUrlsResult = Shopware()->Db()->fetchRow(
                    "
                        select * from s_core_rewrite_urls where main = ? and subshopID = ? and org_path = ?
                    ",
                    array(1, $shopsId, self::ORG_PATH_PART . $bfMappingArticlesModel->getShopwareId())
                );

                if (!empty($sCoreRewriteUrlsResult) && is_array($sCoreRewriteUrlsResult) === true) {
                    FileWriter::$xmlElements['ProductsReport-' . FileWriter::$internalArrayKeyCounter] = array();
                    $productsReportsClass = new \Bf\Saleschannel\Components\Resources\Report\ProductsReports($bfMappingArticlesModel, $sCoreRewriteUrlsResult, $bfMappingArticlesModel->getShopwareId());
                    $productsReportsClass->prepareProductsReportsNode($shopsId);
                    $productsReportsClass->writeApiExportSeoUrls($shopsId);
                } else {
                    $sCoreRewriteUrlsResult = Shopware()->Db()->fetchRow(
                        "
                        select * from s_core_rewrite_urls where (main = ? or main = ?) and subshopID = ? and org_path = ?
                    ",
                        array(1, 0, $shopsId, self::ORG_PATH_PART . $bfMappingArticlesModel->getShopwareId())
                    );

                    if(!empty($sCoreRewriteUrlsResult) && is_array($sCoreRewriteUrlsResult) === true)
                    {
                        FileWriter::$xmlElements['ProductsReport-' . FileWriter::$internalArrayKeyCounter] = array();
                        $productsReportsClass = new \Bf\Saleschannel\Components\Resources\Report\ProductsReports($bfMappingArticlesModel, $sCoreRewriteUrlsResult, $bfMappingArticlesModel->getShopwareId());
                        $productsReportsClass->prepareProductsReportsNode($shopsId);
                        $productsReportsClass->writeApiExportSeoUrls($shopsId);

                    }
                }
            }
        }
        catch(Exception $e)
        {
            throw new Exception($e);
        }

        FileWriter::fromArray($XMLWriter, FileWriter::$xmlElements);
    }
}