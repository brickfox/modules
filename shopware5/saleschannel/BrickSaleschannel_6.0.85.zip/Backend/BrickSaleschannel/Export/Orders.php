<?php
/**
 * Orders
 * This file is part of brickfox.
 *
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */
namespace Bf\Saleschannel\Components\Export;

use Bf\Saleschannel\Components\Util\FileWriter;
use Exception;
use Bf\Saleschannel\Components\ExportAbstractOrders;
use XMLWriter;

class Orders extends ExportAbstractOrders
{
    protected function processExport(\Shopware\Models\Order\Order $item, XMLWriter $XMLWriter)
    {
        try
        {
            if($item instanceof \Shopware\Models\Order\Order)
            {
                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter] = array();
                (new \Bf\Saleschannel\Components\Resources\Orders\Orders($item))->prepareOrderNode();
            }
        }
        catch(Exception $e)
        {
            throw new Exception($e);
        }

        FileWriter::fromArray($XMLWriter, FileWriter::$xmlElements);
    }
}