<?php
namespace Bf\Saleschannel\Components\Gui;

/**
 * Log
 *
 * @package Bf\Saleschannel\Components\Gui
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Log
{
    private $logType = null;

    /** @var int */
    private $start = 0;

    /** @var int */
    private $limit = 25;
    private $filter = null;
    private $sort = null;
    private $orderBy = null;

    /**
     * @param $logType
     * @param $start
     * @param $limit
     * @param null $filter
     * @param string $sort
     * @param string $orderBy
     */
    public function __construct($logType, $start, $limit, $filter = null, $sort = 'desc', $orderBy = 'process_date')
    {
        $this->logType = $logType;
        $this->start   = $start;
        $this->limit   = $limit;
        $this->filter  = $filter;
        $this->sort    = $sort;
        $this->orderBy = $orderBy;
    }

    /**
     * @return array
     */
    public function prepareLogList()
    {
        $filterQueryPart = '';

        $total = Shopware()->Db()->fetchOne(
            "
            select count(baidd.id) from bf_api_import_data_detail baidd
            left join bf_api_import_data baid on baid.job_id = baidd.job_id
            where baid.processed = ? and baid.import_type = ?
            and baidd.error_codes is not null
            ",
            array(1, $this->getLogType())
        );

        if($this->getFilter() !== null)
        {
            $filterQueryPart .= "
                and (
                        baidd.error_codes like '%" . $this->getFilter() . "%'
                        or baidd.error_message like '%" . $this->getFilter() . "%'
                        or baidd.data like '%" . $this->getFilter() . "%'
                        or baidd.process_date like '%" . $this->getFilter() . "%'
                )
            ";
        }

        $list = Shopware()->Db()->fetchAll(
            "
            select
            baidd.id, baid.import_type, baidd.job_id, baidd.data, baidd.processed,
            baidd.error_codes, baidd.error_message, baidd.brickfox_id, baidd.process_date
            from
            bf_api_import_data_detail baidd
            left join
            bf_api_import_data baid on baid.job_id = baidd.job_id
            where
            baid.processed = ? and
            baid.import_type = ? and
            (
              baidd.processed = ? or
              (
                baidd.processed = ? and
                baidd.error_codes is not null
              ) or
              (
                baidd.processed = ? and
                baidd.error_codes is not null
              )
            )
            " . $filterQueryPart . "
            order by
            baidd." . $this->getOrderBy() . " " . $this->getSort() . "
            limit " . $this->getStart() . "," . $this->getLimit(),
            array(1, $this->getLogType(), 0, 1, 0)
        );

        foreach($list as $key => $listElement)
        {
            $bfApiImportDataDetailRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\ApiImportDataDetail');
            $bfApiImportDataDetailModel = $bfApiImportDataDetailRepository->find($listElement['id']);
            if($bfApiImportDataDetailModel !== null)
            {
                $stream           = (string) gzuncompress(stream_get_contents($bfApiImportDataDetailModel->getData()));
                $simpleXmlObject = simplexml_load_string($stream);

                if(is_bool($simpleXmlObject) === true)
                {
                    $list[$key]['data'] = '';
                }
                else if(is_object($simpleXmlObject) === true)
                {
                    $list[$key]['data'] = htmlentities($simpleXmlObject->asXML());
                }
            }

            if(strlen($listElement['error_message']) > 0)
            {
                $list[$key]['errorMessageShort'] = mb_substr($listElement['error_message'], 0, 150) . '...';
            }
            else
            {
                $list[$key]['errorMessageShort'] = '-';
            }

            if(strlen($listElement['error_codes']) <= 0)
            {
                $list[$key]['error_codes'] = '-';
            }
        }

        return array(
            'count' => $total,
            'data'  => $list
        );
    }

    /**
     * @return null
     */
    public function getLogType()
    {
        return $this->logType;
    }

    /**
     * @param null $logType
     *
     * @return Log
     */
    public function setLogType($logType)
    {
        $this->logType = $logType;

        return $this;
    }

    /**
     * @return int
     */
    public function getStart()
    {
        return $this->start;
    }

    /**
     * @param int $start
     *
     * @return Log
     */
    public function setStart($start)
    {
        $this->start = $start;

        return $this;
    }

    /**
     * @return int
     */
    public function getLimit()
    {
        return $this->limit;
    }

    /**
     * @param int $limit
     *
     * @return Log
     */
    public function setLimit($limit)
    {
        $this->limit = $limit;

        return $this;
    }

    /**
     * @return null
     */
    public function getFilter()
    {
        return $this->filter;
    }

    /**
     * @param null $filter
     *
     * @return Log
     */
    public function setFilter($filter)
    {
        $this->filter = $filter;

        return $this;
    }

    /**
     * @return null
     */
    public function getSort()
    {
        return $this->sort;
    }

    /**
     * @param null $sort
     *
     * @return Log
     */
    public function setSort($sort)
    {
        $this->sort = $sort;

        return $this;
    }

    /**
     * @return null
     */
    public function getOrderBy()
    {
        return $this->orderBy;
    }

    /**
     * @param null $orderBy
     *
     * @return Log
     */
    public function setOrderBy($orderBy)
    {
        $this->orderBy = $orderBy;

        return $this;
    }

    public function __destruct()
    {
        $this->logType = null;
    }
}
