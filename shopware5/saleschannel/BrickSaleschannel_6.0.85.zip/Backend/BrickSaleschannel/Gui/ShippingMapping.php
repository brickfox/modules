<?php
namespace Bf\Saleschannel\Components\Gui;

use Bf\Saleschannel\Components\Util\Helper;

/**
 * ShippingMapping
 *
 * @package Bf\Saleschannel\Components\Gui
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class ShippingMapping
{
    /**
     * @return array
     */
    public function getShippingMappingFieldKeys()
    {
        $shipments = array();

        $repository       = Helper::getRepository('Shopware\Models\Order\Status');
        $ordersStateModel = $repository->findBy(array('group' => \Shopware\Models\Order\Status::GROUP_STATE));

        if(count($ordersStateModel) > 0)
        {
            /** @var \Shopware\Models\Order\Status $orderStateModel */
            foreach($ordersStateModel as $orderStateModel)
            {
                $shipments[] = array(
                    'shopwareFieldKeyCode' => $orderStateModel->getId(),
                    'shopwareFieldKeyName' => $orderStateModel->getName()
                );
            }
        }

        return $shipments;
    }
}
