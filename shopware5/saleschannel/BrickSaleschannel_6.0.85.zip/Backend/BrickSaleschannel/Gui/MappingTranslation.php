<?php
namespace Bf\Saleschannel\Components\Gui;

use Bf\Saleschannel\Components\Util\Helper;

/**
 * MappingTranslation
 *
 * @package Bf\Saleschannel\Components\Gui
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class MappingTranslation
{
    /**
     * @return array
     */
    public function getTranslationMappingFieldKeys()
    {
        $isoCodes = array();

        $repository = Helper::getRepository('Shopware\Models\Shop\Locale');
        /** @var \Shopware\Models\Shop\Locale $localModel */
        $localeModel = $repository->findAll();

        if(count($localeModel) > 0)
        {
            foreach($this->getShopwareIsoCodes($localeModel) as $isoCode => $LanguageTerritory)
            {
                $isoCodes[] = array(
                    'shopwareFieldKeyCode' => $isoCode,
                    'shopwareFieldKeyName' => $LanguageTerritory
                );
            }
        }

        return $isoCodes;
    }

    /**
     * @param array $localeModel
     *
     * @return \Generator
     */
    private function getShopwareIsoCodes(array $localeModel)
    {
        $shopwareIsoCodes = array();

        /** @var \Shopware\Models\Shop\Locale $locale */
        foreach($localeModel as $locale)
        {
            if($locale->getLocale() !== 'de_DE')
            {
                $shopwareIsoCodes[$locale->getLocale()] = $locale->getLanguage() . '/' . $locale->getTerritory();
            }
        }

        return $shopwareIsoCodes;
    }
}
