<?php
namespace Bf\Saleschannel\Components\Gui;

use Bf\Saleschannel\Components\Util\Helper;

/**
 * MappingCurrencies
 *
 * @package Bf\Saleschannel\Components\Gui
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class MappingCurrencies
{
    /**
     * @return array
     */
    final public function getCurrenciesMappingFieldKeys()
    {
        $customerGroups = array();

        $repository         = Helper::getRepository('Shopware\Models\Customer\Group');
        $customerGroupModel = $repository->findAll();

        if(count($customerGroupModel) > 0)
        {
            foreach($customerGroupModel as $element)
            {
                $customerGroups[] = array(
                    'shopwareFieldKeyCode' => $element->getKey(),
                    'shopwareFieldKeyName' => $element->getName()
                );
            }
        }

        return $customerGroups;
    }
}
