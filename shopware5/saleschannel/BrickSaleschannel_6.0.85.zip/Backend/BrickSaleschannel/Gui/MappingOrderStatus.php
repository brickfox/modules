<?php
namespace Bf\Saleschannel\Components\Gui;

use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Exception;
use Shopware\CustomModels\BfSaleschannel\Log;

/**
 * MappingOrderStatus
 *
 * @package Bf\Saleschannel\Components\Gui
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class MappingOrderStatus
{
    final public function installDefaultOrderStatus()
    {
        try
        {
            Shopware()->Db()->query(
                "
                    INSERT INTO bf_order_status (`brickfoxID`, `brickfox_code`)
                    VALUES
                      (1, 'open'),
                      (2, 'transferred'),
                      (3, 'PaymentOutstanding'),
                      (4, 'ReadyForShipout'),
                      (5, 'OrderedFromSupplier'),
                      (6, 'Cancelled'),
                      (7, 'NotAvailable'),
                      (8, 'ScanIn'),
                      (9, 'PartlyShipped'),
                      (10, 'Shipped'),
                      (11, 'Returned'),
                      (12, 'Deleted'),
                      (13, 'Unknown'),
                      (14, 'error'),
                      (15, 'Pending'),
                      (16, 'payed'),
                      (17, 'PartlyReturned'),
                      (18, 'fulfilled'),
                      (19, 'Packed'),
                      (20, 'merged'),
                      (21, 'exchange'),
                      (22, 'pickedUp')
                "
            );
        }
        catch(Exception $e)
        {
            Helper::fromArray(
                new Log(),
                array(
                    Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                    Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                    Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                    Logging::SETTER_ALIAS_LOG_MESSAGE => $e->getMessage(),
                    Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                )
            );
        }
    }
}
