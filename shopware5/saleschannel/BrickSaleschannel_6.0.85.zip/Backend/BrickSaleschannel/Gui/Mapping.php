<?php
namespace Bf\Saleschannel\Components\Gui;

use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Doctrine\ORM\AbstractQuery;
use Doctrine\ORM\Tools\Pagination\Paginator;
use Exception;
use ReflectionMethod;
use Shopware\CustomModels\BfSaleschannel\Log;

/**
 * Mapping
 *
 * @package Bf\Saleschannel\Components\Gui
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Mapping extends MappingAbstract
{
    const NOT_TO_SET_ID                         = 'setId';
    const DELETE_MAPPING_SUCCESSFUL_ATTRIBUTES  = 'Removed attributes mapping successful.<br /><b>Attribute: {$attribute}</b>';
    const DELETE_MAPPING_SUCCESSFUL_CUSTOMIZED  = 'Removed customized mapping successful.<br /><b>Attribute: {$attribute}</b>';
    const DELETE_MAPPING_SUCCESSFUL_CURRENCIES  = 'Removed currencies mapping successful.<br /><b>Currency: {$attribute}</b>';
    const DELETE_MAPPING_SUCCESSFUL_TRANSLATION = 'Removed translation mapping successful.<br /><b>Translation: {$attribute}</b>';
    const SAVE_MAPPING_SUCCESSFUL_ATTRIBUTES    = 'Saved attributes mapping successful.<br /><b>Attribute: {$attribute}</b>';
    const SAVE_MAPPING_SUCCESSFUL_CUSTOMIZED    = 'Saved customized mapping successful.<br /><b>Attribute: {$attribute}</b>';
    const SAVE_MAPPING_SUCCESSFUL_CURRENCIES    = 'Saved currencies mapping successful.<br /><b>Currency: {$attribute}</b>';
    const SAVE_MAPPING_SUCCESSFUL_TRANSLATION   = 'saved translation mapping successful.<br /><b>Translation: {$attribute}</b>';
    const CAN_NOT_DELETE_UNDEFINED_MAPPING      = 'Cannot delete undefined Mapping.';

    /** @var null */
    private $mappingModel = null;

    /** @var array */
    private $mappingGetter = array();

    /** @var array */
    private $mappingSetter = array();

    /** @var array */
    private $mappingKeyFields = array();

    /** @var null */
    private $uniqueKey = null;

    /**
     * @return bool
     */
    final public function deleteMappings()
    {
        $result = true;

        try
        {
            foreach($this->getMappingSetter() as $key)
            {
                $model = $this->preLoad($this->getMappingGetter(), $key[$this->getUniqueKey()]);

                if($model !== null)
                {

                    $attributesName = 'unknown';
                    $message        = self::DELETE_MAPPING_SUCCESSFUL_ATTRIBUTES;
                    if(method_exists($model, 'getAttributesCode') === true && strlen($model->getAttributesCode()) > 0)
                    {
                        $attributesName = $model->getAttributesCode();
                    }
                    elseif(method_exists($model, 'getXmlTag') === true && strlen($model->getXmlTag()) > 0)
                    {
                        $message        = self::DELETE_MAPPING_SUCCESSFUL_CUSTOMIZED;
                        $attributesName = $key['xmlTag'];
                    }
                    elseif(method_exists($model, 'getBrickfoxCurrenciesCode') === true && strlen($model->getBrickfoxCurrenciesCode()) > 0)
                    {
                        $message        = self::DELETE_MAPPING_SUCCESSFUL_CURRENCIES;
                        $attributesName = $key['brickfoxCurrenciesCode'];
                    }
                    elseif(method_exists($model, 'getBrickfoxIsoCode') === true && strlen($model->getBrickfoxIsoCode()) > 0)
                    {
                        $message        = self::DELETE_MAPPING_SUCCESSFUL_TRANSLATION;
                        $attributesName = $key['brickfoxIsoCode'];
                    }

                    Shopware()->Models()->remove($model);
                    Shopware()->Models()->flush($model);

                    Helper::fromArray(
                        new Log(),
                        array(
                            Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_SUCCESS,
                            Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                            Logging::SETTER_ALIAS_LOG_MESSAGE => str_replace('{$attribute}', $attributesName, $message),
                            Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                        )
                    );
                }
                else
                {
                    Helper::fromArray(
                        new Log(),
                        array(
                            Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_ERROR,
                            Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                            Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::CAN_NOT_DELETE_UNDEFINED_ERROR_CODE,
                            Logging::SETTER_ALIAS_LOG_MESSAGE => self::CAN_NOT_DELETE_UNDEFINED_MAPPING,
                            Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                        )
                    );
                }
            }
        }
        catch(Exception $e)
        {
            Helper::fromArray(
                new Log(),
                array(
                    Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                    Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                    Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                    Logging::SETTER_ALIAS_LOG_MESSAGE => $e->getMessage(),
                    Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                )
            );

            $result = false;
        }

        return $result;
    }

    /**
     * @param $start
     * @param $limit
     * @param $filter
     *
     * @return array
     */
    final public function loadMappings($start, $limit, $filter)
    {
        $qb = $this->getQueryBuilder();
        $qb->select(array('mapping'))->from($this->getMappingModel(), 'mapping');

        if($filter !== null)
        {
            $qb = $this->mappingFilterCondition($qb, $this->getMappingModel(), $filter);
        }

        if((int) $limit !== 0)
        {
            $qb->setFirstResult($start)->setMaxResults($limit);
        }
        $sql = $qb->getQuery()->setHydrationMode(AbstractQuery::HYDRATE_ARRAY);

        $paginator = new Paginator($sql);

        $total = $paginator->count();
        $list  = $paginator->getIterator()->getArrayCopy();

        $return = array(
            'count' => $total,
            'data'  => $list
        );

        return $return;
    }

    /**
     * @param $params
     *
     * @return array
     */
    final public function getOneOrMoreMappings($params)
    {
        $result = array();

        foreach($this->getMappingKeyFields() as $key => $elements)
        {
            if(array_key_exists($key, $params) === true)
            {
                $result[0][$key] = $params[$key];
            }
        }

        if(count($result) <= 0)
        {

            $counter = 0;

            foreach($params as $key => $elements)
            {
                foreach($elements as $index => $value)
                {
                    if(array_key_exists($index, $this->getMappingKeyFields()) === true)
                    {
                        $result[$counter][$index] = $value;
                    }
                }
                $counter++;
            }
        }

        return $result;
    }

    /**
     * @return bool
     */
    final public function saveMapping()
    {
        $result = true;

        try
        {
            $mappingModel = $this->getMappingModel();

            foreach($this->getMappingSetter() as $key)
            {
                $model = $this->preLoad($this->getMappingGetter(), $key[$this->getUniqueKey()]);

                if($model === null)
                {
                    $model = new $mappingModel();

                    Helper::fromArray($model, $key);
                }
                elseif(is_object($model) === true)
                {
                    Helper::fromArray($model, $key);
                }

                $attributesName = 'unknown';
                $message        = self::SAVE_MAPPING_SUCCESSFUL_ATTRIBUTES;

                if(isset($key['attributesCode']) === true)
                {
                    $attributesName = $key['attributesCode'];
                }
                elseif(isset($key['xmlTag']) === true)
                {
                    $message        = self::SAVE_MAPPING_SUCCESSFUL_CUSTOMIZED;
                    $attributesName = $key['xmlTag'];
                }
                elseif(isset($key['brickfoxCurrenciesCode']) === true)
                {
                    $message        = self::SAVE_MAPPING_SUCCESSFUL_CURRENCIES;
                    $attributesName = $key['brickfoxCurrenciesCode'];
                }
                elseif(isset($key['brickfoxIsoCode']) === true)
                {
                    $message        = self::SAVE_MAPPING_SUCCESSFUL_TRANSLATION;
                    $attributesName = $key['brickfoxIsoCode'];
                }

                Helper::fromArray(
                    new Log(),
                    array(
                        Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_SUCCESS,
                        Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                        Logging::SETTER_ALIAS_LOG_MESSAGE => str_replace('{$attribute}', $attributesName, $message),
                        Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                    )
                );
            }
        }
        catch(Exception $e)
        {
            Helper::fromArray(
                new Log(),
                array(
                    Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                    Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                    Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                    Logging::SETTER_ALIAS_LOG_MESSAGE => $e->getMessage()
                )
            );

            $result = false;
        }

        return $result;
    }

    /**
     * @param $mappingGetter
     * @param string $uniqueKeyValue
     *
     * @return null|object
     */
    final private function preLoad($mappingGetter, $uniqueKeyValue = '')
    {
        $model = null;

        if(isset($mappingGetter['preLoad']['className']) === true && isset($mappingGetter['preLoad']['methodName']) === true)
        {
            $className      = $mappingGetter['preLoad']['className'];
            $methodName     = $mappingGetter['preLoad']['methodName'];
            $modelNamespace = $mappingGetter['preLoad']['modelNamespace'];

            if(class_exists($className, true) === true)
            {
                $method = new ReflectionMethod($className, $methodName);

                if($method->isStatic() === true)
                {
                    $model = $className::$methodName($modelNamespace, $uniqueKeyValue);
                }
                elseif($method->isPublic() === true)
                {
                    try
                    {
                        $class = new $className();
                        $model = $class->$methodName($modelNamespace, $uniqueKeyValue);
                    }
                    catch(Exception $e)
                    {
                        Helper::fromArray(
                            new Log(),
                            array(
                                Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                                Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                                Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                                Logging::SETTER_ALIAS_LOG_MESSAGE => $e->getMessage()
                            )
                        );
                    }
                }
            }
            else
            {
                Helper::fromArray(
                    new Log(),
                    array(
                        Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_ERROR,
                        Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                        Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::CAN_NOT_FIND_CLASS_ERROR_CODE,
                        Logging::SETTER_ALIAS_LOG_MESSAGE => str_replace('{$className}', $className, ErrorCodes::CAN_NOT_FIND_CLASS),
                        Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                    )
                );

                $model = false;
            }
        }

        return $model;
    }

    /**
     * @return null|string
     */
    public function getMappingModel()
    {
        return $this->mappingModel;
    }

    /**
     * @param null $mappingModel
     *
     * @return Mapping
     */
    public function setMappingModel($mappingModel)
    {
        $this->mappingModel = $mappingModel;

        return $this;
    }

    /**
     * @return array
     */
    public function getMappingGetter()
    {
        return $this->mappingGetter;
    }

    /**
     * @param array $mappingGetter
     *
     * @return Mapping
     */
    public function setMappingGetter($mappingGetter)
    {
        $this->mappingGetter = $mappingGetter;

        return $this;
    }

    /**
     * @return array
     */
    public function getMappingSetter()
    {
        return $this->mappingSetter;
    }

    /**
     * @param array $mappingSetter
     *
     * @return Mapping
     */
    public function setMappingSetter($mappingSetter)
    {
        $this->mappingSetter = $mappingSetter;

        return $this;
    }

    /**
     * @return array
     */
    public function getMappingKeyFields()
    {
        return $this->mappingKeyFields;
    }

    /**
     * @param array $mappingKeyFields
     *
     * @return Mapping
     */
    public function setMappingKeyFields($mappingKeyFields)
    {
        $this->mappingKeyFields = $mappingKeyFields;

        return $this;
    }

    /**
     * @return null
     */
    public function getUniqueKey()
    {
        return $this->uniqueKey;
    }

    /**
     * @param null $uniqueKey
     *
     * @return Mapping
     */
    public function setUniqueKey($uniqueKey)
    {
        $this->uniqueKey = $uniqueKey;

        return $this;
    }
}
