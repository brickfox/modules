<?php

namespace Bf\Saleschannel\Components\Gui;

use Bf\Saleschannel\Components\Util\Curl;
use Bf\Saleschannel\Components\Util\Helper;
use Doctrine\ORM\QueryBuilder;

/**
 * MappingAbstract
 *
 * @package Bf\Saleschannel\Components\Gui
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class MappingAbstract extends GuiAbstract
{
    const ATTRIBUTES_MAPPING_MODEL_Attributes_NAMESPACE  = 'Shopware\CustomModels\BfSaleschannel\MappingAttributes';
    const FILTERS_MAPPING_MODEL_FILTERS_NAMESPACE        = 'Shopware\CustomModels\BfSaleschannel\MappingFilters';
    const CUSTOMIZED_MAPPING_MODEL_CUSTOMIZED_NAMESPACE  = 'Shopware\CustomModels\BfSaleschannel\MappingCustomized';
    const ORDER_STATUS_MAPPING_MODEL_NAMESPACE           = 'Shopware\CustomModels\BfSaleschannel\MappingOrderStatus';
    const CURRENCIES_MAPPING_MODEL_NAMESPACE             = 'Shopware\CustomModels\BfSaleschannel\MappingCurrencies';
    const TRANSLATION_MAPPING_MODEL_NAMESPACE            = 'Shopware\CustomModels\BfSaleschannel\MappingTranslation';
    const SHOPS_MAPPING_MODEL_NAMESPACE                  = 'Shopware\CustomModels\BfSaleschannel\MappingShops';
    const TAX_MAPPING_MODEL_NAMESPACE                    = 'Shopware\CustomModels\BfSaleschannel\MappingTax';
    const SHIPPING_STATUS_MAPPING_MODEL_NAMESPACE        = 'Shopware\CustomModels\BfSaleschannel\MappingShippingStatus';
    const ORDER_ATTRIBUTES_MAPPING_MODEL_NAMESPACE       = 'Shopware\CustomModels\BfSaleschannel\MappingOrderAttributes';
    const IMAGES_ATTRIBUTES_MAPPING_MODEL_NAMESPACE      = 'Shopware\CustomModels\BfSaleschannel\MappingImageAttributes';
    const ORDER_LINES_ATTRIBUTES_MAPPING_MODEL_NAMESPACE = 'Shopware\CustomModels\BfSaleschannel\MappingOrderLinesAttributes';
    const PAYMENT_TO_PAYMENT_STATUS_MODEL_NAMESPACE      = 'Shopware\CustomModels\BfSaleschannel\MappingPaymentMethodToPaymentStatus';
    const ORDER_EXPORT_BY_PAYMENT_STATUS_NAMESPACE       = 'Shopware\CustomModels\BfSaleschannel\MappingOrderExportByPaymentStatus';
    const ATTRIBUTES_CODE_FIELD_KEY                      = 'bfAttributesCodeField';
    const ATTRIBUTES_SW_FIELD_KEY                        = 'swFieldKey';
    const MAPPING_ID_FIELD_KEY                           = 'id';
    const HELPER_CLASS_NAMESPACE                         = 'Bf\Saleschannel\Components\Util\Helper';
    const HELPER_CLASS_METHOD_NAME                       = 'getMappingById';

    /**
     * @return array
     */
    public static function getNewAttributesMappingGetter()
    {
        return array(
            'preLoad' => array(
                'className'      => self::HELPER_CLASS_NAMESPACE,
                'methodName'     => self::HELPER_CLASS_METHOD_NAME,
                'uniqueKey'      => self::MAPPING_ID_FIELD_KEY,
                'modelNamespace' => self::ATTRIBUTES_MAPPING_MODEL_Attributes_NAMESPACE
            )
        );
    }

    /**
     * @return array
     */
    public static function getNewFiltersMappingGetter()
    {
        return array(
            'preLoad' => array(
                'className'      => self::HELPER_CLASS_NAMESPACE,
                'methodName'     => self::HELPER_CLASS_METHOD_NAME,
                'uniqueKey'      => self::MAPPING_ID_FIELD_KEY,
                'modelNamespace' => self::FILTERS_MAPPING_MODEL_FILTERS_NAMESPACE
            )
        );
    }

    /**
     * @return array
     */
    public static function getCustomizedMappingGetter()
    {
        return array(
            'preLoad' => array(
                'className'      => self::HELPER_CLASS_NAMESPACE,
                'methodName'     => self::HELPER_CLASS_METHOD_NAME,
                'uniqueKey'      => self::MAPPING_ID_FIELD_KEY,
                'modelNamespace' => self::CUSTOMIZED_MAPPING_MODEL_CUSTOMIZED_NAMESPACE
            )
        );
    }

    /**
     * @return array
     */
    public static function getOrderStatusMappingGetter()
    {
        return array(
            'preLoad' => array(
                'className'      => self::HELPER_CLASS_NAMESPACE,
                'methodName'     => self::HELPER_CLASS_METHOD_NAME,
                'uniqueKey'      => self::MAPPING_ID_FIELD_KEY,
                'modelNamespace' => self::ORDER_STATUS_MAPPING_MODEL_NAMESPACE
            )
        );
    }

    /**
     * @return array
     */
    public static function getCurrenciesMappingGetter()
    {
        return array(
            'preLoad' => array(
                'className'      => self::HELPER_CLASS_NAMESPACE,
                'methodName'     => self::HELPER_CLASS_METHOD_NAME,
                'uniqueKey'      => self::MAPPING_ID_FIELD_KEY,
                'modelNamespace' => self::CURRENCIES_MAPPING_MODEL_NAMESPACE
            )
        );
    }

    /**
     * @return array
     */
    public static function getTaxMappingGetter()
    {
        return array(
            'preLoad' => array(
                'className'      => self::HELPER_CLASS_NAMESPACE,
                'methodName'     => self::HELPER_CLASS_METHOD_NAME,
                'uniqueKey'      => self::MAPPING_ID_FIELD_KEY,
                'modelNamespace' => self::TAX_MAPPING_MODEL_NAMESPACE
            )
        );
    }

    /**
     * @return array
     */
    public static function getShippingStatusMappingGetter()
    {
        return array(
            'preLoad' => array(
                'className'      => self::HELPER_CLASS_NAMESPACE,
                'methodName'     => self::HELPER_CLASS_METHOD_NAME,
                'uniqueKey'      => self::MAPPING_ID_FIELD_KEY,
                'modelNamespace' => self::SHIPPING_STATUS_MAPPING_MODEL_NAMESPACE
            )
        );
    }

    /**
     * @return array
     */
    public static function getOrderAttributesMappingGetter()
    {
        return array(
            'preLoad' => array(
                'className'      => self::HELPER_CLASS_NAMESPACE,
                'methodName'     => self::HELPER_CLASS_METHOD_NAME,
                'uniqueKey'      => self::MAPPING_ID_FIELD_KEY,
                'modelNamespace' => self::ORDER_ATTRIBUTES_MAPPING_MODEL_NAMESPACE
            )
        );
    }

    /**
     * @return array
     */
    public static function getImageAttributesMappingGetter()
    {
        return array(
            'preLoad' => array(
                'className'      => self::HELPER_CLASS_NAMESPACE,
                'methodName'     => self::HELPER_CLASS_METHOD_NAME,
                'uniqueKey'      => self::MAPPING_ID_FIELD_KEY,
                'modelNamespace' => self::IMAGES_ATTRIBUTES_MAPPING_MODEL_NAMESPACE
            )
        );
    }

    /**
     * @return array
     */
    public static function getOrderLinesAttributesMappingGetter()
    {
        return array(
            'preLoad' => array(
                'className'      => self::HELPER_CLASS_NAMESPACE,
                'methodName'     => self::HELPER_CLASS_METHOD_NAME,
                'uniqueKey'      => self::MAPPING_ID_FIELD_KEY,
                'modelNamespace' => self::ORDER_LINES_ATTRIBUTES_MAPPING_MODEL_NAMESPACE
            )
        );
    }

    public static function getPaymentMethodToPaymentStatusMappingGetter()
    {
        return array(
            'preLoad' => array(
                'className'      => self::HELPER_CLASS_NAMESPACE,
                'methodName'     => self::HELPER_CLASS_METHOD_NAME,
                'uniqueKey'      => self::MAPPING_ID_FIELD_KEY,
                'modelNamespace' => self::PAYMENT_TO_PAYMENT_STATUS_MODEL_NAMESPACE
            )
        );
    }

    public static function getOrderExportByPaymentStatusMappingGetter()
    {
        return array(
            'preLoad' => array(
                'className'      => self::HELPER_CLASS_NAMESPACE,
                'methodName'     => self::HELPER_CLASS_METHOD_NAME,
                'uniqueKey'      => self::MAPPING_ID_FIELD_KEY,
                'modelNamespace' => self::ORDER_EXPORT_BY_PAYMENT_STATUS_NAMESPACE
            )
        );
    }

    /**
     * @return array
     */
    public static function getTranslationMappingGetter()
    {
        return array(
            'preLoad' => array(
                'className'      => self::HELPER_CLASS_NAMESPACE,
                'methodName'     => self::HELPER_CLASS_METHOD_NAME,
                'uniqueKey'      => self::MAPPING_ID_FIELD_KEY,
                'modelNamespace' => self::TRANSLATION_MAPPING_MODEL_NAMESPACE
            )
        );
    }

    /**
     * @return array
     */
    public static function getShopsMappingGetter()
    {
        return array(
            'preLoad' => array(
                'className'      => self::HELPER_CLASS_NAMESPACE,
                'methodName'     => self::HELPER_CLASS_METHOD_NAME,
                'uniqueKey'      => self::MAPPING_ID_FIELD_KEY,
                'modelNamespace' => self::SHOPS_MAPPING_MODEL_NAMESPACE
            )
        );
    }

    /**
     * @return array
     */
    public static function getNewAttributesMappingSetter()
    {
        return array(
            'attributesCode'  => '',
            'mappingFieldKey' => '',
            'id'              => ''
        );
    }

    /**
     * @return array
     */
    public static function getNewFiltersMappingSetter()
    {
        return array(
            'attributesCode' => '',
            'id'             => ''
        );
    }

    /**
     * @return array
     */
    public static function getCustomizedMappingSetter()
    {
        return array(
            'xmlTag'          => '',
            'mappingFieldKey' => '',
            'id'              => ''
        );
    }

    /**
     * @return array
     */
    public static function getCurrenciesMappingSetter()
    {
        return array(
            'brickfoxCurrenciesCode' => '',
            'mappingFieldKey'        => '',
            'id'                     => ''
        );
    }

    /**
     * @return array
     */
    public static function getTaxMappingSetter()
    {
        return array(
            'brickfoxTaxId'   => '',
            'mappingFieldKey' => '',
            'id'              => ''
        );
    }

    /**
     * @return array
     */
    public static function getShippingStatusMappingSetter()
    {
        return array(
            'brickfoxShippingStatusCode' => '',
            'mappingFieldKey'            => '',
            'id'                         => ''
        );
    }

    public static function getOrderAttributesMappingSetter()
    {
        return array(
            'shopwareColumnName' => '',
            'brickfoxExportName' => '',
            'id'                 => ''
        );
    }

    public static function getImageAttributesMappingSetter()
    {
        return array(
            'attributesCode' => '',
            'mappingFieldKey' => '',
            'id'                 => ''
        );
    }

    public static function getOrderLinesAttributesMappingSetter()
    {
        return array(
            'shopwareColumnName' => '',
            'brickfoxExportName' => '',
            'id'                 => ''
        );
    }

    /**
     * @return array
     */
    public static function getPaymentMethodToPaymentStatusSetter()
    {
        return array(
            'paymentId'       => '',
            'paymentStatusId' => '',
            'id'              => ''
        );
    }

    /**
     * @return array
     */
    public static function getOrderExportByPaymentStatusSetter()
    {
        return array(
            'paymentId'       => '',
            'paymentStatusId' => '',
            'id'              => ''
        );
    }

    /**
     * @return array
     */
    public static function getTranslationMappingSetter()
    {
        return array(
            'brickfoxIsoCode' => '',
            'mappingFieldKey' => '',
            'id'              => ''
        );
    }

    public static function getShopsMappingSetter()
    {
        return array(
            'brickfoxId' => '',
            'shopwareId' => '',
            'id'         => '',
            'isMasterShop' => ''
        );
    }

    /**
     * @return array
     */
    public static function getNewAttributesMappingKeyFields()
    {
        return array(
            self::ATTRIBUTES_CODE_FIELD_KEY,
            self::ATTRIBUTES_SW_FIELD_KEY,
            self::MAPPING_ID_FIELD_KEY
        );
    }

    /**
     * @param QueryBuilder $qb
     * @param $mappingModel
     * @param $filter
     *
     * @return QueryBuilder
     */
    protected function mappingFilterCondition(QueryBuilder $qb, $mappingModel, $filter)
    {
        switch ($mappingModel) {
            case 'Shopware\CustomModels\BfSaleschannel\MappingAttributes':
                $qb = $this->getMappingConditionsForMappingAttributes($qb, $filter);
                break;

            case 'Shopware\CustomModels\BfSaleschannel\MappingCustomized':
                $qb = $this->getMappingConditionsForMappingCustomized($qb, $filter);
                break;
            default:
                break;
        }

        return $qb;
    }

    /**
     * @param QueryBuilder $qb
     * @param $filter
     *
     * @return QueryBuilder
     */
    final private function getMappingConditionsForMappingAttributes(QueryBuilder $qb, $filter)
    {
        $qb->where('LOWER(mapping.attributesCode) LIKE :attributesCode')->orWhere('LOWER(mapping.mappingFieldKey) LIKE :mappingKeyField')->setParameters(array(
            'attributesCode'  => '%' . strtolower($filter[0]['value']) . '%',
            'mappingKeyField' => '%' . strtolower($filter[0]['value']) . '%'
        ));

        return $qb;
    }

    /**
     * @param QueryBuilder $qb
     * @param $filter
     *
     * @return QueryBuilder
     */
    final private function getMappingConditionsForMappingCustomized(QueryBuilder $qb, $filter)
    {
        $qb->where('LOWER(mapping.xmlTag) LIKE :xmlTag')->orWhere('LOWER(mapping.mappingFieldKey) LIKE :mappingKeyField')->setParameters(array(
            'xmlTag'          => '%' . strtolower($filter[0]['value']) . '%',
            'mappingKeyField' => '%' . strtolower($filter[0]['value']) . '%'
        ));

        return $qb;
    }

    //@todo add filter for the other mapping guis

    /**
     * @param null $restCall
     * @param null $param
     * @param null $mode
     *
     * @return array
     */
    public static function getBrickfoxConfigurationMappingFieldKeys($restCall = null, $param = null, $mode = null)
    {
        $result = array();

        if ($restCall !== null && $param !== null) {
            $curl       = self::getCurlClass($restCall, $param);
            $curlResult = json_decode($curl->get());

            if ((int)$curlResult->totalCount !== 0) {
                switch ($mode) {
                    case 'currencies':
                        $configurationValueList = array((string)$curlResult->data[0]->currenciesCode);
                        break;

                    case 'languages':
                        $configurationValueList = array((string)$curlResult->data[0]->code);
                        break;

                    default:
                        $configurationValueList = explode(',', (string)$curlResult->data[0]->configurationValue);
                        break;
                }

                foreach ($configurationValueList as $value) {
                    $result[] = array(
                        'brickfoxFieldKeyName' => $value,
                        'brickfoxFieldKeyCode' => $value
                    );
                }
            }
        }

        return $result;
    }

    /**
     * @param null $restCall
     * @param array $param
     *
     * @return array
     */
    public static function getBrickfoxMappingFieldKeys($restCall = null, array $param)
    {
        $result = array();

        if ($restCall !== null) {
            $curl       = self::getCurlClass($restCall, $param);
            $curlResult = json_decode($curl->get());

            if ((int)$curlResult->totalCount !== 0) {
                $result['count'] = (int)$curlResult->totalCount;
                foreach (self::getDataContainerInfos($restCall, $curlResult->data) as $id => $value) {
                    switch ($restCall) {
                        case \Shopware_Controllers_Backend_BrickfoxUi::REST_CALL_ATTRIBUTES:
                            $result['data'][] = array(
                                'brickfoxFieldKeyName' => $value,
                                'brickfoxFieldKeyCode' => $value
                            );
                            break;

                        case \Shopware_Controllers_Backend_BrickfoxUi::REST_CALL_SHOPS:
                            $result['data'][] = array(
                                'brickfoxFieldKeyName' => $value,
                                'brickfoxFieldKeyCode' => $id
                            );
                            break;

                        case \Shopware_Controllers_Backend_BrickfoxUi::REST_CALL_TAX:
                            $result['data'][] = array(
                                'brickfoxFieldKeyName' => $value,
                                'brickfoxFieldKeyCode' => $id
                            );
                            break;

                        case \Shopware_Controllers_Backend_BrickfoxUi::REST_CALL_SHIPPING_STATUS:
                            $result['data'][] = array(
                                'brickfoxFieldKeyName' => $value,
                                'brickfoxFieldKeyCode' => $value
                            );
                            break;
                    }
                }
            }
        }

        return $result;
    }

    /**
     * @param $restCall
     * @param array $data
     *
     * @return \Generator
     */
    final private function getDataContainerInfos($restCall, $data = array())
    {
        $dataContainerInfos = array();

        foreach ($data as $container) {
            switch ($restCall) {
                case \Shopware_Controllers_Backend_BrickfoxUi::REST_CALL_ATTRIBUTES:
                    $dataContainerInfos[] = (string)$container->productsAttributesCode;
                    break;

                case \Shopware_Controllers_Backend_BrickfoxUi::REST_CALL_SHOPS:
                    $dataContainerInfos[(int)$container->shopsId] = (string)$container->shopsName;
                    break;

                case \Shopware_Controllers_Backend_BrickfoxUi::REST_CALL_TAX:
                    $dataContainerInfos[(int)$container->taxCategoriesId] = (string)$container->name;
                    break;

                case \Shopware_Controllers_Backend_BrickfoxUi::REST_CALL_SHIPPING_STATUS:
                    $dataContainerInfos[(string)$container->ordersStatusCode] = (string)$container->ordersStatusCode;
                    break;
            }
        }

        return $dataContainerInfos;
    }

    /**
     * @param null $restCall
     * @param string $param
     *
     * @return Curl
     */
    final private function getCurlClass($restCall = null, $param = '')
    {
        return $curl = new Curl(Helper::getConfigurationByKey('brickfoxCustomerUrl')->getConfigurationValue(),
            Helper::getConfigurationByKey('brickfoxApiKey')->getConfigurationValue(), $restCall, $param);
    }

    /**
     * @param $filter
     * @param string $renamedFilterProperty
     *
     * @return string
     */
    public static function getFilter($filter, $renamedFilterProperty = '')
    {
        if (trim($renamedFilterProperty) !== '') {
            $filter[0]['property'] = $renamedFilterProperty;
        }

        $filter = '[{"property":"' . $filter[0]['property'] . '", "value":"' . $filter[0]['value'] . '"}]';
        $filter = urlencode($filter);

        return $filter;
    }
}