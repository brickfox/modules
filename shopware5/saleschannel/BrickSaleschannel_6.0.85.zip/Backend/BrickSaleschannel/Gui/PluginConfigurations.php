<?php

namespace Bf\Saleschannel\Components\Gui;

use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Doctrine\ORM\Query;
use Exception;
use Shopware\CustomModels\BfSaleschannel\Configuration;
use Shopware\CustomModels\BfSaleschannel\Log;

/**
 * PluginConfigurations
 *
 * @package Bf\Saleschannel\Components\Gui
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2020 brickfox GmbH http://www.brickfox.de
 */
class PluginConfigurations extends GuiAbstract
{
    const ADDED_CONFIGURATION_SUCCESSFUL   = 'Konfiguration wurde erfolgreich gespeichert. <br /> <b>Key: {$key}, Value: {$value}</b>';
    const CHANGED_CONFIGURATION_SUCCESSFUL = 'Konfiguration wurde erfolgreich aktualisiert. <br /> <b>Key: {$key}, Value: {$value}</b>';

    /**
     * @return array
     */
    final public function getSwUvpOrSpecialPrice()
    {
        return [[1, 'Shopware UVP = Brickfox UVP'], [2, 'Shopware UVP = Brickfox Sonderpreis'], [3, 'Shopware Pseudopreis ignorieren']];
    }

    /**
     * @return array
     */
    final public function getShops()
    {
        $returnValue = [];

        $shops = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop')->findAll();

        foreach ($shops as $shop) {
            $returnValue[] = [$shop->getId(), $shop->getName()];
        }

        return $returnValue;
    }

    /**
     * @return array
     */
    final public function getPluginModesAsArray()
    {
        return [['pluginMode' => 'swPIM', 'name' => 'Shopware ist PIM'], ['pluginMode' => 'bfPIM', 'name' => 'Brickfox ist PIM']];
    }

    /**
     * @return array
     */
    final public function getYesOrNoAnswer()
    {
        return [['logging' => 'true', 'name' => 'Ja'], ['logging' => 'false', 'name' => 'Nein']];
    }

    /**
     * @return array
     */
    final public function loadPluginConfiguration()
    {
        $returnValue = [
            'error' => false
        ];

        try {
            $qb = $this->getQueryBuilder();
            $qb->select(['config'])
                ->from('Shopware\CustomModels\BfSaleschannel\Configuration', 'config')
                ->where('config.configurationKey = :incomingPath')
                ->orWhere('config.configurationKey = :outgoingPath')
                ->orWhere('config.configurationKey = :pluginMode')
                ->orWhere('config.configurationKey = :logging')
                ->orWhere('config.configurationKey = :logPath')
                ->orWhere('config.configurationKey = :variationTemplateId')
                ->orWhere('config.configurationKey = :masterShopName')
                ->orWhere('config.configurationKey = :brickfoxApiKey')
                ->orWhere('config.configurationKey = :brickfoxCustomerUrl')
                ->orWhere('config.configurationKey = :useOnlyVariationsItemNumbers')
                ->orWhere('config.configurationKey = :multiAttributesSymbol')
                ->orWhere('config.configurationKey = :scriptLogger')
                ->orWhere('config.configurationKey = :orderStatusMultiSelect')
                ->orWhere('config.configurationKey = :ignoreOrdersByShopsIds')
                ->orWhere('config.configurationKey = :overWriteMetaElements')
                ->orWhere('config.configurationKey = :mainLanguagesCode')
                ->orWhere('config.configurationKey = :sendMail')
                ->orWhere('config.configurationKey = :defaultCustomerGroup')
                ->orWhere('config.configurationKey = :imagePath')
                ->orWhere('config.configurationKey = :urlDescriptionActive')
                ->orWhere('config.configurationKey = :imageUrlWithoutExtension')
                ->orWhere('config.configurationKey = :ignoreCategoriesImportFromMultiShop')
                ->orWhere('config.configurationKey = :cleanApiAfterDays')
                ->orWhere('config.configurationKey = :cleanBfLogAfterDays')
                ->orWhere('config.configurationKey = :cleanBfScriptloggerAfterDays')
                ->orWhere('config.configurationKey = :categoryDenormalization')
                ->orWhere('config.configurationKey = :serverProtocol')
                ->orWhere('config.configurationKey = :ignoreImagesImport')
                ->orWhere('config.configurationKey = :keepMissingImagesInImport')
                ->orWhere('config.configurationKey = :releaseDateFromAttribute')
                ->orWhere('config.configurationKey = :shippingFreeFromAttribute')
                ->orWhere('config.configurationKey = :sendPendingMail')
                ->orWhere('config.configurationKey = :costChangingAsCoupon')
                ->orWhere('config.configurationKey = :sortOrderAttributes')
                ->orWhere('config.configurationKey = :imageMappingDiffsOptionsStatus')
                ->orWhere('config.configurationKey = :imageMappingDiffsOptions')
                ->orWhere('config.configurationKey = :packageOrMeasurementId')
                ->orWhere('config.configurationKey = :commentId')
                ->orWhere('config.configurationKey = :strikeThroughPriceRulesId')
                ->orWhere('config.configurationKey = :ignoreDelivery')
                ->orWhere('config.configurationKey = :createDateCode')
                ->orWhere('config.configurationKey = :keepAttributesOnImport')
                ->orWhere('config.configurationKey = :exportTaxesForNetOrders')
                ->orWhere('config.configurationKey = :disableBfPriceUpdates')
                ->orWhere('config.configurationKey = :imageDescriptionAttributeName')
                ->orWhere('config.configurationKey = :carrierAttributeFieldName')
                ->orWhere('config.configurationKey = :excludeCustomerGroupAttributeFieldCode')
                ->orWhere('config.configurationKey = :enableEmailNotificationsOnError')
                ->orWhere('config.configurationKey = :emailNotificationErrorCodes')
                ->orWhere('config.configurationKey = :emailNotificationReceivers')
                ->orWhere('config.configurationKey = :ignoreLongDescription')
                ->orWhere('config.configurationKey = :surchargeCodes')
                ->orWhere('config.configurationKey = :emailNotificationCode')
                ->orWhere('config.configurationKey = :preventPriceModelsRewrite')
                ->orWhere('config.configurationKey = :savingOptionCodeAttributeFieldName')
                ->setParameters([
                    'incomingPath'                           => 'incomingPath',
                    'outgoingPath'                           => 'outgoingPath',
                    'pluginMode'                             => 'pluginMode',
                    'logging'                                => 'logging',
                    'logPath'                                => 'logPath',
                    'variationTemplateId'                    => 'variationTemplateId',
                    'masterShopName'                         => 'masterShopName',
                    'brickfoxCustomerUrl'                    => 'brickfoxCustomerUrl',
                    'brickfoxApiKey'                         => 'brickfoxApiKey',
                    'useOnlyVariationsItemNumbers'           => 'useOnlyVariationsItemNumbers',
                    'multiAttributesSymbol'                  => 'multiAttributesSymbol',
                    'scriptLogger'                           => 'scriptLogger',
                    'orderStatusMultiSelect'                 => 'orderStatusMultiSelect',
                    'ignoreOrdersByShopsIds'                 => 'ignoreOrdersByShopsIds',
                    'overWriteMetaElements'                  => 'overWriteMetaElements',
                    'mainLanguagesCode'                      => 'mainLanguagesCode',
                    'sendMail'                               => 'sendMail',
                    'defaultCustomerGroup'                   => 'defaultCustomerGroup',
                    'imagePath'                              => 'imagePath',
                    'urlDescriptionActive'                   => 'urlDescriptionActive',
                    'imageUrlWithoutExtension'               => 'imageUrlWithoutExtension',
                    'ignoreCategoriesImportFromMultiShop'    => 'ignoreCategoriesImportFromMultiShop',
                    'cleanApiAfterDays'                      => 'cleanApiAfterDays',
                    'cleanBfLogAfterDays'                    => 'cleanBfLogAfterDays',
                    'cleanBfScriptloggerAfterDays'           => 'cleanBfScriptloggerAfterDays',
                    'categoryDenormalization'                => 'categoryDenormalization',
                    'serverProtocol'                         => 'serverProtocol',
                    'ignoreImagesImport'                     => 'ignoreImagesImport',
                    'keepMissingImagesInImport'              => 'keepMissingImagesInImport',
                    'releaseDateFromAttribute'               => 'releaseDateFromAttribute',
                    'shippingFreeFromAttribute'              => 'shippingFreeFromAttribute',
                    'sendPendingMail'                        => 'sendPendingMail',
                    'costChangingAsCoupon'                   => 'costChangingAsCoupon',
                    'sortOrderAttributes'                    => 'sortOrderAttributes',
                    'imageMappingDiffsOptionsStatus'         => 'imageMappingDiffsOptionsStatus',
                    'imageMappingDiffsOptions'               => 'imageMappingDiffsOptions',
                    'packageOrMeasurementId'                 => 'packageOrMeasurementId',
                    'commentId'                              => 'commentId',
                    'strikeThroughPriceRulesId'              => 'strikeThroughPriceRulesId',
                    'ignoreDelivery'                         => 'ignoreDelivery',
                    'createDateCode'                         => 'createDateCode',
                    'keepAttributesOnImport'                 => 'keepAttributesOnImport',
                    'exportTaxesForNetOrders'                => 'exportTaxesForNetOrders',
                    'disableBfPriceUpdates'                  => 'disableBfPriceUpdates',
                    'imageDescriptionAttributeName'          => 'imageDescriptionAttributeName',
                    'carrierAttributeFieldName'              => 'carrierAttributeFieldName',
                    'excludeCustomerGroupAttributeFieldCode' => 'excludeCustomerGroupAttributeFieldCode',
                    'enableEmailNotificationsOnError'        => 'enableEmailNotificationsOnError',
                    'emailNotificationErrorCodes'            => 'emailNotificationErrorCodes',
                    'emailNotificationReceivers'             => 'emailNotificationReceivers',
                    'ignoreLongDescription'                  => 'ignoreLongDescription',
                    'surchargeCodes'                         => 'surchargeCodes',
                    'emailNotificationCode'                  => 'emailNotificationCode',
                    'preventPriceModelsRewrite'              => 'preventPriceModelsRewrite',
                    'savingOptionCodeAttributeFieldName'           => 'savingOptionCodeAttributeFieldName',
                ]);

            $sql           = $qb->getQuery();
            $configuration = $sql->getArrayResult();

            foreach ($configuration as $key => $array) {
                switch ($array['configurationKey']) {
                    case 'orderStatusMultiSelect':
                        $orderStatusMultiSelectId = explode(',', $array['configurationValue']);

                        foreach ($orderStatusMultiSelectId as $index => $element) {
                            $orderStatusMultiSelectId[$index] = $element;
                        }

                        $returnValue['orderStatusMultiSelectId'] = $orderStatusMultiSelectId;
                        break;
                    default:
                        $returnValue[$array['configurationKey']] = $array['configurationValue'];
                        break;
                }
            }
        } catch (Exception $e) {
            Helper::fromArray(new Log(), [
                Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                Logging::SETTER_ALIAS_LOG_MESSAGE => $e->getMessage(),
                Logging::SETTER_ALIAS_USER        => Helper::getUserId()
            ]);

            $returnValue['error'] = true;
        }

        return $returnValue;
    }

    /**
     * @param array $configurationData
     * @return bool
     */
    public function savePluginConfiguration(array $configurationData = [])
    {
        $returnValue = true;

        try {
            if (array_key_exists('ignoreLongDescription', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('ignoreLongDescription', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }
            if (array_key_exists('ignoreDelivery', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('ignoreDelivery', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('sortOrderAttributes', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('sortOrderAttributes', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('imageMappingDiffsOptionsStatus', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('imageMappingDiffsOptionsStatus', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('costChangingAsCoupon', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('costChangingAsCoupon', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('sendPendingMail', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('sendPendingMail', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('sendMail', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('sendMail', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('ignoreImagesImport', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('ignoreImagesImport', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('keepMissingImagesInImport', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('keepMissingImagesInImport', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('serverProtocol', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('serverProtocol', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('urlDescriptionActive', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('urlDescriptionActive', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('imageUrlWithoutExtension', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('imageUrlWithoutExtension', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('ignoreCategoriesImportFromMultiShop', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('ignoreCategoriesImportFromMultiShop', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('categoryDenormalization', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('categoryDenormalization', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('useOnlyVariationsItemNumbers', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('useOnlyVariationsItemNumbers', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('overWriteMetaElements', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('overWriteMetaElements', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('exportTaxesForNetOrders', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('exportTaxesForNetOrders', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            if (array_key_exists('disableBfPriceUpdates', $configurationData) === false) {
                $configurationModel = Helper::getMappingByValue('disableBfPriceUpdates', 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                if ($configurationModel !== null) {
                    $configurationModel->setConfigurationValue('false');

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }

            foreach ($configurationData as $key => $value) {
                if ($value === 'on') {
                    $value = 'true';
                }

                if ($key === 'orderStatusMultiSelect') {
                    $value = implode(',', $value);
                }

                if (strlen($key) > 0) {
                    /** @var Configuration $configurationModel */
                    $configurationModel = Helper::getMappingByValue($key, 'configurationKey', 'Shopware\CustomModels\BfSaleschannel\Configuration');

                    if ($configurationModel === null) {
                        $configurationModel = new Configuration();
                        $configurationModel->setConfigurationKey($key);
                        $configurationModel->setConfigurationValue($value);

                        Helper::fromArray(new Log(), [
                            Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_SUCCESS,
                            Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                            Logging::SETTER_ALIAS_LOG_MESSAGE => str_replace(['{$key}', '{$value}'], [$key, $value], self::ADDED_CONFIGURATION_SUCCESSFUL),
                            Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                        ]);
                    } else {
                        $configurationModel->setConfigurationValue($value);

                        Helper::fromArray(new Log(), [
                            Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_SUCCESS,
                            Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                            Logging::SETTER_ALIAS_LOG_MESSAGE => str_replace(['{$key}', '{$value}'], [$key, $value], self::CHANGED_CONFIGURATION_SUCCESSFUL),
                            Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                        ]);
                    }

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush($configurationModel);
                }
            }
        } catch (Exception $e) {
            Helper::fromArray(new Log(), [
                Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                Logging::SETTER_ALIAS_LOG_MESSAGE => $e->getMessage(),
                Logging::SETTER_ALIAS_USER        => Helper::getUserId()
            ]);

            $returnValue = false;
        }

        return $returnValue;
    }

    /**
     */
    final public function installDefaultPluginConfiguration()
    {
        try {
            $builder = Shopware()->Models()->createQueryBuilder();
            $builder->select('SUBSTRING(locale.locale,1,2)')->from('Shopware\Models\Shop\Shop', 'shop')->innerJoin('shop.locale', 'locale')->where('shop.default = 1');

            Shopware()->Db()->query("
                    INSERT INTO bf_configuration (`configuration_key`, `configuration_value`)
                    VALUES
                      ('incomingPath', 'uploads/brickfox/in/'),
                      ('outgoingPath', 'uploads/brickfox/out/'),
                      ('imagePath', 'uploads/brickfox/image/'),
                      ('logging', 'true'),
                      ('logPath', 'uploads/brickfox/logs/'),
                      ('variationTemplateId', 0),
                      ('masterShopName', ''),
                      ('brickfoxCustomerUrl', ''),
                      ('brickfoxApiKey', ''),
                      ('useOnlyVariationsItemNumbers', 'false'),
                      ('multiAttributesSymbol', ','),
                      ('scriptLogger', '4'),
                      ('orderStatusMultiSelect', '0'),
                      ('overWriteMetaElements', 'true'),
                      ('mainLanguagesCode', '" . $builder->getQuery()->getOneOrNullResult(Query::HYDRATE_SINGLE_SCALAR) . "'),
                      ('sendMail', 'false'),
                      ('defaultCustomerGroup', 'EK'),
                      ('imageUrlWithoutExtension', 'false'),
                      ('urlDescriptionActive', 'false'),
                      ('cleanApiAfterDays', '14'),
                      ('cleanBfLogAfterDays', '60'),
                      ('cleanBfScriptloggerAfterDays', '14'),
                      ('ignoreCategoriesImportFromMultiShop', 'false'),
                      ('categoryDenormalization', 'false'),
                      ('serverProtocol', 'false'),
                      ('ignoreImagesImport', 'false'),
                      ('keepMissingImagesInImport', 'false'),
                      ('releaseDateFromAttribute', ''),
                      ('shippingFreeFromAttribute', ''),
                      ('carrierAttributeFieldName', ''),
                      ('orderAttributes', ''),
                      ('costChangingAsCoupon', 'false'),
                      ('sortOrderAttributes', 'false'),
                      ('imageMappingDiffsOptionsStatus', 'false'),
                      ('imageMappingDiffsOptions', ''),
                      ('packageOrMeasurementId', 1),
                      ('commentId', 'getComment'),
                      ('strikeThroughPriceRulesId', 1),
                      ('ignoreDelivery', 'false'),
                      ('sendPendingMail', 'false'),
                      ('createDateCode', ''),
                      ('keepAttributesOnImport', ''),
                      ('exportTaxesForNetOrders', ''),
                      ('disableBfPriceUpdates', 'false'),
                      ('ignoreOrdersByShopsIds', ''),
                      ('ignoreLongDescription', 'false'),
                      ('surchargeCodes', ''),
                      ('emailNotificationCode', ''),
                      ('preventPriceModelsRewrite', 'false'),
                      ('savingOptionCodeAttributeFieldName', '')
                ");
        } catch (Exception $e) {
            Helper::fromArray(new Log(), [
                Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::CAN_NOT_INSERT_DEFAULT_PLUGIN_CONFIGURATION_ERROR_CODE,
                Logging::SETTER_ALIAS_LOG_MESSAGE => ErrorCodes::CAN_NOT_INSERT_DEFAULT_PLUGIN_CONFIGURATION . $e->getMessage(),
                Logging::SETTER_ALIAS_USER        => Helper::getUserName()
            ]);
        }
    }

    /**
     * @return array
     */
    final public function getVariationTemplateDropDownValues()
    {
        return [
            ['variationTemplateName' => GuiAbstract::VARIATION_DROP_DOWN_STANDARD, 'variationTemplateId' => 0],
            ['variationTemplateName' => GuiAbstract::VARIATION_DROP_DOWN_CHOOSE, 'variationTemplateId' => 1],
            ['variationTemplateName' => GuiAbstract::VARIATION_DROP_DOWN_IMAGE, 'variationTemplateId' => 2]
        ];
    }

    /**
     * @return array
     */
    final public function getPackageOrMeasurementDropDownValues()
    {
        return [
            ['packageOrMeasurementId' => 1, 'packageOrMeasurementName' => GuiAbstract::MEASUREMENT_DROP_DOWN],
            ['packageOrMeasurementId' => 2, 'packageOrMeasurementName' => GuiAbstract::PACKAGE_DROP_DOWN]
        ];
    }

    /**
     * @return array
     */
    final public function getStrikeThroughPriceRulesDropDownValues()
    {
        return [
            ['strikeThroughPriceRulesId' => 1, 'strikeThroughPriceRulesName' => GuiAbstract::STRIKE_THROUGH_PRICE_RULES_1],
            ['strikeThroughPriceRulesId' => 2, 'strikeThroughPriceRulesName' => GuiAbstract::STRIKE_THROUGH_PRICE_RULES_2],
        ];
    }
}