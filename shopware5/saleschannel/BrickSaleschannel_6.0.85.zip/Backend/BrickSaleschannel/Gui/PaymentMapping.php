<?php
namespace Bf\Saleschannel\Components\Gui;

use Bf\Saleschannel\Components\Util\Helper;

/**
 * Class PaymentMapping
 *
 * @package Bf\Saleschannel\Components\Gui
 */
class PaymentMapping
{
    /**
     * @return array
     */
    public function getPaymentMappingFieldKeys()
    {
        $payments = array();

        $repository = Helper::getRepository('Shopware\Models\Payment\Payment');
        $paymentStateModel = $repository->findAll();

        if (count($paymentStateModel) > 0) {
            /** @var \Shopware\Models\Payment\Payment $paymentModel */
            foreach ($paymentStateModel as $paymentModel) {
                $payments[] = array(
                    'shopwareFieldKeyCode' => $paymentModel->getId(),
                    'shopwareFieldKeyName' => $paymentModel->getDescription()
                );
            }
        }

        return $payments;
    }
}