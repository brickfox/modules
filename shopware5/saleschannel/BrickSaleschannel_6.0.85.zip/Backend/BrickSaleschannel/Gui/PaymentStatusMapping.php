<?php
namespace Bf\Saleschannel\Components\Gui;

use Bf\Saleschannel\Components\Util\Helper;

/**
 * Class PaymentStatusMapping
 *
 * @package Bf\Saleschannel\Components\Gui
 */
class PaymentStatusMapping
{
    /**
     * @return array
     */
    public function getPaymentStatusMappingFieldKeys()
    {
        $status = array();

        /** @var \Shopware\Models\Order\Repository $repository */
        $repository = Helper::getRepository('Shopware\Models\Order\Order');
        $statusArray = $repository->getPaymentStatusQuery()->getArrayResult();

        if (count($statusArray) > 0) {
            foreach ($statusArray as $state) {
                $status[] = array(
                    'shopwareFieldKeyCode' => $state['id'],
                    'shopwareFieldKeyName' => $state['name']
                );
            }
        }

        return $status;
    }
}