<?php

namespace Bf\Saleschannel\Components\Gui;

/**
 * GuiAbstract
 *
 * @package Bf\Saleschannel\Components\Gui
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class GuiAbstract
{
    const DROP_DOWN_YES                        = 'ja';
    const DROP_DOWN_NO                         = 'nein';
    const CHECKBOX_ACTIVE                      = 'Aktiv';
    const CHECKBOX_NOT_ACTIVE                  = 'Nicht aktiv';
    const VARIATION_DROP_DOWN_STANDARD         = 'Standard';
    const VARIATION_DROP_DOWN_CHOOSE           = 'Auswahl';
    const VARIATION_DROP_DOWN_IMAGE            = 'Bild';
    const UNKNOWN_IMPORT_EXPORT_TIME           = 'unbekannt';
    const BF_INTERNAL_ERROR_LOADING_DATA_SET   = 'Brickfox internal error while loading data.';
    const ACTION_LOG_LIST                      = 'getLogListAction';
    const CONFIGURATION_KEY_VARIATION_TEMPLATE = 'variationTemplateId';
    const PACKAGE_DROP_DOWN                    = 'Verpackungsmaße';
    const MEASUREMENT_DROP_DOWN                = 'Artikelmaße';
    const STRIKE_THROUGH_PRICE_RULES_1         = 'Wenn Sonderpreis VK vor UVP als Pseudopreis';
    const STRIKE_THROUGH_PRICE_RULES_2         = 'Wenn Sonderpreis UVP vor VK als Pseudopreis';

    /**
     * @return \Doctrine\ORM\QueryBuilder|\Shopware\Components\Model\QueryBuilder
     */
    final protected function getQueryBuilder()
    {
        return Shopware()->Models()->createQueryBuilder();
    }
}
