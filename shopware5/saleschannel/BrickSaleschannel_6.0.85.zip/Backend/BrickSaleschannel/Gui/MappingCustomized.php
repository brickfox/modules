<?php
namespace Bf\Saleschannel\Components\Gui;

/**
 * MappingCustomized
 *
 * @package Bf\Saleschannel\Components\Gui
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class MappingCustomized
{
    /**
     * @return array
     */
    final public function getCustomizedMappingFieldKeys()
    {
        return array(
            array('mappingFieldKeyCode' => 'Article->description', 'mappingFieldKeyName' => 'Kurzbeschreibung'),
            array('mappingFieldKeyCode' => 'Article->keywords', 'mappingFieldKeyName' => 'Keywords'),
            array('mappingFieldKeyCode' => 'Article->metaTitle', 'mappingFieldKeyName' => 'Meta-Titel')
        );
    }
}
