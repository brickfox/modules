<?php
namespace Bf\Saleschannel\Components\Gui;

use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Doctrine\ORM\AbstractQuery;
use Doctrine\ORM\QueryBuilder;
use Doctrine\ORM\Tools\Pagination\Paginator;
use Exception;
use Shopware\CustomModels\BfSaleschannel\Log;

/**
 * Logging
 *
 * @package Bf\Saleschannel\Components\Gui
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Logging extends GuiAbstract
{
    const LOG_MODEL                = 'Shopware\CustomModels\BfSaleschannel\Log';
    const LOG_STATUS_FATAL         = 'Fatal Error';
    const LOG_STATUS_WARNING       = 'Warning';
    const LOG_STATUS_ERROR         = 'Error';
    const LOG_STATUS_SUCCESS       = 'Success';
    const SETTER_ALIAS_LOG_STATUS  = 'logStatus';
    const SETTER_ALIAS_ERROR_CODE  = 'errorCode';
    const SETTER_ALIAS_LOG_MESSAGE = 'logMessage';
    const SETTER_ALIAS_ACTION      = 'action';
    const SETTER_ALIAS_USER        = 'userName';
    const ID                       = 'id';

    /**
     * @param $start
     * @param $limit
     * @param $filter
     *
     * @return array
     */
    final public function loadLogs($start, $limit, $filter)
    {
        $return = array(
            'count' => '',
            'data'  => ''
        );

        try
        {
            $qb = $this->getQueryBuilder();
            $qb->select(array('log'))->from(self::LOG_MODEL, 'log');

            if($filter !== null)
            {
                $qb = $this->logFilterConditions($qb, $filter);
            }

            if((int) $limit !== 0)
            {
                $qb->setFirstResult($start)->setMaxResults($limit);
            }

            $sql = $qb->getQuery()->setHydrationMode(AbstractQuery::HYDRATE_ARRAY);

            $paginator = new Paginator($sql);

            $total = $paginator->count();
            $list  = $paginator->getIterator()->getArrayCopy();

            foreach($list as $key => $listElement)
            {
                $list[$key]['logMessageShort'] = mb_substr($listElement['logMessage'], 0, 25) . '...';
            }

            $return = array(
                'count' => $total,
                'data'  => $list
            );

        }
        catch(Exception $e)
        {
            LogManager::getInstance()->writeLogForGui(
                Log::LOG_STATUS_FATAL,
                __METHOD__,
                ErrorCodes::READING_LOG_LIST,
                Helper::getUserName(),
                Log::TYPE_OF_LOG_READING_LIST,
                ErrorCodes::READING_LOG_LIST_ERROR_CODE
            );
        }

        return $return;
    }

    /**
     * @param $params
     *
     * @return bool
     */
    final public function removeLoggingEntry($params)
    {
        $return = true;

        $arrayId = $this->getOneOrMoreLogging($params);

        try
        {
            foreach($arrayId as $key)
            {
                $model = $this->loadLogById($key[self::ID]);

                if($model !== null)
                {
                    Shopware()->Models()->remove($model);
                    Shopware()->Models()->flush($model);
                }
                else
                {
                    Helper::fromArray(
                        new Log(),
                        array(
                            self::SETTER_ALIAS_LOG_STATUS  => self::LOG_STATUS_FATAL,
                            self::SETTER_ALIAS_ACTION      => __METHOD__,
                            self::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::CAN_NOT_FIND_MODEL_BY_ID_ERROR_CODE,
                            self::SETTER_ALIAS_LOG_MESSAGE => str_replace('{$id}', $key[self::ID], ErrorCodes::CAN_NOT_FIND_MODEL_BY_ID)
                        )
                    );
                }
            }
        }
        catch(Exception $e)
        {
            Helper::fromArray(
                new Log(),
                array(
                    self::SETTER_ALIAS_LOG_STATUS  => self::LOG_STATUS_FATAL,
                    self::SETTER_ALIAS_ACTION      => __METHOD__,
                    self::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                    self::SETTER_ALIAS_LOG_MESSAGE => $e->getMessage()
                )
            );
        }

        return $return;
    }

    /**
     * @param $id
     *
     * @return null|object
     */
    final private function loadLogById($id)
    {
        $model = null;

        if(is_numeric($id) === true)
        {
            try
            {
                $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\Log');
                $model      = $repository->find($id);

                if($model === null)
                {
                    Helper::fromArray(
                        new Log(),
                        array(
                            self::SETTER_ALIAS_LOG_STATUS  => self::LOG_STATUS_FATAL,
                            self::SETTER_ALIAS_ACTION      => __METHOD__,
                            self::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::CAN_NOT_FIND_MODEL_BY_ID_ERROR_CODE,
                            self::SETTER_ALIAS_LOG_MESSAGE => str_replace('{$id}', $id, ErrorCodes::CAN_NOT_FIND_MODEL_BY_ID)
                        )
                    );
                }
            }
            catch(Exception $e)
            {
                Helper::fromArray(
                    new Log(),
                    array(
                        self::SETTER_ALIAS_LOG_STATUS  => self::LOG_STATUS_FATAL,
                        self::SETTER_ALIAS_ACTION      => __METHOD__,
                        self::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                        self::SETTER_ALIAS_LOG_MESSAGE => $e->getMessage()
                    )
                );
            }
        }

        return $model;
    }

    /**
     * @param $params
     *
     * @return array
     */
    final private function getOneOrMoreLogging($params)
    {
        $return = array();

        if(array_key_exists(self::ID, $params) === true)
        {
            $return[0][self::ID] = $params[self::ID];
        }
        else
        {
            $counter = 0;

            foreach($params as $key => $elements)
            {
                if(array_key_exists(self::ID, $elements) === true)
                {
                    $return[$counter][self::ID] = $elements[self::ID];
                }
                $counter++;
            }
        }

        return $return;
    }

    /**
     * @param QueryBuilder $qb
     * @param $filter
     *
     * @return QueryBuilder
     */
    final private function logFilterConditions(QueryBuilder $qb, $filter)
    {
        $qb->where('LOWER(log.logStatus) LIKE :logStatus')->orWhere('LOWER(log.errorCode) LIKE :errorCode')->orWhere('LOWER(log.logMessage) LIKE :logMessage')->setParameters(
            array(
                'logStatus'  => '%' . strtolower($filter[0]['value']) . '%',
                'errorCode'  => '%' . strtolower($filter[0]['value']) . '%',
                'logMessage' => '%' . strtolower($filter[0]['value']) . '%'
            )
        );

        return $qb;
    }
}
