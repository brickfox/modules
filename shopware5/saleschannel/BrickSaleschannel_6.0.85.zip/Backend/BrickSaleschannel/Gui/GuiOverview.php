<?php

namespace Bf\Saleschannel\Components\Gui;

use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Doctrine\ORM\NonUniqueResultException;
use Exception;
use Shopware\CustomModels\BfSaleschannel\Log;
use Shopware\CustomModels\BfSaleschannel\Scriptlogger;
use DateTime;

/**
 * Shopware_Controllers_Backend_BrickfoxUI
 * This file is part of brickfox.
 *
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */
class GuiOverview extends GuiAbstract
{
    const NO_INFORMATION = 'No information from the system.';

    /**
     * @return string
     */
    public function getPhpVersion()
    {
        return PHP_VERSION;
    }

    /**
     * @return string
     */
    public function getMemoryLimit()
    {
        try {
            $returnValue = ini_get('memory_limit');
        } catch (Exception $e) {
            $returnValue = self::NO_INFORMATION;
        }

        return $returnValue;
    }

    /**
     * @return string
     */
    public function getMaxExecutionTime()
    {
        try {
            $returnValue = ini_get('max_execution_time');
        } catch (Exception $e) {
            $returnValue = self::NO_INFORMATION;
        }

        return $returnValue;
    }

    /**
     * @return array
     */
    public function ConvertPluginConfigurationForOverviewDisplayFields()
    {
        $pluginConfigurationClass = new PluginConfigurations();
        $configuration            = $pluginConfigurationClass->loadPluginConfiguration();

        foreach ([
            'logging',
            'ignoreDelivery',
            'ignoreImagesImport',
            'keepMissingImagesInImport',
            'imageMappingDiffsOptionsStatus',
            'serverProtocol',
            'overWriteMetaElements',
            'sendPendingMail',
            'sortOrderAttributes',
            'costChangingAsCoupon',
            'sendMail',
            'urlDescriptionActive',
            'imageUrlWithoutExtension',
            'ignoreCategoriesImportFromMultiShop',
            'categoryDenormalization',
            'exportTaxesForNetOrders',
            'disableBfPriceUpdates',
            'enableEmailNotificationsOnError',
            'ignoreLongDescription',
            'preventPriceModelsRewrite'
        ] as $configurationKey) {
            $this->assignGuiYesNoForBooleanConfig($configuration, $configurationKey);
        }

        if (isset($configuration['variationTemplateId']) === true) {
            switch ($configuration['variationTemplateId']) {
                case 0:
                    $configuration['variationTemplateId'] = GuiAbstract::VARIATION_DROP_DOWN_STANDARD;
                    break;

                case 1:
                    $configuration['variationTemplateId'] = GuiAbstract::VARIATION_DROP_DOWN_CHOOSE;
                    break;

                case 2:
                    $configuration['variationTemplateId'] = GuiAbstract::VARIATION_DROP_DOWN_IMAGE;
                    break;

                default:
                    break;
            }
        }

        if (isset($configuration['packageOrMeasurementId']) === true) {
            switch ($configuration['packageOrMeasurementId']) {
                case 1:
                    $configuration['packageOrMeasurementId'] = GuiAbstract::MEASUREMENT_DROP_DOWN;
                    break;

                case 2:
                    $configuration['packageOrMeasurementId'] = GuiAbstract::PACKAGE_DROP_DOWN;
                    break;

                default:
                    break;
            }
        }

        if (isset($configuration['useOnlyVariationsItemNumbers']) == true) {
            switch ($configuration['useOnlyVariationsItemNumbers']) {
                case 'true':
                    $configuration['useOnlyVariationsItemNumbers'] = self::CHECKBOX_ACTIVE;
                    break;

                case 'false':
                    $configuration['useOnlyVariationsItemNumbers'] = self::CHECKBOX_NOT_ACTIVE;
            }
        }

        if (isset($configuration['orderStatusMultiSelectId']) == true) {
            $configuration['orderStatusMultiSelectIdDescription'] = '';
            $lastKey                                              = null;

            if (count($configuration['orderStatusMultiSelectId']) > 0) {
                $data = array_keys($configuration['orderStatusMultiSelectId']);
                $lastKey = end($data);
            }

            foreach ($configuration['orderStatusMultiSelectId'] as $key => $value) {
                $repository = Helper::getRepository('Shopware\Models\Order\Status');
                /** @var \Shopware\Models\Order\Status $orderStatusModel */
                $orderStatusModel = $repository->findOneBy(array('id' => (int)$value));

                if ($orderStatusModel !== null) {
                    if ($key == $lastKey) {
                        $configuration['orderStatusMultiSelectIdDescription'] .= $orderStatusModel->getName();
                    } else {
                        $configuration['orderStatusMultiSelectIdDescription'] .= $orderStatusModel->getName() . ' , ';
                    }
                }
            }
        }

        if (isset($configuration['commentId']) === true) {
            if ($configuration['commentId'] === 'getComment') {
                $configuration['commentId'] = 'Kommentar';
            } elseif ($configuration['commentId'] === 'getCustomerComment') {
                $configuration['commentId'] = 'Kunden-Kommentar';
            } elseif( $configuration['commentId'] === 'getInternalComment') {
                $configuration['commentId'] = 'Interne-Kommentar';
            }
        }

        if (isset($configuration['strikeThroughPriceRulesId']) === true) {
            if ($configuration['strikeThroughPriceRulesId'] == '1') {
                $configuration['strikeThroughPriceRulesId'] = GuiAbstract::STRIKE_THROUGH_PRICE_RULES_1;
            } elseif ($configuration['strikeThroughPriceRulesId'] == '2') {
                $configuration['strikeThroughPriceRulesId'] = GuiAbstract::STRIKE_THROUGH_PRICE_RULES_2;
            }
        }

        return $configuration;
    }

    /**
     * @param string $scriptName
     *
     * @return mixed|string
     */
    final public function getLastImportExportTimeFromScriptLoggerByScriptName($scriptName = '')
    {
        $returnValue = GuiAbstract::UNKNOWN_IMPORT_EXPORT_TIME;

        if (strlen($scriptName) > 0) {
            $result = Shopware()->Db()->fetchOne("  
                  SELECT date_end 
                  FROM bf_scriptlogger
                  WHERE script_name =  ?
                  ORDER BY date_end DESC 
                  LIMIT 1", array($scriptName));

            if ($result !== null && $result !== false) {
                if (strlen($result) > 0) {
                    $returnValue = strtotime($result);
                    $returnValue = date('d-m-Y H:i:s', $returnValue);
                }
            }
        }

        return $returnValue;
    }

    /**
     * @param null $modelNamespace
     *
     * @return int|mixed
     */
    final public function getCountOfImportedItems($modelNamespace = null)
    {
        $result = array(
            1 => 0
        );

        if ($modelNamespace !== null) {
            try {
                $qb = $this->getQueryBuilder();

                $qb->select(array('COUNT(counter.id)'))->from($modelNamespace, 'counter');

                $sql = $qb->getQuery();

                try {
                    $result = $sql->getOneOrNullResult();
                } catch (NonUniqueResultException $e) {
                    Helper::fromArray(array(
                            new Log(),
                            array(
                                Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                                Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                                Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                                Logging::SETTER_ALIAS_LOG_MESSAGE => $e->getMessage(),
                                Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                            )
                        ));
                }
            } catch (Exception $e) {
                Helper::fromArray(array(
                        new Log(),
                        array(
                            Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                            Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                            Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::BF_INTERNAL_ERROR,
                            Logging::SETTER_ALIAS_LOG_MESSAGE => $e->getMessage(),
                            Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                        )
                    ));
            }
        } else {
            Helper::fromArray(array(
                    new Log(),
                    array(
                        Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_ERROR,
                        Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                        Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::NO_GIVEN_MODEL_NAMESPACE_ERROR_CODE,
                        Logging::SETTER_ALIAS_LOG_MESSAGE => ErrorCodes::NO_GIVEN_MODEL_NAMESPACE,
                        Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                    )
                ));
        }

        return $result[1];
    }

    /**
     * @param $configuration
     * @param $configurationKey
     * @return void
     */
    private function assignGuiYesNoForBooleanConfig(&$configuration, $configurationKey) {
        if (isset($configuration[$configurationKey]) === true) {
            if(filter_var($configuration[$configurationKey], FILTER_VALIDATE_BOOLEAN) === true) {
                $configuration[$configurationKey] = GuiAbstract::DROP_DOWN_YES;
            } else {
                $configuration[$configurationKey] = GuiAbstract::DROP_DOWN_NO;
            }
        }
    }
}