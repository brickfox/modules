<?php
namespace Bf\Saleschannel\Components\Gui;

use Bf\Saleschannel\Components\Util\Helper;

/**
 * MappingShops
 *
 * @package Bf\Saleschannel\Components\Gui
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class MappingShops
{
    /**
     * @return array
     */
    final public function getShopsMappingFieldKeys()
    {
        $shops = array();

        $repository  = Helper::getRepository('Shopware\Models\Shop\Shop');
        $shopsModels = $repository->findAll();

        if(count($shopsModels) > 0)
        {
            /** @var \Shopware\Models\Shop\Shop $shop */
            foreach($shopsModels as $shop)
            {
                $shops[] = array(
                    'shopwareFieldKeyCode' => $shop->getId(),
                    'shopwareFieldKeyName' => $shop->getName()
                );
            }
        }

        return $shops;
    }

    /**
     * @return array
     */
    final public function getShopMappingMasterShop()
    {
        return array(
            0 => array('masterFieldKeyCode' => 0, 'masterFieldKeyName' => 'Nein'),
            1 => array('masterFieldKeyCode' => 1, 'masterFieldKeyName' => 'Ja')
        );
    }
}
