<?php
namespace Bf\Saleschannel\Components\Gui;

use Bf\Saleschannel\Components\Util\Helper;

/**
 * MappingTax
 *
 * @package Bf\Saleschannel\Components\Gui
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class MappingTax
{
    /**
     * @return array
     */
    final public function getTaxMappingFieldKeys()
    {
        $tax = array();

        $repository   = Helper::getRepository('Shopware\Models\Tax\Tax');
        $taxListModel = $repository->findAll();

        if(count($taxListModel) > 0)
        {
            /** @var \Shopware\Models\Tax\Tax $taxModel */
            foreach($taxListModel as $taxModel)
            {
                $tax[] = array(
                    'shopwareFieldKeyCode' => $taxModel->getId(),
                    'shopwareFieldKeyName' => $taxModel->getName()
                );
            }
        }

        return $tax;
    }
}
