<?php
namespace Bf\Saleschannel\Components\Resources\Article;

use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Exceptions;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Doctrine\Common\Collections\ArrayCollection;
use Shopware\CustomModels\BfSaleschannel\Log;
use Shopware\Models\Article\Article as SwArticle;
use SimpleXMLElement;

/**
 * Assignments
 *
 * @package Bf\Saleschannel\Components\Resources\Article
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Assignments extends ArticleAbstract
{
    const ASSIGNMENTS_TYPE_RELATED = 'accessories';
    const ASSIGNMENTS_TYPE_SIMILAR = 'crossselling';

    /**
     * @param SwArticle $article
     * @param SimpleXMLElement $simpleXMLElement
     */
    public function __construct(SwArticle $article, SimpleXMLElement $simpleXMLElement)
    {
        $this->setArticle($article);
        $this->setSimpleXmlElement($simpleXMLElement);
    }

    /**
     * @throws \Exception
     * @return void
     */
    public function prepareProductsAssignment()
    {
        $relatedCollection = new ArrayCollection();
        $similarCollection = new ArrayCollection();

        foreach($this->getProductsAssignment() as $assignmentsType => $assignmentsProductsId)
        {
            foreach($assignmentsProductsId as $productsId)
            {
                /** @var \Shopware\CustomModels\BfSaleschannel\MappingArticles $mappingModel */
                $mappingModel = Helper::getMappingByValue($productsId, 'brickfoxId', self::MAPPING_NAMESPACE_MODEL);

                if($mappingModel !== null)
                {
                    if($assignmentsType === self::ASSIGNMENTS_TYPE_RELATED)
                    {
                        $relatedCollection->add($mappingModel->getArticle());
                    }
                    elseif($assignmentsType === self::ASSIGNMENTS_TYPE_SIMILAR)
                    {
                        $similarCollection->add($mappingModel->getArticle());
                    }
                    else
                    {
                        LogManager::getInstance()->writeLogForGui(
                            Log::LOG_STATUS_ERROR,
                            __METHOD__,
                            str_replace(
                                array('{$brickfoxId}', '{$assignmentType}'),
                                array($productsId, $assignmentsType),
                                ErrorCodes::PRODUCTS_ASSIGNMENTS_WRONG_TYPE
                            ),
                            Helper::getUserName(),
                            Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                            $productsId,
                            ErrorCodes::PRODUCTS_ASSIGNMENTS_WRONG_TYPE_ERROR_CODE,
                            false,
                            false
                        );
                    }
                }
                else
                {
                    LogManager::getInstance()->writeLogForGui(
                        Log::LOG_STATUS_ERROR,
                        __METHOD__,
                        str_replace(
                            array('{$brickfoxId}'),
                            array($productsId),
                            ErrorCodes::PRODUCTS_ASSIGNMENT_CAN_NOT_FIND_RESOURCE
                        ),
                        Helper::getUserName(),
                        Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                        $productsId,
                        ErrorCodes::PRODUCTS_ASSIGNMENTS_CAN_NOT_FIND_RESOURCE_ERROR_CODE,
                        false,
                        false
                    );
                }
            }
        }

        if($relatedCollection->getKeys() > 0)
        {
            $this->getArticle()->setRelated($relatedCollection);
        }

        if($similarCollection->getKeys() > 0)
        {
            $this->getArticle()->setSimilar($similarCollection);
        }
    }

    /**
     * @return array
     */
    private function getProductsAssignment()
    {
        $productsAssignments = array();

        foreach($this->getSimpleXmlElement()->Assignments->Assignment as $assignments)
        {
            if((string) $assignments['type'] === self::ASSIGNMENTS_TYPE_RELATED)
            {
                $productsAssignments[self::ASSIGNMENTS_TYPE_RELATED][] = (int) $assignments->ProductId;
            }
            elseif((string) $assignments['type'] === self::ASSIGNMENTS_TYPE_SIMILAR)
            {
                $productsAssignments[self::ASSIGNMENTS_TYPE_SIMILAR][] = (int) $assignments->ProductId;
            }
        }

        return $productsAssignments;
    }
}
