<?php
namespace Bf\Saleschannel\Components\Resources\Article;

use SimpleXMLElement;
use Shopware\Models\Article\Detail as SwDetail;
use Shopware\Models\Article\Article as SwArticle;

/**
 * CustomAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Article
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class CustomAbstract
{
    private $detail;

    private $article;

    private $simpleXmlElement;

    /**
     * @param SwArticle $article
     * @param SimpleXMLElement $simpleXMLElement
     * @param null $detail
     */
    public function __construct(SwArticle $article, SimpleXMLElement $simpleXMLElement, $detail = null)
    {
        $this->setArticle($article);
        $this->setSimpleXmlElement($simpleXMLElement);

        if($detail !== null)
        {
            $this->setDetail($detail);
        }
    }

    /**
     * @return SwDetail
     */
    public function getDetail()
    {
        return $this->detail;
    }

    /**
     * @param mixed $detail
     *
     * @return CustomAbstract
     */
    public function setDetail($detail)
    {
        $this->detail = $detail;

        return $this;
    }

    /**
     * @return SwArticle
     */
    public function getArticle()
    {
        return $this->article;
    }

    /**
     * @param mixed $article
     *
     * @return CustomAbstract
     */
    public function setArticle($article)
    {
        $this->article = $article;

        return $this;
    }

    /**
     * @return SimpleXmlElement
     */
    public function getSimpleXmlElement()
    {
        return $this->simpleXmlElement;
    }

    /**
     * @param mixed $simpleXmlElement
     *
     * @return CustomAbstract
     */
    public function setSimpleXmlElement($simpleXmlElement)
    {
        $this->simpleXmlElement = $simpleXmlElement;

        return $this;
    }

    abstract function prepareCustomItem();
}
