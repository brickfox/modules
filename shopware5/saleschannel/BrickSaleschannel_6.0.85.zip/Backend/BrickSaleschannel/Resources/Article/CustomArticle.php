<?php
namespace Bf\Saleschannel\Components\Resources\Article;

use SimpleXMLElement;
use Shopware\Models\Article\Article as SwArticle;

/**
 * CustomArticle
 *
 * @package Bf\Saleschannel\Components\Resources\Article
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class CustomArticle extends CustomAbstract
{
    private $classMethods = array(
        //insert ur custom methods here like:
        'customMethodName'
    );

    /**
     * @param SwArticle $article
     * @param SimpleXMLElement $simpleXMLElement
     */
    public function __construct(SwArticle $article, SimpleXMLElement $simpleXMLElement)
    {
        parent::__construct($article, $simpleXMLElement);
    }

    /**
     * @return void
     */
    public function prepareCustomItem()
    {
        foreach($this->classMethods as $methodName)
        {
            if($methodName !== 'customMethodName')
            {
                if(method_exists($this, $methodName) === true)
                {
                    $this->$methodName();
                }
            }
        }
    }
}
