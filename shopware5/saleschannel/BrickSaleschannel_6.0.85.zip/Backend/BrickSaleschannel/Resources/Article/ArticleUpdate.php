<?php
namespace Bf\Saleschannel\Components\Resources\Article;


use Bf\Saleschannel\Components\Resources\Detail\DetailUpdate;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\ProcessingException;
use Doctrine\ORM\EntityNotFoundException;
use Shopware\Models\Article\Article as SwArticle;
use SimpleXMLElement;

/**
 * ArticleUpdate
 *
 * @package Bf\Saleschannel\Components\Resources\Article
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class ArticleUpdate extends ArticleAbstract
{
    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param SwArticle $article
     */
    public function __construct(SimpleXMLElement $simpleXMLElement, SwArticle $article)
    {
        $this->setSimpleXmlElement($simpleXMLElement);
        $this->setArticle($article);
    }

    /**
     * @return void
     * @throws ProcessingException
     */
    public function prepareArticleUpdate()
    {
        $this->getArticle()->setActive((int) $this->getSimpleXmlElement()->Active);
        $this->getArticle()->setChanged();

        foreach($this->getSimpleXmlElement()->Variations->Variation as $productsVariationsXmlElement)
        {
            try {
                /** @var \Shopware\CustomModels\BfSaleschannel\MappingDetails $mappingModel */
                $mappingModel = Helper::getMappingByValue((int)$productsVariationsXmlElement->VariationId, 'brickfoxId', self::MAPPING_NAMESPACE_MODEL_DETAIL);

                if ($mappingModel !== null) {
                    (new DetailUpdate($productsVariationsXmlElement, $this->getArticle(), $mappingModel->getDetail()))->prepareArticleDetailUpdate();
                }

            } catch (EntityNotFoundException $notFoundException) {
                throw new ProcessingException(
                    str_replace(
                        ['{$brickfoxId}', '{shopwareId}'],
                        [$mappingModel->getBrickfoxId(), $mappingModel->getShopwareId()],
                        ErrorCodes::PRODUCTS_UPDATE_CAN_NOT_FIND_VARIATION
                    ),
                    ErrorCodes::PRODUCTS_UPDATE_CAN_NOT_FIND_VARIATION_ERROR_CODE
                );
            }
        }

        $this->checkMainImage();
    }

    private function checkMainImage()
    {
        try {
            $foundMainImage = false;

            if ($this->getArticle()->getImages()->count() > 0) {
                /** @var \Shopware\Models\Article\Image $swImages */
                foreach ($this->getArticle()->getImages() as $swImages) {
                    if (method_exists($swImages, 'getMain') === true) {
                        if ($swImages->getMain() === 1) {
                            $foundMainImage = true;
                            break;
                        }
                    }
                }
            }

            if ($foundMainImage === false) {
                $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Image');
                /** @var \Shopware\Models\Article\Image|null $swImage */
                $swImage = $repository->findOneBy(array('articleId' => $this->getArticle()->getId(), 'position' => 1));

                if ($swImage !== null) {
                    $swImage->setMain(1);
                    if ($swImage->getChildren() > 0) {
                        /** @var \Shopware\Models\Article\Image $swImageChilds */
                        foreach ($swImage->getChildren() as $swImageChilds) {
                            $swImageChilds->setMain(1);
                            Shopware()->Models()->persist($swImageChilds);
                        }

                        Shopware()->Models()->persist($swImage);
                    }
                }
            }
        } catch (\Exception $exception){}
    }
}
