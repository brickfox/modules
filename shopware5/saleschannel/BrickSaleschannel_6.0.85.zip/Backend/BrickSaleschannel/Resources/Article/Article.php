<?php
namespace Bf\Saleschannel\Components\Resources\Article;

use Bf\Saleschannel\Components\Resources\Detail\Detail;
use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\ImageHelper;
use Bf\Saleschannel\Components\Util\LogManager;
use SimpleXMLElement;
use \Shopware\Models\Article\Article as SwArticle;
use Bf\Saleschannel\Components\Resources\Categories\Categories as ResourceCategories;
use Bf\Saleschannel\Components\Resources\Supplier\Supplier as ResourceSupplier;
use Bf\Saleschannel\Components\Util\Cleaner;

/**
 * Article
 *
 * @package Bf\Saleschannel\Components\Resources\Article
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Article extends ArticleAbstract
{
    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param SwArticle $article
     * @param $mode
     */
    public function __construct(SimpleXMLElement $simpleXMLElement, SwArticle $article, $mode)
    {
        $this->setArticle($article);
        $this->setSimpleXmlElement($simpleXMLElement);
        $this->setMode($mode);
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function prepareArticleItem()
    {
        $this->setArticleMainDescriptions();

        (new ResourceCategories($this->getSimpleXmlElement(), $this->getArticle()))->prepareCategoriesAssignment(Helper::getShopsId());

        $this->getArticle()->setActive((int) $this->getSimpleXmlElement()->Active);
        $this->getArticle()->setChanged();
        $this->getArticle()->setAdded($this->getDateInsert());
        $this->getArticle()->setLastStock($this->getArticleLastStock());
        $this->getArticle()->setTax($this->setArticleTax());
        $this->getArticle()->setSupplier((new ResourceSupplier($this->getSimpleXmlElement()))->prepareSupplierAssignment());
        $this->getArticle()->setHighlight($this->getHighlight());

        $emailNotification = $this->getEmailNotification();
        if($emailNotification !== null) {
            $this->getArticle()->setNotification($emailNotification);
        }

        Shopware()->Models()->persist($this->getArticle());

        if(ConfigManager::getInstance()->getIgnoreImageInformation() === false)
        {
            $this->setImagesToArticle(self::IMPORT_ARTICLE_IMAGE_MODE);
        }

        $this->setMediaFilesToArticle();

        (new Detail($this->getSimpleXmlElement(), $this->getArticle()))->prepareDetailItem();

        $this->setAttributesToArticle();
        $this->setCustomerGroupsToAvoid();
        $this->deleteOldData();
        $this->checkMainImage();
    }

    private function checkMainImage()
    {
        try {
            $foundMainImage = false;

            if ($this->getArticle()->getImages()->count() > 0) {
                /** @var \Shopware\Models\Article\Image $swImages */
                foreach ($this->getArticle()->getImages() as $swImages) {
                    if (method_exists($swImages, 'getMain') === true) {
                        if ($swImages->getMain() === 1) {
                            $foundMainImage = true;
                            break;
                        }
                    }
                }
            }

            if ($foundMainImage === false) {
                $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Image');
                /** @var \Shopware\Models\Article\Image|null $swImage */
                $swImage = $repository->findOneBy(array('articleId' => $this->getArticle()->getId(), 'position' => 1));

                if ($swImage !== null) {
                    $swImage->setMain(1);
                    if ($swImage->getChildren() > 0) {
                        /** @var \Shopware\Models\Article\Image $swImageChilds */
                        foreach ($swImage->getChildren() as $swImageChilds) {
                            $swImageChilds->setMain(1);
                            Shopware()->Models()->persist($swImageChilds);
                        }

                        Shopware()->Models()->persist($swImage);
                    }
                } else {
                    $swImage = $repository->findOneBy(array('articleId' => $this->getArticle()->getId(), 'position' => 2));

                    if ($swImage !== null) {
                        if ($swImage->getChildren() > 0) {
                            /** @var \Shopware\Models\Article\Image $swImageChilds */
                            foreach ($swImage->getChildren() as $swImageChilds) {
                                $swImageChilds->setMain(1);
                                Shopware()->Models()->persist($swImageChilds);
                            }

                            Shopware()->Models()->persist($swImage);
                        }
                    }
                }
            }
        } catch (\Exception $exception){}
    }

    /**
     * @return void
     */
    private function deleteOldData()
    {
        if(self::getDeleteOldData() === true)
        {
            if(count(self::getToDeleteImageMappings()) > 0)
            {
                (new Cleaner(self::getToDeleteImageMappings(), self::IMPORT_CLEAR_TYPE_IMAGE_MAPPING))->prepareCleanUp();
            }
        }
        ImageHelper::getInstance()->setImageCache(array());
        self::setDeleteOldData(false);
    }
}
