<?php

namespace Bf\Saleschannel\Components\Resources\Article;

use Bf\Saleschannel\Components\Resources\Configurator\Configurator;
use Bf\Saleschannel\Components\Resources\ImportAbstract;
use Bf\Saleschannel\Components\Resources\MultiShop\MultiShop;
use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Exception;
use Shopware\CustomModels\BfSaleschannel\Log;
use SimpleXMLElement;
use Bf\Saleschannel\Components\Resources\Images\Images as BfImages;
use Bf\Saleschannel\Components\Resources\Images\ImagesDiffsOptions as BfImagesDiffsOptions;
use Bf\Saleschannel\Components\Resources\Media\Media as BfMedia;
use Bf\Saleschannel\Components\Resources\Images\Mapping as BfMapping;
use Bf\Saleschannel\Components\Resources\Attributes\Attributes as BfAttributes;
use Bf\Saleschannel\Components\Resources\Attributes\AvoidCustomerGroup as BfAvoidCustomerGroups;
use Shopware\Models\Article\Detail as SwDetail;

/**
 * ArticleAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Article
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class ArticleAbstract extends ImportAbstract
{
    const MAPPING_NAMESPACE_MODEL                     = 'Shopware\CustomModels\BfSaleschannel\MappingArticles';
    const MAPPING_NAMESPACE_MODEL_DETAIL              = 'Shopware\CustomModels\BfSaleschannel\MappingDetails';
    const ENTITY_NAME                                 = 'Products';
    const FILE_NAME                                   = 'Article.php';
    const IMPORT_ARTICLE_IMAGE_MODE                   = 'article';
    const IMPORT_ARTICLE_VARIATION_IMPORT_MODE        = 'articleVariation';
    const IMPORT_CLEAR_TYPE_IMAGE_MAPPING             = 'IMAGE_MAPPING';
    const IMPORT_CLEAR_TYPE_PRODUCTS_VARIATIONS_DIFFS = 'DIFF_OPTIONS';
    const IMPORT_CLEAR_CATEGORIES_ASSIGNMENTS         = 'CATEGORY_DENORMALIZATION';

    /** @var string */
    private $mode = '';

    /** @var bool */
    public static $deleteOldData = false;

    /** @var array */
    public static $toDeleteImageMappings = array();

    /** @var array */
    public static $toDeleteProductsVariationsDiffOptions = array();

    private static $isNewMapping = null;

    /**
     * @param SwDetail $detail
     * @param SimpleXMLElement $variationXMLElement
     */
    protected function setArticleDetailsAttributesToArticleDetail(SwDetail $detail, SimpleXMLElement $simpleXMLElement, SimpleXMLElement $variationXMLElement)
    {
        (new BfAttributes($this->getArticle(), $detail))->prepareArticleDetailAttributesWithoutProperties($simpleXMLElement, $variationXMLElement);
    }

    /**
     * @return void
     */
    protected function setAttributesToArticle()
    {
        (new BfAttributes($this->getArticle()))->prepareArticleAttributesAndProperties($this->getSimpleXmlElement());
    }

    /**
     * @return void
     * @throws \Exception
     */
    protected function setCustomerGroupsToAvoid()
    {
        (new BfAvoidCustomerGroups($this->getArticle()))->prepareCustomerGroupsToAvoid($this->getSimpleXmlElement());
    }

    /**
     * @return void
     */
    protected function setMediaFilesToArticle()
    {
        (new BfMedia())->prepareMedia($this->getSimpleXmlElement(), $this->getArticle());
    }

    /**
     * @param $mode
     * @param SimpleXMLElement $variationXmlElement
     * @param null $detail
     * @param int $bfProductsId
     */
    protected function setImagesToArticle($mode, SimpleXMLElement $variationXmlElement = null, $detail = null, $bfProductsId = 0)
    {
        if (ConfigManager::getInstance()->getImageMappingDiffsOptionsStatus() === true && $mode === self::IMPORT_ARTICLE_VARIATION_IMPORT_MODE) {
            $bfImageDiffsOptions = new BfImagesDiffsOptions();

            (new BfMapping($detail, $this->getArticle(), $variationXmlElement, $bfImageDiffsOptions,
                Configurator::getInstance()->getOptionsToDetailsRelations()[(int)$variationXmlElement->VariationId], $bfProductsId))->prepareArticleImagesMapping();

        } else {
            $bfImage = new BfImages();

            if ($mode === self::IMPORT_ARTICLE_IMAGE_MODE) {
                $bfImage->prepareImages($this->getSimpleXmlElement(), $this->getArticle(), $mode);
            } elseif ($mode === self::IMPORT_ARTICLE_VARIATION_IMPORT_MODE) {
                (new BfMapping($detail, $this->getArticle(), $variationXmlElement, $bfImage,
                    Configurator::getInstance()->getOptionsToDetailsRelations()[(int)$variationXmlElement->VariationId]))->prepareArticleImagesMapping();
            }

        }
    }

    /**
     * @return string
     */
    protected function getDateInsert()
    {
        $date = 'now';

        if (strlen(ConfigManager::getInstance()->getCreateDateCode()) > 0) {
            if ((bool)$this->getSimpleXmlElement()->Attributes === true) {
                foreach ($this->getSimpleXmlElement()->Attributes as $attributes) {
                    foreach ($attributes as $type => $attribute) {
                        if (in_array((string)$attribute->Translations->Translation['lang'], Helper::getMainLanguagesCode()) === true) {
                            if ((string)$attribute['code'] !== ConfigManager::getInstance()->getCreateDateCode()) {
                                continue;
                            } else {
                                $attributeInformation = Helper::getPropertyNameByAttributesType($attribute, $type);
                                if (strlen($attributeInformation['value']) > 0) {
                                    $date = $attributeInformation['value'];
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if ((bool)$this->getSimpleXmlElement()->DateInsert === true) {
                $date = (string)$this->getSimpleXmlElement()->DateInsert;
            }
        }

        return $date;
    }

    /**
     * @return int|null
     */
    protected function getEmailNotification()
    {
        $emailNotification = null;

        if (strlen(ConfigManager::getInstance()->getEmailNotificationCode()) > 0) {
            if ((bool)$this->getSimpleXmlElement()->Attributes === true) {
                foreach ($this->getSimpleXmlElement()->Attributes as $attributes) {
                    foreach ($attributes as $type => $attribute) {
                        if (in_array((string)$attribute->Translations->Translation['lang'], Helper::getMainLanguagesCode()) === true) {
                            if ((string)$attribute['code'] !== ConfigManager::getInstance()->getEmailNotificationCode()) {
                                continue;
                            } else {
                                $attributeInformation = Helper::getPropertyNameByAttributesType($attribute, $type);
                                if (strlen($attributeInformation['value']) > 0) {
                                    if((int)$attributeInformation['value'] === 1 || (int)$attributeInformation['value'] === 0) {
                                        $emailNotification = (int)$attributeInformation['value'];
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        return $emailNotification;
    }

    /**
     * @return int
     */
    protected function getHighlight()
    {
        $isHighLight = 0;

        if ((bool)$this->getSimpleXmlElement()->Highlight === true) {
            $isHighLight = (int)$this->getSimpleXmlElement()->Highlight;
        }

        return $isHighLight;
    }

    /**
     * @return \Shopware\Models\Tax\Tax
     * @throws Exception
     */
    protected function setArticleTax()
    {
        $taxId = 1;

        $repository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingTax');
        /** @var \Shopware\CustomModels\BfSaleschannel\MappingTax $mappingTaxModel */
        $mappingTaxModel = $repository->findOneBy(array('brickfoxTaxId' => (int)$this->getSimpleXmlElement()->TaxId));

        if ($mappingTaxModel !== null) {
            $taxId = (int)$mappingTaxModel->getMappingFieldKey();
        } else {
            switch ((int)$this->getSimpleXmlElement()->TaxId) {
                case 1:
                    $taxId = Shopware()->Db()->fetchOne("
                        SELECT id
                        FROM s_core_tax
                        WHERE tax = 19
                        LIMIT 1
                    ");
                    break;

                case 2:
                    $taxId = Shopware()->Db()->fetchOne("
                        SELECT id
                        FROM s_core_tax
                        WHERE tax = 7
                        LIMIT 1
                    ");
            }
        }

        $repository = Helper::getRepository('\Shopware\Models\Tax\Tax');
        $model      = $repository->find($taxId);

        return $model;
    }

    /**
     * @param SimpleXMLElement $description
     *
     * @return string
     * @throws \Exception
     */
    protected function getTitle(SimpleXMLElement $description)
    {
        $title = '';

        if ((bool)$description->Title === true && strlen($description->Title) > 0) {
            $title = (string)$description->Title;
        } else {
            LogManager::getInstance()
                ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__,
                    str_replace(array('{$orderNumber}', '{$brickfoxId}'), array((string)$this->getSimpleXmlElement()->ItemNumber, (string)$this->getSimpleXmlElement()->ProductId),
                        ErrorCodes::PRODUCTS_MISSING_TITLE), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId,
                    ErrorCodes::PRODUCTS_MISSING_TITLE_ELEMENT_ERROR_CODE);
        }

        return $title;
    }

    /**
     * @param SimpleXMLElement $description
     *
     * @return string
     */
    protected function getMetaTitle(SimpleXMLElement $description)
    {
        $metaTitle = '';

        if ((bool)$description->SeoTitle === true) {
            $metaTitle = (string)$description->SeoTitle;
        }

        return $metaTitle;
    }

    /**
     * @param $description
     *
     * @return string
     */
    protected function getShortDescription(SimpleXMLElement $description)
    {
        $seoDescription = '';

        if ((bool)$description->SeoDescription === true) {
            $seoDescription = (string)$description->SeoDescription;
        }

        return $seoDescription;
    }

    /**
     * @param $description
     *
     * @return string
     */
    protected function getDescriptionLong(SimpleXMLElement $description)
    {
        $descriptionLong = '';

        if ((bool)$description->LongDescription === true) {
            $descriptionLong = (string)$description->LongDescription;
        }

        return $descriptionLong;
    }

    /**
     * @param $description
     *
     * @return string
     */
    protected function getKeyWords(SimpleXMLElement $description)
    {
        $keyWords = '';

        if ((bool)$description->SearchKeys === true) {
            $keyWords = (string)$description->SearchKeys;
        }

        return $keyWords;
    }

    /**
     * @throws Exception
     */
    public function setArticleMainDescriptions()
    {
        $written = false;

        if ((bool)$this->getSimpleXmlElement()->Descriptions === false || (bool)$this->getSimpleXmlElement()->Descriptions->Description === false) {
            LogManager::getInstance()
                ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__,
                    str_replace(array('{$orderNumber}', '{$brickfoxId}'), array((string)$this->getSimpleXmlElement()->ItemNumber, (string)$this->getSimpleXmlElement()->ProductId),
                        ErrorCodes::PRODUCTS_MISSING_DESCRIPTION), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId,
                    ErrorCodes::PRODUCTS_MISSING_DESCRIPTION_ELEMENT_ERROR_CODE);
        }

        foreach ($this->getSimpleXmlElement()->Descriptions->Description as $description) {
            if (in_array((string)$description['lang'], Helper::getMainLanguagesCode()) === true) {
                $this->getArticle()->setName($this->getTitle($description));

                if (ConfigManager::getInstance()->getIgnoreLongDescription() === false) {
                    $this->getArticle()->setDescriptionLong($this->getDescriptionLong($description));
                }

                if (Helper::getConfigurationByKey('overWriteMetaElements')->getConfigurationValue() === 'true') {
                    $this->getArticle()->setMetaTitle($this->getMetaTitle($description));
                    $this->getArticle()->setDescription($this->getShortDescription($description));
                    $this->getArticle()->setKeywords($this->getKeyWords($description));
                }

                $written = true;
            }

            if ($written === false) {
                LogManager::getInstance()
                    ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(array('{$itemNumber}', '{$brickfoxId}'),
                            array((string)$this->getSimpleXmlElement()->ItemNumber, (string)$this->getSimpleXmlElement()->ProductId),
                            ErrorCodes::PRODUCTS_MISSING_LANGUAGE_ATTRIBUTE), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                        (string)$this->getSimpleXmlElement()->ProductId, ErrorCodes::PRODUCTS_MISSING_LANGUAGE_ATTRIBUTE_ERROR_CODE);
            }
        }
    }

    /**
     * @return int
     */
    public function getArticleLastStock()
    {
        $neverOutOfStock = 1;

        if ((int)$this->getSimpleXmlElement()->Variations[0]->Variation->NeverOutOfStock === 0) {
            $neverOutOfStock = 1;
        } elseif ((int)$this->getSimpleXmlElement()->Variations[0]->Variation->NeverOutOfStock === 1) {
            $neverOutOfStock = 0;
        }

        if ((int)$this->getSimpleXmlElement()->Variations[0]->Variation->ThirdPartyStock > 0) {
            $neverOutOfStock = 0;
        }

        return $neverOutOfStock;
    }

    /**
     * @return string
     */
    public function getMode()
    {
        return $this->mode;
    }

    /**
     * @param string $mode
     *
     * @return ArticleAbstract
     */
    public function setMode($mode)
    {
        $this->mode = $mode;

        return $this;
    }

    /**
     * @return boolean
     */
    public static function getDeleteOldData()
    {
        return self::$deleteOldData;
    }

    /**
     * @param boolean $deleteOldData
     *
     * @return ArticleAbstract
     */
    public static function setDeleteOldData($deleteOldData)
    {
        self::$deleteOldData = $deleteOldData;
    }

    /**
     * @return array
     */
    public static function getToDeleteImageMappings()
    {
        return self::$toDeleteImageMappings;
    }

    /**
     * @param \Shopware\Models\Article\Image $toDeleteImageMappings
     *
     * @return ArticleAbstract
     */
    public static function setToDeleteImageMappings($toDeleteImageMappings)
    {
        if (count($toDeleteImageMappings->getMappings()->toArray()) > 0) {
            self::setIsNewMapping(false);
        } else {
            self::setIsNewMapping(true);
        }

        /** @var \Shopware\Models\Article\Image\Mapping $mapping */
        if (count($toDeleteImageMappings->getMappings()->toArray()) > 0 && self::$isNewMapping === false) {
            foreach ($toDeleteImageMappings->getMappings()->toArray() as $mapping) {
                /** @var \Shopware\Models\Article\Image\Rule $rules */
                foreach ($mapping->getRules()->toArray() as $rules) {
                    if (array_key_exists($toDeleteImageMappings->getId(), self::$toDeleteImageMappings) === false) {
                        self::$toDeleteImageMappings[$toDeleteImageMappings->getId()] = array();
                    }

                    if (array_key_exists($mapping->getId(), self::$toDeleteImageMappings[$toDeleteImageMappings->getId()]) === false && $mapping->getId() !== null) {
                        self::$toDeleteImageMappings[$toDeleteImageMappings->getId()][$mapping->getId()] = array();
                    }

                    if (array_key_exists($toDeleteImageMappings->getId(), self::$toDeleteImageMappings) === true) {
                        if (is_array(self::$toDeleteImageMappings[$toDeleteImageMappings->getId()][$mapping->getId()]) === true) {
                            if (@array_search($rules->getId(), self::$toDeleteImageMappings[$toDeleteImageMappings->getId()][$mapping->getId()]) === false &&
                                $mapping->getId() !== null) {
                                self::$toDeleteImageMappings[$toDeleteImageMappings->getId()][$mapping->getId()][] = $rules->getId();
                            }
                        }
                    }
                }
            }
        } else {
            self::$toDeleteImageMappings[$toDeleteImageMappings->getId()] = array();
        }

    }

    /**
     * @return array
     */
    public static function getToDeleteProductsVariationsDiffOptions()
    {
        return self::$toDeleteProductsVariationsDiffOptions;
    }

    /**
     * @param array $toDeleteProductsVariationsDiffOptions
     *
     * @return ArticleAbstract
     */
    public static function setToDeleteProductsVariationsDiffOptions($toDeleteProductsVariationsDiffOptions)
    {
        self::$toDeleteProductsVariationsDiffOptions = $toDeleteProductsVariationsDiffOptions;
    }

    /**
     * @return mixed
     */
    public static function getIsNewMapping()
    {
        return self::$isNewMapping;
    }

    /**
     * @param mixed $isNewMapping
     *
     * @return ArticleAbstract
     */
    public static function setIsNewMapping($isNewMapping)
    {
        if (self::$isNewMapping === null) {
            self::$isNewMapping = $isNewMapping;
        }
    }
}