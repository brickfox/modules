<?php
namespace Bf\Saleschannel\Components\Resources\Property;

use Shopware\Models\Property\Relation as SwPropertyRelation;
use Shopware\Models\Property\Option as SwPropertyOption;
use Shopware\Models\Property\Group as SwPropertyGroup;

/**
 * Relation
 *
 * @package Bf\Saleschannel\Components\Resources\Property
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Relation extends PropertyAbstract
{
    const MODEL_NAMESPACE_PROPERTY_RELATION = 'Shopware\Models\Property\Relation';

    /** @var array */
    private $findOneByFilterList = array();

    /** @var array */
    private $setterWithValue = array(
        'option'   => '',
        'group'    => '',
        'position' => ''
    );

    /** @var null */
    private $propertyRelation = null;

    /**
     * @param SwPropertyOption $option
     * @param SwPropertyGroup $group
     * @param int $sortOrder
     *
     * @return void
     */
    public function loadPropertyRelation(SwPropertyOption $option, SwPropertyGroup $group, $sortOrder = 0)
    {
        $this->setFindOneByFilterList(array('optionId' => $option->getId(), 'groupId' => $group->getId()));

        $setterWithValue             = $this->getSetterWithValue();
        $setterWithValue['option']   = $option;
        $setterWithValue['group']    = $group;
        $setterWithValue['position'] = $sortOrder;
        $this->setSetterWithValue($setterWithValue);

        $this->setPropertyRelation($this->loadByOrSet(self::MODEL_NAMESPACE_PROPERTY_RELATION, $this->getFindOneByFilterList(), $this->getSetterWithValue()));
    }

    /**
     * @return array
     */
    public function getFindOneByFilterList()
    {
        return $this->findOneByFilterList;
    }

    /**
     * @param array $findOneByFilterList
     *
     * @return Relation
     */
    public function setFindOneByFilterList($findOneByFilterList)
    {
        $this->findOneByFilterList = $findOneByFilterList;

        return $this;
    }

    /**
     * @return array
     */
    public function getSetterWithValue()
    {
        return $this->setterWithValue;
    }

    /**
     * @param array $setterWithValue
     *
     * @return Relation
     */
    public function setSetterWithValue($setterWithValue)
    {
        $this->setterWithValue = $setterWithValue;

        return $this;
    }

    /**
     * @return null|SwPropertyRelation
     */
    public function getPropertyRelation()
    {
        return $this->propertyRelation;
    }

    /**
     * @param null $propertyRelation
     *
     * @return Relation
     */
    public function setPropertyRelation($propertyRelation)
    {
        $this->propertyRelation = $propertyRelation;

        return $this;
    }
}
