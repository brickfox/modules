<?php
namespace Bf\Saleschannel\Components\Resources\Property;

use Bf\Saleschannel\Components\Util\Helper;
use Shopware\Models\Property\Group as SwPropertyGroup;
use Shopware\Models\Property\Option as SwPropertyOption;
use Shopware\Models\Property\Value as SwPropertyValue;
use Shopware\Models\Property\Relation as SwPropertyRelation;

/**
 * PropertyAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Property
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class PropertyAbstract
{
    /**
     * @param null $modelNamespace
     * @param array $findOneByFilterList
     * @param array $setterWithValue
     *
     * @return null|SwPropertyGroup|SwPropertyOption|SwPropertyValue|SwPropertyRelation
     */
    protected function loadByOrSet($modelNamespace = null, array $findOneByFilterList = array(), array $setterWithValue = array())
    {
        $model = null;

        if($modelNamespace !== null && count($findOneByFilterList) > 0 && count($setterWithValue) > 0)
        {
            $repository = Helper::getRepository($modelNamespace);
            $model      = $repository->findOneBy($findOneByFilterList);

            if($model === null)
            {
                $model = new $modelNamespace();

                Helper::fromArray($model, $setterWithValue);
            }
        }

        return $model;
    }
}
