<?php
namespace Bf\Saleschannel\Components\Resources\Property;

use Shopware\Models\Property\Group as SwPropertyGroup;

/**
 * Group
 *
 * @package Bf\Saleschannel\Components\Resources\Property
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Group extends PropertyAbstract
{
    const PROPERTY_GROUP_NAME            = 'Brickfox';
    const MODEL_NAMESPACE_PROPERTY_GROUP = 'Shopware\Models\Property\Group';

    /** @var array */
    private $findOneByFilterList = array(
        'name' => 'Brickfox'
    );

    /** @var array */
    private $setterWithValue = array(
        'name'       => self::PROPERTY_GROUP_NAME,
        'position'   => 0,
        'comparable' => false,
        'sortMode'   => 0
    );

    /** @var null */
    private $propertyGroup = null;

    /**
     * @return void
     */
    public function loadPropertyGroup()
    {
        $this->setPropertyGroup($this->loadByOrSet(self::MODEL_NAMESPACE_PROPERTY_GROUP, $this->getFindOneByFilterList(), $this->getSetterWithValue()));
    }

    /**
     * @return null|SwPropertyGroup
     */
    public function getPropertyGroup()
    {
        return $this->propertyGroup;
    }

    /**
     * @param SwPropertyGroup $propertyGroup
     *
     * @return Group
     */
    public function setPropertyGroup($propertyGroup)
    {
        $this->propertyGroup = $propertyGroup;

        return $this;
    }

    /**
     * @return array
     */
    public function getFindOneByFilterList()
    {
        return $this->findOneByFilterList;
    }

    /**
     * @param array $findOneByFilterList
     *
     * @return Group
     */
    public function setFindOneByFilterList($findOneByFilterList)
    {
        $this->findOneByFilterList = $findOneByFilterList;

        return $this;
    }

    /**
     * @return array
     */
    public function getSetterWithValue()
    {
        return $this->setterWithValue;
    }

    /**
     * @param array $setterWithValue
     *
     * @return Group
     */
    public function setSetterWithValue($setterWithValue)
    {
        $this->setterWithValue = $setterWithValue;

        return $this;
    }
}
