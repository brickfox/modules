<?php
namespace Bf\Saleschannel\Components\Resources\Property;

use Shopware\Models\Property\Option as SwPropertyOption;

/**
 * Option
 *
 * @package Bf\Saleschannel\Components\Resources\Property
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Option extends PropertyAbstract
{
    const FILTER_ABLE                     = true;
    const MODEL_NAMESPACE_PROPERTY_OPTION = 'Shopware\Models\Property\Option';

    /** @var array */
    private $findOneByFilterList = array();

    /** @var array */
    private $setterWithValue = array(
        'name'       => '',
        'filterable' => self::FILTER_ABLE
    );

    /** @var null */
    private $propertyOption = null;

    /**
     * @param $propertyOptionName
     *
     * @return void
     */
    public function loadPropertyOption($propertyOptionName)
    {
        $this->setFindOneByFilterList(array('name' => $propertyOptionName));

        $setterWithValue         = $this->getSetterWithValue();
        $setterWithValue['name'] = $propertyOptionName;
        $this->setSetterWithValue($setterWithValue);

        $this->setPropertyOption($this->loadByOrSet(self::MODEL_NAMESPACE_PROPERTY_OPTION, $this->getFindOneByFilterList(), $this->getSetterWithValue()));
    }

    /**
     * @return array
     */
    public function getFindOneByFilterList()
    {
        return $this->findOneByFilterList;
    }

    /**
     * @param array $findOneByFilterList
     *
     * @return Option
     */
    public function setFindOneByFilterList($findOneByFilterList)
    {
        $this->findOneByFilterList = $findOneByFilterList;

        return $this;
    }

    /**
     * @return array
     */
    public function getSetterWithValue()
    {
        return $this->setterWithValue;
    }

    /**
     * @param array $setterWithValue
     *
     * @return Option
     */
    public function setSetterWithValue($setterWithValue)
    {
        $this->setterWithValue = $setterWithValue;

        return $this;
    }

    /**
     * @return null|SwPropertyOption
     */
    public function getPropertyOption()
    {
        return $this->propertyOption;
    }

    /**
     * @param null $propertyOption
     *
     * @return Option
     */
    public function setPropertyOption($propertyOption)
    {
        $this->propertyOption = $propertyOption;

        return $this;
    }

}
