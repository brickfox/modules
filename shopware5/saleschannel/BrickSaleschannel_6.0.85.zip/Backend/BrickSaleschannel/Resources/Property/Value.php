<?php
namespace Bf\Saleschannel\Components\Resources\Property;

use Bf\Saleschannel\Components\Util\Helper;
use Shopware\Models\Property\Option as SwPropertyOption;
use Shopware\Models\Property\Value as SwPropertyValue;

/**
 * Value
 *
 * @package Bf\Saleschannel\Components\Resources\Property
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Value
{
    const MODEL_NAMESPACE_PROPERTY_VALUE = 'Shopware\Models\Property\Value';

    /** @var array */
    private $findOneByFilterList = array();

    /** @var array */
    private $setterWithValue = array(
        'value'  => '',
        'option' => ''
    );

    /** @var null */
    private $propertyValue = null;

    /**
     * @param $value
     * @param SwPropertyOption $option
     *
     * @return void
     */
    public function loadPropertyValue($value, SwPropertyOption $option)
    {
        if(strlen($value) !== 0)
        {
            $value = mb_substr($value, 0, 255);
            $this->setFindOneByFilterList(array('optionId' => $option->getId(), 'value' => $value));

            $setterWithValue           = $this->getSetterWithValue();
            $setterWithValue['value']  = $value;
            $setterWithValue['option'] = $option;
            $this->setSetterWithValue($setterWithValue);

            $this->setPropertyValue($this->loadByOrSet($option, $value));

        }
    }

    /**
     * @param SwPropertyOption $option
     * @param string $value
     *
     * @return null|object
     */
    protected function loadByOrSet(SwPropertyOption $option, $value)
    {
        $model = null;

        if(count($this->getFindOneByFilterList()) > 0 && count($this->getSetterWithValue()) > 0)
        {
            $repository = Helper::getRepository(self::MODEL_NAMESPACE_PROPERTY_VALUE);
            $model      = $repository->findOneBy($this->getFindOneByFilterList());

            if($model === null)
            {
                $model = new SwPropertyValue($option, $value);
            }
        }

        return $model;
    }

    /**
     * @return array
     */
    public function getFindOneByFilterList()
    {
        return $this->findOneByFilterList;
    }

    /**
     * @param array $findOneByFilterList
     *
     * @return Value
     */
    public function setFindOneByFilterList($findOneByFilterList)
    {
        $this->findOneByFilterList = $findOneByFilterList;

        return $this;
    }

    /**
     * @return array
     */
    public function getSetterWithValue()
    {
        return $this->setterWithValue;
    }

    /**
     * @param array $setterWithValue
     *
     * @return Value
     */
    public function setSetterWithValue($setterWithValue)
    {
        $this->setterWithValue = $setterWithValue;

        return $this;
    }

    /**
     * @return null|SwPropertyValue
     */
    public function getPropertyValue()
    {
        return $this->propertyValue;
    }

    /**
     * @param null $propertyValue
     *
     * @return Value
     */
    public function setPropertyValue($propertyValue)
    {
        $this->propertyValue = $propertyValue;

        return $this;
    }
}
