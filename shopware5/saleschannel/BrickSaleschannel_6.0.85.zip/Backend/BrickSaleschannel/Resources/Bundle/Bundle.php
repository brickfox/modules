<?php

namespace Bf\Saleschannel\Components\Resources\Bundle;

use Exception;
use Shopware\Models\Article\Article as SwArticle;
use Shopware\Models\Article\Detail as SwArticleDetail;
use Shopware\CustomModels\Bundle\Price as SwBundlePrice;
use Shopware\CustomModels\Bundle\Article as SwBundleDetail;
use Shopware\CustomModels\Bundle\Bundle as SwBundle;
use Shopware\Models\Customer\Group as SwGroups;
use Shopware\Models\Article\Price as SwPrice;

/**
 * Bundle
 *
 * @package Bf\Saleschannel\Components\Resources\Bundle
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Bundle extends BundleAbstract
{
    /** @var array */
    private $bundlePrices = array();
    
    /**
     * @param \SimpleXMLElement $simpleXMLElement
     * @param SwArticle $article
     * @param null|SwArticleDetail $detail
     */
    public function __construct(\SimpleXMLElement $simpleXMLElement, SwArticle $article, $detail = null)
    {
        parent::__construct($simpleXMLElement, $article, $detail);
    }

    /**
     * @return SwBundle
     */
    public function prepareArticleBundle()
    {
        $this->initImport();

        if($this->getBundleModel() instanceof SwBundle && $this->getBundleModel()->getId() === null)
        {
            $this->getBundleModel()->setArticle($this->getArticle());
            $this->getBundleModel()->setName($this->getArticle()->getName());
            $this->getBundleModel()->setShowName(true); //Shows the Name of the bundle in the frontend
            $this->getBundleModel()->setType(1); // 1 => standard type (discount)
            $this->getBundleModel()->setActive(true);
            $this->getBundleModel()->setDiscountType(BundleAbstract::DISCOUNT_TYPE_ABSOLUTE);
            $this->getBundleModel()->setDescription($this->getArticle()->getDescription());
            $this->getBundleModel()->setNumber($this->getArticle()->getMainDetail()->getNumber());
            $this->getBundleModel()->setPosition(0);
            $this->getBundleModel()->setDisplayGlobal(true); //to show the bundle on every article, that is part of the bundle
            $this->getBundleModel()->setDisplayDelivery(1); // decides if delivery time is shown and how
            $this->getBundleModel()->setLimited(true);
            $this->getBundleModel()->setCreated(date('Y-m-d h:i:s', time()));
            $this->getBundleModel()->setCustomerGroups($this->getCustomerGroups());
            $this->getBundleModel()->setQuantity($this->calculateBundleQuantity());
            $this->getBundleModel()->setSells(0);

            Shopware()->Models()->persist($this->getBundleModel());
        }
        
        return $this->getBundleModel();
    }

    /**
     * @param SwArticleDetail $detail
     * @param int $quantity
     */
    public function prepareArticleDetailBundle(SwArticleDetail $detail, $quantity)
    {
        $this->initDetailImport($detail->getId());

        if($this->getBundleDetailModel() instanceof SwBundleDetail && $this->getBundleDetailModel()->getId() === null)
        {
            $this->getBundleDetailModel()->setArticleDetail($detail);
            $this->getBundleDetailModel()->setBundle($this->getBundleModel());
            $this->getBundleDetailModel()->setQuantity($quantity);
            $this->getBundleDetailModel()->setPosition($this->getPosition());

            $this->setPosition($this->getPosition() + 1);

            Shopware()->Models()->persist($this->getBundleDetailModel());
        }
    }

    /**
     *
     */
    public function prepareBundlePrices()
    {
        foreach($this->getCustomerGroups(false) as $customerGroup)
        {
            $articlePriceModel = $this->loadPriceByCustomerGroups($customerGroup);

            if($articlePriceModel !== null)
            {
                $this->setBundlePrices(array('customerGroup' => $customerGroup->getKey(), 'price' => $articlePriceModel->getPrice()), $customerGroup->getId());
            }
        }
    }

    /**
     * @param SwGroups $customerGroupsModel
     *
     * @return null|SwPrice
     */
    private function loadPriceByCustomerGroups(SwGroups $customerGroupsModel)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Price');
        $priceModel = $repository->findOneBy(
            array(
                'customerGroupKey' => $customerGroupsModel->getKey(),
                'from'             => 1,
                'to'               => 'beliebig',
                'articleDetailsId' => $this->getArticle()->getMainDetail()->getId()
            )
        );

        return $priceModel;
    }

    /**
     * @return array
     */
    public function getBundlePrices()
    {
        return $this->bundlePrices;
    }

    /**
     * @param array $bundlePrices
     * @param $customerGroupId
     *
     * @return Bundle
     */
    public function setBundlePrices($bundlePrices, $customerGroupId)
    {
        if(isset($this->bundlePrices[$bundlePrices['customerGroup']]) === true)
        {
            $totalPrice = $this->bundlePrices[$bundlePrices['customerGroup']]['totalPrice'] + $bundlePrices['price'];
        }
        else
        {
            $totalPrice = $bundlePrices['price'];
        }
        
        $this->bundlePrices[$bundlePrices['customerGroup']] = array(
            'totalPrice' => $totalPrice,
            'customerGroupId' => $customerGroupId
        );
        
        return $this;
    }

    /**
     *
     */
    public function __destruct()
    {
        parent::__destruct();
    }
}
