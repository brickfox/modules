<?php

namespace Bf\Saleschannel\Components\Resources\Bundle;

use Bf\Saleschannel\Components\Resources\ImportAbstract;
use Doctrine\Common\Collections\ArrayCollection;
use Exception;
use Shopware\Models\Article\Article as SwArticle;
use Shopware\Models\Article\Detail as SwArticleDetail;
use \Shopware\CustomModels\Bundle\Bundle as SwBundle;
use \Shopware\CustomModels\Bundle\Article as SwBundleArticle;
use \Shopware\CustomModels\Bundle\Price as SwBundlePrices;

/**
 * BundleAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Bundle
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class BundleAbstract extends ImportAbstract
{
    const BUNDLE_MODEL_PATH_ARTICLE = 'Shopware\CustomModels\Bundle\Article';
    const BUNDLE_MODEL_PATH_BUNDLE  = 'Shopware\CustomModels\Bundle\Bundle';
    const BUNDLE_MODEL_PATH_PRICE   = 'Shopware\CustomModels\Bundle\Price';
    const DISCOUNT_TYPE_ABSOLUTE    = 'abs';

    private $bundleModel;

    private $bundleDetailModel;

    private $bundlePricesCollection;

    /** @var int */
    private $position = 0;

    /**
     * BundleAbstract constructor.
     *
     * @param \SimpleXMLElement $simpleXMLElement
     * @param SwArticle $article
     * @param null|SwArticleDetail $detail
     */
    public function __construct(\SimpleXMLElement $simpleXMLElement, SwArticle $article, $detail = null)
    {
        $this->setArticle($article);
        $this->setDetail($detail);
        $this->setSimpleXmlElement($simpleXMLElement);
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->bundleModel            = null;
        $this->bundleDetailModel      = null;
        $this->bundlePricesCollection = null;
        $this->position               = 0;
        parent::__destruct();
    }

    /**
     * @return void
     */
    public function initImport()
    {
        $this->setBundleModel($this->loadBundleModel());
    }

    /**
     * @param int $detailId
     */
    public function initDetailImport($detailId)
    {
        $this->setBundleDetailModel($this->loadBundleDetailModel($detailId));
    }

    /**
     * @return SwBundle
     */
    private function loadBundleModel()
    {
        $bundleNamespace = self::BUNDLE_MODEL_PATH_BUNDLE;
        $repository      = Shopware()->Models()->getRepository($bundleNamespace);
        $bundleModel     = $repository->findOneBy(array('articleId' => $this->getArticle()->getId()));

        if($bundleModel === null)
        {
            $bundleModel = new SwBundle();
        }

        return $bundleModel;
    }

    /**
     * @param int $detailId
     *
     * @return SwBundleArticle
     */
    private function loadBundleDetailModel($detailId)
    {
        $bundleNamespace   = self::BUNDLE_MODEL_PATH_ARTICLE;
        $repository        = Shopware()->Models()->getRepository($bundleNamespace);
        $bundleDetailModel = $repository->findOneBy(
            array(
                'bundleId'        => $this->getBundleModel()->getId(),
                'articleDetailId' => $detailId
            )
        );

        if($bundleDetailModel === null)
        {
            $bundleDetailModel = new SwBundleArticle();
        }

        return $bundleDetailModel;
    }

    /**
     * @param bool $asCollection
     *
     * @return array|ArrayCollection
     */
    protected function getCustomerGroups($asCollection = true)
    {
        $repository            = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingCurrencies');
        $mappingCurrenciesList = $repository->findAll();

        if($asCollection === true)
        {
            $customerGroupCollection = new ArrayCollection();
        }
        else
        {
            $customerGroupCollection = array();
        }

        /** @var \Shopware\CustomModels\BfSaleschannel\MappingCurrencies $mappingCurrencies */
        foreach($mappingCurrenciesList as $mappingCurrencies)
        {
            try
            {
                $repositoryGroup    = Shopware()->Models()->getRepository('Shopware\Models\Customer\Group');
                $customerGroupModel = $repositoryGroup->findOneBy(array('key' => $mappingCurrencies->getMappingFieldKey()));

                if($asCollection === true)
                {
                    if($customerGroupModel !== null)
                    {
                        $customerGroupCollection->add($customerGroupModel);
                    }
                }
                else
                {
                    if($customerGroupModel !== null)
                    {
                        $customerGroupCollection[] = $customerGroupModel;
                    }
                }
            }
            catch(Exception $e)
            {
                echo $e->getMessage();
            }
        }

        return $customerGroupCollection;
    }

    /**
     * @return int|null
     */
    protected function calculateBundleQuantity()
    {
        $quantity = null;

        foreach($this->getSimpleXmlElement()->ProductsBundleItem as $productsBundleItem)
        {
            if($quantity === null)
            {
                $quantity = (int) $productsBundleItem->Quantity;
            }
            elseif($quantity !== null && $quantity > (int) $productsBundleItem->Quantity)
            {
                $quantity = (int) $productsBundleItem->Quantity;
            }
        }

        return $quantity;
    }

    /**
     * @return void
     */
    protected function setAndSaveBundleTaxId()
    {
        //Plain SQL because the model has no getter/setter method for the taxID field
        Shopware()->Db()->query(
            "update s_articles_bundles set taxID = ? where id = ?",
            array($this->getArticle()->getTax()->getId(), $this->getBundleModel()->getId())
        );
    }

    /**
     * @return \Shopware\CustomModels\Bundle\Bundle
     */
    public function getBundleModel()
    {
        return $this->bundleModel;
    }

    /**
     * @param \Shopware\CustomModels\Bundle\Bundle $bundleModel
     *
     * @return BundleAbstract
     */
    public function setBundleModel($bundleModel)
    {
        $this->bundleModel = $bundleModel;

        return $this;
    }

    /**
     * @return \Shopware\CustomModels\Bundle\Article
     */
    public function getBundleDetailModel()
    {
        return $this->bundleDetailModel;
    }

    /**
     * @param \Shopware\CustomModels\Bundle\Article $bundleDetailModel
     *
     * @return BundleAbstract
     */
    public function setBundleDetailModel($bundleDetailModel)
    {
        $this->bundleDetailModel = $bundleDetailModel;

        return $this;
    }

    /**
     * @return int
     */
    public function getPosition()
    {
        return $this->position;
    }

    /**
     * @param int $position
     *
     * @return BundleAbstract
     */
    public function setPosition($position)
    {
        $this->position = $position;

        return $this;
    }

    /**
     * @return array
     */
    public function getBundlePricesCollection()
    {
        return $this->bundlePricesCollection;
    }

    /**
     * @param array $bundlePricesCollection
     *
     * @return BundleAbstract
     */
    public function setBundlePricesCollection($bundlePricesCollection)
    {
        $this->bundlePricesCollection = $bundlePricesCollection;

        return $this;
    }
}
