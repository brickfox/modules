<?php
namespace Bf\Saleschannel\Components\Resources\Supplier;

use Bf\Saleschannel\Components\Import\Manufacturers;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Shopware\CustomModels\BfSaleschannel\Log;
use SimpleXMLElement;

/**
 * SupplierAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Supplier
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class SupplierAbstract
{
    const ENTITY_NAME = 'Supplier';

    private $simpleXmlElement;

    /**
     * @param $manufacturerId
     *
     * @return null|object
     */
    protected function getSuppliersMappingModel($manufacturerId)
    {
        $mappingModel = Helper::getMappingByValue($manufacturerId, 'brickfoxId', Manufacturers::MAPPING_NAMESPACE_MODEL);

        if($mappingModel === null)
        {
            LogManager::getInstance()->writeLogForGui(
                Log::LOG_STATUS_WARNING,
                __METHOD__,
                str_replace(
                    array('{$supplierId}', '{$itemNumber}', '{$brickfoxId}'),
                    array(
                        (string) $this->getSimpleXmlElement()->ManufacturerId,
                        (string) $this->getSimpleXmlElement()->ItemNumber,
                        (string) $this->getSimpleXmlElement()->ProductId
                    ),
                    ErrorCodes::SUPPLIERS_CAN_NOT_ASSIGN_TO_PRODUCT
                ),
                Helper::getUserName(),
                Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                (string) $this->getSimpleXmlElement()->ProductId,
                ErrorCodes::SUPPLIERS_CAN_NOT_ASSIGN_TO_PRODUCT_ERROR_CODE,
                true,
                true
            );

            LogManager::getInstance()->logDebug(
                str_replace(
                    array('{$supplierId}', '{$itemNumber}', '{$brickfoxId}'),
                    array(
                        (string) $this->getSimpleXmlElement()->ManufacturerId,
                        (string) $this->getSimpleXmlElement()->ItemNumber,
                        (string) $this->getSimpleXmlElement()->ProductId
                    ),
                    ErrorCodes::SUPPLIERS_CAN_NOT_ASSIGN_TO_PRODUCT
                ),
                self::ENTITY_NAME
            );
        }

        return $mappingModel;
    }

    /**
     * @return mixed
     */
    public function getSimpleXmlElement()
    {
        return $this->simpleXmlElement;
    }

    /**
     * @param mixed $simpleXmlElement
     *
     * @return SupplierAbstract
     */
    public function setSimpleXmlElement($simpleXmlElement)
    {
        $this->simpleXmlElement = $simpleXmlElement;

        return $this;
    }

    /**
     * @param SimpleXMLElement $simpleXMLElement
     *
     * @return void
     */
    abstract public function __construct(SimpleXMLElement $simpleXMLElement);

    public function __destruct()
    {
        unset($this->simpleXmlElement);
    }
}
