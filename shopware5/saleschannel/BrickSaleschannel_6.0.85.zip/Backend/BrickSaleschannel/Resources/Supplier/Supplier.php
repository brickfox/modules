<?php
namespace Bf\Saleschannel\Components\Resources\Supplier;

use SimpleXMLElement;

/**
 * Supplier
 *
 * @package Bf\Saleschannel\Components\Resources\Supplier
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Supplier extends SupplierAbstract
{
    /**
     * @param SimpleXMLElement $simpleXMLElement
     */
    public function __construct(SimpleXMLElement $simpleXMLElement)
    {
        $this->setSimpleXmlElement($simpleXMLElement);
    }

    /**
     * @return null|\Shopware\Models\Article\Supplier
     */
    public function prepareSupplierAssignment()
    {
        $supplier = null;

        /** @var \Shopware\CustomModels\BfSaleschannel\MappingSuppliers $manufacturesMappingModel */
        $manufacturesMappingModel = $this->getSuppliersMappingModel((int) $this->getSimpleXmlElement()->ManufacturerId);

        if($manufacturesMappingModel !== null)
        {
            $supplier = $manufacturesMappingModel->getSupplier();
        }

        return $supplier;
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        parent::__destruct();
    }
}
