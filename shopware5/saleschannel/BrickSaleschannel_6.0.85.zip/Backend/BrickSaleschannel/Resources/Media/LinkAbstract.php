<?php
namespace Bf\Saleschannel\Components\Resources\Media;

use Shopware\Models\Article\Article as SwArticle;

/**
 * LinkAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Media
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class LinkAbstract
{
    /** @var string */
    private $url = '';

    /** @var string */
    private $target = '_blank';

    /** @var string */
    private $description = '';

    private $articleModel = null;
    /** @var array */
    private $toDeleteLinkList = array();

    /** @var array */
    private $linkList = array();

    /**
     * @return null|string
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * @param null|string $url
     *
     * @return Links
     */
    public function setUrl($url)
    {
        $this->url = $url;

        return $this;
    }

    /**
     * @return string
     */
    public function getTarget()
    {
        return $this->target;
    }

    /**
     * @param string $target
     *
     * @return Links
     */
    public function setTarget($target)
    {
        $this->target = $target;

        return $this;
    }

    /**
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param string $description
     *
     * @return Links
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * @return null|SwArticle
     */
    public function getArticleModel()
    {
        return $this->articleModel;
    }

    /**
     * @param null|SwArticle $articleModel
     *
     * @return Links
     */
    public function setArticleModel($articleModel)
    {
        $this->articleModel = $articleModel;

        return $this;
    }

    /**
     * @return array
     */
    public function getToDeleteLinkList()
    {
        return $this->toDeleteLinkList;
    }

    /**
     * @param array $toDeleteLinkList
     *
     * @return Links
     */
    public function setToDeleteLinkList($toDeleteLinkList)
    {
        $this->toDeleteLinkList = $toDeleteLinkList;

        return $this;
    }

    /**
     * @return array
     */
    public function getLinkList()
    {
        return $this->linkList;
    }

    /**
     * @param string $linkList
     *
     * @return Links
     */
    public function setLinkList($linkList)
    {
        $this->linkList[] = $linkList;

        return $this;
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->url          = null;
        $this->target       = null;
        $this->description  = null;
        $this->articleModel = null;
    }
}
