<?php

namespace Bf\Saleschannel\Components\Resources\Media;

use Bf\Saleschannel\Components\Gui\Logging;
use Bf\Saleschannel\Components\Resources\ImportAbstract;
use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\ImageHelper;
use Bf\Saleschannel\Components\Util\LogManager;
use Bf\Saleschannel\Components\Util\MediaTypeMapping;
use Exception;
use Shopware\CustomModels\BfSaleschannel\Log;
use Symfony\Component\HttpFoundation\File\File;
use Shopware\Models\Article\Image as SwImage;
use Shopware\Models\Article\Download as SwDownload;
use Shopware\Models\Media\Media as SwMedia;
use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract as BfArticleAbstract;

/**
 * MediaAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Media
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class MediaAbstract extends ImportAbstract
{
    const ENTITY_NAME       = 'Media';
    const FILE_NAME         = 'MediaAbstract.php';
    const SUFFIX            = '_';
    const IMG_BACKUP_SUFFIX = 'bak';
    const PDF_SUFFIX        = '.pdf';
    const HTML_SUFFIX       = '.html';
    const ZIP_SUFFIX        = '.zip';
    const MEDIA_TYPE_URL    = 'URL';
    const NO_SUFFIX         = '.';
    const SVG_SUFFIX        = '.svg';

    /** @var array */
    private $deleteMediaList = array();

    /** @var array */
    private $mediaList = array();

    /** @var array */
    private $mediaDestinationPath = array(
        'media'  => array(
            'pdf'     => 'media/pdf/',
            'music'   => 'media/music/',
            'video'   => 'media/video/',
            'archive' => 'media/archive/'
        ),
        'images' => array(
            'image'      => 'media/image/',
            'thumbnails' => 'media/image/thumbnail/'
        )
    );

    /** @var null */
    private $hashExtension = null;

    /** @var string */
    private $articleMode = 'article';

    /** @var bool */
    private $imageAlreadyExists = false;

    /**
     * @param $url
     * @param null $baseFileName
     * @param null $extension
     *
     * @return array|null
     */
    protected function mediaLoader($url, $baseFileName = null, $extension = null)
    {
        $return = array(
            'name'    => '',
            'success' => false
        );

        $destinationPath = Shopware()->DocPath('media_' . 'temp');
        Helper::checkDir($destinationPath);

        $destinationPath = realpath($destinationPath);

        if (is_writable($destinationPath) === false) {
            LogManager::getInstance()
                ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(array('{$destinationPath}'), array($destinationPath), ErrorCodes::MEDIA_IS_WRITABLE),
                    Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId, ErrorCodes::MEDIA_IS_WRITABLE_ERROR_CODE);
        }

        $urlArray         = parse_url($url);
        $urlArray['path'] = explode(DIRECTORY_SEPARATOR, $url);

        if (array_key_exists('scheme', $urlArray) === true) {
            switch ($urlArray['scheme']) {
                case 'ftp':
                case 'http':
                case 'https':
                case 'file':

                    $fileName = $baseFileName;

                    if ($this->getArticleMode() === BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE) {
                        $fileName = rtrim($fileName, '_') . self::SUFFIX . $this->getHashExtension();
                    }

                    if (ConfigManager::getInstance()->getInitialImport() === false) {
                        $disabledPhpFunctions = explode(',', ini_get('disable_functions'));
                        if (function_exists('exec') && !in_array('exec', $disabledPhpFunctions)) {
                            $url             = pathinfo($url);
                            $url['basename'] = rawurldecode($url['basename']);
                            $url['basename'] = rawurlencode($url['basename']);
                            $cmd = 'wget ' . "\"" . $url['dirname'] . DIRECTORY_SEPARATOR . $url['basename'] . "\"" . ' -O' . $destinationPath . DIRECTORY_SEPARATOR . $fileName;

                            exec($cmd);
                            //shell_exec('wget ' . $url['dirname'] . DIRECTORY_SEPARATOR . $url['basename'] . ' -O' . $destinationPath . DIRECTORY_SEPARATOR . $fileName);
                            $return['name'] = $destinationPath . DIRECTORY_SEPARATOR . $fileName;
                        } else {
                            LogManager::getInstance()
                                ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(array('{$urlArray}'), array($urlArray['scheme']), ErrorCodes::EXEC_DISABLED),
                                    Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId, ErrorCodes::EXEC_DISABLED_ERROR_CODE,
                                    false, false);
                        }
                    } else {
                        $return['name'] = ConfigManager::getInstance()->getImagesPathDirectory() . $fileName . '.' . $extension;
                    }

                    $return['success'] = true;

                    break;

                default:
                    $return = null;
                    break;
            }
        }

        if ($return === null) {
            LogManager::getInstance()
                ->writeLogForGui(Log::LOG_STATUS_WARNING, __METHOD__, str_replace(array('{$urlArray}'), array($urlArray['scheme']), ErrorCodes::MEDIA_UNSUPPORTED_SCHEME),
                    Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId, ErrorCodes::MEDIA_UNSUPPORTED_SCHEME_ERROR_CODE,
                    false, false);
        }

        return $return;
    }

    /**
     * @param $url
     * @param int $albumId
     *
     * @return SwMedia
     * @throws \Exception
     */
    protected function downloadMediaData($url, $albumId = -1)
    {
        $media = $this->internalCreateMediaByLink($url, $albumId);

        return $media;
    }

    /**
     * @param $url
     * @param int $albumId
     *
     * @return SwMedia
     * @throws \Exception
     */
    protected function internalCreateMediaByLink($url, $albumId)
    {
        $media     = null;
        $name      = $this->getMediaName($url);
        $name      = $this->removeSpecialCharacters($name);
        $originalExtension = $this->getMediaExtension($url);
        $extension = $this->prepareExtensions($originalExtension);

        if ($extension !== SwMedia::TYPE_UNKNOWN) {
            $media = $this->verifyIfMediaAlreadyExists($name, $albumId, $extension);
            $path  = $this->mediaLoader($url, $name, $originalExtension);

            if ($path['success'] === true) {
                if (ConfigManager::getInstance()->getInitialImport() === true) {
                    $name = pathinfo($path['name'], PATHINFO_FILENAME);
                } else {
                    if ($this->getArticleMode() === BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE) {
                        $name = rtrim($name, '_') . self::SUFFIX . $this->getHashExtension();
                    }
                }

                $file = new File($path['name']);

                if ($file->guessExtension() !== null) {
                    if ($media === null) {
                        $media = new SwMedia();
                        $media->setAlbumId($albumId);
                        $media->setFile($file);
                        $media->setName($name);
                        $media->setDescription('');
                        $media->setCreated(new \DateTime());
                        $media->setUserId(0);
                    } else {
                        if ($media instanceof SwMedia) {
                            $media->setAlbumId($albumId);
                            /** @var \Shopware\Bundle\MediaBundle\MediaService $mediaService */
                            $mediaService = Shopware()->Container()->get('shopware_media.media_service');
                            $mediaService->write($media->getPath(), file_get_contents($file->getRealPath()));
                            unlink($path['name']);
                        }
                    }

                    $repository = Helper::getRepository('Shopware\Models\Media\Album');

                    /** @var \Shopware\Models\Media\Album $albumModel */
                    $albumModel = $repository->find($albumId);

                    if ($albumModel === null) {
                        LogManager::getInstance()
                            ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(array('{$albumId}'), array($albumId), ErrorCodes::ALBUM_ID_NOT_FOUND),
                                Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId,
                                ErrorCodes::ALBUM_ID_NOT_FOUND_ERROR_CODE);
                    }

                    $media->setAlbum($albumModel);

                    //persist the model into the model manager this uploads and resizes the image
                    Shopware()->Models()->persist($media);

                    if ($media->getType() === SwMedia::TYPE_IMAGE) {
                        ImageHelper::getInstance()->addThumbnailsToGenerate($media);
                    }
                } else {
                    /** @var \Shopware\Bundle\MediaBundle\MediaService $mediaService */
                    $mediaService = Shopware()->Container()->get('shopware_media.media_service');

                    if ($mediaService->has(Shopware()->DocPath('media_' . 'temp') . $path['name']) === true) {
                        $mediaService->delete(Shopware()->DocPath('media_' . 'temp') . $path['name']);
                    }
                }
            }
        }

        return $media;
    }

    /**
     * @param $extension
     *
     * @return string
     */
    private function prepareExtensions($extension)
    {
        $extension = strtolower($extension);

        switch ($extension) {
            case 'JPEG':
            case 'jpeg':
                $extension = 'jpg';
                break;
            default:
                break;
        }

        return $extension;
    }

    /**
     * @param $name
     * @param $albumId
     * @param $extension
     * @return null|\Shopware\Models\Media\Media
     * @throws \Exception
     */
    private function verifyIfMediaAlreadyExists($name, $albumId, $extension)
    {
        $mediaModel   = null;
        $extensionArr = array();

        if ($this->getArticleMode() === BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE) {
            $name = rtrim($name, '_') . self::SUFFIX . $this->getHashExtension();
        }

        $repository  = Helper::getRepository('Shopware\Models\Media\Media');
        $mediaModels = $repository->findBy(array('path' => 'media/image/' . $name . '.' . $extension, 'albumId' => $albumId));

        /** @var \Shopware\Models\Media\Media $mediaEntries */
        foreach ($mediaModels as $mediaEntries) {
            if ($mediaEntries->getPath() === 'media/image/' . $name . '.' . $extension) {
                $mediaModel = $mediaEntries;
                break;
            }
        }

        if ($mediaModel !== null) {
            $this->setImageAlreadyExists(true);
            $extensionArr = array($mediaModel->getExtension());
        } else {
            if ($albumId === -1) {
                $extensionArr = array('jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'PNG', 'gif', 'GIF', 'bmp', 'BMP');
            } elseif ($albumId === -6) {
                $extensionArr = array('pdf', 'PDF', 'zip', 'ZIP');
            }
        }

        if (Helper::versionCompare(Shopware()->Config()->version, '5.1.0', '>=')) {
            $mediaService = Shopware()->Container()->get('shopware_media.media_service');

            if ($mediaService->has(Shopware()->DocPath('media_unknown') . $name . self::HTML_SUFFIX)) {
                $mediaService->delete(Shopware()->DocPath('media_unknown') . $name . self::HTML_SUFFIX);
            } elseif ($mediaService->has(Shopware()->DocPath('media_unknown') . $name . self::NO_SUFFIX)) {
                $mediaService->delete(Shopware()->DocPath('media_unknown') . $name . self::NO_SUFFIX);
            } elseif ($mediaService->has(Shopware()->DocPath('media_unknown') . $name . self::SVG_SUFFIX)) {
                $mediaService->delete(Shopware()->DocPath('media_unknown') . $name . self::SVG_SUFFIX);
            } elseif ($mediaService->has(Shopware()->DocPath('media_pdf') . $name . self::PDF_SUFFIX)) {
                $mediaService->delete(Shopware()->DocPath('media_pdf') . $name . self::PDF_SUFFIX);
            } elseif ($mediaService->has(Shopware()->DocPath('media_archive') . $name . self::ZIP_SUFFIX)) {
                $mediaService->delete(Shopware()->DocPath('media_archive') . $name . self::ZIP_SUFFIX);
            }
        }

        foreach ($extensionArr as $extension) {
            if (Helper::versionCompare(Shopware()->Config()->version, '5.1.0', '>=')) {
                $mediaService = Shopware()->Container()->get('shopware_media.media_service');

                if ($mediaService->has(Shopware()->DocPath('media_image') . $name . '.' . $extension)) {
                    $success = $mediaService->delete(Shopware()->DocPath('media_image') . $name . '.' . $extension);

                    if ($success === true && $mediaModel !== null) {
                        /** @var \Shopware\Components\Thumbnail\Manager $thumbnailManager */
                        $thumbnailManager = Shopware()->Container()->get('thumbnail_manager');
                        $thumbnailManager->removeMediaThumbnails($mediaModel);
                    }
                }
            } else {
                if (file_exists(Shopware()->DocPath('media_image') . $name . '.' . $extension) === true) {

                    unlink(Shopware()->DocPath('media_image') . DIRECTORY_SEPARATOR . $name . '.' . $extension);
                    break;
                }
            }
        }

        return $mediaModel;
    }

    /**
     * @param string $mode
     * @param \Shopware\Models\Article\Detail|null $detail
     *
     * @throws \Exception
     * @return void
     */
    protected function deleteMediaByDeleteList($mode = 'image', $detail)
    {
        if (count($this->getDeleteMediaList()) > 0) {
            /** @var \Shopware\Models\Article\Image|\Shopware\Models\Media\Media $deleteListItem */
            foreach ($this->getDeleteMediaList() as $deleteListItem) {
                switch ($mode) {
                    case 'image':
                        if (ConfigManager::getInstance()->keepMissingImagesInImport() === true) {
                            return;
                        }

                        if ($this->getArticleMode() === BfArticleAbstract::IMPORT_ARTICLE_IMAGE_MODE) {
                            if ($this->isLastImageAssignment($deleteListItem) === true) {
                                if ($this->killMedia($mode, $deleteListItem) === false) {
                                    LogManager::getInstance()
                                        ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__,
                                            str_replace(array('{$mediaFile}'), array($deleteListItem->getPath() . '.' . $deleteListItem->getExtension()),
                                                ErrorCodes::CAN_NOT_DELETE_MEDIA_FILE), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                                            (string)$this->getSimpleXmlElement()->ProductId, ErrorCodes::CAN_NOT_DELETE_MEDIA_FILE_ERROR_CODE);
                                }

                                $this->clearMediaEntries($deleteListItem->getMedia()->getId());
                            }
                            Helper::doModelOperation($deleteListItem, array(), Helper::OPERATION_REMOVE);
                        } elseif ($this->getArticleMode() === BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE) {
                            /** @var \Shopware\Models\Article\Image $child */
                            foreach ($deleteListItem->getChildren() as $child) {
                                if (method_exists($detail, 'getId') === true) {
                                    if ($child->getArticleDetail()->getId() !== $detail->getId()) {
                                        continue;
                                    }

                                    /**
                                     * workaround because of problem with the entity manager if we
                                     * delete the child elements out of the box
                                     */
                                    Shopware()
                                        ->Db()
                                        ->query("delete from s_articles_img where parent_id = ? and article_detail_id = ?",
                                            array($child->getParent()->getId(), $child->getArticleDetail()->getId()));

                                    if ($this->isLastImageAssignment($child) === true) {
                                        if ($this->killMedia($mode, $deleteListItem) === false) {
                                            LogManager::getInstance()
                                                ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__,
                                                    str_replace(array('{$mediaFile}'), array($deleteListItem->getPath() . '.' . $deleteListItem->getExtension()),
                                                        ErrorCodes::CAN_NOT_DELETE_MEDIA_FILE), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                                                    (string)$this->getSimpleXmlElement()->ProductId, ErrorCodes::CAN_NOT_DELETE_MEDIA_FILE_ERROR_CODE);
                                        }

                                        $this->clearMediaEntries($deleteListItem->getMedia()->getId());
                                        Shopware()->Db()->query("delete from s_articles_img where id = ?", array($deleteListItem->getId()));
                                    }
                                }
                            }
                        }

                        break;

                    case 'media':
                        Shopware()
                            ->Db()
                            ->query("delete from s_articles_downloads where articleID = ? and filename = ?",
                                array($deleteListItem->getArticle()->getId(), $deleteListItem->getFile()));
                        break;

                    default:
                        break;
                }
            }
        }
    }

    /**
     * @param $mode
     * @param SwImage|SwDownload $model
     *
     * @return bool
     */
    private function killMedia($mode, $model)
    {
        $return = false;

        if ($model !== null && is_object($model)) {
            switch ($mode) {
                case 'image':
                    if (Helper::versionCompare(Shopware()->Config()->version, '5.1.0', '>=')) {
                        try {
                            /** @var \Shopware\Bundle\MediaBundle\MediaService $mediaService */
                            $mediaService = Shopware()->Container()->get('shopware_media.media_service');

                            /** @var \Shopware\Components\Thumbnail\Manager $thumbnailManager */
                            $thumbnailManager = Shopware()->Container()->get('thumbnail_manager');
                            try {
                                $mediaModel = $model->getMedia();

                                if ($mediaService->has($mediaModel->getPath()) === true) {
                                    $success = $mediaService->delete($mediaModel->getPath());

                                    if ($success === true) {
                                        $thumbnailManager->removeMediaThumbnails($mediaModel);
                                    }
                                } else {
                                    $thumbnailManager->removeMediaThumbnails($mediaModel);
                                }
                            } catch (\Exception $e) {
                            }
                            $return = true;
                        } catch (\Exception $e) {
                        }
                    } else {
                        if (is_dir($this->getMediaDestinationPath()['images']['image']) === true) {
                            unlink($this->getMediaDestinationPath()['images']['image'] . $model->getPath() . '.' . $model->getExtension());
                            $return = true;
                        }

                        if (is_dir($this->getMediaDestinationPath()['images']['thumbnails']) === true) {
                            array_map('unlink', glob($this->getMediaDestinationPath()['images']['thumbnails'] . $model->getPath() . '*.' . $model->getExtension()));
                        }
                    }

                    break;

                case 'media':
                    if (Helper::versionCompare(Shopware()->Config()->version, '5.1.0', '>=')) {
                        try {
                            /** @var \Shopware\Bundle\MediaBundle\MediaService $mediaService */
                            $mediaService = Shopware()->Container()->get('shopware_media.media_service');
                            $mediaModel   = $model->getMedia();

                            if ($mediaService->has($mediaModel->getPath()) === true) {
                                $mediaService->delete($mediaModel->getPath());
                            }

                            $return = true;

                        } catch (\Exception $e) {
                        }

                    } else {
                        if (is_dir($this->getMediaDestinationPath()['media']['pdf']) === true) {
                            unlink($model->getPath());
                        } elseif (is_dir($this->getMediaDestinationPath()['media']['archive']) === true) {
                            unlink($model->getPath());
                        }
                    }


                    break;
            }
        }

        return $return;
    }

    /**
     * @param \Shopware\Models\Article\Image $image
     * @return bool
     * @throws \Doctrine\ORM\NoResultException
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    private function isLastImageAssignment(SwImage $image)
    {
        $isLastImageAssignment = false;
        $childResult           = 0;

        if ($this->getArticleMode() === BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE) {
            $articleId = $image->getParent()->getArticle()->getId();

            $qb = Shopware()->Models()->createQueryBuilder();
            $qb->select('COUNT(images.id) as num_ids')
                ->from('Shopware\Models\Article\Image', 'images')
                ->where('images.path = :path')
                ->andWhere('images.parentId = :parentId')
                ->andWhere('images.articleDetailId != :articleDetailId')
                ->setParameters(array('path' => $image->getPath(), 'parentId' => $image->getParent()->getId(), 'articleDetailId' => $image->getArticleDetail()->getId()));

            $childResult = $qb->getQuery()->getSingleScalarResult();
        } else {
            $articleId = $image->getArticle()->getId();
        }

        $qb = Shopware()->Models()->createQueryBuilder();
        $qb->select('COUNT(images.id) as num_ids')
            ->from('Shopware\Models\Article\Image', 'images')
            ->where('images.path = :path')
            ->andWhere('images.articleId != :articleId')
            ->andWhere('images.articleId is not null')
            ->setParameters(array('path' => $image->getPath(), 'articleId' => $articleId));

        $mainResult = $qb->getQuery()->getSingleScalarResult();

        if ((int)$mainResult === 0 && (int)$childResult === 0) {
            $isLastImageAssignment = true;
        }

        return $isLastImageAssignment;
    }

    /**
     * @param $albumId
     * @throws \Zend_Db_Adapter_Exception
     */
    private function clearMediaEntries($albumId)
    {
        Shopware()->Db()->query("
            delete from s_media where id = ?
            ", array($albumId));
    }

    /**
     * @param        $articleId
     * @param        $url
     * @param string $mode
     * @return null|\Shopware\Models\Article\Download|\Shopware\Models\Article\Image
     * @throws \Exception
     */
    protected function loadMediaIfExists($articleId, $url, $mode = 'image')
    {
        $name      = $this->getMediaName($url);
        $name      = $this->removeSpecialCharacters($name);
        $extension = $this->prepareExtensions($this->getMediaExtension($url));

        if ($this->getArticleMode() === BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE) {
            $name = rtrim($name, '_') . self::SUFFIX . $this->getHashExtension();
        }

        $this->setMediaList($name, $extension);

        $model = $this->loadArticleMedia($articleId, $name, $mode, $extension);

        return $model;
    }

    /**
     * @param $articleId
     * @param $name
     * @param $mode
     * @param $extension
     *
     * @return null|SwDownload|SwImage
     */
    private function loadArticleMedia($articleId, $name, $mode, $extension)
    {
        $model = null;

        switch ($mode) {
            case 'image':
                if (strlen($name) > 0) {
                    $mediaModel  = null;
                    $repository  = Helper::getRepository('Shopware\Models\Media\Media');
                    $mediaModels = $repository->findBy(array('path' => 'media/image/' . $name . '.' . $extension, 'albumId' => -1));

                    /** @var \Shopware\Models\Media\Media $mediaEntries */
                    foreach ($mediaModels as $mediaEntries) {
                        if ($mediaEntries->getPath() === 'media/image/' . $name . '.' . $extension) {
                            $mediaModel = $mediaEntries;
                            break;
                        }
                    }

                    if ($mediaModel !== null) {
                        $repository = Helper::getRepository('Shopware\Models\Article\Image');
                        $imageModel = $repository->findOneBy(array('articleId' => $articleId, 'mediaId' => $mediaModel->getId()));

                        if ($imageModel !== null) {
                            $model = $imageModel;
                        } else {
                            $model = new SwImage();
                            $model->setPath($mediaModel->getName());
                            $model->setMedia($mediaModel);
                        }
                    } else {
                        if ($this->getArticleMode() === BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE &&
                            ConfigManager::getInstance()->getImageMappingDiffsOptionsStatus() === false) {
                            $imagePreSaveArr = ImageHelper::getInstance()->imageWillBeExistsIfArticleIsSave($name);

                            if ($imagePreSaveArr !== null) {
                                $model = $imagePreSaveArr[0];
                                ImageHelper::getInstance()->setPreSaveIsActive(true);
                            }
                        }
                    }

                    //                    $repository = Helper::getRepository('Shopware\Models\Article\Image');
                    //                    /** @var \Shopware\Models\Article\Image $model */
                    //                    $model = $repository->findOneBy(array('articleId' => $articleId, 'path' => $name));
                    //
                    //                    if($model === null)
                    //                    {
                    //                        /** @var \Shopware\Models\Article\Image $rawImagesModel */
                    //                        $rawImagesModel = $repository->findOneBy(array('path' => $name));
                    //
                    //                        if($rawImagesModel !== null)
                    //                        {
                    //                            $model = new SwImage();
                    //                            $model->setPath($rawImagesModel->getPath());
                    //
                    //                            $mediaRepository = Helper::getRepository('Shopware\Models\Media\Media');
                    //                            $mediaModel      = $mediaRepository->findOneBy(array('id' => $rawImagesModel->getMedia()->getId()));
                    //
                    //                            if($mediaModel !== null)
                    //                            {
                    //                                $model->setMedia($rawImagesModel->getMedia());
                    //                            }
                    //                        }
                    //                        else
                    //                        {
                    //                            $mediaRepository = Helper::getRepository('Shopware\Models\Media\Media');
                    //
                    //                            /** @var \Shopware\Models\Media\Media $mediaModel */
                    //                            $mediaModel = $mediaRepository->findOneBy(array('name' => $name, 'albumId' => -1));
                    //
                    //                            if($mediaModel !== null)
                    //                            {
                    //                                $model = new SwImage();
                    //                                $model->setPath($mediaModel->getName());
                    //                                $model->setMedia($mediaModel);
                    //                            }
                    //                            else
                    //                            {
                    //                                if($this->getArticleMode() === BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE)
                    //                                {
                    //                                    $imagePreSaveArr = ImageHelper::getInstance()->imageWillBeExistsIfArticleIsSave($name);
                    //
                    //                                    if($imagePreSaveArr !== null)
                    //                                    {
                    //                                        $model = $imagePreSaveArr[0];
                    //                                        ImageHelper::getInstance()->setPreSaveIsActive(true);
                    //                                    }
                    //                                }
                    //                            }
                    //                        }
                    //                    }
                }
                break;

            case 'media':
                if (strlen($name) > 0) {
                    $repository = Helper::getRepository('Shopware\Models\Media\Media');
                    $mediaModel = $repository->findOneBy(array('name' => $name, 'albumId' => -6));

                    if ($mediaModel != null) {
                        $path       = $mediaModel->getPath();
                        $repository = Helper::getRepository('Shopware\Models\Article\Download');
                        $model      = $repository->findOneBy(array('articleId' => $articleId, 'file' => $path));
                        if ($model === null) {
                            $model = new SwDownload();
                            $model->setFile($mediaModel->getPath());
                        }
                    }
                }
                break;
        }

        return $model;
    }

    /**
     * @param $url
     *
     * @return mixed
     * @throws \Exception
     */
    protected function getMediaName($url)
    {
        $name = pathinfo($url, PATHINFO_FILENAME);

        if (strlen($name) < 1) {
            LogManager::getInstance()
                ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(array('{$fileName}', '{$itemNumber}', '{$brickfoxId}'),
                    array($url, (string)$this->getSimpleXmlElement()->ItemNumber, (string)$this->getSimpleXmlElement()->ProductId), ErrorCodes::MEDIA_COULD_NOT_DETECT_FILE_NAME),
                    Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId,
                    ErrorCodes::MEDIA_COULD_NOT_DETECT_FILE_NAME_ERROR_CODE);
        }

        return $name;
    }

    /**
     * @param $url
     *
     * @return mixed
     */
    protected function getMediaExtension($url)
    {
        $extension = pathinfo($url, PATHINFO_EXTENSION);

        if (Helper::getConfigurationByKey('imageUrlWithoutExtension')->getConfigurationValue() == 'false') {
            if (strlen($extension) < 1 || array_key_exists(strtolower($extension), MediaTypeMapping::$typeMapping) === false) {
                LogManager::getInstance()
                    ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(array('{$fileName}', '{$itemNumber}', '{$brickfoxId}'),
                        array($url, ((bool) $this->getSimpleXmlElement()->ItemNumber) ? (string)$this->getSimpleXmlElement()->ItemNumber : '',
                            ((bool)$this->getSimpleXmlElement()->ProductId) ? (string)$this->getSimpleXmlElement()->ProductId : 000),
                        ErrorCodes::MEDIA_COULD_NOT_DETECT_EXTENSION), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                        ((bool)$this->getSimpleXmlElement()->ProductId) ? (string)$this->getSimpleXmlElement()->ProductId : 000,
                        ErrorCodes::MEDIA_COULD_NOT_DETECT_EXTENSION_ERROR_CODE, false, false);
                $extension = SwMedia::TYPE_UNKNOWN;
            }
        } else {
            if (strlen($extension) < 1 || array_key_exists(strtolower($extension), MediaTypeMapping::$typeMapping) === false) {
                $extension = '';
            }
        }

        return $extension;
    }

    /**
     * @param $imageXmlElement
     *
     * @return string
     */
    protected function getMediaPath($imageXmlElement)
    {
        $path = '';

        if ((bool)$imageXmlElement->Path === true) {
            $path = str_replace('https://', 'http://', (string)$imageXmlElement->Path);
        }

        return $path;
    }

    /**
     * @return array
     */
    public function getDeleteMediaList()
    {
        return $this->deleteMediaList;
    }

    /**
     * @param $deleteMediaList
     *
     * @return MediaAbstract
     */
    public function setDeleteMediaList($deleteMediaList)
    {
        $this->deleteMediaList[] = $deleteMediaList;

        return $this;
    }

    /**
     * @return array
     */
    public function getMediaList()
    {
        return $this->mediaList;
    }

    /**
     * @param $imageName
     * @param $extension
     *
     * @return MediaAbstract
     */
    public function setMediaList($imageName, $extension)
    {
        $this->mediaList[] = array('imageName' => $imageName, 'extension' => $extension);

        return $this;
    }

    /**
     * @return array
     */
    public function getMediaDestinationPath()
    {
        return $this->mediaDestinationPath;
    }

    /**
     * @return null
     */
    public function getHashExtension()
    {
        return $this->hashExtension;
    }

    /**
     * @param null $hashExtension
     *
     * @return MediaAbstract
     */
    public function setHashExtension($hashExtension)
    {
        $this->hashExtension = $hashExtension;

        return $this;
    }

    /**
     * @return string
     */
    public function getArticleMode()
    {
        return $this->articleMode;
    }

    /**
     * @param string $articleMode
     *
     * @return MediaAbstract
     */
    public function setArticleMode($articleMode)
    {
        $this->articleMode = $articleMode;

        return $this;
    }

    /**
     * @return boolean
     */
    public function getImageAlreadyExists()
    {
        return $this->imageAlreadyExists;
    }

    /**
     * @param boolean $imageAlreadyExists
     *
     * @return MediaAbstract
     */
    public function setImageAlreadyExists($imageAlreadyExists)
    {
        $this->imageAlreadyExists = $imageAlreadyExists;

        return $this;
    }

    /**
     * @param $error
     * @param $e
     * @param $code
     *
     * @return void
     */
    protected function throwWarning($error = null, $e = null, $code = null)
    {
        switch ($error) {
            case 'path':
                LogManager::getInstance()->logDebug(ErrorCodes::CAN_NOT_SAVE_IMAGE_WITHOUT_IMAGE_PATH, self::ENTITY_NAME);
                Helper::fromArray(new Log(), array(
                    Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_WARNING,
                    Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                    Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::CAN_NOT_SAVE_IMAGE_WITHOUT_IMAGE_PATH_ERROR_CODE,
                    Logging::SETTER_ALIAS_LOG_MESSAGE => ErrorCodes::CAN_NOT_SAVE_IMAGE_WITHOUT_IMAGE_PATH,
                    Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                ));
                break;

            default:
                LogManager::getInstance()->logDebug($e, self::ENTITY_NAME);
                Helper::fromArray(new Log(), array(
                    Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_WARNING,
                    Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                    Logging::SETTER_ALIAS_ERROR_CODE  => $code,
                    Logging::SETTER_ALIAS_LOG_MESSAGE => $e,
                    Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                ));
                break;
        }
    }

    /**
     * @param $name
     *
     * @return string
     */
    protected function removeSpecialCharacters($name)
    {
        $name = iconv('utf-8', 'ascii//translit', $name);
        $name = preg_replace('#[^A-z0-9\-_]#', '-', $name);
        $name = preg_replace('#-{2,}#', '-', $name);
        $name = trim($name, '-');

        return mb_substr($name, 0, 180);
    }
}
