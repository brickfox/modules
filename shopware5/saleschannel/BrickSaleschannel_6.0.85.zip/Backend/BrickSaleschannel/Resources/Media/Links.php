<?php
namespace Bf\Saleschannel\Components\Resources\Media;

use Shopware\Models\Article\Article as SwArticle;
use Shopware\Models\Article\Link as SwLink;

/**
 * Links
 *
 * @package Bf\Saleschannel\Components\Resources\Media
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Links extends LinkAbstract
{
    /**
     * @param \SimpleXMLElement $mediaXmlElement
     * @param SwArticle $swArticle
     *
     * @return void
     */
    public function setProperties(\SimpleXMLElement $mediaXmlElement, SwArticle $swArticle)
    {
        $articleModel = $swArticle;
        $url          = ((bool) $mediaXmlElement->Path === true && strlen($mediaXmlElement->Path) > 0) ? (string) $mediaXmlElement->Path : null;
        $description  = ((bool) $mediaXmlElement->Name === true && strlen($mediaXmlElement->Name) > 0) ? (string) $mediaXmlElement->Name : '';

        $this->setUrl($url);
        $this->setArticleModel($articleModel);
        $this->setDescription($description);
    }

    /**
     * @return void
     */
    public function prepareLinks()
    {
        if($this->getUrl() !== null && $this->getArticleModel() !== null)
        {
            $linkModel = $this->loadLinkModel(false, array('articleId' => $this->getArticleModel()->getId(), 'link' => $this->getUrl()));

            if($linkModel === null)
            {
                $linkModel = $this->loadLinkModel(true);
                $linkModel->setName($this->getDescription());
                $linkModel->setArticle($this->getArticleModel());
                $linkModel->setTarget($this->getTarget());
                $linkModel->setLink($this->getUrl());
            }
            else
            {
                $linkModel->setName($this->getDescription());
            }

            $this->setLinkList($linkModel->getLink());

            Shopware()->Models()->persist($linkModel);
        }
    }

    /**
     * @param bool $isNewModel
     * @param array $criteria
     *
     * @return \Shopware\Models\Article\Link
     */
    private function loadLinkModel($isNewModel = false, array $criteria = array())
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Link');
        if($isNewModel === false)
        {
            $linkModel = $repository->findOneBy($criteria);
        }
        else
        {
            $linkModel = new SwLink();
        }

        return $linkModel;
    }

    /**
     * @param SwArticle $article
     *
     * @return array
     */
    public function prepareToDeleteList(SwArticle $article)
    {
        $qb = Shopware()->Models()->createQueryBuilder();
        $qb->select('links')->from('Shopware\Models\Article\Link', 'links')->where('links.articleId = :articleId')->setParameter('articleId', $article->getId());

        $sql      = $qb->getQuery();
        $linkList = $sql->getArrayResult();

        $this->setToDeleteLinkList($linkList);
    }

    /**
     * @return void
     */
    public function removeLinks()
    {
        $toDeleteList = $this->getToDeleteLinkList();
        foreach($toDeleteList as $key => $removeLink)
        {
            foreach($this->getLinkList() as $link)
            {
                if($removeLink['link'] === $link)
                {
                    unset($toDeleteList[$key]);
                }
            }
        }

        foreach($toDeleteList as $removeLink)
        {
            Shopware()->Db()->query(
                "
                    delete from s_articles_information where id = ?
                ",
                array($removeLink['id'])
            );
        }
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        parent::__destruct();
    }
}
