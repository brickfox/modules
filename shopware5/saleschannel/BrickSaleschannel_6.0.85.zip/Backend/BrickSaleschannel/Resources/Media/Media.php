<?php
namespace Bf\Saleschannel\Components\Resources\Media;

use Bf\Saleschannel\Components\Util\Exceptions;
use Shopware\Models\Article\Article as SwArticle;
use Shopware\Models\Article\Download as SwDownloads;
use SimpleXMLElement;

/**
 * Media
 *
 * @package Bf\Saleschannel\Components\Resources\Media
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Media extends MediaAbstract
{
    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param SwArticle $article
     *
     * @throws \Exception
     * @return void
     */
    public function prepareMedia(SimpleXMLElement $simpleXMLElement, SwArticle $article)
    {
        $linkClass = new Links();
        $linkClass->prepareToDeleteList($article);

        if((bool) $simpleXMLElement->Media === true)
        {
            foreach($simpleXMLElement->Media->MediaEntry as $mediaXmlElement)
            {
                if((string) $mediaXmlElement->Type !== self::MEDIA_TYPE_URL)
                {
                    $url = $this->getMediaPath($mediaXmlElement);
                    echo '<pre>';
                    print_r($url);
                    echo '</pre>';
                    if(strlen($url) === 0)
                    {
                        $this->throwWarning('path');
                        continue;
                    }

                    $oldDownloadModel = $this->loadMediaIfExists($article->getId(), $url, 'media');

                    if($oldDownloadModel === null)
                    {
                        echo '<pre>';
                        print_r("is null");
                        echo '</pre>';
                        if($this->getImageAlreadyExists() === false)
                        {
                            echo '<pre>';
                            print_r('here');
                            echo '</pre>';
                            $oldDownloadModel = new SwDownloads();
                        }

                        $mediaModel = $this->downloadMediaData($url, -6);
                    }
                    else
                    {
                        $mediaModel = null;
                    }

                    if($oldDownloadModel instanceof \Shopware\Models\Article\Download)
                    {
                        $newDownloadModel = $this->prepareDownloadData($article, $oldDownloadModel, $mediaXmlElement, $mediaModel);

                        if($newDownloadModel !== false)
                        {
                            if($newDownloadModel instanceof \Shopware\Models\Article\Download)
                            {
                                Shopware()->Models()->persist($newDownloadModel);
                                $article->getDownloads()->add($newDownloadModel);
                            }
                            else
                            {
                                continue;
                            }
                        }
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    $linkClass->setProperties($mediaXmlElement, $article);
                    $linkClass->prepareLinks();
                }
            }
        }

        $linkClass->removeLinks();
        $this->prepareToDeleteMediaList($article->getId());
    }

    /**
     * @param SwArticle $article
     * @param SwDownloads $download
     * @param SimpleXMLElement $mediaXmlElement
     * @param null $mediaModel
     *
     * @return SwDownloads
     */
    private function prepareDownloadData(SwArticle $article, SwDownloads $download, SimpleXMLElement $mediaXmlElement, $mediaModel = null)
    {
        $download->setName($this->getFileName($mediaXmlElement));
        $fileName = ($mediaModel === null) ? $download->getFile() : $mediaModel->getPath();

        if(strlen($fileName) > 0)
        {
            $download->setFile($fileName);
            $download->setArticle($article);

            if (method_exists($download, 'setSize')) {
                $download->setSize(0);
            }
        }
    else
        {
            $download = false;
        }

        return $download;
    }

    /**
     * @param SimpleXMLElement $mediaXmlElement
     *
     * @return string
     */
    private function getFileName(SimpleXMLElement $mediaXmlElement)
    {
        if((bool) ($mediaXmlElement->Name) === true)
        {
            $fileName = (string) $mediaXmlElement->Name;
        }
        else
        {
            $fileName = (string) $mediaXmlElement->Path;
        }

        return $fileName;
    }

    /**
     * @param $articleId
     *
     * @return void
     * @throws \Exception
     */
    private function prepareToDeleteMediaList($articleId)
    {
        $qb = Shopware()->Models()->createQueryBuilder();
        $qb->select(array('download'))->from('Shopware\Models\Article\Download', 'download')->where('download.articleId = :articleId')->setParameter('articleId', $articleId);

        $sql          = $qb->getQuery();
        $downloadList = $sql->getResult();

        foreach($downloadList as $download)
        {
            $existingFile = pathinfo($download->getFile(), PATHINFO_FILENAME);
            $exists = false;

            if (count($this->getMediaList()) > 0) {
                foreach ($this->getMediaList() as $medias) {
                    if ($medias['imageName'] === $existingFile) {
                        $exists = true;
                        break;
                    }
                }

                //ToDo diese Stelle prüfen evtl. ist das Problem das die Downloads die hinzukommen direkt wieder rausgeworfen werden.
                if ($exists === false) {
                    $this->setDeleteMediaList($download);
                }

            } else {
                $this->setDeleteMediaList($download);
            }
        }

        $this->deleteMediaByDeleteList('media', null);
    }
}
