<?php

namespace Bf\Saleschannel\Components\Resources\Report;

use Bf\Saleschannel\Components\Util\FileWriter;
use Bf\Saleschannel\Components\Util\Helper;

/**
 * Class ProductsReports
 *
 * @package Bf\Saleschannel\Components\Resources\Report
 */
class ProductsReports extends ProductsReportsAbstract
{
    /**
     * ProductsReports constructor.
     *
     * @param \Shopware\CustomModels\BfSaleschannel\MappingArticles $bfMappingArticlesModel
     * @param array $sCoreRewriteUrlsInformation
     * @param $articleId
     */
    public function __construct(\Shopware\CustomModels\BfSaleschannel\MappingArticles $bfMappingArticlesModel, array $sCoreRewriteUrlsInformation, $articleId)
    {
        parent::__construct($bfMappingArticlesModel, $sCoreRewriteUrlsInformation, $articleId);
    }

    /**
     * @param $shopsId
     *
     * @return void
     */
    public function prepareProductsReportsNode($shopsId)
    {
        FileWriter::$xmlElements['ProductsReport-' . FileWriter::$internalArrayKeyCounter] = array(
            'Actions'         => array(
                'Action' => array('@cdata' => ProductsReportsAbstract::BRICKFOX_REPORTS_PRODUCTS_LINK_ACTION_NAME),
            ),
            'ProductsId'      => array('@value' => $this->getBfMappingArticlesModel()->getBrickfoxId()),
            'RawProductsLink' => array('@cdata' => $this->getHostInformation($shopsId) . $this->getSCoreRewriteUrlsInformation()['org_path']),
            'ProductsLink'    => array('@cdata' => $this->getHostInformation($shopsId) . $this->getSCoreRewriteUrlsInformation()['path'])
        );

        $this->addVariationsInformation($shopsId);
    }

    /**
     * @param $shopsId
     */
    private function addVariationsInformation($shopsId)
    {
        if ($this->getBfMappingArticlesModel()->getArticle()->getDetails()->count() > 0) {
            $key = 0;

            /**
             * @var  $detailsKey
             * @var \Shopware\Models\Article\Detail $detailsModel
             */
            foreach ($this->getBfMappingArticlesModel()->getArticle()->getDetails() as $detailsKey => $detailsModel) {
                $bfMappingArticlesDetailsMappingRepository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingDetails');
                /** @var \Shopware\CustomModels\BfSaleschannel\MappingDetails $bfMappingArticlesDetailsMappingModel */
                $bfMappingArticlesDetailsMappingModel = $bfMappingArticlesDetailsMappingRepository->findOneBy(array('shopwareId' => $detailsModel->getId()));

                if ($bfMappingArticlesDetailsMappingModel !== null) {
                    FileWriter::$xmlElements['ProductsReport-' . FileWriter::$internalArrayKeyCounter]['Variations']['Variation'][] = array(
                        'VariationAddInfo' => array(
                            'ProductsVariationsId' => array('@value' => $bfMappingArticlesDetailsMappingModel->getBrickfoxId()),
                            'RawProductsLink'      => array(
                                '@cdata' => $this->getHostInformation($shopsId) . $this->getSCoreRewriteUrlsInformation()['org_path'] . '?number=' . $detailsModel->getNumber()
                            ),
                            'ProductsLink'         => array(
                                '@cdata' => $this->getHostInformation($shopsId) . $this->getSCoreRewriteUrlsInformation()['path'] . '?number=' . $detailsModel->getNumber()
                            ),
                            'key'                  => array('@cdata' => 'number'),
                            'value'                => array('@cdata' => $detailsModel->getNumber())
                        )
                    );

                    $this->writeApiExportSeoUrls($shopsId,true, $bfMappingArticlesDetailsMappingModel, $detailsModel->getNumber());
                    $key++;
                }
            }
        }
    }

    /**
     * @param $shopsId
     * @param bool $isVariation
     * @param \Shopware\CustomModels\BfSaleschannel\MappingDetails $bfMappingArticlesDetailsMappingModel
     * @param null $itemNumber
     */
    public function writeApiExportSeoUrls(
        $shopsId,
        $isVariation = false,
        \Shopware\CustomModels\BfSaleschannel\MappingDetails $bfMappingArticlesDetailsMappingModel = null,
        $itemNumber = null
    ) {
        $apiExportSeoUrlsRepository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\ApiExportSeoUrls');

        if ($isVariation === false) {
            $apiExportSeoUrlsModel = $apiExportSeoUrlsRepository->findOneBy(array(
                    'brickfoxId' => $this->getBfMappingArticlesModel()->getBrickfoxId(),
                    'shopwareId' => $this->getBfMappingArticlesModel()->getShopwareId(),
                    'subShopId'  => $shopsId
                ));
        } else {
            $apiExportSeoUrlsModel = $apiExportSeoUrlsRepository->findOneBy(array(
                    'brickfoxId'        => $bfMappingArticlesDetailsMappingModel->getBrickfoxId(),
                    'shopwareDetailsId' => $bfMappingArticlesDetailsMappingModel->getShopwareId(),
                    'subShopId'         => $shopsId
                ));
        }

        if ($apiExportSeoUrlsModel === null) {
            $apiExportSeoUrlsModel = new \Shopware\CustomModels\BfSaleschannel\ApiExportSeoUrls();

            if ($isVariation === false) {
                $apiExportSeoUrlsModel->setBrickfoxId($this->getBfMappingArticlesModel()->getBrickfoxId());
                $apiExportSeoUrlsModel->setShopwareId($this->getBfMappingArticlesModel()->getShopwareId());
                $apiExportSeoUrlsModel->setSubShopId($shopsId);
            } else {
                $apiExportSeoUrlsModel->setBrickfoxId($bfMappingArticlesDetailsMappingModel->getBrickfoxId());
                $apiExportSeoUrlsModel->setShopwareDetailsId($bfMappingArticlesDetailsMappingModel->getShopwareId());
                $apiExportSeoUrlsModel->setSubShopId($shopsId);
            }

            $apiExportSeoUrlsModel->setDateInsert(date('Y-m-d H:i:s', time()));
        }

        $seoPath      = $this->getSeoPath($itemNumber, $isVariation);
        $originalPath = $this->getOriginalPath();

        $apiExportSeoUrlsModel->setOriginalPath($originalPath);
        $apiExportSeoUrlsModel->setSeoPath($seoPath);
        $apiExportSeoUrlsModel->setLastUpdate(date('Y-m-d H:i:s', time()));

        Shopware()->Models()->persist($apiExportSeoUrlsModel);
    }

    /**
     * @param $itemNumber
     * @param bool $isVariation
     *
     * @return string
     */
    private function getSeoPath($itemNumber, $isVariation = false)
    {
        if ($isVariation === false) {
            $seoPath = (isset($this->getSCoreRewriteUrlsInformation()['path']) === true) ? $this->getSCoreRewriteUrlsInformation()['path'] : '';
        } else {
            $seoPath = (isset($this->getSCoreRewriteUrlsInformation()['path']) === true) ? $this->getSCoreRewriteUrlsInformation()['path'] . '?number=' . $itemNumber : '';
        }

        return $seoPath;
    }

    /**
     * @return string
     */
    private function getOriginalPath()
    {
        return (isset($this->getSCoreRewriteUrlsInformation()['org_path']) === true &&
                strlen($this->getSCoreRewriteUrlsInformation()['org_path']) > 0) ? $this->getSCoreRewriteUrlsInformation()['org_path'] : '';
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}