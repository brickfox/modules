<?php
namespace Bf\Saleschannel\Components\Resources\Report;

use Bf\Saleschannel\Components\Util\ConfigManager;

/**
 * Class ProductsReportsAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Report
 */
abstract class ProductsReportsAbstract
{
    const HTTP_PROTOCOL  = 'http://';
    const HTTPS_PROTOCOL = 'https://';

    const BRICKFOX_REPORTS_PRODUCTS_LINK_ACTION_NAME = 'saveShopsProductsDescriptionLink';

    /** @var array */
    protected $sCoreRewriteUrlsInformation = array();

    /** @var  integer */
    protected $articleId;

    /** @var \Shopware\CustomModels\BfSaleschannel\MappingArticles */
    protected $bfMappingArticlesModel = null;

    /**
     * ProductsReportsAbstract constructor.
     *
     * @param \Shopware\CustomModels\BfSaleschannel\MappingArticles $bfMappingArticlesModel
     * @param array $sCoreRewriteUrlsInformation
     * @param $articleId
     */
    public function __construct(\Shopware\CustomModels\BfSaleschannel\MappingArticles $bfMappingArticlesModel, array $sCoreRewriteUrlsInformation, $articleId)
    {
        $this->sCoreRewriteUrlsInformation = $sCoreRewriteUrlsInformation;
        $this->articleId                   = $articleId;
        $this->bfMappingArticlesModel      = $bfMappingArticlesModel;
    }

    public function __destruct()
    {
        $this->sCoreRewriteUrlsInformation = array();
        $this->articleId                   = null;
        $this->bfMappingArticlesModel      = null;
    }

    /**
     * @param $shopsId
     *
     * @return string
     */
    protected function getHostInformation($shopsId)
    {
        $secureResult = Shopware()->Db()->fetchOne('select host from s_core_shops where id = ?', array($shopsId));

        $hostInformation = ConfigManager::getInstance()->getServerProtocol() . rtrim($secureResult, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;

        return $hostInformation;
    }

    /**
     * @return array
     */
    public function getSCoreRewriteUrlsInformation()
    {
        return $this->sCoreRewriteUrlsInformation;
    }

    /**
     * @param array $sCoreRewriteUrlsInformation
     */
    public function setSCoreRewriteUrlsInformation($sCoreRewriteUrlsInformation)
    {
        $this->sCoreRewriteUrlsInformation = $sCoreRewriteUrlsInformation;
    }

    /**
     * @return int
     */
    public function getArticleId()
    {
        return $this->articleId;
    }

    /**
     * @param int $articleId
     */
    public function setArticleId($articleId)
    {
        $this->articleId = $articleId;
    }

    /**
     * @return \Shopware\CustomModels\BfSaleschannel\MappingArticles
     */
    public function getBfMappingArticlesModel()
    {
        return $this->bfMappingArticlesModel;
    }

    /**
     * @param \Shopware\CustomModels\BfSaleschannel\MappingArticles $bfMappingArticlesModel
     */
    public function setBfMappingArticlesModel($bfMappingArticlesModel)
    {
        $this->bfMappingArticlesModel = $bfMappingArticlesModel;
    }
}