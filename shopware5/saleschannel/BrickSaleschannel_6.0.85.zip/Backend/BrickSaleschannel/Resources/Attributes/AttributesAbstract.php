<?php

namespace Bf\Saleschannel\Components\Resources\Attributes;

use Bf\Saleschannel\Components\Resources\ImportAbstract;
use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Resources\Property\Group as BfPropertyGroup;
use Bf\Saleschannel\Components\Resources\Property\Option as BfPropertyOption;
use Bf\Saleschannel\Components\Resources\Property\Value as BfPropertyValue;
use Bf\Saleschannel\Components\Resources\Property\Relation as BfPropertyRelation;
use Bf\Saleschannel\Components\Util\LogManager;
use Exception;
use Shopware\CustomModels\BfSaleschannel\Log;
use Shopware\Models\Attribute\Article as SwAttribute;
use Shopware\Models\Property\Value as SwPropertyValue;
use SimpleXMLElement;

/**
 * AttributesAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Attributes
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class AttributesAbstract extends ImportAbstract
{
    const SHOPWARE_ATTRIBUTE_MODEL_NAMESPACE = 'Shopware\Models\Attribute\Article';
    const UNIQUE_KEY_ARTICLE_ID              = 'articleId';
    const UNIQUE_KEY_MAIN_DETAIL_ID          = 'articleDetailId';
    const ARRAY_KEY_PRODUCT_ID               = '$productId';
    const ARRAY_KEY_ITEM_NUMBER              = '$itemNumber';

    /** @var null */
    private $attributeModel = null;

    /** @var null */
    private $propertyGroupClass = null;

    /** @var null */
    private $propertyOptionClass = null;

    /** @var null */
    private $propertyValueClass = null;

    /** @var null */
    private $propertyRelationClass = null;

    /** @var SwPropertyValue */
    private $propertiesCollection = [];

    /** @var string */
    private $mappingFieldKey = '';

    /** @var array */
    private $attributeToDeleteList = [];

    /** @var null */
    private $mappingFiltersRelationsModel = null;

    /**
     * @return void
     */
    protected function createPropertyGroupClass()
    {
        $this->setPropertyGroupClass(new BfPropertyGroup());
    }

    /**
     * @return void
     */
    protected function createPropertyOptionClass()
    {
        $this->setPropertyOptionClass(new BfPropertyOption());
    }

    /**
     * @return void
     */
    protected function createPropertyValueClass()
    {
        $this->setPropertyValueClass(new BfPropertyValue());
    }

    /**
     * @return void
     */
    protected function createPropertyRelationClass()
    {
        $this->setPropertyRelationClass(new BfPropertyRelation());
    }

    /**
     * @param string $uniqueKey
     * @param array $log
     *
     * @return void
     * @throws Exception
     */
    protected function loadAttributesModelById($uniqueKey, array $log = [])
    {
        $repository = Helper::getRepository('Shopware\Models\Attribute\Article');

        if ($uniqueKey === self::UNIQUE_KEY_ARTICLE_ID) {
            $attributesModel = null;

            if ($this->getArticle()->getMainDetail()->getId() !== null) {
                $attributesModel = $repository->findOneBy([self::UNIQUE_KEY_MAIN_DETAIL_ID => $this->getArticle()->getMainDetail()->getId()]);
            }

            if ($attributesModel === null) {
                $attributesModel = $this->getArticle()->getMainDetail()->getAttribute();

                if ($attributesModel === null) {
                    $attributesModel = $this->getNewSwAttributeModel();
                }
            }

            $attributesModel->setArticleDetail($this->getArticle()->getMainDetail());
            $this->setAttributeModel($attributesModel);
        } elseif ($uniqueKey === self::UNIQUE_KEY_MAIN_DETAIL_ID && $this->getDetail() !== null) {
            $attributesModel = null;

            if ($this->getDetail()->getId() !== null) {
                $attributesModel = $repository->findOneBy([self::UNIQUE_KEY_MAIN_DETAIL_ID => $this->getDetail()->getId()]);
            }

            if ($attributesModel === null) {
                $attributesModel = $this->getDetail()->getAttribute();

                if ($attributesModel === null) {
                    $attributesModel = $this->getNewSwAttributeModel();
                }
            }

            $attributesModel->setArticleDetail($this->getDetail());
            $this->setAttributeModel($attributesModel);
        } else {
            LogManager::getInstance()
                ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(['{' . self::ARRAY_KEY_PRODUCT_ID . '}', '{' . self::ARRAY_KEY_ITEM_NUMBER . '}'],
                    [$log[self::ARRAY_KEY_PRODUCT_ID], $log[self::ARRAY_KEY_ITEM_NUMBER]], ErrorCodes::PRODUCTS_ATTRIBUTES_CAN_NOT_FIND_ATTRIBUTE_NO_UNIQUE_KEY_WAS_GIVEN),
                    Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, $log[self::ARRAY_KEY_PRODUCT_ID],
                    ErrorCodes::PRODUCTS_ATTRIBUTES_CAN_NOT_FIND_ATTRIBUTE_NO_UNIQUE_KEY_WAS_GIVEN_ERROR_CODE, true);
        }
    }

    /**
     * @param string $type
     * @param SimpleXMLElement $attribute
     *
     * @return array
     * @throws \Exception
     */
    protected function getPropertyNameByAttributesType($type = '', SimpleXMLElement $attribute)
    {
        $return = [
            'name'      => '',
            'value'     => '',
            'id'        => '',
            'sortOrder' => 0
        ];

        switch ($type) {
            case 'String':
            case 'Text':
            case 'Array':
                $return['name']      = ((bool)$attribute->Translations->Translation->Name) ? (string)$attribute->Translations->Translation->Name : '';
                $return['value']     = ((bool)$attribute->Translations->Translation->Value) ? (string)$attribute->Translations->Translation->Value : '';
                $return['id']        = (int)$attribute->Translations->Translation->Value['id'];
                $return['sortOrder'] = (int)$attribute->Translations->Translation->Value['sortOrder'];
                break;

            case 'Integer':
            case 'Float':
            case 'Boolean':
            case 'DateTime':
                $return['name']  = ((bool)$attribute->Translations->Translation->Name) ? (string)$attribute->Translations->Translation->Name : '';
                $return['value'] = ((bool)$attribute->Value) ? (string)$attribute->Value : '';
                $return['id']    = (string)$attribute['code'] . '-' . (string)$attribute['id'];
                break;
        }

        return $return;
    }

    /**
     * @return null|SwAttribute
     */
    public function getAttributeModel()
    {
        return $this->attributeModel;
    }

    /**
     * @param null $attributeModel
     *
     * @return AttributesAbstract
     */
    public function setAttributeModel($attributeModel)
    {
        $this->attributeModel = $attributeModel;

        return $this;
    }

    /**
     * @return null|BfPropertyGroup
     */
    public function getPropertyGroupClass()
    {
        return $this->propertyGroupClass;
    }

    /**
     * @param null $propertyGroupClass
     *
     * @return AttributesAbstract
     */
    public function setPropertyGroupClass($propertyGroupClass)
    {
        $this->propertyGroupClass = $propertyGroupClass;

        return $this;
    }

    /**
     * @return null|BfPropertyOption
     */
    public function getPropertyOptionClass()
    {
        return $this->propertyOptionClass;
    }

    /**
     * @param null $propertyOptionClass
     *
     * @return AttributesAbstract
     */
    public function setPropertyOptionClass($propertyOptionClass)
    {
        $this->propertyOptionClass = $propertyOptionClass;

        return $this;
    }

    /**
     * @return null|BfPropertyValue
     */
    public function getPropertyValueClass()
    {
        return $this->propertyValueClass;
    }

    /**
     * @param null $propertyValueClass
     *
     * @return AttributesAbstract
     */
    public function setPropertyValueClass($propertyValueClass)
    {
        $this->propertyValueClass = $propertyValueClass;

        return $this;
    }

    /**
     * @return null|BfPropertyRelation
     */
    public function getPropertyRelationClass()
    {
        return $this->propertyRelationClass;
    }

    /**
     * @param null $propertyRelationClass
     *
     * @return AttributesAbstract
     */
    public function setPropertyRelationClass($propertyRelationClass)
    {
        $this->propertyRelationClass = $propertyRelationClass;

        return $this;
    }

    /**
     * @return array
     */
    public function getPropertiesCollection()
    {
        return $this->propertiesCollection;
    }

    /**
     * @param SwPropertyValue $propertiesCollection
     *
     * @return Attributes
     */
    public function setPropertiesCollection($propertiesCollection)
    {
        $unique = true;
        //        foreach($this->propertiesCollection as $currentPropertyValue)
        //        {
        //            if($propertiesCollection == $currentPropertyValue)
        //            {
        //                $unique = false;
        //                break;
        //            }
        //        }

        if ($unique === true) {
            $this->propertiesCollection[] = $propertiesCollection;
        }

        return $this;
    }

    /**
     * @return string
     */
    public function getMappingFieldKey()
    {
        return $this->mappingFieldKey;
    }

    /**
     * @param string $mappingFieldKey
     *
     * @return Attributes
     */
    public function setMappingFieldKey($mappingFieldKey)
    {
        $this->mappingFieldKey = $mappingFieldKey;

        return $this;
    }

    /**
     * @return array
     */
    public function getAttributeToDeleteList()
    {
        return $this->attributeToDeleteList;
    }

    /**
     * @param null $array
     *
     * @return Attributes
     */
    public function setAttributeToDeleteList($array = null)
    {
        if ($array === null) {
            $attributeGetter        = $this->getAttributeGetter();
            $keepOnImportAttributes = $this->getKeepOnImportAttributes();
            if (count($attributeGetter) > 0) {
                foreach ($attributeGetter as $attributeColumnHeader) {

                    if (in_array($attributeColumnHeader, $keepOnImportAttributes) === true) {
                        continue;
                    }

                    $attributeColumnsHeaderParts = explode('_', $attributeColumnHeader);
                    $setter                      = '';

                    $closure = function ($columnPart) use (&$setter) {
                        // digit OR umlaut second part is starting with umlaut
                        if (
                            ctype_digit($columnPart) === true ||
                            in_array(mb_substr($columnPart, 0, 1), ['ä', 'ö', 'ü']) === true
                        ) {
                            $setter .= '_' . $columnPart;
                        } else {
                            $setter .= ucfirst($columnPart);
                        }
                    };

                    array_walk($attributeColumnsHeaderParts, $closure);

                    $setter = 'set' . $setter;

                    if ($this->getArticle()->getMainDetail() !== null && method_exists($this->getArticle()->getMainDetail()->getAttribute(), $setter) === true) {
                        $this->attributeToDeleteList[$setter] = null;
                    }
                }
            }
        } else {
            $this->attributeToDeleteList = $array;
        }

        return $this;
    }

    /**
     * @return array
     */
    private function getKeepOnImportAttributes()
    {
        $result = [];

        $keepAttributesOnImportConfigValue = ConfigManager::getInstance()->getKeepOnImportAttributes();

        if (strlen($keepAttributesOnImportConfigValue) > 0) {
            $result = explode(',', $keepAttributesOnImportConfigValue);
        }

        return $result;
    }

    /**
     * @return array
     */
    private function getAttributeGetter()
    {
        $attributeGetter = [];

        $queryResult = Shopware()->Db()->fetchAll("show columns from s_articles_attributes");

        if (count($queryResult) > 0) {
            foreach ($queryResult as $columns) {
                if ($columns['Field'] !== 'id' && $columns['Field'] !== 'articleID' && $columns['Field'] !== 'articledetailsID') {
                    $attributeGetter[] = $columns['Field'];
                }
            }
        }

        return $attributeGetter;
    }

    /**
     * @return SwAttribute
     */
    private function getNewSwAttributeModel()
    {
        return new SwAttribute();
    }

    /**
     * @return null
     */
    public function getMappingFiltersRelationsModel()
    {
        return $this->mappingFiltersRelationsModel;
    }

    /**
     * @param null $mappingFiltersRelationsModel
     *
     * @return AttributesAbstract
     */
    public function setMappingFiltersRelationsModel($mappingFiltersRelationsModel)
    {
        $this->mappingFiltersRelationsModel = $mappingFiltersRelationsModel;

        return $this;
    }
}
