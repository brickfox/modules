<?php

namespace Bf\Saleschannel\Components\Resources\Attributes;

use Bf\Saleschannel\Components\Resources\Property\Group;
use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Doctrine\Common\Collections\ArrayCollection;
use Shopware\CustomModels\BfSaleschannel\MappingFiltersRelations;
use SimpleXMLElement;
use Shopware\Models\Article\Article as SwArticle;
use Bf\Saleschannel\Components\Resources\Property\Group as BfPropertyGroup;
use Shopware\CustomModels\BfSaleschannel\Log;

/**
 * Attributes
 *
 * @package Bf\Saleschannel\Components\Resources\Attributes
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Attributes extends AttributesAbstract
{
    const MODE_ARTICLE   = 'article';
    const MODE_VARIATION = 'variation';

    private $mappingFiltersId;

    /**
     * @param SwArticle $article
     * @param null $detail
     */
    public function __construct(SwArticle $article, $detail = null)
    {
        $this->setArticle($article);
        $this->setDetail($detail);
        $this->setAttributeToDeleteList();
        $this->createPropertyGroupClass();
    }

    /**
     * @param SimpleXMLElement $simpleXMLElement
     *
     * @return void
     */
    public function prepareArticleAttributesAndProperties(SimpleXMLElement $simpleXMLElement)
    {
        $logArray = [self::ARRAY_KEY_PRODUCT_ID => (string)$simpleXMLElement->ProductId, self::ARRAY_KEY_ITEM_NUMBER => (string)$simpleXMLElement->ItemNumber];

        $this->getPropertyGroupClass()->loadPropertyGroup();

        if ($this->getPropertyGroupClass()->getPropertyGroup() !== null) {
            $this->getArticle()->setPropertyGroup($this->getPropertyGroupClass()->getPropertyGroup());
        } else {
            LogManager::getInstance()->writeLogForGui(
                Log::LOG_STATUS_ERROR,
                __METHOD__,
                str_replace(
                    ['{$propertyGroupName}', '{$itemNumber}', '{$brickfoxId}'],
                    [Group::PROPERTY_GROUP_NAME, $logArray[self::ARRAY_KEY_ITEM_NUMBER], $logArray[self::ARRAY_KEY_PRODUCT_ID]],
                    ErrorCodes::PRODUCTS_PROPERTY_GROUP_NOT_FOUND
                ),
                Helper::getUserName(),
                Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                (string)$simpleXMLElement->ProductId,
                ErrorCodes::PRODUCTS_PROPERTY_GROUP_NOT_FOUND_ERROR_CODE,
                false
            );
        }

        if ((bool)$simpleXMLElement->Attributes === true) {
            foreach ($simpleXMLElement->Attributes as $attributes) {
                foreach ($attributes as $type => $attribute) {
                    if (in_array((string)$attribute->Translations->Translation['lang'], Helper::getMainLanguagesCode()) === true) {
                        $propertyOptionNameAndValue = $this->getPropertyNameByAttributesType($type, $attribute);

                        if ($this->attributeIsMatched((string)$attribute['code']) === false && $propertyOptionNameAndValue['name'] != '') {
                            if ($this->propertyIsMatched((string)$attribute['code']) === true) {
                                $this->prepareProperties($propertyOptionNameAndValue, $this->getPropertyGroupClass(), (int)$attribute['sort']);
                            }
                        }
                    }
                }
            }

            $this->getArticle()->setPropertyValues($this->getPropertiesCollection());
        }
    }

    /**
     * This method will be used to set the variations attribute into the article detail.
     * For Variations in Shopware there are no properties available so we have no need to set
     * the properties if the attribute of the variations are not matched.
     *
     * @param SimpleXMLElement $simpleXMLElement
     *
     * @return void
     */
    public function prepareArticleDetailAttributesWithoutProperties(SimpleXMLElement $simpleXMLElement, SimpleXMLElement $variationXmlElement)
    {
        $this->loadAttributesModelById(AttributesAbstract::UNIQUE_KEY_MAIN_DETAIL_ID);

        $merge = $this->createMergeArrays($simpleXMLElement, $variationXmlElement);

        if (count($merge) > 0) {
            foreach ($merge as $attributeCode => $attributeValue) {
                if ($this->attributeIsMatched($attributeCode) === true) {
                    $this->settingAttributesByMappingFieldKey($attributeValue);
                }
            }
        }

        $this->deleteNotMatchedAttributes();
        $this->persistAttributesModel();
    }

    /**
     * @param array $propertyOptionNameAndValue
     * @param BfPropertyGroup $group
     * @param $sortOrder
     *
     * @return void
     */
    private function prepareProperties(array $propertyOptionNameAndValue = [], BfPropertyGroup $group = null, $sortOrder)
    {
        $bfMappingFilterRelationsRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingFiltersRelations');
        /** @var \Shopware\CustomModels\BfSaleschannel\MappingFiltersRelations $bfMappingFilterRelations */
        $bfMappingFilterRelations = $bfMappingFilterRelationsRepository->findOneBy(['brickfoxId' => (int)$propertyOptionNameAndValue['id']]);

        if ($bfMappingFilterRelations !== null) {
            if (ConfigManager::getInstance()->getSortOrderAttributes() === true) {
                $sFilterRelationRepository = Shopware()->Models()->getRepository('Shopware\Models\Property\Relation');
                /** @var \Shopware\Models\Property\Relation $sFilterRelationModel */
                $sFilterRelationModel = $sFilterRelationRepository->findOneBy(['optionId' => $bfMappingFilterRelations->getOptionId()]);

                if ($sFilterRelationModel !== null) {
                    $sFilterRelationModel->setPosition($sortOrder);
                    Shopware()->Models()->persist($sFilterRelationModel);
                }
            }

            $sFilterValuesRepository = Shopware()->Models()->getRepository('Shopware\Models\Property\Value');
            /** @var \Shopware\Models\Property\Value $sFilterValuesModel */
            $sFilterValuesModel = $sFilterValuesRepository->findOneBy(['id' => $bfMappingFilterRelations->getValueId()]);

            if ($sFilterValuesModel !== null) {
                $sFilterValuesModelChanged = false;

                if (trim($propertyOptionNameAndValue['value']) !== $sFilterValuesModel->getValue()) {
                    //check if value already exists
                    $existingFilterValuesRepository = Shopware()->Models()->getRepository('Shopware\Models\Property\Value');
                    $existingFilterValuesModel      = $existingFilterValuesRepository->findOneBy([
                        'optionId' => $bfMappingFilterRelations->getOptionId(),
                        'value'    => trim($propertyOptionNameAndValue['value'])
                    ]);

                    if ($existingFilterValuesModel !== null && $existingFilterValuesModel->getId() !== $sFilterValuesModel->getId()) {
                        $sFilterValuesModel = $existingFilterValuesModel;
                    } else {
                        $sFilterValuesModel->setValue(trim($propertyOptionNameAndValue['value']));

                        $sFilterValuesModelChanged = true;
                    }
                }

                if ($sFilterValuesModel->getPosition() !== (int)$propertyOptionNameAndValue['sortOrder']) {
                    if (ConfigManager::getInstance()->getSortOrderAttributes() === true) {
                        $sFilterValuesModel->setPosition($propertyOptionNameAndValue['sortOrder']);

                        $sFilterValuesModelChanged = true;
                    }
                }

                if ($sFilterValuesModelChanged === true) {
                    Shopware()->Models()->persist($sFilterValuesModel);
                }

                $this->setPropertiesCollection($sFilterValuesModel);
            }

            $sFilterOptionRepository = Shopware()->Models()->getRepository('Shopware\Models\Property\Option');
            /** @var \Shopware\Models\Property\Option $sFilterOptionModel */
            $sFilterOptionModel = $sFilterOptionRepository->findOneBy(['id' => $bfMappingFilterRelations->getOptionId()]);

            if ($sFilterOptionModel !== null) {
                if (trim($propertyOptionNameAndValue['name']) !== $sFilterOptionModel->getName()) {
                    $sFilterOptionModel->setName(trim($propertyOptionNameAndValue['name']));
                    Shopware()->Models()->persist($sFilterOptionModel);
                }
            }
        } else {
            if ($propertyOptionNameAndValue['name'] !== '') {
                $this->createPropertyOptionClass();
                $this->getPropertyOptionClass()->loadPropertyOption($propertyOptionNameAndValue['name']);

                if ($this->getPropertyOptionClass()->getPropertyOption() !== null) {
                    $this->createPropertyValueClass();
                    $this->getPropertyValueClass()->loadPropertyValue($propertyOptionNameAndValue['value'], $this->getPropertyOptionClass()->getPropertyOption());

                    if ($this->getPropertyValueClass()->getPropertyValue() !== null) {
                        $this->createPropertyRelationClass();
                        $this->getPropertyRelationClass()->loadPropertyRelation($this->getPropertyOptionClass()->getPropertyOption(), $group->getPropertyGroup(), $sortOrder);

                        if ($this->getPropertyRelationClass()->getPropertyRelation() !== null) {
                            $this->setPropertiesCollection($this->getPropertyValueClass()->getPropertyValue());
                            $this->loadMappingFiltersRelations(
                                $this->getPropertyOptionClass()->getPropertyOption()->getId(),
                                $this->getPropertyValueClass()->getPropertyValue()->getId(),
                                $propertyOptionNameAndValue['id']
                            );
                        }
                    }
                }
            }
        }
    }

    /**
     * @param string $value
     * @param string $mode
     *
     * @throws \Exception
     */
    private function prepareReleaseDate($value, $mode = 'variation')
    {
        $releaseDate = trim($value);

        try {
            if (strlen($releaseDate) > 0) {
                $releaseDateTimeStamp = strtotime($releaseDate);
                $release              = date('Y-m-d', $releaseDateTimeStamp);

                if ($release !== false) {

                    if ($mode === self::MODE_ARTICLE) {
                        /** @var \Shopware\Models\Article\Detail $detailsModel */
                        foreach ($this->getArticle()->getDetails() as $detailsModel) {
                            $detailsModel->setReleaseDate($release);
                            Shopware()->Models()->persist($detailsModel);
                        }
                    } elseif ($mode === self::MODE_VARIATION) {
                        $this->getDetail()->setReleaseDate($release);
                        Shopware()->Models()->persist($this->getDetail());
                    }
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage();
            throw new \Exception($e);
        }
    }

    /**
     * @param $optionId
     * @param $valueId
     * @param $id
     *
     * @return void
     */
    private function loadMappingFiltersRelations($optionId, $valueId, $id)
    {
        $repository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingFiltersRelations');
        /** @var \Shopware\CustomModels\BfSaleschannel\MappingFiltersRelations $mappingFiltersRelationsModel */
        $mappingFiltersRelationsModel = $repository->findOneBy(
            ['mappingFiltersId' => $this->getMappingFiltersId(), 'optionId' => $optionId, 'valueId' => $valueId, 'brickfoxId' => $id]
        );

        if ($mappingFiltersRelationsModel === null) {
            if ($optionId !== null && $valueId !== null && $id !== null) {
                $mappingFiltersRelationsModel = new MappingFiltersRelations();
                $mappingFiltersRelationsModel->setMappingFiltersId($this->getMappingFiltersId());
                $mappingFiltersRelationsModel->setOptionId($optionId);
                $mappingFiltersRelationsModel->setValueId($valueId);
                $mappingFiltersRelationsModel->setBrickfoxId($id);

                Shopware()->Models()->persist($mappingFiltersRelationsModel);
            }
        } else {
            $mappingFiltersRelationsModel->setBrickfoxId($id);

            if ((int)$id !== (int)$mappingFiltersRelationsModel->getBrickfoxId()) {
                Shopware()->Models()->persist($mappingFiltersRelationsModel);
            }
        }
    }

    /**
     * @param $attributesCode
     *
     * @return bool
     */
    private function attributeIsMatched($attributesCode)
    {
        $isMatched = false;

        if (strlen($attributesCode) > 0) {
            $attributesMappingResult = Shopware()->Db()->fetchOne(
                "
                    select mapping_field_key from bf_mapping_attr
                    where attributes_code = ?
                ",
                [$attributesCode]
            );

            if (strlen($attributesMappingResult) > 0) {
                $this->setMappingFieldKey($attributesMappingResult);
                $isMatched = true;
            }
        }

        return $isMatched;
    }

    private function getMappedAttributesMappingFieldKey($attributesCode)
    {
        $mappingFieldKey = null;

        if (strlen($attributesCode) > 0) {
            $attributesMappingResult = Shopware()->Db()->fetchOne(
                "
                    select mapping_field_key from bf_mapping_attr
                    where attributes_code = ?
                ",
                [$attributesCode]
            );

            if (strlen($attributesMappingResult) > 0) {
                $mappingFieldKey = $attributesMappingResult;
            }
        }

        return $mappingFieldKey;
    }

    /**
     * @param $attributesCode
     *
     * @return bool
     */
    private function propertyIsMatched($attributesCode)
    {
        $isMatched = false;

        if (strlen($attributesCode) > 0) {
            $filterMappingResult = Shopware()->Db()->fetchOne(
                "
                    select id from bf_mapping_filters
                    where attributes_code = ?
                ",
                [$attributesCode]
            );

            if (strlen($filterMappingResult) > 0) {
                $this->setMappingFiltersId($filterMappingResult);
                $isMatched = true;
            }
        }

        return $isMatched;
    }

    /**
     * @param $attributesValue
     * @param null $orderNumber
     * @param null $productId
     *
     * @return void
     */
    public function settingAttributesByMappingFieldKey($attributesValue, $orderNumber = null, $productId = null)
    {
        if ($this->getAttributeModel() !== null) {
            $attributeColumnsHeaderParts = explode('_', $this->getMappingFieldKey());

            $setter  = '';
            $closure = function ($columnPart) use (&$setter) {
                if (ctype_digit($columnPart) === true) {
                    $setter .= '_' . $columnPart;
                } else {
                    $setter .= ucfirst($columnPart);
                }
            };

            array_walk($attributeColumnsHeaderParts, $closure);

            $setter = 'set' . $setter;

            // standard case
            if (method_exists($this->getAttributeModel(), $setter) === true) {
                $this->callSetterForAttributesValue($setter, $attributesValue);
                return;
            }

            $setter = ucwords($this->getMappingFieldKey(), '_');
            $setter = 'set' . ucfirst($setter);

            // for parts which start with an umlaut (e.g. "pl_ärmellänge" the setter has to be "setPl_ärmellänge" in the model)
            if (method_exists($this->getAttributeModel(), $setter) === true) {
                $this->callSetterForAttributesValue($setter, $attributesValue);
                return;
            }
        } else {
            LogManager::getInstance()->writeLogForGui(
                Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                __METHOD__,
                str_replace(
                    ['{$orderNumber}', '{$brickfoxId}'],
                    [$orderNumber, $productId],
                    ErrorCodes::PRODUCTS_ATTRIBUTES_MODEL_NOT_FOUND
                ),
                Helper::getUserName(),
                Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                $productId,
                ErrorCodes::PRODUCTS_ATTRIBUTES_MODEL_NOT_FOUND_ERROR_CODE,
                false
            );
        }
    }

    /**
     * @param string $setter
     * @param string $attributesValue
     */
    private function callSetterForAttributesValue($setter, $attributesValue)
    {
        $this->getAttributeModel()->$setter($attributesValue);

        $toDeleteList = $this->getAttributeToDeleteList();

        if (array_key_exists($setter, $toDeleteList)) {
            unset($toDeleteList[$setter]);
            $this->setAttributeToDeleteList($toDeleteList);
        }
    }

    /**
     * @return void
     */
    private function deleteNotMatchedAttributes()
    {
        if ($this->getAttributeModel() !== null) {
            foreach ($this->getAttributeToDeleteList() as $setter => $value) {
                if (method_exists($this->getAttributeModel(), $setter)) {
                    $this->getAttributeModel()->$setter($value);
                }
            }
        }
    }

    /**
     * @return void
     */
    private function persistAttributesModel()
    {
        if ($this->getAttributeModel() !== null) {
            Shopware()->Models()->persist($this->getAttributeModel());
        }
    }

    /**
     * @param SimpleXMLElement $productsAttributesXmlElement
     * @param SimpleXMLElement $variationsAttributesXmlElement
     *
     * @return array
     */
    private function createMergeArrays(SimpleXMLElement $productsAttributesXmlElement, SimpleXMLElement $variationsAttributesXmlElement)
    {
        $productsMergeArray   = [];
        $variationsMergeArray = [];

        if ((bool)$productsAttributesXmlElement->Attributes === true) {
            foreach ($productsAttributesXmlElement->Attributes as $attributes) {
                foreach ($attributes as $type => $attribute) {
                    if (in_array((string)$attribute->Translations->Translation['lang'], Helper::getMainLanguagesCode()) === true) {
                        $propertyOptionNameAndValue = $this->getPropertyNameByAttributesType($type, $attribute);

                        if (isset($attribute['code']) === true) {
                            if ($this->attributeIsMatched((string)$attribute['code']) === true) {
                                if (ConfigManager::getInstance()->getSortOrderAttributes() === true) {
                                    $mappingFieldKey = $this->getMappedAttributesMappingFieldKey((string)$attribute['code']);

                                    if (strlen($mappingFieldKey) > 0) {
                                        $this->updateAttributesPosition($mappingFieldKey, (int)$attribute['sort']);
                                    }
                                }

                                if (array_key_exists((string)$attribute['code'], $productsMergeArray) === false) {
                                    $productsMergeArray[(string)$attribute['code']] = $propertyOptionNameAndValue['value'];
                                } else {
                                    $productsMergeArray[(string)$attribute['code']] = $productsMergeArray[(string)$attribute['code']] .
                                        ConfigManager::getInstance()->getMultiAttributesExplodeCharacter() .
                                        $propertyOptionNameAndValue['value'];
                                }
                            }
                        }
                    }
                }
            }
        }

        if ((bool)$variationsAttributesXmlElement->Attributes === true) {
            foreach ($variationsAttributesXmlElement->Attributes as $attributes) {
                foreach ($attributes as $type => $attribute) {
                    if (in_array((string)$attribute->Translations->Translation['lang'], Helper::getMainLanguagesCode()) === true) {
                        $propertyOptionNameAndValue = $this->getPropertyNameByAttributesType($type, $attribute);

                        if (isset($attribute['code']) === true) {
                            if ($this->attributeIsMatched((string)$attribute['code']) === true) {
                                if (ConfigManager::getInstance()->getSortOrderAttributes() === true) {
                                    $mappingFieldKey = $this->getMappedAttributesMappingFieldKey((string)$attribute['code']);

                                    if (strlen($mappingFieldKey) > 0) {
                                        $this->updateAttributesPosition($mappingFieldKey, (int)$attribute['sort']);
                                    }
                                }

                                if (array_key_exists((string)$attribute['code'], $variationsMergeArray) === false) {
                                    $variationsMergeArray[(string)$attribute['code']] = $propertyOptionNameAndValue['value'];
                                } else {
                                    $variationsMergeArray[(string)$attribute['code']] = $variationsMergeArray[(string)$attribute['code']] .
                                        ConfigManager::getInstance()->getMultiAttributesExplodeCharacter() .
                                        $propertyOptionNameAndValue['value'];
                                }
                            }
                        }
                    }
                }
            }
        }

        // use array_replace instead of array_merge to retain numeric matched keys
        $mergeArray = array_replace($productsMergeArray, $variationsMergeArray);
        unset($productsMergeArray);
        unset($variationsMergeArray);

        return $mergeArray;
    }

    /**
     * @param string $attributeColumnName
     * @param int $sortOrder
     *
     * @throws \Exception
     */
    private function updateAttributesPosition($attributeColumnName, $sortOrder)
    {
        try {
            Shopware()->Db()->query('update s_attribute_configuration set position = ? where column_name = ?', [$sortOrder, $attributeColumnName]);
        } catch (\Exception $e) {
            throw new \Exception($e);
        }
    }

    /**
     * @return mixed
     */
    public function getMappingFiltersId()
    {
        return $this->mappingFiltersId;
    }

    /**
     * @param mixed $mappingFiltersId
     *
     * @return Attributes
     */
    public function setMappingFiltersId($mappingFiltersId)
    {
        $this->mappingFiltersId = $mappingFiltersId;

        return $this;
    }
}
