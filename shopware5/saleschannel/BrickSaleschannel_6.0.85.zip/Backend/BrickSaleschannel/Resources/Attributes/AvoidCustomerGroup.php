<?php

namespace Bf\Saleschannel\Components\Resources\Attributes;

use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\Helper;
use Shopware\Models\Article\Article as SwArticle;
use SimpleXMLElement;

class AvoidCustomerGroup extends AttributesAbstract
{
    /**
     * @param SwArticle $article
     * @param null $detail
     */
    public function __construct(SwArticle $article, $detail = null)
    {
        $this->setArticle($article);
        $this->setDetail($detail);
    }

    /**
     * @param SimpleXMLElement $simpleXMLElement
     *
     * @return void
     * @throws \Exception
     */
    public function prepareCustomerGroupsToAvoid(SimpleXMLElement $simpleXMLElement)
    {
        if (strlen($excludeCustomerGroupAttributeFieldCode = ConfigManager::getInstance()->getExcludeCustomerGroupAttributeFieldCode()) > 0) {
            $existingAvoidCustomerGroups = $this->loadExistingAvoidCustomerGroupsForArticle();
            $newAvoidCustomerGroups      = $this->prepareNewAvoidCustomerGroups($simpleXMLElement);

            $groupsToDelete = array_diff($existingAvoidCustomerGroups, $newAvoidCustomerGroups);
            $groupsToCreate = array_diff($newAvoidCustomerGroups, $existingAvoidCustomerGroups);

            $this->deleteFromCustomerGroupsToAvoid($groupsToDelete);
            $this->insertIntoCustomerGroupsToAvoid($groupsToCreate);
        }
    }

    /**
     * @return int[]
     */
    private function loadExistingAvoidCustomerGroupsForArticle()
    {
        $sql                 = 'SELECT customergroupID FROM s_articles_avoid_customergroups
                WHERE articleID = ?;
        ';
        $avoidCustomerGroups = Shopware()->Db()->fetchAll($sql, [$this->getArticle()->getId()]);

        $return = [];
        foreach ($avoidCustomerGroups as $row) {
            $return[] = $row['customergroupID'];
        }

        return $return;
    }

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     * @return int[]
     * @throws \Exception
     */
    private function prepareNewAvoidCustomerGroups(SimpleXMLElement $simpleXMLElement)
    {
        $newAvoidCustomerGroupIds = [];

        $customerGroupStrings = $this->getAvoidCustomerGroupsFromXml($simpleXMLElement);
        foreach ($customerGroupStrings as $customerGroupString) {
            if (($customerGroupId = $this->loadCustomerGroupForStringWithFallback($customerGroupString)) !== null) {
                $newAvoidCustomerGroupIds[] = $customerGroupId;
            }
        }

        return $newAvoidCustomerGroupIds;
    }

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     * @return int[]
     * @throws \Exception
     */
    private function getAvoidCustomerGroupsFromXml(SimpleXMLElement $simpleXMLElement)
    {
        $customerGroupStrings = [];

        if ((bool)$simpleXMLElement->Attributes === true) {
            foreach ($simpleXMLElement->Attributes as $attributes) {
                foreach ($attributes as $type => $attribute) {
                    if (
                        (string)$attribute['code'] === ConfigManager::getInstance()->getExcludeCustomerGroupAttributeFieldCode() &&
                        in_array((string)$attribute->Translations->Translation['lang'], Helper::getMainLanguagesCode()) === true
                    ) {
                        $customerGroupStrings[] = $this->getPropertyNameByAttributesType($type, $attribute)['value'];
                    }
                }
            }
        }

        return $customerGroupStrings;
    }

    private function loadCustomerGroupForStringWithFallback($customerGroupString)
    {
        $repository = Helper::getRepository('Shopware\Models\Customer\Group');

        foreach (['key', 'name', 'id'] as $field) {
            // find out which one to use!
            $customerGroupModel = $repository->findOneBy([$field => $customerGroupString]);
            if ($customerGroupModel !== null) {
                return $customerGroupModel->getId();
            }
        }

        return null;
    }

    /**
     * @param int[] $groupsToDelete
     */
    private function deleteFromCustomerGroupsToAvoid(array $groupsToDelete)
    {
        foreach ($groupsToDelete as $customergroupID) {
            $sql = 'DELETE FROM s_articles_avoid_customergroups WHERE articleID=? AND customergroupID=?';
            Shopware()->Db()->query($sql, [$this->getArticle()->getId(), $customergroupID]);
        }
    }

    /**
     * @param int[] $groupsToCreate
     * @throws \Zend_Db_Adapter_Exception
     */
    private function insertIntoCustomerGroupsToAvoid(array $groupsToCreate)
    {
        foreach ($groupsToCreate as $customergroupID) {
            $sql = 'INSERT INTO s_articles_avoid_customergroups VALUES (?,?);';
            Shopware()->Db()->query($sql, [$this->getArticle()->getId(), $customergroupID]);
        }
    }
}