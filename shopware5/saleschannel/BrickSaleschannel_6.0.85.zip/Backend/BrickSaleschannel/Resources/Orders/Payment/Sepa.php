<?php
namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

use Bf\Saleschannel\Components\Interfaces\PaymentMethodsInterface;

/**
 * Sepa
 *
 * @package Bf\Saleschannel\Components\Resources\Orders\Payment
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Sepa implements PaymentMethodsInterface
{
    const SEPA_PAYMENT_NAME = 'sepa';

    private $ordersId = null;

    /** @var bool */
    private $isSepa = false;

    private $sCorePaymentData = null;

    /**
     * Sepa constructor.
     *
     * @param null $orderId
     */
    public function __construct($orderId = null)
    {
        $this->ordersId = $orderId;
    }

    /**
     * @return string
     */
    public function getIban()
    {
        return $this->getSCorePaymentData()->getIban();
    }

    /**
     * @return string
     */
    public function getBic()
    {
        return $this->getSCorePaymentData()->getBic();
    }

    /**
     * @return string
     */
    public function getBankName()
    {
        return $this->getSCorePaymentData()->getBankName();
    }

    /**
     * @return string
     */
    public function getAccountHolder()
    {
        return $this->getSCorePaymentData()->getAccountHolder();
    }

    /**
     * @return integer
     */
    public function getOrdersId()
    {
        return $this->ordersId;
    }

    /**
     * @param integer $ordersId
     *
     * @return Sepa
     */
    public function setOrdersId($ordersId)
    {
        $this->ordersId = $ordersId;

        return $this;
    }

    /**
     * @return boolean
     */
    public function getIsSepa()
    {
        return $this->isSepa;
    }

    /**
     * @param boolean $isSepa
     *
     * @return Sepa
     */
    public function setIsSepa($isSepa)
    {
        $this->isSepa = $isSepa;

        return $this;
    }

    /**
     * @return \Shopware\Models\Customer\PaymentData
     */
    public function getSCorePaymentData()
    {
        return $this->sCorePaymentData;
    }

    /**
     * @param \Shopware\Models\Customer\PaymentData $sCorePaymentData
     *
     * @return Sepa
     */
    public function setSCorePaymentData($sCorePaymentData)
    {
        $this->sCorePaymentData = $sCorePaymentData;

        return $this;
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->ordersId         = null;
        $this->isSepa           = false;
        $this->sCorePaymentData = null;
    }
}
