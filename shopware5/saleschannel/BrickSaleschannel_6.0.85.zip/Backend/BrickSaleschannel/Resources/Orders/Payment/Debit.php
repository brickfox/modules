<?php

namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

use Bf\Saleschannel\Components\Interfaces\PaymentMethodsInterface;

/**
 * Debit
 *
 * @package Bf\Saleschannel\Components\Resources\Orders\Payment
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2021 brickfox GmbH http://www.brickfox.de
 */
class Debit implements PaymentMethodsInterface
{
    const DEBIT_PAYMENT_NAME = 'debit';

    private $ordersId = null;

    private $sCorePaymentData = null;

    /**
     * Debit constructor.
     *
     * @param null $orderId
     */
    public function __construct($orderId = null)
    {
        $this->ordersId = $orderId;
    }

    /**
     * @param int $orderId
     * @return \Bf\Saleschannel\Components\Resources\Orders\Payment\Debit
     */
    public function setOrdersId($orderId)
    {
        $this->ordersId = $orderId;

        return $this;
    }

    /**
     * @return int|void|null
     */
    public function getOrdersId()
    {
        return $this->ordersId;
    }

    /**
     * @return mixed
     */
    public function getAccountNumber()
    {
        return $this->getSCorePaymentData()->getAccountNumber();
    }

    /**
     * @return mixed
     */
    public function getBankCode()
    {
        return $this->getSCorePaymentData()->getBankCode();
    }

    /**
     * @return mixed
     */
    public function getBankName()
    {
        return $this->getSCorePaymentData()->getBankName();
    }

    /**
     * @return mixed
     */
    public function getAccountHolder()
    {
        return $this->getSCorePaymentData()->getAccountHolder();
    }

    /**
     * @return null
     */
    public function getSCorePaymentData()
    {
        return $this->sCorePaymentData;
    }

    /**
     * @param $sCorePaymentData
     * @return \Bf\Saleschannel\Components\Resources\Orders\Payment\Debit
     */
    public function setSCorePaymentData($sCorePaymentData)
    {
        $this->sCorePaymentData = $sCorePaymentData;

        return $this;
    }

    /**
     *
     */
    public function __destruct()
    {
        $this->ordersId = null;
    }
}