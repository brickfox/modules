<?php
namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

/**
 * BillPayHelper
 *
 * @package Bf\Saleschannel\Components\Resources\Orders\Payment
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class BillPayHelper
{
    const BILL_PAY_NAME      = 'billpay';
    const BILL_PAY_B2B       = 'billpayb2b';
    const BILL_PAY_DEBIT     = 'billpaydebit';
    const BILL_PAY_TC        = 'billpaytc';
    const BILL_PAY_PAY_LATER = 'billpaypaylater';

    /** @var bool|false */
    private $isBillPay = false;

    /** @var null */
    private $orderId = null;

    /**
     * @param bool|false $isBillPay
     * @param null $orderId
     *
     * @return void
     */
    public function __construct($isBillPay = false, $orderId = null)
    {
        $this->isBillPay = $isBillPay;
        $this->orderId   = $orderId;
    }

    /**
     * @return string
     */
    public function getBillPayAccountHolder()
    {
        $accountHolder = '';

        if($this->isBillPay === true)
        {
            $accountHolder = Shopware()->Db()->fetchOne(
                "select billpay_account_holder from s_order where id = ?",
                array($this->getOrderId())
            );
        }

        return $accountHolder;
    }

    /**
     * @return string
     */
    public function getBillPayAccountNumber()
    {
        $accountNumber = '';

        if($this->isBillPay === true)
        {
            $accountNumber = Shopware()->Db()->fetchOne(
                "select billpay_account_number from s_order where id = ?",
                array($this->getOrderId())
            );
        }

        return $accountNumber;
    }

    /**
     * @return string
     */
    public function getBillPayBankName()
    {
        $bankName = '';

        if($this->isBillPay === true)
        {
            $bankName = Shopware()->Db()->fetchOne(
                "select billpay_bank_name from s_order where id = ?",
                array($this->getOrderId())
            );
        }

        return $bankName;
    }

    /**
     * @return string
     */
    public function getBillPayBankCode()
    {
        $bankCode = '';

        if($this->isBillPay === true)
        {
            $bankCode = Shopware()->Db()->fetchOne(
                "select billpay_bank_code from s_order where id = ?",
                array($this->getOrderId())
            );
        }

        return $bankCode;
    }

    /**
     * @return string
     */
    public function getBillPayApiReference()
    {
        $apiReference = '';

        if($this->isBillPay === true)
        {
            $apiReference = Shopware()->Db()->fetchOne(
                "select billpay_api_reference from s_order where id = ?",
                array($this->getOrderId())
            );
        }

        return $apiReference;
    }

    /**
     * @return string
     */
    public function getBillPayPortalId()
    {
        $portalId = '';

        if($this->isBillPay === true)
        {
            $portalId = Shopware()->Db()->fetchOne(
                "select billpay_portal_id from s_order where id = ?",
                array($this->getOrderId())
            );
        }

        return $portalId;
    }

    /**
     * @return string
     */
    public function getMerchantId()
    {
        $merchantId = '';

        if($this->isBillPay === true)
        {
            $merchantId = Shopware()->Db()->fetchOne(
                "select billpay_merchant_id from s_order where id = ?",
                array($this->getOrderId())
            );

            return $merchantId;
        }

        return $merchantId;
    }

    /**
     * @return string
     */
    public function getBillPayTxId()
    {
        $txId = '';

        if($this->isBillPay === true)
        {
            $txId = Shopware()->Db()->fetchOne(
                "select billpay_tx_id from s_order where id = ?",
                array($this->getOrderId())
            );
        }

        return $txId;
    }

    /**
     * @return string
     */
    public function getAuthToken()
    {
        $authToken = '';

        if($this->isBillPay === true)
        {
            $authToken = Shopware()->Db()->fetchOne(
                "select billpay_auth_token from s_order where id = ?",
                array($this->getOrderId())
            );
        }

        return $authToken;
    }

    /**
     * @return bool|false
     */
    public function getIsBillPay()
    {
        return $this->isBillPay;
    }

    /**
     * @param bool|false $isBillPay
     *
     * @return BillPayHelper
     */
    public function setIsBillPay($isBillPay)
    {
        $this->isBillPay = $isBillPay;

        return $this;
    }

    /**
     * @return null
     */
    public function getOrderId()
    {
        return $this->orderId;
    }

    /**
     * @param null $orderId
     *
     * @return BillPayHelper
     */
    public function setOrderId($orderId)
    {
        $this->orderId = $orderId;

        return $this;
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->isBillPay = false;
        $this->orderId   = null;
    }
}
