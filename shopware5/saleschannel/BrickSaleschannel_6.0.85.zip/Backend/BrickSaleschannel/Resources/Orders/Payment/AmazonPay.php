<?php
/**
 * @package Bf\Saleschannel\Components\Resources\Orders\Payment
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2021 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

use Bf\Saleschannel\Components\Interfaces\PaymentMethodsInterface;

class AmazonPay implements PaymentMethodsInterface
{
    // plugin names
    const AMAZON_PAY = 'amazon_pay';
    const AMAZON_PAY_CHECKOUT = 'amazon_pay_checkout';

    // transaction types
    const AMAZON_PAY_CHECKOUT_TRANSACTION_CHARGE_TYPE = 'Charge';

    private $ordersId = null;

    /**
     * @param null $ordersId
     */
    public function __construct($ordersId = null)
    {
        $this->ordersId = $ordersId;
    }

    /**
     * @return null|integer
     */
    public function getOrdersId()
    {
        return $this->ordersId;
    }

    /**
     * @param int $ordersId
     * @return $this|mixed
     */
    public function setOrdersId($ordersId)
    {
        $this->ordersId = $ordersId;

        return $this;
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->ordersId = null;
    }

    /**
     * @return string
     */
    public function getBestItAuthorisationId()
    {
        $authorizationId = Shopware()->Db()->fetchOne(
            "select bestit_amazon_authorization_id from s_order_attributes where orderID = ?",
            [
                $this->getOrdersId()
            ]
        );

        if (empty($authorizationId)) {
            $authorizationId = '';
        }

        return $authorizationId;
    }

    /**
     * @return string
     */
    public function getOrderReference()
    {
        $orderReferenceId = Shopware()->Db()->fetchOne(
            "SELECT transactionID FROM s_order WHERE id = ?",
            [
                $this->getOrdersId()
            ]
        );

        if (empty($orderReferenceId)) {
            $orderReferenceId = '';
        }

        return $orderReferenceId;
    }

    /**
     * @param string $paymentMethod
     * @return string
     */
    public function getCaptureId($paymentMethod = self::AMAZON_PAY)
    {
        $captureId = '';

        switch ($paymentMethod) {
            case self::AMAZON_PAY:
                $captureId = $this->getBestItCaptureId();
                break;
            case self::AMAZON_PAY_CHECKOUT:
                $captureId = $this->getAmazonPayCheckoutCaptureId();
                break;

            // Here cen be added more payment plugin names and reaction on them
        }

        if ($captureId === null) {
            $captureId = '';
        }

        return $captureId;
    }

    /**
     * @return false|string|null
     */
    private function getBestItCaptureId()
    {
        return Shopware()->Db()->fetchOne(
            "SELECT bestit_amazon_capture_id FROM s_order_attributes WHERE orderID = ?",
            [
                $this->getOrdersId()
            ]
        );
    }

    /**
     * @return false|string|null
     */
    private function getAmazonPayCheckoutCaptureId()
    {
        return Shopware()->Db()->fetchOne(
            "SELECT reference FROM s_plugin_amazon_pay_checkout_transaction WHERE order_id = ? AND type = ?",
            [
                $this->getOrdersId(),
                self::AMAZON_PAY_CHECKOUT_TRANSACTION_CHARGE_TYPE
            ]
        );
    }
}
