<?php
/**
 * TeleCash.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

class TeleCash
{
    const TELE_CASH_GENERIC             = 'telecashcw_generic';
    const TELE_CASH_CREDIT_CARD         = 'telecashcw_creditcard';
    const TELE_CASH_MASTER_CARD         = 'telecashcw_mastercard';
    const TELE_CASH_VISA                = 'telecashcw_visa';
    const TELE_CASH_AMERICAN_EXPRESS    = 'telecashcw_americanexpress';
    const TELE_CASH_DINERS              = 'telecashcw_diners';
    const TELE_CASH_JCB                 = 'telecashcw_jcb';
    const TELE_CASH_DIRECT_DEBIT_SEPA   = 'telecashcw_directdebitssepa';
    const TELE_CASH_GIRO_PAY            = 'telecashcw_giropay';
    const TELE_CASH_MAESTRO             = 'telecashcw_maestro';
    const TELE_CASH_PAY_PAL             = 'telecashcw_paypal';
    const TELE_CASH_CLICK_AND_BUY       = 'telecashcw_clickandbuy';
    const TELE_CASH_DIREKT_UEBERWEISUNG = 'telecashcw_direktueberweisung';
    const TELE_CASH_SOFORT_UEBERWEISUNG = 'telecashcw_sofortueberweisung';
    const TELE_CASH_IDEAL               = 'telecashcw_ideal';
    const TELE_CASH_KLARNA_OPEN_INVOICE = 'telecashcw_klarnaopeninvoice';
    const TELE_CASH_KLARNA_INSTALLMENTS = 'telecashcw_klarnainstallments';
    const TELE_CASH_MASTER_PASS         = 'telecashcw_masterpass';
    const TELE_CASH_BC_MC               = 'telecashcw_bcmc';

    /** @var int */
    private $userId;

    /** @var \Shopware\Models\Order\Order */
    private $orderItem;

    /** @var string */
    private $transactionId = '';

    /** @var string */
    private $transactionExternalId = '';

    /** @var string */
    private $aliasForDisplay = '';

    /** @var string */
    private $paymentMachineName = '';

    private $teleCashPaymentMethods = array(
        self::TELE_CASH_GENERIC,
        self::TELE_CASH_CREDIT_CARD,
        self::TELE_CASH_MASTER_CARD,
        self::TELE_CASH_VISA,
        self::TELE_CASH_AMERICAN_EXPRESS,
        self::TELE_CASH_DINERS,
        self::TELE_CASH_JCB,
        self::TELE_CASH_DIRECT_DEBIT_SEPA,
        self::TELE_CASH_GIRO_PAY,
        self::TELE_CASH_MAESTRO,
        self::TELE_CASH_PAY_PAL,
        self::TELE_CASH_CLICK_AND_BUY,
        self::TELE_CASH_DIREKT_UEBERWEISUNG,
        self::TELE_CASH_SOFORT_UEBERWEISUNG,
        self::TELE_CASH_IDEAL,
        self::TELE_CASH_KLARNA_OPEN_INVOICE,
        self::TELE_CASH_KLARNA_INSTALLMENTS,
        self::TELE_CASH_MASTER_PASS,
        self::TELE_CASH_BC_MC
    );

    public function __construct(\Shopware\Models\Order\Order $orderItem, $userId)
    {
        $this->setOrderItem($orderItem);
        $this->setUserId($userId);
    }

    public function prepareInformation()
    {
        $this->setInformation();
    }

    private function setInformation()
    {
        $result = Shopware()->Db()->fetchAll("select transactionId, transactionExternalId, aliasForDisplay, paymentMachineName
                  from telecashcw_transaction where orderId = ?", array($this->getOrderItem()->getId()));

        if (count($result) > 0) {
            foreach ($result as $teleCashInformation) {
                $this->setTransactionId($teleCashInformation['transactionId']);
                $this->setTransactionExternalId($teleCashInformation['transactionExternalId']);
                $this->setAliasForDisplay($teleCashInformation['aliasForDisplay']);
                $this->setPaymentMachineName($teleCashInformation['paymentMachineName']);
            }
        }
    }

    /**
     * @return mixed
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * @param mixed $userId
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;
    }

    /**
     * @return \Shopware\Models\Order\Order
     */
    public function getOrderItem()
    {
        return $this->orderItem;
    }

    /**
     * @param \Shopware\Models\Order\Order $orderItem
     */
    public function setOrderItem($orderItem)
    {
        $this->orderItem = $orderItem;
    }

    /**
     * @return string
     */
    public function getTransactionId()
    {
        return $this->transactionId;
    }

    /**
     * @param string $transactionId
     */
    public function setTransactionId($transactionId)
    {
        $this->transactionId = $transactionId;
    }

    /**
     * @return string
     */
    public function getTransactionExternalId()
    {
        return $this->transactionExternalId;
    }

    /**
     * @param string $transactionExternalId
     */
    public function setTransactionExternalId($transactionExternalId)
    {
        $this->transactionExternalId = $transactionExternalId;
    }

    /**
     * @return string
     */
    public function getAliasForDisplay()
    {
        return $this->aliasForDisplay;
    }

    /**
     * @param string $aliasForDisplay
     */
    public function setAliasForDisplay($aliasForDisplay)
    {
        $this->aliasForDisplay = $aliasForDisplay;
    }

    /**
     * @return string
     */
    public function getPaymentMachineName()
    {
        return $this->paymentMachineName;
    }

    /**
     * @param string $paymentMachineName
     */
    public function setPaymentMachineName($paymentMachineName)
    {
        $this->paymentMachineName = $paymentMachineName;
    }

    /**
     * @return array
     */
    public function getTeleCashPaymentMethods()
    {
        return $this->teleCashPaymentMethods;
    }

    /**
     * @param array $teleCashPaymentMethods
     */
    public function setTeleCashPaymentMethods($teleCashPaymentMethods)
    {
        $this->teleCashPaymentMethods = $teleCashPaymentMethods;
    }
}