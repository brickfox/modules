<?php
namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

use XMLWriter;
use Shopware\Models\Order\Order as SwOrder;

/**
 * PaymentMethodValues
 *
 * @package Bf\Saleschannel\Components\Resources\Orders\Payment
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class PaymentMethodValues extends PaymentMethodValuesAbstract
{
    /**
     * @param SwOrder $order
     */
    public function __construct(SwOrder $order)
    {
        $this->setOrderItem($order);
    }

    /**
     * Add custom class here like:
     * public function foo()
     * {
     *      ...
     * }
     */

    public function __destruct()
    {
    }
}
