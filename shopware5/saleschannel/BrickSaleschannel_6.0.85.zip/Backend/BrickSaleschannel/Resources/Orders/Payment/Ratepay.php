<?php
/**
 * Ratepay.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2018 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

class Ratepay
{
    /** @var \Shopware\Models\Order\Order */
    private $orderItem;

    /** @var array */
    private $ratePayPaymentMethods = array(
        'rpayratepayinvoice',
        'rpayratepayrate',
        'rpayratepaydebit',
        'rpayratepayrate0'
    );

    /**
     * @param \Shopware\Models\Order\Order $orderItem
     */
    public function __construct(\Shopware\Models\Order\Order $orderItem)
    {
        $this->setOrderItem($orderItem);
    }

    /**
     */
    public function prepareInformation()
    {
        $this->setInformation();
    }

    /**
     */
    private function setInformation()
    {

    }

    /**
     * @return string
     */
    public function getAccountHolder()
    {
        $response = Shopware()->Db()->fetchOne(
            "SELECT response FROM rpay_ratepay_logging WHERE transactionId = ? AND operation = 'PAYMENT_REQUEST'",
            array($this->getOrderItem()->getTransactionId())
        );

        $responseXml = simplexml_load_string($response);

        $descriptor = '';

        if($responseXml !== false) {
            if(isset($responseXml->content->payment->descriptor) === true) {
                $descriptor = (string)$responseXml->content->payment->descriptor;
            }
        }

        return $descriptor . ';' . $this->getOrderItem()->getRemoteAddress();
    }

    /**
     * @return string
     */
    public function getAccountNumber()
    {
        return $this->getOrderItem()->getCustomer()->getBirthday();
    }

    /**
     * @return \Shopware\Models\Order\Order
     */
    public function getOrderItem()
    {
        return $this->orderItem;
    }

    /**
     * @param \Shopware\Models\Order\Order $orderItem
     */
    public function setOrderItem($orderItem)
    {
        $this->orderItem = $orderItem;
    }

    /**
     * @return array
     */
    public function getRatePayPaymentMethods()
    {
        return $this->ratePayPaymentMethods;
    }

    /**
     * @param array $ratePayPaymentMethods
     */
    public function setRatePayPaymentMethods($ratePayPaymentMethods)
    {
        $this->ratePayPaymentMethods = $ratePayPaymentMethods;
    }
}