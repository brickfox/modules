<?php
namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

use Shopware\Models\Order\Order as SwOrder;

/**
 * IPayment
 *
 * @package Bf\Saleschannel\Components\Resources\Orders\Payment
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class IPayment
{
    const I_PAYMENT_PREG_MATCH_EXPRESSION = '/^ipaymentcw/';
    
    /** @var null|SwOrder */
    private $orderItem = null;

    /**
     * IPayment constructor.
     *
     * @param SwOrder $orderItem
     */
    public function __construct(SwOrder $orderItem)
    {
        $this->orderItem = $orderItem;
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->orderItem = null;
    }

    /**
     * @return bool
     */
    public function isIPayment()
    {
        $isIPayment = false;

        if(preg_match(self::I_PAYMENT_PREG_MATCH_EXPRESSION ,$this->getOrderItem()->getPayment()->getName())) 
        {
            $isIPayment = true;
        }

        return $isIPayment;
    }

    /**
     * @return string
     */
    public function getTransactionId()
    {
        return Shopware()->Db()->fetchOne(
            "select paymentId from ipaymentcw_transaction where orderId = ?", array($this->getOrderItem()->getId())
        );
    }

    /**
     * @return null|SwOrder
     */
    public function getOrderItem()
    {
        return $this->orderItem;
    }

    /**
     * @param null|SwOrder $orderItem
     *
     * @return IPayment
     */
    public function setOrderItem($orderItem)
    {
        $this->orderItem = $orderItem;

        return $this;
    }
}
