<?php
namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

use Bf\Saleschannel\Components\Interfaces\PaymentMethodsInterface;

/**
 * HeidelPay
 *
 * @package Bf\Saleschannel\Components\Resources\Orders\Payment
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class HeidelPay implements PaymentMethodsInterface
{
    const HEIDEL_PAY_CC_NAME  = 'hgw_cc';
    const HEILDE_PAY_DC_NAME  = 'hgw_dc';
    const HEIDEL_PAY_DD_NAME  = 'hgw_dd';
    const HEIDEL_PAY_IV_NAME  = 'hgw_iv';
    const HEIDEL_PAY_PP_NAME  = 'hgw_pp';
    const HEIDEL_PAY_SUE_NAME = 'hgw_sue';
    const HEIDEL_PAY_GIR_NAME = 'hgw_gir';
    const HEIDEL_PAY_PAY_NAME = 'hgw_pay';
    const HEIDEL_PAY_IDE_NAME = 'hgw_ide';
    const HEIDEL_PAY_BS_NAME  = 'hgw_bs';
    const HEIDEL_PAY_MK_NAME  = 'hgw_mk';
    const HEIDEL_PAY_PF_NAME  = 'hgw_pf';
    const HEIDEL_PAY_YT_NAME  = 'hgw_yt';
    const HEIDEL_PAY_MPA_NAME = 'hgw_mpa';
    const HEIDEL_PAY_PAPG_NAME = 'hgw_papg';
    const HEIDEL_PAY_IVB2B     = 'hgw_ivb2b';
    const HEIDEL_PAY_ALIPAY_NAME = 'heidelAlipay';
    const HEIDEL_PAY_CREDIT_CARD_NAME = 'heidelCreditCard';
    const HEIDEL_PAY_EPS_NAME = 'heidelEps';
    const HEIDEL_PAY_FLEXIPAY_NAME = 'heidelFlexipay';
    const HEIDEL_PAY_GIROPAY_NAME = 'heidelGiropay';
    const HEIDEL_PAY_HIRE_PURCHASE_NAME = 'heidelHirePurchase';
    const HEIDEL_PAY_IDEAL_NAME = 'heidelIdeal';
    const HEIDEL_PAY_INVOICE_NAME = 'heidelInvoice';
    const HEIDEL_PAY_INVOICE_FACTORING_NAME = 'heidelInvoiceFactoring';
    const HEIDEL_PAY_INVOICE_GUARANTEED_NAME = 'heidelInvoiceGuaranteed';
    const HEIDEL_PAY_PAYPAL_NAME = 'heidelPaypal';
    const HEIDEL_PAY_PREPAYMENT_NAME = 'heidelPrepayment';
    const HEIDEL_PAY_PRZELEWY_NAME = 'heidelPrzelewy';
    const HEIDEL_PAY_SEPA_DIRECT_DEBIT_NAME = 'heidelSepaDirectDebit';
    const HEIDEL_PAY_SEPA_DIRECT_DEBIT_GUARANTEED_NAME = 'heidelSepaDirectDebitGuaranteed';
    const HEIDEL_PAY_SOFORT_NAME = 'heidelSofort';
    const HEIDEL_PAY_WE_CHAT_NAME = 'heidelWeChat';

    private $ordersId = null;

    /** @var bool */
    private $isHeidelPay = false;

    /**
     * HeidelPayCc constructor.
     *
     * @param null $ordersId
     */
    public function __construct($ordersId = null)
    {
        $this->ordersId = $ordersId;
    }

    /**
     * @return string
     */
    public function getCardAuthorization()
    {
        $cardAuthorization = Shopware()->Db()->fetchOne(
            "select temporaryID from s_order where id = ?",
            array($this->getOrdersId())
        );

        return $cardAuthorization;
    }

    /**
     * @return string
     */
    public function getShortId()
    {
        $shortId = '';

        $comment = Shopware()->Db()->fetchOne(
            "select comment from s_order where id = ?",
            array($this->getOrdersId())
        );

        if (
            strpos($comment, 'ShortID:') !== false ||
            strpos($comment, 'ShortId:') !== false ||
            strpos($comment, 'Short-ID:') !== false ||
            strpos($comment, 'Short-Id:') !== false
        ) {
            $shortId = trim(substr(strrchr($comment, ':'), 1));
        }

        if(strlen($shortId) <= 0) {
            $comment = Shopware()->Db()->fetchOne(
                "select internalcomment from s_order where id = ?",
                array($this->getOrdersId())
            );

            if (
                strpos($comment, 'ShortID:') !== false ||
                strpos($comment, 'ShortId:') !== false ||
                strpos($comment, 'Short-ID:') !== false ||
                strpos($comment, 'Short-Id:') !== false
            ) {
                $shortId = trim(substr(strrchr($comment, ':'), 1));
            }
        }

        return $shortId;
    }

    /**
     * @return null|integer
     */
    public function getOrdersId()
    {
        return $this->ordersId;
    }

    /**
     * @param null $ordersId
     *
     * @return HeidelPay
     */
    public function setOrdersId($ordersId)
    {
        $this->ordersId = $ordersId;

        return $this;
    }

    /**
     * @return boolean
     */
    public function getIsHeidelPay()
    {
        return $this->isHeidelPay;
    }

    /**
     * @param boolean $isHeidelPay
     *
     * @return HeidelPay
     */
    public function setIsHeidelPay($isHeidelPay)
    {
        $this->isHeidelPay = $isHeidelPay;

        return $this;
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->ordersId    = null;
        $this->isHeidelPay = false;
    }
}
