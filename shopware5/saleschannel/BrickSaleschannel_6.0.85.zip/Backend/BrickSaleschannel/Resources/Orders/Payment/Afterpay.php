<?php
/**
 * Afterpay.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2018 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

class Afterpay
{
    /** @var \Shopware\Models\Order\Order */
    private $orderItem;

    private $afterPayPaymentMethods = array(
        'colo_afterpay_invoice',
        'colo_afterpay_dd',
        'colo_afterpay_installment',
        'colo_afterpay_campaigns'
    );

    /**
     * Afterpay constructor.
     *
     * @param \Shopware\Models\Order\Order $orderItem
     */
    public function __construct(\Shopware\Models\Order\Order $orderItem)
    {
        $this->setOrderItem($orderItem);
    }

    public function prepareInformation()
    {
        $this->setInformation();
    }

    private function setInformation()
    {

    }

    /**
     * @return \Shopware\Models\Order\Order
     */
    public function getOrderItem()
    {
        return $this->orderItem;
    }

    /**
     * @param \Shopware\Models\Order\Order $orderItem
     */
    public function setOrderItem($orderItem)
    {
        $this->orderItem = $orderItem;
    }

    /**
     * @return array
     */
    public function getAfterPayPaymentMethods()
    {
        return $this->afterPayPaymentMethods;
    }

    /**
     * @param array $afterPayPaymentMethods
     */
    public function setAfterPayPaymentMethods($afterPayPaymentMethods)
    {
        $this->afterPayPaymentMethods = $afterPayPaymentMethods;
    }
}