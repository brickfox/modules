<?php
/**
 * Paymorrow.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2018 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

class Paymorrow
{
    const BANK_HOLDER               = 'PAYMORROW GMBH';
    const PAYMORROW_INVOICE         = 'PaymorrowInvoice';
    const PAYMORROW_DEBIT           = 'PaymorrowDebit';
    const PAYMORROW_INVOICE_PAYMENT = 'PaymorrowInvoicePayment';

    /** @var \Shopware\Models\Order\Order */
    private $orderItem;

    /** @var array */
    private $paymorrowPaymentMethods = array(
        self::PAYMORROW_DEBIT,
        self::PAYMORROW_INVOICE,
        self::PAYMORROW_INVOICE_PAYMENT
    );

    /** @var string */
    private $transactionId = '';

    /** @var string */
    private $bic = '';

    /** @var string */
    private $iban = '';

    /** @var string */
    private $nationalBankName = '';

    /** @var string */
    private $nationalBankCode = '';

    /** @var string */
    private $nationalBankAccountNumber = '';

    /** @var string */
    private $paymentReference = '';

    /** @var string */
    private $paymentReference2 = '';

    /**
     * Paymorrow constructor.
     *
     * @param \Shopware\Models\Order\Order $orderItem
     */
    public function __construct(\Shopware\Models\Order\Order $orderItem)
    {
        $this->setOrderItem($orderItem);
    }

    public function prepareInformation()
    {
        $this->setInformation();
    }

    private function setInformation()
    {
        $result = Shopware()->Db()->fetchAll("select * from `pi_paymorrow_orders` where ordernumber = ?", array($this->getOrderItem()->getNumber()));

        if (count($result) > 0) {
            foreach ($result as $paymorrowInfo) {
                $this->setTransactionId($paymorrowInfo['transactionId']);
                $this->setBic($paymorrowInfo['bic']);
                $this->setIban($paymorrowInfo['iban']);
                $this->setNationalBankName($paymorrowInfo['nationalBankName']);
                $this->setNationalBankCode($paymorrowInfo['nationalBankCode']);
                $this->setNationalBankAccountNumber($paymorrowInfo['nationalBankAccountNumber']);
                $this->setPaymentReference($paymorrowInfo['paymentReference']);
                $this->setPaymentReference2($paymorrowInfo['paymentReference2']);
            }
        }
    }

    /**
     * @return array
     */
    public function getPaymorrowPaymentMethods()
    {
        return $this->paymorrowPaymentMethods;
    }

    /**
     * @param array $paymorrowPaymentMethods
     */
    public function setPaymorrowPaymentMethods($paymorrowPaymentMethods)
    {
        $this->paymorrowPaymentMethods = $paymorrowPaymentMethods;
    }

    /**
     * @return \Shopware\Models\Order\Order
     */
    public function getOrderItem()
    {
        return $this->orderItem;
    }

    /**
     * @param \Shopware\Models\Order\Order $orderItem
     */
    public function setOrderItem($orderItem)
    {
        $this->orderItem = $orderItem;
    }

    /**
     * @return string
     */
    public function getTransactionId()
    {
        return $this->transactionId;
    }

    /**
     * @param string $transactionId
     */
    public function setTransactionId($transactionId)
    {
        $this->transactionId = $transactionId;
    }

    /**
     * @return string
     */
    public function getBic()
    {
        return $this->bic;
    }

    /**
     * @param string $bic
     */
    public function setBic($bic)
    {
        $this->bic = $bic;
    }

    /**
     * @return string
     */
    public function getIban()
    {
        return $this->iban;
    }

    /**
     * @param string $iban
     */
    public function setIban($iban)
    {
        $this->iban = $iban;
    }

    /**
     * @return string
     */
    public function getNationalBankName()
    {
        return $this->nationalBankName;
    }

    /**
     * @param string $nationalBankName
     */
    public function setNationalBankName($nationalBankName)
    {
        $this->nationalBankName = $nationalBankName;
    }

    /**
     * @return string
     */
    public function getNationalBankCode()
    {
        return $this->nationalBankCode;
    }

    /**
     * @param string $nationalBankCode
     */
    public function setNationalBankCode($nationalBankCode)
    {
        $this->nationalBankCode = $nationalBankCode;
    }

    /**
     * @return string
     */
    public function getNationalBankAccountNumber()
    {
        return $this->nationalBankAccountNumber;
    }

    /**
     * @param string $nationalBankAccountNumber
     */
    public function setNationalBankAccountNumber($nationalBankAccountNumber)
    {
        $this->nationalBankAccountNumber = $nationalBankAccountNumber;
    }

    /**
     * @return string
     */
    public function getPaymentReference()
    {
        return $this->paymentReference;
    }

    /**
     * @param string $paymentReference
     */
    public function setPaymentReference($paymentReference)
    {
        $this->paymentReference = $paymentReference;
    }

    /**
     * @return string
     */
    public function getPaymentReference2()
    {
        return $this->paymentReference2;
    }

    /**
     * @param string $paymentReference2
     */
    public function setPaymentReference2($paymentReference2)
    {
        $this->paymentReference2 = $paymentReference2;
    }
}