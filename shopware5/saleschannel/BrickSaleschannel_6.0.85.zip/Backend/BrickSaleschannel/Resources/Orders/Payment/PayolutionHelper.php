<?php
/**
 * PayolutionHelper.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

class PayolutionHelper
{
    const PAYOLUTION_INVOICE_B2C = 'payolution_invoice_b2c';
    const PAYOLUTION_INVOICE_B2B = 'payolution_invoice_b2b';
    const PAYOLUTION_INSTALLMENT = 'payolution_installment';
    const PAYOLUTION_ELV         = 'payolution_elv';

    /** @var bool */
    private $isPayolution = false;

    /** @var int|null */
    private $orderId = null;

    /** @var int|null */
    private $userId = null;

    /**
     * PayolutionHelper constructor.
     *
     * @param bool $isPayolution
     * @param null $orderId
     * @param $userId
     */
    public function __construct($isPayolution = false, $orderId = null, $userId)
    {
        $this->isPayolution = $isPayolution;
        $this->orderId      = $orderId;
        $this->userId       = $userId;
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->isPayolution = false;
        $this->orderId      = null;
        $this->userId       = null;
    }

    /**
     * @return string
     */
    public function getPayolutionCardHolder()
    {
        $result = Shopware()->Db()->fetchOne(
            "select payolution_payment_reference_id from s_order_attributes where orderID = ?",
            array($this->getOrderId())
        );

        return $result;
    }

    /**
     * @return string
     */
    public function getPayolutionBankName()
    {
        $result = Shopware()->Db()->fetchOne(
            "select payolution_unique_id from s_order_attributes where orderID = ?",
            array($this->getOrderId())
        );

        return $result;
    }

    /**
     * @return string
     */
    public function getPayolutionBic()
    {
        $result = Shopware()->Db()->fetchOne(
            "select accountBic from bestit_payolution_elv where userId = ?",
            array($this->getUserId())
        );

        return $result;
    }

    /**
     * @return string
     */
    public function getPayolutionIban()
    {
        $result = Shopware()->Db()->fetchOne(
            "select accountIban from bestit_payolution_elv where userId = ?",
            array($this->getUserId())
        );

        return $result;
    }

    /**
     * @return string
     */
    public function getPayolutionHolder()
    {
        $result = Shopware()->Db()->fetchOne(
            "select accountHolder from bestit_payolution_elv where userId = ?",
            array($this->getUserId())
        );

        return $result;
    }

    /**
     * @return boolean
     */
    public function isIsPayolution()
    {
        return $this->isPayolution;
    }

    /**
     * @param boolean $isPayolution
     */
    public function setIsPayolution($isPayolution)
    {
        $this->isPayolution = $isPayolution;
    }

    /**
     * @return null
     */
    public function getOrderId()
    {
        return $this->orderId;
    }

    /**
     * @param null $orderId
     */
    public function setOrderId($orderId)
    {
        $this->orderId = $orderId;
    }

    /**
     * @return int|null
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * @param int|null $userId
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;
    }
}