<?php
/**
 * Klarna.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

class Klarna
{
    const KLARNA_ACCOUNT = 'klarna_account';
    const KLARNA_INVOICE = 'klarna_invoice';

    const KLARNA_BEST_IT_PAYMENT_METHODS = [
        'bestit_klarna_payments_instant_shopping',
        'bestit_klarna_payments_card',
        'bestit_klarna_payments_direct_debit',
        'bestit_klarna_payments_pay_later',
        'bestit_klarna_payments_slice_it',
        'bestit_klarna_payments_pay_now',
        'bestit_klarna_payments_direct_bank_transfer',
    ];

    /** @var  int */
    private $userId;

    private $orderItem;

    /** @var  int */
    private $orderId;

    private $klarnaPersonalNumber = '';

    private $klarnaPClass;

    private $klarnaEid;

    private $orderStatus = 1;

    /** @var string */
    private $reservationNumber = '';

    /**
     * @param \Shopware\Models\Order\Order $orderItem
     * @param $userId
     * @param $orderId
     */
    public function __construct(\Shopware\Models\Order\Order $orderItem, $userId, $orderId)
    {
        $this->setUserId($userId);
        $this->setOrderId($orderId);
        $this->setOrderItem($orderItem);
    }

    public function prepareInformation()
    {
        $this->prepareKlarnaPClass($this->getOrderItem()->getPayment()->getName());
        $this->prepareKlarnaPersonalNumber();
        $this->prepareKlarnaEid();
        $this->prepareKlarnaReservationNumber();
    }

    public function prepareInformationBestIt() {
        $this->prepareKlarnaPersonalNumber();
        $this->prepareKlarnaReservationNumber();
    }

    private function prepareKlarnaReservationNumber()
    {
        if (strlen($this->getOrderItem()->getTransactionId()) > 0) {
            $this->setReservationNumber($this->getOrderItem()->getTransactionId());
        }
    }

    /**
     * @param $paymentName
     */
    private function prepareKlarnaPClass($paymentName)
    {
        switch($paymentName){
            case self::KLARNA_ACCOUNT:
                $this->setKlarnaPClass(1);
                break;

            case self::KLARNA_INVOICE:
                $this->setKlarnaPClass(-1);
                break;

            default:
                $this->setKlarnaPClass('');
                break;
        }
    }

    private function prepareKlarnaEid()
    {
        $eId = Shopware()->Db()->fetchOne('select eid from s_klarna_pclasses limit 1');
        $this->setKlarnaEid($eId);
    }

    private function prepareKlarnaPersonalNumber()
    {
        $userRepository = Shopware()->Models()->getRepository('Shopware\Models\Customer\Customer');
        /** @var \Shopware\Models\Customer\Customer $userModel */
        $userModel = $userRepository->find($this->getUserId());

        if ($userModel !== null) {
            $birthday = '';
            if ($userModel->getBirthday() !== null) {
                $birthday   = $userModel->getBirthday()->format('dmY');
            }

            $salutation = $userModel->getSalutation();

            switch ($salutation) {
                case 'mr':
                    $salutationNumber = 1;
                    break;
                case 'mrs':
                    $salutationNumber = 0;
                    break;
                default:
                    $salutationNumber = 1;
                    break;
            }

            $this->setKlarnaPersonalNumber($birthday . $salutationNumber);
        }
    }

    /**
     * @return string
     */
    public function getKlarnaPersonalNumber()
    {
        return $this->klarnaPersonalNumber;
    }

    /**
     * @param string $klarnaPersonalNumber
     */
    public function setKlarnaPersonalNumber($klarnaPersonalNumber)
    {
        $this->klarnaPersonalNumber = $klarnaPersonalNumber;
    }

    /**
     * @return int
     */
    public function getOrderId()
    {
        return $this->orderId;
    }

    /**
     * @param int $orderId
     */
    public function setOrderId($orderId)
    {
        $this->orderId = $orderId;
    }

    /**
     * @return int
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * @param int $userId
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;
    }

    /**
     * @return mixed
     */
    public function getKlarnaPClass()
    {
        return $this->klarnaPClass;
    }

    /**
     * @param mixed $klarnaPClass
     */
    public function setKlarnaPClass($klarnaPClass)
    {
        $this->klarnaPClass = $klarnaPClass;
    }

    /**
     * @return mixed
     */
    public function getKlarnaEid()
    {
        return $this->klarnaEid;
    }

    /**
     * @param mixed $klarnaEid
     */
    public function setKlarnaEid($klarnaEid)
    {
        $this->klarnaEid = $klarnaEid;
    }

    /**
     * @return int
     */
    public function getOrderStatus()
    {
        return $this->orderStatus;
    }

    /**
     * @param int $orderStatus
     */
    public function setOrderStatus($orderStatus)
    {
        $this->orderStatus = $orderStatus;
    }

    /**
     * @return \Shopware\Models\Order\Order
     */
    public function getOrderItem()
    {
        return $this->orderItem;
    }

    /**
     * @param mixed $orderItem
     */
    public function setOrderItem($orderItem)
    {
        $this->orderItem = $orderItem;
    }

    /**
     * @return string
     */
    public function getReservationNumber()
    {
        return $this->reservationNumber;
    }

    /**
     * @param string $reservationNumber
     */
    public function setReservationNumber($reservationNumber)
    {
        $this->reservationNumber = $reservationNumber;
    }
}