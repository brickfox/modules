<?php

namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

use Bf\Saleschannel\Components\Interfaces\PaymentMethodsInterface;

class Mollie implements PaymentMethodsInterface
{
    const MOLLIE_APPLEPAY = 'mollie_applepay';
    const MOLLIE_CREDITCARD = 'mollie_creditcard';
    const MOLLIE_KLARNAPAYLATER = 'mollie_klarnapaylater';
    const MOLLIE_KLARNAPAYNOW = 'mollie_klarnapaynow';
    const MOLLIE_KLARNASLICEIT = 'mollie_klarnasliceit';
    const MOLLIE_SOFORT = 'mollie_sofort';
    const MOLLIE_EPS = 'mollie_eps';
    const MOLLIE_APPLEPAYDIRECT = 'mollie_applepaydirect';

    /** @var string|null */
    private $orderId;

    /**
     * @inheritDoc
     */
    public function __construct($orderId = null)
    {
        $this->orderId = $orderId;
    }

    /**
     * @inheritDoc
     */
    public function setOrdersId($orderId)
    {
        $this->orderId = $orderId;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getOrdersId()
    {
        return $this->orderId;
    }

    /**
     * @return string
     */
    public function getPaymentMethod() {
        return Shopware()->Db()->fetchOne(
            "select payment_method from mol_sw_transactions where order_id = ?",
            array($this->getOrdersId())
        );
    }

    /**
     * @return string
     */
    public function getBasketSignature() {
        return Shopware()->Db()->fetchOne(
            "select basket_signature from mol_sw_transactions where order_id = ?",
            array($this->getOrdersId())
        );
    }

    /**
     * @return string|null
     */
    public function getMollieId() {
        return Shopware()->Db()->fetchOne(
            "select mollie_id from mol_sw_transactions where order_id = ?",
            array($this->getOrdersId())
        );
    }

    /**
     * @return string|null
     */
    public function getMolliePaymentId() {
        return Shopware()->Db()->fetchOne(
            "select mollie_payment_id from mol_sw_transactions where order_id = ?",
            array($this->getOrdersId())
        );
    }

    /**
     * @return string|null
     */
    public function getSessionId() {
        return Shopware()->Db()->fetchOne(
            "select session_id from mol_sw_transactions where order_id = ?",
            array($this->getOrdersId())
        );
    }

    /**
     * @return string|null
     */
    public function getOrdermailVariables() {
        return Shopware()->Db()->fetchOne(
            "select ordermail_variables from mol_sw_transactions where order_id = ?",
            array($this->getOrdersId())
        );
    }

    /**
     * @inheritDoc
     */
    public function __destruct()
    {
        $this->orderId = null;
    }
}