<?php
/**
 * Created by PhpStorm.
 * User: kurz
 * Date: 09.09.16
 * Time: 14:06
 */

namespace Bf\Saleschannel\Components\Resources\Orders\Payment;

use Bf\Saleschannel\Components\Resources\Orders\OrdersAbstract;
use Bf\Saleschannel\Components\Util\FileWriter;
use Exception;

abstract class PaymentMethodValuesAbstract extends OrdersAbstract
{
    const NODE_NAME_PAYMENT_METHOD_VALUE = 'PaymentMethodValue';

    const ATTRIBUTE_KEY = 'key';

    const ATTRIBUTE_VALUE = 'value';

    /** @var array */
    private $customMethods = array();

    /** @var array */
    private $customClasses = array();

    private $internalKey = 0;

    /**
     * @return void
     */
    public function preparePaymentMethodValues()
    {
        $this->prepareTransactionId();
        $this->prepareDebitPayment();
        $this->prepareAmazonPayment();
        $this->prepareBillPayPayment();
        $this->prepareMollie();
        $this->prepareHeidelPayCc();
        $this->prepareSepaPayment();
        $this->prepareIPayment();
        $this->preparePayolutionPayment();
        $this->prepareKlarnaPayment();
        $this->prepareBestItKlarnaPayment();
        $this->prepareTeleCashPayment();
        $this->preparePaymorrowPayment();
        $this->prepareAfterPayPayment();
        $this->prepareRatePayPayment();

        if (count($this->getCustomMethods()) > 0) {
            foreach ($this->getCustomMethods() as $key) {
                foreach ($key as $method) {
                    $this->$method();
                }
            }
        }
    }

    private function prepareRatePayPayment()
    {
        $ratePayPayment = new Ratepay($this->getOrderItem());

        if (in_array($this->getOrderItem()->getPayment()->getName(), $ratePayPayment->getRatePayPaymentMethods()) === true) {
            $this->writePaymentMethodValue('accountHolder', $ratePayPayment->getAccountHolder());
            $this->writePaymentMethodValue('accountNumber', $ratePayPayment->getAccountNumber());
        }
    }

    private function prepareAfterPayPayment()
    {
        $afterPayPayment = new Afterpay($this->getOrderItem());

        if (in_array($this->getOrderItem()->getPayment()->getName(), $afterPayPayment->getAfterPayPaymentMethods()) === true) {

        }
    }

    private function preparePaymorrowPayment()
    {
        $paymorrowPayment = new Paymorrow($this->getOrderItem());
        if (in_array($this->getOrderItem()->getPayment()->getName(), $paymorrowPayment->getPaymorrowPaymentMethods()) === true) {
            $paymorrowPayment->prepareInformation();

            if (strlen($paymorrowPayment->getTransactionId()) > 0) {
                $this->writePaymentMethodValue('transactionId', $paymorrowPayment->getTransactionId());
            }
            $this->writePaymentMethodValue('bic', $paymorrowPayment->getBic());
            $this->writePaymentMethodValue('iban', $paymorrowPayment->getIban());
            $this->writePaymentMethodValue('nationalBankName', $paymorrowPayment->getNationalBankName());
            $this->writePaymentMethodValue('nationalBankCode', $paymorrowPayment->getNationalBankCode());
            $this->writePaymentMethodValue('nationalBankAccountNumber', $paymorrowPayment->getNationalBankAccountNumber());
            $this->writePaymentMethodValue('paymentReference', $paymorrowPayment->getPaymentReference());
            $this->writePaymentMethodValue('paymentReference2', $paymorrowPayment->getPaymentReference2());
            $this->writePaymentMethodValue('bankHolder', Paymorrow::BANK_HOLDER);
        }
    }

    private function prepareTeleCashPayment()
    {
        $teleCashPayment = new TeleCash($this->getOrderItem(), $this->getOrderItem()->getCustomer()->getId());
        if (in_array($this->getOrderItem()->getPayment()->getName(), $teleCashPayment->getTeleCashPaymentMethods()) === true) {
            $teleCashPayment->prepareInformation();
            $this->writePaymentMethodValue('transactionId', $teleCashPayment->getTransactionId());
            $this->writePaymentMethodValue('transactionExternalId', $teleCashPayment->getTransactionExternalId());
            $this->writePaymentMethodValue('aliasForDisplay', $teleCashPayment->getAliasForDisplay());
            $this->writePaymentMethodValue('paymentMachineName', $teleCashPayment->getPaymentMachineName());
        }
    }

    private function prepareKlarnaPayment()
    {
        if ($this->getOrderItem()->getPayment()->getName() === Klarna::KLARNA_ACCOUNT || $this->getOrderItem()->getPayment()->getName() === Klarna::KLARNA_INVOICE) {
            $klarnaPayment = new Klarna($this->getOrderItem(), $this->getOrderItem()->getCustomer()->getId(), $this->getOrderItem()->getId());
            $klarnaPayment->prepareInformation();

            $this->writePaymentMethodValue('personalNumber', $klarnaPayment->getKlarnaPersonalNumber());
            $this->writePaymentMethodValue('pClass', $klarnaPayment->getKlarnaPClass());
            $this->writePaymentMethodValue('eId', $klarnaPayment->getKlarnaEid());
            $this->writePaymentMethodValue('orderStatus', $klarnaPayment->getOrderStatus());
            $this->writePaymentMethodValue('reservationNumber', $klarnaPayment->getReservationNumber());
        }
    }

    private function prepareBestItKlarnaPayment() {
        if(in_array($this->getOrderItem()->getPayment()->getName(), Klarna::KLARNA_BEST_IT_PAYMENT_METHODS) === true) {
            $klarnaPayment = new Klarna($this->getOrderItem(), $this->getOrderItem()->getCustomer()->getId(), $this->getOrderItem()->getId());
            $klarnaPayment->prepareInformationBestIt();

            $this->writePaymentMethodValue('personalNumber', $klarnaPayment->getKlarnaPersonalNumber());
            $this->writePaymentMethodValue('orderStatus', $klarnaPayment->getOrderStatus());
            $this->writePaymentMethodValue('reservationNumber', $klarnaPayment->getReservationNumber());
        }
    }

    private function prepareIPayment()
    {
        $iPaymentClass = new IPayment($this->getOrderItem());

        if ($iPaymentClass->isIPayment() === true) {
            try {
                $iPaymentTransactionId = $iPaymentClass->getTransactionId();

                if ($iPaymentTransactionId) {
                    $this->writePaymentMethodValue('transactionId', $iPaymentTransactionId);
                }
            } catch (Exception $e) {
            }
        }
    }

    /**
     * @return void
     */
    private function prepareTransactionId()
    {
        if ($this->getOrderItem()->getPayment()->getName() !== 'cash' && $this->getOrderItem()->getPayment()->getName() !== 'prepayment') {
            if (strlen($this->getOrderItem()->getTransactionId()) > 0) {
                $this->writePaymentMethodValue('transactionId', $this->getOrderItem()->getTransactionId());
            }
        }
    }

    /**
     * @return void
     */
    private function prepareDebitPayment()
    {
        if ($this->getOrderItem()->getPayment()->getName() === Debit::DEBIT_PAYMENT_NAME) {
            $debitClass = new Debit($this->getOrderItem()->getId());

            $repository       = Shopware()->Models()->getRepository('Shopware\Models\Customer\PaymentData');
            $paymentDataModel = $repository->findOneBy(array(
                'paymentMeanId' => $this->getOrderItem()->getPayment()->getId(),
                'customer'      => $this->getOrderItem()->getCustomer()->getId()
            ));

            if ($paymentDataModel !== null) {
                $debitClass->setSCorePaymentData($paymentDataModel);
                $this->writePaymentMethodValue('debitAccountNumber', $debitClass->getAccountNumber());
                $this->writePaymentMethodValue('debitAccountHolder', $debitClass->getAccountHolder());
                $this->writePaymentMethodValue('debitBankCode', $debitClass->getBankCode());
                $this->writePaymentMethodValue('debitBankName', $debitClass->getBankName());
            }
        }
    }

    /**
     * @return void
     */
    private function prepareSepaPayment()
    {
        if ($this->getOrderItem()->getPayment()->getName() === Sepa::SEPA_PAYMENT_NAME) {
            $sepaClass = new Sepa($this->getOrderItem()->getId());
            $sepaClass->setIsSepa(true);

            $repository       = Shopware()->Models()->getRepository('Shopware\Models\Customer\PaymentData');
            $paymentDataModel = $repository->findOneBy(array(
                'paymentMeanId' => $this->getOrderItem()->getPayment()->getId(),
                'customer'      => $this->getOrderItem()->getCustomer()->getId()
            ));

            if ($paymentDataModel !== null) {
                $sepaClass->setSCorePaymentData($paymentDataModel);
                $this->writePaymentMethodValue('iban', $sepaClass->getIban());
                $this->writePaymentMethodValue('bic', $sepaClass->getBic());
                $this->writePaymentMethodValue('bankName', $sepaClass->getBankName());
                $this->writePaymentMethodValue('accountHolder', $sepaClass->getAccountHolder());
            }
        }
    }

    /**
     * @return void
     */
    private function prepareHeidelPayCc()
    {
        if ($this->isHeidelPay()) {
            $heidelPayClass = new HeidelPay($this->getOrderItem()->getId());
            $heidelPayClass->setIsHeidelPay(true);

            $this->writePaymentMethodValue('cardAuthorization', $heidelPayClass->getCardAuthorization());
            $this->writePaymentMethodValue('shortId', $heidelPayClass->getShortId());
        }
    }

    /**
     * @return bool
     */
    private function isHeidelPay()
    {
        return $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_CC_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEILDE_PAY_DC_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_DD_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_IV_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_PP_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_SUE_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_GIR_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_PAY_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_IDE_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_BS_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_MK_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_PF_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_YT_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_MPA_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_PAPG_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_IVB2B
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_ALIPAY_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_CREDIT_CARD_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_EPS_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_FLEXIPAY_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_GIROPAY_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_HIRE_PURCHASE_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_IDEAL_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_INVOICE_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_INVOICE_FACTORING_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_INVOICE_GUARANTEED_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_PAYPAL_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_PREPAYMENT_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_PRZELEWY_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_SEPA_DIRECT_DEBIT_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_SEPA_DIRECT_DEBIT_GUARANTEED_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_SOFORT_NAME
            || $this->getOrderItem()->getPayment()->getName() === HeidelPay::HEIDEL_PAY_WE_CHAT_NAME;
    }

    /**
     * @return void
     */
    private function prepareMollie()
    {
        if ($this->isMollie()) {
            $mollieClass = new Mollie($this->getOrderItem()->getId());

            $this->writePaymentMethodValue('paymentMethod', $mollieClass->getPaymentMethod());
            $this->writePaymentMethodValue('basketSignature', $mollieClass->getBasketSignature());
            $this->writePaymentMethodValue('mollieId', $mollieClass->getMollieId());
            $this->writePaymentMethodValue('molliePaymentId', $mollieClass->getMolliePaymentId());
            $this->writePaymentMethodValue('sessionId', $mollieClass->getSessionId());
            $this->writePaymentMethodValue('ordermailVariables', $mollieClass->getOrdermailVariables());
        }
    }

    /**
     * @return bool
     */
    private function isMollie() {
        $paymentMethodName = $this->getOrderItem()->getPayment()->getName();

        return $paymentMethodName === Mollie::MOLLIE_APPLEPAY
            || $paymentMethodName === Mollie::MOLLIE_APPLEPAYDIRECT
            || $paymentMethodName === Mollie::MOLLIE_CREDITCARD
            || $paymentMethodName === Mollie::MOLLIE_EPS
            || $paymentMethodName === Mollie::MOLLIE_KLARNAPAYLATER
            || $paymentMethodName === Mollie::MOLLIE_KLARNAPAYNOW
            || $paymentMethodName === Mollie::MOLLIE_KLARNASLICEIT
            || $paymentMethodName === Mollie::MOLLIE_SOFORT;
    }

    /**
     * @return void
     */
    private function prepareBillPayPayment()
    {
        if ($this->getOrderItem()->getPayment()->getName() === BillPayHelper::BILL_PAY_NAME || $this->getOrderItem()->getPayment()->getName() === BillPayHelper::BILL_PAY_B2B ||
            $this->getOrderItem()->getPayment()->getName() === BillPayHelper::BILL_PAY_DEBIT || $this->getOrderItem()->getPayment()->getName() === BillPayHelper::BILL_PAY_TC ||
            $this->getOrderItem()->getPayment()->getName() === BillPayHelper::BILL_PAY_PAY_LATER) {
            $billPayHelperClass = new BillPayHelper(true, $this->getOrderItem()->getId());

            $this->writePaymentMethodValue('billPayAccountHolder', $billPayHelperClass->getBillPayAccountHolder());
            $this->writePaymentMethodValue('billPayAccountNumber', $billPayHelperClass->getBillPayAccountNumber());
            $this->writePaymentMethodValue('billPayBankCode', $billPayHelperClass->getBillPayBankCode());
            $this->writePaymentMethodValue('billPayBankName', $billPayHelperClass->getBillPayBankName());
            $this->writePaymentMethodValue('billPayTxId', $billPayHelperClass->getBillPayTxId());
            $this->writePaymentMethodValue('billPayApiReference', $billPayHelperClass->getBillPayApiReference());
            $this->writePaymentMethodValue('billPayPortalId', $billPayHelperClass->getBillPayPortalId());
            $this->writePaymentMethodValue('billPayMerchantId', $billPayHelperClass->getMerchantId());
            $this->writePaymentMethodValue('billPayAuthToken', $billPayHelperClass->getAuthToken());
        }
    }

    /**
     * @return void
     */
    private function preparePayolutionPayment()
    {
        if ($this->getOrderItem()->getPayment()->getName() === PayolutionHelper::PAYOLUTION_INVOICE_B2C ||
            $this->getOrderItem()->getPayment()->getName() === PayolutionHelper::PAYOLUTION_INVOICE_B2B ||
            $this->getOrderItem()->getPayment()->getName() === PayolutionHelper::PAYOLUTION_INSTALLMENT ||
            $this->getOrderItem()->getPayment()->getName() === PayolutionHelper::PAYOLUTION_ELV) {
            $payolutionClass = new PayolutionHelper(true, $this->getOrderItem()->getId(), $this->getOrderItem()->getCustomer()->getId());

            $cardHolder = $payolutionClass->getPayolutionCardHolder();
            $bankName   = $payolutionClass->getPayolutionBankName();

            if (strlen($cardHolder) > 0) {
                $this->writePaymentMethodValue('cardHolder', $cardHolder);
            }

            if (strlen($bankName) > 0) {
                $this->writePaymentMethodValue('bankName', $bankName);
            }

            if ($this->getOrderItem()->getPayment()->getName() === PayolutionHelper::PAYOLUTION_ELV) {
                $bic    = $payolutionClass->getPayolutionBic();
                $iban   = $payolutionClass->getPayolutionIban();
                $holder = $payolutionClass->getPayolutionHolder();

                if (strlen($bic) > 0) {
                    $this->writePaymentMethodValue('bic', $bic);
                }

                if (strlen($iban) > 0) {
                    $this->writePaymentMethodValue('iban', $iban);
                }

                if (strlen($holder) > 0) {
                    $this->writePaymentMethodValue('holder', $holder);
                }
            }
        }
    }

    /**
     * Payment method value entry for amazon payment
     */
    private function prepareAmazonPayment()
    {
        $paymentMethodName = $this->getOrderItem()->getPayment()->getName();

        if ($paymentMethodName === AmazonPay::AMAZON_PAY ||
            $paymentMethodName === AmazonPay::AMAZON_PAY_CHECKOUT) {
            $amazonPay = new AmazonPay($this->getOrderItem()->getId());

            $this->writePaymentMethodValue('orderReferenceId', $amazonPay->getOrderReference());
            $this->writePaymentMethodValue('captureId', $amazonPay->getCaptureId($paymentMethodName));

            if ($paymentMethodName === AmazonPay::AMAZON_PAY) {
                $this->writePaymentMethodValue('authorizationId', $amazonPay->getBestItAuthorisationId());
            }
        }
    }

    /**
     * @param string $attributeKey
     * @param string $attributeValue
     *
     * @return void
     */
    private function writePaymentMethodValue($attributeKey = '', $attributeValue = '')
    {
        FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['PaymentMethodValues']['PaymentMethodValue-' . $this->internalKey] = array(
            '@attributes' => array('key' => $attributeKey, 'value' => $attributeValue)
        );

        ++$this->internalKey;
    }

    /**
     * @return array
     */
    public function getCustomMethods()
    {
        return $this->customMethods;
    }

    /**
     * @param array $customMethods
     */
    public function setCustomMethods($customMethods)
    {
        $this->customMethods = $customMethods;
    }

    /**
     * @return array
     */
    public function getCustomClasses()
    {
        return $this->customClasses;
    }

    /**
     * @param array $customClasses
     */
    public function setCustomClasses($customClasses)
    {
        $this->customClasses = $customClasses;
    }
}