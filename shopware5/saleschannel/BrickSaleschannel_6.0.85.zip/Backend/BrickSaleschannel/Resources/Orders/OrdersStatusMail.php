<?php
namespace Bf\Saleschannel\Components\Resources\Orders;

use Exception;

/**
 * OrdersStatusMail
 *
 * @package Bf\Saleschannel\Components\Resources\Orders
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class OrdersStatusMail
{
    private static $instance = null;

    /** @var array */
    private $ordersStatusModels = array();

    /**
     * @return OrdersStatusMail
     */
    public static function getInstance()
    {
        if(self::$instance === null)
        {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * @return void
     */
    public function sendStatusMail()
    {
        if(count(self::getInstance()->getOrdersStatusModels()) > 0)
        {
            /** @var \Shopware\Models\Order\Status $ordersStatusModel */
            foreach(self::getInstance()->getOrdersStatusModels() as $value)
            {
                try
                {
                    $mailData = $this->getMailForOrder($value['orderId'], $value['statusId']);

                    if($mailData['data']['error'] === false)
                    {
                        if(is_object($mailData['mail']) === true)
                        {
                            Shopware()->Modules()->Order()->sendStatusMail($mailData['mail']);
                            Shopware()->Models()->clear();
                        }
                    }
                }
                catch(Exception $e)
                {
                }
            }
        }
    }

    /**
     * @param $orderId
     * @param $statusId
     *
     * @return array
     * @throws Exception
     */
    final private function getMailForOrder($orderId, $statusId)
    {
        $return = array(
            'mail' => null,
            'data' => array(
                'error'   => true,
                'message' => ''
            )
        );

        try
        {
            /** @var \Enlight_Components_Mail $mail */
            $mail = Shopware()->Modules()->Order()->createStatusMail($orderId, $statusId);

            if($mail instanceof \Enlight_Components_Mail)
            {
                $return = array(
                    'mail' => $mail,
                    'data' => array(
                        'error'    => false,
                        'content'  => $mail->getPlainBodyText(),
                        'subject'  => $mail->getPlainSubject(),
                        'to'       => implode(', ', $mail->getTo()),
                        'fromMail' => $mail->getFrom(),
                        'fromName' => $mail->getFromName(),
                        'sent'     => false,
                        'orderId'  => $orderId
                    )
                );
            }
        }
        catch(Exception $e)
        {
            throw new Exception($e);
        }

        return $return;
    }

    /**
     * @return array
     */
    public function getOrdersStatusModels()
    {
        return $this->ordersStatusModels;
    }

    /**
     * @param array $ordersStatusModels
     *
     * @return OrdersStatusMail
     */
    public function setOrdersStatusModels($ordersStatusModels)
    {
        $this->ordersStatusModels[] = $ordersStatusModels;

        return $this;
    }
}
