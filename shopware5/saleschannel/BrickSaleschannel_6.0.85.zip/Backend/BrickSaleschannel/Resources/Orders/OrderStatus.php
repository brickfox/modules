<?php

namespace Bf\Saleschannel\Components\Resources\Orders;

use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Exception;
use Shopware\CustomModels\BfSaleschannel\MappingPaymentMethodToPaymentStatus;
use Shopware\CustomModels\BfSaleschannel\MappingShippingStatus;
use Shopware\Models\Order\Detail;
use Shopware\Models\Order\DetailStatus;
use Shopware\Models\Order\Status;
use SimpleXMLElement;
use Shopware\Models\Order\Order as SwOrder;

/**
 * OrderStatus
 *
 * @package Bf\Saleschannel\Components\Resources\Orders
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2020 brickfox GmbH http://www.brickfox.de
 */
class OrderStatus extends OrderStatusAbstract
{
    const SHIPPING_MAPPING_CODE_SHIPPED = 'Shipped';

    /** @var null */
    private $paymentStatus = null;

    /** @var string */
    private $carrierAttributeFieldName = '';

    /**
     * @param SimpleXMLElement $simpleXmlElement
     * @param SwOrder $order
     */
    public function __construct(SimpleXmlElement $simpleXmlElement, SwOrder $order)
    {
        $this->setOrder($order);
        $this->setOrderXmlElement($simpleXmlElement);

        $this->carrierAttributeFieldName = ConfigManager::getInstance()->getCarrierAttributeFieldName();
    }

    /**
     * @throws Exception
     */
    public function prepareOrderStatusItem()
    {
        /** @var Status $orderStatusModel */
        $orderStatusModel = $this->getOrderStatusIdByBrickfoxCode();
        $oldStatusId      = $this->getOrder()->getOrderStatus()->getId();
        $newStatusId      = $orderStatusModel->getId();

        if ($oldStatusId !== $newStatusId) {
            $this->getOrder()->setOrderStatus($orderStatusModel);
            $this->getOrder()->setTrackingCode($this->getOrderTrackingCode());

            if (strlen($this->carrierAttributeFieldName) > 0 && strlen($carrierName = $this->getCarrierName()) > 0) {
                $orderAttributes = $this->getOrder()->getAttribute();
                $setter          = 'set' . ucfirst($this->carrierAttributeFieldName);

                if (method_exists($orderAttributes, $setter)) {
                    $orderAttributes->$setter($carrierName);

                    Shopware()->Models()->persist($orderAttributes);
                }
            }
        }

        foreach ($this->getOrderLines() as $orderLine) {
            /** @var Detail $orderDetailModel */
            $orderDetailModel = Helper::getMappingById('Shopware\Models\Order\Detail', (int)$orderLine->OrderLineId);

            if ($orderDetailModel !== null) {
                try {
                    $oldDetailStatusId = $orderDetailModel->getStatus()->getId();
                    $newDetailStatusId = $this->getOrderLineStatusIdByBrickfoxCode((string)$orderLine->OrderLineStatus);

                    if ($oldDetailStatusId !== $newDetailStatusId) {
                        $orderDetailModel->setStatus($this->getOrderLineStatusIdByBrickfoxCode((string)$orderLine->OrderLineStatus));

                        Shopware()->Models()->persist($orderDetailModel);
                    }
                } catch (Exception $e) {
                    LogManager::getInstance()->logError($e->getMessage());
                }
            }
        }

        if (
            $oldStatusId !== $newStatusId
            && $newStatusId === $this->getSendEmailStatusId()
            && Helper::getConfigurationByKey('sendMail')->getConfigurationValue() === 'true'
        ) {
            OrdersStatusMail::getInstance()->setOrdersStatusModels(
                [
                    'orderId'  => $this->getOrder()->getId(),
                    'statusId' => $newStatusId
                ]
            );
        }
    }

    /**
     * @return int
     */
    private function getSendEmailStatusId()
    {
        $sendEmailStatusId = 2;

        /** @var MappingShippingStatus $shippingStatusModel */
        $shippingStatusModel = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingShippingStatus')
            ->findOneBy(['brickfoxShippingStatusCode' => self::SHIPPING_MAPPING_CODE_SHIPPED]);

        if ($shippingStatusModel !== null) {
            $sendEmailStatusId = (int)$shippingStatusModel->getMappingFieldKey();
        }

        return $sendEmailStatusId;
    }

    /**
     * @return array
     */
    private function getOrderLines()
    {
        $orderLines = [];

        foreach ($this->getOrderXmlElement()->{"OrderLines"}->{"OrderLine"} as $orderLine) {
            $orderLines[] = $orderLine;
        }

        return $orderLines;
    }

    /**
     * @return string
     */
    private function getOrderTrackingCode()
    {
        $trackingCode = '';

        if ((bool)$this->getOrderXmlElement()->ShippingTrackingId === true) {
            $trackingCode = (string)$this->getOrderXmlElement()->ShippingTrackingId;
        }

        return $trackingCode;
    }

    /**
     * @return string
     */
    private function getCarrierName()
    {
        return isset($this->getOrderXmlElement()->CarrierName) ? (string)$this->getOrderXmlElement()->CarrierName : '';
    }

    /**
     * @param string $orderLineStatus
     * @return DetailStatus|Status|null
     * @throws Exception
     */
    private function getOrderLineStatusIdByBrickfoxCode($orderLineStatus)
    {
        $orderStatusId = 1; // Klärung notwendig

        /** @var MappingShippingStatus $shippingStatusMappingModel */
        $shippingStatusMappingModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingShippingStatus')
            ->findOneBy(['brickfoxShippingStatusCode' => $orderLineStatus]);

        if ($shippingStatusMappingModel !== null) {
            if ($shippingStatusMappingModel->getBrickfoxShippingStatusCode() === $orderLineStatus) {
                $orderStatusId = (int)$shippingStatusMappingModel->getMappingFieldKey();
            }
        } else {
            switch ($orderLineStatus) {
                case 'new':
                case 'processing':
                case 'pending':
                    $orderStatusId = 1; //In Bearbeitung
                    break;

                case 'canceled':
                    $orderStatusId = 2;
                    break;

                case 'fulfilled':
                case 'complete':
                case 'shipped':
                    $orderStatusId = 3; //Komplett abgeschlossen
                    break;

                default:
                    $orderStatusId = 1; //Klärung notwendig
            }
        }

        return $this->getOrderStatusModelById('Shopware\Models\Order\DetailStatus', $orderStatusId);
    }

    /**
     * @return DetailStatus|Status|null
     * @throws Exception
     */
    private function getOrderStatusIdByBrickfoxCode()
    {
        $statusCode = (string)$this->getOrderXmlElement()->OrderStatus;

        /** @var MappingShippingStatus $shippingStatusMappingModel */
        $shippingStatusMappingModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingShippingStatus')
            ->findOneBy(['brickfoxShippingStatusCode' => $statusCode]);

        if ($shippingStatusMappingModel !== null) {
            $orderStatus = (int)$shippingStatusMappingModel->getMappingFieldKey();
        } else {
            switch ($statusCode) {
                case 'new':
                case 'processing':
                case 'pending':
                case 'open':
                    $orderStatus = 1; // In Bearbeitung
                    break;

                case 'complete':
                    $orderStatus = 2; // Komplett abgeschlossen
                    break;

                case 'canceled':
                    $orderStatus = 4; // Storniert / Abgelehnt
                    break;

                case 'readyforshipping':
                    $orderStatus = 5; // Zur Lieferung bereit
                    break;

                case 'partlyshipped':
                    $orderStatus = 6; // Teilweise ausgeliefert
                    break;

                case 'shipped':
                    $orderStatus = 2; // Komplett ausgeliefert
                    break;

                default:
                    $orderStatus = 8; // Klärung notwendig
                    break;
            }
        }

        if ($statusCode === 'shipped') {
            $this->preparePaymentStatus();
        }

        return $this->getOrderStatusModelById('Shopware\Models\Order\Status', $orderStatus);
    }

    /**
     */
    private function preparePaymentStatus()
    {
        /** @var MappingPaymentMethodToPaymentStatus $mappingModel */
        $mappingModel = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingPaymentMethodToPaymentStatus')
            ->findOneBy(['paymentId' => $this->getOrder()->getPayment()->getId()]);

        if ($mappingModel !== null) {
            /** @var Status $paymentStatusModel */
            $paymentStatusModel = Helper::getRepository('Shopware\Models\Order\Status')->findOneBy(['id' => $mappingModel->getPaymentStatusId()]);

            if ($paymentStatusModel !== null) {
                $this->getOrder()->setPaymentStatus($paymentStatusModel);

                Shopware()->Models()->persist($this->getOrder());
            }
        }
    }

    /**
     * @return null
     */
    public function getPaymentStatus()
    {
        return $this->paymentStatus;
    }

    /**
     * @param null $paymentStatus
     */
    public function setPaymentStatus($paymentStatus)
    {
        $this->paymentStatus = $paymentStatus;
    }
}
