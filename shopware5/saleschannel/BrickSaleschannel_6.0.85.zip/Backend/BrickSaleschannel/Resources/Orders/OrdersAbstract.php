<?php
/**
 * OrdersAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Orders
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Orders;

use Bf\Saleschannel\Components\Util\Exceptions;
use Bf\Saleschannel\Components\Util\Helper;
use XmlWriter;
use Shopware\Models\Order\Order as SwOrder;
use Doctrine\Common\Collections\ArrayCollection;

abstract class OrdersAbstract
{
    private $xmlWriter;

    /** @var array */
    private $orderItem = array();

    /** @var string */
    private $ordersPartiesEmailAddress = '';

    /** @var string */
    private $ordersPartiesVatId = '';

    /** @var string */
    private $ordersPartiesPhoneNumber = '';

    /**
     * @return mixed|XmlWriter
     */
    public function getXmlWriter()
    {
        return $this->xmlWriter;
    }

    /**
     * @param mixed $xmlWriter
     * @return OrdersAbstract
     */
    public function setXmlWriter($xmlWriter)
    {
        $this->xmlWriter = $xmlWriter;

        return $this;
    }

    /**
     * @return SwOrder|ArrayCollection
     */
    public function getOrderItem()
    {
        return $this->orderItem;
    }

    /**
     * @param SwOrder|ArrayCollection $orderItem
     * @return OrdersAbstract
     */
    public function setOrderItem($orderItem)
    {
        $this->orderItem = $orderItem;

        return $this;
    }

    /**
     * @param array $operation
     * @return float|int
     * @throws \Exception
     */
    protected function calculate(array $operation = array())
    {
        $result = 0;

        if(count($operation) > 0)
        {
            $allowedOperations = array('+', '-', '/', '*');
            $error             = array(
                'div0'    => 'You cant divide by zero',
                'wrongOp' => 'This operator does not exists, please use +, -, /, or *'
            );

            if(in_array($operation['operator'], $allowedOperations) === true)
            {
                $number1 = Helper::toFloat($operation['number1']);
                $number2 = Helper::toFloat($operation['number2']);

                switch($operation['operator'])
                {
                    case '+':
                        $result = $number1 + $number2;
                        break;

                    case '-':
                        $result = $number1 - $number2;
                        break;

                    case '/':
                        if($number2 === 0)
                        {
                            Exceptions::throwException(
                                $error['div0']
                            );
                        }

                        $result = $number1 / $number2;
                        break;

                    case '*':
                        $result = $number1 * $number2;
                        break;
                }
            }
            else
            {
                Exceptions::throwException(
                    $error['wrongOp']
                );
            }
        }

        return $result;
    }

    /**
     * @param $modelNamespace
     * @param array $condition
     * @param string $loader
     * @return null|object
     * @throws \Exception
     */
    final public function loadModelByCondition($modelNamespace, array $condition = array(), $loader = 'findOneBy')
    {
        $model = null;

        if(count($condition) <= 0)
        {
            Exceptions::throwException(
                'Cannot load model without conditions.'
            );
        }

        $repository = Helper::getRepository($modelNamespace);
        $model      = $repository->$loader($condition);

        return $model;
    }

    /**
     * @return string
     */
    public function getOrdersPartiesEmailAddress()
    {
        return $this->ordersPartiesEmailAddress;
    }

    /**
     * @param string $ordersPartiesEmailAddress
     * @return OrdersAbstract
     */
    public function setOrdersPartiesEmailAddress($ordersPartiesEmailAddress)
    {
        $this->ordersPartiesEmailAddress = $ordersPartiesEmailAddress;

        return $this;
    }

    /**
     * @return string
     */
    public function getOrdersPartiesVatId()
    {
        return $this->ordersPartiesVatId;
    }

    /**
     * @param string $ordersPartiesVatId
     * @return OrdersAbstract
     */
    public function setOrdersPartiesVatId($ordersPartiesVatId)
    {
        $this->ordersPartiesVatId = $ordersPartiesVatId;

        return $this;
    }

    /**
     * @return string
     */
    public function getOrdersPartiesPhoneNumber()
    {
        return $this->ordersPartiesPhoneNumber;
    }

    /**
     * @param string $ordersPartiesPhoneNumber
     * @return OrdersAbstract
     */
    public function setOrdersPartiesPhoneNumber($ordersPartiesPhoneNumber)
    {
        $this->ordersPartiesPhoneNumber = $ordersPartiesPhoneNumber;

        return $this;
    }

    /**
     * @param SwOrder $orderItem
     */
    abstract protected function __construct(SwOrder $orderItem);

    abstract protected function __destruct();
}
