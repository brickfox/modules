<?php

namespace Bf\Saleschannel\Components\Resources\Orders;

use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\Exceptions;
use Bf\Saleschannel\Components\Util\FileWriter;
use Bf\Saleschannel\Components\Util\Helper;
use XMLWriter;
use Shopware\Models\Order\Order as SwOrder;
use Shopware\Models\Order\Detail as SwOrderDetail;

/**
 * OrdersLines
 *
 * @package Bf\Saleschannel\Components\Resources\Orders
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class OrdersLines extends OrdersAbstract
{
    const FILE_NAME = 'OrdersLines';

    /** @var int */
    private $ordersLinesCount = 0;

    /**
     * @param SwOrder $orderItem
     */
    public function __construct(SwOrder $orderItem)
    {
        $this->setOrderItem($orderItem->getDetails());
        $this->setOrdersLinesCount(count($this->getOrderItem()));
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function prepareOrderLines()
    {
        $count                                                                                  = 0;
        FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['OrderLines'] = array(
            '@attributes' => array('count' => $this->getOrdersLinesCount())
        );

        /** @var \Shopware\Models\Order\Detail $orderLine */
        foreach ($this->getOrderLine() as $orderLine) {
            if (($orderLine->getMode() === 0 || $orderLine->getMode() === 1) && $orderLine->getArticleId() !== 0) {
                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['OrderLines']['OrderLine-' . $count] = array(
                    'OrderLineId' => array('@value' => $orderLine->getId()),
                    'ProductId'   => array('@value' => $this->getBrickfoxIdByArticleId($orderLine->getArticleId())),
                    'ProductName' => array('@value' => $orderLine->getArticleName()),
                    'ItemNumber'  => array('@value' => $orderLine->getArticleNumber())
                );

                $ean = $this->getEanByNumber($orderLine->getArticleNumber());

                $hasNetPrice = $orderLine->getOrder()->getNet();
                $taxRate = $orderLine->getOrder()->getTaxFree() ? 0 : $orderLine->getTaxRate();

                if($hasNetPrice && ConfigManager::getInstance()->getExportTaxesForNetOrders() == "true") {
                    $netPrice        = Helper::toFloat($orderLine->getPrice());
                    $grossPrice      = $this->calculatePriceGross($netPrice, $taxRate);
                    $totalPriceGross = $this->calculatePriceGross($netPrice, $taxRate, $orderLine->getQuantity());
                }
                else {
                    $totalPriceGross = $this->calculate(array('operator' => '*', 'number1' => $orderLine->getPrice(), 'number2' => $orderLine->getQuantity()));
                    $grossPrice      = Helper::toFloat($orderLine->getPrice());
                    $netPrice        = $this->calculate(array('operator' => '/', 'number1' => $orderLine->getPrice(), 'number2' => $this->getArticleTax($orderLine)));
                    $taxRate         = ($orderLine->getOrder()->getTaxFree() || $orderLine->getOrder()->getNet()) ? 0 : $orderLine->getTaxRate();
                }

                if ($ean !== null) {
                    FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['OrderLines']['OrderLine-' . $count]['EAN'] = array(
                        '@value' => $ean
                    );
                }

                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['OrderLines']['OrderLine-' . $count]['VariationId'] = array(
                    '@value' => $this->getVariationIdByNumber($orderLine->getArticleNumber())
                );

                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['OrderLines']['OrderLine-' . $count]['QuantityOrdered'] = array(
                    '@value' => $orderLine->getQuantity()
                );

                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['OrderLines']['OrderLine-' . $count]['ProductsPriceTotal'] = array(
                    '@value' => $totalPriceGross
                );

                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['OrderLines']['OrderLine-' . $count]['VatPriceTotal'] = array(
                    '@value' => 0
                );

                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['OrderLines']['OrderLine-' . $count]['ProductsPrice'] = array(
                    '@value' => $grossPrice
                );

                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['OrderLines']['OrderLine-' . $count]['ProductsPriceNetto'] = array(
                    '@value' => $netPrice
                );

                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['OrderLines']['OrderLine-' . $count]['TaxRate'] = array(
                    '@value' => $taxRate
                );

                $repository                      = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingOrderLinesAttributes');
                $mappingOrderLinesAttributesList = $repository->findAll();

                if (count($mappingOrderLinesAttributesList) > 0) {
                    $orderLinesAttributesModel                                                                                                          = $orderLine->getAttribute();
                    FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['OrderLines']['OrderLine-' . $count]['OrderLineAddInfos'] = array(
                        '@attributes' => array(
                            'count' => count($mappingOrderLinesAttributesList)
                        )
                    );

                    if ($orderLinesAttributesModel !== null) {
                        $orderLinesAddInfoCount = 1;

                        /** @var \Shopware\CustomModels\BfSaleschannel\MappingOrderLinesAttributes $mappingOrderLinesAttributes */
                        foreach ($mappingOrderLinesAttributesList as $mappingOrderLinesAttributes) {
                            $getter = ucwords($mappingOrderLinesAttributes->getShopwareColumnName(), '_');
                            $getter = 'get' . ucfirst($getter);
                            $getter = str_replace('_', '', $getter);

                            try {
                                $value = '';

                                if (method_exists($orderLinesAttributesModel, $getter) === true) {
                                    $value = $orderLinesAttributesModel->$getter();
                                }

                                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['OrderLines']['OrderLine-' .
                                                                                                                        $count]['OrderLineAddInfos']['OrderLineAddInfo-' .
                                                                                                                                                     $orderLinesAddInfoCount] = array(
                                    '@attributes' => array('num' => $orderLinesAddInfoCount),
                                    'Key'         => array('@value' => $mappingOrderLinesAttributes->getBrickfoxExportName()),
                                    'Value'       => array('@cdata' => $value)
                                );
                            } catch (\Exception $e) {
                                echo '<pre>';
                                print_r($e->getMessage());
                                echo '</pre>';
                            }

                            ++$orderLinesAddInfoCount;
                        }
                    }
                }

                ++$count;
            }
        }
    }

    /**
     * @param float $priceNet
     * @param int   $vat
     * @param int   $quantity
     * @return string
     */
    private function calculatePriceGross($priceNet, $vat, $quantity = 1)
    {
        $priceNet = $priceNet * $quantity;

        if($vat == false)
        {
            $grossPrice = $priceNet;
        }
        else
        {
            $grossPrice = $priceNet * (1 + ($vat / 100));
        }

        $grossPrice =  number_format($grossPrice, 2, '.', '');

        return $grossPrice;
    }

    /**
     * @param float $priceGross
     * @param int   $vat
     * @return string
     */
    private function calculatePriceNet($priceGross, $vat)
    {
        if($vat == false)
        {
            $priceNet = $priceGross;
        }
        else
        {
            $priceNet = $priceGross / (1 + ($vat / 100));
        }

        $priceNet =  number_format($priceNet, 2, '.', '');

        return $priceNet;
    }


    /**
     * @return array
     */
    private function getOrderLine()
    {
        $orderLineArr = array();

        foreach ($this->getOrderItem() as $orderLine) {
            $orderLineArr[] = $orderLine;
        }

        return $orderLineArr;
    }

    /**
     * @param $articleId
     *
     * @return int
     * @throws \Exception
     */
    private function getBrickfoxIdByArticleId($articleId)
    {
        /** @var \Shopware\CustomModels\BfSaleschannel\MappingArticles $mappingModel */
        $mappingModel = $this->loadModelByCondition('Shopware\CustomModels\BfSaleschannel\MappingArticles', array('shopwareId' => $articleId));

        if (is_object($mappingModel) === false || $mappingModel === null) {
            throw new \Exception('Could not load mapping model. ArticleID: ' . $articleId);
        }

        return $mappingModel->getBrickfoxId();
    }

    /**
     * @param $orderNumber
     *
     * @return float|null
     * @throws \Exception
     */
    private function getEanByNumber($orderNumber)
    {
        $ean = null;

        $detailModel = $this->loadModelByCondition('Shopware\Models\Article\Detail', array('number' => $orderNumber));

        Exceptions::instanceOfException(array(
            'fileName' => self::FILE_NAME,
            array(
                'obj'   => 'Shopware\Models\Article\Detail',
                'param' => $detailModel
            )
        ));

        if ($detailModel !== null) {
            $ean = $detailModel->getEan();
        }

        return $ean;
    }

    /**
     * @param $orderNumber
     *
     * @return int
     * @throws \Exception
     */
    private function getVariationIdByNumber($orderNumber)
    {
        /** @var \Shopware\Models\Article\Detail $detailModel */
        $detailModel = $this->loadModelByCondition('Shopware\Models\Article\Detail', array('number' => $orderNumber));

        Exceptions::instanceOfException(array(
            'fileName' => self::FILE_NAME,
            array(
                'obj'   => 'Shopware\Models\Article\Detail',
                'param' => $detailModel
            )
        ));

        /** @var \Shopware\CustomModels\BfSaleschannel\MappingDetails $detailMappingModel */
        $detailMappingModel = $this->loadModelByCondition('Shopware\CustomModels\BfSaleschannel\MappingDetails', array('shopwareId' => $detailModel->getId()));

        if ($detailMappingModel === false || $detailMappingModel === null) {
            throw new \Exception('Could not load mapping details model. shopwareID: ' . $detailModel->getId());
        }

        return $detailMappingModel->getBrickfoxId();
    }

    /**
     * @param SwOrderDetail $orderLine
     *
     * @return float|int
     */
    private function getArticleTax(SwOrderDetail $orderLine)
    {
        if ($orderLine->getOrder()->getTaxFree() === 1 || $orderLine->getOrder()->getNet() === 1) {
            $divisionNumber = 1;
        } else {
            $orderLineTaxRate = $orderLine->getTaxRate();
            $divisionNumber   = $orderLineTaxRate / 100 + 1;
        }

        return $divisionNumber;
    }

    /**
     * @return int
     */
    public function getOrdersLinesCount()
    {
        return $this->ordersLinesCount;
    }

    /**
     * @param int $ordersLinesCount
     *
     * @return OrdersLines
     */
    public function setOrdersLinesCount($ordersLinesCount)
    {
        $this->ordersLinesCount = $ordersLinesCount;

        return $this;
    }

    /**
     * @return void
     */
    public function __destruct()
    {
    }
}
