<?php
/**
 * Voucher
 *
 * @package Bf\Saleschannel\Components\Resources\Orders\Voucher
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Orders\Voucher;

use Bf\Saleschannel\Components\Resources\Orders\Plugins\NetIEasyCoupon;
use Bf\Saleschannel\Components\Util\FileWriter;
use Shopware\Models\Order\Detail as SwOrderDetail;
use Shopware\Models\Order\Order as SwOrder;

class Voucher extends VoucherAbstract
{
    const NET_I_EASY_COUPON_DESCRIPTION = 'netiEasyCoupon';

    /**
     * @param SwOrder $order
     * @param SwOrderDetail $detail
     */
    public function __construct(SwOrder $order, SwOrderDetail $detail)
    {
        parent::__construct($order, $detail);
    }

    public function prepareCouponsItem($count)
    {
        $this->prepareVoucher();

        if ($this->getVoucher() !== null) {
            if ($this->getVoucher()->getDescription() !== self::NET_I_EASY_COUPON_DESCRIPTION) {
                $coupon = [
                    'ExternId'         => ['@value' => $this->getDetail()->getArticleId()],
                    'Code'             => ['@value' => $this->writeVoucherCode()],
                    'Type'             => ['@value' => self::VOUCHER_TYPE_CAMPAIGN],
                    'ReduceType'       => ['@value' => $this->writeReduceType()],
                    'Rebate'           => ['@value' => $this->writeRebate()],
                    'Title'            => ['@cdata' => $this->getVoucher()->getDescription()],
                    'CalculatedRebate' => ['@value' => $this->getDetail()->getPrice() * -1.0]
                ];

                $this->prepareRestrictedArticles();

                $orderLineReferenceCount = 0;

                /** @var \Shopware\Models\Order\Detail $detail */
                foreach ($this->getOrder()->getDetails() as $detail) {
                    if (strlen($detail->getArticleNumber()) > 0 && in_array($detail->getArticleNumber(), $this->getRestrictedArticles())) {
                        $coupon['OrderLineReferences']['OrderLineReference-' . $orderLineReferenceCount++] = ['OrderLineId' => ['@value' => $detail->getId()]];
                    }
                }

                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['Coupons']['Coupon-' . $count] = $coupon;
            } else {
                (new NetIEasyCoupon($this->getOrder(), $this->getDetail()))->prepareCoupon($count, $this->getVoucher()->getDescription());
            }
        } elseif ($this->getDetail()->getMode() === 10) {
            $bundleModel = $this->getBundleModelByOrderNumber();

            if ($bundleModel !== null) {
                $rebate = 0;

                /** @var \Shopware\CustomModels\Bundle\Price $price */
                foreach ($bundleModel->getPrices() as $price) {
                    if ($price->getCustomerGroup()->getKey() === $this->getOrder()->getCustomer()->getGroup()->getKey()) {
                        $rebate = $price->getPrice();
                    }
                }

                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['Coupons']['Coupon-' . $count] = [
                    'ExternId'         => ['@value' => $this->getDetail()->getArticleId()],
                    'Code'             => ['@value' => $this->getDetail()->getArticleNumber()],
                    'Type'             => ['@value' => self::VOUCHER_TYPE_CAMPAIGN],
                    'ReduceType'       => ['@value' => ($bundleModel->getDiscountType() === 'abs') ? 'ABSOLUTE' : 'RELATIVE'],
                    'Rebate'           => ['@value' => $rebate],
                    'Title'            => ['@cdata' => $bundleModel->getName()],
                    'CalculatedRebate' => ['@value' => $this->getDetail()->getPrice() * -1.0]
                ];
            }
        } else {
            $rebate = $this->getDetail()->getPrice() * -1.0;

            FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['Coupons']['Coupon-' . $count] = [
                'ExternId'         => ['@value' => $this->getDetail()->getArticleId()],
                'Code'             => ['@value' => $this->getDetail()->getArticleNumber()],
                'Type'             => ['@value' => self::VOUCHER_TYPE_CAMPAIGN],
                'ReduceType'       => ['@value' => 'ABSOLUTE'],
                'Rebate'           => ['@value' => $rebate],
                'Title'            => ['@cdata' => $this->getDetail()->getArticleName()],
                'CalculatedRebate' => ['@value' => $rebate]
            ];
        }
    }

    /**
     * @return \SwagBundle\Models\Bundle
     */
    private function getBundleModelByOrderNumber()
    {
        $bundleModelRepository = Shopware()->Models()->getRepository('SwagBundle\Models\Bundle');
        $bundleModel           = $bundleModelRepository->findOneBy(['number' => $this->getDetail()->getArticleNumber()]);

        return $bundleModel;
    }

    /**
     * @return string
     */
    private function writeVoucherCode()
    {
        $returnValue = self::DEFAULT_VOUCHER_CODE;

        $voucherCode = $this->getVoucher()->getVoucherCode();

        if (strlen($voucherCode) > 0) {
            $returnValue = $voucherCode;
        }

        return $returnValue;
    }

    /**
     * @return string
     */
    private function writeReduceType()
    {
        return $this->getVoucher()->getPercental() ? 'RELATIVE' : 'ABSOLUTE';
    }

    /**
     * @return string
     */
    private function writeRebate()
    {
        return $this->getRebateValue();
    }
}
