<?php
/**
 * VoucherAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Orders\Voucher
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Orders\Voucher;

use Bf\Saleschannel\Components\Util\Helper;
use Shopware\Models\Order\Detail as SwOrderDetail;
use Shopware\Models\Voucher\Voucher as SwVoucher;
use Shopware\Models\Order\Order as SwOrder;
use XMLWriter;

class VoucherAbstract
{
    const VOUCHER_TYPE_CAMPAIGN = 'CAMPAIGN';
    const DEFAULT_VOUCHER_CODE = 'Shopware-Coupon';

    private $voucher;

    private $order;

    private $detail;

    private $restrictedArticles = [];

    /**
     * @param SwOrder $order
     * @param SwOrderDetail $detail
     */
    public function __construct(SwOrder $order, SwOrderDetail $detail)
    {
        $this->setDetail($detail);
        $this->setOrder($order);
    }

    protected function prepareVoucher()
    {
        $voucherModel = Helper::getMappingByValue($this->getDetail()->getArticleNumber(), 'orderCode', 'Shopware\Models\Voucher\Voucher');

        $this->setVoucher($voucherModel);
    }

    /**
     * @return string
     */
    protected function getShippingFree()
    {
        return Shopware()->Db()->fetchOne('SELECT `shippingfree` FROM s_emarketing_vouchers WHERE ordercode = ?', $this->getDetail()->getArticleNumber());
    }

    /**
     * @return string
     */
    protected function getRebateValue()
    {
        return Shopware()->Db()->fetchOne('SELECT `value` FROM s_emarketing_vouchers WHERE ordercode = ?', $this->getDetail()->getArticleNumber());
    }

    /**
     */
    protected function prepareRestrictedArticles()
    {
        if ($this->getVoucher()->getStrict()) {
            $this->setRestrictedArticles(explode(';', $this->getVoucher()->getRestrictArticles()));
        }
    }

    /**
     * @return null|SwVoucher
     */
    public function getVoucher()
    {
        return $this->voucher;
    }

    /**
     * @param mixed $voucher
     * @return VoucherAbstract
     */
    public function setVoucher($voucher)
    {
        $this->voucher = $voucher;

        return $this;
    }

    /**
     * @return SwOrderDetail
     */
    public function getDetail()
    {
        return $this->detail;
    }

    /**
     * @param SwOrderDetail $detail
     * @return VoucherAbstract
     */
    public function setDetail($detail)
    {
        $this->detail = $detail;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getRestrictedArticles()
    {
        return $this->restrictedArticles;
    }

    /**
     * @param mixed $restrictedArticles
     * @return VoucherAbstract
     */
    public function setRestrictedArticles($restrictedArticles)
    {
        $this->restrictedArticles = $restrictedArticles;

        return $this;
    }

    /**
     * @return SwOrder
     */
    public function getOrder()
    {
        return $this->order;
    }

    /**
     * @param mixed $order
     * @return VoucherAbstract
     */
    public function setOrder($order)
    {
        $this->order = $order;

        return $this;
    }
}
