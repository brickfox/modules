<?php
namespace Bf\Saleschannel\Components\Resources\Orders;

use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Shopware\CustomModels\BfSaleschannel\Log;
use Shopware\Models\Order\Order as SwOrder;
use SimpleXMLElement;

/**
 * OrderStatusAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Orders
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class OrderStatusAbstract
{
    private $order;

    private $orderXmlElement;

    /**
     * @param $modelNamespace
     * @param $id
     *
     * @return null|\Shopware\Models\Order\Status|\Shopware\Models\Order\DetailStatus
     * @throws \Exception
     */
    protected function getOrderStatusModelById($modelNamespace, $id)
    {
        $statusModel = Helper::getMappingById($modelNamespace, $id);

        if($statusModel === null)
        {
            LogManager::getInstance()->writeLogForGui(
                Log::LOG_STATUS_ERROR,
                __METHOD__,
                str_replace(
                    array('{$statusId}', '{$orderNumber}', '{$orderId}'),
                    array($id, $this->getOrder()->getNumber(), (string) $this->getOrderXmlElement()->OrderId),
                    ErrorCodes::ORDERS_STATUS_CAN_NOT_LOAD_BY_ID
                ),
                Helper::getUserName(),
                Log::TYPE_OF_LOG_EXPORT_ORDERS,
                (string) $this->getOrderXmlElement()->OrderId,
                ErrorCodes::ORDERS_STATUS_CAN_NOT_LOAD_BY_ID_ERROR_CODE
            );
        }

        return $statusModel;
    }

    /**
     * @return SwOrder
     */
    public function getOrder()
    {
        return $this->order;
    }

    /**
     * @param mixed $order
     *
     * @return OrderStatusAbstract
     */
    public function setOrder($order)
    {
        $this->order = $order;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getOrderXmlElement()
    {
        return $this->orderXmlElement;
    }

    /**
     * @param mixed $orderXmlElement
     *
     * @return OrderStatusAbstract
     */
    public function setOrderXmlElement($orderXmlElement)
    {
        $this->orderXmlElement = $orderXmlElement;

        return $this;
    }

    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param SwOrder $order
     */
    abstract public function __construct(SimpleXMLElement $simpleXMLElement, SwOrder $order);

    /**
     * @return void
     */
    public function __destruct()
    {
        unset($this->order);
        unset($this->orderXmlElement);
    }
}
