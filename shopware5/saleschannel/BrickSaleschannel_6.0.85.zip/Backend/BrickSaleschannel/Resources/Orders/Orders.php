<?php

namespace Bf\Saleschannel\Components\Resources\Orders;

use Bf\Saleschannel\Components\Resources\Orders\Payment\PaymentMethodValues;
use Bf\Saleschannel\Components\Resources\Orders\Plugins\ThirdPartiesPluginsInformation;
use Bf\Saleschannel\Components\Resources\Orders\Voucher\Voucher;
use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\FileWriter;
use Bf\Saleschannel\Components\Util\Helper;
use Exception;
use Shopware\Models\Order\Order as SwOrder;

/**
 * Class Orders
 *
 * @package Bf\Saleschannel\Components\Resources\Orders
 */
class Orders extends OrdersAbstract
{
    const KIND_OF_ORDER_PARTY_BILLING  = 'billing';
    const KIND_OF_ORDER_PARTY_SHIPPING = 'shipping';
    const SALUTATION_MR                = 'Herr';
    const SALUTATION_MS                = 'Frau';
    const SALUTATION_UNDEFINED         = '';
    const SWAG_DHL_PLUGIN_NAME         = 'SwagDhl';

    public function __construct(SwOrder $orderItem)
    {
        $this->setOrderItem($orderItem);
    }

    public function prepareOrderNode()
    {
        try {
            FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter] = array(
                'OrderId'                  => array('@value' => $this->getOrderItem()->getNumber()),
                'OrderDate'                => array('@value' => date('y-m-d H:i:s', $this->getOrderItem()->getOrderTime()->getTimestamp())),
                'CustomerId'               => array('@value' => $this->getOrderItem()->getCustomer()->getNumber()),
                'IsoCurrencyCode'          => array('@value' => $this->getOrderItem()->getCurrency()),
                'TotalAmountProducts'      => array(
                    '@value' => $this->calculate(array(
                            'operator' => '-',
                            'number1'  => $this->getOrderItem()->getInvoiceAmount(),
                            'number2'  => $this->getOrderItem()->getInvoiceShipping()
                        ))
                ),
                'TotalAmountProductsNetto' => array(
                    '@value' => $this->calculate(array(
                            'operator' => '-',
                            'number1'  => $this->getOrderItem()->getInvoiceAmountNet(),
                            'number2'  => $this->getOrderItem()->getInvoiceShippingNet()
                        ))
                ),
                'TotalAmount'              => array('@value' => $this->getOrderItem()->getInvoiceAmount()),
                'Comment'                  => array('@cdata' => $this->getOrderItem()->getComment())
            );

            $this->preparePaymentCostNode();

            FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['PaymentMethod'] = array('@value' => $this->preparePaymentMethod());

            $this->preparePaymentMethodValuesNode();

            FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['ShippingCost'] = array(
                '@value' => Helper::toFloat($this->getOrderItem()->getInvoiceShipping())
            );

            $this->prepareDispatchNode();
            $this->prepareOrderAddInfoNode();

            $commentField = ConfigManager::getInstance()->getCommentField();

            FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['Comment'] = array(
                '@value' => $this->getOrderItem()->$commentField()
            );

            if (ConfigManager::getInstance()->getCostChangingAsCoupon() === false) {
                $this->prepareCostsChangingsNode();
            }

            $this->prepareCouponsNode();
            $this->prepareOrderPartiesNode('billing');
            $this->prepareOrderPartiesNode('shipping');

            (new OrdersLines($this->getOrderItem()))->prepareOrderLines();

        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    /**
     * @param $kindOfParty
     */
    private function prepareOrderPartiesNode($kindOfParty)
    {
        $partiesInformation = array();

        switch ($kindOfParty) {
            case self::KIND_OF_ORDER_PARTY_BILLING:
                /** @var \Shopware\Models\Order\Billing $partiesInformation */
                $partiesInformation                                                                       = $this->loadModelByCondition('Shopware\Models\Order\Billing', array(
                        'orderId' => $this->getOrderItem()->getId()
                    ));
                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['BillingParty'] = array();
                break;

            case self::KIND_OF_ORDER_PARTY_SHIPPING:
                /** @var \Shopware\Models\Order\Shipping $partiesInformation */
                $partiesInformation                                                                        = $this->loadModelByCondition('Shopware\Models\Order\Shipping', array(
                        'orderId' => $this->getOrderItem()->getId()
                    ));
                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['DeliveryParty'] = array();
                break;

            default:
                break;

        }

        if ($kindOfParty === self::KIND_OF_ORDER_PARTY_BILLING) {
            $this->setOrdersPartiesEmailAddress($partiesInformation->getCustomer()->getEmail());
            $this->setOrdersPartiesVatId($partiesInformation->getVatId());
            $this->setOrdersPartiesPhoneNumber($partiesInformation->getPhone());
        }

        if ($partiesInformation !== null) {
            try {
                $country = '';

                if (is_object($partiesInformation->getCountry()) === true && method_exists($partiesInformation->getCountry(), 'getName') === true) {
                    $country = $partiesInformation->getCountry()->getName();
                }

                $partyType = ($kindOfParty === self::KIND_OF_ORDER_PARTY_BILLING) ? 'BillingParty' : 'DeliveryParty';

                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter][$partyType] = array(
                    'Title'        => array('@cdata' => $this->convertSalutation($partiesInformation->getSalutation())),
                    'Company'      => array('@cdata' => $partiesInformation->getCompany()),
                    'CompanyAdd'   => array('@cdata' => $partiesInformation->getDepartment()),
                    'FirstName'    => array('@cdata' => $partiesInformation->getFirstName()),
                    'LastName'     => array('@cdata' => $partiesInformation->getLastName()),
                    'Address'      => array('@cdata' => $partiesInformation->getStreet()),
                    'Number'       => array('@cdata' => ''),
                    'AddressAdd'   => array('@cdata' => $partiesInformation->getAdditionalAddressLine1() . ' ' . $partiesInformation->getAdditionalAddressLine2()),
                    'PostalCode'   => array('@cdata' => $partiesInformation->getZipCode()),
                    'City'         => array('@cdata' => $partiesInformation->getCity()),
                    'Country'      => array('@cdata' => $country),
                    'EmailAddress' => array('@cdata' => $this->getOrdersPartiesEmailAddress()),
                    'VatId'        => array('@cdata' => $this->getOrdersPartiesVatId()),
                    'PhonePrivate' => array('@cdata' => $this->getOrdersPartiesPhoneNumber())
                );

                try {
                    if (is_object($partiesInformation->getState()) === true && strlen($partiesInformation->getState()->getShortCode()) > 0) {
                        FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter][$partyType]['State'] = array(
                            '@cdata' => $partiesInformation->getState()->getShortCode()
                        );
                    }
                } catch (\Exception $e) {
                }

                if ($partiesInformation->getCustomer() !== null) {
                    if (is_object($partiesInformation->getCustomer()->getBirthday()) === true) {
                        FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter][$partyType]['DateOfBirth'] = array(
                            '@cdata' => date('Y-m-d', $partiesInformation->getCustomer()->getBirthday()->getTimestamp())
                        );
                    }
                }

                if ($kindOfParty === self::KIND_OF_ORDER_PARTY_SHIPPING) {
                    $thirdPartiesPluginsInformation = new ThirdPartiesPluginsInformation($this->getOrderItem(), array(self::SWAG_DHL_PLUGIN_NAME));
                    $ordersInformation              = $thirdPartiesPluginsInformation->getThirdPartiesInformation();

                    if (count($ordersInformation) > 0) {
                        if (array_key_exists(self::SWAG_DHL_PLUGIN_NAME, $ordersInformation) === true) {
                            FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter][$partyType]['AddressAdd'] = array(
                                '@cdata' => FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter][$partyType]['AddressAdd'] . '<br />' .
                                            $ordersInformation[self::SWAG_DHL_PLUGIN_NAME]['AddressAdd']
                            );
                        }
                    }
                }
            } catch (Exception $e) {
                echo '<pre>';
                print_r($e->getTraceAsString());
                echo '</pre>';
            }
        }
    }

    /**
     * @return void
     */
    private function prepareCouponsNode()
    {
        $extendsSql = ' and modus = 2';

        if (Helper::assertRequiredPluginsPresent('SwagBundle') === true) {
            if (ConfigManager::getInstance()->getCostChangingAsCoupon() === true) {
                $extendsSql = ' and (modus = 2 or modus = 10 or modus = 3 or modus = 4)';
            } else {
                $extendsSql = ' and (modus = 2 or modus = 10)';
            }
        } elseif (ConfigManager::getInstance()->getCostChangingAsCoupon() === true) {
            $extendsSql = ' and (modus = 2 or modus = 3 or modus = 4)';
        }

        $sql = 'select id from s_order_details where orderID = ?' . $extendsSql;

        $result = Shopware()->Db()->fetchOne($sql, array($this->getOrderItem()->getId()));

        if ($result !== false) {
            $count = 0;

            foreach ($this->getCoupons() as $detail) {
                (new Voucher($this->getOrderItem(), $detail))->prepareCouponsItem($count);
                ++$count;
            }
        }
    }

    /**
     * @return void
     */
    private function prepareCostsChangingsNode()
    {
        $type      = 0;
        $typeValue = 0;
        $count     = 0;

        $result = Shopware()->Db()->fetchOne("select id from s_order_details where orderID = ? and (modus = 4 or modus = 3)", array($this->getOrderItem()->getId()));

        if ($result !== false) {

            FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['CostsChangings'] = array();

            /** @var \Shopware\Models\Order\Detail $detail */
            foreach ($this->getCostsChangings() as $detail) {
                if ($detail->getMode() === 4) {

                    $articleNumberSuffix = '';
                    $articleNumberLower  = strtolower($detail->getArticleNumber());
                    $type                = '1';

                    if (substr($articleNumberLower, -8) === 'absolute') {
                        $articleNumberSuffix = 'absolute';
                        $type                = '0';
                    } elseif (
                        substr($articleNumberLower, -9) === 'surcharge' ||
                        in_array((string)$detail->getArticleNumber(), ConfigManager::getInstance()->getSurchargeCodes()) === true
                    ) {
                        $articleNumberSuffix = 'surcharge';
                        $type                = '0';
                    }

                    if ($type == '0') {
                        if($articleNumberSuffix == 'surcharge') {
                            $typeValue = $detail->getPrice();
                        } else {
                            $typeValue = $this->getOrderItem()->getPayment()->getSurcharge();
                        }
                    } else {
                        $typeValue = $this->getOrderItem()->getPayment()->getDebitPercent();
                    }
                } elseif ($detail->getMode() === 3) {
                    $type      = 0;
                    $typeValue = 0;
                }

                if($type == 1 && (int)$typeValue === 0)
                {
                    // in this case we probably determined wrongfully that it was a relative reduction and we change the type to absolute
                    $type = 0;
                }

                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['CostsChangings']['CostsChanging-' . $count] = array(
                    'Type'      => array('@value' => $type),
                    'TypeValue' => array('@value' => $typeValue),
                    'Value'     => array('@value' => $detail->getPrice())
                );
                ++$count;
            }
        }
    }

    /**
     * @return void
     */
    private function prepareOrderAddInfoNode()
    {
        $repository                 = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingOrderAttributes');
        $mappingOrderAttributesList = $repository->findAll();

        if (count($mappingOrderAttributesList) > 0) {
            $ordersAttributesModel = $this->getOrderItem()->getAttribute();

            FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['OrderAddInfos'] = array(
                '@attributes' => array(
                    'count' => count($mappingOrderAttributesList)
                )
            );

            if ($ordersAttributesModel !== null) {
                $count = 1;

                /** @var \Shopware\CustomModels\BfSaleschannel\MappingOrderAttributes $mappingOrderAttributes */
                foreach ($mappingOrderAttributesList as $mappingOrderAttributes) {
                    $getter = ucwords($mappingOrderAttributes->getShopwareColumnName(), '_');
                    $getter = 'get' . ucfirst($getter);
                    $getter = str_replace('_', '', $getter);

                    try {
                        $value = '';

                        if (method_exists($ordersAttributesModel, $getter) === true) {
                            $value = $ordersAttributesModel->$getter();
                        }

                        FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['OrderAddInfos']['OrderAddInfo-' . $count] = array(
                            '@attributes' => array('num' => $count),
                            'Key'         => array('@value' => $mappingOrderAttributes->getBrickfoxExportName()),
                            'Value'       => array('@cdata' => $value)
                        );
                    } catch (Exception $e) {
                        echo '<pre>';
                        print_r($e->getMessage());
                        echo '</pre>';
                    }

                    ++$count;
                }
            }
        }
    }

    /**
     * @throws Exception
     */
    private function prepareDispatchNode()
    {
        $dispatchId = Shopware()->Db()->fetchOne("select dispatchID from s_order where id = ?", array($this->getOrderItem()->getId()));

        $dispatchRepository = Shopware()->Models()->getRepository('Shopware\Models\Dispatch\Dispatch');
        $dispatchModel      = $dispatchRepository->findOneBy(array('id' => $dispatchId));

        if ($dispatchModel !== null) {
            if (is_object($this->getOrderItem()->getDispatch()) && strlen($this->getOrderItem()->getDispatch()->getName()) > 0) {
                FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['ShippingMethod'] = array(
                    '@value' => $this->getOrderItem()->getDispatch()->getName()
                );
            } else {
                throw new Exception('Cannot find Carrier for Order #' . $this->getOrderItem()->getNumber() . '. Skip Order!');
            }
        } else {
            throw new Exception('Cannot find Carrier for Order #' . $this->getOrderItem()->getNumber() . '. Skip Order!');
        }
    }

    /**
     * @return string
     * @throws Exception
     */
    private function preparePaymentMethod()
    {
        $paymentName       = '';
        $paymentId         = Shopware()->Db()->fetchOne("select paymentID from s_order where id = ?", array($this->getOrderItem()->getId()));
        $paymentRepository = Shopware()->Models()->getRepository('Shopware\Models\Payment\Payment');
        $paymentModel      = $paymentRepository->findOneBy(array('id' => $paymentId));

        if ($paymentModel !== null) {
            if (is_object($this->getOrderItem()->getPayment()) && strlen($this->getOrderItem()->getPayment()->getName()) > 0) {
                $paymentName = $this->getOrderItem()->getPayment()->getName();
            }
        } else {
            throw new Exception("Can not find payment method for Order # {$this->getOrderItem()->getNumber()}. Skip Order!");
        }

        return $paymentName;
    }

    /**
     * @return void
     */
    private function preparePaymentMethodValuesNode()
    {
        FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['PaymentMethodValues'] = array();

        $paymentMethodClass = new PaymentMethodValues($this->getOrderItem());
        $paymentMethodClass->preparePaymentMethodValues();
    }

    /**
     * @return void
     */
    public function preparePaymentCostNode()
    {
        /** @var \Shopware\Models\Order\Detail $detail */
        $paymentCost = 0.0;

        foreach ($this->getOrderItem()->getDetails() as $detail) {
            // sum up all surcharges (e.g. payment and shipping)
            if ($detail->getMode() === 4 && $detail->getPrice() > 0) {
                $paymentCost += $detail->getPrice();
            }
        }

        if($paymentCost > 0.0) {
            FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['PaymentCost'] = array('@value' => $paymentCost);
        }
    }

    /**
     * @return \array
     */
    private function getCoupons()
    {
        $coupons     = array();
        $couponModes = array(2, 10);

        if (Helper::assertRequiredPluginsPresent('SwagBundle') === true) {
            if (ConfigManager::getInstance()->getCostChangingAsCoupon() === true) {
                $couponModes = array(2, 10, 3, 4);
            }
        } elseif (ConfigManager::getInstance()->getCostChangingAsCoupon() === true) {
            $couponModes = array(2, 3, 4);
        }

        foreach ($this->getOrderItem()->getDetails() as $detail) {
            if (in_array($detail->getMode(), $couponModes)) {
                $coupons[] = $detail;
            }
        }

        return $coupons;
    }

    /**
     * @return \array
     */
    private function getCostsChangings()
    {
        $costChanings = array();

        /** @var \Shopware\Models\Order\Detail $detail */
        foreach ($this->getOrderItem()->getDetails() as $detail) {
            if ($detail->getMode() === 4 || $detail->getMode() === 3) {
                $costChanings[] = $detail;
            }
        }

        return $costChanings;
    }

    /**
     * @param $salutation
     *
     * @return string
     */
    private function convertSalutation($salutation)
    {
        switch ($salutation) {
            case 'mr':
                $title = self::SALUTATION_MR;
                break;

            case 'ms':
                $title = self::SALUTATION_MS;
                break;

            default:
                $title = self::SALUTATION_UNDEFINED;
                break;
        }

        return $title;
    }

    public function __destruct()
    {
        // TODO: Implement __destruct() method.
    }
}