<?php
namespace Bf\Saleschannel\Components\Resources\Orders\Plugins\SwagDhl;

use Exception;
use Shopware\Models\Order\Order;

/**
 * SwagDhl
 *
 * @package Bf\Saleschannel\Components\Resources\Orders\Plugins\SwagDhl
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class SwagDhl
{
    const SWAG_DHL_PLUGIN_ATTRIBUTE_COLUMN_NAME = 'swag_dhl_address';

    /** @var null|Order */
    private $orderItem = null;

    /**
     * SwagDhl constructor.
     *
     * @param Order $orderItem
     */
    public function __construct(Order $orderItem)
    {
        $this->orderItem = $orderItem;
    }

    /**
     * @return array
     */
    public function prepareThirdPartiesOrdersInformation()
    {
        $ordersInformation = array();

        try
        {
            $ordersAttributeGetter = ucwords(self::SWAG_DHL_PLUGIN_ATTRIBUTE_COLUMN_NAME, '_');
            $ordersAttributeGetter = 'get' . ucfirst($ordersAttributeGetter);
            $ordersAttributeGetter = str_replace('_', '', $ordersAttributeGetter);

            if(is_object($this->getOrderItem()) === true && method_exists($this->getOrderItem()->getAttribute(), $ordersAttributeGetter) === true)
            {
                $dhlInfoObj = unserialize($this->getOrderItem()->getAttribute()->$ordersAttributeGetter());

                if(is_object($dhlInfoObj) === true)
                {
                    $dhlInfo = get_object_vars($dhlInfoObj);

                    if(array_key_exists('postNumber', $dhlInfo) === true)
                    {
                        $ordersInformation['AddressAdd'] = $dhlInfo['postNumber'];
                    }
                }
            }
        }
        catch(Exception $e)
        {
            echo '<pre>';
            print_r($e->getTraceAsString());
            echo '</pre>';
        }

        return $ordersInformation;
    }

    /**
     * @return null|Order
     */
    public function getOrderItem()
    {
        return $this->orderItem;
    }

    public function __destruct()
    {
        $this->orderItem = null;
    }
}
