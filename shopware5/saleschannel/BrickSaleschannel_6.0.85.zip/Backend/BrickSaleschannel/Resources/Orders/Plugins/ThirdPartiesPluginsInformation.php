<?php

namespace Bf\Saleschannel\Components\Resources\Orders\Plugins;

use Bf\Saleschannel\Components\Resources\Orders\Plugins\SwagDhl\SwagDhl;
use Bf\Saleschannel\Components\Util\Helper;
use Shopware\Models\Order\Order;

/**
 * ThirdPartiesPluginsInformation
 *
 * @package Bf\Saleschannel\Components\Resources\Orders\Plugins
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class ThirdPartiesPluginsInformation
{
    /** @var array */
    private $pluginNames = array();

    /** @var null|Order */
    private $orderItem = null;

    /**
     * ThirdPartyPluginsInformation constructor.
     *
     * @param Order $orderItem
     * @param array $neededOrdersInformationByPlugins
     */
    public function __construct(Order $orderItem, array $neededOrdersInformationByPlugins = array())
    {
        $this->pluginNames = $neededOrdersInformationByPlugins;
        $this->orderItem   = $orderItem;
    }

    /**
     * @return array
     */
    public function getThirdPartiesInformation()
    {
        $ordersInformation = array();

        foreach($this->pluginNames as $pluginName)
        {
            if(Helper::assertRequiredPluginsPresent($pluginName) === true)
            {
                $className = '\Bf\Saleschannel\Components\Resources\Orders\Plugins' . '\\' . $pluginName . '\\' . $pluginName;

                /** @var SwagDhl $thirdPartiesPluginClass */
                $thirdPartiesPluginClass        = new $className($this->getOrderItem());
                $ordersInformation[$pluginName] = $thirdPartiesPluginClass->prepareThirdPartiesOrdersInformation();
            }
        }

        return $ordersInformation;
    }

    /**
     * @return null|Order
     */
    public function getOrderItem()
    {
        return $this->orderItem;
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        $this->orderItem = null;
    }
}
