<?php
/**
 * NetIEasyCoupon.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Orders\Plugins;

use Bf\Saleschannel\Components\Resources\Orders\Voucher\VoucherAbstract;
use Bf\Saleschannel\Components\Util\FileWriter;
use Shopware\Models\Order\Detail as SwOrderDetail;
use Shopware\Models\Order\Order as SwOrder;

class NetIEasyCoupon extends VoucherAbstract
{
    const REDUCE_TYPE = 'ABSOLUTE';

    /**
     * @param SwOrder $order
     * @param SwOrderDetail $detail
     */
    public function __construct(SwOrder $order, SwOrderDetail $detail)
    {
        parent::__construct($order, $detail);
    }

    public function prepareCoupon($count, $voucherDescription)
    {
        FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter]['Coupons']['Coupon-' . $count] = array(
            'ExternId'         => array('@value' => $this->getDetail()->getArticleId()),
            'Code'             => array('@value' => self::DEFAULT_VOUCHER_CODE),
            'Type'             => array('@value' => self::VOUCHER_TYPE_CAMPAIGN),
            'ReduceType'       => array('@value' => self::REDUCE_TYPE),
            'Rebate'           => array('@value' => $this->getDetail()->getPrice() * -1.0),
            'Title'            => array('@cdata' => $voucherDescription),
            'CalculatedRebate' => array('@value' => $this->getDetail()->getPrice() * -1.0)
        );
    }
}