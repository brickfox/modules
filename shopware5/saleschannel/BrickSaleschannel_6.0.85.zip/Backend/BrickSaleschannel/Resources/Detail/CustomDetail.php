<?php
namespace Bf\Saleschannel\Components\Resources\Detail;

use Bf\Saleschannel\Components\Resources\Article\CustomAbstract;
use SimpleXMLElement;
use Shopware\Models\Article\Detail as SwDetail;
use Shopware\Models\Article\Article as SwArticle;

/**
 * CustomDetail
 *
 * @package Bf\Saleschannel\Components\Resources\Detail
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class CustomDetail extends CustomAbstract
{
    private $classMethods = array(
        //insert ur custom methods here like:
        'customMethodName'
    );

    /**
     * @param SwArticle $article
     * @param SwDetail $detail
     * @param SimpleXMLElement $variationXmlElement
     */
    public function __construct(SwArticle $article, SimpleXMLElement $variationXmlElement, SwDetail $detail)
    {
        parent::__construct($article, $variationXmlElement, $detail);
    }

    public function prepareCustomItem()
    {
        foreach($this->classMethods as $methodName)
        {
            if($methodName !== 'customMethodName')
            {
                if(method_exists($this, $methodName) === true)
                {
                    $this->$methodName();
                }
            }
        }
    }
}
