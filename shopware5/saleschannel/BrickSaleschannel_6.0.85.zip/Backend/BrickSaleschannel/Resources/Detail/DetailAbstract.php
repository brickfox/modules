<?php
namespace Bf\Saleschannel\Components\Resources\Detail;

use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\Helper;
use Doctrine\Common\Collections\ArrayCollection;
use Shopware\CustomModels\BfSaleschannel\ApiImportPriceHash;
use Shopware\CustomModels\BfSaleschannel\MappingDetails;
use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract;
use Shopware\Models\Article\Detail as SwDetail;
use Shopware\Models\Article\Article as SwArticle;
use SimpleXMLElement;

/**
 * DetailAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Detail
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class DetailAbstract extends ArticleAbstract
{
    const CONTENT_UNIT_ML = 'ml';
    const CONTENT_UNIT_L  = 'l';
    const CONTENT_UNIT_G  = 'g';
    const CONTENT_UNIT_KG = 'kg';
    const PACKAGE_ELEMENT_WEIGHT = 'Weight';

    /** @var int */
    private $hasVariations = 0;

    /** @var int */
    private $hasVariationsSwCounter = 1;

    /** @var string */
    private $productsItemNumber = '';

    /** @var bool */
    private $isMain = false;

    private $detailCollection;

    private $variationXmlElement;

    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param SwArticle $article
     * @param null $detail
     */
    abstract public function __construct(SimpleXMLElement $simpleXMLElement, SwArticle $article, $detail = null);

    /**
     * @return void
     */
    public function __destruct()
    {
        unset($this->detailCollection);
        parent::__destruct();
    }

    /**
     * @return SwDetail
     */
    protected function loadDetail()
    {
        $repository   = Helper::getRepository(ArticleAbstract::MAPPING_NAMESPACE_MODEL_DETAIL);
        $mappingModel = $repository->findOneBy(array('brickfoxId' => (int) $this->getVariationXmlElement()->VariationId));

        if($mappingModel === null)
        {
            $detail = new SwDetail();
            $detail->setArticle($this->getArticle());

            $mappingModel = new MappingDetails();
            $mappingModel->setBrickfoxId((int) $this->getVariationXmlElement()->VariationId);
            $mappingModel->setDetail($detail);

            Shopware()->Models()->persist($mappingModel);
        }
        else
        {
            $detail = $mappingModel->getDetail();
        }

        return $detail;
    }

    /**
     * @param $xmlElementNode
     *
     * @return float|int
     */
    protected function getPackageElement($xmlElementNode)
    {
        $element = 0;

        if((bool) $this->getVariationXmlElement()->Package->$xmlElementNode === true && $xmlElementNode === self::PACKAGE_ELEMENT_WEIGHT)
        {
            $element = (float) $this->getVariationXmlElement()->Package->$xmlElementNode / 1000;
        } elseif ((bool) $this->getVariationXmlElement()->Package->$xmlElementNode === true) {
            $element = (float) $this->getVariationXmlElement()->Package->$xmlElementNode;
        }

        return $element;
    }

    /**
     * @param $xmlElementNode
     *
     * @return float|int
     */
    protected function getArticleMeasurement($xmlElementNode)
    {
        $packageOrMeasurementNode = ConfigManager::getInstance()->getPackageOrMeasurementsNode();

        $articleMeasurement = 0;

        if ((bool) $this->getVariationXmlElement()->$packageOrMeasurementNode->$xmlElementNode === true && $xmlElementNode === self::PACKAGE_ELEMENT_WEIGHT) {
            $articleMeasurement = (float) $this->getVariationXmlElement()->$packageOrMeasurementNode->$xmlElementNode / 1000;
        } elseif ((bool) $this->getVariationXmlElement()->$packageOrMeasurementNode->$xmlElementNode === true) {
            $articleMeasurement = (float) $this->getVariationXmlElement()->$packageOrMeasurementNode->$xmlElementNode /10;
        }

        return $articleMeasurement;
    }

    /**
     * @return bool
     */
    public function getHasVariations()
    {
        return $this->hasVariations;
    }

    /**
     * @param int $hasVariations
     *
     * @return $this
     */
    public function setHasVariations($hasVariations)
    {
        $this->hasVariations = $hasVariations;

        return $this;
    }

    /**
     * @return int
     */
    public function getHasVariationsSwCounter()
    {
        return $this->hasVariationsSwCounter;
    }

    /**
     * @param int $hasVariationsSwCounter
     *
     * @return $this
     */
    public function setHasVariationsSwCounter($hasVariationsSwCounter)
    {
        $this->hasVariationsSwCounter = $this->hasVariationsSwCounter + (int) $hasVariationsSwCounter;

        return $this;
    }

    /**
     * @return string
     */
    public function getProductsItemNumber()
    {
        return $this->productsItemNumber;
    }

    /**
     * @param string $productsItemNumber
     *
     * @return $this
     */
    public function setProductsItemNumber($productsItemNumber)
    {
        $this->productsItemNumber = $productsItemNumber;

        return $this;
    }

    /**
     * @return boolean
     */
    public function getIsMain()
    {
        return $this->isMain;
    }

    /**
     * @param boolean $isMain
     *
     * @return $this
     */
    public function setIsMain($isMain)
    {
        $this->isMain = $isMain;

        return $this;
    }

    /**
     * @return ArrayCollection
     */
    public function getDetailCollection()
    {
        return $this->detailCollection;
    }

    /**
     * @param mixed $detailCollection
     *
     * @return DetailAbstract
     */
    public function setDetailCollection($detailCollection)
    {
        $this->detailCollection = $detailCollection;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getVariationXmlElement()
    {
        return $this->variationXmlElement;
    }

    /**
     * @param mixed $variationXmlElement
     *
     * @return DetailAbstract
     */
    public function setVariationXmlElement($variationXmlElement)
    {
        $this->variationXmlElement = $variationXmlElement;

        return $this;
    }

    /**
     * @return bool
     */
    protected function checkHash()
    {
        $checkSumEqual = false;
        $hashModel     = $this->loadHashByVariationsId();

        if($hashModel !== null)
        {
            $hashValue = $this->generateHashValue();

            if($hashValue && $hashValue === $hashModel->getHash())
            {
                $checkSumEqual = true;
            }
        }

        return $checkSumEqual;
    }

    /**
     * @return void
     */
    protected function generateHash()
    {
        $hashModel = $this->loadHashByVariationsId();

        if($hashModel === null)
        {
            $hashModel = new ApiImportPriceHash();
            $hashModel->setBrickfoxId((int) $this->getVariationXmlElement()->VariationId);
            $hashModel->setHash($this->generateHashValue());
            $hashModel->setDateInsert(new \DateTime());
            $hashModel->setLastUpdate(new \DateTime());
        }
        else
        {
            $hashModel->setHash($this->generateHashValue());
            $hashModel->setLastUpdate(new \DateTime());
        }

        Shopware()->Models()->persist($hashModel);
    }

    /**
     * @return null|string
     */
    private function generateHashValue()
    {
        $taxRate = $this->getVariationXmlElement()->TaxRate ? $this->getVariationXmlElement()->TaxRate->asXML() : '';

        if((bool) $this->getVariationXmlElement()->Currencies === false) {
            $priceGross        = ((bool) $this->getVariationXmlElement()->PriceGross === true) ? $this->getVariationXmlElement()->PriceGross->asXml() : '';
            $rrp               = ((bool) $this->getVariationXmlElement()->Rrp === true) ? $this->getVariationXmlElement()->Rrp->asXml() : '';
            $specialPrice      = ((bool) $this->getVariationXmlElement()->SpecialPrice === true) ? $this->getVariationXmlElement()->SpecialPrice->asXml() : '';
            $scalePrice        = ((bool) $this->getVariationXmlElement()->ScalePrices === true) ? $this->getVariationXmlElement()->ScalePrices->asXml() : '';
            $specialPriceStart = ((bool) $this->getVariationXmlElement()->SpecialPriceStart === true) ? $this->getVariationXmlElement()->SpecialPriceStart->asXml() : '';
            $specialPriceEnd   = ((bool) $this->getVariationXmlElement()->SpecialPriceEnd === true) ? $this->getVariationXmlElement()->SpecialPriceEnd->asXml() : '';
            $primeCost         = ((bool) $this->getVariationXmlElement()->PrimeCost === true) ? $this->getVariationXmlElement()->PrimeCost->asXml() : '';

            $valuesToHash = $priceGross . $rrp . $specialPrice . $scalePrice . $specialPriceStart . $specialPriceEnd . $primeCost;
        } else {
            $valuesToHash = $this->getVariationXmlElement()->Currencies->asXml();
        }

        $valuesToHash .= $taxRate;

        return sha1($valuesToHash);
    }

    /**
     * @return \Shopware\CustomModels\BfSaleschannel\ApiImportPriceHash
     */
    private function loadHashByVariationsId()
    {
        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\ApiImportPriceHash');
        /** @var \Shopware\CustomModels\BfSaleschannel\ApiImportPriceHash $hashModel */
        $hashModel = $repository->findOneBy(array('brickfoxId' => (int) $this->getVariationXmlElement()->VariationId));

        return $hashModel;
    }

    /**
     * @param SimpleXMLElement $variation
     * @param null $article
     *
     * @return int
     */
    protected function getVariationsActiveStatus(SimpleXMLElement $variation, $article = null)
    {
        $articleActive = 1;

        if(is_null($article) === false)
        {
            $articleActive = $article->getActive();
        }

        $variationActive = (int) $variation->VariationActive;

        $status = min($articleActive, $variationActive);

        if((bool) $variation->Available === true && $this->getHasVariations() === 1)
        {
            if($status === 1 && (int) $variation->Available === 0)
            {
                $status = 0;
            }
        }

        return $status;
    }
}
