<?php

namespace Bf\Saleschannel\Components\Resources\Detail;

use Bf\Saleschannel\Components\Resources\Configurator\Configurator as BfConfigurator;
use Bf\Saleschannel\Components\Resources\Configurator\Set;
use Bf\Saleschannel\Components\Resources\Prices\Prices as ResourcePrice;
use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Doctrine\Common\Collections\ArrayCollection;
use Exception;
use Shopware\CustomModels\BfSaleschannel\Log;
use \Shopware\Models\Article\Article as SwArticle;
use SimpleXMLElement;
use Bf\Saleschannel\Components\Resources\Images\Images as BfImage;
use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract as BfArticleAbstract;

/**
 * Detail
 *
 * @package Bf\Saleschannel\Components\Resources\Detail
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Detail extends DetailAbstract
{
    private $bfProductsId = 0;

    const FILE_NAME = 'Detail.php';

    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param SwArticle $article
     * @param null $detail
     */
    public function __construct(SimpleXMLElement $simpleXMLElement, SwArticle $article, $detail = null)
    {
        $this->setSimpleXmlElement($simpleXMLElement);
        $this->setArticle($article);
        $this->setDetailCollection(new ArrayCollection());
        $this->setBfProductsId((int)$this->getSimpleXmlElement()->ProductId);
    }

    /**
     * @return void
     * @throws \Exception
     * @throws \Zend_Db_Adapter_Exception
     */
    public function prepareDetailItem()
    {
        if ((bool)$this->getSimpleXmlElement()->Variations === true) {
            $this->setHasVariations((int)$this->getSimpleXmlElement()->HasVariations);
            $this->setProductsItemNumber((string)$this->getSimpleXmlElement()->ItemNumber);

            if ($this->getHasVariations() === 1) {
                $this->handleVariations();
            } else {
                $this->assignDetailItem($this->getSimpleXmlElement()->Variations[0]->Variation);
                $this->getArticle()->setMainDetail($this->getDetail());
                $this->setArticleDetailsAttributesToArticleDetail($this->getDetail(), $this->getSimpleXmlElement(), $this->getSimpleXmlElement()->Variations[0]->Variation);
            }

            if ($this->getHasVariations() === 1) {
                $configuratorSetModel = null;

                if (is_object($this->getArticle()->getMainDetail()) === true) {
                    $configuratorSetModel = (new Set($this->getArticle()))->prepareConfigurationSetItem();
                }

                if ($configuratorSetModel !== null) {
                    $this->getArticle()->setConfiguratorSet($configuratorSetModel);
                } else {
                    LogManager::getInstance()
                        ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(['{$itemNumber}', '{$productId}'],
                            [(string)$this->getSimpleXmlElement()->ItemNumber, (string)$this->getSimpleXmlElement()->ProductId],
                            ErrorCodes::PRODUCTS_VARIATIONS_CONFIGURATOR_SET), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                            (string)$this->getSimpleXmlElement()->ProductId, ErrorCodes::PRODUCTS_VARIATIONS_CONFIGURATOR_SET_ERROR_CODE);
                }

                BfConfigurator::getInstance()->resetGroupIds();
                BfConfigurator::getInstance()->resetOptionIds();
            }
        } else {
            LogManager::getInstance()
                ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__,
                    str_replace(['{$itemNumber}', '{$productId}'], [(string)$this->getSimpleXmlElement()->ItemNumber, (string)$this->getSimpleXmlElement()->ProductId],
                        ErrorCodes::PRODUCTS_VARIATIONS_CONFIGURATOR_SET_MISSING_NODE), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                    (string)$this->getSimpleXmlElement()->ProductId, ErrorCodes::PRODUCTS_VARIATIONS_CONFIGURATOR_SET_MISSING_NODE_ERROR_CODE);
        }
    }

    /**
     * @return void
     * @throws \Exception
     * @throws \Zend_Db_Adapter_Exception
     */
    private function handleVariations()
    {
        $this->setIsMain(true);
        foreach ($this->getXmlVariations() as $variation) {
            $this->assignDetailItem($variation);
            $this->getDetail()->setKind(2);

            if ((bool)$variation->MainFlag === true) {
                $mainFlag = (int)$variation->MainFlag;

                if ($mainFlag === 1) {
                    $this->getDetail()->setActive(1);
                    $this->setIsMain(true);
                    $this->prepareMainDetailSettings($variation);
                } else {
                    $this->setIsMain(false);
                    $this->prepareMainDetailSettings($variation);
                }
            } else {
                $this->prepareMainDetailSettings($variation);
            }

            if ($this->isElementAvailable($this->getVariationXmlElement(), 'VariationImages') === true && ConfigManager::getInstance()->getIgnoreImageInformation() === false) {
                $this->setImagesToArticle(self::IMPORT_ARTICLE_VARIATION_IMPORT_MODE, $this->getVariationXmlElement(), $this->getDetail(), $this->getBfProductsId());
            } else {
                $bfImage = new BfImage();
                $bfImage->setArticleMode(BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE);
                $bfImage->prepareToDeleteImageList($this->getArticle()->getId(), $this->getDetail());
            }

            (new CustomDetail($this->getArticle(), $this->getVariationXmlElement(), $this->getDetail()))->prepareCustomItem();
        }

        Helper::$mainImageBaseProductsIsSet = false;

        if (count($this->getDetailCollection()) > 0) {
            if (is_object($this->getArticle()->getMainDetail()) === false) {
                $this->getArticle()->setMainDetail($this->getDetailCollection()->first());
                $this->getDetailCollection()->first()->setKind(1);
            } elseif ($this->getArticle()->getMainDetail()->getKind() === 2) {
                $this->getArticle()->getMainDetail()->setKind(1);
            }
            $this->getArticle()->setDetails($this->getDetailCollection());
        }
    }

    /**
     * @param $variation
     * @throws \Zend_Db_Adapter_Exception
     */
    private function prepareMainDetailSettings($variation)
    {
        if ($this->getIsMain() === true && $this->getDetail()->getActive() === 1) {
            $this->getArticle()->setMainDetail($this->getDetail());
            $this->setIsMain(false);
            $this->setArticleDetailsAttributesToArticleDetail($this->getDetail(), $this->getSimpleXmlElement(), $variation);
        } else {
            $this->getDetailCollection()->add($this->getDetail());
            $this->setArticleDetailsAttributesToArticleDetail($this->getDetail(), $this->getSimpleXmlElement(), $variation);
        }
    }

    /**
     * @param $variation
     *
     * @return void
     * @throws \Exception
     */
    private function assignDetailItem($variation)
    {
        $this->setVariationXmlElement($variation);
        $this->setDetail($this->loadDetail());
        $this->prepareDetail();
    }

    /**
     * @return void
     * @throws \Exception
     */
    private function prepareDetail()
    {
        $this->getDetail()->setNumber($this->prepareArticleVariationsOrderNumber((int)$this->getVariationXmlElement()->VariationActive));
        $this->getDetail()->setSupplierNumber($this->prepareArticleVariationsManufacturerItemNumber());
        $this->getDetail()->setActive($this->getVariationsActiveStatus($this->getVariationXmlElement(), $this->getArticle()));
        $this->getDetail()->setInStock(Stock::getInstance()->prepareArticleVariationsStock($this->getVariationXmlElement()));
        $this->getDetail()->setStockMin(Stock::getInstance()->prepareArticleVariationsMinimumStock($this->getVariationXmlElement()));
        $this->getDetail()->setEan($this->prepareArticleVariationsEan());

        if (ConfigManager::getInstance()->getIgnoreDelivery() === 'false' || ConfigManager::getInstance()->getIgnoreDelivery() === '') {
            $this->getDetail()->setShippingTime($this->prepareArticleVariationsDeliveryTime());
        }

        $this->getDetail()->setUnit($this->prepareArticleVariationsContentUnit());
        $this->getDetail()->setPurchaseUnit($this->prepareArticleVariationsPurchaseUnit());
        $this->getDetail()->setReferenceUnit($this->prepareReferenceUnit());
        $this->getDetail()->setWeight($this->getArticleMeasurement('Weight'));
        $this->getDetail()->setWidth($this->getArticleMeasurement('Width'));
        $this->getDetail()->setHeight($this->getArticleMeasurement('Height'));
        $this->getDetail()->setLen($this->getArticleMeasurement('Length'));
        $this->getDetail()->setMinPurchase((int)$this->getMinimumOrderQuantity());
        $this->getDetail()->setMaxPurchase($this->getMaximumOrderQuantity());
        $this->getDetail()->setPackUnit($this->getPackingUnit());
        $this->getDetail()->setPurchaseSteps((int)$this->getDefaultQuantity());
        $this->getDetail()->setReleaseDate($this->getReleaseDateByAttribute());
        $this->getDetail()->setShippingFree($this->getShippingFreeByAttribute());

        if (Helper::versionCompare(Shopware()->Config()->version, '5.4.0', '>=')) {
            $this->getDetail()->setLastStock($this->getArticleVariationsLastStock());
        }

        if ($this->getHasVariations() === 1) {
            $this->getDetail()->setAdditionalText($this->getAdditionalText());
        }

        if (
            (
                $this->checkHash() === false &&
                ConfigManager::getInstance()->getDisableBfPriceUpdates() === false
            ) ||
            $this->getDetail()->getPrices()->isEmpty() === true
        ) {
            $price = new ResourcePrice();
            $this->getDetail()->setPrices($price->preparePrices($this->getVariationXmlElement(), $this->getDetail(), $this->getArticle()));
            $this->generateHash();
        }
    }

    /**
     * @return |null
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    private function getReleaseDateByAttribute()
    {
        $releaseDate = null;

        if (strlen(ConfigManager::getInstance()->isReleaseDateFromAttribute() === true)) {
            if ((bool)$this->getVariationXmlElement()->Attributes === true) {
                foreach ($this->getVariationXmlElement()->Attributes as $attributes) {
                    foreach ($attributes as $type => $attribute) {
                        if (in_array((string)$attribute->Translations->Translation['lang'], Helper::getMainLanguagesCode()) === true) {
                            if ((string)$attribute['code'] !== ConfigManager::getInstance()->getReleaseDateFromAttribute()->getConfigurationValue()) {
                                continue;
                            } else {
                                $attributesInformation = Helper::getPropertyNameByAttributesType($attribute, $type);
                                if (strlen($attributesInformation['value']) > 0) {
                                    $releaseDate = $attributesInformation['value'];
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            // fallback to product attributes, if variations attributes had no value
            if ($releaseDate=== null && (bool)$this->getSimpleXmlElement()->Attributes === true) {
                foreach ($this->getSimpleXmlElement()->Attributes as $attributes) {
                    foreach ($attributes as $type => $attribute) {
                        if (in_array((string)$attribute->Translations->Translation['lang'], Helper::getMainLanguagesCode()) === true) {
                            if ((string)$attribute['code'] !== ConfigManager::getInstance()->getReleaseDateFromAttribute()->getConfigurationValue()) {
                                continue;
                            } else {
                                $attributesInformation = Helper::getPropertyNameByAttributesType($attribute, $type);
                                if (strlen($attributesInformation['value']) > 0) {
                                    $releaseDate = $attributesInformation['value'];
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        return $releaseDate;
    }

    /**
     * @return string|null
     */
    private function getShippingFreeByAttribute()
    {
        $shippingFree = 0;

        $shippingFreeAttributesCode = ConfigManager::getInstance()->getShippingFreeFromAttribute()->getConfigurationValue();

        if (strlen(ConfigManager::getInstance()->isShippingFreeFromAttribute() === true)) {
            if ((bool)$this->getSimpleXmlElement()->Attributes === true) {
                foreach ($this->getSimpleXmlElement()->Attributes as $attributes) {
                    foreach ($attributes as $type => $attribute) {
                        if (in_array((string)$attribute->Translations->Translation['lang'], Helper::getMainLanguagesCode()) === true) {
                            if ((string)$attribute['code'] !== $shippingFreeAttributesCode) {
                                continue;
                            } else {
                                $attributesInformation = Helper::getPropertyNameByAttributesType($attribute, $type);
                                if (strlen($attributesInformation['value']) > 0) {
                                    $shippingFree = (int)$attributesInformation['value'];
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        return $shippingFree;
    }

    /**
     * @return int
     */
    private function getArticleVariationsLastStock()
    {
        $neverOutOfStock = 1;

        if ((int)$this->getVariationXmlElement()->NeverOutOfStock === 0) {
            $neverOutOfStock = 1;
        } elseif ((int)$this->getVariationXmlElement()->NeverOutOfStock === 1) {
            $neverOutOfStock = 0;
        }

        if ((int)$this->getVariationXmlElement()->ThirdPartyStock > 0) {
            $neverOutOfStock = 0;
        }

        return $neverOutOfStock;
    }

    /**
     * @return array
     */
    private function getXmlVariations()
    {
        $xmlVariations = [];

        foreach ($this->getSimpleXmlElement()->Variations->Variation as $variation) {
            $xmlVariations[] = $variation;
        }

        return $xmlVariations;
    }

    /**
     * @return string
     * @throws Exception
     */
    private function getAdditionalText()
    {
        BfConfigurator::getInstance()->setAdditionalText('');

        $additionalText = BfConfigurator::getInstance()->prepareConfiguratorItem($this->getVariationXmlElement(), $this->getDetail(), (string)$this->getSimpleXmlElement()->ProductId);

        if (strlen($additionalText) < 1) {
            LogManager::getInstance()
                ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(['{$variationId}', '{$orderNumber}'],
                    [(string)$this->getVariationXmlElement()->VariationId, (string)$this->getSimpleXmlElement()->ItemNumber], ErrorCodes::VARIATION_ADDITIONAL_TEXT),
                    Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId, ErrorCodes::VARIATION_ADDITIONAL_TEXT_ERROR_CODE);
        }

        return $additionalText;
    }

    /**
     * @return null|object|\Shopware\Models\Article\Unit
     */
    private function prepareArticleVariationsContentUnit()
    {
        $unitModel = null;

        if ((bool)$this->getVariationXmlElement()->Descriptions === true) {
            if ((bool)$this->getVariationXmlElement()->Descriptions->Description[0] === true) {
                if (
                    (bool)$this->getVariationXmlElement()->Descriptions->Description[0]->BasePriceUnit === true &&
                    (bool)$this->getVariationXmlElement()->Descriptions->Description[0]->ContentUnit === true
                ) {
                    $contentUnit = (string)$this->getVariationXmlElement()->Descriptions->Description->ContentUnit;

                    if ($contentUnit === self::CONTENT_UNIT_ML && (float)$this->getVariationXmlElement()->ContentQuantity > 250) {
                        $contentUnit = self::CONTENT_UNIT_L;
                    } elseif ($contentUnit === self::CONTENT_UNIT_G && (float)$this->getVariationXmlElement()->ContentQuantity > 250) {
                        $contentUnit = self::CONTENT_UNIT_KG;
                    }

                    $repository = Helper::getRepository('Shopware\Models\Article\Unit');
                    $unitModel  = $repository->findOneBy(['name' => $contentUnit]);

                    if ($unitModel === null) {
                        $unitModel = $repository->findOneBy(['unit' => $contentUnit]);
                    }
                }
            }
        }

        return $unitModel;
    }

    /**
     * @return int
     */
    private function prepareReferenceUnit()
    {
        $referenceUnit = null;

        if ((bool)$this->getVariationXmlElement()->Descriptions === true && (bool)$this->getVariationXmlElement()->Descriptions->Description[0] === true) {
            if ((bool)$this->getVariationXmlElement()->Descriptions->Description[0]->ContentUnit === true) {
                $contentUnit = (string)$this->getVariationXmlElement()->Descriptions->Description[0]->ContentUnit;

                if((bool)$this->getVariationXmlElement()->BasePriceQuantity === true) {
                    $referenceUnit = (float)$this->getVariationXmlElement()->BasePriceQuantity;
                }

                if(strlen($referenceUnit) <= 0) {
                    if (($contentUnit === self::CONTENT_UNIT_ML || $contentUnit === self::CONTENT_UNIT_G) && (float)$this->getVariationXmlElement()->ContentQuantity <= 250) {
                        $referenceUnit = 100;
                    } else {
                        $referenceUnit = 1;
                    }
                }
            }
        }

        return $referenceUnit;
    }

    /**
     * @return float|int|string
     */
    private function prepareArticleVariationsPurchaseUnit()
    {
        $contentQuantity = null;

        if ((bool)$this->getVariationXmlElement()->Descriptions === true && (bool)$this->getVariationXmlElement()->ContentQuantity === true) {
            if (
                (bool)$this->getVariationXmlElement()->Descriptions->Description[0] === true &&
                (bool)$this->getVariationXmlElement()->Descriptions->Description[0]->ContentUnit === true
            ) {
                $contentUnit     = (string)$this->getVariationXmlElement()->Descriptions->Description[0]->ContentUnit;
                $contentQuantity = (float)$this->getVariationXmlElement()->ContentQuantity;

                if (($contentUnit === self::CONTENT_UNIT_ML || $contentUnit === self::CONTENT_UNIT_G) && $contentQuantity > 250) {
                    $contentQuantity = round(($contentQuantity / 1000), 3);
                }
            }
        }

        return $contentQuantity;
    }

    /**
     * @return null|string
     */
    private function prepareArticleVariationsEan()
    {
        $ean = null;

        if ((bool)$this->getVariationXmlElement()->EAN === true) {
            if (strlen((string)$this->getVariationXmlElement()->EAN) > 0) {
                $ean = (string)$this->getVariationXmlElement()->EAN;
            }
        }

        return $ean;
    }

    /**
     * @return int|string
     * @throws Exception
     */
    private function prepareArticleVariationsDeliveryTime()
    {
        $shippingTime = null;

        if ((bool)$this->getVariationXmlElement()->DeliveryTime === true) {
            if (strlen((string)$this->getVariationXmlElement()->DeliveryTime) > 0 && strlen((string)$this->getVariationXmlElement()->DeliveryTime) <= 11) {
                $shippingTime = (string)$this->getVariationXmlElement()->DeliveryTime;
            }
        }

        return $shippingTime;
    }

    /**
     * @return string
     */
    private function prepareArticleVariationsManufacturerItemNumber()
    {
        $supplierNumber = '';

        if ((bool)$this->getVariationXmlElement()->ManufacturerItemNumber === true) {
            $supplierNumber = (string)$this->getVariationXmlElement()->ManufacturerItemNumber;
        }

        return $supplierNumber;
    }

    /**
     * @return string
     * @throws \Exception
     */
    private function getItemNumber()
    {
        if (ConfigManager::getInstance()->getUseOnlyVariationsItemNumbers() === 'true') {
            if ((bool)$this->getVariationXmlElement()->VariationItemNumber === false || strlen($this->getVariationXmlElement()->VariationItemNumber) <= 0) {
                LogManager::getInstance()
                    ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(['{$brickfoxId}', '{$productTitle}'],
                        [(string)$this->getSimpleXmlElement()->ProductId, (string)$this->getSimpleXmlElement()->Descriptions->Description[0]->Title],
                        ErrorCodes::PRODUCTS_MISSING_ITEM_NUMBER), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId,
                        ErrorCodes::PRODUCTS_MISSING_ITEM_NUMBER_ERROR_CODE);
            }

            $number = (string)$this->getVariationXmlElement()->VariationItemNumber;
        } else {
            if ((bool)$this->getSimpleXmlElement()->ItemNumber === true && strlen($this->getSimpleXmlElement()->ItemNumber) > 0) {
                $number = (string)$this->getSimpleXmlElement()->ItemNumber;
            } else {
                LogManager::getInstance()
                    ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(['{$brickfoxId}', '{$productTitle}'],
                        [(string)$this->getSimpleXmlElement()->ProductId, (string)$this->getSimpleXmlElement()->Descriptions->Description[0]->Title],
                        ErrorCodes::PRODUCTS_MISSING_ITEM_NUMBER), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId,
                        ErrorCodes::PRODUCTS_MISSING_ITEM_NUMBER_ERROR_CODE);
            }

            if (strlen($number) > 0) {
                if ($this->getHasVariationsSwCounter() > 0 && $this->getHasVariations() === 1) {
                    $detailsMappingRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingDetails');
                    /** @var \Shopware\CustomModels\BfSaleschannel\MappingDetails $detailMappingModel */
                    $detailMappingModel = $detailsMappingRepository->findOneBy(['brickfoxId' => (string)$this->getVariationXmlElement()->VariationId]);

                    if ($detailMappingModel === null) {
                        $number = $this->generateNewItemNumber($number);
                    } else {
                        $number = $detailMappingModel->getDetail()->getNumber();
                    }
                }
            } else {
                LogManager::getInstance()
                    ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(['{$productTitle}', '{$brickfoxId}'],
                        [(string)$this->getSimpleXmlElement()->Descriptions->Description[0]->Title, (string)$this->getSimpleXmlElement()->ProductId],
                        ErrorCodes::PRODUCTS_VARIATION_NO_VARIATION_ITEM_NUMBER), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                        (string)$this->getSimpleXmlElement()->ProductId, ErrorCodes::PRODUCTS_VARIATION_NO_VARIATION_ITEM_NUMBER_ERROR_CODE);
            }
        }

        return $number;
    }

    /**
     * @param string $bfOrderNumber
     *
     * @return string
     */
    private function generateNewItemNumber($bfOrderNumber = '')
    {
        $number = $bfOrderNumber . '.' . $this->getHasVariationsSwCounter();

        $detailRepository = Shopware()->Models()->getRepository('Shopware\Models\Article\Detail');
        $detailModel      = $detailRepository->findOneBy(['number' => $number]);

        $this->setHasVariationsSwCounter(1);

        if ($detailModel !== null) {
            $number = $this->generateNewItemNumber($bfOrderNumber);
        }

        return $number;
    }

    /**
     * @param $active
     *
     * @return mixed|string
     * @throws \Exception
     */
    protected function prepareArticleVariationsOrderNumber($active)
    {
        $number = $this->getItemNumber();

        if ($active === 0) {
            if (strpos($number, (string)$this->getVariationXmlElement()->VariationId . '-') === false) {
                $number = (string)$this->getVariationXmlElement()->VariationId . '-' . $number;
            }
        } else {
            $number = str_replace((string)$this->getVariationXmlElement()->VariationId . '-', '', $number);
        }

        $swArticleDetailResult = Shopware()->Db()->fetchRow(
            "select id, articleID from s_articles_details where ordernumber = ?",
            [$number]
        );

        if (!empty($swArticleDetailResult) && $swArticleDetailResult !== false) {
            if ((int)$swArticleDetailResult['id'] !== $this->getDetail()->getId()) {
                LogManager::getInstance()
                    ->writeLogForGui(Log::LOG_STATUS_WARNING, __METHOD__,
                        str_replace(['{$itemNumber}', '{$brickfoxId}'], [$number, (string)$this->getSimpleXmlElement()->ProductId], ErrorCodes::PRODUCTS_DUPLICATE_ENTRY),
                        Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId, ErrorCodes::PRODUCTS_DUPLICATE_ENTRY_ERROR_CODE);
            }
        }

        return $number;
    }

    /**
     * @return int|string
     */
    private function getMinimumOrderQuantity()
    {
        return ((bool)$this->getVariationXmlElement()->MinimumOrderQuantity === true) ? (string)$this->getVariationXmlElement()->MinimumOrderQuantity : 1;
    }

    /**
     * @return int|string
     */
    private function getMaximumOrderQuantity()
    {
        $maximumOrderQuantity = null;

        if ((bool)$this->getVariationXmlElement()->MaximumOrderQuantity === true) {
            $maximumOrderQuantity = (int)$this->getVariationXmlElement()->MaximumOrderQuantity;
        }

        return $maximumOrderQuantity;
    }

    /**
     * @return string
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    private function getPackingUnit()
    {
        $packingUnit = '';

        if ((bool)$this->getVariationXmlElement()->Descriptions === true && (bool)$this->getVariationXmlElement()->Descriptions->Description === true) {
            foreach ($this->getVariationXmlElement()->Descriptions->Description as $description) {

                if (in_array((string)$description['lang'], Helper::getMainLanguagesCode()) === true) {
                    if ((bool)$description->PackingUnit === true) {
                        $packingUnit = (string)$description->PackingUnit;
                    }
                }
            }
        }

        return $packingUnit;
    }

    /**
     * @return int|string
     */
    private function getDefaultQuantity()
    {
        return ((bool)$this->getVariationXmlElement()->DefaultQuantity === true) ? (string)$this->getVariationXmlElement()->DefaultQuantity : 1;
    }

    /**
     * @return int
     */
    public function getBfProductsId()
    {
        return $this->bfProductsId;
    }

    /**
     * @param int $bfProductsId
     */
    public function setBfProductsId($bfProductsId)
    {
        $this->bfProductsId = $bfProductsId;
    }
}
