<?php
/**
 * Stock.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Detail;

class Stock
{
    private static $instance = null;

    private function __construct()
    {
    }

    private function __clone()
    {
    }

    /**
     * @return Stock
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * @param \SimpleXMLElement $variationsXmlElement
     *
     * @return int
     */
    public function prepareArticleVariationsStock(\SimpleXMLElement $variationsXmlElement)
    {
        $inStock = 0;

        if ((bool) $variationsXmlElement->Stock === true && (bool) $variationsXmlElement->Stock->StockLocation === true) {
            foreach($variationsXmlElement->Stock->StockLocation as $locationItem) {
                $inStock += (int) $locationItem->Stock;
            }
        } else {
            $inStock = (int)$variationsXmlElement->Stock;
        }

        return $inStock;
    }

    /**
     * @param \SimpleXMLElement $variationsXmlElement
     *
     * @return int
     */
    public function prepareArticleVariationsMinimumStock(\SimpleXMLElement $variationsXmlElement)
    {
        $minStock = 0;

        if ((bool) $variationsXmlElement->MinimumStockQuantity === true) {
            $minStock = (int)$variationsXmlElement->MinimumStockQuantity;
        }

        return $minStock;
    }
}