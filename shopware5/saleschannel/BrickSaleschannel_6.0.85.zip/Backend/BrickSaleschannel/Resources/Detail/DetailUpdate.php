<?php
namespace Bf\Saleschannel\Components\Resources\Detail;

use Bf\Saleschannel\Components\Util\ConfigManager;
use Shopware\Models\Article\Detail as SwDetail;
use Shopware\Models\Article\Article as SwArticle;
use Bf\Saleschannel\Components\Resources\Prices\Prices;
use SimpleXMLElement;

/**
 * DetailUpdate
 *
 * @package Bf\Saleschannel\Components\Resources\Detail
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class DetailUpdate extends DetailAbstract
{
    /**
     * @param SimpleXMLElement $productsVariationsSimpleXmlElement
     * @param SwDetail $detail
     * @param SwArticle $article
     */
    public function __construct(SimpleXMLElement $productsVariationsSimpleXmlElement, SwArticle $article, $detail = null)
    {
        $this->setVariationXmlElement($productsVariationsSimpleXmlElement);
        $this->setDetail($detail);
        $this->setArticle($article);
    }

    /**
     * @return void
     */
    public function prepareArticleDetailUpdate()
    {
        $this->getDetail()->setActive($this->getVariationsActiveStatus($this->getVariationXmlElement()));

        if (ConfigManager::getInstance()->getIgnoreDelivery() === 'false' || ConfigManager::getInstance()->getIgnoreDelivery() === '') {
            $this->getDetail()->setShippingTime((string) $this->getVariationXmlElement()->DeliveryTime);
        }

        $this->getDetail()->setInStock(Stock::getInstance()->prepareArticleVariationsStock($this->getVariationXmlElement()));

        if(
            (
                $this->checkHash() === false &&
                ConfigManager::getInstance()->getDisableBfPriceUpdates() === false
            ) ||
            $this->getDetail()->getPrices()->isEmpty() === true
        )
        {
            $prices = new Prices();
            $this->getDetail()->setPrices($prices->preparePrices($this->getVariationXmlElement(), $this->getDetail(), $this->getArticle()));
            $this->generateHash();
        }
    }
}
