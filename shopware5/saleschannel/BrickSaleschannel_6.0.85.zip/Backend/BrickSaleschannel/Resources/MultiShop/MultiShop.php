<?php

namespace Bf\Saleschannel\Components\Resources\MultiShop;

use Bf\Saleschannel\Components\Resources\Categories\Categories;
use Bf\Saleschannel\Components\Resources\Prices\Prices;
use Bf\Saleschannel\Components\Resources\Translation\Translation;
use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Shopware\CustomModels\BfSaleschannel\Log;
use Shopware\Models\Article\Article as SwArticle;

/**
 * MultiShop
 *
 * @package Bf\Saleschannel\Components\Resources\MultiShop
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class MultiShop extends MultiShopAbstract
{
    /**
     * @param \SimpleXMLElement $simpleXMLElement
     * @param \Shopware\Models\Article\Article $item
     * @param $brickfoxShopId
     */
    public function __construct(\SimpleXMLElement $simpleXMLElement, SwArticle $item, $brickfoxShopId)
    {
        $this->setSimpleXmlElement($simpleXMLElement);
        $this->setArticle($item);
        $this->setBrickfoxShopId($brickfoxShopId);
    }

    /**
     * @return void
     */
    public function prepareMultiShop()
    {
        $this->prepareArticleTranslation();
        $this->prepareVariationsTranslation();

        if (ConfigManager::getInstance()->getIgnoreImportMultiShopCategories() === false) {
            $this->prepareCategories();
        }

        $this->prepareMultiShopPrices();
        $this->preparePropertyTranslations();
        $this->prepareConfiguratorTranslation();
    }

    /**
     * @return void
     */
    private function prepareCategories()
    {
        $shopsMappingModelRepository = Shopware()->Models()->getRepository(MultiShopAbstract::MAPPING_NAMESPACE_SHOPS);
        $shopsMappingModels          = $shopsMappingModelRepository->findBy(array('brickfoxId' => $this->getBrickfoxShopId()));

        if (count($shopsMappingModels) > 1) {
            (new Categories($this->getSimpleXmlElement(), $this->getArticle()))->prepareCategoriesAssignment(null, $shopsMappingModels);
        } elseif (count($shopsMappingModels) === 1) {
            (new Categories($this->getSimpleXmlElement(), $this->getArticle()))->prepareCategoriesAssignment($shopsMappingModels[0]->getShopwareId());
        }
    }

    /**
     * @return void
     */
    private function prepareArticleTranslation()
    {
        $shopsMapping = $this->getShopMappingModel();

        if (count($shopsMapping) > 1) {
            /** @var \Shopware\CustomModels\BfSaleschannel\MappingShops $shop */
            foreach ($shopsMapping as $shop) {
                $this->loadTranslationModel(self::TYPE_ARTICLE, $this->getArticle()->getId(), $shop->getShop()->getId(), false);

                if ((bool)$this->getSimpleXmlElement()->Descriptions === true && (bool)$this->getSimpleXmlElement()->Descriptions->Description === true) {
                    (new Translation($this->getSimpleXmlElement(), true))->prepareTranslationItem($this->getTranslationModel(), $shop->getShop()->getId(), self::TYPE_ARTICLE,
                        $this->getArticle()->getId(), false, $this->getArticle());

                }

                if ((bool)$this->getSimpleXmlElement()->Attributes === true) {
                    $this->loadTranslationModel(self::TYPE_ATTRIBUTES, $this->getArticle()->getId(), $shop->getShop()->getId(), false);
                    (new Translation($this->getSimpleXmlElement(), true))->prepareTranslationItem($this->getTranslationModel(), $shop->getShop()->getId(),
                        self::TYPE_ATTRIBUTES, $this->getArticle()->getId());

                    $this->loadTranslationModel(self::TYPE_ARTICLE, $this->getArticle()->getId(), $shop->getShop()->getId(), false);
                    (new Translation($this->getSimpleXmlElement(), true))->prepareTranslationItem($this->getTranslationModel(), $shop->getShop()->getId(),
                        self::TYPE_ARTICLE, $this->getArticle()->getId());
                }
                $this->persistTranslations();
            }
        } elseif (count($shopsMapping) === 1) {
            $this->loadTranslationModel(self::TYPE_ARTICLE, $this->getArticle()->getId(), $this->getBrickfoxShopId());

            if ($this->getTranslationModel() !== null) {
                if ((bool)$this->getSimpleXmlElement()->Descriptions === true && (bool)$this->getSimpleXmlElement()->Descriptions->Description === true) {
                    (new Translation($this->getSimpleXmlElement()))->prepareTranslationItem($this->getTranslationModel(), $this->getBrickfoxShopId(), self::TYPE_ARTICLE,
                        $this->getArticle()->getId(), false, $this->getArticle());
                }

                if ((bool)$this->getSimpleXmlElement()->Attributes === true) {
                    $this->loadTranslationModel(self::TYPE_ATTRIBUTES, $this->getArticle()->getId(), $this->getBrickfoxShopId());
                    (new Translation($this->getSimpleXmlElement()))->prepareTranslationItem($this->getTranslationModel(), $this->getBrickfoxShopId(), self::TYPE_ATTRIBUTES,
                        $this->getArticle()->getId());

                    $this->loadTranslationModel(self::TYPE_ARTICLE, $this->getArticle()->getId(), $this->getBrickfoxShopId());
                    (new Translation($this->getSimpleXmlElement()))->prepareTranslationItem($this->getTranslationModel(), $this->getBrickfoxShopId(), self::TYPE_ARTICLE,
                        $this->getArticle()->getId());
                }
                $this->persistTranslations();
            }
        }
    }

    /**
     * @return array
     */
    private function getShopMappingModel()
    {
        $shopsMappingRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingShops');
        $shopsMapping           = $shopsMappingRepository->findBy(array('brickfoxId' => $this->getBrickfoxShopId()));

        return $shopsMapping;
    }

    /**
     * @return void
     */
    private function prepareVariationsTranslation()
    {
        $shopMapping = $this->getShopMappingModel();

        /** @var \Shopware\Models\Article\Detail $detail */
        foreach ($this->getArticle()->getDetails() as $detail) {
            if ($detail->getKind() === 2) {

                if (count($shopMapping) > 1) {

                    /** @var \Shopware\CustomModels\BfSaleschannel\MappingShops $shop */
                    foreach ($shopMapping as $shop) {
                        $this->loadTranslationModel(self::TYPE_VARIATION, $detail->getId(), $shop->getShop()->getId(), false);

                        if ($this->getTranslationModel() !== null) {
                            if ((bool)$this->getSimpleXmlElement()->Variations->Variation === true) {
                                foreach ($this->getSimpleXmlElement()->Variations->Variation as $variationElement) {
                                    $bfMappingDetailsRepository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingDetails');
                                    /** @var \Shopware\CustomModels\BfSaleschannel\MappingDetails $bfMappingDetailModel */
                                    $bfMappingDetailModel = $bfMappingDetailsRepository->findOneBy(array('brickfoxId' => (int)$variationElement->VariationId));

                                    if ($bfMappingDetailModel !== null) {
                                        if ($bfMappingDetailModel->getShopwareId() === $detail->getId()) {
                                            $translationClass = new Translation($this->getSimpleXmlElement(), true);
                                            $translationClass->prepareTranslationItem($this->getTranslationModel(), $shop->getShop()->getId(), self::TYPE_VARIATION,
                                                $detail->getId());

                                            Translation::$translation['txtzusatztxt'] = $translationClass->prePrepareVariationsAdditionalTextForVariationTranslationMultiLanguage($variationElement);

                                            $this->persistTranslations();
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    $this->loadTranslationModel(self::TYPE_VARIATION, $detail->getId(), $this->getBrickfoxShopId());

                    if ($this->getTranslationModel() !== null) {
                        if ((bool)$this->getSimpleXmlElement()->Variations->Variation === true) {
                            foreach ($this->getSimpleXmlElement()->Variations->Variation as $variationElement) {
                                $bfMappingDetailsRepository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingDetails');
                                /** @var \Shopware\CustomModels\BfSaleschannel\MappingDetails $bfMappingDetailModel */
                                $bfMappingDetailModel = $bfMappingDetailsRepository->findOneBy(array('brickfoxId' => (int)$variationElement->VariationId));

                                if ($bfMappingDetailModel !== null) {
                                    if ($bfMappingDetailModel->getShopwareId() === $detail->getId()) {
                                        $translationClass = new Translation($this->getSimpleXmlElement());
                                        $translationClass->prepareTranslationItem($this->getTranslationModel(), $this->getBrickfoxShopId(), self::TYPE_VARIATION, $detail->getId());
                                        Translation::$translation['txtzusatztxt'] = $translationClass->prepareVariationsAdditionalText($variationElement);

                                        $this->persistTranslations();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @return void
     */
    private function persistTranslations()
    {
        if (count(Translation::$translation) > 0) {
            echo '<pre>';
            print_r(Translation::$translation);
            echo '</pre>';
            $this->getTranslationModel()->setData(serialize(Translation::$translation));
            Shopware()->Models()->persist($this->getTranslationModel());
            $this->resetTranslation();
        }
    }

    /**
     * @return void
     */
    private function preparePropertyTranslations()
    {
        $shopsMapping = $this->getShopMappingModel();

        if (count($shopsMapping) > 1) {
            /** @var \Shopware\CustomModels\BfSaleschannel\MappingShops $shop */
            foreach ($shopsMapping as $shop) {
                (new Translation($this->getSimpleXmlElement(), true))->prepareTranslationItem(null, $shop->getShop()->getId(), self::TYPE_PROPERTY_OPTION_AND_VALUE, null, true,
                    $this->getArticle());
            }
        } else {
            (new Translation($this->getSimpleXmlElement()))->prepareTranslationItem(null, $this->getBrickfoxShopId(), self::TYPE_PROPERTY_OPTION_AND_VALUE, null, true,
                $this->getArticle());
        }
    }

    private function prepareConfiguratorTranslation()
    {
        $shopsMapping = $this->getShopMappingModel();

        if (count($shopsMapping) > 1) {
            /** @var \Shopware\CustomModels\BfSaleschannel\MappingShops $shop */
            foreach ($shopsMapping as $shop) {
                (new Translation($this->getSimpleXmlElement(), true))->prepareTranslationItem(null, $shop->getShop()->getId(), self::TYPE_CONFIGURATOR_GROUP_AND_OPTION, null, false,
                    $this->getArticle(), true);
            }
        } else {
            (new Translation($this->getSimpleXmlElement()))->prepareTranslationItem(null, $this->getBrickfoxShopId(), self::TYPE_CONFIGURATOR_GROUP_AND_OPTION, null, false,
                $this->getArticle(), true);
        }
    }

    private function prepareMultiShopPrices()
    {
        foreach ($this->getSimpleXmlElement()->Variations->Variation as $variation) {
            if ((bool)$variation->Currencies === true && (bool)$variation->Currencies->Currency === true) {
                $repository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingDetails');

                /** @var \Shopware\CustomModels\BfSaleschannel\MappingDetails $detailMappingModel */
                $detailMappingModel = $repository->findOneBy(array('brickfoxId' => (int)$variation->VariationId));

                if ($detailMappingModel !== null) {
                    if ($this->checkHash((int)$variation->VariationId, $variation) === false) {
                        $priceClass = new Prices();
                        $price      = $priceClass->preparePrices($variation, $detailMappingModel->getDetail(), $this->getArticle(), $this->getBrickfoxShopId());

                        $detailMappingModel->getDetail()->setPrices($price);
                        Shopware()->Models()->persist($detailMappingModel->getDetail());
                        $this->generateHash($variation);
                    }

                    $detailMappingModel = null;
                }
            } else {
                LogManager::getInstance()
                    ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(array('{$itemNumber}', '{$brickfoxId}'),
                            array((string)$this->getSimpleXmlElement()->ItemNumber, (string)$this->getSimpleXmlElement()->ProductId), ErrorCodes::MULTI_SHOP_CORRUPT_PRICES),
                        Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_SUB_SHOP, (string)$this->getSimpleXmlElement()->ProductId, ErrorCodes::MULTI_SHOP_CORRUPT_PRICES_ERROR_CODE,
                        false, false);
            }
        }
    }

    /**
     * @return void
     */
    public function removeArticleFromMultiShop()
    {
        if (ConfigManager::getInstance()->getIgnoreImportMultiShopCategories() === false) {
            $repository        = Shopware()->Models()->getRepository(MultiShopAbstract::MAPPING_NAMESPACE_SHOPS);
            $shopsMappingModel = $repository->findBy(array('brickfoxId' => $this->getBrickfoxShopId()));

            if (count($shopsMappingModel) > 0) {
                /** @var \Shopware\CustomModels\BfSaleschannel\MappingShops $mappingModel */
                foreach ($shopsMappingModel as $mappingModel) {
                    $repository = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop');
                    /** @var \Shopware\Models\Shop\Shop $shopModel */
                    $shopModel = $repository->findOneBy(array('id' => $mappingModel->getShopwareId()));

                    if ($shopModel !== null) {
                        /** @var \Shopware\Models\Category\Category $category */
                        foreach ($this->getArticle()->getCategories() as $category) {
                            if ($category->isChildOf($shopModel->getCategory())) {
                                if ($category->getId() !== null) {
                                    $this->getArticle()->removeCategory($category);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        parent::__destruct();
    }
}
