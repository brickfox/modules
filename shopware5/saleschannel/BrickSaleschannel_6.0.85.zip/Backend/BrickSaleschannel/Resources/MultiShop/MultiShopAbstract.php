<?php
namespace Bf\Saleschannel\Components\Resources\MultiShop;

use Bf\Saleschannel\Components\Resources\ImportAbstract;
use Bf\Saleschannel\Components\Resources\Translation\Translation;
use Bf\Saleschannel\Components\Util\Helper;
use Shopware\CustomModels\BfSaleschannel\ApiImportPriceHash;
use Shopware\Models\Article\Article as SwArticle;
use Shopware\Models\Translation\Translation as SwTranslation;

/**
 * MultiShopAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\MultiShop
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class MultiShopAbstract extends ImportAbstract
{
    const TYPE_ARTICLE                       = 'article';
    const TYPE_VARIATION                     = 'variant';
    const TYPE_PROPERTY_OPTION_AND_VALUE     = 'propertyoption|propertyvalue';
    const TYPE_CONFIGURATOR_GROUP_AND_OPTION = 'configuratorgroup|configuratoroption';
    const TYPE_ATTRIBUTES                    = 'attributes';
    const MAPPING_NAMESPACE_SHOPS            = 'Shopware\CustomModels\BfSaleschannel\MappingShops';

    private $brickfoxShopId;

    private $translationModel = null;

    private $translationData;

    private $translationType;

    private $translationShop;

    private $translationObjectKey;

    private $data;

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     * @param SwArticle $article
     * @param $brickfoxShopId
     */
    abstract public function __construct(\SimpleXMLElement $simpleXMLElement, SwArticle $article, $brickfoxShopId);

    /**
     * @param $translationType
     * @param $objectKey
     * @param $shopsId
     * @param bool $useBrickfoxId
     *
     * @return void
     */
    protected function loadTranslationModel($translationType, $objectKey, $shopsId, $useBrickfoxId = true)
    {
        $shopwareShopsId = 0;

        if ($useBrickfoxId === true) {
            /** @var \Shopware\CustomModels\BfSaleschannel\MappingShops $shopsMappingModel */
            $shopsMappingModel = Helper::getMappingByValue($shopsId, 'brickfoxId', MultiShopAbstract::MAPPING_NAMESPACE_SHOPS);

            if ($shopsMappingModel !== null) {
                $shopwareShopsId = $shopsMappingModel->getShop()->getId();
            }
        } else {
            $shopwareShopsId = $shopsId;
        }


        if($shopwareShopsId > 0)
        {
            $repository       = Helper::getRepository('Shopware\Models\Translation\Translation');
            $translationModel = $repository->findOneBy(
                array('type' => $translationType, 'key' => $objectKey, 'shopId' => $shopwareShopsId)
            );

            if($translationModel !== null)
            {
                $this->setTranslationModel($translationModel);
            }
            else
            {

                $this->setTranslationModel((new SwTranslation()));
            }
        }
    }

    /**
     * @return array
     */
    protected function getPropertyValues()
    {
        $propertyValues = array();

        foreach($this->getArticle()->getPropertyValues() as $propertyValues)
        {
            $propertyValues[] = $propertyValues;
        }

        return $propertyValues;
    }

    /**
     * @return mixed
     */
    public function getBrickfoxShopId()
    {
        return $this->brickfoxShopId;
    }

    /**
     * @param mixed $brickfoxShopId
     *
     * @return MultiShopAbstract
     */
    public function setBrickfoxShopId($brickfoxShopId)
    {
        $this->brickfoxShopId = $brickfoxShopId;

        return $this;
    }

    /**
     * @return SwTranslation
     */
    public function getTranslationModel()
    {
        return $this->translationModel;
    }

    /**
     * @param mixed $translationModel
     *
     * @return MultiShopAbstract
     */
    public function setTranslationModel($translationModel)
    {
        $this->translationModel = $translationModel;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getTranslationData()
    {
        return $this->translationData;
    }

    /**
     * @param mixed $translationData
     *
     * @return MultiShopAbstract
     */
    public function setTranslationData($translationData)
    {
        $this->translationData = $translationData;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getTranslationType()
    {
        return $this->translationType;
    }

    /**
     * @param mixed $translationType
     *
     * @return MultiShopAbstract
     */
    public function setTranslationType($translationType)
    {
        $this->translationType = $translationType;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getTranslationShop()
    {
        return $this->translationShop;
    }

    /**
     * @param mixed $translationShop
     *
     * @return MultiShopAbstract
     */
    public function setTranslationShop($translationShop)
    {
        $this->translationShop = $translationShop;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getTranslationObjectKey()
    {
        return $this->translationObjectKey;
    }

    /**
     * @param mixed $translationObjectKey
     *
     * @return MultiShopAbstract
     */
    public function setTranslationObjectKey($translationObjectKey)
    {
        $this->translationObjectKey = $translationObjectKey;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * @param mixed $data
     *
     * @return MultiShopAbstract
     */
    public function setData($data)
    {
        $this->data = $data;

        return $this;
    }

    /**
     * @param $variationXmlElement
     *
     * @return null
     */
    protected function customerGroupHelper($variationXmlElement)
    {
        $mappingFieldKey = null;

        if((bool) $variationXmlElement->Currencies[0] === true)
        {
            $currencyCode = (string) $variationXmlElement->Currencies[0]->Currency['code'];

            $currenciesMappingModel = Helper::getMappingByValue($currencyCode, 'brickfoxCurrenciesCode', 'Shopware\CustomModels\BfSaleschannel\MappingCurrencies');

            if($currenciesMappingModel !== null)
            {
                $mappingFieldKey = $currenciesMappingModel->getMappingFieldKey();
            }
        }

        return $mappingFieldKey;
    }

    /**
     * @param string $customerGroupKey
     * @param $articleId
     *
     * @return array
     */
    protected function getAllPrices($customerGroupKey = '', $articleId)
    {
        $priceList = array();

        if(strlen($customerGroupKey) > 0 && $customerGroupKey !== null)
        {
            $qb = Shopware()->Models()->createQueryBuilder();
            $qb->select(array('prices'))->from('Shopware\Models\Article\Price', 'prices')->where('prices.articleId = :articleId')->andWhere(
                'prices.customerGroupKey != :customerGroupKey'
            )->setParameters(
                array(
                    'articleId'        => $articleId,
                    'customerGroupKey' => $customerGroupKey
                )
            );

            $sql       = $qb->getQuery();
            $priceList = $sql->getResult();
        }

        return $priceList;
    }

    /**
     * @return void
     */
    protected function resetTranslation()
    {
        Translation::$translation = array();
    }

    /**
     * @param $variationId
     * @param \SimpleXMLElement $variation
     *
     * @return bool
     */
    protected function checkHash($variationId, \SimpleXMLElement $variation)
    {
        $checkSumEqual = false;
        $hashModel     = $this->loadMultiShopPriceHashByVariationId($variationId);

        if($hashModel !== null)
        {
            if($this->generateHashValue($variation) === $hashModel->getHash())
            {
                $checkSumEqual = true;
            }
        }

        return $checkSumEqual;
    }

    /**
     * @param $variationId
     *
     * @return ApiImportPriceHash
     */
    protected function loadMultiShopPriceHashByVariationId($variationId)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\ApiImportPriceHash');
        /** @var \Shopware\CustomModels\BfSaleschannel\ApiImportPriceHash $hashModel */
        $hashModel = $repository->findOneBy(array('brickfoxId' => $variationId, 'isMultiShop' => $this->getBrickfoxShopId()));

        return $hashModel;
    }

    /**
     * @param \SimpleXMLElement $variation
     *
     * @return string
     */
    protected function generateHashValue(\SimpleXMLElement $variation)
    {
        $valueToHash = $variation->Currencies->asXml();
        $hashValue   = sha1($valueToHash);

        return $hashValue;
    }

    /**
     * @param \SimpleXMLElement $variation
     *
     * @return void
     */
    protected function generateHash(\SimpleXMLElement $variation)
    {
        $hashModel = $this->loadMultiShopPriceHashByVariationId((int) $variation->VariationId);

        if($hashModel === null)
        {
            $hashModel = new ApiImportPriceHash();
            $hashModel->setBrickfoxId((int) $variation->VariationId);
            $hashModel->setHash($this->generateHashValue($variation));
            $hashModel->setIsMultiShop($this->getBrickfoxShopId());
            $hashModel->setDateInsert(new \DateTime());
            $hashModel->setLastUpdate(new \DateTime());
        }
        else
        {
            $hashModel->setHash($this->generateHashValue($variation));
            $hashModel->setLastUpdate(new \DateTime());
        }

        Shopware()->Models()->persist($hashModel);
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        parent::__destruct();
    }
}
