<?php

namespace Bf\Saleschannel\Components\Resources\Categories;

use Bf\Saleschannel\Components\Import\Categories;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Shopware\CustomModels\BfSaleschannel\Log;
use Shopware\Models\Article\Article as SwArticle;
use SimpleXMLElement;

/**
 * CategoriesAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Categories
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class CategoriesAbstract
{
    private $simpleXmlElement;

    private $article;

    /**
     * @param $categoryXmlElement
     *
     * @return null|\Shopware\CustomModels\BfSaleschannel\MappingCategories
     */
    protected function getCategoryMappingModel($categoryXmlElement)
    {
        $mappingModel = Helper::getMappingByValue((int)$categoryXmlElement->CategoryId, 'brickfoxId', Categories::MAPPING_NAMESPACE_MODEL);

        if ($mappingModel === null) {
            LogManager::getInstance()
                ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(array('{$categoryId}', '{$brickfoxId}', '{$itemNumber}'),
                        array((string)$categoryXmlElement->CategoryId, (string)$this->getSimpleXmlElement()->ProductId, (string)$this->getSimpleXmlElement()->ItemNumber),
                        ErrorCodes::CAN_NOT_FIND_CATEGORY_BY_ID), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId,
                    ErrorCodes::CAN_NOT_FIND_CATEGORY_BY_ID_ERROR_CODE, false, false);
        }

        return $mappingModel;
    }

    /**
     * @param $categoryXmlElement
     * @param $shopsId
     *
     * @return array
     */
    protected function getCategoryMappingModelList($categoryXmlElement, $shopsId)
    {
        $categoriesRepository = Shopware()->Models()->getRepository(Categories::MAPPING_NAMESPACE_MODEL);
        $mappingModels        = $categoriesRepository->findBy(array('brickfoxId' => (int)$categoryXmlElement->CategoryId, 'shopsId' => $shopsId));

        if (count($mappingModels) === 0) {
            LogManager::getInstance()
                ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(array('{$categoryId}', '{$brickfoxId}', '{$itemNumber}'),
                    array((string)$categoryXmlElement->CategoryId, (string)$this->getSimpleXmlElement()->ProductId, (string)$this->getSimpleXmlElement()->ItemNumber),
                    ErrorCodes::CAN_NOT_FIND_CATEGORY_BY_ID), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId,
                    ErrorCodes::CAN_NOT_FIND_CATEGORY_BY_ID_ERROR_CODE, false, false);
        }

        return $mappingModels;
    }

    /**
     * @param $categoryXmlElement
     *
     * @return array
     */
    protected function getAllCategoriesMappingModels($categoryXmlElement)
    {
        $categoriesRepository = Shopware()->Models()->getRepository(Categories::MAPPING_NAMESPACE_MODEL);
        $mappingModels        = $categoriesRepository->findBy(array('brickfoxId' => (int)$categoryXmlElement->CategoryId));

        if (count($mappingModels) === 0) {
            LogManager::getInstance()
                ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(array('{$categoryId}', '{$brickfoxId}', '{$itemNumber}'),
                        array((string)$categoryXmlElement->CategoryId, (string)$this->getSimpleXmlElement()->ProductId, (string)$this->getSimpleXmlElement()->ItemNumber),
                        ErrorCodes::CAN_NOT_FIND_CATEGORY_BY_ID), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId,
                    ErrorCodes::CAN_NOT_FIND_CATEGORY_BY_ID_ERROR_CODE, false, false);
        }

        return $mappingModels;
    }

    /**
     * @return array
     */
    protected function getCategoryXmlElement()
    {
        $categoryXmlElement = array();

        if ((bool)$this->getSimpleXmlElement()->Categories === true && (bool)$this->getSimpleXmlElement()->Categories->Category === true) {
            foreach ($this->getSimpleXmlElement()->Categories->Category as $category) {
                $categoryXmlElement[] = $category;
            }
        }

        return $categoryXmlElement;
    }

    /**
     * @return mixed
     */
    public function getSimpleXmlElement()
    {
        return $this->simpleXmlElement;
    }

    /**
     * @param mixed $simpleXmlElement
     *
     * @return CategoriesAbstract
     */
    public function setSimpleXmlElement($simpleXmlElement)
    {
        $this->simpleXmlElement = $simpleXmlElement;

        return $this;
    }

    /**
     * @return SwArticle
     */
    public function getArticle()
    {
        return $this->article;
    }

    /**
     * @param mixed $article
     *
     * @return CategoriesAbstract
     */
    public function setArticle($article)
    {
        $this->article = $article;

        return $this;
    }

    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param SwArticle $article
     */
    abstract public function __construct(SimpleXMLElement $simpleXMLElement, SwArticle $article);

    /**
     * @return void
     */
    public function __destruct()
    {
        unset($this->article);
        unset($this->simpleXmlElement);
    }
}
