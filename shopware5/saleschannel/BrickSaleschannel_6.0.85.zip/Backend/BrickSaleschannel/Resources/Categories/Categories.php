<?php

namespace Bf\Saleschannel\Components\Resources\Categories;

use Shopware\Models\Article\Article as SwArticle;
use SimpleXMLElement;

/**
 * Categories
 *
 * @package Bf\Saleschannel\Components\Resources\Categories
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Categories extends CategoriesAbstract
{
    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param SwArticle $article
     */
    public function __construct(SimpleXMLElement $simpleXMLElement, SwArticle $article)
    {
        $this->setSimpleXmlElement($simpleXMLElement);
        $this->setArticle($article);
    }

    /**
     * @param $shopsId
     * @param array $shopsMappingModels
     *
     * @return void
     */
    public function prepareCategoriesAssignment($shopsId, array $shopsMappingModels = array())
    {
        $importCategoriesHelper = array();

        if ($shopsId !== null) {
            $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingShops');
            /** @var \Shopware\CustomModels\BfSaleschannel\MappingShops $bfMappingShops*/
            $bfMappingShops = $repository->findOneBy(array('shopwareId' => $shopsId));

            if ($bfMappingShops !== null) {
                $bfMappingShopsList = $repository->findBy(array('brickfoxId' => $bfMappingShops->getBrickfoxId()));

                if (count($bfMappingShopsList) > 0) {
                    foreach ($this->getCategoryXmlElement() as $category) {
                        $categoriesMappingModel = $this->getCategoryMappingModelList($category, $bfMappingShops->getBrickfoxId());

                        if (count($categoriesMappingModel) > 0) {
                            /** @var \Shopware\CustomModels\BfSaleschannel\MappingCategories $categoryMappingModel */
                            foreach($categoriesMappingModel as $categoryMappingModel) {
                                $importCategoriesHelper[$categoryMappingModel->getCategory()->getId()] = $categoryMappingModel->getCategory();
                                $this->getArticle()->addCategory($categoryMappingModel->getCategory());
                            }
                        }
                    }

                    /** @var \Shopware\Models\Category\Category $category */
                    foreach ($this->getArticle()->getCategories() as $category) {
                        /** @var \Shopware\CustomModels\BfSaleschannel\MappingShops $shopModel */
                        foreach($bfMappingShopsList as $shopModel) {
                            if ($category->isChildOf($shopModel->getShop()->getCategory())) {
                                if ($category->getId() !== null) {
                                    if (array_key_exists($category->getId(), $importCategoriesHelper) === false) {
                                        $this->getArticle()->removeCategory($category);
                                    }
                                }
                            }
                        }
                    }
                } else {
                    $repository = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop');
                    /** @var \Shopware\Models\Shop\Shop $shopModel */
                    $shopModel = $repository->findOneBy(array('id' => $shopsId));

                    foreach ($this->getCategoryXmlElement() as $category) {
                        $categoryMappingModel = $this->getCategoryMappingModel($category);

                        if ($categoryMappingModel !== null) {
                            $importCategoriesHelper[$categoryMappingModel->getCategory()->getId()] = $categoryMappingModel->getCategory();
                            $this->getArticle()->addCategory($categoryMappingModel->getCategory());
                        }
                    }

                    /** @var \Shopware\Models\Category\Category $category */
                    foreach ($this->getArticle()->getCategories() as $category) {
                        if ($category->isChildOf($shopModel->getCategory())) {
                            if ($category->getId() !== null) {
                                if (array_key_exists($category->getId(), $importCategoriesHelper) === false) {
                                    $this->getArticle()->removeCategory($category);
                                }
                            }
                        }
                    }
                }
            }
        } elseif ($shopsId === null && count($shopsMappingModels) > 1) {
            foreach ($this->getCategoryXmlElement() as $category) {
                $categoriesMappingModel = $this->getAllCategoriesMappingModels($category);
                if (count($categoriesMappingModel) > 0) {
                    /** @var \Shopware\CustomModels\BfSaleschannel\MappingCategories $categoryMappingModel */
                    foreach ($categoriesMappingModel as $categoryMappingModel) {
                        $importCategoriesHelper[$categoryMappingModel->getCategory()->getId()] = $categoryMappingModel->getCategory();
                        $this->getArticle()->addCategory($categoryMappingModel->getCategory());
                    }
                }
            }

            /** @var \Shopware\Models\Category\Category $category */
            foreach ($this->getArticle()->getCategories() as $category) {
                /** @var \Shopware\CustomModels\BfSaleschannel\MappingShops $shopModel */
                foreach($shopsMappingModels as $shopModel) {
                    if ($category->isChildOf($shopModel->getShop()->getCategory())) {
                        if ($category->getId() !== null) {
                            if (array_key_exists($category->getId(), $importCategoriesHelper) === false) {
                                $this->getArticle()->removeCategory($category);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        parent::__destruct();
    }
}
