<?php
namespace Bf\Saleschannel\Components\Resources\Configurator;

use Bf\Saleschannel\Components\Gui\GuiAbstract;
use Bf\Saleschannel\Components\Util\Exceptions;
use Bf\Saleschannel\Components\Util\Helper;
use Shopware\Models\Article\Article as SwArticle;

/**
 * Set
 *
 * @package Bf\Saleschannel\Components\Resources\Configurator
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Set extends SetAbstract
{
    const FILE_NAME = 'Set';

    /**
     * @param SwArticle $article
     */
    public function __construct(SwArticle $article)
    {
        $this->setArticle($article);
        parent::loadSetModel();
    }

    /**
     * @return null|\Shopware\Models\Article\Configurator\Set
     * @throws \Exception
     */
    public function prepareConfigurationSetItem()
    {
        /** @var \Shopware\CustomModels\BfSaleschannel\Configuration $variationsTemplateConfiguratorModel */
        $variationsTemplateConfiguratorModel = Helper::getConfigurationByKey(GuiAbstract::CONFIGURATION_KEY_VARIATION_TEMPLATE);
        $this->getSetModel()->setType((int) $variationsTemplateConfiguratorModel->getConfigurationValue());

        Exceptions::instanceOfException(
            array(
                'fileName' => self::FILE_NAME,
                array(
                    'obj'   => 'Shopware\Models\Article\Configurator\Set',
                    'param' => $this->getSetModel()
                )
            )
        );

        Shopware()->Models()->persist($this->getSetModel());
        Shopware()->Models()->flush($this->getSetModel());


        try
        {
            $groupsCollection = Configurator::getInstance()->prepareConfiguratorRelations(Configurator::getInstance()->getGroupsIds());

            $toDeleteGroups = array();

            /** @var \Shopware\Models\Article\Configurator\Group $groups */
            foreach ($this->getSetModel()->getGroups() as $groups) {
                $toDeleteGroups[] = $groups->getId();
            }


            if(count($groupsCollection) > 0)
            {
                foreach($groupsCollection as $groups)
                {
                    Shopware()->Db()->query(
                        "
                         insert ignore into s_article_configurator_set_group_relations (`set_id`, `group_id`)
                         values(?, ?)
                        ",array($this->getSetModel()->getId(), $groups->getId())
                    );

                    if (($key = array_search($groups->getId(), $toDeleteGroups)) !== false) {
                        unset($toDeleteGroups[$key]);
                    }
                }
            }

            if (count($toDeleteGroups) > 0) {
                $sql = "DELETE acsor.* FROM s_article_configurator_set_group_relations acsor WHERE acsor.set_id = " . $this->getSetModel()->getId() . " and acsor.group_id in (" . implode(',', $toDeleteGroups) . ")";
                Shopware()->Db()->query($sql);
            }

            $optionsCollection = Configurator::getInstance()->prepareConfiguratorRelations(Configurator::getInstance()->getOptionIds(), ConfiguratorAbstract::TYPE_OPTIONS);

            $toDelete = array();

            /** @var \Shopware\Models\Article\Configurator\Option $options */
            foreach($this->getSetModel()->getOptions() as $options)
            {
                $toDelete[] = $options->getId();
            }

            if(count($optionsCollection) > 0)
            {
                foreach($optionsCollection as $options)
                {
                    Shopware()->Db()->query(
                        "
                         insert ignore into s_article_configurator_set_option_relations (`set_id`, `option_id`)
                         values(?, ?)
                        ",array($this->getSetModel()->getId(), $options->getId())
                    );

                    if(($key = array_search($options->getId(), $toDelete)) !== false) {
                        unset($toDelete[$key]);
                    }
                }
            }

            if(count($toDelete) > 0)
            {
                $sql = "DELETE acsor.* FROM s_article_configurator_set_option_relations acsor WHERE acsor.set_id = " . $this->getSetModel()->getId() . " and acsor.option_id in (" . implode(',', $toDelete) . ")";
                Shopware()->Db()->query($sql);
            }
        }
        catch(Exception $e)
        {
            echo '<pre>';
            print_r($e->getMessage());
            echo '</pre>';
        }

        return $this->getSetModel();

        return $this->getSetModel();
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        parent::__destruct();
    }
}
