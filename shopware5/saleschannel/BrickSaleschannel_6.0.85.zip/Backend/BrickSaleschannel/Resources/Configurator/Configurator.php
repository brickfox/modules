<?php

namespace Bf\Saleschannel\Components\Resources\Configurator;

use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Shopware\CustomModels\BfSaleschannel\Log;
use Shopware\Models\Article\Configurator\Option as SwOption;
use Shopware\Models\Attribute\ConfiguratorOption as ConfiguratorOptionAttribute;
use SimpleXMLElement;
use Shopware\Models\Article\Detail as SwDetail;

/**
 * Configurator
 *
 * @package Bf\Saleschannel\Components\Resources\Configurator
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Configurator extends ConfiguratorAbstract
{
    private const ARTICLE_CONFIGURATOR_OPTIONS_ATTRIBUTE_TABLE_NAME = 's_article_configurator_options_attributes';
    public static $configurator = null;

    public function __clone()
    {
    }

    public function __wakeup()
    {
    }

    /**
     * @return Configurator|null
     */
    public static function getInstance()
    {
        if (self::$configurator === null) {
            self::$configurator = new self;
        }

        return self::$configurator;
    }

    /**
     * @param SimpleXMLElement $variationXmlElement
     * @param SwDetail $detail
     * @param $productId
     *
     * @return string
     * @throws \Exception
     */
    public function prepareConfiguratorItem(SimpleXMLElement $variationXmlElement, SwDetail $detail, $productId)
    {
        $this->setDetail($detail);

        //todo delete list and update for configurator sets

        if ((bool)$variationXmlElement->Options === true && (bool)$variationXmlElement->Options->Option === true) {
            $additionalText = '';
            $counter        = 0;
            $optionCode     = '';
            $optionValueCode = '';

            $this->resetOptionArray();
            $this->resetGroupArray();

            foreach ($variationXmlElement->Options->Option as $option) {
                if (strlen($option['id']) > 0) {
                    $groupId   = (int)$option['id'];
                    $groupSort = (int)$option['sort'];
                }

                if (strlen($option['valueId']) > 0) {
                    $valueId = (int)$option['valueId'];
                }

                if (strlen($option['code']) > 0) {
                    $optionCode = (string)$option['code'];
                }

                if (strlen($option['valueCode']) > 0) {
                    $optionValueCode = (string)$option['valueCode'];
                }

                $optionsName  = '';
                $optionsValue = '';

                foreach ($this->getOptionsTranslation($option) as $translation) {
                    $optionsName      = trim((string)$translation->OptionName);
                    $optionsValue     = trim((string)$translation->OptionValue);
                    $optionsValueSort = 0;

                    if ((int)$translation->OptionValue['sort'] > 0) {
                        $optionsValueSort = (int)$translation->OptionValue['sort'];
                    }
                }

                if (strlen($optionsName) > 0 && strlen($optionsValue) > 0) {
                    $counter++;
                    $groupModel  = (new Group())->getGroupModel($optionsName, $groupId, $groupSort);
                    $optionModel = (new Option())->getOptionModel($groupModel, $optionsValue, $valueId, $optionsValueSort, $optionCode);

                    if ($counter < count($variationXmlElement->Options->Option)) {
                        $additionalText .= $optionsValue . ' / ';
                    } else {
                        $additionalText .= $optionsValue;
                    }

                    $this->addGroupModel($groupModel);
                    $this->addOptionModel($optionModel);

                    /** @var string $savingOptionCodeAttributeFieldName */
                    $savingOptionCodeAttributeFieldName = ConfigManager::getInstance()->getSavingOptionCodeAttributeFieldName();

                    if ($savingOptionCodeAttributeFieldName !== '' && $optionValueCode !== '') {
                        $this->setValueFromCodeField($optionModel, $savingOptionCodeAttributeFieldName, $optionValueCode);
                    }
                } else {
                    LogManager::getInstance()
                        ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__,
                            str_replace(array('{$variationItemNumber}', '{$productId}'), array((string)$variationXmlElement->VariationItemNumber, $productId),
                                ErrorCodes::PRODUCTS_VARIATIONS_CONFIGURATOR_ITEM), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, $productId,
                            ErrorCodes::PRODUCTS_VARIATIONS_CONFIGURATOR_ITEM_ERROR_CODE);
                }
            }

            $this->setAdditionalText($additionalText);
            $this->getDetail()->setConfiguratorOptions($this->getOptionArray());

            if (count($this->getOptionArray()) > 0 && count($this->getGroupsArray()) > 0) {
                $this->setGroupsIds($this->getGroupsArray());
                $this->setOptionIds($this->getOptionArray());
            }
        }

        $this->setOptionsToDetailsRelations(array(
            'bfVariationID'                            => (string)$variationXmlElement->VariationId,
            'detailID::' . $this->getDetail()->getId() => $this->getOptionArray()
        ));

        return $this->getAdditionalText();
    }

    /**
     * @param SwOption $optionModel
     * @param string $savingOptionCodeAttributeFieldName
     * @param string $optionCode
     * @return void
     * @throws \Doctrine\ORM\ORMException
     */
    private function setValueFromCodeField(SwOption $optionModel, $savingOptionCodeAttributeFieldName, $optionCode)
    {
        /** @var ConfiguratorOptionAttribute $repository */
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Attribute\ConfiguratorOption');

        /** @var ConfiguratorOptionAttribute $configuratorOptionAttribute */
        $configuratorOptionAttribute = $repository->findOneBy(['configuratorOptionId' => $optionModel->getId()]);

        if ($configuratorOptionAttribute === null) {
            $configuratorOptionAttribute = new ConfiguratorOptionAttribute();
        }

        $configuratorOptionAttribute->{$this->getFunctionNameForSetOptionAttributeValue($savingOptionCodeAttributeFieldName)}($optionCode);
        Shopware()->Models()->persist($configuratorOptionAttribute);

        $optionModel->setAttribute($configuratorOptionAttribute);
        Shopware()->Models()->persist($optionModel);
    }

    /**
     * @param string $savingOptionCodeAttributeFieldName
     * @return string
     */
    private function getFunctionNameForSetOptionAttributeValue($savingOptionCodeAttributeFieldName)
    {
        $name = 'set';
        $name .= lcfirst(str_replace('_', '', ucwords($savingOptionCodeAttributeFieldName, '_')));

        return $name;
    }

    /**
     * @param SimpleXMLElement $options
     *
     * @return array
     */
    private function getOptionsTranslation(SimpleXMLElement $options)
    {
        $optionsTranslation = array();

        foreach ($options->Translations->Translation as $translation) {
            if (in_array((string)$translation['lang'], Helper::getMainLanguagesCode()) === true) {
                $optionsTranslation[] = $translation;
            }
        }

        return $optionsTranslation;
    }
}
