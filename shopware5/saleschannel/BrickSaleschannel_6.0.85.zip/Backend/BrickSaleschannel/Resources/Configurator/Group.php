<?php
namespace Bf\Saleschannel\Components\Resources\Configurator;

/**
 * Group
 *
 * @package Bf\Saleschannel\Components\Resources\Configurator
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Configurator;

use Bf\Saleschannel\Components\Util\Helper;
use Shopware\Models\Article\Configurator\Group as SwGroup;

class Group
{
    /**
     * @param string $GroupName
     * @param int $groupId
     * @param int $groupSort
     *
     * @return null|object|SwGroup
     */
    public function getGroupModel($GroupName, $groupId, $groupSort)
    {
        $mappingConfiguratorGroupsRepository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingConfiguratorGroups');
        /** @var \Shopware\CustomModels\BfSaleschannel\MappingConfiguratorGroups $mappingConfiguratorGroupsModel */
        $mappingConfiguratorGroupsModel = $mappingConfiguratorGroupsRepository->findOneBy(array('brickfoxId' => $groupId));

        if($mappingConfiguratorGroupsModel === null)
        {
            $repository = Helper::getRepository('Shopware\Models\Article\Configurator\Group');
            /** @var \Shopware\Models\Article\Configurator\Group $groupModel */
            $groupModel = $repository->findOneBy(array('name' => $GroupName));

            if($groupModel === null)
            {
                $groupModel = $this->setGroupModel($GroupName, $groupId, $groupSort);
            }
            else
            {
                Shopware()->Db()->query(
                    "insert into bf_mapping_configurator_groups (`brickfoxID`, `shopwareID`, `date_insert`) VALUES (?,?,?)",
                    array($groupId, $groupModel->getId(), date('y-m-d h:i:s', time()))
                );
            }
        }
        else
        {
            $groupRepository = Shopware()->Models()->getRepository('Shopware\Models\Article\Configurator\Group');
            /** @var \Shopware\Models\Article\Configurator\Group $groupModel */
            $groupModel = $groupRepository->findOneBy(array('id' => $mappingConfiguratorGroupsModel->getShopwareId()));
            $groupModel->setPosition($groupSort);

            if(trim($groupModel->getName()) !== trim($GroupName))
            {
                $groupModel->setName($GroupName);
            }

            Shopware()->Models()->persist($groupModel);
        }

        return $groupModel;
    }

    /**
     * @param string $GroupName
     * @param int $bfGroupId
     * @param int $groupSort
     *
     * @return SwGroup
     */
    private function setGroupModel($GroupName, $bfGroupId, $groupSort)
    {
        $repository = Helper::getRepository('Shopware\Models\Article\Configurator\Group');

        //try to load group again
        $groupId = Shopware()->Db()->fetchOne(
            "select id from s_article_configurator_groups where name = ?",
            array($GroupName)
        );

        if($groupId === null || $groupId === false || (int) $groupId <= 0)
        {
            // workaround because if we flush here, we flush all the persisted models
            Shopware()->Db()->query(
                "insert into s_article_configurator_groups (name, position) values(?,?)",
                array($GroupName, $groupSort)
            );

            $groupModel = $repository->findOneBy(array('name' => $GroupName));
        }
        else
        {
            $groupModel = $repository->findOneBy(array('id' => (int) $groupId));
        }

        Shopware()->Db()->query(
            "insert into bf_mapping_configurator_groups (`brickfoxID`, `shopwareID`, `date_insert`) VALUES (?,?,?)",
            array($bfGroupId, $groupModel->getId(), date('y-m-d h:i:s', time()))
        );

        return $groupModel;
    }
}
