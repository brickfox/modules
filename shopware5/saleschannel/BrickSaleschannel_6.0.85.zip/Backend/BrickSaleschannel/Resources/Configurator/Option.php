<?php

namespace Bf\Saleschannel\Components\Resources\Configurator;

use Bf\Saleschannel\Components\Util\Helper;
use Shopware\Models\Article\Configurator\Group as SwGroup;
use Shopware\Models\Article\Configurator\Option as SwOption;

/**
 * Option
 *
 * @package Bf\Saleschannel\Components\Resources\Configurator
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Option
{
    /**
     * @param SwGroup $group
     * @param string $optionsValue
     * @param int $valueId
     * @param int $optionsValueSort
     * @param string $optionCode
     *
     * @return null|object|SwOption
     */
    public function getOptionModel(SwGroup $group, $optionsValue, $valueId, $optionsValueSort, $optionCode = '')
    {
        $mappingConfiguratorOptionsRepository = Helper::getRepository('\Shopware\CustomModels\BfSaleschannel\MappingConfiguratorOptions');
        /** @var \Shopware\CustomModels\BfSaleschannel\MappingConfiguratorOptions $mappingConfiguratorOptionsModel */
        $mappingConfiguratorOptionsModel = $mappingConfiguratorOptionsRepository->findOneBy(array('brickfoxId' => $valueId));

        if ($mappingConfiguratorOptionsModel === null) {
            $repository  = Helper::getRepository('Shopware\Models\Article\Configurator\Option');
            $optionModel = $repository->findOneBy(array('groupId' => $group->getId(), 'name' => $optionsValue));

            if ($optionModel === null) {
                $optionModel = $this->setOptionModel($group, $optionsValue, $valueId, $optionsValueSort, $optionCode);
            } else {
                Shopware()
                    ->Db()
                    ->query("insert into bf_mapping_configurator_options (`brickfoxID`, `shopwareID`, `brickfox_diffs_options_code`,`date_insert`) VALUES (?,?,?,?)",
                        array($valueId, $optionModel->getId(), $optionCode, date('y-m-d h:i:s', time())));
            }
        } else {
            $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Configurator\Option');
            /** @var \Shopware\Models\Article\Configurator\Option $optionModel */
            $optionModel = $repository->findOneBy(array('id' => $mappingConfiguratorOptionsModel->getShopwareId()));

            if ($optionModel === null) {
                $optionModel = $this->setOptionModel($group, $optionsValue, $valueId, $optionsValueSort, $optionCode);
            }

            if (trim($optionModel->getName()) !== trim($optionsValue)) {
                $duplicateOptionModel = $repository->findOneBy(array('groupId' => $group->getId(), 'name' => $optionsValue));

                if ($duplicateOptionModel === null) {
                    $optionModel->setName($optionsValue);
                    $optionModel->setPosition($optionsValueSort);

                    Shopware()->Models()->persist($optionModel);
                } else {
                    Shopware()
                        ->Db()
                        ->query("UPDATE bf_mapping_configurator_options set `shopwareID` = ?, `brickfox_diffs_options_code` = ? WHERE `id` = ?",
                            array($duplicateOptionModel->getId(), $optionCode, $mappingConfiguratorOptionsModel->getId()));
                }
            } else {
                $optionModel->setPosition($optionsValueSort);

                Shopware()->Models()->persist($optionModel);
            }

            if ($optionCode !== $mappingConfiguratorOptionsModel->getBrickfoxDiffsOptionsCode()) {
                Shopware()
                    ->Db()
                    ->query("UPDATE bf_mapping_configurator_options set brickfox_diffs_options_code = ? where id = ?",
                        array($optionCode, $mappingConfiguratorOptionsModel->getId()));
            }
        }

        return $optionModel;
    }

    /**
     * @param SwGroup $group
     * @param string $optionsValue
     * @param int $bfOptionId
     * @param int $optionsValueSort
     * @param $optionCode
     *
     * @return SwOption
     */
    private function setOptionModel(SwGroup $group, $optionsValue, $bfOptionId, $optionsValueSort, $optionCode)
    {
        // workaround because if we flush here, we flush all the persisted models
        Shopware()
            ->Db()
            ->query("insert into s_article_configurator_options (group_id, `name`, `position`) values (?,?,?)", array($group->getId(), $optionsValue, $optionsValueSort));

        $repository  = Helper::getRepository('Shopware\Models\Article\Configurator\Option');
        $optionModel = $repository->findOneBy(array('groupId' => $group->getId(), 'name' => $optionsValue));

        Shopware()
            ->Db()
            ->query("insert into bf_mapping_configurator_options (`brickfoxID`, `shopwareID`, `brickfox_diffs_options_code`,`date_insert`) VALUES (?,?,?,?)",
                array($bfOptionId, $optionModel->getId(), $optionCode, date('y-m-d h:i:s', time())));

        return $optionModel;
    }
}
