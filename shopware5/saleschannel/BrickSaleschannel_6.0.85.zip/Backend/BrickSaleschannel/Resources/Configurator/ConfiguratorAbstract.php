<?php
namespace Bf\Saleschannel\Components\Resources\Configurator;

use Shopware\Models\Article\Detail as SwDetail;
use Shopware\Models\Article\Configurator\Group as SwGroup;
use Shopware\Models\Article\Configurator\Option as SwOption;

/**
 * ConfiguratorAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Configurator
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class ConfiguratorAbstract
{
    const TYPE_GROUP   = 'group';
    const TYPE_OPTIONS = 'option';

    /** @var array */
    private $arrayCollection = array();

    /** @var array */
    private $groupsIds = array();

    /** @var array */
    private $optionIds = array();

    /** @var array */
    private $optionsToDetailsRelations = array();

    private $variationsXmlElement;

    private $detail;

    /** @var string */
    private $additionalText = '';

    /** @var int */
    private $counter = 1;

    /** @var array */
    private $optionArray = array();

    /** @var array */
    private $groupsArray = array();

    /**
     * @param array $array
     *
     * @return array
     */
    public function prepareConfiguratorRelations(array $array = array(), $type = self::TYPE_GROUP)
    {
        $collection = array();
        $names      = array();
        $groupOrOptionType = $type;

        if(count($array) > 0)
        {
            foreach($array as $dataSet)
            {
                if(is_array($dataSet) === true)
                {
                    /** @var  \Shopware\Models\Article\Configurator\Option|\Shopware\Models\Article\Configurator\Group $data */
                    $closure = function ($data) use (&$collection, &$names, &$groupOrOptionType)
                    {
                        switch($groupOrOptionType)
                        {
                            case self::TYPE_GROUP:
                                if(in_array($data->getName(), $names) === false)
                                {
                                    $collection[] = $data;
                                    $names[]      = $data->getName();
                                }
                                break;

                            case self::TYPE_OPTIONS:
                                $collection[] = $data;
                                $names[]      = $data->getName();
                                break;
                        }
                    };

                    array_walk($dataSet, $closure);
                }
            }
        }

        unset($names);

        return $collection;
    }

    /**
     * @return string
     */
    public function getAdditionalText()
    {
        return $this->additionalText;
    }

    /**
     * @param string $additionalText
     *
     * @return ConfiguratorAbstract
     */
    public function setAdditionalText($additionalText)
    {
        $this->additionalText = $additionalText;

        return $this;
    }

    /**
     * @return int
     */
    public function getCounter()
    {
        return $this->counter;
    }

    /**
     * @param int $counter
     *
     * @return ConfiguratorAbstract
     */
    public function setCounter($counter)
    {
        $this->counter = $counter;

        return $this;
    }

    /**
     * @return array
     */
    public function getOptionArray()
    {
        return $this->optionArray;
    }

    /**
     * @param array|SwOption $optionArray
     *
     * @return ConfiguratorAbstract
     */
    public function setOptionArray($optionArray)
    {
        $this->optionArray = $optionArray;

        return $this;
    }

    /**
     * @param SwOption $optionModel
     *
     * @return ConfiguratorAbstract
     */
    public function addOptionModel($optionModel)
    {
        $this->optionArray[] = $optionModel;

        return $this;
    }

    /**
     * @return ConfiguratorAbstract
     */
    public function resetOptionArray()
    {
        $this->optionArray = array();

        return $this;
    }

    /**
     * @return array
     */
    public function getGroupsArray()
    {
        return $this->groupsArray;
    }

    /**
     * @param array|SwGroup $groupsArray
     *
     * @return ConfiguratorAbstract
     */
    public function setGroupsArray($groupsArray)
    {
        $this->groupsArray[] = $groupsArray;

        return $this;
    }

    /**
     * @param SwGroup $groupModel
     *
     * @return ConfiguratorAbstract
     */
    public function addGroupModel($groupModel)
    {
        $this->groupsArray[] = $groupModel;

        return $this;
    }

    /**
     * @return ConfiguratorAbstract
     */
    public function resetGroupArray()
    {
        $this->groupsArray = array();

        return $this;
    }

    /**
     * @return mixed
     */
    public function getVariationsXmlElement()
    {
        return $this->variationsXmlElement;
    }

    /**
     * @param mixed $variationsXmlElement
     *
     * @return ConfiguratorAbstract
     */
    public function setVariationsXmlElement($variationsXmlElement)
    {
        $this->variationsXmlElement = $variationsXmlElement;

        return $this;
    }

    /**
     * @return SwDetail
     */
    public function getDetail()
    {
        return $this->detail;
    }

    /**
     * @param mixed $detail
     *
     * @return ConfiguratorAbstract
     */
    public function setDetail($detail)
    {
        $this->detail = $detail;

        return $this;
    }

    /**
     * @return array
     */
    public function getArrayCollection()
    {
        return $this->arrayCollection;
    }

    /**
     * @param array $arrayCollection
     *
     * @return ConfiguratorAbstract
     */
    public function setArrayCollection($arrayCollection)
    {
        $this->arrayCollection = $arrayCollection;

        return $this;
    }

    /**
     * @return array
     */
    public function getGroupsIds()
    {
        return $this->groupsIds;
    }

    /**
     * @param array $groupsIds
     *
     * @return ConfiguratorAbstract
     */
    public function setGroupsIds($groupsIds)
    {
        $this->groupsIds[] = $groupsIds;

        return $this;
    }

    /**
     * @return array
     */
    public function getOptionIds()
    {
        return $this->optionIds;
    }

    /**
     * @param array $optionIds
     *
     * @return ConfiguratorAbstract
     */
    public function setOptionIds($optionIds)
    {
        $this->optionIds[] = $optionIds;

        return $this;
    }

    public function resetOptionIds()
    {
        $this->optionIds = array();
    }

    public function resetGroupIds()
    {
        $this->groupsIds = array();
    }

    /**
     * @return array
     */
    public function getOptionsToDetailsRelations()
    {
        return $this->optionsToDetailsRelations;
    }

    /**
     * @param array $optionsToDetailsRelations
     *
     * @return ConfiguratorAbstract
     */
    public function setOptionsToDetailsRelations($optionsToDetailsRelations)
    {
        $this->optionsToDetailsRelations[$optionsToDetailsRelations['bfVariationID']] = $optionsToDetailsRelations;

        return $this;
    }
}
