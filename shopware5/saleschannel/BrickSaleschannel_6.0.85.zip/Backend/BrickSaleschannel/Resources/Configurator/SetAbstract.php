<?php
namespace Bf\Saleschannel\Components\Resources\Configurator;

use Bf\Saleschannel\Components\Resources\ImportAbstract;
use Bf\Saleschannel\Components\Util\Helper;
use Shopware\Models\Article\Article as SwArticle;
use Shopware\Models\Article\Configurator\Set as SwSet;

/**
 * SetAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Configurator
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class SetAbstract extends ImportAbstract
{
    /** @var null */
    private $setModel = null;

    /**
     * @return void
     */
    public function loadSetModel()
    {
        $repository = Helper::getRepository('Shopware\Models\Article\Configurator\Set');
        $setModel   = $repository->findOneBy(array('name' => $this->getArticle()->getMainDetail()->getNumber()));

        if($setModel === null)
        {
            $setModel = new SwSet();
            $setModel->setName($this->getArticle()->getMainDetail()->getNumber());
        }

        $this->setSetModel($setModel);
    }

    /**
     * @return null|\Shopware\Models\Article\Configurator\Set
     */
    public function getSetModel()
    {
        return $this->setModel;
    }

    /**
     * @param null $setModel
     *
     * @return SetAbstract
     */
    public function setSetModel($setModel)
    {
        $this->setModel = $setModel;

        return $this;
    }

    /**
     * @param SwArticle $article
     */
    abstract public function __construct(SwArticle $article);

    /**
     * @return void
     */
    public function __destruct()
    {
        parent::__destruct();
    }
}
