<?php
namespace Bf\Saleschannel\Components\Resources;

/**
 * ImportAbstract
 *
 * @package Bf\Saleschannel\Components\Resources
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class ImportAbstract
{
    /** @var null */
    private $article = null;

    /** @var null */
    private $detail = null;

    /** @var null */
    private $simpleXmlElement = null;

    /**
     * @return null|\Shopware\Models\Article\Article
     */
    public function getArticle()
    {
        return $this->article;
    }

    /**
     * @param null|\Shopware\Models\Article\Article $article
     *
     * @return ImportAbstract
     */
    public function setArticle($article)
    {
        $this->article = $article;

        return $this;
    }

    /**
     * @return null|\Shopware\Models\Article\Detail
     */
    public function getDetail()
    {
        return $this->detail;
    }

    /**
     * @param null|\Shopware\Models\Article\Detail $detail
     *
     * @return ImportAbstract
     */
    public function setDetail($detail)
    {
        $this->detail = $detail;

        return $this;
    }

    /**
     * @return null|\SimpleXmlElement
     */
    public function getSimpleXmlElement()
    {
        return $this->simpleXmlElement;
    }

    /**
     * @param null|\SimpleXmlElement $simpleXmlElement
     *
     * @return ImportAbstract
     */
    public function setSimpleXmlElement($simpleXmlElement)
    {
        $this->simpleXmlElement = $simpleXmlElement;

        return $this;
    }

    /**
     * @param $xmlElement
     * @param $elements (...->Attributes->String)
     *
     * @return bool
     */
    public function isElementAvailable($xmlElement, $elements)
    {
        $available = false;

        if((bool) $xmlElement->$elements === true)
        {
            $available = true;
        }

        return $available;
    }

    public function __destruct()
    {
        $this->setSimpleXmlElement(null);
        $this->setArticle(null);
        $this->setDetail(null);
    }
}
