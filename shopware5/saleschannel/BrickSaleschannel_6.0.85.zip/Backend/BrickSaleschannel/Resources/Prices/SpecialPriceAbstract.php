<?php
/**
 * SpecialPriceAbstract.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Prices;

use Shopware\CustomModels\BfSaleschannel\SpecialPrices;

abstract class SpecialPriceAbstract
{
    /** @var string */
    private $specialPriceStartDate = '0000-00-00 00:00:00';

    /** @var string */
    private $specialPriceEndDate = '0000-00-00 00:00:00';

    /** @var int */
    private $specialPrice = 0;

    /** @var int */
    private $price = 0;

    /** @var int */
    private $active = 0;

    /** @var string */
    private $dateInsert = '';

    /** @var string */
    private $lastUpdate = '';

    /** @var string */
    private $customerGroup = '';

    /** @var SpecialPrices */
    private $bfSpecialPrice = null;

    /** @var int */
    private $uvp = 0;

    /**
     * SpecialPriceAbstract constructor.
     *
     * @param        $price
     * @param        $specialPrice
     * @param        $customerGroup
     * @param string $specialPriceStartDate
     * @param string $specialPriceEndDate
     * @param        $uvp
     */
    public function __construct($price, $specialPrice, $customerGroup, $specialPriceStartDate = '', $specialPriceEndDate = '', $uvp)
    {
        $this->price                 = $price;
        $this->specialPrice          = $specialPrice;
        $this->customerGroup         = $customerGroup;
        $this->specialPriceStartDate = $specialPriceStartDate;
        $this->specialPriceEndDate   = $specialPriceEndDate;
        $this->dateInsert            = date('Y-m-d H:i:s', time());
        $this->lastUpdate            = date('Y-m-d H:i:s', time());
        $this->uvp                   = $uvp;
    }

    public function __destruct()
    {
        $this->price                 = null;
        $this->specialPrice          = null;
        $this->customerGroup         = null;
        $this->specialPriceStartDate = null;
        $this->specialPriceEndDate   = null;
    }

    /**
     * @param array $attributes
     *
     * @return void
     */
    protected function loadSpecialPrice(array $attributes = array())
    {
        $this->bfSpecialPrice = new SpecialPrices();
        $this->bfSpecialPrice = $this->bfSpecialPrice->loadByAndSet($attributes);
    }

    /**
     * @return string
     */
    public function getSpecialPriceStartDate()
    {
        return $this->specialPriceStartDate;
    }

    /**
     * @param string $specialPriceStartDate
     */
    public function setSpecialPriceStartDate($specialPriceStartDate)
    {
        $this->specialPriceStartDate = $specialPriceStartDate;
    }

    /**
     * @return string
     */
    public function getSpecialPriceEndDate()
    {
        return $this->specialPriceEndDate;
    }

    /**
     * @param string $specialPriceEndDate
     */
    public function setSpecialPriceEndDate($specialPriceEndDate)
    {
        $this->specialPriceEndDate = $specialPriceEndDate;
    }

    /**
     * @return int
     */
    public function getSpecialPrice()
    {
        return $this->specialPrice;
    }

    /**
     * @param int $specialPrice
     */
    public function setSpecialPrice($specialPrice)
    {
        $this->specialPrice = $specialPrice;
    }

    /**
     * @return int
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * @param int $price
     */
    public function setPrice($price)
    {
        $this->price = $price;
    }

    /**
     * @return int
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * @param int $active
     */
    public function setActive($active)
    {
        $this->active = $active;
    }

    /**
     * @return string
     */
    public function getDateInsert()
    {
        return $this->dateInsert;
    }

    /**
     * @param string $dateInsert
     */
    public function setDateInsert($dateInsert)
    {
        $this->dateInsert = $dateInsert;
    }

    /**
     * @return string
     */
    public function getLastUpdate()
    {
        return $this->lastUpdate;
    }

    /**
     * @param string $lastUpdate
     */
    public function setLastUpdate($lastUpdate)
    {
        $this->lastUpdate = $lastUpdate;
    }

    /**
     * @return string
     */
    public function getCustomerGroup()
    {
        return $this->customerGroup;
    }

    /**
     * @param string $customerGroup
     */
    public function setCustomerGroup($customerGroup)
    {
        $this->customerGroup = $customerGroup;
    }

    /**
     * @return SpecialPrices
     */
    public function getBfSpecialPrice()
    {
        return $this->bfSpecialPrice;
    }

    /**
     * @param SpecialPrices $bfSpecialPrice
     */
    public function setBfSpecialPrice($bfSpecialPrice)
    {
        $this->bfSpecialPrice = $bfSpecialPrice;
    }

    /**
     * @return int
     */
    public function getUvp()
    {
        return $this->uvp;
    }

    /**
     * @param int $uvp
     */
    public function setUvp($uvp)
    {
        $this->uvp = $uvp;
    }
}