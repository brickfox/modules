<?php
namespace Bf\Saleschannel\Components\Resources\Prices;

/**
 * Class SpecialPrices
 *
 * @package Bf\Saleschannel\Components\Resources\Prices
 */
class SpecialPrices extends SpecialPriceAbstract
{
    const SPECIAL_PRICE_START_AND_END_GIVEN     = 1;
    const SPECIAL_PRICE_START_GIVEN             = 2;
    const SPECIAL_PRICE_END_GIVEN               = 3;
    const SPECIAL_PRICE_START_AND_END_NOT_GIVEN = 4;

    /** @var int */
    private $specialPriceMode = 1;

    /**
     * SpecialPrices constructor.
     *
     * @param        $price
     * @param        $specialPrice
     * @param        $customerGroup
     * @param string $specialPriceStartDate
     * @param string $specialPriceEndDate
     * @param        $uvp
     */
    public function __construct($price, $specialPrice, $customerGroup, $specialPriceStartDate = '', $specialPriceEndDate = '', $uvp)
    {
        parent::__construct($price, $specialPrice, $customerGroup, $specialPriceStartDate, $specialPriceEndDate, $uvp);
    }

    /**
     * @param array $attributes
     *
     * @return void
     */
    public function loadSpecialPrice(array $attributes = array())
    {
        parent::loadSpecialPrice($attributes);

        if($this->getBfSpecialPrice()->isLoaded() === false)
        {
            $this->getBfSpecialPrice()->setCurrencyCode($this->getCustomerGroup());
            $this->getBfSpecialPrice()->setDateInsert($this->getDateInsert());
        }
    }

    /**
     * @return array
     */
    public function prepareSpecialPriceData()
    {
        $pricesResult = array(
            'pseudoPrice' => 0,
            'price'       => $this->getPrice(),
            'isSpecialPriceActive' => false
        );

        switch($this->getSpecialPriceMode())
        {
            case self::SPECIAL_PRICE_START_AND_END_GIVEN:
                $specialPriceStart = $this->getSpecialPriceStartDate();
                $specialPriceEnd   = $this->getSpecialPriceEndDate();
                break;

            case self::SPECIAL_PRICE_START_GIVEN:
                $specialPriceStart = $this->getSpecialPriceStartDate();
                $specialPriceEnd   = null;
                break;

            case self::SPECIAL_PRICE_END_GIVEN:
                $specialPriceStart = null;
                $specialPriceEnd   = $this->getSpecialPriceEndDate();
                break;

            default:
                $specialPriceStart = null;
                $specialPriceEnd   = null;
                break;
        }

        $this->getBfSpecialPrice()->setSpecialPriceStart($specialPriceStart);
        $this->getBfSpecialPrice()->setSpecialPriceEnd($specialPriceEnd);
        $this->getBfSpecialPrice()->setSpecialPrice($this->getSpecialPrice());
        $this->getBfSpecialPrice()->setPrice($this->getPrice());
        $this->getBfSpecialPrice()->setLastUpdate($this->getLastUpdate());
        $this->getBfSpecialPrice()->setActive($this->getActive());
        $this->getBfSpecialPrice()->setUvp($this->getUvp());
        $this->calculateSpecialPrice();

        if($this->getActive() === 1)
        {
            $this->getBfSpecialPrice()->setActive($this->getActive());
            $pricesResult['pseudoPrice'] = $this->getBfSpecialPrice()->getPrice();
            $pricesResult['price']       = $this->getBfSpecialPrice()->getSpecialPrice();
            $pricesResult['isSpecialPriceActive'] = true;
        }

        Shopware()->Models()->persist($this->getBfSpecialPrice());

        return $pricesResult;
    }

    /**
     * @return int
     */
    public function calculateSpecialPrice()
    {
        if($this->getSpecialPriceMode() === self::SPECIAL_PRICE_START_AND_END_GIVEN)
        {
            if(strtotime($this->getBfSpecialPrice()->getSpecialPriceStart()) < time() && strtotime($this->getBfSpecialPrice()->getSpecialPriceEnd()) > time())
            {
                $this->setActive(1);
            }
        }
        elseif($this->getSpecialPriceMode() === self::SPECIAL_PRICE_START_GIVEN)
        {
            if(strtotime($this->getBfSpecialPrice()->getSpecialPriceStart()) < time())
            {
                $this->setActive(1);
            }
        }
        elseif($this->getSpecialPriceMode() === self::SPECIAL_PRICE_END_GIVEN)
        {
            if(strtotime($this->getBfSpecialPrice()->getSpecialPriceEnd()) > time())
            {
                $this->setActive(1);
            }
        }
        elseif($this->getSpecialPriceMode() === self::SPECIAL_PRICE_START_AND_END_NOT_GIVEN)
        {
            $this->setActive(1);
        }
    }

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     *
     * @return void
     */
    public function prepareSpecialPriceMode(\SimpleXMLElement $simpleXMLElement)
    {
        if((bool) $simpleXMLElement->SpecialPriceStart === true && (bool) $simpleXMLElement->SpecialPriceEnd === true)
        {
            $this->setSpecialPriceMode(self::SPECIAL_PRICE_START_AND_END_GIVEN);
        }
        elseif((bool) $simpleXMLElement->SpecialPriceStart === true && (bool) $simpleXMLElement->SpecialPriceEnd === false)
        {
            $this->setSpecialPriceMode(self::SPECIAL_PRICE_START_GIVEN);
        }
        elseif((bool) $simpleXMLElement->SpecialPriceStart === false && (bool) $simpleXMLElement->SpecialPriceEnd === true)
        {
            $this->setSpecialPriceMode(self::SPECIAL_PRICE_END_GIVEN);
        }
        else
        {
            $this->setSpecialPriceMode(self::SPECIAL_PRICE_START_AND_END_NOT_GIVEN);
        }
    }

    public function __destruct()
    {
        parent::__destruct();
        $this->specialPriceMode = null;
    }

    /**
     * @return int
     */
    public function getSpecialPriceMode()
    {
        return $this->specialPriceMode;
    }

    /**
     * @param int $specialPriceMode
     */
    public function setSpecialPriceMode($specialPriceMode)
    {
        $this->specialPriceMode = $specialPriceMode;
    }
}