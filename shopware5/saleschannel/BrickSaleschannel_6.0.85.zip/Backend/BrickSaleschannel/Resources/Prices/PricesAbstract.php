<?php
namespace Bf\Saleschannel\Components\Resources\Prices;

use Bf\Saleschannel\Components\Resources\ImportAbstract;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Exception;
use Shopware\CustomModels\BfSaleschannel\Log;
use SimpleXMLElement;
use Shopware\Models\Article\Price as SwPrices;
use Shopware\Models\Tax\Tax as SwTax;
use Shopware\Models\Customer\Group as SwGroup;

/**
 * PricesAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Prices
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class PricesAbstract extends ImportAbstract
{
    const DEFAULT_CURRENCY_GROUP_KEY = 'EK';
    const FILE_NAME                  = 'Prices.php';

    /** @var array */
    protected $scalePricesCollection = array();

    /** @var string */
    private $customerGroupKey = 'EK';

    /** @var null */
    private $currencyXmlElement = null;

    /** @var int */
    private $brickfoxShopsId = 0;

    /**
     * @param bool $preventPriceModelsRewrite
     * @return SwPrices
     */
    protected function loadPrices($preventPriceModelsRewrite = false)
    {
        $repository  = Helper::getRepository('Shopware\Models\Article\Price');
        // pricesModel will have 0 or 1 entry
        $pricesModel = $repository->findBy(array('articleDetailsId' => $this->getDetail()->getId(), 'customerGroupKey' => $this->getCustomerGroupKey()));

        if(count($pricesModel) === 0)
        {
            return new SwPrices();
        }

        if($preventPriceModelsRewrite === false) {
            foreach ($pricesModel as $priceModel) {
                Shopware()->Db()->query("delete from s_articles_prices where id = ?", [$priceModel->getId()]);
            }

            return new SwPrices();
        }

        // return existing entry
        return array_pop($pricesModel);
    }

    /**
     * @param SwPrices $prices
     *
     * @return float
     * @throws Exception
     */
    protected function priceToPseudoPrice(SwPrices $prices)
    {
        return $prices->getPrice();
    }

    /**
     * @param string $currencyCode
     *
     * @return bool
     */
    protected function checkIfCurrencyIsMapped($currencyCode = '')
    {
        $result = false;
        $customerGroupKeys = '';

        if (strlen($currencyCode) > 0) {
            $currenciesMappingModelRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingCurrencies');
            $currenciesMappingModels          = $currenciesMappingModelRepository->findBy(array('brickfoxCurrenciesCode' => $currencyCode));

            if (count($currenciesMappingModels) > 1) {
                $sCoreShopsModels = $this->getSwShopsModel();


                if (count($sCoreShopsModels) > 0) {
                    /** @var \Shopware\Models\Shop\Shop $sCoreShopsModel */
                    foreach ($sCoreShopsModels as $key => $sCoreShopsModel) {
                        if ($key === 0) {
                            $customerGroupKeys .= $sCoreShopsModel->getCustomerGroup()->getKey();
                        }  else {
                            $customerGroupKeys .= ',' . $sCoreShopsModel->getCustomerGroup()->getKey();
                        }
                    }
                }

                $result = true;

            } elseif (count($currenciesMappingModels) === 1) {
                /** @var \Shopware\CustomModels\BfSaleschannel\MappingCurrencies $currenciesMappingModel */
                $currenciesMappingModel = $currenciesMappingModels[0];
                $customerGroupKeys = $currenciesMappingModel->getMappingFieldKey();

                $result = true;
            }
        } else {
            LogManager::getInstance()
                ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__,
                    str_replace(array('{$brickfoxId}', '{$itemNumber}'), array((string)$this->getSimpleXmlElement()->ProductId, (string)$this->getSimpleXmlElement()->ItemNumber),
                        ErrorCodes::ORDERS_CURRENCY_CODE_IS_EMPTY), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId,
                    ErrorCodes::ORDERS_CURRENCY_CODE_IS_EMPTY_ERROR_CODE);
        }

        $this->setCustomerGroupKey($customerGroupKeys);

        return $result;
    }

    /**
     * @return array
     */
    private function getSwShopsModel()
    {
        $swShopsModel = array();

        $shopsMappingModelRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingShops');
        $shopsMappingModel = $shopsMappingModelRepository->findBy(array('brickfoxId' => $this->getBrickfoxShopsId()));

        if (count($shopsMappingModel) > 0) {
            /** @var \Shopware\CustomModels\BfSaleschannel\MappingShops $shopsModel */
            foreach($shopsMappingModel as $shopsModel) {
                $swShopsModel[] = $shopsModel->getShop();
            }
        }

        return $swShopsModel;
    }

    /**
     * @param $price
     * @param SwTax $tax
     * @param SwGroup $customerGroup
     * @param bool $isNetPrice
     *
     * @return string
     * @throws Exception
     */
    protected function priceToNetCalculate($price, SwTax $tax, SwGroup $customerGroup, $isNetPrice = false)
    {
        if($customerGroup->getTaxInput() === true && $isNetPrice === false)
        {
            $price = number_format($price / (1 + ($tax->getTax() / 100)), 8, '.', '');
        }

        return $price;
    }

    /**
     * @return array
     */
    public function getScalePricesCollection()
    {
        $sortArray = array();

        foreach($this->scalePricesCollection as $index => $scale)
        {
            foreach($scale as $key => $value)
            {
                if(!isset($sortArray[$key]))
                {
                    $sortArray[$key] = array();
                }

                $sortArray[$key][] = $value;
            }
        }

        $orderBy = 'quantity';

        array_multisort($sortArray[$orderBy], SORT_ASC, $this->scalePricesCollection);

        return $this->scalePricesCollection;
    }

    /**
     * @param array $scalePricesCollection
     * @param bool $preRemove
     *
     * @return $this
     */
    public function setScalePricesCollection($scalePricesCollection, $preRemove = false)
    {
        if($preRemove === false)
        {
            $this->scalePricesCollection[] = $scalePricesCollection;
        }
        else
        {
            $this->scalePricesCollection = array();
        }

        return $this;
    }

    /**
     * @return string
     */
    public function getCustomerGroupKey()
    {
        return $this->customerGroupKey;
    }

    /**
     * @param string $customerGroupKey
     *
     * @return $this
     */
    public function setCustomerGroupKey($customerGroupKey)
    {
        $this->customerGroupKey = $customerGroupKey;

        return $this;
    }

    /**
     * @return null|\SimpleXmlElement
     */
    public function getCurrencyXmlElement()
    {
        return $this->currencyXmlElement;
    }

    /**
     * @param null|\SimpleXmlElement $currencyXmlElement
     *
     * @return $this
     */
    public function setCurrencyXmlElement($currencyXmlElement)
    {
        $this->currencyXmlElement = $currencyXmlElement;

        return $this;
    }


    /**
     * @return int
     */
    public function getBrickfoxShopsId()
    {
        return $this->brickfoxShopsId;
    }

    /**
     * @param int $brickfoxShopsId
     */
    public function setBrickfoxShopsId($brickfoxShopsId)
    {
        $this->brickfoxShopsId = $brickfoxShopsId;
    }
}
