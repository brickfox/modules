<?php

namespace Bf\Saleschannel\Components\Resources\Prices;

use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Exceptions;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Exception;
use Shopware\CustomModels\BfSaleschannel\Log;
use Shopware\Models\Article\Detail as SwDetail;
use Shopware\Models\Article\Article as SwArticle;
use Shopware\Models\Tax\Tax as SwTax;
use Shopware\Models\Article\Price as SwPrices;

/**
 * Prices
 *
 * @package Bf\Saleschannel\Components\Resources\Prices
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Prices extends PricesAbstract
{
    const QUANTITY_OPTIONAL = 'beliebig';

    /**
     * @param $variationXmlElement
     * @param SwDetail $detail
     * @param SwArticle $article
     * @param int $brickfoxShopsId
     *
     * @return array
     * @throws \Exception
     */
    public function preparePrices($variationXmlElement, SwDetail $detail, SwArticle $article, $brickfoxShopsId = 0)
    {
        /** @var bool $preventPriceModelsRewrite */
        $preventPriceModelsRewrite = ConfigManager::getInstance()->getPreventPriceModelsRewrite();

        $pricesCollection  = [];
        $prices            = null;
        $customerGroupKeys = [];

        $this->setSimpleXmlElement($variationXmlElement);
        $this->setDetail($detail);
        $this->setArticle($article);
        $this->setBrickfoxShopsId($brickfoxShopsId);

        if ((bool)($this->getSimpleXmlElement()->Currencies) === false) {
            $customerGroupKeys[] = Helper::getConfigurationByKey('defaultCustomerGroup')->getConfigurationValue();
            $this->setCustomerGroupKey(Helper::getConfigurationByKey('defaultCustomerGroup')->getConfigurationValue());

            if ($this->hasScalePrices() === false) {
                $prices             = $this->prepareSinglePrice($preventPriceModelsRewrite);
                $pricesCollection[] = $prices;
            } else {
                $pricesCollection = $this->prepareMultiPrice($pricesCollection);
            }
        } else {
            foreach ($this->getSimpleXmlElement()->Currencies->Currency as $currency) {
                if ($this->checkIfCurrencyIsMapped((string)$currency['code']) === true) {
                    $this->setCurrencyXmlElement($currency);
                    $groupKeys = explode(',', $this->getCustomerGroupKey());

                    if (count($groupKeys) > 0) {
                        foreach ($groupKeys as $groupKey) {
                            if ($this->hasScalePrices() === false) {
                                $this->setCustomerGroupKey($groupKey);
                                $prices             = $this->prepareSinglePrice($preventPriceModelsRewrite);
                                $pricesCollection[] = $prices;
                            } else {
                                $pricesCollection = $this->prepareMultiPrice($pricesCollection);
                            }
                            $customerGroupKeys[] = $groupKey;
                        }
                    }
                } else {
                    LogManager::getInstance()
                        ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, ErrorCodes::MULTI_SHOP_CORRUPT_PRICES, Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                            (string)$this->getSimpleXmlElement()->ProductId, ErrorCodes::MULTI_SHOP_CORRUPT_PRICES_ERROR_CODE, false, false);
                }
            }
        }

        $priceList = $this->getAllNotImportedPrices($customerGroupKeys);

        if ($priceList !== null) {
            foreach ($priceList as $prices) {
                $pricesModelRepository = Shopware()->Models()->getRepository('Shopware\Models\Article\Price');
                /** @var \Shopware\Models\Article\Price $pricesModel */
                $pricesModel = $pricesModelRepository->find($prices['id']);

                if ($pricesModel !== null) {
                    if ($pricesModel->getAttribute() === null && class_exists('\Shopware\Models\Attribute\ArticlePrice')) {
                        /** @var \Shopware\Models\Attribute\ArticlePrice' $priceAttributesModel */
                        $priceAttributesModel = new \Shopware\Models\Attribute\ArticlePrice();
                        $priceAttributesModel->setArticlePriceId($pricesModel->getId());
                        Shopware()->Models()->persist($priceAttributesModel);
                    }
                    if($preventPriceModelsRewrite === false) {
                        $pricesCollection[] = clone $pricesModel;
                    } else {
                        $pricesCollection[] = $pricesModel;
                    }
                }
            }
        }

        $this->resetScalePriceCollection();

        return $pricesCollection;
    }

    /**
     * @param array $pricesCollection
     *
     * @return array
     * @throws \Exception
     */
    private function prepareMultiPrice(array $pricesCollection = [])
    {
        $preventPriceModelsRewrite = ConfigManager::getInstance()->getPreventPriceModelsRewrite();

        $lastScaleQuantity    = null;
        $scalePriceCollection = [];

        if ($this->getCurrencyXmlElement() === null) {
            $scalePriceCollection[1] = [
                'from' => 1,
                'to' => self::QUANTITY_OPTIONAL,
                'price' => (string)$this->getSimpleXmlElement()->PriceGross
            ];
            foreach ($this->getSimpleXmlElement()->ScalePrices->ScalePrice as $scalePrice) {
                $scalePriceCollection[(int)$scalePrice->Quantity]         = [
                    'from' => (int)$scalePrice->Quantity,
                    'to' => self::QUANTITY_OPTIONAL,
                    'price' => (string)$scalePrice->Price
                ];
            }
        } else {
            $scalePriceCollection[1] = [
                'from' => 1,
                'to' => self::QUANTITY_OPTIONAL,
                'price' => (string)$this->getCurrencyXmlElement()->PriceGross
            ];
            foreach ($this->getCurrencyXmlElement()->ScalePrices->ScalePrice as $scalePrice) {
                $scalePriceCollection[(int)$scalePrice->Quantity]         = [
                    'from' => (int)$scalePrice->Quantity,
                    'to' => self::QUANTITY_OPTIONAL,
                    'price' => (string)$scalePrice->Price
                ];
            }
        }

        // sort by key, then remove it
        ksort($scalePriceCollection);
        $scalePriceCollection = array_values($scalePriceCollection);

        foreach ($scalePriceCollection as $i => &$value) {
            if(isset($scalePriceCollection[$i+1]) === true) {
                $value['to'] = ($scalePriceCollection[$i+1]['from'] - 1);
            }
        }

        foreach ($scalePriceCollection as $scalePrices) {
            $prices = $this->loadPrices($preventPriceModelsRewrite);
            $prices->setCustomerGroup($this->getCustomerGroup());

            $prices->setFrom($scalePrices['from']);
            $prices->setTo($scalePrices['to']);
            $prices->setPrice($this->getPrice($this->getArticle()->getTax(), $scalePrices['price']));
            $prices->setPseudoPrice($this->getPseudoPrice($this->getArticle()->getTax(), $prices));
            $this->getDetail()->setPurchasePrice($this->getPurchasePrice());
            $prices->setArticle($this->getArticle());

            $pricesCollection[] = $prices;
        }

        return $pricesCollection;
    }

    /**
     * @param bool $overwriteExistingPrices
     * @return SwPrices
     * @throws \Exception
     */
    private function prepareSinglePrice($preventPriceModelsRewrite = false)
    {
        $prices = $this->loadPrices($preventPriceModelsRewrite);

        Exceptions::instanceOfException([
            'fileName' => self::FILE_NAME,
            [
                'param' => $prices,
                'obj'   => 'Shopware\Models\Article\Price'
            ]
        ]);

        $prices->setCustomerGroup($this->getCustomerGroup());
        $prices->setFrom(1);
        $prices->setPrice($this->getPrice($this->getArticle()->getTax()));
        $prices->setPseudoPrice($this->getPseudoPrice($this->getArticle()->getTax(), $prices));

        $this->getDetail()->setPurchasePrice($this->getPurchasePrice());
        $prices->setArticle($this->getArticle());

        return $prices;
    }

    /**
     * @param $scalePrice
     *
     * @return void
     */
    private function prepareScalePrices($scalePrice)
    {
        if ($scalePrice !== null) {
            if ((bool)$scalePrice->Quantity === true && (bool)$scalePrice->Price === true) {
                $this->setScalePricesCollection(['quantity' => (int)$scalePrice->Quantity - 1, 'price' => (string)$scalePrice->Price]);
            } else {
                $this->setScalePricesCollection([], true);
            }
        }
    }

    /**
     * @return void
     */
    private function resetScalePriceCollection()
    {
        $this->scalePricesCollection = [];
    }

    /**
     * @param $priceGross
     *
     * @return void
     */
    private function prepareStartScalePrice($priceGross)
    {
        $this->setScalePricesCollection(['quantity' => 1, 'price' => (float)$priceGross]);
    }

    /**
     * @return float|int
     */
    private function getPurchasePrice()
    {
        $purchasePrice = 0;

        if ((bool)$this->getSimpleXmlElement()->PrimeCost === true) {
            $purchasePrice = Helper::toFloat($this->getSimpleXmlElement()->PrimeCost);
        }

        return $purchasePrice;
    }

    /**
     * @param SwTax $tax
     * @param SwPrices $prices
     *
     * @return float|int|string
     * @throws Exception
     */
    private function getPseudoPrice(SwTax $tax, SwPrices $prices)
    {
        $pseudoPrice          = 0;
        $isSpecialPriceActive = false;

        $specialPriceEndDate = null;

        if ($this->getCurrencyXmlElement() === null) {
            if ((bool)$this->getSimpleXmlElement()->SpecialPrice === true && $prices->getFrom() === 1) {
                $specialPriceClass = new SpecialPrices(
                    $this->priceToPseudoPrice($prices),
                    $this->priceToNetCalculate((string)$this->getSimpleXmlElement()->SpecialPrice, $tax, $this->getCustomerGroup()), $this->getCustomerGroupKey(),
                    (string)$this->getSimpleXmlElement()->SpecialPriceStart,
                    (string)$this->getSimpleXmlElement()->SpecialPriceEnd,
                    (string)$this->getSimpleXmlElement()->Rrp === "" ? 0 : $this->priceToNetCalculate((string)$this->getSimpleXmlElement()->Rrp, $tax, $this->getCustomerGroup())
                );

                $specialPriceClass->loadSpecialPrice(['brickfoxId' => (int)$this->getSimpleXmlElement()->VariationId]);
                $specialPriceClass->prepareSpecialPriceMode($this->getSimpleXmlElement());
                $priceResult          = $specialPriceClass->prepareSpecialPriceData();
                $isSpecialPriceActive = $priceResult['isSpecialPriceActive'];

                $pseudoPrice = $priceResult['pseudoPrice'];

                $prices->setPrice($priceResult['price']);

                $specialPriceEndDate = (string)$this->getSimpleXmlElement()->SpecialPriceEnd;
            } elseif ((bool)$this->getSimpleXmlElement()->Rrp === true) {
                $pseudoPrice = Helper::toFloat($this->getSimpleXmlElement()->Rrp);
                $pseudoPrice = $this->priceToNetCalculate($pseudoPrice, $tax, $this->getCustomerGroup());
            }

            if ((bool)$this->getSimpleXmlElement()->SpecialPrice === true && $prices->getFrom() === 1 && (bool)$this->getSimpleXmlElement()->Rrp === true) {
                if ($isSpecialPriceActive === false) {
                    $pseudoPrice = Helper::toFloat($this->getSimpleXmlElement()->Rrp);
                    $pseudoPrice = $this->priceToNetCalculate($pseudoPrice, $tax, $this->getCustomerGroup());
                } else {
                    if (ConfigManager::getInstance()->getStrikeThroughPriceRules() == '1') {
                        $pseudoPrice = $this->priceToPseudoPrice($prices);
                    } elseif (ConfigManager::getInstance()->getStrikeThroughPriceRules() == '2') {
                        $pseudoPrice = Helper::toFloat($this->getSimpleXmlElement()->Rrp);
                        $pseudoPrice = $this->priceToNetCalculate($pseudoPrice, $tax, $this->getCustomerGroup());
                    }
                }
            }
        } else {
            if ((bool)$this->getCurrencyXmlElement()->SpecialPrice === true && $prices->getFrom() === 1) {
                $specialPriceClass = new SpecialPrices(
                    $this->priceToPseudoPrice($prices),
                    $this->priceToNetCalculate(
                        (string)$this->getCurrencyXmlElement()->SpecialPrice,
                        $tax,
                        $this->getCustomerGroup()
                    ),
                    $this->getCustomerGroupKey(),
                    (string)$this->getCurrencyXmlElement()->SpecialPriceStart,
                    (string)$this->getCurrencyXmlElement()->SpecialPriceEnd,
                    (string)$this->getCurrencyXmlElement()->Rrp === "" ?
                        0 : $this->priceToNetCalculate(
                        (string)$this->getCurrencyXmlElement()->Rrp,
                        $tax,
                        $this->getCustomerGroup()
                    )
                );

                $specialPriceClass->loadSpecialPrice([
                    'brickfoxId'   => (int)$this->getSimpleXmlElement()->VariationId,
                    'currencyCode' => $this->getCustomerGroupKey()
                ]);
                $specialPriceClass->prepareSpecialPriceMode($this->getCurrencyXmlElement());
                $priceResult          = $specialPriceClass->prepareSpecialPriceData();
                $isSpecialPriceActive = $priceResult['isSpecialPriceActive'];
                $pseudoPrice          = $priceResult['pseudoPrice'];

                $prices->setPrice($priceResult['price']);

                $specialPriceEndDate = (string)$this->getCurrencyXmlElement()->SpecialPriceEnd;
            } elseif ((bool)$this->getCurrencyXmlElement()->Rrp === true) {
                $pseudoPrice = Helper::toFloat($this->getCurrencyXmlElement()->Rrp);
                $pseudoPrice = $this->priceToNetCalculate($pseudoPrice, $tax, $this->getCustomerGroup());
            }

            if ((bool)$this->getCurrencyXmlElement()->SpecialPrice === true && $prices->getFrom() === 1 && (bool)$this->getCurrencyXmlElement()->Rrp === true) {
                if ($isSpecialPriceActive === false) {
                    $pseudoPrice = Helper::toFloat($this->getCurrencyXmlElement()->Rrp);
                    $pseudoPrice = $this->priceToNetCalculate($pseudoPrice, $tax, $this->getCustomerGroup());
                } else {
                    if (ConfigManager::getInstance()->getStrikeThroughPriceRules() == '1') {
                        $pseudoPrice = Helper::toFloat($this->getCurrencyXmlElement()->PriceGross);
                    } elseif (ConfigManager::getInstance()->getStrikeThroughPriceRules() == '2') {
                        $pseudoPrice = Helper::toFloat($this->getCurrencyXmlElement()->Rrp);
                        $pseudoPrice = $this->priceToNetCalculate($pseudoPrice, $tax, $this->getCustomerGroup());
                    }
                }
            }
        }

        if (
            Helper::getConfigurationByKey('specialPriceEndDateAttributeField') !== null &&
            strlen(($specialPriceEndDateAttributeField = Helper::getConfigurationByKey('specialPriceEndDateAttributeField')->getConfigurationValue())) > 0 &&
            strtotime($specialPriceEndDate) > 0
        ) {
            try {
                Shopware()->Db()->query(
                    "UPDATE s_articles_attributes SET " . $specialPriceEndDateAttributeField . " = ? WHERE articledetailsID = ?",
                    [$specialPriceEndDate, $this->getDetail()->getId()]
                );
            } catch (Exception $e) {
                LogManager::getInstance()
                    ->writeLogForGui(
                        Log::LOG_STATUS_ERROR,
                        __METHOD__,
                        ErrorCodes::SPECIAL_PRICE_END_DATE_ATTRIBUTE_FIELD_ERROR,
                        Helper::getUserName(),
                        Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                        (string)$this->getSimpleXmlElement()->ProductId,
                        ErrorCodes::SPECIAL_PRICE_END_DATE_ATTRIBUTE_FIELD_ERROR_CODE,
                        false,
                        false
                    );
            }
        }

        return $pseudoPrice;
    }

    /**
     * @param SwTax $tax
     * @param null $scalePrice
     *
     * @return float|int|string
     * @throws Exception
     */
    private function getPrice(SwTax $tax, $scalePrice = null)
    {
        if ($this->getCurrencyXmlElement() === null) {
            $price = Helper::toFloat($this->getSimpleXmlElement()->PriceGross);
        } else {
            Exceptions::instanceOfException([
                'fileName' => self::FILE_NAME,
                [
                    'param' => $this->getCurrencyXmlElement(),
                    'obj'   => 'SimpleXMLElement'
                ]
            ]);

            $price = Helper::toFloat($this->getCurrencyXmlElement()->PriceGross);
        }

        if ($scalePrice !== null) {
            $price = Helper::toFloat($scalePrice);
        }

        $price = $this->priceToNetCalculate($price, $tax, $this->getCustomerGroup());

        return $price;
    }

    /**
     * @return object|\Shopware\Models\Customer\Group
     * @throws Exception
     */
    private function getCustomerGroup()
    {
        $customerGroupModel = Helper::getMappingByValue($this->getCustomerGroupKey(), 'key', 'Shopware\Models\Customer\Group');

        $return = null;

        if ($customerGroupModel !== null) {
            $return = $customerGroupModel;
        } else {
            LogManager::getInstance()
                ->writeLogForGui(Log::LOG_STATUS_WARNING, __METHOD__, str_replace(['{$brickfoxId}', '{$itemNumber}', '{$customerGroupKey}'],
                    [(string)$this->getSimpleXmlElement()->ProductId, (string)$this->getSimpleXmlElement()->ItemNumber, $this->getCustomerGroupKey()],
                    ErrorCodes::ORDERS_CAN_NOT_LOAD_CUSTOMER_GROUP), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS, (string)$this->getSimpleXmlElement()->ProductId,
                    ErrorCodes::ORDERS_CAN_NOT_LOAD_CUSTOMER_GROUP_ERROR_CODE, false, false);

            if ($customerGroupModel === null) {
                $return = Helper::getMappingById('Shopware\Models\Customer\Group', 1);

                if ($return === null) {
                    LogManager::getInstance()
                        ->writeLogForGui(Log::LOG_STATUS_ERROR, __METHOD__, str_replace(['{$brickfoxId}', '{$itemNumber}'],
                            [(string)$this->getSimpleXmlElement()->ProductId, (string)$this->getSimpleXmlElement()->ItemNumber],
                            ErrorCodes::ORDERS_CAN_NOT_LOAD_DEFAULT_CUSTOMER_GROUP), Helper::getUserName(), Log::TYPE_OF_LOG_IMPORT_PRODUCTS,
                            (string)$this->getSimpleXmlElement()->ProductId, ErrorCodes::ORDERS_CAN_NOT_LOAD_DEFAULT_CUSTOMER_GROUP_ERROR_CODE);
                }
            }
        }

        return $return;
    }

    /**
     * @return bool
     */
    private function hasScalePrices()
    {
        $return = false;

        if ($this->getCurrencyXmlElement() === null && (bool)$this->getSimpleXmlElement()->ScalePrices === true) {
            $return = true;
        } elseif ($this->getCurrencyXmlElement() !== null && (bool)$this->getCurrencyXmlElement()->ScalePrices === true) {
            $return = true;
        }

        return $return;
    }

    /**
     * @param $customerGroupKeys
     *
     * @return array|null
     */
    private function getAllNotImportedPrices($customerGroupKeys)
    {
        $priceList    = null;
        $queryCounter = 1;

        if (count($customerGroupKeys) > 0) {
            $query = "select id from s_articles_prices where articleID = ? and articledetailsID = ? and (";

            foreach ($customerGroupKeys as $customerGroupKey) {
                if ($queryCounter === 1) {
                    $query .= " pricegroup != '" . $customerGroupKey . "'";
                } else {
                    $query .= " or pricegroup != '" . $customerGroupKey . "'";
                }

                $queryCounter++;
            }

            $query .= ')';

            $priceList = Shopware()->Db()->fetchAll($query, [$this->getArticle()->getId(), $this->getDetail()->getId()]);
        }

        return $priceList;
    }
}
