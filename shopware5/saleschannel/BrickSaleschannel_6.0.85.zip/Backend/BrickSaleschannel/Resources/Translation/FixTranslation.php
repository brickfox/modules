<?php
namespace Bf\Saleschannel\Components\Resources\Translation;

use PDO;

/**
 * Class FixTranslation
 *
 * @package Bf\Saleschannel\Components\Resources\Translation
 */
class FixTranslation extends \Shopware_Components_Translation
{
    const OBJECT_TYPE_ARTICLE = 'article';

    /** @var array */
    private $fixTranslationItemsList;

    public function __construct()
    {
        parent::__construct(Shopware()->Container()->get('dbal_connection'), Shopware()->Container());
        $this->fixTranslationItemsList = array();
    }

    public function __destruct()
    {
        $this->fixTranslationItemsList = array();
    }

    /**
     * @param array $processedArticleIds
     * @return void
     */
    public function prepareFixTranslation($processedArticleIds = [])
    {
        $this->setFixTranslationItemsList($this->getSCoreTranslations());

        if (count($this->getFixTranslationItemsList()) > 0) {
            foreach ($this->getFixTranslationItemsList() as $key => $translationItem) {
                try {
                    if (in_array($translationItem['objectkey'], $processedArticleIds)) {
                        $this->fixArticleTranslation($translationItem['objectlanguage'], $translationItem['objectkey'], $translationItem['objectdata']);
                    }
                } catch (\Exception $e) {

                }
            }
        }
    }

    /**
     * @param $languageId
     * @param $articleId
     * @param $data
     */
    private function executeFixTranslation($languageId, $articleId, $data)
    {
        $sql = "SELECT id FROM s_core_shops WHERE fallback_id = ?";
        $ids = Shopware()->Db()->fetchCol($sql, array($languageId));

        $existStmt = Shopware()->Container()->get('dbal_connection')->prepare(
            "SELECT id
             FROM s_core_translations
             WHERE objectlanguage = :language"
        );

        $insertStmt = Shopware()->Container()->get('dbal_connection')->prepare(
            "
          INSERT INTO `s_articles_translations` (articleID, languageID, name, keywords, description, description_long)
          VALUE (:articleId, :languageId, :name, :keywords, :description, :descriptionLong)
          ON DUPLICATE KEY UPDATE
              name = VALUES(name),
              keywords = VALUES(keywords),
              description = VALUES(description),
              description_long = VALUES(description_long);
        "
        );

        // prepare data
        $data = unserialize($data);
        if(!empty($data['txtlangbeschreibung']) && strlen($data['txtlangbeschreibung']) > 1000)
        {
            $data['txtlangbeschreibung'] = substr(strip_tags($data['txtlangbeschreibung']), 0, 1000);
        }
        $data['txtArtikel']          = isset($data['txtArtikel']) ? (string) $data['txtArtikel'] : '';
        $data['txtkeywords']         = isset($data['txtkeywords']) ? (string) $data['txtkeywords'] : '';
        $data['txtshortdescription'] = isset($data['txtshortdescription']) ? (string) $data['txtshortdescription'] : '';
        $data['txtlangbeschreibung'] = isset($data['txtlangbeschreibung']) ? (string) $data['txtlangbeschreibung'] : '';

        // Insert s_articles_translations entry for current locale
        $insertStmt->execute(
            array(
                ':articleId'       => $articleId,
                ':languageId'      => $languageId,
                ':name'            => $data['txtArtikel'],
                ':keywords'        => $data['txtkeywords'],
                ':description'     => $data['txtshortdescription'],
                ':descriptionLong' => $data['txtlangbeschreibung']
            )
        );

        // Insert s_articles_translations entry for fallbacks
        foreach($ids as $id)
        {
            $existStmt->execute(array(':language' => $id));
            $exist = $existStmt->fetch(PDO::FETCH_COLUMN);

            if($exist)
            {
                continue;
            }

            $insertStmt->execute(
                array(
                    ':articleId'       => $articleId,
                    ':languageId'      => $id,
                    ':name'            => $data['txtArtikel'],
                    ':keywords'        => $data['txtkeywords'],
                    ':description'     => $data['txtshortdescription'],
                    ':descriptionLong' => $data['txtlangbeschreibung']
                )
            );
        }
    }

    /**
     * @return array
     */
    private function getSCoreTranslations()
    {
        $sCoreTranslationItems = Shopware()->Db()->fetchAll(
            "
            select * from s_core_translations
            where objecttype = ?
            ",
            array(self::OBJECT_TYPE_ARTICLE)
        );

        return $sCoreTranslationItems;
    }

    /**
     * @return array
     */
    public function getFixTranslationItemsList()
    {
        return $this->fixTranslationItemsList;
    }

    /**
     * @param array $fixTranslationItemsList
     */
    public function setFixTranslationItemsList($fixTranslationItemsList)
    {
        $this->fixTranslationItemsList = $fixTranslationItemsList;
    }
}