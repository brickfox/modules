<?php

namespace Bf\Saleschannel\Components\Resources\Translation;

use Bf\Saleschannel\Components\Gui\Logging;
use Bf\Saleschannel\Components\Resources\ImportAbstract;
use Bf\Saleschannel\Components\Resources\MultiShop\MultiShopAbstract;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Shopware\CustomModels\BfSaleschannel\Log;
use Shopware\Models\Translation\Translation as SwTranslation;

/**
 * TranslationAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Translation
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class TranslationAbstract extends ImportAbstract
{
    const TRANSLATION_TYPE_SERIALIZED_CODE_OPTION_NAME = 'optionName';

    /** @var bool */
    private $isMultiLanguage = false;

    private $translationModel;

    /**
     * @param $translationType
     * @param $objectKey
     * @param $shopsId
     *
     * @return void
     */
    protected function loadTranslationModel($translationType, $objectKey, $shopsId)
    {
            $repository       = Helper::getRepository('Shopware\Models\Translation\Translation');
            $translationModel = $repository->findOneBy(array('type' => $translationType, 'key' => $objectKey, 'shopId' => $shopsId));

            if ($translationModel !== null) {
                $this->setTranslationModel($translationModel);
            } else {

                $this->setTranslationModel((new SwTranslation()));
            }
    }

    /**
     * @param $translationTyp
     *
     * @return null|\SimpleXMLElement
     */
    protected function prepareTranslation($translationTyp)
    {
        $descriptionItem = null;

        switch ($translationTyp) {
            case MultiShopAbstract::TYPE_ARTICLE:
                $descriptionItem = $this->getDescriptionXmlElement();
                break;

            case MultiShopAbstract::TYPE_ATTRIBUTES:
                $descriptionItem = $this->getAttributesXmlElement();
                break;

            case MultiShopAbstract::TYPE_PROPERTY_OPTION_AND_VALUE:
                $descriptionItem = $this->getAttributesXmlElement();
                break;

            case MultiShopAbstract::TYPE_CONFIGURATOR_GROUP_AND_OPTION:
                $descriptionItem = $this->getDiffOptionsXmlElement();
                break;

            default:
                break;
        }

        return $descriptionItem;
    }

    /**
     * @return null|\SimpleXMLElement[]
     */
    public function getAttributesXmlElement()
    {
        $attributesXmlElement = null;

        if ((bool)$this->getSimpleXmlElement()->Attributes === true) {
            $attributesXmlElement = $this->getSimpleXmlElement()->Attributes;
        }

        return $attributesXmlElement;
    }

    /**
     * @return null|\SimpleXMLElement
     */
    public function getDescriptionXmlElement()
    {
        $descriptionXmlElement = null;

        if ((bool)$this->getSimpleXmlElement()->Descriptions === true && (bool)$this->getSimpleXmlElement()->Descriptions->Description === true &&
            $this->getIsMultiLanguage() === false) {
            $descriptionXmlElement = $this->getSimpleXmlElement()->Descriptions->Description;
        } elseif ($this->getIsMultiLanguage() === true) {
            $descriptionXmlElement = $this->getSimpleXmlElement()->Descriptions;
        } else {
            Helper::fromArray(new Log(), array(
                    Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_WARNING,
                    Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                    Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::TRANSLATION_DESCRIPTION_ERROR_CODE,
                    Logging::SETTER_ALIAS_LOG_MESSAGE => ErrorCodes::TRANSLATION_DESCRIPTION,
                    Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                ));
        }

        return $descriptionXmlElement;
    }

    /**
     * @return array
     */
    public function getDiffOptionsXmlElement()
    {
        $diffOptionsXmlElement = array();

        if ((bool)$this->getSimpleXmlElement()->Variations->Variation === true) {
            foreach ($this->getSimpleXmlElement()->Variations->Variation as $variation) {
                if ((bool)$variation->Options->Option === true) {
                    foreach ($variation->Options->Option as $option) {
                        $diffOptionsXmlElement[] = $option;
                    }
                }
            }
        }

        return $diffOptionsXmlElement;
    }

    /**
     * @param $attributesCode
     *
     * @return bool
     */
    protected function attributeIsMatched($attributesCode)
    {
        $isMatched = null;

        if (strlen($attributesCode) > 0) {
            /** @var \Shopware\CustomModels\BfSaleschannel\MappingAttributes $attributesMappingModel */
            $attributesMappingModel = Helper::getMappingByValue($attributesCode, 'attributesCode', 'Shopware\CustomModels\BfSaleschannel\MappingAttributes');

            if ($attributesMappingModel !== null) {
                $isMatched = $attributesMappingModel->getMappingFieldKey();
            }
        }

        return $isMatched;
    }

    /**
     * @param $attributesCode
     *
     * @return null|\Shopware\Models\Property\Option
     */
    protected function propertyIsMatched($attributesCode)
    {
        $filtersMappingModel = null;

        if (strlen($attributesCode) > 0) {
            /** @var \Shopware\CustomModels\BfSaleschannel\MappingFilters $filtersMappingModel */
            $filtersMappingModel = Helper::getMappingByValue($attributesCode, 'attributesCode', 'Shopware\CustomModels\BfSaleschannel\MappingFilters');
        }

        return $filtersMappingModel;
    }

    /**
     * @param \SimpleXMLElement $attribute
     * @param string $type
     * @param null|\Shopware\CustomModels\BfSaleschannel\MappingShops $shopMappingModel
     *
     * @return array
     */
    protected function getAttributeValueAndName(\SimpleXMLElement $attribute, $type = '', $shopMappingModel = null)
    {
        $return = array(
            'code'  => (string)$attribute['code'],
            'name'  => (string)$attribute['code'],
            'value' => '',
            'id'    => ''
        );

        if ($this->getIsMultiLanguage() === true && $shopMappingModel instanceof \Shopware\CustomModels\BfSaleschannel\MappingShops) {
            $translationMappingRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingTranslation');
            /** @var \Shopware\CustomModels\BfSaleschannel\MappingTranslation $translationModel */
            $translationModel = $translationMappingRepository->findOneBy(array('mappingFieldKey' => $shopMappingModel->getShop()->getLocale()->getLocale()));

            if ($translationModel !== null) {
                $isoCode = $translationModel->getBrickfoxIsoCode();

                if ((bool)$attribute->Translations === true && (bool)$attribute->Translations->Translation === true) {
                    foreach ($attribute->Translations->Translation as $translation) {
                        if ((string) $translation['lang'] === $isoCode) {
                            switch ($type) {
                                case 'String':

                                    if ((bool)$attribute->Translations === true && (bool)$attribute->Translations->Translation === true) {
                                        $return['name']  = (string)$translation->Name;
                                        $return['value'] = (string)$translation->Value;
                                        $return['id']    = (int)$translation->Value['id'];
                                    }
                                    break;

                                case 'Integer':
                                case 'Float':
                                case 'Boolean':

                                    $return['name'] = ((bool)$translation->Name) ? (string)$translation->Name : (string)$attribute['code'];
                                    $return['value'] = ((bool)$translation->Value) ? (string)$translation->Value : '';
                                    break;
                            }
                        }
                    }
                }
            }
        } else {
            switch ($type) {
                case 'String':

                    if ((bool)$attribute->Translations === true && (bool)$attribute->Translations->Translation === true) {
                        $return['name']  = (string)$attribute->Translations->Translation->Name;
                        $return['value'] = (string)$attribute->Translations->Translation->Value;
                        $return['id']    = (int)$attribute->Translations->Translation->Value['id'];
                    } else {
                        $return['name']  = (string)$attribute['code'];
                        $return['value'] = '';
                    }
                    break;

                case 'Integer':
                case 'Float':
                case 'Boolean':

                    if ((bool)$attribute->Translations === true && (bool)$attribute->Translations->Translation === true) {
                        $return['name'] = ((bool)$attribute->Translations->Translation->Name) ? (string)$attribute->Translations->Translation->Name : (string)$attribute['code'];
                    }

                    $return['value'] = ((bool)$attribute->Value) ? (string)$attribute->Value : '';
                    break;
            }
        }

        return $return;
    }

    /**
     * @return \Shopware\Models\Translation\Translation
     */
    public function getTranslationModel()
    {
        return $this->translationModel;
    }

    /**
     * @param mixed $translationModel
     *
     * @return TranslationAbstract
     */
    public function setTranslationModel($translationModel)
    {
        $this->translationModel = $translationModel;

        return $this;
    }

    /**
     * @return bool
     */
    public function getIsMultiLanguage()
    {
        return $this->isMultiLanguage;
    }

    /**
     * @param bool $isMultiLanguage
     */
    public function setIsMultiLanguage($isMultiLanguage)
    {
        $this->isMultiLanguage = $isMultiLanguage;
    }

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     */
    abstract public function __construct(\SimpleXMLElement $simpleXMLElement);

    /**
     * @return void
     */
    public function __destruct()
    {
        parent::__destruct();
    }
}
