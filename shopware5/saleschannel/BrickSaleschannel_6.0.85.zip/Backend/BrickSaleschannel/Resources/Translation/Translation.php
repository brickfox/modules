<?php

namespace Bf\Saleschannel\Components\Resources\Translation;

use Bf\Saleschannel\Components\Gui\Logging;
use Bf\Saleschannel\Components\Resources\MultiShop\MultiShopAbstract;
use Bf\Saleschannel\Components\Util\ConfigManager;
use Shopware\Models\Translation\Translation as SwTranslation;
use Shopware\CustomModels\BfSaleschannel\MappingShops as BfShopsMapping;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Exceptions;
use Bf\Saleschannel\Components\Util\Helper;
use Shopware\CustomModels\BfSaleschannel\Log;

/**
 * Translation
 *
 * @package Bf\Saleschannel\Components\Resources\Translation
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Translation extends TranslationAbstract
{
    const SHOPWARE_ATTRIBUTES_TRANSLATIONS_PREFIX = '__attribute_';

    /** @var array */
    private $uniquePropertyOptionNames = array();

    /** @var array */
    public static $translation = array();

    private $shopsId;

    /** @var \Shopware\CustomModels\BfSaleschannel\MappingShops */
    private $shopMappingModel = null;

    /** @var SwTranslation */
    private $translationModel;

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     * @param bool $isMultiLanguage
     */
    public function __construct(\SimpleXMLElement $simpleXMLElement, $isMultiLanguage = false)
    {
        $this->setSimpleXmlElement($simpleXMLElement);
        $this->setIsMultiLanguage($isMultiLanguage);
    }

    /**
     * @param $translationModel
     * @param $shopsId
     * @param $translationTyp
     * @param $objectKey
     * @param bool|false $isPropertyTranslation
     * @param null $article
     * @param bool $isConfiguratorTranslation
     *
     * @throws \Exception
     * @return void
     */
    public function prepareTranslationItem(
        $translationModel,
        $shopsId,
        $translationTyp,
        $objectKey,
        $isPropertyTranslation = false,
        $article = null,
        $isConfiguratorTranslation = false
    ) {
        $this->setShopsId($shopsId);
        $this->translationModel = $translationModel;

        /** @var \Shopware\CustomModels\BfSaleschannel\MappingShops $shopsMappingModel */

        if ($this->getIsMultiLanguage() === false) {
            $shopsMappingModel = Helper::getMappingByValue($this->getShopsId(), 'brickfoxId', MultiShopAbstract::MAPPING_NAMESPACE_SHOPS);
        } else {
            $shopsMappingModel = Helper::getMappingByValue($this->getShopsId(), 'shopwareId', MultiShopAbstract::MAPPING_NAMESPACE_SHOPS);
        }

        if ($shopsMappingModel === null) {
            Helper::fromArray(new Log(), array(
                Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_FATAL,
                Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::CAN_NOT_FIND_ENTITY_BY_GIVEN_VALUE_ERROR_CODE,
                Logging::SETTER_ALIAS_LOG_MESSAGE => str_replace('{$id}', $this->getShopsId(), ErrorCodes::CAN_NOT_FIND_ENTITY_BY_GIVEN_VALUE),
                Logging::SETTER_ALIAS_USER        => Helper::getUserName()
            ));
            var_dump($this->getIsMultiLanguage());
            echo '<pre>';
            print_r($this->getShopsId());
            echo '</pre>';
            exit();
            Exceptions::throwException('Cannot load shops mapping model, please check your shops mapping');
        }

        $this->setShopMappingModel($shopsMappingModel);
        $itemTranslation = $this->prepareTranslation($translationTyp);

        if ($itemTranslation !== null && $isPropertyTranslation === false && $isConfiguratorTranslation === false) {
            $this->prepareTranslationModel($translationModel, $translationTyp, $objectKey);
            $this->assignTranslationItems($itemTranslation, $translationTyp, $article);
        } elseif ($itemTranslation !== null && $isPropertyTranslation === true && $isConfiguratorTranslation === false) {
            $this->assignTranslationItems($itemTranslation, $translationTyp, $article);
        } elseif ($itemTranslation !== null && $isPropertyTranslation === false && $isConfiguratorTranslation === true) {
            $this->assignTranslationItems($itemTranslation, $translationTyp);
        } elseif ($itemTranslation === null && $isPropertyTranslation === false && $isConfiguratorTranslation === false) {
            $this->prepareTranslationModel($translationModel, $translationTyp, $objectKey);
        }
    }

    /**
     * @param SwTranslation $translationModel
     * @param $translationTyp
     * @param $objectKey
     *
     * @return void
     */
    private function prepareTranslationModel(SwTranslation $translationModel, $translationTyp, $objectKey)
    {
        if (strlen($translationModel->getType()) <= 0 || $translationModel->getType() === null) {
            $translationModel->setType($translationTyp);
        }

        if ($translationModel->getKey() === null) {
            $translationModel->setKey($objectKey);
        }

        if ($translationModel->getShopId() === null) {
            $translationModel->setShop($this->getShopMappingModel()->getShop());
        }
    }

    /**
     * @param $itemTranslation
     * @param $translationType
     * @param null $article
     *
     * @return void
     */
    private function assignTranslationItems($itemTranslation, $translationType, $article = null)
    {
        if($this->translationModel !== null) {
            $data = $this->translationModel->getData();
            if(strlen($data) >= 0) {
                $arrData = unserialize($data);

                if(is_array($arrData)) {
                    self::$translation = $arrData;
                }
            }
        }

        switch ($translationType) {
            case MultiShopAbstract::TYPE_ARTICLE:
                $this->prepareDescription($itemTranslation, $article);
                break;

            case MultiShopAbstract::TYPE_ATTRIBUTES:
                $this->prepareAttributes($itemTranslation);
                break;

            case MultiShopAbstract::TYPE_PROPERTY_OPTION_AND_VALUE:
                $this->prepareProperties($itemTranslation, $article);
                break;

            case MultiShopAbstract::TYPE_CONFIGURATOR_GROUP_AND_OPTION:
                $this->prepareConfigurator($itemTranslation);
                break;

            default:
                break;
        }
    }

    private function prepareConfigurator($itemTranslation)
    {
        if (count($itemTranslation) > 0) {
            foreach ($itemTranslation as $option) {
                if (strlen($option['id']) > 0 && strlen($option['valueId']) > 0) {
                    $groupId  = (int)$option['id'];
                    $optionId = (int)$option['valueId'];

                    $swConfiguratorGroupId  = $this->loadMappingConfigurator('Shopware\CustomModels\BfSaleschannel\MappingConfiguratorGroups', $groupId);
                    $swConfiguratorOptionId = $this->loadMappingConfigurator('Shopware\CustomModels\BfSaleschannel\MappingConfiguratorOptions', $optionId);

                    if ($swConfiguratorGroupId > 0 && $swConfiguratorOptionId > 0) {
                        //configurator group
                        $translationType = explode('|', MultiShopAbstract::TYPE_CONFIGURATOR_GROUP_AND_OPTION);

                        $this->loadTranslationModel($translationType[0], $swConfiguratorGroupId, $this->getShopMappingModel()->getShop()->getId());

                        if ($this->getIsMultiLanguage() === true) {
                            $serializedString = serialize(array('name' => ''));
                            $translationMappingRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingTranslation');
                            /** @var \Shopware\CustomModels\BfSaleschannel\MappingTranslation $translationModel */
                            $translationModel = $translationMappingRepository->findOneBy(array('mappingFieldKey' => $this->getShopMappingModel()->getShop()->getLocale()->getLocale()));

                            if ($translationModel !== null) {
                                $isoCode = $translationModel->getBrickfoxIsoCode();
                                $name = '';

                                foreach ($option->Translations->Translation as $translation) {
                                    if ((string) $translation['lang'] === $isoCode) {
                                        $name = (string) $translation->OptionName;
                                        break;
                                    }
                                }

                                $serializedString = serialize(array('name' => $name));
                            }

                        } else {
                            $serializedString = serialize(array('name' => (string)$option->Translations->Translation->OptionName));
                        }

                        $this->getTranslationModel()->setType($translationType[0]);
                        $this->getTranslationModel()->setKey($swConfiguratorGroupId);

                        $this->getTranslationModel()->setShop($this->getShopMappingModel()->getShop());
                        $this->getTranslationModel()->setData($serializedString);

                        Shopware()->Models()->persist($this->getTranslationModel());
                        Shopware()->Models()->flush($this->getTranslationModel());

                        // configurator option

                        $this->loadTranslationModel($translationType[1], $swConfiguratorOptionId, $this->getShopMappingModel()->getShop()->getId());

                        if ($this->getIsMultiLanguage() === true) {
                            $serializedString = serialize(array('name' => ''));
                            $translationMappingRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingTranslation');
                            /** @var \Shopware\CustomModels\BfSaleschannel\MappingTranslation $translationModel */
                            $translationModel = $translationMappingRepository->findOneBy(array('mappingFieldKey' => $this->getShopMappingModel()->getShop()->getLocale()->getLocale()));

                            if ($translationModel !== null) {
                                $isoCode = $translationModel->getBrickfoxIsoCode();
                                $name = '';

                                foreach ($option->Translations->Translation as $translation) {
                                    if ((string) $translation['lang'] === $isoCode) {
                                        $name = (string) $translation->OptionValue;
                                        break;
                                    }
                                }

                                $serializedString = serialize(array('name' => $name));
                            }

                        } else {
                            $serializedString = serialize(array('name' => (string)$option->Translations->Translation->OptionValue));
                        }

                        $this->getTranslationModel()->setType($translationType[1]);
                        $this->getTranslationModel()->setKey($swConfiguratorOptionId);

                        $this->getTranslationModel()->setShop($this->getShopMappingModel()->getShop());
                        $this->getTranslationModel()->setData($serializedString);

                        Shopware()->Models()->persist($this->getTranslationModel());
                        Shopware()->Models()->flush($this->getTranslationModel());
                    }
                }
            }
        }
    }

    /**
     * @param $mappingModelNamespace
     * @param $bfId
     *
     * @return int
     */
    private function loadMappingConfigurator($mappingModelNamespace, $bfId)
    {
        $id = 0;

        $repository   = Shopware()->Models()->getRepository($mappingModelNamespace);
        $mappingModel = $repository->findOneBy(array('brickfoxId' => $bfId));

        if ($mappingModel !== null) {
            $id = $mappingModel->getShopwareId();
        }

        return $id;
    }

    /**
     * @param $itemTranslation
     * @param \Shopware\Models\Article\Article $article
     *
     * @return void
     */
    private function prepareProperties($itemTranslation, $article)
    {
        if (count($itemTranslation) > 0) {
            foreach ($itemTranslation as $attributes) {
                foreach ($attributes as $type => $attribute) {

                    if ($this->getIsMultiLanguage() === true) {
                        $attributeData = $this->getAttributeValueAndName($attribute, $type, $this->getShopMappingModel());
                    } else {
                        $attributeData = $this->getAttributeValueAndName($attribute, $type);
                    }

                    if ($attributeData['id'] > 0) {
                        $filtersMappingModel = $this->propertyIsMatched($attributeData['code']);

                        if ($filtersMappingModel !== null) {
                            $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingFiltersRelations');
                            /** @var array $mappingFiltersRelationsModel */
                            $mappingFiltersRelationsModel = $repository->findBy(array('mappingFiltersId' => $filtersMappingModel->getId()));

                            if (count($mappingFiltersRelationsModel) > 0) {
                                $this->preparePropertiesOptionName($filtersMappingModel->getId(), $attributeData);

                                /** @var \Shopware\CustomModels\BfSaleschannel\MappingFiltersRelations $mappingFiltersRelations */
                                foreach ($mappingFiltersRelationsModel as $mappingFiltersRelations) {
                                    /** @var \Shopware\Models\Property\Value $propertyValues */
                                    foreach ($article->getPropertyValues() as $propertyValues) {
                                        if (
                                            (int)$propertyValues->getId() === (int)$mappingFiltersRelations->getValueId() &&
                                            (int)$mappingFiltersRelations->getBrickfoxId() === (int)$attributeData['id']
                                        ) {
                                            $objectKey       = $mappingFiltersRelations->getValueId();
                                            $translationType = explode('|', MultiShopAbstract::TYPE_PROPERTY_OPTION_AND_VALUE);

                                            $this->loadTranslationModel($translationType[1], $objectKey, $this->getShopMappingModel()->getShop()->getId());
                                            $serializedString = serialize(array('optionValue' => $attributeData['value']));

                                            $this->getTranslationModel()->setType($translationType[1]);
                                            $this->getTranslationModel()->setKey($objectKey);

                                            $this->getTranslationModel()->setShop($this->getShopMappingModel()->getShop());
                                            $this->getTranslationModel()->setData($serializedString);

                                            Shopware()->Models()->persist($this->getTranslationModel());
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @param $itemTranslation
     *
     * @return void
     */
    private function prepareAttributes($itemTranslation)
    {
        $attributesToIgnore = $this->getKeepOnImportAttributes();

        foreach ($itemTranslation as $attributes) {
            foreach ($attributes as $type => $attribute) {
                if ($type === 'String') {
                    $mappingFieldKey = $this->attributeIsMatched((string)$attribute['code']);

                    if ($mappingFieldKey !== null) {
                        $isTranslatable = Shopware()->Db()->fetchOne("select translatable from s_attribute_configuration where table_name = 's_articles_attributes' and column_name = ?", array($mappingFieldKey));
                        if ((int)$isTranslatable === 1) {

                            $attributeValueAndName = $this->getAttributeValueAndName($attribute, $type, $this->getShopMappingModel());

                            if(in_array($attributeValueAndName['code'], $attributesToIgnore) === true) {
                                continue;
                            }

                            if (strlen($attributeValueAndName['value']) > 0) {
                                self::$translation[self::SHOPWARE_ATTRIBUTES_TRANSLATIONS_PREFIX . $mappingFieldKey] = $attributeValueAndName['value'];
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @param $itemTranslation
     * @param $article
     *
     * @return string
     */
    private function prepareDescription($itemTranslation, $article)
    {
        $isoCode = '';

        if ($this->getIsMultiLanguage() === true) {
            $translationMappingRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingTranslation');
            /** @var \Shopware\CustomModels\BfSaleschannel\MappingTranslation $translationModel */
            $translationModel = $translationMappingRepository->findOneBy(array('mappingFieldKey' => $this->getShopMappingModel()->getShop()->getLocale()->getLocale()));

            if ($translationModel !== null) {
                $isoCode = $translationModel->getBrickfoxIsoCode();
            } else {
                $code = (string) $itemTranslation->Description['lang'];

                if (in_array($code, Helper::getMainLanguagesCode()) === true) {
                    $key = array_search($code, Helper::getMainLanguagesCode());
                    $isoCode = Helper::getMainLanguagesCode()[$key];
                }
            }

            foreach ($itemTranslation->Description as $description) {
                if ((string)$description['lang'] === $isoCode) {
                    if ((bool)$description->Title === true) {
                        self::$translation['txtArtikel'] = (string)$description->Title;
                    }

                    if (Helper::getConfigurationByKey('overWriteMetaElements')->getConfigurationValue() === 'true') {
                        if ((bool)$itemTranslation->SeoDescription === true) {
                            self::$translation['txtshortdescription'] = (string)$itemTranslation->SeoDescription;
                        }

                        if ((bool)$itemTranslation->SearchKeys === true) {
                            self::$translation['txtkeywords'] = (string)$itemTranslation->SearchKeys;
                        }

                        if ((bool)$itemTranslation->SeoTitle === true) {
                            self::$translation['metaTitle'] = (string)$itemTranslation->SeoTitle;
                        }
                    }

                    if ((bool)$description->LongDescription === true
                        && ConfigManager::getInstance()->getIgnoreLongDescription() === false) {
                        self::$translation['txtlangbeschreibung'] = (string)$description->LongDescription;
                    }

                    break;
                }
            }
        } else {
            if ((bool)$itemTranslation->Title === true) {
                self::$translation['txtArtikel'] = (string)$itemTranslation->Title;
            }
            if (Helper::getConfigurationByKey('overWriteMetaElements')->getConfigurationValue() === 'true') {
                if ((bool)$itemTranslation->SeoDescription === true) {
                    self::$translation['txtshortdescription'] = (string)$itemTranslation->SeoDescription;
                }

                if ((bool)$itemTranslation->SearchKeys === true) {
                    self::$translation['txtkeywords'] = (string)$itemTranslation->SearchKeys;
                }

                if ((bool)$itemTranslation->SeoTitle === true) {
                    self::$translation['metaTitle'] = (string)$itemTranslation->SeoTitle;
                }
            }

            if ((bool)$itemTranslation->LongDescription === true
                && ConfigManager::getInstance()->getIgnoreLongDescription() === false) {
                self::$translation['txtlangbeschreibung'] = (string)$itemTranslation->LongDescription;
            }
        }

        if ((bool)$this->getSimpleXmlElement()->Variations->Variation === true) {
            foreach ($this->getSimpleXmlElement()->Variations->Variation as $variationElement) {
                $bfMappingDetailsRepository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingDetails');
                /** @var \Shopware\CustomModels\BfSaleschannel\MappingDetails $bfMappingDetailModel */
                $bfMappingDetailModel = $bfMappingDetailsRepository->findOneBy(array('brickfoxId' => (int)$variationElement->VariationId));

                /** @var \Shopware\Models\Article\Article $article */
                if ($article !== null && $bfMappingDetailModel !== null) {
                    if ($article->getMainDetail()->getId() === $bfMappingDetailModel->getShopwareId()) {
                        self::$translation['txtzusatztxt'] = $this->prepareVariationsAdditionalText($variationElement, $isoCode);
                        if ((bool) $variationElement->Descriptions === true && (bool) $variationElement->Descriptions->Description[0] === true) {
                            if ((bool) $variationElement->Descriptions->Description[0]->PackingUnit === true) {
                                self::$translation['txtpackunit'] = (string)$variationElement->Descriptions->Description[0]->PackingUnit;
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @param \SimpleXMLElement $variationElement
     *
     * @return string
     */
    public function prePrepareVariationsAdditionalTextForVariationTranslationMultiLanguage(\SimpleXMLElement $variationElement)
    {
        $isoCode = '';
        $additionalText = '';

        if ($this->getIsMultiLanguage() === true) {
            $translationMappingRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingTranslation');
            /** @var \Shopware\CustomModels\BfSaleschannel\MappingTranslation $translationModel */
            $translationModel = $translationMappingRepository->findOneBy(array('mappingFieldKey' => $this->getShopMappingModel()->getShop()->getLocale()->getLocale()));

            if ($translationModel !== null) {
                $isoCode = $translationModel->getBrickfoxIsoCode();
            }

            $additionalText = $this->prepareVariationsAdditionalText($variationElement, $isoCode);
        }

        return $additionalText;
    }

    /**
     * @param \SimpleXMLElement $variationElement
     * @param string $isoCode
     *
     * @return string
     */
    public function prepareVariationsAdditionalText(\SimpleXMLElement $variationElement, $isoCode = '')
    {
        if ((bool)$variationElement->Options === true && (bool)$variationElement->Options->Option) {
            $additionalText = '';
            $counter        = 0;

            foreach ($variationElement->Options->Option as $option) {
                $optionsTranslations = array();

                foreach ($option->Translations->Translation as $translation) {
                    if ($this->getIsMultiLanguage() === false) {
                        $optionsTranslations[] = $translation;
                    } else {
                        if ((string)$translation['lang'] === $isoCode) {
                            $optionsTranslations[] = $translation;
                            break;
                        } elseif (in_array((string)$translation['lang'], Helper::getMainLanguagesCode()) === true) {
                            $key = array_search((string)$translation['lang'], Helper::getMainLanguagesCode());
                            $isoCode = Helper::getMainLanguagesCode()[$key];
                            $optionsTranslations[] = $translation;
                            break;
                        }
                    }
                }

                if (count($optionsTranslations) > 0) {
                    foreach ($optionsTranslations as $translation) {
                        $optionName  = trim((string)$translation->OptionName);
                        $optionValue = trim((string)$translation->OptionValue);

                        if (strlen($optionValue) > 0) {
                            $counter++;

                            if ($counter < count($variationElement->Options->Option)) {
                                $additionalText .= $optionValue . '/';
                            } else {
                                $additionalText .= $optionValue;
                            }
                        }
                    }
                }
            }

            return $additionalText;
        }
    }

    /**
     * @param $filterMappingModel
     * @param $attributeData
     *
     * @return void
     */
    private function preparePropertiesOptionName($filterMappingModel, $attributeData)
    {
        $translateProperty = false;
        $groupResult       = Shopware()
            ->Db()
            ->fetchAll("select rel.* from bf_mapping_filters_relations rel where rel.mappingFiltersID = ? group by rel.optionID", array($filterMappingModel));

        if (count($groupResult) > 0) {
            foreach ($groupResult as $filterRelation) {
                if (array_key_exists($attributeData['name'], $this->getUniquePropertyOptionNames()) === false) {
                    $translateProperty = true;
                } elseif (in_array($filterRelation['optionID'], $this->getUniquePropertyOptionNames()[$attributeData['name']]) === false) {
                    $translateProperty = true;
                }

                if ($translateProperty === true) {
                    $this->setUniquePropertyOptionNames($attributeData['name'], $filterRelation['optionID']);

                    $objectKey       = $filterRelation['optionID'];
                    $translationType = explode('|', MultiShopAbstract::TYPE_PROPERTY_OPTION_AND_VALUE);
                    $this->loadTranslationModel($translationType[0], $objectKey, $this->getShopMappingModel()->getShop()->getId());

                    $serializedTranslationOptionName = serialize(array('optionName' => $attributeData['name']));
                    $this->getTranslationModel()->setType($translationType[0]);
                    $this->getTranslationModel()->setKey($objectKey);

                    $this->getTranslationModel()->setShop($this->getShopMappingModel()->getShop());
                    $this->getTranslationModel()->setData($serializedTranslationOptionName);

                    Shopware()->Models()->persist($this->getTranslationModel());
                }
            }
        }
    }

    /**
     * @return mixed
     */
    public function getShopsId()
    {
        return $this->shopsId;
    }

    /**
     * @param mixed $shopsId
     *
     * @return Translation
     */
    public function setShopsId($shopsId)
    {
        $this->shopsId = $shopsId;

        return $this;
    }

    /**
     * @return array
     */
    public function getUniquePropertyOptionNames()
    {
        return $this->uniquePropertyOptionNames;
    }

    /**
     * @param $uniquePropertyOptionNames
     * @param $optionId
     *
     * @return Translation
     */
    public function setUniquePropertyOptionNames($uniquePropertyOptionNames, $optionId)
    {
        $this->uniquePropertyOptionNames[$uniquePropertyOptionNames][] = $optionId;

        return $this;
    }

    /**
     * @return BfShopsMapping
     */
    public function getShopMappingModel()
    {
        return $this->shopMappingModel;
    }

    /**
     * @param BfShopsMapping $shopMappingModel
     */
    public function setShopMappingModel($shopMappingModel)
    {
        $this->shopMappingModel = $shopMappingModel;
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        parent::__destruct();
    }

    /**
     * @return array
     */
    private function getKeepOnImportAttributes()
    {
        $result = [];

        $keepAttributesOnImportConfigValue = ConfigManager::getInstance()->getKeepOnImportAttributes();

        if (strlen($keepAttributesOnImportConfigValue) > 0) {
            $result = explode(',', $keepAttributesOnImportConfigValue);
        }

        return $result;
    }
}
