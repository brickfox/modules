<?php
namespace Bf\Saleschannel\Components\Resources\Images;

use Bf\Saleschannel\Components\Gui\Logging;
use Bf\Saleschannel\Components\Resources\Media\MediaAbstract;
use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\LogManager;
use Shopware\Models\Article\Article as SwArticle;
use Shopware\Models\Article\Image as SwImage;
use Shopware\Models\Log\Log;
use Shopware\Models\Media\Media as SwMedia;
use SimpleXMLElement;
use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract as BfArticleAbstract;

/**
 * ImagesAbstract
 *
 * @package Bf\Saleschannel\Components\Resources\Images
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class ImagesAbstract extends MediaAbstract
{
    const MAIN_IMAGE_FLAG     = 1;
    const NOT_MAIN_IMAGE_FLAG = 2;
    const FILE_NAME   = 'ImagesAbstract.php';
    const ENTITY_NAME = 'Images';
    const CHILD_NODE_IMAGE           = 'Image';
    const CHILD_NODE_VARIATION_IMAGE = 'VariationImage';

    /** @var bool */
    private $isFirstImage = true;

    /**
     * @param SwArticle $article
     * @param SwImage $image
     * @param SwMedia $media
     * @param SimpleXMLElement $xmlImageElement
     * @param $mode
     *
     * @return SwImage
     */
    protected function prepareImageData(SwArticle $article, SwImage $image, SwMedia $media, SimpleXMLElement $xmlImageElement, $mode)
    {
        if ($mode === BfArticleAbstract::IMPORT_ARTICLE_IMAGE_MODE && $this->getIsFirstImage() === true ||
            $mode === BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE && ConfigManager::getInstance()->getImageMappingDiffsOptionsStatus() === false &&
            $this->getIsFirstImage() === true && Helper::$mainImageBaseProductsIsSet === false) {
            $image->setMain(self::MAIN_IMAGE_FLAG);
            Helper::$mainImageBaseProductsIsSet = true;
            $this->setIsFirstImage(false);
        } elseif ($mode === BfArticleAbstract::IMPORT_ARTICLE_IMAGE_MODE && $this->getIsFirstImage() === false ||
                  $mode === BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE && ConfigManager::getInstance()->getImageMappingDiffsOptionsStatus() === false &&
                  $this->getIsFirstImage() === false) {
            $image->setMain(self::NOT_MAIN_IMAGE_FLAG);
        }

        $image->setPosition($this->getSortOrder($image, $xmlImageElement));
        $image->setMedia($media);
        $image->setArticle($article);

        $image->setPath($media->getName());
        $image->setExtension($media->getExtension());
        $image->setDescription($this->getImageDescription($xmlImageElement));

        return $image;
    }

    /**
     * @param SwImage $image
     * @param $imageXmlElement
     *
     * @return int
     */
    private function getSortOrder(SwImage $image, $imageXmlElement)
    {
        $sort = 1;

        if($image->getMain() !== self::MAIN_IMAGE_FLAG)
        {
            if(isset($imageXmlElement['sort']))
            {
                $sort = (int) $imageXmlElement['sort'];
            }
            else
            {
                $sort = 2;
            }
        }

        return $sort;
    }

    /**
     * @param $imageXmlElement
     *
     * @return string
     */
    private function getImageDescription($imageXmlElement)
    {
        $imageDescription = '';

        if((bool) $imageXmlElement->ImageDescription === true && strlen((string) $imageXmlElement->ImageDescription) > 0)
        {
            $imageDescription = (string) $imageXmlElement->ImageDescription;

            if(Helper::getConfigurationByKey('urlDescriptionActive')->getConfigurationValue() === 'false')
            {
                if(strpos($imageDescription, 'http') !== false || strpos($imageDescription, 'https') !== false)
                {
                    $imageDescription = '';
                }
            }

        }
        else
        {
            if((bool) $imageXmlElement->Path === true)
            {
                $imageDescription = (string) $imageXmlElement->Path;

                if(Helper::getConfigurationByKey('urlDescriptionActive')->getConfigurationValue() === 'false')
                {
                    $imageDescription = '';
                }
            }
            else
            {
                LogManager::getInstance()->logDebug(ErrorCodes::CAN_NOT_SAVE_IMAGE_WITHOUT_IMAGE_PATH, self::ENTITY_NAME);
                Helper::fromArray(
                    new Log(),
                    array(
                        Logging::SETTER_ALIAS_LOG_STATUS  => Logging::LOG_STATUS_WARNING,
                        Logging::SETTER_ALIAS_ACTION      => __METHOD__,
                        Logging::SETTER_ALIAS_ERROR_CODE  => ErrorCodes::CAN_NOT_SAVE_IMAGE_WITHOUT_IMAGE_PATH_ERROR_CODE,
                        Logging::SETTER_ALIAS_LOG_MESSAGE => ErrorCodes::CAN_NOT_SAVE_IMAGE_WITHOUT_IMAGE_PATH,
                        Logging::SETTER_ALIAS_USER        => Helper::getUserName()
                    )
                );
            }
        }

        return $imageDescription;
    }

    /**
     * @param $articleId
     * @param \Shopware\Models\Article\Detail|null $detail
     *
     * @return void
     */
    public function prepareToDeleteImageList($articleId, $detail)
    {
        if ($articleId > 0) {
            $qb = Shopware()->Models()->createQueryBuilder();
            $qb->select(array('images'))->from('Shopware\Models\Article\Image', 'images')->where('images.articleId = :articleId')->setParameter('articleId', $articleId);

            $sql       = $qb->getQuery();
            $imageList = $sql->getResult();

            /** @var \Shopware\Models\Article\Image $images */
            foreach($imageList as $images)
            {
                $imageFound = false;

                if($this->getArticleMode() === BfArticleAbstract::IMPORT_ARTICLE_IMAGE_MODE)
                {
                    if(count($images->getChildren()) > 0)
                    {
                        continue;
                    }
                }

                if($this->getArticleMode() === BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE)
                {
                    if(count($images->getChildren()) <= 0)
                    {
                        continue;
                    }
                }

                foreach($this->getMediaList() as $mediaInfo) {
                    if ($images->getPath() === $mediaInfo['imageName'] && $images->getExtension() === $mediaInfo['extension']) {
                        $imageFound = true;
                        break;
                    }
                }

                if ($imageFound === false) {
                    $this->setDeleteMediaList($images);
                }
            }

            $this->deleteMediaByDeleteList('image', $detail);
        }
    }

    /**
     * @return boolean
     */
    public function getIsFirstImage()
    {
        return $this->isFirstImage;
    }

    /**
     * @param boolean $isFirstImage
     *
     * @return ImagesAbstract
     */
    public function setIsFirstImage($isFirstImage)
    {
        $this->isFirstImage = $isFirstImage;

        return $this;
    }
}
