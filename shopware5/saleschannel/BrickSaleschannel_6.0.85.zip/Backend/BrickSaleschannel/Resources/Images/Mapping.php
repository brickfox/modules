<?php

namespace Bf\Saleschannel\Components\Resources\Images;

use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\Helper;
use Doctrine\Common\Collections\ArrayCollection;
use Exception;
use Shopware\Models\Article\Article as SwArticle;
use Shopware\Models\Article\Image\Mapping as SwImageMapping;
use Shopware\Models\Article\Image\Rule as SwImageRule;
use Shopware\Models\Article\Image as SwImage;
use Shopware\Models\Article\Detail as SwDetail;
use Shopware\Models\Article\Configurator\Option as SwOption;
use Bf\Saleschannel\Components\Resources\Images\Images as BfImage;
use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract as BfArticleAbstract;

use SimpleXMLElement;

/**
 * Mapping
 *
 * @package Bf\Saleschannel\Components\Resources\Images
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Mapping extends MappingAbstract
{

    /** @var bool */
    private $isVariationsMainImage = true;

    /** @var bool */
    private $imageMappingExists = false;

    private $mappingModel = null;

    /** @var string */
    private $mainImageType = self::MAIN_IMAGE_NON_BASE_PRODUCT;

    /**
     * @param SwDetail $swDetail
     * @param SwArticle $swArticle
     * @param SimpleXMLElement $variationXmlElement
     * @param $bfImageType
     * @param array $options
     * @param int $bfProductsId
     *
     * @internal param SwDetail $detail
     */
    public function __construct(SwDetail $swDetail, SwArticle $swArticle, SimpleXMLElement $variationXmlElement, $bfImageType, $options = array(), $bfProductsId = 0)
    {
        parent::__construct($swDetail, $swArticle, $variationXmlElement, $bfImageType, $options, $bfProductsId);
    }

    /**
     * @throws Exception
     * @return void
     */
    public function prepareArticleImagesMapping()
    {
        if (count($this->getOptions()) > 0) {
            $this->calculateMainImageType();

            foreach ($this->getBfImageType()
                         ->prepareImages($this->getVariationXmlElement(), $this->getSwArticle(), BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE, $this->getSwDetail(),
                             self::VARIATIONS_IMAGES_NODE_NAME, $this->getBfProductsId()) as $sort => $image
            ) {
                $optionCollection = $this->getImageOptions($this->getOptions(), $image);
                $this->createCloneForConfiguratorImages($image, $sort);


                if ($optionCollection !== null && $optionCollection->count() > 0) {

                    foreach ($optionCollection as $option) {
                        if (count($option) > 0) {
                            $this->createImageMappingForOptions($option, $image);
                        }
                    }
                    $this->setImageMappingExists(false);
                    $this->setMappingModel(null);
                }
            }
        }
    }

    /**
     * @param array $options
     * @param SwImage $image
     *
     * @return ArrayCollection
     */
    private function getImageOptions(array $options, SwImage $image)
    {
        $optionsCollection = new ArrayCollection();
        foreach ($options as $key => $opt) {
            if (is_array($opt) === true) {
                $tempOptions = array();
                $diffIsWritten = false;

                /** @var \Shopware\Models\Article\Configurator\Option $option */
                foreach ($opt as $option) {
                    if (count(ConfigManager::getInstance()->getImageMappingDiffsOptions()) > 0) {
                        $mappingConfiguratorOptionsRepository = Helper::getRepository('\Shopware\CustomModels\BfSaleschannel\MappingConfiguratorOptions');
                        /** @var \Shopware\CustomModels\BfSaleschannel\MappingConfiguratorOptions $mappingConfiguratorOptionsModel */
                        $mappingConfiguratorOptionsModel = $mappingConfiguratorOptionsRepository->findOneBy(array('shopwareId' => $option->getId()));
                        $tempOptions[] = $option;
                        if ($mappingConfiguratorOptionsModel !== null && in_array($mappingConfiguratorOptionsModel->getBrickfoxDiffsOptionsCode(), ConfigManager::getInstance()->getImageMappingDiffsOptions()) === true) {
                            $optionsCollection->add($option);
                            $optionIds[] = $option->getId();
                            $diffIsWritten = true;
                        }
                    } else {
                        $optionsCollection->add($option);
                        $optionIds[] = $option->getId();
                    }
                }

                if (count($tempOptions) > 0 && $diffIsWritten === false) {
                    /** @var \Shopware\Models\Article\Configurator\Option $option */
                    foreach($tempOptions as $option) {
                        $optionsCollection->add($option);
                        $optionIds[] = $option->getId();
                    }
                }
            }
        }

        sort($optionIds);
        $optionIds = array_values($optionIds);

        /** @var \Shopware\Models\Article\Image\Mapping $mapping */
        foreach ($image->getMappings()->toArray() as $mapping) {
            $currentRules = array();

            /** @var \Shopware\Models\Article\Image\Rule $rules */
            foreach ($mapping->getRules()->toArray() as $rules) {
                $currentRules[] = $rules->getOption()->getId();
            }

            sort($currentRules);
            $currentRules = array_values($currentRules);
            if ($currentRules == $optionIds) {
                unset(BfArticleAbstract::$toDeleteImageMappings[$image->getId()][$mapping->getId()]);
                return;
            }
        }

        BfArticleAbstract::setDeleteOldData(true);

        return $optionsCollection;
    }

    /**
     * @param $options
     * @param SwImage $image
     *
     * @return void
     */
    private function createImageMappingForOptions(SwOption $options, SwImage $image)
    {
        $ruleModel = null;

        $repository   = Helper::getRepository('\Shopware\Models\Article\Image\Mapping');
        $mappingModel = $repository->findOneBy(array('imageId' => $image->getId()));

        if ($mappingModel === null && $this->getMappingModel() === null && $this->getImageMappingExists() === false) {
            $mappingModel = new SwImageMapping();
            $mappingModel->setImage($image);
            $this->setImageMappingExists(true);
        }

        if ($mappingModel !== null) {
            $this->setMappingModel($mappingModel);
        }

        $repository = Helper::getRepository('\Shopware\Models\Article\Image\Rule');

        if ($this->getMappingModel()->getId() !== null) {
            $ruleModel = $repository->findOneBy(array('mappingId' => $this->getMappingModel()->getId(), 'optionId' => $options->getId()));
        }

        if ($ruleModel === null) {
            $ruleModel = new SwImageRule();
            $ruleModel->setMapping($this->getMappingModel());
            $ruleModel->setOption($options);
            $this->getMappingModel()->getRules()->add($ruleModel);
            $image->getMappings()->add($this->getMappingModel());
        }
    }

    /**
     * @param SwImage $image
     * @param int $sort
     *
     * @return void
     */
    private function createCloneForConfiguratorImages(SwImage $image, $sort = 0)
    {
        $repository = Helper::getRepository('Shopware\Models\Article\Image');

        if (ConfigManager::getInstance()->getImageMappingDiffsOptionsStatus() === false) {
            $imageModel = $repository->findOneBy(array('path' => $image->getPath(), 'parentId' => $image->getId(), 'articleDetailId' => $this->getSwDetail()->getId()));
        } else {
            $imageModel = $repository->findOneBy(array('parentId' => $image->getId(), 'articleDetailId' => $this->getSwDetail()->getId()));
        }

        if ($imageModel === null) {
            $imageModel = new SwImage();
            $imageModel->setPath($image->getPath());
            $imageModel->setDescription($image->getDescription());
            $imageModel->setPosition($image->getPosition());
            $imageModel->setWidth($image->getWidth());
            $imageModel->setHeight($image->getHeight());
            $imageModel->setRelations($image->getRelations());
            $imageModel->setExtension($image->getExtension());
            $imageModel->setParent($image);
            $imageModel->setArticleDetail($this->getSwDetail());
            $imageModel->setMedia($image->getMedia());
        }


        if ($this->getMainImageType() === self::MAIN_IMAGE_BASE_PRODUCT) {
            $imageModel->setMain(self::DEACTIVATE_VARIATION_MAIN_FLAG);

            if ($this->getBfImageType() instanceof \Bf\Saleschannel\Components\Resources\Images\ImagesDiffsOptions) {
                if ($image->getMain() === 1 && $sort === self::ACTIVATE_VARIATION_MAIN_FLAG) {
                    $image->setMain(self::ACTIVATE_VARIATION_MAIN_FLAG);
                } else {
                    $image->setMain(self::DEACTIVATE_VARIATION_MAIN_FLAG);
                }
            } else {
                $image->setMain(self::DEACTIVATE_VARIATION_MAIN_FLAG);
            }
        } elseif ($this->getMainImageType() === self::MAIN_IMAGE_NON_BASE_PRODUCT && $sort === self::ACTIVATE_VARIATION_MAIN_FLAG) {
            $this->setMain($imageModel, self::ACTIVATE_VARIATION_MAIN_FLAG);
            $this->setMain($image, self::ACTIVATE_VARIATION_MAIN_FLAG);
            $this->setMainImageType(self::MAIN_IMAGE_BASE_PRODUCT);
            Helper::$mainImageBaseProductsIsSet = true;
        } elseif ($this->getMainImageType() === self::MAIN_IMAGE_NON_BASE_PRODUCT && $sort !== self::ACTIVATE_VARIATION_MAIN_FLAG) {
            $this->setMain($imageModel, self::DEACTIVATE_VARIATION_MAIN_FLAG);
            $this->setMain($image, self::DEACTIVATE_VARIATION_MAIN_FLAG);
        }

        $imageModel->setPosition($sort);
        $image->setPosition($sort);

        Helper::doModelOperation(null, array($imageModel, $image));
    }

    /**
     * @param SwImage $model
     * @param $main
     *
     * @return void
     */
    private function setMain($model, $main)
    {
        $model->setMain($main);
    }

    /**
     * @return boolean
     */
    public function getIsVariationsMainImage()
    {
        return $this->isVariationsMainImage;
    }

    /**
     * @param boolean $isVariationsMainImage
     *
     * @return Mapping
     */
    public function setIsVariationsMainImage($isVariationsMainImage)
    {
        $this->isVariationsMainImage = $isVariationsMainImage;

        return $this;
    }

    /**
     * @return boolean
     */
    public function getImageMappingExists()
    {
        return $this->imageMappingExists;
    }

    /**
     * @param boolean $imageMappingExists
     *
     * @return Mapping
     */
    public function setImageMappingExists($imageMappingExists)
    {
        $this->imageMappingExists = $imageMappingExists;

        return $this;
    }

    /**
     * @return \Shopware\Models\Article\Image\Mapping
     */
    public function getMappingModel()
    {
        return $this->mappingModel;
    }

    /**
     * @param null $mappingModel
     *
     * @return Mapping
     */
    public function setMappingModel($mappingModel)
    {
        $this->mappingModel = $mappingModel;

        return $this;
    }

    /**
     * @return string
     */
    public function getMainImageType()
    {
        return $this->mainImageType;
    }

    /**
     * @param string $mainImageType
     *
     * @return Mapping
     */
    public function setMainImageType($mainImageType)
    {
        $this->mainImageType = $mainImageType;

        return $this;
    }
}
