<?php

namespace Bf\Saleschannel\Components\Resources\Images;

use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Shopware\CustomModels\BfSaleschannel\Log;
use Bf\Saleschannel\Components\Util\ImageHelper;
use Bf\Saleschannel\Components\Util\LogManager;
use \Shopware\Models\Article\Article as SwArticle;
use Shopware\Models\Article\Image as SwImage;
use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract as BfArticleAbstract;
use SimpleXMLElement;
use Symfony\Component\HttpFoundation\File\File;

/**
 * Images
 *
 * @package Bf\Saleschannel\Components\Resources\Images
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class Images extends ImagesAbstract
{
    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param SwArticle $article
     * @param string $mode
     * @param \Shopware\Models\Article\Detail|null $detail
     * @param string $node
     * @param int $bfProductsId
     *
     * @return array
     */
    public function prepareImages(SimpleXMLElement $simpleXMLElement, SwArticle $article, $mode, $detail = null, $node = 'Images', $bfProductsId = 0)
    {
        $prepareImages = array();
        $this->setArticleMode($mode);
        $variationsId = null;

        if ($this->isElementAvailable($simpleXMLElement, $node) === true) {
            /** @var \Shopware\Bundle\MediaBundle\MediaService $mediaService */
            $mediaService = Shopware()->Container()->get('shopware_media.media_service');
            $childNode    = self::CHILD_NODE_IMAGE;

            if ($node === Mapping::VARIATIONS_IMAGES_NODE_NAME) {
                $childNode    = self::CHILD_NODE_VARIATION_IMAGE;
                $variationsId = (string)$simpleXMLElement->VariationId;
            }

            foreach ($simpleXMLElement->$node->$childNode as $xmlImageElement) {
                $url = $this->getMediaPath($xmlImageElement);

                if ($this->getArticleMode() === BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE) {
                    $this->setHashExtension(md5($this->getMediaName($url) . $variationsId));
                }

                if (strlen($url) === 0) {
                    $this->throwWarning('path');
                    continue;
                }

                $oldImageModel = $this->loadMediaIfExists($article->getId(), $url);

                if (($oldImageModel === null || (int)$xmlImageElement['changed'] === 1) && ImageHelper::getInstance()->getPreSaveIsActive() === false) {
                    $media = $this->downloadMediaData($url);

                    if ($this->getImageAlreadyExists() === false) {
                        $oldImageModel = new SwImage();
                    }
                } else {
                    $media = $oldImageModel->getMedia();

                    if ($mediaService->has($media->getPath()) === false) {
                        $result = $this->mediaLoader($url, $this->removeSpecialCharacters($this->getMediaName($url)), $this->getMediaExtension($url));

                        if ($result['success'] === true) {
                            $file = new File($result['name']);

                            if ($media instanceof \Shopware\Models\Media\Media) {
                                $media->setFile($file);
                                $media->onSave();
                            }

                            Shopware()->Models()->persist($media);
                        }
                    }
                }

                if ($media !== null) {
                    if ($media instanceof \Shopware\Models\Media\Media && $oldImageModel instanceof \Shopware\Models\Article\Image) {
                        $newImageModel = $this->prepareImageData($article, $oldImageModel, $media, $xmlImageElement, $mode);

                        if ($this->getArticleMode() === BfArticleAbstract::IMPORT_ARTICLE_VARIATION_IMPORT_MODE) {
                            $name = rtrim($this->getMediaName($url), '_') . self::SUFFIX . $this->getHashExtension();
                            $name = $this->removeSpecialCharacters($name);

                            ImageHelper::getInstance()->setPreSaveImages($newImageModel, $media, $name);

                            BfArticleAbstract::setToDeleteImageMappings($newImageModel);
                            ImageHelper::getInstance()->setPreSaveIsActive(false);
                        }

                        if ($newImageModel instanceof \Shopware\Models\Article\Image) {
                            if ($this->getArticleMode() !== BfArticleAbstract::IMPORT_ARTICLE_IMAGE_MODE) {
                                $prepareImages[(int)$xmlImageElement['sort']] = $newImageModel;
                            }

                            Shopware()->Models()->persist($newImageModel);
                            $article->getImages()->add($newImageModel);
                            try {
                                if ($newImageModel->getAttribute() === null) {
                                    $imageAttributeModel = new \Shopware\Models\Attribute\ArticleImage();
                                    $imageAttributeModel->setArticleImage($newImageModel);
                                } else {
                                    $imageAttributeModel = $newImageModel->getAttribute();
                                }

                                if ((bool)$xmlImageElement->Attributes === true && (bool)$xmlImageElement->Attributes->Attribute === true) {
                                    foreach ($xmlImageElement->Attributes->Attribute as $imagesAttributes) {
                                        $code                       = $imagesAttributes['code'];
                                        $mappingImagesAttributeRepo = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingImageAttributes');
                                        /** @var \Shopware\CustomModels\BfSaleschannel\MappingImageAttributes $mappingImagesAttributeModel */
                                        $mappingImagesAttributeModel = $mappingImagesAttributeRepo->findOneBy(array('attributesCode' => $code));

                                        if ($mappingImagesAttributeModel !== null) {
                                            $mappingFieldKey               = $mappingImagesAttributeModel->getMappingFieldKey();
                                            $imageDescriptionAttributeName = ConfigManager::getInstance()->getImageDescriptionAttributeName();
                                            $imageAttributeValue           = (string)$imagesAttributes->Value;

                                            $setter = ucwords($mappingFieldKey, '_');
                                            $setter = 'set' . ucfirst($setter);
                                            $setter = str_replace('_', '', $setter);

                                            if (method_exists($imageAttributeModel, $setter) === true) {
                                                $value = (string)$imagesAttributes->Value;
                                                $imageAttributeModel->$setter($value);
                                                Shopware()->Models()->persist($imageAttributeModel);

                                                if(strlen($imageDescriptionAttributeName) > 0) {
                                                    // should be "attribute1" === "attribute1" for example
                                                    if($imageDescriptionAttributeName === $mappingFieldKey) {
                                                        $newImageModel->setDescription($imageAttributeValue);
                                                        Shopware()->Models()->persist($newImageModel);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } catch (\Exception $exception){}

                        } else {
                            LogManager::getInstance()
                                ->writeLogForGui(Log::LOG_STATUS_WARNING, __METHOD__, str_replace(array('{$url}'), array($url), ErrorCodes::CANNOT_SAVE_IMAGE), Helper::getUserId(),
                                    Log::TYPE_OF_LOG_IMPORT_PRODUCTS, 000, ErrorCodes::CANNOT_SAVE_IMAGE_ERROR_CODE, false, false);
                            continue;
                        }
                    } else {
                        LogManager::getInstance()
                            ->writeLogForGui(Log::LOG_STATUS_WARNING, __METHOD__, str_replace(array('{$url}'), array($url), ErrorCodes::CANNOT_SAVE_IMAGE), Helper::getUserId(),
                                Log::TYPE_OF_LOG_IMPORT_PRODUCTS, 000, ErrorCodes::CANNOT_SAVE_IMAGE_ERROR_CODE, false, false);
                        continue;
                    }
                }
            }
        }

        $this->prepareToDeleteImageList($article->getId(), $detail);

        return $prepareImages;
    }
}
