<?php
/**
 * ImagesDiffsOptions.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Images;

use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Helper;
use Shopware\CustomModels\BfSaleschannel\Log;
use Bf\Saleschannel\Components\Util\ImageHelper;
use Bf\Saleschannel\Components\Util\LogManager;
use \Shopware\Models\Article\Article as SwArticle;
use Shopware\Models\Article\Image as SwImage;
use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract as BfArticleAbstract;
use Shopware\Models\Article\Image;
use SimpleXMLElement;
use Symfony\Component\HttpFoundation\File\File;

class ImagesDiffsOptions extends ImagesAbstract
{
    /**
     * @param SimpleXMLElement $simpleXMLElement
     * @param SwArticle $article
     * @param $mode
     * @param $detail
     * @param $node
     * @param int $bfProductsId
     *
     * @return array
     */
    public function prepareImages(SimpleXMLElement $simpleXMLElement, SwArticle $article, $mode, $detail, $node, $bfProductsId = 0)
    {
        $prepareImages = array();
        $this->setArticleMode($mode);

        if ($this->isElementAvailable($simpleXMLElement, $node) === true) {
            /** @var \Shopware\Bundle\MediaBundle\MediaService $mediaService */
            $mediaService = Shopware()->Container()->get('shopware_media.media_service');
            $childNode    = self::CHILD_NODE_VARIATION_IMAGE;

            foreach ($simpleXMLElement->$node->$childNode as $xmlImageElement) {
                $forceImageDownload = false;
                $url                = $this->getMediaPath($xmlImageElement);
                $this->setHashExtension(md5($bfProductsId));

                $name = rtrim($this->getMediaName($url), '_') . self::SUFFIX . $this->getHashExtension();
                $name = $this->removeSpecialCharacters($name);

                if (strlen($url) === 0) {
                    $this->throwWarning('path');
                    continue;
                }

                $oldImageModel = $this->loadMediaIfExists($article->getId(), $url);

                if ($oldImageModel !== null && $oldImageModel->getMedia() !== null && array_key_exists($name, ImageHelper::getInstance()->getImageCache()) === false) {
                    $forceImageDownload = true;
                } else if (array_key_exists($name, ImageHelper::getInstance()->getImageCache()) === true) {
                    $oldImageModel = ImageHelper::getInstance()->getImageCache()[$name]['img'];
                } else {
                    $forceImageDownload = true;
                }

                if (($oldImageModel === null || (int)$xmlImageElement['changed'] === 1) && $forceImageDownload === true) {
                    $media = $this->downloadMediaData($url);

                    if ($this->getImageAlreadyExists() === false) {
                        $oldImageModel = new SwImage();
                    }
                } else {
                    $media = $oldImageModel->getMedia();

                    if ($mediaService->has($media->getPath()) === false) {
                        $result = $this->mediaLoader($url, $this->removeSpecialCharacters($this->getMediaName($url)), $this->getMediaExtension($url));

                        if ($result['success'] === true) {
                            $file = new File($result['name']);

                            if ($media instanceof \Shopware\Models\Media\Media) {
                                $media->setFile($file);
                                $media->onSave();
                            }

                            Shopware()->Models()->persist($media);
                        }
                    }
                }

                if ($media !== null && $media instanceof \Shopware\Models\Media\Media && $oldImageModel instanceof \Shopware\Models\Article\Image) {
                    $newImageModel = $this->prepareImageData($article, $oldImageModel, $media, $xmlImageElement, $mode);
                    ImageHelper::getInstance()->setPreSaveImages($newImageModel, $media, $name);

                    if ($newImageModel instanceof \Shopware\Models\Article\Image) {
                        $prepareImages[(int)$xmlImageElement['sort']] = $newImageModel;

                        if (array_key_exists($name, ImageHelper::getInstance()->getImageCache()) === false) {
                            Shopware()->Models()->persist($newImageModel);
                            $article->getImages()->add($newImageModel);
                            ImageHelper::getInstance()->addImageCacheItem($name, $media, $newImageModel);

                            try {
                                if ($newImageModel->getAttribute() === null) {
                                    $imageAttributeModel = new \Shopware\Models\Attribute\ArticleImage();
                                } else {
                                    $imageAttributeModel = $newImageModel->getAttribute();
                                }

                                if ((bool)$xmlImageElement->Attributes === true && (bool)$xmlImageElement->Attributes->Attribute === true) {
                                    foreach ($xmlImageElement->Attributes->Attribute as $imagesAttributes) {
                                        $code                       = $imagesAttributes['code'];
                                        $mappingImagesAttributeRepo = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingImageAttributes');
                                        /** @var \Shopware\CustomModels\BfSaleschannel\MappingImageAttributes $mappingImagesAttributeModel */
                                        $mappingImagesAttributeModel = $mappingImagesAttributeRepo->findOneBy(array('attributesCode' => $code));

                                        if ($mappingImagesAttributeModel !== null) {
                                            $setter = ucwords($mappingImagesAttributeModel->getMappingFieldKey(), '_');
                                            $setter = 'set' . ucfirst($setter);
                                            $setter = str_replace('_', '', $setter);

                                            if (method_exists($imageAttributeModel, $setter) === true) {
                                                $value = ((bool)$imagesAttributes->Value === true) ? (string)$imagesAttributes->Value : null;
                                                $imageAttributeModel->$setter($value);
                                                Shopware()->Models()->persist($imageAttributeModel);
                                            }
                                        }
                                    }
                                }
                            } catch (\Exception $exception){}
                        }

                    } else {
                        LogManager::getInstance()
                            ->writeLogForGui(Log::LOG_STATUS_WARNING, __METHOD__, str_replace(array('{$url}'), array($url), ErrorCodes::CANNOT_SAVE_IMAGE), Helper::getUserId(),
                                Log::TYPE_OF_LOG_IMPORT_PRODUCTS, 000, ErrorCodes::CANNOT_SAVE_IMAGE_ERROR_CODE, false, false);
                        continue;
                    }
                } else {
                    LogManager::getInstance()
                        ->writeLogForGui(Log::LOG_STATUS_WARNING, __METHOD__, str_replace(array('{$url}'), array($url), ErrorCodes::CANNOT_SAVE_IMAGE), Helper::getUserId(),
                            Log::TYPE_OF_LOG_IMPORT_PRODUCTS, 000, ErrorCodes::CANNOT_SAVE_IMAGE_ERROR_CODE, false, false);
                    continue;
                }
            }
        }
        $this->prepareToDeleteImageList($article->getId(), $detail);

        return $prepareImages;
    }
}