<?php
/**
 * MappingAbstract.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Components\Resources\Images;

use Bf\Saleschannel\Components\Util\Helper;
use Doctrine\Common\Collections\ArrayCollection;
use Exception;
use Shopware\Models\Article\Article as SwArticle;
use Shopware\Models\Article\Image\Mapping as SwImageMapping;
use Shopware\Models\Article\Image\Rule as SwImageRule;
use Shopware\Models\Article\Image as SwImage;
use Shopware\Models\Article\Detail as SwDetail;
use Shopware\Models\Article\Configurator\Option as SwOption;
use Bf\Saleschannel\Components\Resources\Images\Images as BfImage;
use Bf\Saleschannel\Components\Resources\Images\ImagesDiffsOptions as BfImageDiffsOptions;
use Bf\Saleschannel\Components\Resources\Article\ArticleAbstract as BfArticleAbstract;

use SimpleXMLElement;

class MappingAbstract
{
    const FILE_NAME                      = 'Mapping';
    const DEACTIVATE_VARIATION_MAIN_FLAG = 2;
    const ACTIVATE_VARIATION_MAIN_FLAG   = 1;
    const VARIATIONS_IMAGES_NODE_NAME    = 'VariationImages';
    const MAIN_IMAGE_BASE_PRODUCT        = 'BASE_PRODUCT';
    const MAIN_IMAGE_NON_BASE_PRODUCT    = 'NON_BASE_PRODUCT';

    /** @var null|SwDetail */
    private $swDetail = null;

    /** @var null|SwArticle */
    private $swArticle = null;

    /** @var null|SimpleXMLElement */
    private $variationXmlElement = null;

    /** @var null|BfImage|BfImageDiffsOptions */
    private $bfImageType = null;

    /** @var array */
    private $options = array();

    /** @var int */
    private $bfProductsId = 0;

    /** @var string */
    private $mainImageType = self::MAIN_IMAGE_NON_BASE_PRODUCT;

    /**
     * @param SwDetail $swDetail
     * @param SwArticle $swArticle
     * @param SimpleXMLElement $variationXmlElement
     * @param $bfImageType
     * @param array $options
     * @param $bfProductsId
     */
    public function __construct(SwDetail $swDetail, SwArticle $swArticle, SimpleXMLElement $variationXmlElement, $bfImageType, $options = array(), $bfProductsId)
    {
        $this->setSwDetail($swDetail);
        $this->setSwArticle($swArticle);
        $this->setVariationXmlElement($variationXmlElement);
        $this->setBfImageType($bfImageType);
        $this->setOptions($options);
        $this->setBfProductsId($bfProductsId);

    }

    protected function calculateMainImageType()
    {
        /** @var \Shopware\Models\Article\Image $swImage */
        foreach ($this->getSwArticle()->getImages() as $swImage) {
            if (method_exists($swImage, 'getMain') === true) {
                if ($swImage->getMain() === 1 && count($swImage->getChildren()) <= 0) {
                    $this->setMainImageType(self::MAIN_IMAGE_BASE_PRODUCT);
                }
            }
        }

        if (Helper::$mainImageBaseProductsIsSet === true) {
            $this->setMainImageType(self::MAIN_IMAGE_BASE_PRODUCT);
        }
    }

    /**
     * @return null|SwDetail
     */
    public function getSwDetail()
    {
        return $this->swDetail;
    }

    /**
     * @param null|SwDetail $swDetail
     */
    public function setSwDetail($swDetail)
    {
        $this->swDetail = $swDetail;
    }

    /**
     * @return null|SwArticle
     */
    public function getSwArticle()
    {
        return $this->swArticle;
    }

    /**
     * @param null|SwArticle $swArticle
     */
    public function setSwArticle($swArticle)
    {
        $this->swArticle = $swArticle;
    }

    /**
     * @return null|SimpleXMLElement
     */
    public function getVariationXmlElement()
    {
        return $this->variationXmlElement;
    }

    /**
     * @param null|SimpleXMLElement $variationXmlElement
     */
    public function setVariationXmlElement($variationXmlElement)
    {
        $this->variationXmlElement = $variationXmlElement;
    }

    /**
     * @return Images|ImagesDiffsOptions|null
     */
    public function getBfImageType()
    {
        return $this->bfImageType;
    }

    /**
     * @param Images|ImagesDiffsOptions|null $bfImageType
     */
    public function setBfImageType($bfImageType)
    {
        $this->bfImageType = $bfImageType;
    }

    /**
     * @return array
     */
    public function getOptions()
    {
        return $this->options;
    }

    /**
     * @param array $options
     */
    public function setOptions($options)
    {
        $this->options = $options;
    }

    /**
     * @return string
     */
    public function getMainImageType()
    {
        return $this->mainImageType;
    }

    /**
     * @param string $mainImageType
     */
    public function setMainImageType($mainImageType)
    {
        $this->mainImageType = $mainImageType;
    }

    /**
     * @return int
     */
    public function getBfProductsId()
    {
        return $this->bfProductsId;
    }

    /**
     * @param int $bfProductsId
     */
    public function setBfProductsId($bfProductsId)
    {
        $this->bfProductsId = $bfProductsId;
    }
}