<?php
namespace Bf\Saleschannel\Install;

/**
 * RegisterEvents
 *
 * @package Bf\Saleschannel\Install
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class RegisterEvents extends InstallAbstract
{
    /**
     * @param \Shopware_Components_Plugin_Bootstrap $shopwarePluginBootstrapClass
     */
    public function __construct($shopwarePluginBootstrapClass)
    {
        parent::__construct($shopwarePluginBootstrapClass);
    }

    /**
     * @return void
     */
    public function executeRegisterEvents()
    {
        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Enlight_Controller_Dispatcher_ControllerPath_Backend_Brickfox',
            'onGetControllerPath'
        );

        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Enlight_Controller_Dispatcher_ControllerPath_Backend_BrickfoxUi',
            'onGetUiControllerPath'
        );

        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Enlight_Controller_Dispatcher_ControllerPath_Backend_BrickfoxUiLog',
            'onGetUiControllerLogPath'
        );

        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Enlight_Controller_Dispatcher_ControllerPath_Backend_BrickfoxUiErrorCodeList',
            'onGetUiControllerErrorCodeList'
        );

        /** insert the css */
        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Enlight_Controller_Action_PostDispatch_Backend_Index',
            'onPostDispatchBackendIndex'
        );

        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Shopware\CustomModels\BfSaleschannel\Log::prePersist',
            'prePersistLog'
        );

        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Shopware\Models\Article\Article::preRemove',
            'preRemoveArticle'
        );
    }

    /**
     * @return void
     */
    public function __destruct()
    {
        parent::__destruct();
    }
}
