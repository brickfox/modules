<?php
namespace Bf\Saleschannel\Components;

use Bf\Saleschannel\Components\Resources\Orders\OrdersStatusMail;
use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\ErrorCodes;
use Bf\Saleschannel\Components\Util\Exceptions;
use Bf\Saleschannel\Components\Util\FileManager;
use Bf\Saleschannel\Components\Util\FileWriter;
use Bf\Saleschannel\Components\Util\Iterator;
use Bf\Saleschannel\Components\Util\LogManager;
use Bf\Saleschannel\Components\Util\ScriptLogger;
use Doctrine\Common\Collections\Criteria;
use Shopware\CustomModels\BfSaleschannel\ApiExportOrdersHistory as OrderHistory;
use Shopware\Models\Order\Order as SwOrder;
use Bf\Saleschannel\Components\Util\Helper;
use Exception;
use XMLWriter;

/**
 * ExportAbstract
 *
 * @package Bf\Saleschannel\Components
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
abstract class ExportAbstractOrders
{
    const ORDER_PENDING_STATUS_ID = 1;

    const ROOT_ORDER_XML_ELEMENT = 'Orders';

    /** @var int */
    private $exportItemsCount = 1;

    /** @var string */
    private $randomOrdersFileName = '';

    /** @var string */
    private $destinationPath = '';

    /** @var string */
    private $finalOrderFileName = '';

    /** @var array */
    private $orderExportByPaymentStatus = [];

    /**
     * @param $logEntity
     *
     * @return void
     */
    public function export($logEntity)
    {
        $this->preExport();

        $shopsRepository = Helper::getRepository('Shopware\Models\Shop\Shop');

        if (strlen(Helper::getConfigurationByKey('ignoreOrdersByShopsIds')->getConfigurationValue()) > 0) {
            $shopsIdsToExclude = array_map(
                'trim',
                explode(',', Helper::getConfigurationByKey('ignoreOrdersByShopsIds')->getConfigurationValue())
            );

            $shopsModel = $shopsRepository
                ->createQueryBuilder('s')
                ->where('s.active = :active')
                ->addCriteria(
                    (new Criteria())
                        ->where(Criteria::expr()->notIn('id', $shopsIdsToExclude))
                )
                ->setParameter('active', 1)
                ->getQuery()
                ->getResult();
        } else {
            $shopsModel = $shopsRepository->findBy(['active' => 1]);
        }

        /** \Shopware\Models\Shop\Shop $shopsModel */
        if(count($shopsModel) > 0)
        {
            $exportOrdersList = $this->getExportOrdersList($shopsModel);

            if(count($exportOrdersList) > 0)
            {
                foreach($exportOrdersList as $shopsId => $ordersList)
                {
                    foreach($ordersList as $languageId => $orderList)
                    {

                        $this->generateRandomOrdersFileName();
                        $this->generateFinalOrdersFileName();

                        Helper::checkPath(
                            ConfigManager::getInstance()->getExchangeDirectory() . ConfigManager::getInstance()->getOutgoingDestinationDirectory() . $shopsId . DIRECTORY_SEPARATOR .
                            $languageId,
                            true
                        );

                        $this->generateDestinationPath(
                            ConfigManager::getInstance()->getExchangeDirectory() . ConfigManager::getInstance()->getOutgoingDestinationDirectory() . $shopsId . DIRECTORY_SEPARATOR .
                            $languageId
                        );

                        $destinationPath = $this->getDestinationPath() . $this->getRandomOrdersFileName();

                        $xmlWriter = new XMLWriter();
                        $xmlWriter->openUri($destinationPath);
                        $xmlWriter->setIndent(true);
                        $xmlWriter->startDocument('1.0', 'UTF-8');
                        $xmlWriter->startElement(self::ROOT_ORDER_XML_ELEMENT);
                        $xmlWriter->writeAttribute('count', 1);

                        if(count($orderList) > 0)
                        {
                            /** @var \Shopware\Models\Order\Order $orderItem */
                            foreach($orderList as $orderItem)
                            {
                                try
                                {
                                    $this->processExport($orderItem, $xmlWriter);
                                    $this->setExportItemsCount(1);
                                    FileWriter::$internalArrayKeyCounter++;
                                    FileWriter::$xmlElements = [];

                                    $orderStatusModel = Helper::getMappingById('Shopware\Models\Order\Status', self::ORDER_PENDING_STATUS_ID);

                                    if($orderStatusModel === null)
                                    {
                                        Exceptions::throwException(ErrorCodes::CAN_NOT_LOAD_ORDER_STATUS_MODEL_BY_ID, ['{$id}'], [1]);
                                    } else {
                                        $orderItem->setOrderStatus($orderStatusModel);

                                        if (Helper::getConfigurationByKey('sendPendingMail')->getConfigurationValue() === 'true') {
                                            OrdersStatusMail::getInstance()->setOrdersStatusModels(
                                                [
                                                    'orderId'  => $orderItem->getId(),
                                                    'statusId' => self::ORDER_PENDING_STATUS_ID
                                                ]
                                            );
                                        }
                                    }

                                    Shopware()->Models()->persist($orderItem);
                                }
                                catch(Exception $e)
                                {
                                    ScriptLogger::getInstance()->errorHandler($e->getCode(), $e->getMessage(), $e->getFile(), $e->getLine());
                                    LogManager::logException($e, $logEntity);
                                    continue;
                                }
                            }
                            $xmlWriter->endElement();
                            $xmlWriter->endDocument();
                            FileWriter::$internalArrayKeyCounter = 0;

                            $this->writeOrderHistory($destinationPath);

                            Shopware()->Models()->flush();

                            $this->postExport($destinationPath);
                        }
                    }
                }
            }
        }
    }

    /**
     * @param $destinationPath
     *
     * @removed param \Shopware\Models\Shop\Shop $shops
     * @removed param \Shopware\CustomModels\BfSaleschannel\Configuration $configurationModel
     */
    private function generateDestinationPath($destinationPath)
    {
        $this->setDestinationPath($destinationPath . DIRECTORY_SEPARATOR);
    }

    /**
     * @param $shopsModel
     *
     * @return array
     * @internal param $shops
     */
    private function getExportOrdersList($shopsModel)
    {
        $exportOrdersList   = [];
        $configurationValue = Helper::getConfigurationByKey('orderStatusMultiSelect')->getConfigurationValue();
        $configurationValue = explode(',', $configurationValue);

        /** @var \Shopware\Models\Shop\Shop $shops */
        foreach($shopsModel as $shops)
        {
            $orders = [];

            foreach($configurationValue as $orderStatusId)
            {
                $now = time();

                $ordersList = Shopware()->Db()->fetchAll(
                    "
                    select o.id, o.ordertime
                    from s_order o
                    left join s_order_billingaddress sob on sob.orderID = o.id
                    left join s_order_shippingaddress sos on sos.orderID = o.id
                    where o.`status` = ? and o.subshopID = ? and sob.userID = o.userID
                    and (sob.id is not null and sos.id is not null)
                ",
                    [(int)$orderStatusId, $shops->getId()]
                );

                if(count($ordersList) > 0)
                {
                    foreach($ordersList as $order)
                    {
                        $timeStamp1 = strtotime($order['ordertime']);

                        if(($now - $timeStamp1) > 300)
                        {
                            $repository = Shopware()->Models()->getRepository('Shopware\Models\Order\Order');
                            /** @var \Shopware\Models\Order\Order $orderItem */
                            $orderItem = $repository->find($order['id']);

                            $mappingsPaymentIdToPaymentStatusIds = $this->getOrderExportByPaymentStatus();

                            if (count($mappingsPaymentIdToPaymentStatusIds) > 0) {
                                if (array_key_exists($orderItem->getPayment()->getId(), $mappingsPaymentIdToPaymentStatusIds) === true
                                    && in_array($orderItem->getPaymentStatus()->getId(), $mappingsPaymentIdToPaymentStatusIds[$orderItem->getPayment()->getId()]) === false) {
                                    continue;
                                }
                            }

                            if($orderItem !== null)
                            {
                                $orders[$orderItem->getLanguageSubShop()->getId()][] = $orderItem;
                            }
                        }
                    }
                }

                $exportOrdersList[$shops->getId()] = $orders;
            }
        }

        return $exportOrdersList;
    }

    /**
     * @return void
     */
    protected function preExport()
    {
        $orderExportByPaymentStatusRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfSaleschannel\MappingOrderExportByPaymentStatus');
        $orderExportByMappingStatus = $orderExportByPaymentStatusRepository->findAll();

        if (count($orderExportByMappingStatus) > 0) {
            /** @var \Shopware\CustomModels\BfSaleschannel\MappingOrderExportByPaymentStatus $mappingModel */
            foreach($orderExportByMappingStatus as $mappingModel) {
                $this->addOrderExportByPaymentStatusItem($mappingModel->getPaymentId(), $mappingModel->getPaymentStatusId());
            }
        }
    }

    /**
     * @param null $tmpDestinationPath
     *
     * @return void
     */
    protected function postExport($tmpDestinationPath = null)
    {
        if(file_exists($tmpDestinationPath) === true)
        {
            copy($tmpDestinationPath, $this->getDestinationPath() . $this->getFinalOrderFileName());
        }

        FileManager::getInstance()->moveExportFile($this->getDestinationPath() . $this->getFinalOrderFileName());
        FileManager::getInstance()->moveExportFile($tmpDestinationPath);
        unlink($tmpDestinationPath);
        OrdersStatusMail::getInstance()->sendStatusMail();
    }

    /**
     * @param null $destinationPath
     */
    private function writeOrderHistory($destinationPath = null)
    {
        $xmlReader = new \XMLReader();
        $xmlReader->open($destinationPath, null, LIBXML_NOCDATA);

        try
        {
            while($xmlReader->read() === true)
            {
                if($xmlReader->nodeType === \XMLReader::ELEMENT && $xmlReader->depth === 1)
                {
                    $simpleXmlElement = $xmlReader->readOuterXml();
                    $xmlElement       = new \SimpleXMLElement((string) $simpleXmlElement);

                    $orderHistoryModel = new OrderHistory();
                    $orderHistoryModel->setData((string) $simpleXmlElement);
                    $orderHistoryModel->setOrderNumber((string) $xmlElement->OrderId);
                    $orderHistoryModel->setDateInsert(date('Y-m-d h:i:s', time()));
                    Shopware()->Models()->persist($orderHistoryModel);
                }
            }
        }
        catch(Exception $e)
        {
            echo $e->getTraceAsString();
        }
    }

    /**
     * @param int $len
     *
     * @return string
     */
    private function generateRandomOrdersFileName($len = 15)
    {
        $this->setRandomOrdersFileName(substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $len) . '.tmp');
    }

    /**
     * @return string
     */
    private function generateFinalOrdersFileName()
    {
        $this->setFinalOrderFileName('Orders_' . date('Ymd_His', time()) . '.xml');
    }

    /**
     * @return int
     */
    public function getExportItemsCount()
    {
        return $this->exportItemsCount;
    }

    /**
     * @param int $exportItemsCount
     */
    public function setExportItemsCount($exportItemsCount)
    {
        $this->exportItemsCount += $exportItemsCount;
    }

    /**
     * @return string
     */
    public function getRandomOrdersFileName()
    {
        return $this->randomOrdersFileName;
    }

    /**
     * @param string $randomOrdersFileName
     */
    public function setRandomOrdersFileName($randomOrdersFileName)
    {
        $this->randomOrdersFileName = $randomOrdersFileName;
    }

    /**
     * @return string
     */
    public function getDestinationPath()
    {
        return $this->destinationPath;
    }

    /**
     * @param string $destinationPath
     */
    public function setDestinationPath($destinationPath)
    {
        $this->destinationPath = $destinationPath;
    }

    /**
     * @return string
     */
    public function getFinalOrderFileName()
    {
        return $this->finalOrderFileName;
    }

    /**
     * @param string $finalOrderFileName
     */
    public function setFinalOrderFileName($finalOrderFileName)
    {
        $this->finalOrderFileName = $finalOrderFileName;
    }

    /**
     * @return array
     */
    public function getOrderExportByPaymentStatus()
    {
        return $this->orderExportByPaymentStatus;
    }

    /**
     * @param array $orderExportByPaymentStatus
     */
    public function setOrderExportByPaymentStatus($orderExportByPaymentStatus)
    {
        $this->orderExportByPaymentStatus = $orderExportByPaymentStatus;
    }

    /**
     * @param $paymentId
     * @param $paymentStatusId
     */
    public function addOrderExportByPaymentStatusItem($paymentId, $paymentStatusId) {
        $this->orderExportByPaymentStatus[$paymentId][] = $paymentStatusId;
    }

    /**
     * @param  \Shopware\Models\Order\Order $item
     * @param XMLWriter $XMLWriter
     *
     * @return mixed
     */
    abstract protected function processExport(\Shopware\Models\Order\Order $item, XMLWriter $XMLWriter);
}
