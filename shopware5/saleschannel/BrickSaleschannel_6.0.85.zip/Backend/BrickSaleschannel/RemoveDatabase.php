<?php
/**
 * RemoveDatabase
 *
 * @package Bf\Saleschannel\Install
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Install;

class RemoveDatabase extends InstallAbstract
{
    /**
     * @param \Shopware_Components_Plugin_Bootstrap $shopwarePluginBootstrapClass
     */
    public function __construct($shopwarePluginBootstrapClass)
    {
        parent::__construct($shopwarePluginBootstrapClass);
    }

    public function executeRemoveDatabase()
    {
        $sql = "DROP TABLE IF EXISTS bf_mapping_articles;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_details;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_categories;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_suppliers;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_scriptlogger;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_configuration;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_attr;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_log;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_customized;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_currencies";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_translation";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_shops";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_filters;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_filters_relations;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_import_data;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_import_data_detail;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_import_data;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_import_data_detail;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_tax;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_shipping_status;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_import_price_hash;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_export_orders_history;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_configurator_groups;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_configurator_options;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_order_attr;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_export_seo_urls;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_special_prices;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_payment_to_payment_status;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_order_lines_attr;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_order_export_by_payment_status;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_image_attr;";
        Shopware()->Db()->query($sql);
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
