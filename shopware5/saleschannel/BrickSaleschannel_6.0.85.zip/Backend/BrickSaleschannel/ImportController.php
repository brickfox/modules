<?php
namespace Bf\Saleschannel\Components;

use Bf\Saleschannel\Components\Import\CalculateSpecialPrices;
use Bf\Saleschannel\Components\Util\FileManager;
use Bf\Saleschannel\Components\Util\LogManager;
use Bf\Saleschannel\Components\Util\ScriptLogger;
use Exception;

/**
 * ImportController
 *
 * @package Bf\Saleschannel\Components
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class ImportController
{
    const LOG_ENTITY = 'ImportController';

    public function importAll()
    {
        $this->importManufacturers();
        $this->importCategories();
        $this->importProducts();
        $this->importProductsAssignment();
        $this->importProductsBundle();
        $this->importOrdersStatus();
    }

    public function importCategories()
    {
        ScriptLogger::getInstance()->run('import/Categories');
        $filesToImport = FileManager::getInstance()->getImportFiles(FileManager::FILENAME_BASE_CATEGORIES);
        $this->import($filesToImport, __FUNCTION__);
    }

    public function importManufacturers()
    {
        ScriptLogger::getInstance()->run('import/Manufacturers');
        $filesToImport = FileManager::getInstance()->getImportFiles(FileManager::FILENAME_BASE_MANUFACTURERS);
        $this->import($filesToImport, __FUNCTION__);
    }

    public function importProducts()
    {
        $productsUpdateIsRunning = ScriptLogger::getInstance()->checkIfSpecifiedScriptLoggerIsRunning('import/ProductsUpdate');

        if($productsUpdateIsRunning === false)
        {
            ScriptLogger::getInstance()->run('import/Products');
            $filesToImport = FileManager::getInstance()->getImportFiles(FileManager::FILENAME_BASE_PRODUCTS);
            $this->import($filesToImport, __FUNCTION__);
        }
    }

    public function importProductsAssignment()
    {
        ScriptLogger::getInstance()->run('import/ProductsAssignments');
        $filesToImport = FileManager::getInstance()->getImportFiles(FileManager::FILENAME_BASE_PRODUCTS_ASSIGNMENTS);
        $this->import($filesToImport, __FUNCTION__);
    }

    public function importProductsUpdate()
    {
        $productsImportIsRunning = ScriptLogger::getInstance()->checkIfSpecifiedScriptLoggerIsRunning('import/Products');

        if($productsImportIsRunning === false)
        {
            ScriptLogger::getInstance()->run('import/ProductsUpdate');
            $filesToImport = FileManager::getInstance()->getImportFiles(FileManager::FILENAME_BASE_PRODUCTS_UPDATE);
            $this->import($filesToImport, __FUNCTION__);
        }
    }

    public function importOrdersStatus()
    {
        ScriptLogger::getInstance()->run('import/OrdersStatus');
        $filesToImport = FileManager::getInstance()->getImportFiles(FileManager::FILENAME_BASE_ORDERS_STATUS);
        $this->import($filesToImport, __FUNCTION__);
    }

    public function importMultiShops()
    {
        ScriptLogger::getInstance()->run('import/MultiShops');
        $filesToImport = FileManager::getInstance()->getImportFiles(FileManager::FILENAME_BASE_SUB_MULTI_SHOP);
        $this->import($filesToImport, __FUNCTION__);
    }

    public function importProductsBundle()
    {
        ScriptLogger::getInstance()->run('import/ProductsBundle');
        $filesToImport = FileManager::getInstance()->getImportFiles(FileManager::FILENAME_BASE_PRODUCTS_BUNDLES);
        $this->import($filesToImport, __FUNCTION__);
    }

    public function calculateSpecialPrices()
    {
        $productsUpdateIsRunning = ScriptLogger::getInstance()->checkIfSpecifiedScriptLoggerIsRunning('process/importProductsUpdate');
        $productsImportIsRunning = ScriptLogger::getInstance()->checkIfSpecifiedScriptLoggerIsRunning('process/importProducts');

        if($productsUpdateIsRunning === false && $productsImportIsRunning === false)
        {
            ScriptLogger::getInstance()->run('calculate/SpecialPrices');

            try
            {
                $calculateSpecialPriceClass = new CalculateSpecialPrices();
                $specialPriceCalculationList = $calculateSpecialPriceClass->getSpecialPriceList();
                $calculateSpecialPriceClass->calculate($specialPriceCalculationList);
            }
            catch(Exception $e)
            {
                echo '<pre>';
                print_r($e->getMessage());
                echo '</pre>';
                ScriptLogger::getInstance()->errorHandler($e->getCode(), $e->getMessage(), $e->getFile(), $e->getLine());
                LogManager::getInstance()->logException($e, __FUNCTION__);
            }
        }
    }

    /**
     * @param array $filesToImport
     * @param $methodName
     */
    private function import(array $filesToImport, $methodName)
    {
        foreach($filesToImport as $importFile)
        {
            try
            {
                LogManager::getInstance()->logDebug('Start importing ' . $importFile, self::LOG_ENTITY);

                $importer = new Import($importFile, $methodName);
                $importer->import();

                LogManager::getInstance()->logDebug('End importing ' . $importFile, self::LOG_ENTITY);
                LogManager::getInstance()->zipLogFiles();
                FileManager::getInstance()->moveImportFile($importFile);
            }
            catch(Exception $e)
            {
                ScriptLogger::getInstance()->errorHandler($e->getCode(), $e->getMessage(), $e->getFile(), $e->getLine());
                LogManager::getInstance()->logException($e, $methodName);
            }
        }
    }
}
