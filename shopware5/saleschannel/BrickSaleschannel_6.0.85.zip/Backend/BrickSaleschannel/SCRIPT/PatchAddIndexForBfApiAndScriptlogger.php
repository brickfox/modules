<?php
/**
 * PatchAddIndexForBfApiAndScriptlogger
 *
 * @package Bf\Saleschannel\Patches\SCRIPT
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2019 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Patches\SCRIPT;

use Bf\Saleschannel\Components\Util\Patches\PatchAbstract;

class PatchAddIndexForBfApiAndScriptlogger extends PatchAbstract
{
    const SQL_PATCH_FILE_NAME = 'Patches/SQL/PatchAddIndexForBfApiAndScriptlogger.sql';

    /**
     * @param null $shopwarePluginBootstrap
     */
    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    public function preparePatch()
    {
        $sqlContent = file_get_contents($this->getShopwarePluginBootstrapClass()->Path() . self::SQL_PATCH_FILE_NAME);

        Shopware()->Db()->query($sqlContent);
    }
}
