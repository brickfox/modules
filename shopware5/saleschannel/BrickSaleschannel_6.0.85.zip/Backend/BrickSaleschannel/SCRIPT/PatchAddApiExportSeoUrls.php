<?php
namespace Bf\Saleschannel\Patches\SCRIPT;

use Bf\Saleschannel\Components\Util\Patches\PatchAbstract;
use Doctrine\ORM\Tools\SchemaTool;

/**
 * Class PatchAddApiExportSeoUrls
 *
 * @package Bf\Saleschannel\Patches\SCRIPT
 */
class PatchAddApiExportSeoUrls extends PatchAbstract
{
    const SQL_PATCH_FILE_NAME = 'Patches/SQL/PatchAddServerProtocolConfiguration.sql';

    /**
     * @param null $shopwarePluginBootstrap
     */
    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    public function preparePatch()
    {
        $modelManager = Shopware()->Models();

        $schemaTool = new SchemaTool($modelManager);
        $schemaTool->createSchema(
            array(
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\ApiExportSeoUrls')
            )
        );

        $sqlContent = file_get_contents($this->getShopwarePluginBootstrapClass()->Path() . self::SQL_PATCH_FILE_NAME);
        Shopware()->Db()->query($sqlContent);
    }
}