<?php
namespace Bf\Saleschannel\Patches\SCRIPT;

use Bf\Saleschannel\Components\Util\Patches\PatchAbstract;

class PatchAddIgnoreLongDescriptionConfiguration extends PatchAbstract
{
    const SQL_PATCH_FILE_NAME = 'Patches/SQL/PatchAddIgnoreLongDescriptionConfiguration.sql';

    public function __construct($shopwarePluginBootstrapClass = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrapClass);
        parent::__construct(self::SQL_PATCH_FILE_NAME);
    }

    public function preparePatch()
    {
        $sqlContent = file_get_contents($this->getShopwarePluginBootstrapClass()->Path() . self::SQL_PATCH_FILE_NAME);

        Shopware()->Db()->query($sqlContent);
    }
}
