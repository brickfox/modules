<?php

namespace Bf\Saleschannel\Patches\SCRIPT;

use Bf\Saleschannel\Components\Util\Patches\PatchAbstract;

class PatchAddEnableMultishopImportsOfArticlesWithoutStockConfiguration extends PatchAbstract
{
    const SQL_PATCH_FILE_NAME = 'Patches/SQL/PatchAddEnableMultishopImportsOfArticlesWithoutStockConfiguration.sql';

    /**
     * @param null $shopwarePluginBootstrap
     */
    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    public function preparePatch()
    {
        $sqlContent = file_get_contents($this->getShopwarePluginBootstrapClass()->Path() . self::SQL_PATCH_FILE_NAME);

        Shopware()->Db()->query($sqlContent);
    }
}
