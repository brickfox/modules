<?php
namespace Bf\Saleschannel\Patches\SCRIPT;

use Bf\Saleschannel\Components\Util\Patches\PatchAbstract;
use Exception;
use PDO;

/**
 * Class PatchRemoveConfiguratorUniqueKeys
 *
 * @package Bf\Saleschannel\Patches\SCRIPT
 */
class PatchRemoveConfiguratorUniqueKeys extends PatchAbstract
{
    const SQL_PATCH_FILE_NAME = '';

    /**
     * @param null $shopwarePluginBootstrap
     */
    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct();
    }

    public function preparePatch()
    {
        $mysqlConfig                = include 'config.php';
        $mysqlConfigPDO['dbname']   = 'information_schema';
        $mysqlConfigPDO['username'] = $mysqlConfig['db']['username'];
        $mysqlConfigPDO['password'] = $mysqlConfig['db']['password'];
        $mysqlConfigPDO['host']     = $mysqlConfig['db']['host'];

        $pdo = new \Zend_Db_Adapter_Pdo_Mysql($mysqlConfigPDO);

        $result = $pdo->fetchOne('select CONSTRAINT_NAME from KEY_COLUMN_USAGE where TABLE_NAME = "bf_mapping_configurator_options" and COLUMN_NAME = "shopwareID"');

        if(strlen($result) > 0 && $result !== false)
        {
            Shopware()->Db()->exec("drop index $result on bf_mapping_configurator_options");
        }

        $result = $pdo->fetchOne('select CONSTRAINT_NAME from KEY_COLUMN_USAGE where TABLE_NAME = "bf_mapping_configurator_groups" and COLUMN_NAME = "shopwareID"');

        if(strlen($result) > 0 && $result !== false)
        {
            Shopware()->Db()->exec("drop index $result on bf_mapping_configurator_groups");
        }
    }
}