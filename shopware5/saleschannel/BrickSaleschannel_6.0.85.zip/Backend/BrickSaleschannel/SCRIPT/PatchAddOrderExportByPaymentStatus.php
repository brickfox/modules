<?php
/**
 * PatchAddOrderExportByPaymentStatus.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */
namespace Bf\Saleschannel\Patches\SCRIPT;

use Bf\Saleschannel\Components\Util\Patches\PatchAbstract;
use Doctrine\ORM\Tools\SchemaTool;

class PatchAddOrderExportByPaymentStatus extends PatchAbstract
{
    const SQL_PATCH_FILE_NAME = '';

    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    public function preparePatch()
    {
        $modelManager = Shopware()->Models();

        $schemaTool = new SchemaTool($modelManager);
        $schemaTool->createSchema(
            array(
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingOrderExportByPaymentStatus')
            )
        );
    }
}