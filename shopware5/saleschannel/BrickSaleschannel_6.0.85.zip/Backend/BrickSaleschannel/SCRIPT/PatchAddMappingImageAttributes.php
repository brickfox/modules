<?php
/**
 * PatchAddMappingImageAttributes.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2019 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Patches\SCRIPT;

use Bf\Saleschannel\Components\Util\Patches\PatchAbstract;
use Doctrine\ORM\Tools\SchemaTool;

class PatchAddMappingImageAttributes extends PatchAbstract
{
    const SQL_PATCH_FILE_NAME = '';

    /**
     * PatchAddApiExportOrdersHistory constructor.
     *
     * @param null $shopwarePluginBootstrap
     */
    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    /**
     * @throws \Doctrine\ORM\Tools\ToolsException
     */
    public function preparePatch()
    {
        $modelManager = Shopware()->Models();

        $schemaTool = new SchemaTool($modelManager);
        $schemaTool->createSchema(
            array(
                $modelManager->getClassMetadata('Shopware\CustomModels\BfSaleschannel\MappingImageAttributes')
            )
        );
    }
}