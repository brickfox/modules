<?php
/**
 * PatchAddNewUiSubscribes
 *
 * @package Bf\Saleschannel\Patches\SCRIPT
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Patches\SCRIPT;

use Bf\Saleschannel\Components\Util\Patches\PatchAbstract;

class PatchAddNewUiSubscribes extends PatchAbstract
{
    const SQL_PATCH_FILE_NAME = '';

    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    public function preparePatch()
    {
        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Enlight_Controller_Dispatcher_ControllerPath_Backend_BrickfoxUiLog',
            'onGetUiControllerLogPath'
        );

        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Enlight_Controller_Dispatcher_ControllerPath_Backend_BrickfoxUiErrorCodeList',
            'onGetUiControllerErrorCodeList'
        );
    }
}
