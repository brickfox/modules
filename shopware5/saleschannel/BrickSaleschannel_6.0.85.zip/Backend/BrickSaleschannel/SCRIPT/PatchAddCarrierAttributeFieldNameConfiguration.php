<?php
/**
 * PatchAddCarrierAttributeFieldNameConfiguration.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Saleschannel\Patches\SCRIPT;

use Bf\Saleschannel\Components\Util\Patches\PatchAbstract;
use Zend_Db_Adapter_Exception;

/**
 * Class PatchAddCarrierAttributeFieldNameConfiguration
 * @package Bf\Saleschannel\Patches\SCRIPT
 */
class PatchAddCarrierAttributeFieldNameConfiguration extends PatchAbstract
{
    const SQL_PATCH_FILE_NAME = 'Patches/SQL/PatchAddCarrierAttributeFieldNameConfiguration.sql';

    /**
     * PatchAddCarrierAttributeFieldNameConfiguration constructor.
     * @param null $shopwarePluginBootstrap
     */
    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);

        parent::__construct('');
    }

    /**
     * @throws Zend_Db_Adapter_Exception
     */
    public function preparePatch()
    {
        $sqlContent = file_get_contents($this->getShopwarePluginBootstrapClass()->Path() . self::SQL_PATCH_FILE_NAME);

        Shopware()->Db()->query($sqlContent);
    }
}