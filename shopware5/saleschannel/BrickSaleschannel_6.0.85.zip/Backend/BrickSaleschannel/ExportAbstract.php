<?php
namespace Bf\Saleschannel\Components;

use Bf\Saleschannel\Components\Export\ProductsReports;
use Bf\Saleschannel\Components\Util\ConfigManager;
use Bf\Saleschannel\Components\Util\FileManager;
use Bf\Saleschannel\Components\Util\FileWriter;
use Bf\Saleschannel\Components\Util\Helper;
use Bf\Saleschannel\Components\Util\Iterator;
use Bf\Saleschannel\Components\Util\LogManager;
use Bf\Saleschannel\Components\Util\ScriptLogger;
use Exception;
use XMLWriter;

/**
 * Class ExportAbstract
 *
 * @package Bf\Saleschannel\Components
 */
abstract class ExportAbstract
{
    const PRODUCTS_REPORTS_EXPORT = 'ProductsReports';

    /** @var int */
    private $exportItemsCount = 1;

    /** @var array */
    private $exportList = array();

    public function export($exportType, $logEntity)
    {
        $exportList = $this->preExport($exportType);

        $shopsRepository = Helper::getRepository('Shopware\Models\Shop\Shop');
        $shopsModel      = $shopsRepository->findBy(array('active' => 1));

        if(count($shopsModel) > 0 && count($exportList) > 0)
        {
            /** @var \Shopware\Models\Shop\Shop $shops */
            foreach($shopsModel as $shops)
            {
                if($exportType === ExportController::EXPORT_TYPE_PRODUCTS_REPORTS_SEO)
                {
                    $this->setExportList($this->checkItemsToExportViaSeoUrls($shops->getId(), $exportList));
                }

                Helper::checkPath(ConfigManager::getInstance()->getExchangeDirectory() . ConfigManager::getInstance()->getOutgoingDestinationDirectory() . $shops->getId(), true);

                $iterator = new Iterator($this->getExportList());
                $iterator->rewind();

                /** @var \Shopware\CustomModels\BfSaleschannel\Configuration $configurationModel */
                $configurationModel = Helper::getConfigurationByKey('outgoingPath');
                $destinationPath    = $configurationModel->getConfigurationValue() . DIRECTORY_SEPARATOR . $shops->getId() . DIRECTORY_SEPARATOR . self::PRODUCTS_REPORTS_EXPORT .
                                      '_' . date('Ymd_His', time()) . '.xml';

                $xmlWriter = new \XMLWriter();
                $xmlWriter->openUri($destinationPath);
                $xmlWriter->setIndent(true);
                $xmlWriter->startDocument('1.0', 'UTF-8');
                $xmlWriter->startElement(self::PRODUCTS_REPORTS_EXPORT);
                $xmlWriter->writeAttribute('count', $iterator->count());

                while($iterator->valid() === true)
                {
                    try
                    {
                        $exportItem = $iterator->current();

                        $this->processExport($exportItem, $xmlWriter, $shops->getId());
                        $this->setExportItemsCount(1);
                        FileWriter::$internalArrayKeyCounter++;
                        FileWriter::$xmlElements = array();
                    }
                    catch(Exception $e)
                    {
                        ScriptLogger::getInstance()->errorHandler($e->getCode(), $e->getMessage(), $e->getFile(), $e->getLine());
                        LogManager::logException($e, $logEntity);
                        $iterator->next();
                    }

                    $iterator->next();
                }

                $xmlWriter->endElement();
                $xmlWriter->endDocument();
                FileWriter::$internalArrayKeyCounter = 0;

                Shopware()->Models()->flush();

                $this->postExport($destinationPath);
            }
        }
    }

    /**
     * @param $exportType
     *
     * @return array
     */
    protected function preExport($exportType)
    {
        switch($exportType)
        {
            default:
                $exportList = $this->getDefaultExportList();
                break;
        }

        return $exportList;
    }

    /**
     * @param $destinationPath
     *
     * @return void
     */
    protected function postExport($destinationPath)
    {
        FileManager::getInstance()->moveExportFile($destinationPath);
    }

    /**
     * @return array
     */
    private function getDefaultExportList()
    {
        $exportList          = array();
        $mappingArticlesList = Shopware()->Db()->fetchAll(
            "
            select id, brickfoxID, shopwareID from bf_mapping_articles
            "
        );

        if(count($mappingArticlesList) > 0)
        {
            $exportList = $mappingArticlesList;
        }

        return $exportList;
    }

    /**
     * @param $shopsId
     * @param $exportList
     *
     * @return array
     */
    private function checkItemsToExportViaSeoUrls($shopsId, $exportList)
    {
        $itemsToExport = array();

        foreach($exportList as $fullExportList)
        {
            $apiExportSeoUrlsRepository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\ApiExportSeoUrls');
            /** @var \Shopware\CustomModels\BfSaleschannel\ApiExportSeoUrls $apiExportSeoUrlsModel */
            $apiExportSeoUrlsModel = $apiExportSeoUrlsRepository->findOneBy(array('brickfoxId' => $fullExportList['brickfoxID'], 'shopwareDetailsId' => null, 'subShopId' => $shopsId));

            if($apiExportSeoUrlsModel === null)
            {
                $itemsToExport[] = $fullExportList['shopwareID'];
            }
            else
            {
                $sCoreRewriteUrlsResult = Shopware()->Db()->fetchRow(
                    "
                    select org_path, path from s_core_rewrite_urls where main = ? and subshopID = ? and org_path = ?
                    ",
                    array(1, $shopsId, ProductsReports::ORG_PATH_PART . $fullExportList['shopwareID'])
                );

                if(empty($sCoreRewriteUrlsResult))
                {
                    $sCoreRewriteUrlsResult = Shopware()->Db()->fetchRow(
                        "
                            select org_path, path from s_core_rewrite_urls where main = ? and subshopID = ? and org_path = ?
                        ",
                        array(0, $shopsId, ProductsReports::ORG_PATH_PART . $fullExportList['shopwareID'])
                    );
                }

                if($apiExportSeoUrlsModel->getSeoPath() !== $sCoreRewriteUrlsResult['path'])
                {
                    $itemsToExport[] = $fullExportList['shopwareID'];
                }
                else
                {
                    $articleDetailsRepository = Helper::getRepository('Shopware\Models\Article\Detail');
                    /** @var array $articleDetailsCollection */
                    $articleDetailsCollection = $articleDetailsRepository->findBy(array('articleId' => $fullExportList['shopwareID']));

                    if(count($articleDetailsCollection) > 1)
                    {
                        /** @var \Shopware\Models\Article\Detail $articleDetailModel */
                        foreach($articleDetailsCollection as $articleDetailModel)
                        {
                            $bfMappingArticlesDetailRepository = Helper::getRepository('Shopware\CustomModels\BfSaleschannel\MappingDetails');
                            /** @var \Shopware\CustomModels\BfSaleschannel\MappingDetails $bfMappingArticleDetailModel */
                            $bfMappingArticleDetailModel = $bfMappingArticlesDetailRepository->findOneBy(array('shopwareId' => $articleDetailModel->getId()));

                            if($bfMappingArticleDetailModel !== null)
                            {
                                $apiExportSeoUrlsDetailResult = Shopware()->Db()->fetchAll(
                                    "select * from bf_api_export_seo_urls where brickfoxID = ? and shopwareDetailsID = ?",
                                    array($bfMappingArticleDetailModel->getBrickfoxId(), $articleDetailModel->getId())
                                );

                                if(count($apiExportSeoUrlsDetailResult) > 0)
                                {
                                    foreach($apiExportSeoUrlsDetailResult as $apiExportSeoUrlsDetail)
                                    {
                                        if($apiExportSeoUrlsDetail['seo_path'] !== $sCoreRewriteUrlsResult['path'] . '?number=' . $articleDetailModel->getNumber())
                                        {
                                            $itemsToExport[] = $fullExportList['shopwareID'];
                                            break 2;
                                        }
                                    }
                                }
                                else
                                {
                                    $itemsToExport[] = $fullExportList['shopwareID'];
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        return $itemsToExport;
    }

    /**
     * @return int
     */
    public function getExportItemsCount()
    {
        return $this->exportItemsCount;
    }

    /**
     * @param int $exportItemsCount
     */
    public function setExportItemsCount($exportItemsCount)
    {
        $this->exportItemsCount += $exportItemsCount;
    }

    /**
     * @return array
     */
    public function getExportList()
    {
        return $this->exportList;
    }

    /**
     * @param array $exportList
     */
    public function setExportList($exportList)
    {
        $this->exportList = $exportList;
    }

    /**
     * @param mixed $item
     * @param XMLWriter $XMLWriter
     * @param null $shopsId
     *
     * @return mixed
     */
    abstract protected function processExport($item, XMLWriter $XMLWriter, $shopsId = null);
}