<?php
/**
 * Shopware_Plugins_Backend_BfSaleschannel_Bootstrap
 * This file is part of brickfox.
 *
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2020 brickfox GmbH http://www.brickfox.de
 */

use Bf\Saleschannel\Components\ExportController;
use Bf\Saleschannel\Components\ImportController;
use Bf\Saleschannel\Components\Util\ConfigManager as BfConfigManager;
use Bf\Saleschannel\Components\Util\ModelEvents as BfModelEvents;
use Bf\Saleschannel\Install\CreateDatabase;
use Bf\Saleschannel\Install\CreateDirectories;
use Bf\Saleschannel\Install\RegisterEvents;
use Bf\Saleschannel\Install\RegisterMenu;
use Bf\Saleschannel\Install\RemoveDatabase;
use Bf\Saleschannel\Patches;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddApiExportSeoUrls;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddApiImportPriceHash;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddBfApiImportDataDetailIndexes;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddCarrierAttributeFieldNameConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddCategoryDenormalizationConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddCommentConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddConfigurationForBfLogStoringDuration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddConfiguratorMappingModels;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddCostChangingAsCouponConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddCreateDateConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddDefaultCustomerGroupConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddDisableBfPriceUpdates;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddExcludeCustomerGroupAttributeFieldCodeConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddExportTaxesForNetOrdersAttributes;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddIgnoreCategoriesImportMultiShopConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddIgnoreDeliveryConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddIgnoreImmageConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddIgnoreLongDescriptionConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddIgnoreOrdersByShopsIds;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddImageDescriptionAttributeName;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddImageMappingConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddImportImagesWithoutExtensionConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddIndexForArticleMappings;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddIndexForBfApiAndScriptlogger;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddInitialImagePath;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddIsMasterShopColumnForShopsMapping;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddKeepMissingImagesInImportConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddKeepOnImportAttributes;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddMappingImageAttributes;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddMappingOrderAttributes;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddMappingOrderLinesAttributes;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddMappingPaymentMethodToPaymentStatus;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddNewConfigurationCleanApiAfterDays;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddNewUiSubscribes;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddOrderExportByPaymentStatus;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddPackageOrMeasurementDropDownConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddReAssignVariationsConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddReleaseDateFromAttributeConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddRrpToSpecialPriceModel;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddSendPendingMailConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddShippingFreeFromAttributeConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddShippingMappingStatus;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddShopsIdToMappingCategoriesTable;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddSortOrderAttributesConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddSpecialPricesTable;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddStrikeThroughPriceRules;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddSubShopIdSeoExport;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddSurchargeCodesConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddUrlImageAsImageDescriptionConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchApiImportDataModel;
use Bf\Saleschannel\Patches\SCRIPT\PatchAutomaticOderStatusEmailSending;
use Bf\Saleschannel\Patches\SCRIPT\PatchBfScriptLoggerIndex;
use Bf\Saleschannel\Patches\SCRIPT\PatchChangedOrderAttributesTableName;
use Bf\Saleschannel\Patches\SCRIPT\PatchChangeFilterRelationsColumn;
use Bf\Saleschannel\Patches\SCRIPT\PatchExtendsFilterRelationMappingTable;
use Bf\Saleschannel\Patches\SCRIPT\PatchFiltersMapping;
use Bf\Saleschannel\Patches\SCRIPT\PatchFiltersMappingRelations;
use Bf\Saleschannel\Patches\SCRIPT\PatchNewMenuEntries;
use Bf\Saleschannel\Patches\SCRIPT\PatchOrderExportFailureStatus;
use Bf\Saleschannel\Patches\SCRIPT\PatchPreventPriceModelsRewrite;
use Bf\Saleschannel\Patches\SCRIPT\PatchRemoveConfigurationReAssignArticles;
use Bf\Saleschannel\Patches\SCRIPT\PatchRemoveConfiguratorUniqueKeys;
use Bf\Saleschannel\Patches\SCRIPT\PatchRemoveUniqueShopsMappingBrickfoxId;
use Bf\Saleschannel\Patches\SCRIPT\PatchRenameMappingTable;
use Bf\Saleschannel\Patches\SCRIPT\PatchScriptLoggerConfigurationEntry;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddEmailNotificationOnError;
use Bf\Saleschannel\Patches\SCRIPT\PatchAddEmailNotificationConfiguration;
use Bf\Saleschannel\Patches\SCRIPT\PatchUpdateConstraintsBfMappingOrderExportByPaymentStatus;

/**
 * Class Shopware_Plugins_Backend_BrickSaleschannel_Bootstrap
 */
class Shopware_Plugins_Backend_BrickSaleschannel_Bootstrap extends Shopware_Components_Plugin_Bootstrap
{
    /**
     * @param array $plugins
     * @return bool
     */
    public function assertRequiredPluginsPresent($plugins)
    {
        return parent::assertRequiredPluginsPresent($plugins);
    }

    /**
     * @return array|bool[]
     */
    public function getCapabilities()
    {
        return [
            'install' => true,
            'update'  => true,
            'enable'  => true
        ];
    }

    /**
     * @return array
     */
    public function getInfo()
    {
        $banner = base64_encode(file_get_contents(dirname(__FILE__) . '/banner.png'));

        return [
            'version'     => $this->getVersion(),
            'label'       => $this->getLabel(),
            'supplier'    => 'brickfox GmbH',
            'author'      => 'brickfox GmbH',
            'description' => '<img src="data:image/png;base64,' . $banner . '" />',
            'copyright'   => 'Copyright © 2015, brickfox GmbH',
            'support'     => 'support@brickfox.de',
            'link'        => 'http://www.brickfox.de'
        ];
    }

    /**
     * @return string
     */
    public function getVersion()
    {
        return '6.0.85';
    }

    /**
     * @return string
     */
    public function getLabel()
    {
        return 'Brickfox';
    }

    /**
     * @return array|bool
     */
    public function install()
    {
        if (version_compare(PHP_VERSION, '5.4.0') < 0) {
            return ['success' => false, 'message' => 'Ihr System erfüllt nicht die mindest PHP-Version von 5.4.0 bitte wenden Sie sich an Ihren Hoster.'];
        }

        $this->createDatabase();
        $this->registerEvents();
        $this->registerMenuItem();
        $this->registerCronJobs();
        $this->createDirectories();

        return ['success' => true, 'invalidateCache' => ['backend', 'config']];
    }

    /**
     */
    private function createDatabase()
    {
        $this->registerCustomModels();

        (new CreateDatabase($this))->executeCreateDatabase();
    }

    /**
     */
    private function registerEvents()
    {
        (new RegisterEvents($this))->executeRegisterEvents();
    }

    /**
     */
    private function registerMenuItem()
    {
        (new RegisterMenu($this))->executeRegisterMenu();
    }

    /**
     */
    private function registerCronJobs()
    {
        $this->createCronJob(
            'BfSaleschannelCleareLog',
            'BfSaleschannelCleareLog',
            86400,
            1
        );
    }

    /**
     */
    public function createDirectories()
    {
        (new CreateDirectories($this))->executeCreateDirectories();
    }

    /**
     * @return array|bool
     */
    public function uninstall()
    {
        $this->removeDatabase();

        return ['success' => true, 'invalidateCache' => ['backend', 'config']];
    }

    /**
     */
    private function removeDatabase()
    {
        (new RemoveDatabase($this))->executeRemoveDatabase();
    }

    /**
     * @param string $version
     * @return array|bool
     * @throws Zend_Db_Adapter_Exception
     */
    public function update($version)
    {
        switch ($version) {
            case '1.0.3':
                (new PatchFiltersMapping($this))->preparePatch();
            case '1.0.4':
            case '1.0.5':
            case '1.1.0':
                (new PatchFiltersMappingRelations($this))->preparePatch();
            case '2.0.0':
            case '2.0.1':
            case '2.0.2':
                (new PatchOrderExportFailureStatus($this))->preparePatch();
            case '2.4.3':
                (new PatchRenameMappingTable($this))->preparePatch();
            case '2.5.0':
            case '2.5.1':
            case '2.5.2':
            case '2.5.3':
            case '2.5.4':
            case '2.5.5':
            case '2.5.6':
            case '2.5.7':
            case '2.5.8':
            case '2.5.9':
            case '2.6.0':
            case '2.6.1':
            case '2.6.2':
            case '2.6.3':
            case '2.6.4':
                (new PatchScriptLoggerConfigurationEntry($this))->preparePatch();
            case '2.6.5':
            case '2.6.6':
            case '2.6.7':
            case '2.6.8':
            case '2.6.9':
            case '2.7.0':
            case '2.7.1':
            case '2.7.2':
            case '2.7.3':
            case '2.7.4':
            case '2.7.5':
            case '2.7.6':
            case '2.7.7':
            case '2.7.8':
            case '2.7.9':
                (new PatchApiImportDataModel($this))->preparePatch();
            case '2.8.0':
                (new PatchNewMenuEntries($this))->preparePatch();
            case '2.8.1':
                (new PatchAddNewUiSubscribes($this))->preparePatch();
            case '2.8.2':
            case '2.8.3':
            case '2.8.4':
            case '2.8.5':
            case '2.8.6':
            case '2.8.7':
            case '2.8.8':
                (new PatchAutomaticOderStatusEmailSending($this))->preparePatch();
            case '2.8.9':
            case '2.9.0':
            case '2.9.1':
            case '2.9.2':
                (new PatchExtendsFilterRelationMappingTable($this))->preparePatch();
                (new PatchAddShippingMappingStatus($this))->preparePatch();
            case '2.9.3':
            case '2.9.4':
                (new PatchAddDefaultCustomerGroupConfiguration($this))->preparePatch();
            case '2.9.5':
            case '2.9.6':
                (new PatchAddIndexForArticleMappings($this))->preparePatch();
                (new PatchAddInitialImagePath($this))->preparePatch();
                (new PatchAddUrlImageAsImageDescriptionConfiguration($this))->preparePatch();
            case '2.9.7':
            case '2.9.8':
            case '2.9.9':
                (new PatchAddApiImportPriceHash($this))->preparePatch();
            case '3.0.0':
                (new PatchAddImportImagesWithoutExtensionConfiguration($this))->preparePatch();
            case '3.0.1':
            case '3.0.2':
            case '3.0.3':
            case '3.0.4':
            case '3.0.5':
            case '3.0.6':
            case '3.0.7':
            case '3.0.8':
            case '3.0.9':
            case '3.1.0':
            case '3.1.1':
                (new PatchAddBfApiImportDataDetailIndexes($this))->preparePatch();
                (new PatchBfScriptLoggerIndex($this))->preparePatch();
            case '3.1.2':
            case '3.1.3':
            case '3.1.4':
                (new PatchAddNewConfigurationCleanApiAfterDays($this))->preparePatch();
                (new PatchAddMappingOrderAttributes($this))->preparePatch();
            case '3.1.5':
                (new PatchAddIgnoreCategoriesImportMultiShopConfiguration($this))->preparePatch();
            case '3.1.6':
            case '3.1.7':
            case '3.1.8':
            case '3.1.9':
            case '3.2.0':
            case '3.2.1':
            case '3.2.2':
                (new PatchChangedOrderAttributesTableName($this))->preparePatch();
            case '3.2.3':
            case '3.2.4':
                (new PatchAddConfiguratorMappingModels($this))->preparePatch();
            case '3.2.5':
            case '3.2.6':
            case '3.2.7':
            case '3.2.8':
            case '3.2.9':
            case '3.3.0':
            case '3.3.1':
            case '3.3.2':
            case '3.3.3':
            case '3.3.4':
            case '3.3.5':
            case '3.3.6':
            case '3.3.7':
            case '3.3.8':
                (new PatchRemoveConfiguratorUniqueKeys($this))->preparePatch();
            case '3.3.9':
            case '3.4.0':
            case '3.4.1':
            case '3.4.2':
                (new PatchAddCategoryDenormalizationConfiguration($this))->preparePatch();
            case '3.4.3':
                (new PatchAddApiExportSeoUrls($this))->preparePatch();
            case '3.4.4':
            case '3.4.5':
            case '3.4.6':
            case '3.4.7':
                (new PatchAddSpecialPricesTable($this))->preparePatch();
            case '3.4.8':
            case '3.4.9':
            case '3.5.0':
            case '3.5.1':
            case '3.5.2':
                (new PatchAddIgnoreImmageConfiguration($this))->preparePatch();
            case '3.5.3':
            case '3.5.4':
                (new PatchAddShopsIdToMappingCategoriesTable($this))->preparePatch();
            case '3.5.5':
            case '3.5.6':
            case '3.5.7':
            case '3.5.8':
            case '3.5.9':
            case '3.6.0':
            case '3.6.1':
            case '3.6.2':
            case '3.6.3':
                (new PatchAddReAssignVariationsConfiguration($this))->preparePatch();
            case '3.6.4':
            case '3.6.5':
            case '3.6.6':
                (new PatchAddReleaseDateFromAttributeConfiguration($this))->preparePatch();
            case '3.6.7':
                (new PatchAddMappingPaymentMethodToPaymentStatus($this))->preparePatch();
            case '3.6.8':
            case '3.6.9':
            case '3.7.0':
            case '3.7.1':
                (new PatchAddSendPendingMailConfiguration($this))->preparePatch();
            case '3.7.2':
            case '3.7.3':
                (new PatchAddCostChangingAsCouponConfiguration($this))->preparePatch();
            case '3.7.4':
                (new PatchAddSortOrderAttributesConfiguration($this))->preparePatch();
            case '3.7.5':
            case '3.7.6':
                (new PatchRemoveUniqueShopsMappingBrickfoxId($this))->preparePatch();
                (new PatchAddImageMappingConfiguration($this))->preparePatch();
            case '3.7.7':
                (new PatchAddMappingOrderLinesAttributes($this))->preparePatch();
            case '3.7.8':
            case '3.7.9':
            case '3.8.0':
            case '3.8.1':
                (new PatchAddIsMasterShopColumnForShopsMapping($this))->preparePatch();
            case '3.8.2':
            case '3.8.3':
            case '3.8.4':
            case '3.8.5':
            case '3.8.6':
            case '3.8.7':
                (new PatchAddOrderExportByPaymentStatus($this))->preparePatch();
            case '3.8.8':
            case '3.8.9':
            case '3.9.0':
            case '3.9.1':
            case '3.9.2':
                (new PatchAddSubShopIdSeoExport($this))->preparePatch();
            case '3.9.3':
            case '3.9.4':
            case '3.9.5':
            case '3.9.6':
                (new PatchAddPackageOrMeasurementDropDownConfiguration($this))->preparePatch();
            case '3.9.7':
            case '3.9.8':
            case '3.9.9':
                (new PatchAddCommentConfiguration($this))->preparePatch();
            case '4.0.0':
                (new PatchAddStrikeThroughPriceRules($this))->preparePatch();
            case '4.0.1':
            case '4.0.2':
            case '4.0.3':
                (new PatchAddIgnoreDeliveryConfiguration($this))->preparePatch();
            case '4.0.4':
                (new PatchChangeFilterRelationsColumn($this))->preparePatch();
            case '4.0.5':
            case '4.0.6':
            case '4.0.7':
            case '4.0.8':
                (new PatchAddRrpToSpecialPriceModel($this))->preparePatch();
            case '4.0.9':
            case '4.0.10':
            case '4.0.11':
            case '4.0.12':
            case '4.0.13':
                (new PatchAddCreateDateConfiguration($this))->preparePatch();
            case '4.0.14':
            case '4.0.15':
            case '4.0.16':
            case '4.0.17':
                (new PatchRemoveConfigurationReAssignArticles($this))->preparePatch();
            case '4.0.18':
            case '4.0.19':
            case '4.0.21':
            case '4.0.22':
            case '4.0.23':
            case '4.0.24':
                (new PatchAddKeepOnImportAttributes($this))->preparePatch();
            case '4.0.25':
            case '4.0.26':
            case '4.0.27':
            case '4.0.29':
            case '4.0.30':
                (new PatchAddMappingImageAttributes($this))->preparePatch();
            case '4.0.31':
            case '4.0.32':
            case '4.0.33':
                (new PatchAddShippingFreeFromAttributeConfiguration($this))->preparePatch();
            case '4.0.34':
                (new PatchAddExportTaxesForNetOrdersAttributes($this))->preparePatch();
            case '4.0.35':
            case '4.0.36':
            case '4.0.37':
                (new PatchAddIndexForBfApiAndScriptlogger($this))->preparePatch();
            case '4.0.38':
            case '4.0.39':
            case '4.0.40':
            case '4.0.41':
                (new PatchAddConfigurationForBfLogStoringDuration($this))->preparePatch();
            case '4.0.42':
            case '4.0.43':
            case '6.0.0':
            case '6.0.1':
                (new PatchAddDisableBfPriceUpdates($this))->preparePatch();
            case '6.0.2':
            case '6.0.3':
            case '6.0.4':
            case '6.0.5':
            case '6.0.6':
            case '6.0.7':
            case '6.0.8':
            case '6.0.9':
            case '6.0.10':
            case '6.0.11':
            case '6.0.12':
            case '6.0.13':
            case '6.0.14':
                (new PatchAddIgnoreOrdersByShopsIds($this))->preparePatch();
            case '6.0.15':
                (new PatchAddImageDescriptionAttributeName($this))->preparePatch();
            case '6.0.16':
            case '6.0.17':
            case '6.0.18':
            case '6.0.19':
            case '6.0.20':
            case '6.0.21':
            case '6.0.22':
            case '6.0.23':
            case '6.0.24':
            case '6.0.25':
            case '6.0.26':
            case '6.0.27':
            case '6.0.28':
            case '6.0.30':
            case '6.0.31':
                (new PatchAddCarrierAttributeFieldNameConfiguration($this))->preparePatch();
            case '6.0.32':
            case '6.0.33':
            case '6.0.34':
            case '6.0.35':
            case '6.0.36':
            case '6.0.37':
            case '6.0.38':
            case '6.0.39':
            case '6.0.40':
                (new PatchAddExcludeCustomerGroupAttributeFieldCodeConfiguration($this))->preparePatch();
            case '6.0.41':
            case '6.0.42':
                (new PatchAddEmailNotificationOnError($this))->preparePatch();
            case '6.0.43':
            case '6.0.44':
            case '6.0.45':
                (new PatchAddKeepMissingImagesInImportConfiguration($this))->preparePatch();
            case '6.0.46':
                (new PatchAddIgnoreLongDescriptionConfiguration($this))->preparePatch();
            case '6.0.47':
                (new PatchAddSurchargeCodesConfiguration($this))->preparePatch();
            case '6.0.48':
            case '6.0.49':
            case '6.0.50':
            case '6.0.51':
            case '6.0.52':
            case '6.0.53':
            case '6.0.54':
                (new PatchAddEmailNotificationConfiguration($this))->preparePatch();
            case '6.0.55':
            case '6.0.56':
            case '6.0.57':
            case '6.0.58':
            case '6.0.59':
            case '6.0.60':
            case '6.0.61':
            case '6.0.62':
            case '6.0.63':
            case '6.0.64':
            case '6.0.65':
            case '6.0.67':
            case '6.0.68':
            case '6.0.69':
                (new PatchPreventPriceModelsRewrite($this))->preparePatch();
            case '6.0.70':
            case '6.0.71':
            case '6.0.72':
            case '6.0.73':
            case '6.0.74':
            case '6.0.75':
            case '6.0.76':
            case '6.0.77':
            case '6.0.78':
            case '6.0.79':
            case '6.0.80':
            (new PatchUpdateConstraintsBfMappingOrderExportByPaymentStatus($this))->preparePatch();
            case '6.0.81':
            case '6.0.82':
            case '6.0.83':
            case '6.0.84':
            default:
                break;
        }

        $this->clearProxyCache();

        return true;
    }

    /**
     */
    private function clearProxyCache()
    {
        $cacheManager = $this->get('shopware.cache_manager');
        $cacheManager->clearProxyCache();
    }

    /**
     * @return string
     */
    public function onGetControllerPath()
    {
        try {
            if ($this->assertMinimumVersion('5')) {
                BfConfigManager::getInstance()->setShopwareVersion(5);
            } else {
                BfConfigManager::getInstance()->setShopwareVersion(4);
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }

        return $this->Path() . 'Controllers/Backend/Brickfox.php';
    }

    /**
     * @param Enlight_Event_EventArgs $args
     */
    public function onPostDispatchBackendIndex(Enlight_Event_EventArgs $args)
    {
        $request = $args->getSubject()->Request();
        $path    = str_replace('Bootstrap.php', 'style.css', __FILE__);
        $path    = preg_replace('!^(?:.*?)(/engine/Shopware.*?)$!', '$1', $path);
        $path    = str_replace('/shopware.php', '', $_SERVER['PHP_SELF']) . $path;
        $path    .= '?' . urlencode($this->getVersion());

        if ($request->getActionName() == 'index') {
            $view = $args->getSubject()->View();
            $view->extendsBlock(
                'backend/base/header/css',
                '<link href="' . $path . '" type="text/css" rel="stylesheet">',
                'append'
            );
        }
    }

    /**
     * @param Enlight_Event_EventArgs $args
     * @return string
     */
    public function onGetUiControllerPath(Enlight_Event_EventArgs $args)
    {
        /** register template dir */
        $this->Application()->Template()->addTemplateDir(
            $this->Path() . 'Views/'
        );

        $this->registerCustomModels();

        return $this->Path() . '/Controllers/Backend/BrickfoxUi.php';
    }

    /**
     * @param Enlight_Event_EventArgs $args
     * @return string
     */
    public function onGetUiControllerLogPath(Enlight_Event_EventArgs $args)
    {
        /* register template dir */
        $this->Application()->Template()->addTemplateDir(
            $this->Path() . 'Views/'
        );

        $this->registerCustomModels();

        return $this->Path() . '/Controllers/Backend/BrickfoxUiLog.php';
    }

    /**
     * @param Enlight_Event_EventArgs $args
     * @return string
     */
    public function onGetUiControllerErrorCodeList(Enlight_Event_EventArgs $args)
    {
        /* register template dir */
        $this->Application()->Template()->addTemplateDir(
            $this->Path() . 'Views/'
        );

        $this->registerCustomModels();

        return $this->Path() . '/Controllers/Backend/BrickfoxUiErrorCodeList.php';
    }

    /**
     * @param Enlight_Event_EventArgs $arguments
     */
    public function preRemoveArticle(Enlight_Event_EventArgs $arguments)
    {
        //no implementation possible, fetch doesnt brings the correct results
        //so we cant delete mapping table.
    }

    /**
     * @param Enlight_Event_EventArgs $arguments
     * @throws Exception
     */
    public function prePersistLog(Enlight_Event_EventArgs $arguments)
    {
        $model = $arguments->get('entity');
        (new BfModelEvents($model))->prePersistLogEvent();
    }

    /**
     * @param Enlight_Event_EventArgs $args
     */
    public function onRunSaleschannelImportCron(Enlight_Event_EventArgs $args)
    {
        $importController = new ImportController();
        $importController->importAll();
    }

    /**
     * @param Enlight_Event_EventArgs $args
     */
    public function onRunSaleschannelExportCron(Enlight_Event_EventArgs $args)
    {
        $exportController = new ExportController();
        $exportController->exportOrders();
    }

    /**
     */
    public function afterInit()
    {
        ini_set('memory_limit', '4096M');
        set_time_limit(60 * 60 * 4);

        $this->registerCustomModels();
        $this->Application()->Loader()->registerNamespace(
            'Bf\Saleschannel',
            $this->Path()
        );
    }
}
