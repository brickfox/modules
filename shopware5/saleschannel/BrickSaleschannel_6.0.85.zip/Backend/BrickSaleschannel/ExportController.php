<?php
namespace Bf\Saleschannel\Components;

use Bf\Saleschannel\Components\Export\Orders;
use Bf\Saleschannel\Components\Export\ProductsReports;
use Bf\Saleschannel\Components\Util\ScriptLogger;

/**
 * ExportController
 *
 * @package Bf\Saleschannel\Components
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */
class ExportController
{
    const EXPORT_TYPE_PRODUCTS_REPORTS_SEO = 'SeoUrls';

    /**
     * @return void
     */
    public function exportOrders()
    {
        ScriptLogger::getInstance()->run('export/Orders');
        $exporter = new Orders();

        $exporter->export(__FUNCTION__);
    }

    public function exportSeoUrls()
    {
        ScriptLogger::getInstance()->run('export/seoUrls');
        $exporter = new ProductsReports();

        $exporter->export(self::EXPORT_TYPE_PRODUCTS_REPORTS_SEO, __FUNCTION__);
    }
}
