<?php
namespace Bf\Saleschannel\Components\Interfaces;

/**
 * Interface PaymentMethodsInterface
 *
 * @package Bf\Saleschannel\Components\Interfaces
 */
interface PaymentMethodsInterface
{
    /**
     * Initialize all required parameters.
     *
     * @param integer $orderId <p>
     * The orderId from table s_orders (id).
     * </p>
     */
    public function __construct($orderId = null);

    /**
     * Set the orderId of the given order.
     *
     * @param integer $orderId
     *
     * @return mixed
     */
    public function setOrdersId($orderId);

    /**
     * Returns id from the given order
     *
     * @return null|integer
     */
    public function getOrdersId();

    /**
     * Destroy all given required parameters
     */
    public function __destruct();
}