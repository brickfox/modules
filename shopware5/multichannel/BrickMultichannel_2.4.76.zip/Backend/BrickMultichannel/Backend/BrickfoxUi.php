<?php

use Bf\Multichannel\Components\Gui\GuiOverview;
use Bf\Multichannel\Components\Gui\Mapping;
use Bf\Multichannel\Components\Gui\MappingAddressToFreetext;
use Bf\Multichannel\Components\Gui\MappingCurrencies;
use Bf\Multichannel\Components\Gui\MappingMultiShopExport;
use Bf\Multichannel\Components\Gui\MappingOrderStatus;
use Bf\Multichannel\Components\Gui\MappingOrderStatusDetail;
use Bf\Multichannel\Components\Gui\MappingOrdersToCustomerGroups;
use Bf\Multichannel\Components\Gui\MappingOrdersToShops;
use Bf\Multichannel\Components\Gui\MappingPayment;
use Bf\Multichannel\Components\Gui\MappingShippingAddressToFreetext;
use Bf\Multichannel\Components\Gui\MappingShopwareCurrencies;
use Bf\Multichannel\Components\Gui\MappingTaxClasses;
use Bf\Multichannel\Components\Gui\MappingTranslation;
use Bf\Multichannel\Components\Gui\PluginConfigurations;
use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\Ftp;
use Doctrine\ORM\AbstractQuery;
use Doctrine\ORM\Tools\Pagination\Paginator;
use Shopware\CustomModels\BfMultichannel\ApiExportLog;
use Shopware\CustomModels\BfMultichannel\ApiGuiLog;
use Shopware\CustomModels\BfMultichannel\ApiImportOrders;
use Shopware\CustomModels\BfMultichannel\Configuration;
use Shopware\CustomModels\BfMultichannel\ModelSchemaClass;

/**
 * BrickfoxUi
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */
class Shopware_Controllers_Backend_BrickfoxUi extends Shopware_Controllers_Backend_ExtJs
{
    const REST_CALL_CONFIGURATION           = 'bfconfiguration/';
    const REST_CALL_LANGUAGES_FALLBACK      = 'languages/';
    const REST_CALL_CURRENCIES_FALLBACK     = 'currencies/';
    const REST_CALL_PARAM_CONFIGURATION_KEY = 'configurationKey';

    public function indexAction()
    {
    }

    public function getConfigurationSchemaAction()
    {
        $returnValue = array(
            'success' => true,
            'fields'  => ModelSchemaClass::getInstance()->getConfigurationSchemaModel()
        );

        $this->View()->assign($returnValue);
    }

    public function removeProductExportsAction()
    {
        $touchedRaws = Shopware()->Db()->query('DELETE FROM bf_api_export_products')->rowCount();

        if ($touchedRaws) {
            $message = $touchedRaws . ' Einträge gelöscht.';
        } else {
            $message = 'Die Exporttabelle ist schon leer.';
        }

        $this->View()->assign(array(
            'success' => (bool)$touchedRaws,
            'data'    => $message
        ));
    }

    public function getSettingsListAction()
    {
        $overviewClass = new GuiOverview();

        $pluginConfiguration = $overviewClass->convertPluginConfigurationForOverviewDisplayFields();
        $config              = $pluginConfiguration;

        $config['phpVersion']            = $overviewClass->getPhpVersion();
        $config['phpMemoryLimit']        = $overviewClass->getMemoryLimit();
        $config['phpMaxExecutionTime']   = $overviewClass->getMaxExecutionTime();
        $config['lastProductsExport']    = $overviewClass->getLastImportExportTimeFromScriptLoggerByScriptName('export/Products');
        $config['lastCategoriesExport']  = $overviewClass->getLastImportExportTimeFromScriptLoggerByScriptName('export/Categories');
        $config['lastSuppliersExport']   = $overviewClass->getLastImportExportTimeFromScriptLoggerByScriptName('export/Manufacturers');
        $config['lastOrderStatusExport'] = $overviewClass->getLastImportExportTimeFromScriptLoggerByScriptName('export/OrdersStatus');
        $config['lastOrderImport']       = $overviewClass->getLastImportExportTimeFromScriptLoggerByScriptName('import/Orders');

        $this->View()->assign(array(
            'success' => true,
            'data'    => $config
        ));
    }

    public function getMainConfigurationAction()
    {
        $pluginConfigurationClass = new PluginConfigurations();
        $result                   = $pluginConfigurationClass->load();

        $this->View()->assign(array(
                'data' => $result
            ));
    }

    public function checkIsMultiShopAction()
    {
        $pluginConfigurationClass = new PluginConfigurations();
        $isMultiShop              = $pluginConfigurationClass->getIsMultiShop();
        $multiShops               = $pluginConfigurationClass->getMultiShops();

        $this->View()->assign(array(
                'isMultiShop' => $isMultiShop,
                'multiShops'  => $multiShops
            ));
    }

    public function getYesOrNoComboListValuesAction()
    {
        $pluginConfigurationClass = new PluginConfigurations();

        $answers = $pluginConfigurationClass->getYesOrNoDropDownContent();

        $this->View()->assign(array(
                'success' => true,
                'data'    => $answers
            ));
    }

    public function getPseudoPriceDropDownAction()
    {
        $pluginConfigurationClass = new PluginConfigurations();

        $result = $pluginConfigurationClass->getPseudoPriceDropDownContent();

        $this->View()->assign(array(
                'success' => true,
                'data'    => $result
            ));
    }

    public function saveMainConfigurationAction()
    {
        $formData = $this->Request()->getParam('formData', null);
        $pluginConfigurationClass = new PluginConfigurations();
        $result                   = $pluginConfigurationClass->save(json_decode($formData));

        $this->View()->assign(array(
                'success' => $result
            ));
    }

    public function checkFtpConnectionAction()
    {
        $host = '';
        $user = '';
        $pass = '';
        $port = 0;

        if (ConfigManager::getInstance()->getFtpHost() !== null) {
            /** @var Configuration $host */
            $host = ConfigManager::getInstance()->getFtpHost();
        }

        if (ConfigManager::getInstance()->getFtpUser() !== null) {
            /** @var Configuration $user */
            $user = ConfigManager::getInstance()->getFtpUser();
        }

        if (ConfigManager::getInstance()->getFtpPass() !== null) {
            /** @var Configuration $pass */
            $pass = ConfigManager::getInstance()->getFtpPass();
        }

        if (ConfigManager::getInstance()->getFtpSslPort() !== null) {
            /** @var Configuration $port */
            $port = ConfigManager::getInstance()->getFtpSslPort();
        }

        $ftpClass   = new Ftp($user->getConfigurationValue(), $pass->getConfigurationValue(), $host->getConfigurationValue(), (int)$port->getConfigurationValue());
        $connection = $ftpClass->ftpTestConnection();

        $this->View()->assign(array(
                'success' => $connection
            ));
    }

    public function getTranslationMappingListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingTranslation');

        $this->View()->assign(array(
                'data'  => $result['data'],
                'count' => $result['count']
            ));
    }

    public function saveTranslationMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->save(array(
                'params'           => $params,
                'mappingKeyFields' => array(
                    'brickfoxIsoCode' => '',
                    'mappingFieldKey' => '',
                    'id'              => ''
                ),
                'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingTranslation',
                'uniqueKey'        => 'id'
            ));

        $this->View()->assign(array(
                'success' => $result
            ));
    }

    public function deleteTranslationMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->delete(array(
                'params'           => $params,
                'mappingKeyFields' => array(
                    'brickfoxIsoCode' => '',
                    'mappingFieldKey' => '',
                    'id'              => ''
                ),
                'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingTranslation',
                'uniqueKey'        => 'id'
            ));

        $this->View()->assign(array(
                'success' => $result
            ));
    }

    public function getOrdersToCustomerGroupsMappingListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingOrdersToCustomerGroups');

        $this->View()->assign(array(
            'data'  => $result['data'],
            'count' => $result['count']
        ));
    }

    public function saveOrdersToCustomerGroupsMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->save(array(
            'params'           => $params,
            'mappingKeyFields' => array(
                'brickfoxShopsId' => '',
                'shopwareCustomerGroupId' => '',
                'id'              => ''
            ),
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingOrdersToCustomerGroups',
            'uniqueKey'        => 'id'
        ));

        $this->View()->assign(array(
            'success' => $result
        ));
    }

    public function deleteOrdersToCustomerGroupsMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->delete(array(
            'params'           => $params,
            'mappingKeyFields' => array(
                'brickfoxShopsId' => '',
                'shopwareCustomerGroupId' => '',
                'id'              => ''
            ),
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingOrdersToCustomerGroups',
            'uniqueKey'        => 'id'
        ));

        $this->View()->assign(array(
            'success' => $result
        ));
    }

    public function getOrdersToShopsMappingListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingOrdersToShops');

        $this->View()->assign(array(
            'data'  => $result['data'],
            'count' => $result['count']
        ));
    }

    public function saveOrdersToShopsMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->save(array(
            'params'           => $params,
            'mappingKeyFields' => array(
                'brickfoxShopsId' => '',
                'shopwareShopsId' => '',
                'id'              => ''
            ),
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingOrdersToShops',
            'uniqueKey'        => 'id'
        ));

        $this->View()->assign(array(
            'success' => $result
        ));
    }

    public function deleteOrdersToShopsMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->delete(array(
            'params'           => $params,
            'mappingKeyFields' => array(
                'brickfoxShopsId' => '',
                'shopwareShopsId' => '',
                'id'              => ''
            ),
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingOrdersToShops',
            'uniqueKey'        => 'id'
        ));

        $this->View()->assign(array(
            'success' => $result
        ));
    }

    public function getTaxRatesMappingDropDownAction()
    {
        $taxRatesMappingClass = new MappingTaxClasses();

        $this->View()->assign([
            'data' => $taxRatesMappingClass->getShopwareTaxRatesMappingFieldKeys()
        ]);
    }

    public function getTaxRatesMappingBrickfoxDropDownAction()
    {
        $taxRatesMappingClass = new MappingTaxClasses();

        $this->View()->assign([
            'data' => $taxRatesMappingClass->getBrickfoxTaxCategoriesMappingFieldKeys()
        ]);
    }

    public function getTaxRatesMappingListAction()
    {

        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingTaxRates');

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);
    }

    public function saveTaxRatesMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->save([
            'params'           => $params,
            'mappingKeyFields' => [
                'id'                    => '',
                'mappingFieldKey'       => '',
                'brickfoxTaxClass' => ''
            ],
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingTaxRates',
            'uniqueKey'        => 'id'
        ]);

        $this->View()->assign([
            'success' => $result
        ]);
    }

    public function deleteTaxRatesMapping()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->delete([
            'params'           => $params,
            'mappingKeyFields' => [
                'id'                    => '',
                'mappingFieldKey'       => '',
                'brickfoxTaxClass' => ''
            ],
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingTaxRates',
            'uniqueKey'        => 'id'
        ]);

        $this->View()->assign([
            'success' => $result
        ]);
    }

    public function getTranslationMappingDropDownAction()
    {
        $translationMappingClass = new MappingTranslation();
        $this->View()->assign(array(
                'data' => $translationMappingClass->getTranslationMappingFieldKeys()
            ));
    }

    public function getLanguageMappingBrickfoxDropDownAction()
    {
        $mapping = new Mapping();

        $data = $mapping->getBrickfoxConfigurationMappingFieldKeys(self::REST_CALL_CONFIGURATION, array(self::REST_CALL_PARAM_CONFIGURATION_KEY => 'languagesList'));

        if (count($data) === 0) {
            $data = $mapping->getBrickfoxConfigurationMappingFieldKeys(self::REST_CALL_LANGUAGES_FALLBACK, array(self::REST_CALL_PARAM_CONFIGURATION_KEY => 'defaultLanguageId'),
                'languages');
        }

        $this->View()->assign(array(
                'data' => $data
            ));
    }

    public function getOrdersToShopsMappingDropDownAction()
    {
        $ordersToShopsMappingClass = new MappingOrdersToShops();
        $this->View()->assign(array(
            'data' => $ordersToShopsMappingClass->getOrdersToShopsMapping()
        ));
    }

    public function getOrdersToCustomerGroupsMappingDropDownAction()
    {
        $ordersToShopsMappingClass = new MappingOrdersToCustomerGroups();
        $this->View()->assign(array(
            'data' => $ordersToShopsMappingClass->getOrdersToCustomerGroupsMapping()
        ));
    }

    public function getOrdersToCustomerGroupsMappingBrickfoxDropDownAction()
    {
        $mapping = new Mapping();
        $data = $mapping->doRestCall('shops/');

        $this->View()->assign(array('data' => $data));
    }

    public function getOrdersToShopsMappingBrickfoxDropDownAction()
    {
        $mapping = new Mapping();
        $data = $mapping->doRestCall('shops/');

        $this->View()->assign(array('data' => $data));
    }

    public function getCurrenciesMappingListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingCurrencies');

        $this->View()->assign(array(
                'data'  => $result['data'],
                'count' => $result['count']
            ));
    }

    public function saveCurrenciesMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->save(array(
                'params'           => $params,
                'mappingKeyFields' => array(
                    'brickfoxCurrenciesCode' => '',
                    'mappingFieldKey'        => '',
                    'isNetFieldKey'          => '',
                    'id'                     => ''
                ),
                'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingCurrencies',
                'uniqueKey'        => 'id'
            ));

        $this->View()->assign(array(
                'success' => $result
            ));
    }

    public function deleteCurrenciesMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->delete(array(
                'params'           => $params,
                'mappingKeyFields' => array(
                    'brickfoxCurrenciesCode' => '',
                    'mappingFieldKey'        => '',
                    'id'                     => ''
                ),
                'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingCurrencies',
                'uniqueKey'        => 'id'
            ));

        $this->View()->assign(array(
                'success' => $result
            ));
    }

    public function getCurrenciesMappingDropDownAction()
    {
        $this->View()->assign(array(
                'data' => (new MappingCurrencies())->getCurrenciesMappingFieldKeys()
            ));
    }

    public function getIsNetMappingDropDownAction()
    {
        $this->View()->assign(array(
            'data' => (new MappingCurrencies())->getIsNetMapping()
        ));
    }

    public function getBrickfoxCurrenciesMappingDropDownAction()
    {
        $mapping = new Mapping();
        $data    = $mapping->getBrickfoxConfigurationMappingFieldKeys(self::REST_CALL_CONFIGURATION, array(self::REST_CALL_PARAM_CONFIGURATION_KEY => 'currenciesList'));

        if (count($data) === 0) {
            $data = $mapping->getBrickfoxConfigurationMappingFieldKeys(self::REST_CALL_CURRENCIES_FALLBACK, array(self::REST_CALL_PARAM_CONFIGURATION_KEY => 'defaultCurrencyId'),
                'currencies');
        }

        $this->View()->assign(array(
                'data' => $data
            ));
    }

    public function getAttributesVariationsListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingAttributesVariations');

        $this->View()->assign(array(
                'data'  => $result['data'],
                'count' => $result['count']
            ));
    }

    public function setNewAttributesVariationsMappingAction()
    {
        $params       = $this->Request()->getParams();
        $mappingClass = new Mapping();
        $result       = $mappingClass->save(array(
                'params'           => $params,
                'mappingKeyFields' => array(
                    'attributesVariationsCode' => '',
                    'id'                       => ''
                ),
                'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingAttributesVariations',
                'uniqueKey'        => 'id'
            ));

        $this->View()->assign(array(
                'data' => $result
            ));
    }

    public function deleteAttributesVariationsMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->delete(array(
                'params'           => $params,
                'mappingKeyFields' => array(
                    'brickfoxCurrenciesCode' => '',
                    'mappingFieldKey'        => '',
                    'id'                     => ''
                ),
                'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingAttributesVariations',
                'uniqueKey'        => 'id'
            ));

        $this->View()->assign(array(
                'success' => $result
            ));
    }

    public function getAttributesVariationsMappingDropDownAction()
    {
        $data = array();

        $attributesHeader = Shopware()->Db()->fetchAll("show columns from s_articles_attributes");

        if (count($attributesHeader) > 0) {
            foreach ($attributesHeader as $header) {
                if ($header['Field'] !== 'id' && $header['Field'] !== 'articleID' && $header['Field'] !== 'articledetailsID') {
                    $data[] = array(
                        'shopwareAttributesCode' => $header['Field']
                    );
                }
            }
        }

        $this->View()->assign(array(
                'data'  => $data,
                'count' => count($data)
            ));
    }

    public function getCustomerGroupsListAction()
    {
        $pluginConfigurationClass = new PluginConfigurations();

        $customerGroups = $pluginConfigurationClass->getCustomerGroupsList();

        $this->View()->assign(array(
                'success' => true,
                'data'    => $customerGroups
            ));
    }

    public function getLogOrdersListAction()
    {
        $data = array();

        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        $qb = Shopware()->Models()->createQueryBuilder();

        if ($limit !== 0) {
            $qb->setFirstResult($start)->setMaxResults($limit);
        }

        $qb->select(array('orders'))
            ->from('Shopware\CustomModels\BfMultichannel\ApiImportOrders', 'orders')
            ->where('orders.processed != :status')
            ->orderBy('orders.dateInsert', 'DESC')
            ->setParameter('status', 0);

        $sql = $qb->getQuery()->setHydrationMode(AbstractQuery::HYDRATE_ARRAY);

        $paginator = new Paginator($sql);
        $total     = $paginator->count();
        $list      = $paginator->getIterator()->getArrayCopy();

        if (count($list) > 0) {
            foreach ($list as $values) {
                $data['data'][] = array(
                    'id'                 => $values['id'],
                    'bf_shops_orders_id' => $values['shopsOrdersId'],
                    'bf_shops_name'      => $values['channelName'],
                    'processed'          => $values['processed'],
                    'error'              => $values['error'],
                    'last_update'        => $values['lastUpdate']
                );
            }
        }
        $this->View()->assign(array(
                'count' => $total,
                'data'  => $data['data']
            ));
    }

    public function getLogExportListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        $qb = Shopware()->Models()->createQueryBuilder();

        if ($limit !== 0) {
            $qb->setFirstResult($start)->setMaxResults($limit);
        }

        $qb->select(array('logExport'))->from('Shopware\CustomModels\BfMultichannel\ApiExportLog', 'logExport')->orderBy('logExport.dateInsert', 'DESC');

        $sql = $qb->getQuery()->setHydrationMode(AbstractQuery::HYDRATE_ARRAY);

        $paginator = new Paginator($sql);
        $total     = $paginator->count();
        $list      = $paginator->getIterator()->getArrayCopy();

        $this->View()->assign(array(
                'count' => $total,
                'data'  => $list
            ));
    }

    public function getLogGuiListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        $qb = Shopware()->Models()->createQueryBuilder();

        if ($limit !== 0) {
            $qb->setFirstResult($start)->setMaxResults($limit);
        }

        $qb->select(array('logGui'))->from('Shopware\CustomModels\BfMultichannel\ApiGuiLog', 'logGui')->orderBy('logGui.dateInsert', 'DESC');

        $sql = $qb->getQuery()->setHydrationMode(AbstractQuery::HYDRATE_ARRAY);

        $paginator = new Paginator($sql);
        $total     = $paginator->count();
        $list      = $paginator->getIterator()->getArrayCopy();

        $this->View()->assign(array(
                'count' => $total,
                'data'  => $list
            ));
    }

    public function deleteLogExportAction()
    {
        $deleteId = $this->Request()->getParam('id', null);

        if ($deleteId !== null) {
            $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportLog');
            /** @var ApiExportLog $apiExportLogModel */
            $apiExportLogModel = $repository->find((int)$deleteId);

            if ($apiExportLogModel !== null) {
                Shopware()->Models()->remove($apiExportLogModel);
                Shopware()->Models()->flush();
            }
        }
    }

    public function deleteLogOrderAction()
    {
        $deleteId = $this->Request()->getParam('id', null);

        if ($deleteId !== null) {
            $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiImportOrders');
            /** @var ApiImportOrders $apiExportLogModel */
            $apiImportOrdersModel = $repository->find((int)$deleteId);

            if ($apiImportOrdersModel !== null) {
                Shopware()->Models()->remove($apiImportOrdersModel);
                Shopware()->Models()->flush();
            }
        }
    }

    public function deleteLogGuiAction()
    {
        $deleteId = $this->Request()->getParam('id', null);

        if ($deleteId !== null) {
            $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiGuiLog');
            /** @var ApiGuiLog $apiGuiLogModel */
            $apiGuiLogModel = $repository->find((int)$deleteId);

            if ($apiGuiLogModel !== null) {
                Shopware()->Models()->remove($apiGuiLogModel);
                Shopware()->Models()->flush();
            }
        }
    }

    public function getPaymentMappingListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingPayment');

        $this->View()->assign(array(
                'data'  => $result['data'],
                'count' => $result['count']
            ));
    }

    public function savePaymentMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->save(array(
                'params'           => $params,
                'mappingKeyFields' => array(
                    'brickfoxPaymentCode' => '',
                    'mappingFieldKey'     => '',
                    'id'                  => ''
                ),
                'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingPayment',
                'uniqueKey'        => 'id'
            ));

        $this->View()->assign(array(
                'success' => $result
            ));
    }

    public function deletePaymentMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->delete(array(
                'params'           => $params,
                'mappingKeyFields' => array(
                    'brickfoxPaymentCode' => '',
                    'mappingFieldKey'     => '',
                    'id'                  => ''
                ),
                'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingPayment',
                'uniqueKey'        => 'id'
            ));

        $this->View()->assign(array(
                'success' => $result
            ));
    }

    public function getPaymentStateMappingDropDownAction()
    {
        $this->View()->assign(array(
                'data' => (new MappingPayment())->getPaymentStateMappingFieldKeys()
            ));
    }

    public function getMultiShopExportListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingMultiShopExport');

        $this->View()->assign(array(
                'data'  => $result['data'],
                'count' => $result['count']
            ));
    }

    public function saveMultiShopExportAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->save(array(
                'params'           => $params,
                'mappingKeyFields' => array(
                    'mappingFieldKey' => '',
                    'id'              => ''
                ),
                'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingMultiShopExport',
                'uniqueKey'        => 'id'
            ));

        $this->View()->assign(array(
                'success' => $result
            ));
    }

    public function deleteMultiShopExportAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->delete(array(
                'params'           => $params,
                'mappingKeyFields' => array(
                    'mappingFieldKey' => '',
                    'id'              => ''
                ),
                'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingMultiShopExport',
                'uniqueKey'        => 'id'
            ));

        $this->View()->assign(array(
                'success' => $result
            ));
    }

    public function getMultiShopExportDropDownAction()
    {
        $this->View()->assign(array(
                'data' => (new MappingMultiShopExport())->getMultiShopExportMappingFieldKeys()
            ));
    }

    public function getInvoiceDocumentTypesDropDownAction()
    {
        $documentTypes = [];

        $pluginConfigurationClass = new PluginConfigurations();
        $databaseTypes            = $pluginConfigurationClass->getDocumentsTypes();

        foreach ($databaseTypes as $documentId => $name) {
            $documentTypes[] = [
                'documentTypeId'          => $documentId,
                'documentTypeDescription' => $name
            ];
        }

        $this->View()->assign([
            'data' => $documentTypes
        ]);
    }

    public function getOrderStatesAction()
    {
        $result = [];

        $pluginConfigurationClass = new PluginConfigurations();
        $orderStates = $pluginConfigurationClass->getOrderStates();

        foreach ($orderStates as $stateId => $name) {
            $result[] = [
                'stateId' => $stateId,
                'name' => $name
            ];
        }

        $this->View()->assign([
            'data' => $result
        ]);
    }

    public function getShopsInformationCommentFieldDropDownAction()
    {
        $commentFields = array_values((new PluginConfigurations())->getCommentFieldDropDown());

        $this->View()->assign([
            'data' => $commentFields
        ]);
    }

    public function getAttributesAsBulletsMultiSelectDropDownAction()
    {
        $attributesAsBullets = array();

        $pluginConfigurationClass    = new PluginConfigurations();
        $attributesColumnHeaderNames = $pluginConfigurationClass->getAttributesColumnHeaderNames();

        foreach ($attributesColumnHeaderNames as $values) {
            $attributesAsBullets[] = array(
                'attributesMultiSelectId'              => $values,
                'exportAttributesAsBulletsDescription' => $values
            );
        }

        $this->View()->assign(array(
                'data' => $attributesAsBullets
            ));
    }

    public function getBulletsAsAttributesMultiSelectDropDownAction()
    {
        $attributesAsBullets = array();

        $pluginConfigurationClass    = new PluginConfigurations();
        $attributesColumnHeaderNames = $pluginConfigurationClass->getAttributesColumnHeaderNames();

        foreach ($attributesColumnHeaderNames as $values) {
            $attributesAsBullets[] = array(
                'bulletsAsAttributesMultiSelectId'     => $values,
                'exportBulletsAsAttributesDescription' => $values
            );
        }

        $this->View()->assign(array(
                'data' => $attributesAsBullets
            ));
    }

    public function getOrderStatusShopwareMappingDropDownAction()
    {
        $mappingOrderStatusClass   = new MappingOrderStatus();
        $mappingShopwareOderStatus = $mappingOrderStatusClass->getShopwareOrderStatusMapping();

        $this->View()->assign(array('data' => $mappingShopwareOderStatus));
    }

    public function getOrderStatusShopwareMappingDetailDropDownAction()
    {
        $mappingOrderStatusClass = new MappingOrderStatusDetail();
        $mappingOrderStatusDetail = $mappingOrderStatusClass->getMappingOrderStatusCodeShopware();

        $this->View()->assign(array('data' => $mappingOrderStatusDetail));
    }

    public function getOrderStatusBrickfoxMappingDropDownAction()
    {
        $mappingOrderStatusClass = new MappingOrderStatus();
        $mappingOrderStatusClass = $mappingOrderStatusClass->getMappingOrderStatusCodeBrickFox();

        $this->View()->assign(array('data' => $mappingOrderStatusClass));
    }

    public function getOrderStatusBrickfoxMappingDetailDropDownAction()
    {
        $mappingOrderStatusClass = new MappingOrderStatusDetail();
        $mappingOrderStatusDetail = $mappingOrderStatusClass->getMappingOrderStatusCodeBrickFox();

        $this->View()->assign(array('data' => $mappingOrderStatusDetail));
    }

    public function getOrderStatusMappingListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingOrderStatus');

        $this->View()->assign(array(
                'data'  => $result['data'],
                'count' => $result['count']
            ));
    }

    public function getOrderStatusMappingDetailListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingOrderStatusDetail');

        $this->View()->assign(array(
            'data'  => $result['data'],
            'count' => $result['count']
        ));
    }

    public function saveOrderStatusMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->save(array(
                'params'           => $params,
                'mappingKeyFields' => array(
                    'brickfoxOrderStatusCode' => '',
                    'shopwareId'           => '',
                    'id'                      => ''
                ),
                'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingOrderStatus',
                'uniqueKey'        => 'id'
            ));

        $this->View()->assign(array(
                'success' => $result
            ));
    }

    public function saveOrderStatusMappingDetailAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->save(array(
            'params'           => $params,
            'mappingKeyFields' => array(
                'brickfoxOrderStatusCode' => '',
                'shopwareId'           => '',
                'id'                      => ''
            ),
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingOrderStatusDetail',
            'uniqueKey'        => 'id'
        ));

        $this->View()->assign(array(
            'success' => $result
        ));
    }

    public function deleteOrderStatusMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->delete(array(
                'params'           => $params,
                'mappingKeyFields' => array(
                    'brickfoxOrderStatusCode' => '',
                    'shopwareId'           => '',
                    'id'                      => ''
                ),
                'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingOrderStatus',
                'uniqueKey'        => 'id'
            ));

        $this->View()->assign(array(
                'success' => $result
            ));
    }

    public function deleteOrderStatusMappingDetailAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->delete(array(
            'params'           => $params,
            'mappingKeyFields' => array(
                'brickfoxOrderStatusCode' => '',
                'shopwareId'           => '',
                'id'                      => ''
            ),
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingOrderStatusDetail',
            'uniqueKey'        => 'id'
        ));

        $this->View()->assign(array(
            'success' => $result
        ));
    }

    public function getOrdersAttributesMappingListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingOrderAttributes');

        $this->View()->assign(array(
            'data'  => $result['data'],
            'count' => $result['count']
        ));
    }

    public function getOrdersAddInfoListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingOrderDetailsAttributes');

        $this->View()->assign(array(
            'data'  => $result['data'],
            'count' => $result['count']
        ));
    }

    public function setOrdersAttributesMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->save(array(
            'params'           => $params,
            'mappingKeyFields' => array(
                'shopwareFieldName'         => '',
                'brickfoxOrderAddInfoKey'   => '',
                'id'                        => ''
            ),
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingOrderAttributes',
            'uniqueKey'        => 'id'
        ));

        $this->View()->assign(array(
            'success' => $result
        ));
    }

    public function setNewOrdersAddInfoAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->save(array(
            'params'           => $params,
            'mappingKeyFields' => array(
                'shopwareFieldName'         => '',
                'brickfoxOrderAddInfoKey'   => '',
                'id'                        => ''
            ),
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingOrderDetailsAttributes',
            'uniqueKey'        => 'id'
        ));

        $this->View()->assign(array(
            'success' => $result
        ));
    }

    public function deleteOrdersAttributesMappingAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result = $mappingClass->delete(array(
            'params'           => $params,
            'mappingKeyFields' => array(
                'shopwareFieldName'       => '',
                'brickfoxOrderAddInfoKey' => '',
                'id'                      => ''
            ),
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingOrderAttributes',
            'uniqueKey'        => 'id'
        ));

        $this->View()->assign(array(
            'success' => $result
        ));
    }

    public function deleteOrdersAddInfoAction()
    {
        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result = $mappingClass->delete(array(
            'params'           => $params,
            'mappingKeyFields' => array(
                'shopwareFieldName'       => '',
                'brickfoxOrderAddInfoKey' => '',
                'id'                      => ''
            ),
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingOrderDetailsAttributes',
            'uniqueKey'        => 'id'
        ));

        $this->View()->assign(array(
            'success' => $result
        ));
    }

    public function getShopwareCurrenciesMappingListAction() {

        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingShopwareCurrencies');

        $this->View()->assign([
            'data'  => $result['data'],
            'count' => $result['count']
        ]);

    }

    public function saveShopwareCurrenciesMappingAction() {

        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->save([
            'params'           => $params,
            'mappingKeyFields' => [
                'brickfoxCurrenciesCode' => '',
                'mappingFieldKey' => '',
                'id'                     => ''
            ],
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingShopwareCurrencies',
            'uniqueKey'        => 'id'
        ]);

        $this->View()->assign([
            'success' => $result
        ]);

    }

    public function deleteShopwareCurrenciesMappingAction() {

        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->delete([
            'params'           => $params,
            'mappingKeyFields' => [
                'brickfoxCurrenciesCode' => '',
                'mappingFieldKey'        => '',
                'id'                     => ''
            ],
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingShopwareCurrencies',
            'uniqueKey'        => 'id'
        ]);

        $this->View()->assign([
            'success' => $result
        ]);

    }

    public function getShopwareCurrenciesMappingDropDownAction() {

        $this->View()->assign([
            'data' => (new MappingShopwareCurrencies())->getShopwareCurrenciesMappingFieldKeys()
        ]);

    }

    public function getAddressToFreetextMappingListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingAddressToFreetext');

        $this->View()->assign(array(
            'data'  => $result['data'],
            'count' => $result['count']
        ));
    }

    public function saveAddressToFreetextMappingAction() {

        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->save([
            'params'           => $params,
            'mappingKeyFields' => [
                'freetextFieldId'  => '',
                'addressFieldName' => '',
                'id'               => ''
            ],
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingAddressToFreetext',
            'uniqueKey'        => 'id'
        ]);

        $this->View()->assign([
            'success' => $result
        ]);

    }

    public function deleteAddressToFreetextMappingAction() {

        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->delete([
            'params'           => $params,
            'mappingKeyFields' => [
                'freetextFieldId'  => '',
                'addressFieldName' => '',
                'id'               => ''
            ],
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingAddressToFreetext',
            'uniqueKey'        => 'id'
        ]);

        $this->View()->assign([
            'success' => $result
        ]);

    }

    public function getShopwareAddressAttributesDropDownAction() {

        $mappingShopwareAddressFields    = new MappingAddressToFreetext();
        $freetextFields = $mappingShopwareAddressFields->getMappingShopwareAddressFields();

        $this->View()->assign(array(
            'data' => $freetextFields
        ));
    }

    public function getAddressAttributesDropDownAction() {

        $mappingAddressToFreetextClass    = new MappingAddressToFreetext();
        $freetextFields = $mappingAddressToFreetextClass->getFreetextfields();

        $this->View()->assign(array(
            'data' => $freetextFields
        ));
    }

    public function getShippingAddressToFreetextMappingListAction()
    {
        $start  = $this->Request()->getParam('start', 0);
        $limit  = $this->Request()->getParam('limit', 25);
        $filter = null;

        if ($this->Request()->has('filter') === true) {
            $filter = $this->Request()->getParam('filter');
        }

        $mappingClass = new Mapping();
        $result       = $mappingClass->load($start, $limit, $filter, 'Shopware\CustomModels\BfMultichannel\MappingShippingAddressToFreetext');

        $this->View()->assign(array(
            'data'  => $result['data'],
            'count' => $result['count']
        ));
    }

    public function saveShippingAddressToFreetextMappingAction() {

        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->save([
            'params'           => $params,
            'mappingKeyFields' => [
                'freetextFieldId'  => '',
                'addressFieldName' => '',
                'id'               => ''
            ],
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingShippingAddressToFreetext',
            'uniqueKey'        => 'id'
        ]);

        $this->View()->assign([
            'success' => $result
        ]);

    }

    public function deleteShippingAddressToFreetextMappingAction() {

        $params = $this->Request()->getParams();

        $mappingClass = new Mapping();
        $result       = $mappingClass->delete([
            'params'           => $params,
            'mappingKeyFields' => [
                'freetextFieldId'  => '',
                'addressFieldName' => '',
                'id'               => ''
            ],
            'mappingModel'     => 'Shopware\CustomModels\BfMultichannel\MappingShippingAddressToFreetext',
            'uniqueKey'        => 'id'
        ]);

        $this->View()->assign([
            'success' => $result
        ]);

    }

    public function getShopwareShippingAddressAttributesDropDownAction() {

        $mappingShopwareAddressFields    = new MappingShippingAddressToFreetext();
        $freetextFields = $mappingShopwareAddressFields->getMappingShopwareShippingAddressFields();

        $this->View()->assign(array(
            'data' => $freetextFields
        ));
    }

    public function getShippingAddressAttributesDropDownAction() {

        $mappingAddressToFreetextClass    = new MappingShippingAddressToFreetext();
        $freetextFields = $mappingAddressToFreetextClass->getFreetextfields();

        $this->View()->assign(array(
            'data' => $freetextFields
        ));
    }
}
