<?php

/**
 * Shopware_Controllers_Backend_BrickfoxUiErrorCodeList
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

use Bf\Multichannel\Components\Util\LogCodes;

class Shopware_Controllers_Backend_BrickfoxUiErrorCodeList extends Shopware_Controllers_Backend_ExtJs
{
    public function indexAction()
    {
    }

    public function getErrorListAction()
    {
        $list = array(
            'count' => 0,
            'data'  => array(
                array(
                    'error_code'    => LogCodes::EXPORT_SUCCESS_CODE,
                    'error_message' => LogCodes::EXPORT_SUCCESS
                ),
                array(
                    'error_code'    => LogCodes::EXPORT_NOTHING_TO_DO_CODE,
                    'error_message' => LogCodes::EXPORT_NOTHING_TO_DO
                ),
                array(
                    'error_code'    => LogCodes::EXPORT_PRODUCTS_ASSIGNMENTS_CODE,
                    'error_message' => LogCodes::EXPORT_PRODUCTS_ASSIGNMENTS
                ),
                array(
                    'error_code'    => LogCodes::EXPORT_CATEGORIES_BY_DEFAULT_CODE,
                    'error_message' => LogCodes::EXPORT_CATEGORIES_BY_DEFAULT
                ),
                array(
                    'error_code'    => LogCodes::EXPORT_ORDERS_STATUS_NO_HISTORY_CODE,
                    'error_message' => LogCodes::EXPORT_ORDERS_STATUS_NO_HISTORY
                ),
                array(
                    'error_code'    => LogCodes::EXPORT_PRICE_WITHOUT_CURRENCIES_CODE,
                    'error_message' => LogCodes::EXPORT_PRICE_WITHOUT_CURRENCIES
                ),
                array(
                    'error_code'    => LogCodes::EXPORT_PRICE_WITHOUT_CURRENCIES_CODE,
                    'error_message' => LogCodes::EXPORT_PRICE_WITHOUT_CURRENCIES
                ),
                array(
                    'error_code'    => LogCodes::EXPORT_TRANSLATION_WITHOUT_LOCALE_ISO_CODE,
                    'error_message' => LogCodes::EXPORT_TRANSLATION_WITHOUT_LOCALE_ISO
                ),
                array(
                    'error_code'    => LogCodes::EXPORT_TRANSLATION_MAPPING_ERROR_CODE,
                    'error_message' => LogCodes::EXPORT_TRANSLATION_MAPPING_ERROR
                ),
                array(
                    'error_code'    => LogCodes::EXPORT_DESCRIPTION_NO_PRODUCTS_NAME_CODE,
                    'error_message' => LogCodes::EXPORT_DESCRIPTION_NO_PRODUCTS_NAME
                ),
                array(
                    'error_code'    => LogCodes::EXPORT_MEDIA_TYPE_NOT_FOUND_CODE,
                    'error_message' => LogCodes::EXPORT_MEDIA_TYPE_NOT_FOUND
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_TOTAL_AMOUNT_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_TOTAL_AMOUNT
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_INVOICE_AMOUNT_NET_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_INVOICE_AMOUNT_NET
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_INVOICE_SHIPPING_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_INVOICE_SHIPPING
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_ZIP_CODE_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_ZIP_CODE
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_COUNTRY_ISO_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_COUNTRY_ISO
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_COUNTRY_MODEL_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_COUNTRY_MODEL
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_PAYMENT_METHOD_GIVEN_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_PAYMENT_METHOD_GIVEN
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_PAYMENT_MODEL_FOUND_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_PAYMENT_MODEL_FOUND
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_SHIPPING_METHOD_GIVEN_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_SHIPPING_METHOD_GIVEN
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_SHIPPING_MODEL_FOUND_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_SHIPPING_MODEL_FOUND
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_GIVEN_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_GIVEN
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_BILLING_ADDRESS_GIVEN_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_BILLING_ADDRESS_GIVEN
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_BILLING_ADDRESS_GIVEN_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_BILLING_ADDRESS_GIVEN
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_ORDER_NUMBER_GIVEN_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_ORDER_NUMBER_GIVEN
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_ORDER_STATUS_MODEL_FOUND_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_ORDER_STATUS_MODEL_FOUND
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_QUANTITY_GIVEN_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_QUANTITY_GIVEN
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_PRICE_GIVEN_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_PRICE_GIVEN
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_ITEM_NUMBER_GIVEN_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_ITEM_NUMBER_GIVEN
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_PRODUCT_ID_GIVEN_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_PRODUCT_ID_GIVEN
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_ARTICLE_NOT_FOUND_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_ARTICLE_NOT_FOUND
                ),
                array(
                    'error_code'    => LogCodes::IMPORT_ORDERS_NO_EMAIL_ADDRESS_GIVEN_CODE,
                    'error_message' => LogCodes::IMPORT_ORDERS_NO_EMAIL_ADDRESS_GIVEN
                ),
                array(
                    'error_code'    => LogCodes::EXPORT_FTP_CONNECTION_TEST_CODE,
                    'error_message' => LogCodes::EXPORT_FTP_CONNECTION_TEST
                ),
                array(
                    'error_code'    => LogCodes::EXPORT_FTP_TRANSFER_CODE,
                    'error_message' => LogCodes::EXPORT_FTP_TRANSFER
                ),
                array(
                    'error_code'    => LogCodes::EXPORT_FTP_EXTENSION_NOT_INSTALLED_CODE,
                    'error_message' => LogCodes::EXPORT_FTP_EXTENSION_NOT_INSTALLED
                )
            )
        );

        $this->View()->assign(
            $list
        );
    }
}
