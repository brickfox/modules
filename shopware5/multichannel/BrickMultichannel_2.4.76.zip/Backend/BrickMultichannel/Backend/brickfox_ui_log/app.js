// {namespace name="backend/BrickfoxUi"}
// {block name="backend/BrickfoxUiLog/application"}
Ext.define('Shopware.apps.BrickfoxUiLog', {

    name: 'Shopware.apps.BrickfoxUiLog',

    extend: 'Enlight.app.SubApplication',

    loadPath: '{url action=load}',

    bulkLoad: true,

    controllers: [
        'Main',
        'Log'
    ],

    views: [
        'Main',
        'LogExportProducts',
        'LogExportCategories',
        'LogExportDeleteFeed',
        'LogExportOrdersStatus',
        'LogExportProductsAssignments',
        'LogExportSuppliers',
        'LogImportOrders',
        'LogExportWindow'
    ],

    stores: [
        'LogExport'
    ],

    models: [
        'LogExport'
    ],

    launch: function () {
        var me = this,
            mainController = me.getController('Main');

        return mainController.mainWindow;
    }

});
// {/block}