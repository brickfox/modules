// {namespace name="backend/BrickfoxUiLog/controller"}
// {block name="backend/BrickfoxUiLog/controller/Log"}
Ext.define('Shopware.apps.BrickfoxUiLog.controller.Log', {

    extend: 'Ext.app.Controller',

    init: function () {
        var me = this;

        me.control({
            'BrickfoxUiLog-view-LogExportCategories':          {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            },
            'BrickfoxUiLog-view-LogExportDeleteFeed':          {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            },
            'BrickfoxUiLog-view-LogExportOrdersStatus':        {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            },
            'BrickfoxUiLog-view-LogExportProducts':            {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            },
            'BrickfoxUiLog-view-LogExportProductsAssignments': {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            },
            'BrickfoxUiLog-view-LogExportSuppliers':           {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            },
            'BrickfoxUiLog-view-LogImportOrders':              {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            }
        });

        me.callParent(arguments);
    },

    onRowDbClick: function (dv, record) {
        console.log(record.data);

        Ext.create('Shopware.apps.BrickfoxUiLog.view.LogExportWindow', {
            identifier:   record.data.identifier,
            errorCodes:   record.data.error_code,
            errorMessage: record.data.error_message,
            lastUpdate:   record.data.last_update
        }).show();
    },

    onReloadLog: function (view) {
        view.setLoading(true);

        view.store.load({
            callback: function () {
                view.setLoading(false)
            }
        });
    },

    onDeleteRow: function (view) {
        var selectedRows = view.getSelectionModel().getSelection();

        if (selectedRows.length) {
            Ext.MessageBox.confirm('Info', 'Sind Sie sicher das Sie diesen Datensatz löschen wollen?', function (btn) {
                if (btn === 'yes') {
                    view.store.remove(selectedRows);
                    view.store.suspendAutoSync();
                    view.store.destroy(selectedRows);
                    view.store.resumeAutoSync();
                    Shopware.Notification.createSuccessMessage('Löschen erfolgreich.', 'Daten konnten gelöscht werden.');
                }
            });
        } else {
            Shopware.Notification.createNoticeMessage('Info', 'Bitte wählen Sie ein Datensatz aus das Sie löschen möchten.');
        }
    }
});
// {/block}