// {namespace name="backend/BrickfoxUiLog/store"}
// {block name="backend/BrickfoxUiLog/store/LogExport"}
Ext.define('Shopware.apps.BrickfoxUiLog.store.LogExport', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUiLog-store-LogExport',

    model: 'Shopware.apps.BrickfoxUiLog.model.LogExport',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    logTypeList: null,

    proxy: {
        type:        'ajax',
        api:         {
            read:    '{url action=getExportLogList}',
            destroy: '{url action=deleteExportLog}'
        },
        reader:      {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        },
        extraParams: {
            logType: this.logTypeList
        }
    },

    listeners: {
        beforeload: function (store, foo, bar) {
            store.getProxy().setExtraParam('logType', store.logTypeList);
        }
    }
});
// {/block}