// {namespace name=backend/BrickfoxUiLog/view}
// {block name=backend/BrickfoxUiLog/view/LogExportProductsAssignments}
Ext.define('Shopware.apps.BrickfoxUiLog.view.LogExportProductsAssignments', {

    extend: 'Ext.grid.Panel',

    alias: 'widget.BrickfoxUiLog-view-LogExportProductsAssignments',

    title: '{s name="BrickfoxUiLog/view/Log/Assignments/Import/Log"}Zubehör-Export{/s}',

    layout: 'border',

    autoScroll: true,

    border: false,

    selType: 'checkboxmodel',

    selModel: {
        mode: 'MULTI'
    },

    viewConfig: {
        stripeRows:  false,
        getRowClass: function (record, rowIndex, rp, store) {
            var returnVal = null,
                processed = null,
                errorCodes = null;

            processed = record.get('processed');
            errorCodes = record.get('error_codes');

            if (processed === '0') {
                returnVal = 'error-row';
            } else if (processed === '1' && errorCodes !== '') {
                returnVal = 'warning-row';
            } else {
                returnVal = 'warning-row';
            }

            return returnVal;
        }
    },

    isBuilt: false,

    init: function () {
        var me = this;

        if (me.isBuilt === true) {
            me.store.load({
                params: {
                    logType: 'ProductsAssignments'
                }
            })
        }
    },

    initComponent: function () {
        var me = this;

        me.registerEvents();
        me.store = Ext.create('Shopware.apps.BrickfoxUiLog.store.LogExport', {
            logTypeList: 'ProductsAssignments'
        });

        me.columns = me.buildColumns();
        me.tbar = me.buildToolbar();
        me.dockedItems = me.buildToolbarBottom();

        me.callParent(arguments);

        me.isBuilt = true;
    },

    registerEvents: function () {
        var me = this;

        me.addEvents('reloadLog', 'delete');
    },

    buildColumns: function () {
        return [
            {
                header:    '{s name="BrickfoxUiLog/view/Log/Products/Column/Id"}Id{/s}',
                dataIndex: 'id',
                hidden:    true,
                width:     25
            },
            {
                header:    '{s name="BrickfoxUiLog/view/Log/Products/Column/JobId"}Verarbeitungs-ID{/s}',
                dataIndex: 'identifier',
                flex:      1
            },
            {
                header:    '{s name="BrickfoxUiLog/view/Log/Products/Column/error_codes"}Fehler-Codes{/s}',
                dataIndex: 'error_code',
                flex:      1
            },
            {
                header:    '{s name="BrickfoxUiLog/view/Log/Products/Column/error_message"}Fehlermeldung{/s}',
                dataIndex: 'errorMessageShort',
                flex:      1
            },
            {
                header:    '{s name="BrickfoxUiLog/view/Log/Products/Column/process_date"}Verarbeitungs Datum{/s}',
                dataIndex: 'last_update',
                flex:      1
            }
        ];
    },

    buildToolbar: function () {
        var me = this,
            buttons = [];

        buttons.push({
            xtype: 'tbfill'
        });

        buttons.push({
            xtype:             'textfield',
            name:              'searchfield',
            width:             170,
            cls:               'searchfield',
            enableKeyEvents:   true,
            checkChangeBuffer: 500,
            emptyText:         '{s name="BrickfoxUiLog/view/Log/Toolbar/Search"}Suchen..{/s}',
            listeners:         {
                'change': function (field, value) {
                    console.log(value);
                    var store = me.store,
                        searchString = Ext.String.trim(value);

                    //scroll the store to first page
                    store.currentPage = 1;

                    //if the search-value is empty, reset the filter
                    if (searchString.length === 0) {
                        store.filters.clear();
                        store.filter('logType', 'importProducts');
                    } else {
                        //this won't reload the store
                        store.filters.clear();

                        //
                        ////loads the store with a special filter
                        store.filter(
                            [
                                {
                                    property: 'search',
                                    value:    searchString
                                },
                                {
                                    property: 'logType',
                                    value:    'importProducts'
                                }
                            ]
                        );
                    }
                }
            }
        });

        buttons.push({
            xtype: 'tbspacer',
            width: 6
        });

        return Ext.create('Ext.toolbar.Toolbar', {
            ui:    'shopware-ui',
            items: buttons
        });
    },

    buildToolbarBottom: function () {
        var me = this;

        return Ext.create('Ext.toolbar.Toolbar', {
            cls:   'shopware-toolbar',
            dock:  'bottom',
            ui:    'shopware-ui',
            items: [
                Ext.create('Ext.PagingToolbar', {
                    store:       me.store,
                    displayInfo: true
                }),
                {
                    xtype: 'tbfill'
                },
                {
                    xtype: 'tbspacer',
                    width: 6
                }
            ]
        });
    }
});
// {/block}