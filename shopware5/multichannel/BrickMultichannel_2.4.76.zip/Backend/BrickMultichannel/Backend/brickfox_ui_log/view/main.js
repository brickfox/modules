// {namespace name=backend/BrickfoxUiLog/view}
// {block name=backend/BrickfoxUiLog/view/Main}
Ext.define('Shopware.apps.BrickfoxUiLog.view.Main', {

    extend: 'Enlight.app.Window',

    alias: 'widget.BrickfoxUiLog-view-main',

    layout: 'fit',

    width: 900,

    height: '90%',

    autoShow: true,

    stateful: true,

    stateId: 'BrickfoxUiLog-view-main',

    title: '{s name="main/Window/title/Log"}Connector Log{/s}',

    iconCls: 'bf_icon_log',

    initComponent: function () {
        var me = this;

        me.callParent(arguments);
    },

    createTabPanel: function () {
        var me = this;

        me.start = Ext.widget('BrickfoxUiLog-view-LogExportProducts', {
            logExport: me.logExport,
            main:      me
        });
        me.start.on('activate', me.start.init);

        me.exportCategories = Ext.widget('BrickfoxUiLog-view-LogExportCategories', {
            exportCategories: me.exportCategories,
            main:             me
        });
        me.exportCategories.on('activate', me.exportCategories.init);

        me.exportSuppliers = Ext.widget('BrickfoxUiLog-view-LogExportSuppliers', {
            exportSuppliers: me.exportSuppliers,
            main:            me
        });
        me.exportSuppliers.on('activate', me.exportSuppliers.init);

        me.exportOrdersStatus = Ext.widget('BrickfoxUiLog-view-LogExportOrdersStatus', {
            exportOrdersStatus: me.exportOrdersStatus,
            main:               me
        });
        me.exportOrdersStatus.on('activate', me.exportOrdersStatus.init);

        me.exportProductsAssignments = Ext.widget('BrickfoxUiLog-view-LogExportProductsAssignments', {
            exportProductsAssignments: me.exportProductsAssignments,
            main:                      me
        });
        me.exportProductsAssignments.on('activate', me.exportProductsAssignments.init);

        me.exportDeleteFeed = Ext.widget('BrickfoxUiLog-view-LogExportDeleteFeed', {
            exportDeleteFeed: me.exportDeleteFeed,
            main:             me
        });
        me.exportDeleteFeed.on('activate', me.exportDeleteFeed.init);


        me.importOrders = Ext.widget('BrickfoxUiLog-view-LogImportOrders', {
            importOrders: me.importOrders,
            main:         me
        });
        me.importOrders.on('activate', me.importOrders.init);

        me.tabpanel = Ext.create('Ext.tab.Panel', {
            items: [
                me.start,
                me.exportCategories,
                me.exportSuppliers,
                me.exportOrdersStatus,
                me.exportProductsAssignments,
                me.exportDeleteFeed,
                me.importOrders
            ]
        });

        me.add(me.tabpanel);
    }
});
// {/block}