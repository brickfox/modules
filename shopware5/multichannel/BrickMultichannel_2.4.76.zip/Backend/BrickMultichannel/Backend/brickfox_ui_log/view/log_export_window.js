// {namespace name=backend/BrickfoxUiLog/view}
// {block name=backend/BrickfoxUiLog/view/LogExportWindow}
Ext.define('Shopware.apps.BrickfoxUiLog.view.LogExportWindow', {

    extend: 'Ext.window.Window',

    title: '{s name="BrickfoxUiLog/view/Log/Import/Window/Title"}Log-Detail{/s}',

    width: 900,

    height: 500,

    autoScroll: false,

    modal: true,

    identifier: '-',

    errorCodes: '-',

    errorMessage: '-',

    lastUpdate: '-',

    initComponent: function () {
        var me = this;

        me.items = me.buildItems();

        me.callParent(arguments);
    },

    buildItems: function () {
        var me = this;

        return [
            {
                height: 500,
                width:  900,
                layout: {
                    type:  'hbox',
                    align: 'stretch'
                },
                items:  [
                    {
                        title: 'Information',
                        flex:  1,
                        items: [
                            {
                                xtype:    'fieldset',
                                border:   false,
                                defaults: {
                                    anchor:     '100%',
                                    labelWidth: '33%',
                                    xtype:      'displayfield'
                                },
                                items:    [
                                    {
                                        fieldLabel: '{s name="BrickfoxUiLog/view/Log/Products/Column/JobId"}Verarbeitungs-ID{/s}',
                                        value:      me.identifier
                                    },
                                    {
                                        fieldLabel: '{s name="BrickfoxUiLog/view/Log/Products/Column/process_date"}Verarbeitungs Datum{/s}',
                                        value:      me.lastUpdate
                                    },
                                    {
                                        fieldLabel: '{s name="BrickfoxUiLog/view/Log/Products/Column/error_codes"}Fehler-Codes{/s}',
                                        value:      me.errorCodes
                                    },
                                    {
                                        xtype:            'htmleditor',
                                        height:           290,
                                        fieldLabel:       '{s name="BrickfoxUiLog/view/Log/Products/Column/error_message"}Fehlermeldung{/s}',
                                        value:            me.errorMessage,
                                        enableAlignments: false,
                                        enableColors:     false,
                                        enableFont:       false,
                                        enableLinks:      false,
                                        enableLists:      false,
                                        enableSourceEdit: false,
                                        enableFormat:     false,
                                        enableFontSize:   false,
                                        editable:         false,
                                        frame:            false,
                                        border:           0,
                                        listeners:        {
                                            render: function (element) {
                                                element.setReadOnly(true);
                                            }
                                        }
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    }
});
// {/block}