// {namespace name="backend/BrickfoxUiLog/model"}
// {block name="backend/BrickfoxUiLog/model/LogExport"}
Ext.define('Shopware.apps.BrickfoxUiLog.model.LogExport', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/LogImport"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'identifier',
            type: 'string'
        },
        {
            name: 'error_code',
            type: 'string'
        },
        {
            name: 'error_message',
            type: 'string'
        },
        {
            name: 'errorMessageShort',
            type: 'string'
        },
        {
            name: 'last_update',
            type: 'string'
        }
    ]
});
// {/block}