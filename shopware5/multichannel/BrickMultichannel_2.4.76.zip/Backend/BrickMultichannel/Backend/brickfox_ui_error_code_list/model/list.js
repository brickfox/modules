// {namespace name="backend/BrickfoxUiErrorCodeList/model"}
// {block name="backend/BrickfoxUiErrorCodeList/model/List"}
Ext.define('Shopware.apps.BrickfoxUiErrorCodeList.model.List', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/Error/CodeList"}{/block}
        {
            name: 'error_code',
            type: 'string'
        },
        {
            name: 'error_message',
            type: 'string'
        }
    ]
});
// {/block}