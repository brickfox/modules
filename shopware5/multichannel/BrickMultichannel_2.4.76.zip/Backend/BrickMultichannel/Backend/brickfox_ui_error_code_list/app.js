// {namespace name="backend/BrickfoxUiErrorCodeList"}
// {block name="backend/BrickfoxUiErrorCodeList/application"}
Ext.define('Shopware.apps.BrickfoxUiErrorCodeList', {

    name: 'Shopware.apps.BrickfoxUiErrorCodeList',

    extend: 'Enlight.app.SubApplication',

    loadPath: '{url action=load}',

    bulkLoad: false,

    controllers: [
        'Main'
    ],

    views: [
        'Main'
    ],

    stores: [
        'List'
    ],

    models: [
        'List'
    ],

    launch: function () {
        var me = this,
            mainController = me.getController('Main');

        return mainController.mainWindow;
    }
});
// {/block}