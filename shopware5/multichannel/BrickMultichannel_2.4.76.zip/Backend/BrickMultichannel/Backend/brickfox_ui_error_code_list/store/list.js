// {namespace name="backend/BrickfoxUiErrorCodeList/store"}
// {block name="backend/BrickfoxUiErrorCodeList/store/List"}
Ext.define('Shopware.apps.BrickfoxUiErrorCodeList.store.List', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUiErrorCodeList-store-List',

    model: 'Shopware.apps.BrickfoxUiErrorCodeList.model.List',

    autoLoad: false,

    remoteSort: false,

    remoteFilter: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getErrorList}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}