// {namespace name="backend/BrickfoxUi"}
// {block name="backend/BrickfoxUi/application"}
Ext.define('Shopware.apps.BrickfoxUi', {

    name: 'Shopware.apps.BrickfoxUi',

    extend: 'Enlight.app.SubApplication',

    loadPath: '{url action=load}',

    bulkLoad: true,

    controllers: [
        'Configuration',
        'Logging',
        'Main'
    ],

    views: [
        'Configuration',
        'AttributesVariationsMapping',
        'CurrenciesMapping',
        'ShopwareCurrenciesMapping',
        'PaymentMapping',
        'Main',
        'Overview',
        'TranslationMapping',
        'LogGui',
        'MultiShopExport',
        'Log',
        'OrderStatusMapping',
        'OrderStatusMappingDetail',
        'OrdersAddInfosMapping',
        'OrdersAttributesMapping',
        'OrdersToShopsMapping',
        'OrdersToCustomerGroupsMapping',
        'AddressToFreetextMapping',
        'ShippingAddressToFreetextMapping',
        'TaxRatesMapping'
    ],

    stores: [
        'CurrenciesMapping',
        'AttributesVariationsMapping',
        'PaymentMapping',
        'combo.CustomerGroup',
        'combo.CurrenciesMapping',
        'combo.AttributesVariationsMapping',
        'combo.CurrenciesMappingBrickfox',
        'combo.IsNetMapping',
        'combo.TranslationMapping',
        'combo.TranslationMappingBrickfox',
        'combo.PaymentMapping',
        'combo.MultiShopExport',
        'combo.OrderStatusShopwareMapping',
        'combo.OrderStatusShopwareMappingDetail',
        'combo.OrdersToShopsMapping',
        'combo.OrdersToShopsMappingBrickfox',
        'combo.OrdersToCustomerGroupsMapping',
        'combo.OrdersToCustomerGroupsMappingBrickfox',
        'combo.ShopwareCurrenciesMapping',
        'combo.TaxRatesMapping',
        'combo.ShopsInformationCommentFieldMultiSelect',
        'combo.InvoiceDocumentTypesMultiSelect',
        'Overview',
        'TranslationMapping',
        'LogGui',
        'MultiShopExport',
        'OrdersAddInfosMapping',
        'OrdersAttributesMapping',
        'OrdersToShopsMapping',
        'OrdersToCustomerGroupsMapping',
        'AddressToFreetextMapping',
        'ShippingAddressToFreetextMapping',
        'ShopwareCurrenciesMapping',
        'TaxRatesMapping'
    ],

    models: [
        'CurrenciesMapping',
        'AttributesVariationsMapping',
        'PaymentMapping',
        'combo.CustomerGroup',
        'combo.CurrenciesMapping',
        'combo.AttributesVariationsMapping',
        'combo.CurrenciesMappingBrickfox',
        'combo.IsNetMapping',
        'combo.TranslationMapping',
        'combo.TranslationMappingBrickfox',
        'combo.PaymentMapping',
        'combo.MultiShopExport',
        'combo.OrderStatusShopwareMapping',
        'combo.OrderStatusShopwareMappingDetail',
        'combo.OrdersToShopsMapping',
        'combo.OrdersToShopsMappingBrickfox',
        'combo.OrdersToCustomerGroupsMapping',
        'combo.OrdersToCustomerGroupsMappingBrickfox',
        'combo.ShopwareCurrenciesMapping',
        'combo.TaxRatesMapping',
        'combo.ShopsInformationCommentFieldMultiSelect',
        'combo.InvoiceDocumentTypesMultiSelect',
        'Overview',
        'TranslationMapping',
        'LogGui',
        'MultiShopExport',
        'OrdersAddInfosMapping',
        'OrdersAttributesMapping',
        'OrdersToShopsMapping',
        'OrdersToCustomerGroupsMapping',
        'AddressToFreetextMapping',
        'ShippingAddressToFreetextMapping',
        'ShopwareCurrenciesMapping',
        'TaxRatesMapping'
    ],

    launch: function () {
        var me = this,
            mainController = me.getController('Main');

        return mainController.mainWindow;
    }
});
// {/block}
