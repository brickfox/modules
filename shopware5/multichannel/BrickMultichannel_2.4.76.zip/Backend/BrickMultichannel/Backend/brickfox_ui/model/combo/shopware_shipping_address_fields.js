// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/ShopwareShippingAddressFields"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.ShopwareShippingAddressFields', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/combo/ShopwareShippingAddressFields"}{/block}
        {
            name: 'addressFieldValue',
            type: 'string'
        }
    ]

});
// {/block}