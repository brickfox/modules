// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/OrdersToShopsMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.OrdersToShopsMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschanel/model/combo/OrdersToShopsMapping"}{/block}
        {
            name: 'shopwareFieldKeyName',
            type: 'string'
        },
        {
            name: 'shopwareFieldKeyCode',
            type: 'string'
        }
    ]
});
// {/block}