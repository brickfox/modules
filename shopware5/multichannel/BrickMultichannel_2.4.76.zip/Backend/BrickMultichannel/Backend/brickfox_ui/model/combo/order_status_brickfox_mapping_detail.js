// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/OrderStatusBrickfoxMappingDetail"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.OrderStatusBrickfoxMappingDetail', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/combo/OrderStatusBrickfoxMappingDetail"}{/block}
        {
            name: 'brickfoxOrderStatusCode',
            type: 'string'
        },
        {
            name: 'brickfoxOrderStatusName',
            type: 'string'
        }
    ]
});
// {/block}