// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/LogGui"}
Ext.define('Shopware.apps.BrickfoxUi.model.LogGui', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/LogGui"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'type',
            type: 'string'
        },
        {
            name: 'errorCode',
            type: 'string'
        },
        {
            name: 'message',
            type: 'string'
        },
        {
            name: 'lastUpdate',
            type: 'string'
        },
        {
            name: 'lastUpdater',
            type: 'string'
        }
    ]
});
// {/block}