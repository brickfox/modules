// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/PaymentMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.PaymentMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/Payment"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'brickfoxPaymentCode',
            type: 'string'
        },
        {
            name: 'mappingFieldKey',
            type: 'string'
        }
    ]
});
// {/block}