// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/MultiShopExport"}
Ext.define('Shopware.apps.BrickfoxUi.model.MultiShopExport', {
    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/MultiShopExport"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'mappingFieldKey',
            type: 'string'
        }
    ]
});
// {/block}