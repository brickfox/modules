// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/OrderStatusBrickfoxMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.OrderStatusBrickfoxMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/combo/OrderStatusBrickfoxMapping"}{/block}
        {
            name: 'brickfoxOrderStatusCode',
            type: 'string'
        },
        {
            name: 'brickfoxOrderStatusName',
            type: 'string'
        }
    ]
});
// {/block}