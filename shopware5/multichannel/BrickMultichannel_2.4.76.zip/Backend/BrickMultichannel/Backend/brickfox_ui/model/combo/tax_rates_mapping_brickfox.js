// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/TaxRatesMappingBrickfox"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.TaxRatesMappingBrickfox', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/BfTaxClass"}{/block}
        {
            name: 'brickfoxFieldKeyCode',
            type: 'string'
        },
        {
            name: 'brickfoxFieldKeyName',
            type: 'string'
        }
    ]
});
// {/block}