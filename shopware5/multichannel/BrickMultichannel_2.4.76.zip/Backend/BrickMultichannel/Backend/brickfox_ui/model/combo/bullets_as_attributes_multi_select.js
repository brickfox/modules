// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/BulletsAsAttributesMultiSelect"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.BulletsAsAttributesMultiSelect',{
    extend: 'Ext.data.Model',

    fields:[
        // {block name="backend/BfMultichannel/model/combo/BulletsAsAttributesMultiSelect"}{/block}
        {
            name: 'exportBulletsAsAttributesDescription',
            type: 'string'
        },
        {
            name: 'bulletsAsAttributesMultiSelectId',
            type: 'string'
        }
    ]
});
// {/block}