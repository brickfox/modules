// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/TranslationMappingBrickfox"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.TranslationMappingBrickfox', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/IsoBf"}{/block}
        {
            name: 'brickfoxFieldKeyCode',
            type: 'string'
        },
        {
            name: 'brickfoxFieldKeyName',
            type: 'string'
        }
    ]
});
// {/block}