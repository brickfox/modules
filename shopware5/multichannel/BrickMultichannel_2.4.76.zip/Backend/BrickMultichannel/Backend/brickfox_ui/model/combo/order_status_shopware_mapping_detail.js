// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/OrderStatusShopwareMappingDetail"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.OrderStatusShopwareMappingDetail', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/combo/OrderStatusShopwareMappingDetail"}{/block}
        {
            name: 'shopwareId',
            type: 'integer'
        },
        {
            name: 'orderStatusName',
            type: 'string'
        }
    ]
});
// {/block}