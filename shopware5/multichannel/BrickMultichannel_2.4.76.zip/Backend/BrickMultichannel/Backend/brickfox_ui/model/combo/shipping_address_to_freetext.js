// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/ShippingAddressToFreetext"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.ShippingAddressToFreetext', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/combo/ShippingAddressToFreetext"}{/block}
        {
            name: 'freetextFieldId',
            type: 'int'
        },
        {
            name: 'columnName',
            type: 'string'
        },
         {
             name: 'label',
             type: 'string'
         }
    ]
});
// {/block}