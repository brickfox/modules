// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/OrdersAttributesMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.OrdersAttributesMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/OrdersAttributesMapping"}{/block}
        {
            name: 'brickfoxOrderAddInfoKey',
            type: 'string'
        },
        {
            name: 'shopwareFieldName',
            type: 'string'
        },
        {
            name: 'id',
            type: 'string'
        }
    ]
});
// {/block}