// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/ShopwareCurrenciesMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.ShopwareCurrenciesMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/ShopwareCurrencies"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'brickfoxCurrenciesCode',
            type: 'string'
        },
        {
            name: 'mappingFieldKey',
            type: 'string'
        }
    ]
});
// {/block}