// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/Overview"}
Ext.define('Shopware.apps.BrickfoxUi.model.Overview', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/Overview/fields"}{/block}
        {
            name: 'phpVersion',
            type: 'string'
        },
        {
            name: 'phpMemoryLimit',
            type: 'string'
        },
        {
            name: 'phpMaxExecutionTime',
            type: 'string'
        },
        {
            name: 'masterShopName',
            type: 'string'
        },
        {
            name: 'brickfoxCustomerUrl',
            type: 'string'
        },
        {
            name: 'brickfoxApiKey',
            type: 'string'
        },
        {
            name: 'incomingPath',
            type: 'string'
        },
        {
            name: 'outgoingPath',
            type: 'string'
        },
        {
            name: 'logging',
            type: 'string'
        },
        {
            name: 'logPath',
            type: 'string'
        },
        {
            name: 'scriptLogger',
            type: 'int'
        },
        {
            name: 'cleanBfScriptloggerAfterDays',
            type: 'string'
        },
        {
            name: 'serverProtocol',
            type: 'string'
        },
        {
            name: 'isIncreaseInnoDBLockWaitTimeoutEnabled',
            type: 'string'
        },
        {
            name: 'importedOrderStatus',
            type: 'string'
        },
        {
            name: 'orderStatusForOrdersWithComment',
            type: 'string'
        },
        {
            name: 'rrpSpecialPrice',
            type: 'string'
        },
        {
            name: 'useExternOrdersNumberAsShopwareOrdersNumber',
            type: 'string'
        },
        {
            name: 'disabledCategories',
            type: 'string'
        },
        {
            name: 'defaultCustomerGroup',
            type: 'string'
        },
        {
            name: 'imageAttributesKeyWords',
            type: 'string'
        },
        {
            name: 'productsExportAttributes',
            type: 'string'
        },
        {
            name: 'attributesMultiSelectId',
            type: 'string'
        },
        {
            name: 'bulletsAsAttributesMultiSelectId',
            type: 'string'
        },
        {
            name: 'multiShopExport',
            type: 'string'
        },
        {
            name: 'multiLanguagesExport',
            type: 'string'
        },
        {
            name: 'exportMultivaluedPropertiesAsSingleAttributes',
            type: 'string'
        },
        {
            name: 'orderAttributes',
            type: 'string'
        },
        {
            name: 'ftpOrdersPath',
            type: 'string'
        },
        {
            name: 'ftpHost',
            type: 'string'
        },
        {
            name: 'ftpUser',
            type: 'string'
        },
        {
            name: 'ftpSslActive',
            type: 'string'
        },
        {
            name: 'ftpPort',
            type: 'string'
        },
        {
            name: 'lastProductsExport',
            type: 'string'
        },
        {
            name: 'lastSuppliersExport',
            type: 'string'
        },
        {
            name: 'lastOrderStatusExport',
            type: 'string'
        },
        {
            name: 'lastCategoriesExport',
            type: 'string'
        },
        {
            name: 'lastOrderImport',
            type: 'string'
        },
        {
            name: 'proFtpActive',
            type: 'string'
        },
        {
            name: 'ordersLinesIdAttributesField',
            type: 'string'
        },
        {
            name: 'exportOrderLineStatus',
            type: 'string'
        },
        {
            name: 'customerOrderNumberAttributesField',
            type: 'string'
        },
        {
            name: 'orderAttributesFieldReturnTrackingId',
            type: 'string'
        },
        {
            name: 'orderCarrierColumnName',
            type: 'string'
        },
        {
            name: 'orderTrackingIdColumnName',
            type: 'string'
        },
        {
            name: 'invoiceDocumentType',
            type: 'string'
        },
        {
            name: 'invoiceFolderPath',
            type: 'string'
        },
        {
            name: 'enableShopsOrderIdToComment',
            type: 'string'
        },
        {
            name: 'shopsInformationCommentField',
            type: 'string'
        },
        {
            name: 'orderNumberInCommentField',
            type: 'string'
        },
        {
            name: 'isbnFromAttribute',
            type: 'string'
        },
        {
            name: 'skipArticlesWithoutVariations',
            type: 'string'
        },
        {
            name: 'enableShopsNameToComment',
            type: 'string'
        },
        {
            name: 'enableShopsCustomerIdToComment',
            type: 'string'
        },
        {
            name: 'orderDisablePartnerImport',
            type: 'string'
        },
        {
            name: 'orderPartnerIdIncludeSalesChannelName',
            type: 'string'
        },
        {
            name: 'mappingActionToScriptTimeLimit',
            type: 'string'
        },
        {
            name: 'orderStatusExportUsesPickware',
            type: 'string'
        },
        {
            name: 'orderCarrierColumnNameMain',
            type: 'string'
        },
        {
            name: 'orderTrackingIdColumnNameMain',
            type: 'string'
        },
        {
            name: 'baseProductExportPreviewImageAlways',
            type: 'string'
        },
        {
            name: 'enableOrderImportWithItemNumber',
            type: 'string'
        },
        {
            name: 'usePickwareCompability',
            type: 'string'
        },
    ]
})
// {/block}
