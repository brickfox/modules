// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/ShippingAddressToFreetextMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.ShippingAddressToFreetextMapping', {
    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/ShippingAddressToFreetextMapping"}{/block}
        {
            name: 'addressFieldName',
            type: 'string'
        },
        {
            name: 'freetextFieldId',
            type: 'integer'
        },
        {
            name: 'id',
            type: 'integer'
        }
    ]
});
// {/block}