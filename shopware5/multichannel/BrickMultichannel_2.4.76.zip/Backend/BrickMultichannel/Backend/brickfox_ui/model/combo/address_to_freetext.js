// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/AddressToFreetext"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.AddressToFreetext', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/combo/AddressToFreetext"}{/block}
        {
            name: 'freetextFieldId',
            type: 'int'
        },
        {
            name: 'columnName',
            type: 'string'
        },
         {
             name: 'label',
             type: 'string'
         }
    ]
});
// {/block}