// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/TaxRatesMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.TaxRatesMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/TaxRates"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'mappingFieldKey',
            type: 'string'
        },
        {
            name: 'brickfoxTaxClass',
            type: 'string'
        }
    ]
});
// {/block}