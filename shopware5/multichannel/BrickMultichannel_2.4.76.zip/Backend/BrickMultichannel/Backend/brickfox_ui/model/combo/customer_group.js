// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/CustomerGroup"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.CustomerGroup', {

    extend: 'Ext.data.Model',

    fields: [
        //{block name="backend/BfMultichannel/model/combo/CustomerGroup"}{/block}
        {
            name: 'defaultCustomerGroupKey',
            type: 'string'
        },
        {
            name: 'defaultCustomerGroup',
            type: 'string'
        }
    ]
});
// {/block}