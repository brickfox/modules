// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/ShopsInformationCommentFieldMultiSelect"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.ShopsInformationCommentFieldMultiSelect', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/ShopsInformationCommentField/MultiSelect"}{/block}
        {
            name: 'commentFieldDescription',
            type: 'string'
        },
        {
            name: 'commentFieldId',
            type: 'string'
        }
    ]
});
// {/block}