// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/MultiShopExport"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.MultiShopExport', {
    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/combo/Multi/Shop/Export"}{/block}
        {
            name: 'shopName',
            type: 'string'
        },
        {
            name: 'shopId',
            type: 'string'
        }
    ]
});
// {/block}