// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/InvoiceDocumentTypesMultiSelect"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.InvoiceDocumentTypesMultiSelect', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/InvoiceDocumentTypes/MultiSelect"}{/block}
        {
            name: 'documentTypeDescription',
            type: 'string'
        },
        {
            name: 'documentTypeId',
            type: 'string'
        }
    ]
});
// {/block}