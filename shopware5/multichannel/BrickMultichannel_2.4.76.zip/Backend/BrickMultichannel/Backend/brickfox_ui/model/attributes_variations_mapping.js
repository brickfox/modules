// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/AttributesVariationsMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.AttributesVariationsMapping', {
    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/AttributesVariationsMapping"}{/block}
        {
            name: 'attributesVariationsCode',
            type: 'string'
        },
        {
            name: 'id',
            type: 'string'
        }
    ]
});
// {/block}