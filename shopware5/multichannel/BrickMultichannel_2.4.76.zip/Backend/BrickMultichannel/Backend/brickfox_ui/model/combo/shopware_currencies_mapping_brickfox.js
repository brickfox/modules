// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/ShopwareCurrenciesMappingBrickfox"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.ShopwareCurrenciesMappingBrickfox', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/ShopwareCurrenciesMappingBrickfox"}{/block}
        {
            name: 'brickfoxFieldKeyName',
            type: 'string'
        },
        {
            name: 'brickfoxFieldKeyCode',
            type: 'string'
        }
    ]
});
// {/block}