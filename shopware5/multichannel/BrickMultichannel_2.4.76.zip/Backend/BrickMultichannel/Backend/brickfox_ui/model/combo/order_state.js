// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/OrderState"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.OrderState', {
    extend: 'Ext.data.Model',
    fields: [
        // {block name="backend/BfSaleschannel/model/combo/OrderState/MultiSelect"}{/block}
        {
            name: 'name',
            type: 'string'
        },
        {
            name: 'stateId',
            type: 'string'
        }
    ]
});
// {/block}