// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/OrderStatusShopwareMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.OrderStatusShopwareMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/combo/OrderStatusShopwareMapping"}{/block}
        {
            name: 'shopwareId',
            type: 'integer'
        },
        {
            name: 'orderStatusName',
            type: 'string'
        }
    ]
});
// {/block}