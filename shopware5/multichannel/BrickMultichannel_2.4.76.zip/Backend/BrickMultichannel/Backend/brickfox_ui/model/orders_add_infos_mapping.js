// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/OrdersAddInfosMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.OrdersAddInfosMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/OrdersAddInfosMapping"}{/block}
        {
            name: 'brickfoxOrderAddInfoKey',
            type: 'string'
        },
        {
            name: 'shopwareFieldName',
            type: 'string'
        },
        {
            name: 'id',
            type: 'string'
        }
    ]
});
// {/block}