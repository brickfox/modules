// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/OrdersToToCustomerGroupsMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.OrdersToCustomerGroupsMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschanel/model/combo/OrdersToCustomerGroupsMapping"}{/block}
        {
            name: 'shopwareFieldKeyName',
            type: 'string'
        },
        {
            name: 'shopwareFieldKeyCode',
            type: 'string'
        }
    ]
});
// {/block}