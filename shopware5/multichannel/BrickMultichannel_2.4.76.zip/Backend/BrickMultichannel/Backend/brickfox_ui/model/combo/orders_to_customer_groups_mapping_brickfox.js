// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/OrdersToToCustomerGroupsMappingBrickfox"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.OrdersToCustomerGroupsMappingBrickfox', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschanel/model/combo/OrdersToCustomerGroupsMappingBrickfox"}{/block}
        {
            name: 'brickfoxFieldKeyName',
            type: 'string'
        },
        {
            name: 'brickfoxFieldKeyCode',
            type: 'string'
        }
    ]
});
// {/block}