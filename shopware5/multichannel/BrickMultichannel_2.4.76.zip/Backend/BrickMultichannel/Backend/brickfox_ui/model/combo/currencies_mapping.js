// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/CurrenciesMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.CurrenciesMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/Currencies"}{/block}
        {
            name: 'shopwareFieldKeyName',
            type: 'string'
        },
        {
            name: 'shopwareFieldKeyCode',
            type: 'string'
        }
    ]
});
// {/block}