// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/OrdersToShopsMappingBrickfox"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.OrdersToShopsMappingBrickfox', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/OrdersToShopsMappingBrickfox"}{/block}
        {
            name: 'brickfoxFieldKeyCode',
            type: 'string'
        },
        {
            name: 'brickfoxFieldKeyName',
            type: 'string'
        }
    ]
});
// {/block}