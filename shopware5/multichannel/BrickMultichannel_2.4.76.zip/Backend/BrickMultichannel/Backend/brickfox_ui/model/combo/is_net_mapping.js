// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/IsNetMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.IsNetMapping', {
    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/isNet"}{/block}
        {
            name: 'isNetFieldKeyName',
            type: 'string'
        },
        {
            name: 'isNetFieldKeyCode',
            type: 'string'
        }
    ]
});
// {/block}