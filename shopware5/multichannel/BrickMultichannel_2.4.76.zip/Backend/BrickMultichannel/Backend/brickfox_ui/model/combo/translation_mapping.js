// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/TranslationMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.TranslationMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschanel/model/combo/Translation"}{/block}
        {
            name: 'shopwareFieldKeyName',
            type: 'string'
        },
        {
            name: 'shopwareFieldKeyCode',
            type: 'string'
        }
    ]
});
// {/block}