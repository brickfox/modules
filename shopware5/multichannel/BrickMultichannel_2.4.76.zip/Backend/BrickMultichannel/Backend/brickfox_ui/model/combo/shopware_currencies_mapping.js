// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/ShopwareCurrenciesMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.ShopwareCurrenciesMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/Currencies"}{/block}
        {
            name: 'shopwareFieldKeyName',
            type: 'string'
        },
        {
            name: 'shopwareFieldKeyCode',
            type: 'string'
        }
    ]
});
// {/block}