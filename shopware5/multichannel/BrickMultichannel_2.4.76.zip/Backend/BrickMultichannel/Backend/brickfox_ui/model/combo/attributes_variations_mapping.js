// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/AttributesVariationsMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.AttributesVariationsMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/combo/AttributesVariationsMapping"}{/block}
        {
            name: 'shopwareAttributesCode',
            type: 'string'
        },
        {
            name: 'shopwareAttributesCode',
            type: 'string'
        }
    ]
});
// {/block}