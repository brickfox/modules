// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/OrdersToShopsMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.OrdersToShopsMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/OrdersToShopsMapping"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'brickfoxShopsId',
            type: 'string'
        },
        {
            name: 'shopwareShopsId',
            type: 'string'
        }
    ]
});
// {/block}