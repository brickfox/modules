// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/AddressToFreetextMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.AddressToFreetextMapping', {
    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/AddressToFreetextMapping"}{/block}
        {
            name: 'addressFieldName',
            type: 'string'
        },
        {
            name: 'freetextFieldId',
            type: 'integer'
        },
        {
            name: 'id',
            type: 'integer'
        }
    ]
});
// {/block}