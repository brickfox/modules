// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/OrdersToCustomerGroupsMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.OrdersToCustomerGroupsMapping', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/OrdersToCustomerGroupsMapping"}{/block}
        {
            name: 'id',
            type: 'string'
        },
        {
            name: 'brickfoxShopsId',
            type: 'string'
        },
        {
            name: 'shopwareCustomerGroupId',
            type: 'string'
        }
    ]
});
// {/block}