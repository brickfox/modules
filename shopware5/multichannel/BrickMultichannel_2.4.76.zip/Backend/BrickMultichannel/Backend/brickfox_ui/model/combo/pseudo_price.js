// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/PseudoPrice"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.PseudoPrice', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/combo/PseudoPrice"}{/block}
        {
            name: 'rrpSpecialPrice',
            type: 'string'
        },
        {
            name: 'name',
            type: 'string'
        }
    ]

});
// {/block}