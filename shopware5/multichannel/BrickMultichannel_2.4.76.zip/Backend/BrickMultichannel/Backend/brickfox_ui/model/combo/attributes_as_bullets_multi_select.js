// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/AttributesAsBulletsMultiSelect"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.AttributesAsBulletsMultiSelect', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfSaleschannel/model/combo/AttributesAsBullets/MultiSelect"}{/block}
        {
            name: 'exportAttributesAsBulletsDescription',
            type: 'string'
        },
        {
            name: 'attributesMultiSelectId',
            type: 'string'
        }
    ]
});
// {/block}