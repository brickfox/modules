// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/OrderStatusMapping"}
Ext.define('Shopware.apps.BrickfoxUi.model.OrderStatusMapping', {
    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/OrderStatusMapping"}{/block}
        {
            name: 'shopwareId',
            type: 'integer'
        },
        {
            name: 'brickfoxOrderStatusCode',
            type: 'string'
        }
    ]
});
// {/block}