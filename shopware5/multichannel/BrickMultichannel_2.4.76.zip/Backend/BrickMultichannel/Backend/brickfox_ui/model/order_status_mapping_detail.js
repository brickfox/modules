// {namespace name="backend/BrickfoxUi/model"}
// {block name="backend/BrickfoxUi/model/OrderStatusMappingDetail"}
Ext.define('Shopware.apps.BrickfoxUi.model.OrderStatusMappingDetail', {
    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/OrderStatusMappingDetail"}{/block}
        {
            name: 'shopwareId',
            type: 'integer'
        },
        {
            name: 'brickfoxOrderStatusCode',
            type: 'string'
        }
    ]
});
// {/block}