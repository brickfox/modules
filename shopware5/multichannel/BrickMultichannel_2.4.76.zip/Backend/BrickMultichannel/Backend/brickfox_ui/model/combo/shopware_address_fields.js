// {namespace name="backend/BrickfoxUi/model/combo"}
// {block name="backend/BrickfoxUi/model/combo/ShopwareAddressFields"}
Ext.define('Shopware.apps.BrickfoxUi.model.combo.ShopwareAddressFields', {

    extend: 'Ext.data.Model',

    fields: [
        // {block name="backend/BfMultichannel/model/combo/ShopwareAddressFields"}{/block}
        {
            name: 'addressFieldValue',
            type: 'string'
        }
    ]

});
// {/block}