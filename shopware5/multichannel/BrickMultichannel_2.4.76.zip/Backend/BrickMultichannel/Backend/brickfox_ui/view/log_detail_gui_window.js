// {namespace name=backend/BrickfoxUi/view}
// {block name=backend/BrickfoxUi/view/LogDetailGuiWindow}
Ext.define('Shopware.apps.BrickfoxUi.view.LogDetailGuiWindow', {

    extend: 'Ext.Window',

    title: '{s name="BrickfoxUi/view/logging/Detail/GUI/Window/Title"}Log-Detail{/s}',

    width: 900,

    height: 400,

    autoScroll: true,

    modal: true,

    type: '-',

    errorCode: '-',

    message: '-',

    lastUpdate: '-',

    lastUpdater: '-',

    initComponent: function () {
        var me = this;

        me.items = me.buildItems();

        me.callParent(arguments);
    },

    buildItems: function () {
        var me = this;

        return [
            {
                xtype:      'fieldset',
                autoScroll: true,
                defaults:   {
                    anchor:     '100%',
                    labelWidth: '33%',
                    xtype:      'displayfield'
                },
                items:      [
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/Log/GUI/Column/ExportType"}Typ{/s}',
                        value:      me.type
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/Log/GUI/Column/ErrorCode"}Fehler-Code{/s}',
                        value:      me.errorCode
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/Log/GUI/Column/lastUpdate"}Letzte Aktualisierung{/s}',
                        value:      me.lastUpdate
                    },
                    {
                        xtype:            'htmleditor',
                        fieldLabel:       '{s name="BrickfoxUi/view/Log/GUI/Column/Message"}Meldung{/s}',
                        value:            me.message,
                        enableAlignments: false,
                        enableColors:     false,
                        enableFont:       false,
                        enableLinks:      false,
                        enableLists:      false,
                        enableSourceEdit: false,
                        enableFormat:     false,
                        enableFontSize:   false,
                        editable:         false,
                        frame:            false,
                        border:           0,
                        listeners:        {
                            render: function (element) {
                                element.setReadOnly(true);
                            }
                        }
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/Log/GUIColumn/LastUpdater"}Benutzername{/s}',
                        value:      me.lastUpdater
                    }
                ]
            }
        ]
    }
});
// {/block}