// {namespace name=backend/BrickfoxUi/view}
// {block name=backend/BrickfoxUi/view/Configuration}
Ext.define('Shopware.apps.BrickfoxUi.view.Configuration', {

    extend: 'Ext.form.Panel',

    alias: 'widget.BrickfoxUi-view-Configuration',

    title: '{s name="BrickfoxUi/view/configuration/title"}Plugin-Konfiguration{/s}',

    autoScroll: true,

    cls: 'shopware-form',

    layout: 'anchor',

    border: false,

    checkIsMultiShopUrl: 'BrickfoxUi/checkIsMultiShop',

    isMultiShop:   false,
    multiShopData: {},

    isBuilt: false,

    store: {},

    init: function () {
        var me = this;

        if (me.isBuilt === true) {
            me.remove(me.items.items[1]);
            me.onCheckMultiShop();
            me.add(me.buildFtpFields());
            me.loadStore();
        }
    },

    initComponent: function () {
        var me = this;

        me.store = Ext.create('Shopware.apps.BrickfoxUi.store.Configuration');
        me.onCheckMultiShop();

        me.items = me.buildItems();
        me.dockedItems = me.buildToolbar();
        me.registerEvents();

        me.callParent(arguments);

        me.loadStore();

        me.isBuilt = true;
    },

    loadStore: function () {
        var me = this;

        me.store.load({
            callback: function (records) {
                records[0].data = records[0].raw;
                me.loadRecord(records[0]);
            }
        })
    },

    registerEvents: function () {
        var me = this;

        me.addEvents('save', 'changedMultiShop');
    },

    buildItems: function () {
        var me = this,
            items = [
                {
                    xtype:    'fieldset',
                    title:    'Konfiguration',
                    defaults: {
                        anchor:     '100%',
                        labelWidth: '33%'
                    },
                    id:       'configurationForm',
                    items:    [
                        {
                            xtype:      'displayfield',
                            fieldLabel: '{s name="BrickfoxUi/view/configuration/combobox/pluginMode"}Modus{/s}',
                            value:      'Shopware ist PIM'
                        },
                        {
                            xtype:       'checkbox',
                            fieldLabel:  '{s name="BrickfoxUi/view/overview/displayField/proFtpActive"}Pro-FTP{/s}',
                            name:        'proFtpActive',
                            inputValue:  true,
                            supportText: 'Wenn aktiv, wird davon ausgegangen das Pro-FTP auf dem FTP - Server installiert ist.'
                        },
                        {
                            xtype:      'textfield',
                            name:       'masterShopName',
                            fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/masterShopsName"}Name des Master - Shop{/s}',
                            allowBlank: false,
                            value:      ''
                        },
                        {
                            xtype:      'textfield',
                            name:       'brickfoxCustomerUrl',
                            fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/brickfoxCustomerUrl"}Brickfox - Mandanten URL{/s}',
                            allowBlank: false,
                            value:      ''
                        },
                        {
                            xtype:      'textfield',
                            inputType:  'password',
                            name:       'brickfoxApiKey',
                            fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/brickfoxApiKey"}Brickfox REST API - KEY Passwort{/s}',
                            allowBlank: false,
                            value:      ''
                        },
                        {
                            xtype:      'textfield',
                            name:       'incomingPath',
                            fieldLabel: '{s name="BrickfoxUio/view/configuration/textfield/incomingPath"}Pfad für eingehende XML Dateien{/s}',
                            allowBlank: false,
                            value:      ''
                        },
                        {
                            xtype:      'textfield',
                            name:       'outgoingPath',
                            fieldLabel: '{s name="BrickfoxUio/view/configuration/textfield/outgoingPath"}Pfad für ausgehende XML Dateien{/s}',
                            allowBlank: false
                        },
                        {
                            xtype:        'combobox',
                            editable:     false,
                            name:         'logging',
                            fieldLabel:   '{s name="BrickfoxUi/view/configuration/combobox/logging"}Logging aktivieren{/s}',
                            allowBlank:   false,
                            queryMode:    'local',
                            displayField: 'name',
                            valueField:   'logging',
                            store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.Logging').load(),
                            id:           'comboLogging'
                        },
                        {
                            xtype:      'textfield',
                            name:       'logPath',
                            fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/logPath"}Pfad für Logfiles{/s}',
                            allowBlank: false
                        },
                        {
                            xtype:         'numberfield',
                            name:          'scriptLogger',
                            fieldLabel:    '{s name="Brickfox/view/overview/displayField/scriptLogger"}Zurücksetzen des Script-Logger{/s}',
                            allowBlank:    false,
                            allowDecimals: false
                        },
                        {
                            xtype:         'numberfield',
                            name:          'cleanBfScriptloggerAfterDays',
                            fieldLabel:    '{s name="Brickfox/view/configuration/textfield/cleanBfScriptloggerAfterDays"}Scriptlogger-Daten nach X-Tage(n) bereinigen{/s}',
                            value:         14,
                            allowDecimals: false
                        },
                        {
                            xtype:       'checkbox',
                            name:        'serverProtocol',
                            fieldLabel:  '{s name="Brickfox/view/overview/displayField/httpsProtocol"}Server-Protokoll https{/s}',
                            supportText: 'Wenn aktiv, wird als Server Protokoll https verwendet'
                        },
                        {
                            xtype:       'checkbox',
                            name:        'isIncreaseInnoDBLockWaitTimeoutEnabled',
                            inputValue:  true,
                            fieldLabel:  '{s name="Brickfox/view/overview/displayField/isIncreaseInnoDBLockWaitTimeoutEnabled"}Increase InnoDBLockWaitTimeout{/s}',
                            supportText: 'Wenn aktiv, wird der InnoDbLockWaitTimeout erhöht'
                        },
                        {
                            xtype:        'combobox',
                            editable:     false,
                            name:         'rrpSpecialPrice',
                            fieldLabel:   '{s name="BrickfoxUi/view/configuration/combobox/specialAndRrpPricesToBrickfox"}Shopware Pseudopreis - Übertragung{/s}',
                            allowBlank:   false,
                            queryMode:    'local',
                            displayField: 'name',
                            valueField:   'rrpSpecialPrice',
                            store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.PseudoPrice'),
                            id:           'comboRrpSpecialPrices',
                            supportText:  '{s name="BrickfoxUi/view/configuration/supportText/rrpSpecialPrice"}Wählen Sie bitte aus wie Sie den Pseudopreis aus Shopware zu brickfox übertragen möchten.{/s}'
                        },
                        {
                            xtype:       'checkbox',
                            name:        'useExternOrdersNumberAsShopwareOrdersNumber',
                            fieldLabel:  '{s name="Brickfox/view/configuation/combobox/useExternOrdersNumberAsShopwareOrdersNumber"}BF-Externe Bestellnummer verwenden{/s}',
                            inputValue:  true,
                            supportText: '{s name="BrickfoxUi/view/configuration/supportText/userExternOrdersNumberAsShopwareNumber"}Wenn aktiv wird bsp.: Bestellnummer aus Amazon als Shopware Bestellnummer eingetragen. Ansonsten wird der Shopware-Interne Nummernkreis verwendet.{/s}'
                        },
                        {
                            xtype:       'textfield',
                            name:        'disabledCategories',
                            fieldLabel:  '{s name="BrickfoxUi/view/configuration/textfield/disabledCategories"}Nicht zu exprtierende Kategorie{/s}',
                            supportText: '{s name="BrickfoxUi/view/configuration/supportText/disabledCategories"}Tragen Sie "," (Komma) separiert Kategorie-Ids ein die Sie nicht an Brickfox übertragen möchten.{/s}'
                        },
                        {
                            xtype:        'combobox',
                            editable:     false,
                            name:         'defaultCustomerGroup',
                            fieldLabel:   '{s name="BrickfoxUi/view/configuration/textfield/defaultCustomerGroup"}Neu-Kunden Kundengruppe{/s}',
                            allowBlank:   false,
                            queryMode:    'local',
                            displayField: 'defaultCustomerGroup',
                            valueField:   'defaultCustomerGroupKey',
                            store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.CustomerGroup').load(),
                            id:           'comboCustomerGroup'
                        },
                        {
                            xtype: 'checkbox',
                            name:       'usePickwareCompability',
                            fieldLabel: '{s name="Brickfox/view/configuration/checkbox/usePickwareCompability"}Kompatibilität für Pickware "Stücklisten / Sets"{/s}',
                            inputValue: true,
                            supportText: '{s name="BrickfoxUi/view/configuration/support/usePickwareCompability"}Aktivieren wenn das Plugin "Stücklisten / Sets" von Pickware verwendet wird.{/s}'
                        },
                        {
                            xtype: 'checkbox',
                            name:       'baseProductExportPreviewImageAlways',
                            fieldLabel: '{s name="Brickfox/view/configuration/checkbox/baseProductExportPreviewImageAlways"}Vorschaubild auf Stammartikel-Ebene exportieren{/s}',
                            inputValue: true,
                            supportText: '{s name="BrickfoxUi/view/configuration/support/baseProductExportPreviewImageAlways"}Wenn aktiv, wird beim Produkt-Export das Vorschaubild immer auch auf Stammartikel-Ebene mit Sortierreihenfolge 1 exportiert.{/s}'
                        },
                        {
                            xtype:       'textfield',
                            name:        'imageAttributesKeyWords',
                            fieldLabel:  '{s name="BrickfoxUi/view/configuration/textfield/imageAttributeKeys"}Keywords - Bildattribute{/s}',
                            supportText: '{s name="BrickfoxUi/view/configuration/supportText/imageAttributeKeys"}Hier können Sie eine \",\" separierte Liste hinterlegt mit Key-Wörtern. Sobald Sie hier Werte eintragen werden nur noch Bilder exportiert die einen dieser Werte als Attribut hinterlegt haben.{/s}'
                        },
                        {
                            xtype:       'textfield',
                            name:        'productsExportAttributes',
                            fieldLabel:  '{s name="BrickfoxUi/view/configuration/textfield/productsExportAttributes"}Produkte mit Attribut exportieren{/s}',
                            supportText: '{s name="BrickfoxUi/view/configuration/supportText/productsExportAttributes"}Geben Sie an welche Produkte anhand eines Attributes ausgesteuert werden dürfen. Bsp.: attr1 => BF{/s}'
                        },
                        {
                            xtype:        'combobox',
                            fieldLabel:   '{s name="Brickfox/view/configuration/combobox/AttributesAsBulletsExport"}Attribute/Eigenschaften als Bulletpoints{/s}',
                            multiSelect:  true,
                            valueField:   'attributesMultiSelectId',
                            displayField: 'exportAttributesAsBulletsDescription',
                            store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.AttributesAsBulletsMultiSelect').load(),
                            queryMode:    'local',
                            name:         'attributesMultiSelectId',
                            id:           'attributesAsBulletsId',
                            supportText:  'Bestimmen Sie hier die Attribute die als Bullet-Points an Brickfox übertragen werden sollen.'
                        },
                        {
                            xtype:        'combobox',
                            fieldLabel:   '{s name="Brickfox/view/configuration/combobox/BulletsAsAttributesExport"}Attribute als Bulletpoints-Attribute{/s}',
                            multiSelect:  true,
                            valueField:   'bulletsAsAttributesMultiSelectId',
                            displayField: 'exportBulletsAsAttributesDescription',
                            store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.BulletsAsAttributesMultiSelect').load(),
                            queryMode:    'local',
                            name:         'bulletsAsAttributesMultiSelectId',
                            id:           'bulletsAsAttributesId',
                            supportText:  'Bestimmen Sie hier die Attribute die als Bulletpoint - Attribute übertragen werden sollen.'
                        },
                        {
                            xtype:       'checkbox',
                            name:        'multiShopExport',
                            fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/multiShopExport"}Multishops - Exportieren{/s}',
                            inputValue:  true,
                            supportText: '{s name="BrickfoxUi/view/configuration/support/multiShopExport"}Wenn aktiv, können Kategorien und Produkte aus unterschiedlichen Shops exportiert werden.{/s}'
                        },
                        {
                            xtype:       'checkbox',
                            name:        'multiLanguagesExport',
                            fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/multiLanguagesExport"}Übersetzungen - Exportieren{/s}',
                            inputValue:  true,
                            supportText: '{s name="BrickfoxUi/view/configuration/support/multiLanguagesExport"}Wenn aktiv, werden Übersetzungen von Beschreibungen, Attributen und Variantenmerkmalen mit exportiert.{/s}',
                        },
                        {
                            xtype:       'checkbox',
                            name:        'exportMultivaluedPropertiesAsSingleAttributes',
                            fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/exportMultivaluedPropertiesAsSingleAttributes"}Mehrfache Eigenschaften als Mehrfachattribute getrennt exportieren{/s}',
                            inputValue:  true,
                            supportText: '{s name="BrickfoxUi/view/configuration/support/exportMultivaluedPropertiesAsSingleAttributes"}Wenn aktiv, werden Eigenschaften mit mehreren Werten nicht als kommaseparierte Liste übergeben, sondern für jeden Wert ein separates Attribut-Tag{/s}'
                        },
                        {
                            xtype:       'textfield',
                            name:        'orderAttributes',
                            fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/orderAttributes"}Plattform-Bestellnummer in Attributfeld{/s}',
                            supportText: '{s name="BrickfoxUi/view/configuration/support/orderAttributes"}Werte können sein attribute1 - attribute6{/s}'
                        },
                        {
                            xtype:       'checkbox',
                            name:        'enableShopsNameToComment',
                            fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/enableShopsNameToComment"}Marktplatzname in Kommentarfeld speichern{/s}',
                            inputValue:  true,
                            supportText: '{s name="BrickfoxUi/view/configuration/support/enableShopsNameToComment"}Wenn aktiv, wird der Name des Marktplatzes in das ausgewählte Kommentarfeld gespeichert.{/s}'
                        },
                        {
                            xtype:       'checkbox',
                            name:        'enableShopsOrderIdToComment',
                            fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/enableShopsOrderIdToComment"}Plattform-Bestellnummer in Kommentarfeld speichern{/s}',
                            inputValue:  true,
                            supportText: '{s name="BrickfoxUi/view/configuration/support/enableShopsOrderIdToComment"}Wenn aktiv, wird die Bestellnummer des Marktplatzes in das ausgewählte Kommentarfeld gespeichert.{/s}'
                        },
                        {
                            xtype:       'checkbox',
                            name:        'enableShopsCustomerIdToComment',
                            fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/enableShopsCustomerIdToComment"}Plattform-Kundennummer in Kommentarfeld speichern{/s}',
                            inputValue:  true,
                            supportText: '{s name="BrickfoxUi/view/configuration/support/enableShopsCustomerIdToComment"}Wenn aktiv, wird die Kundennummer des Marktplatzes in das ausgewählte Kommentarfeld gespeichert.{/s}'
                        },
                        {
                            xtype:        'combobox',
                            fieldLabel:   '{s name="Brickfox/view/configuration/combobox/shopsInformationCommentField"}Shopware Kommentarfeld für Marktplatzname, Bestellnummer, Kundennummer{/s}',
                            name:         'shopsInformationCommentField',
                            multiSelect:  false,
                            valueField:   'commentFieldId',
                            displayField: 'commentFieldDescription',
                            store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.ShopsInformationCommentFieldMultiSelect').load(),
                            queryMode:    'local',
                            id:           'shopsInformationCommentFieldSelectBox',
                            supportText:  'Bestimmen Sie das Kommentarfeld, in welches die Kombination aus Marktplatzname, Bestellnummer des Kanals und/oder Kundennummer (in dieser Reihenfolge) ausgegeben werden soll.'
                        },
                        {
                            xtype:        'combobox',
                            fieldLabel:   '{s name="Brickfox/view/configuration/combobox/saveOrderNumberInCommentField"}Interne B2B-Händler Bestellnummer in Kommentarfeld speichern{/s}',
                            name:         'orderNumberInCommentField',
                            multiSelect:  false,
                            valueField:   'commentFieldId',
                            displayField: 'commentFieldDescription',
                            store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.ShopsInformationCommentFieldMultiSelect').load(),
                            queryMode:    'local',
                            id:           'saveOrderNumberInCommentFieldSelectBox',
                            supportText:  'Wenn aktiv, wird die Interne B2B-Händler Bestellnummer des Marktplatzes in das ausgewählte Kommentarfeld gespeichert.'
                        },
                        {
                            xtype:       'textfield',
                            name:        'ordersLinesIdAttributesField',
                            fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/ordersLinesIdAttributesField"}brickfox Bestellpositions-Nummer in Attributfeld{/s}',
                            supportText: '{s name="BrickfoxUi/view/configuration/support/ordersLinesIdAttributesField"}Werte können sein attribute1 - attribute6{/s}'
                        },
                        {
                            xtype:       'checkbox',
                            name:        'exportOrderLineStatus',
                            fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/exportOrderLineStatus"}Status auf Bestellpositionsebene exportieren{/s}',
                            inputValue:  true,
                            supportText: '{s name="BrickfoxUi/view/configuration/support/exportOrderLineStatus"}Wenn aktiv, werden die Status auf Bestellpositionsebene exportiert.{/s}'
                        },
                        {
                            xtype:       'checkbox',
                            name:        'orderStatusExportUsesPickware',
                            fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/orderStatusExportUsesPickware"}Orderstatus-Export verwendet Pickware{/s}',
                            inputValue:  true,
                                supportText: '{s name="BrickfoxUi/view/configuration/support/orderStatusExportUsesPickware"}Wenn aktiv kommen retournierte Menge und stornierte Menge von Pickware.{/s}'
                        },
                        {
                            xtype:      'textfield',
                            name:       'customerOrderNumberAttributesField',
                            fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/customerOrderNumberAttributesField"}Attributefeld für Kundennummer{/s}'
                        },
                        {
                            xtype     : 'textfield',
                            name      : 'orderAttributesFieldReturnTrackingId',
                            fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/orderAttributesFieldReturnTrackingId"}Bestellung-Attribut-Feld für Return-Tracking-ID{/s}'
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '{s name="Brickfox/view/configuration/textfield/orderCarrierColumnNameMain"}Bestellung Feld für Versanddienstleister (Bestellung){/s}',
                            name:       'orderCarrierColumnNameMain',
                            supportText: '{s name="BrickfoxUi/view/configuration/support/orderCarrierColumnNameMain"}"s_order_attributes" Tabelle{/s}'
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '{s name="Brickfox/view/configuration/textfield/orderTrackingIdColumnNameMain"}Bestellung Feld für Tracking-ID (Bestellung){/s}',
                            name:       'orderTrackingIdColumnNameMain',
                            supportText: '{s name="BrickfoxUi/view/configuration/support/orderTrackingIdColumnNameMain"}"s_order_attributes" Tabelle{/s}'
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '{s name="Brickfox/view/configuration/textfield/orderCarrierColumnName"}Bestellung Feld für Versanddienstleister (Bestell-Position){/s}',
                            name:       'orderCarrierColumnName',
                            supportText: '{s name="BrickfoxUi/view/configuration/support/orderCarrierColumnName"}"s_order_details_attributes" Tabelle{/s}'
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '{s name="Brickfox/view/configuration/textfield/orderTrackingIdColumnName"}Bestellung Feld für Tracking-ID (Bestell-Position){/s}',
                            name:       'orderTrackingIdColumnName',
                            supportText: '{s name="BrickfoxUi/view/configuration/support/orderTrackingIdColumnName"}"s_order_details_attributes" Tabelle{/s}'
                        },
                        {
                            xtype: 'checkbox',
                            name:       'enableOrderImportWithItemNumber',
                            fieldLabel: '{s name="Brickfox/view/configuration/checkbox/enableOrderImportWithItemNumber"}Order Import über Artikelnummer{/s}',
                            inputValue: true,
                            supportText: '{s name="BrickfoxUi/view/configuration/support/enableOrderImportWithItemNumber"}Wenn aktiv, wird versucht den Shopware-Artikel einer Bestellposition anhand der Artikelnummer der Bestellposition zu laden.{/s}'
                        },
                        {
                            xtype:        'combobox',
                            fieldLabel:   '{s name="Brickfox/view/configuration/combobox/invoiceDocumentType"}Shopware Dokumententyp für Rechnungen{/s}',
                            name:         'invoiceDocumentType',
                            multiSelect:  false,
                            valueField:   'documentTypeId',
                            displayField: 'documentTypeDescription',
                            store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.InvoiceDocumentTypesMultiSelect').load(),
                            queryMode:    'local',
                            id:           'invoiceDocumentTypeSelectBox',
                            supportText:  'Bestimmen Sie den Shopware Dokumententyp, welcher für Rechnungen genutzt werden soll.'
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '{s name="Brickfox/view/configuration/textfield/invoiceFolderPath"}Präfix für Rechnungspfad vom FTP-Root{/s}',
                            name:       'invoiceFolderPath',
                            supportText:  'Konfigurieren Sie den Pfad vom FTP Zugang für Brickfox zum Stammverzeichnis der Shopware Installation.'
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '{s name="Brickfox/view/configuration/textfield/isbnFromAttribute"}ISBN aus Attribut{/s}',
                            name:       'isbnFromAttribute',
                        },
                        {
                            xtype: 'checkbox',
                            name:       'skipArticlesWithoutVariations',
                            fieldLabel: '{s name="Brickfox/view/configuration/checkbox/skipArticlesWithoutVariations"}Artikel ohne Varianten überspringen{/s}',
                            inputValue: true,
                            supportText: '{s name="BrickfoxUi/view/configuration/support/skipArticlesWithoutVariations"}Wenn aktiv, werden Artikel ohne eine Variante übersprungen.{/s}'
                        },
                        {
                            xtype: 'checkbox',
                            name:       'orderDisablePartnerImport',
                            fieldLabel: '{s name="Brickfox/view/configuration/checkbox/orderDisablePartnerImport"}Keinen Partner beim Bestell-Import anlegen{/s}',
                            inputValue: true,
                            supportText: '{s name="BrickfoxUi/view/configuration/support/orderDisablePartnerImport"}Wenn aktiv, wird beim Bestell-Import kein Partner ("Brickfox") angelegt.{/s}'
                        },
                        {
                            xtype: 'checkbox',
                            name:       'orderPartnerIdIncludeSalesChannelName',
                            fieldLabel: '{s name="Brickfox/view/configuration/checkbox/orderPartnerIdIncludeSalesChannelName"}Den Marktplatz der Bestellung an die Partner-ID anfügen{/s}',
                            inputValue: true,
                            supportText: '{s name="BrickfoxUi/view/configuration/support/orderPartnerIdIncludeSalesChannelName"}z.B. \'Brickfox-Amazon\'{/s}'
                        },
                        {
                            xtype:        'combobox',
                            fieldLabel:   '{s name="BrickfoxUi/view/configuration/textfield/importedOrderStatus"}Orderstatus nach Order Import{/s}',
                            name:         'importedOrderStatus',
                            multiSelect:  false,
                            valueField:   'stateId',
                            displayField: 'name',
                            store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.OrderState').load(),
                            queryMode:    'local',
                            id:           'importedOrderStatusSelectBox'
                        },
                        {
                            xtype:        'combobox',
                            fieldLabel:   '{s name="BrickfoxUi/view/configuration/textfield/orderStatusForOrdersWithComment"}Orderstatus bei Bestellungen mit Kommentar{/s}',
                            name:         'orderStatusForOrdersWithComment',
                            multiSelect:  false,
                            valueField:   'stateId',
                            displayField: 'name',
                            store:        Ext.create('Shopware.apps.BrickfoxUi.store.combo.OrderState').load(),
                            queryMode:    'local',
                            id:           'orderStatusForOrdersWithCommentSelectBox'
                        },
                        {
                            xtype: 'textareafield',
                            name:       'mappingActionToScriptTimeLimit',
                            fieldLabel: '{s name="Brickfox/view/configuration/textareafield/mappingActionToScriptTimeLimit"}Mapping von Skript zu Laufzeit (Sekunden){/s}',
                            supportText: '{s name="BrickfoxUi/view/configuration/support/mappingActionToScriptTimeLimit"}z.B. exportProducts=>7200;exportCategories=>3600{/s}'
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '{s name="Brickfox/view/configuration/displayField/customergroupTaxRate"}Kundengruppe für Steuerrate{/s}',
                            name: 'customergroupTaxRate',
                            supportText: 'Name der Kundengruppe welche für die Steuerrate verwendet werden soll, z.B. um die Standart-Steuerrate zu überschreiben.'
                        }
                    ]
                }
            ];

        items.push(me.buildFtpFields());

        return items;
    },

    buildFtpFields: function () {
        var me = this,
            items = [],
            subItems = [];

        if (me.getIsMultiShop() === false) {
            items = {
                xtype:    'fieldset',
                title:    'Shopware ist PIM Konfiguration',
                defaults: {
                    anchor:     '100%',
                    labelWidth: '33%'
                },
                id:       'swIsPimConfig',
                items:    [
                    {
                        xtype:       'textfield',
                        name:        'ftpOrdersPath',
                        fieldLabel:  '{s name="BrickfoxUi/view/configuration/textfield/OrderFtpPath"}Bestell-Verzeichnis{/s}',
                        allowBlank:  false,
                        supportText: '{s name="BrickfoxUi/view/configuation/supportText/ftpOrdersPath"}Pfad zum Ordner in dem die Bestellungen abgelegt werden.{/s}'
                    },
                    {
                        xtype:       'textfield',
                        name:        'ftpHost',
                        fieldLabel:  '{s name="BrickfoxUi/view/configuration/textfield/ftpServer"}FTP-Host{/s}',
                        allowBlank:  false,
                        supportText: '{s name="BrickfoxUi/view/configuation/supportText/ftpHost"}Tragen Sie hier den Host Ihres FTP ein.{/s}'
                    },
                    {
                        xtype:       'textfield',
                        name:        'ftpUser',
                        fieldLabel:  '{s name="BrickfoxUi/view/configuration/textfield/ftpUser"}FTP-User{/s}',
                        allowBlank:  false,
                        supportText: '{s name="BrickfoxUi/view/configuration/supportText/ftpUser"}Trange Sie hier den Username Ihres FTP ein.{/s}'
                    },
                    {
                        xtype:       'textfield',
                        inputType:   'password',
                        name:        'ftpPassword',
                        fieldLabel:  '{s name="BrickfoxUi/view/configuration/textfield/ftpPassword"}FTP-Passwort{/s}',
                        allowBlank:  false,
                        supportText: '{s name="BrickfoxUi/view/configuration/supportText/ftpPassword"}Trangen Sie hier das Passwort Ihres FTP ein.{/s}'
                    },
                    {
                        xtype:      'checkbox',
                        name:       'ftpSslActive',
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/checkbox/ftpSslActive"}SSL aktivieren{/s}',
                        inputValue: '1'
                    },
                    {
                        xtype:      'textfield',
                        name:       'ftpPort',
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/ftpPort"}FTP-Port{/s}',
                        allowBlank: false
                    }
                ]
            }
        } else {
            Ext.iterate(me.getMultiShopData().shops, function (object) {
                subItems.push(
                    {
                        title:      object.shopName,
                        xtype:      'form',
                        autoScroll: true,
                        cls:        'shopware-form',
                        layout:     'anchor',
                        border:     false,
                        items:      {
                            xtype:    'fieldset',
                            border:   0,
                            defaults: {
                                anchor:     '100%',
                                labelWidth: '33%'
                            },
                            id:       'swIsPimConfig_' + object.shopsId,
                            items:    [
                                {
                                    xtype:       'textfield',
                                    name:        'ftpOrdersPath_' + object.shopsId,
                                    fieldLabel:  '{s name="BrickfoxUi/view/configuration/textfield/OrderFtpPath"}Bestell-Verzeichnis{/s}',
                                    allowBlank:  false,
                                    supportText: '{s name="BrickfoxUi/view/configuation/supportText/ftpOrdersPath"}Pfad zum Ordner in dem die Bestellungen abgelegt werden.{/s}'
                                },
                                {
                                    xtype:       'textfield',
                                    name:        'ftpHost_' + object.shopsId,
                                    fieldLabel:  '{s name="BrickfoxUi/view/configuration/textfield/ftpServer"}FTP-Host{/s}',
                                    allowBlank:  false,
                                    supportText: '{s name="BrickfoxUi/view/configuation/supportText/ftpHost"}Tragen Sie hier den Host Ihres FTP ein.{/s}'
                                },
                                {
                                    xtype:       'textfield',
                                    name:        'ftpUser_' + object.shopsId,
                                    fieldLabel:  '{s name="BrickfoxUi/view/configuration/textfield/ftpUser"}FTP-User{/s}',
                                    allowBlank:  false,
                                    supportText: '{s name="BrickfoxUi/view/configuration/supportText/ftpUser"}Trange Sie hier den Username Ihres FTP ein.{/s}'
                                },
                                {
                                    xtype:       'textfield',
                                    inputType:   'password',
                                    name:        'ftpPassword_' + object.shopsId,
                                    fieldLabel:  '{s name="BrickfoxUi/view/configuration/textfield/ftpPassword"}FTP-Passwort{/s}',
                                    allowBlank:  false,
                                    supportText: '{s name="BrickfoxUi/view/configuration/supportText/ftpPassword"}Trangen Sie hier das Passwort Ihres FTP ein.{/s}'
                                },
                                {
                                    xtype:      'checkbox',
                                    name:       'ftpSslActive_' + object.shopsId,
                                    fieldLabel: '{s name="BrickfoxUi/view/configuration/checkbox/ftpSslActive"}SSL aktivieren{/s}',
                                    inputValue: '1'
                                },
                                {
                                    xtype:      'textfield',
                                    name:       'ftpPort_' + object.shopsId,
                                    fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/ftpPort"}FTP-Port{/s}',
                                    allowBlank: false
                                }
                            ]
                        }
                    }
                );
            });

            items = Ext.create('Ext.tab.Panel', {
                items: subItems
            });
        }

        return items;
    },

    buildToolbar: function () {
        var me = this;

        return Ext.create('Ext.toolbar.Toolbar', {
            cls:   'shopware-toolbar',
            dock:  'bottom',
            ui:    'shopware-ui',
            items: [
                '->',
                {
                    xtype:   'button',
                    text:    '{s name="BrickfoxUi/view/configuration/button/checkFtp"}FTP-Daten prüfen{/s}',
                    cls:     'secondary',
                    handler: function () {
                        me.fireEvent('checkFtp', me);
                    },
                    id:      'checkFtpBtn'
                },
                {
                    xtype:   'button',
                    text:    '{s name="BrickfoxUi/view/configuration/button/save"}Speichern{/s}',
                    cls:     'primary',
                    handler: function () {
                        me.fireEvent('save', me);
                    }
                }
            ]
        });
    },

    onCheckMultiShop: function () {
        var me = this;

        Ext.Ajax.request({
            method:  'POST',
            async:   false,
            url:     me.checkIsMultiShopUrl,
            success: function (res) {
                var response = Ext.JSON.decode(res.responseText);

                if (response.isMultiShop === true) {
                    me.isMultiShop = true;
                    me.multiShopData = response.multiShops;
                } else {
                    me.isMultiShop = false;
                }
            }
        });
    },

    getIsMultiShop: function () {
        var me = this;

        return me.isMultiShop;
    },

    getMultiShopData: function () {
        var me = this;

        return me.multiShopData;
    }
});
// {/block}
