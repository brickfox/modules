// {namespace name=backend/BrickfoxUi/view}
// {block name=backend/BrickfoxUi/view/Main}
Ext.define('Shopware.apps.BrickfoxUi.view.Main', {

    extend: 'Enlight.app.Window',

    alias: 'widget.BrickfoxUi-view-main',

    layout: 'fit',

    width: 950,

    height: '90%',

    autoShow: true,

    stateful: true,

    stateId: 'BrickfoxUi-view-main',

    title: '{s name="main/view/title"}Brickfox Connector{/s}',

    iconCls: 'bf_icon',

    initComponent: function () {
        var me = this;

        me.callParent(arguments);
    },

    createTabPanel: function () {
        var me = this;

        me.start = Ext.widget('BrickfoxUi-view-Overview', {
            overview: me.overview,
            main:     me
        });
        me.start.on('activate', me.start.init);

        me.configuration = Ext.widget('BrickfoxUi-view-Configuration', {
            configuration: me.configuration,
            main:          me
        });
        me.configuration.on('activate', me.configuration.init);

        me.attributesVariations = Ext.widget('BrickfoxUi-view-AttributesVariations', {
            attributesVariations: me.attributesVariations,
            main:                 me
        });
        me.attributesVariations.on('activate', me.attributesVariations.init);

        me.translation = Ext.widget('BrickfoxUi-view-TranslationMapping', {
            translation: me.translation,
            main:        me
        });
        me.translation.on('activate', me.translation.init);

        me.ordersToShops = Ext.widget('BrickfoxUi-view-OrdersToShopsMapping', {
            ordersToShops: me.ordersToShops,
            main: me
        });
        me.ordersToShops.on('activate', me.ordersToShops.init);

        me.ordersToCustomerGroups = Ext.widget('BrickfoxUi-view-OrdersToCustomerGroupsMapping', {
            ordersToCustomerGroups: me.ordersToCustomerGroups,
            main: me
        });
        me.ordersToCustomerGroups.on('activate', me.ordersToCustomerGroups.init);

        me.addressToFreetext = Ext.widget('BrickfoxUi-view-AddressToFreetextMapping', {
            addressToFreetext: me.addressToFreetext,
            main: me
        });
        me.addressToFreetext.on('activate', me.addressToFreetext.init);

        me.shippingAddressToFreetext = Ext.widget('BrickfoxUi-view-ShippingAddressToFreetextMapping', {
            shippingAddressToFreetext: me.shippingAddressToFreetext,
            main: me
        });
        me.shippingAddressToFreetext.on('activate', me.shippingAddressToFreetext.init);

        me.currencies = Ext.widget('BrickfoxUi-view-CurrenciesMapping', {
            currencies: me.currencies,
            main:       me
        });
        me.currencies.on('activate', me.currencies.init);

        me.shopwareCurrencies = Ext.widget('BrickfoxUi-view-ShopwareCurrenciesMapping', {
            shopwareCurrencies: me.shopwareCurrencies,
            main:               me
        });
        me.shopwareCurrencies.on('activate', me.shopwareCurrencies.init);

        me.payment = Ext.widget('BrickfoxUi-view-PaymentMapping', {
            payment: me.payment,
            main:    me
        });
        me.payment.on('activate', me.payment.init);

        me.multi = Ext.widget('BrickfoxUi-view-MultiShopExport', {
            multi: me.multi,
            main:  me
        });
        me.multi.on('activate', me.multi.init);

        me.orderStatus = Ext.widget('BrickfoxUi-view-OrderStatusMapping', {
            orderStatus: me.orderStatus,
            main:        me
        });
        me.orderStatus.on('activate', me.orderStatus.init);

        me.orderStatusDetail = Ext.widget('BrickfoxUi-view-OrderStatusMappingDetail', {
            orderStatusDetail: me.orderStatusDetail,
            main:        me
        });
        me.orderStatusDetail.on('activate', me.orderStatusDetail.init);

        me.addInfo = Ext.widget('BrickfoxUi-view-OrdersAddInfosMapping', {
            addInfo: me.addInfo,
            main:        me
        });
        me.addInfo.on('activate', me.addInfo.init);

        me.orderAttributes = Ext.widget('BrickfoxUi-view-OrdersAttributesMapping', {
            orderAttributes: me.orderAttributes,
            main: me
        });
        me.addInfo.on('activate', me.orderAttributes.init);

        me.taxRates = Ext.widget('BrickfoxUi-view-TaxRatesMapping', {
            taxRates: me.taxRates,
            main: me
        });
        me.taxRates.on('activate', me.taxRates.init);

        me.log = Ext.widget('BrickfoxUi-view-log', {
            log:  me.log,
            main: me
        });
        me.log.on('activate', me.log.init);

        me.tabpanel = Ext.create('Ext.tab.Panel', {
            items: [
                me.start,
                me.configuration,
                me.attributesVariations,
                me.translation,
                me.ordersToShops,
                me.ordersToCustomerGroups,
                me.addressToFreetext,
                me.shippingAddressToFreetext,
                me.currencies,
                me.shopwareCurrencies,
                me.payment,
                me.multi,
                me.orderStatus,
                me.orderStatusDetail,
                me.addInfo,
                me.orderAttributes,
                me.taxRates,
                me.log
            ]
        });

        me.add(me.tabpanel);
    }
});
// {/block}