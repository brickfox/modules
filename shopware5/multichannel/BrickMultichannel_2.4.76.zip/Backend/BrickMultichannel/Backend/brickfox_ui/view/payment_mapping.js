// {namespace name=backend/BrickfoxUi/view}
// {block name=backend/BrickfoxUi/view/PaymentMapping}
Ext.define('Shopware.apps.BrickfoxUi.view.PaymentMapping', {

    extend: 'Ext.grid.Panel',

    alias: 'widget.BrickfoxUi-view-PaymentMapping',

    title: '{s name="BrickfoxUi/view/payment/Mapping/title"}Payment-Mapping Shopware zu Brickfox{/s}',

    layout: 'border',

    autoScroll: true,

    border: false,

    store: Ext.create('Shopware.apps.BrickfoxUi.store.PaymentMapping'),

    comboStore: Ext.create('Shopware.apps.BrickfoxUi.store.combo.PaymentMapping'),

    selType: 'checkboxmodel',

    selModel: {
        mode: 'MULTI'
    },

    viewConfig: {
        stripeRows: true
    },

    isBuilt: false,

    init: function () {
        var me = this;

        if (me.isBuilt === true) {
            me.fireEvent('reloadMapping', me);
        }
    },

    initComponent: function () {
        var me = this;

        me.registerEvents();

        me.columns = me.buildColumns();
        me.plugins = me.buildEditingPlugin();
        me.tbar = me.buildToolbar();
        me.dockedItems = me.buildToolbarBottom();

        me.callParent(arguments);

        me.isBuilt = true;
    },

    registerEvents: function () {
        var me = this;

        me.addEvents('add', 'delete', 'save', 'reloadMapping');
    },

    buildEditingPlugin: function () {
        return Ext.create('Ext.grid.plugin.RowEditing', {
            clickToEdit: 2
        });
    },

    buildColumns: function () {
        var me = this;

        return [
            {
                header:    '{s name="BrickfoxUi/view/payment/Mapping/Column/Id"}Id{/s}',
                dataIndex: 'id',
                hidden:    true,
                width:     35
            },
            {
                header:    '{s name="BrickfoxUi/view/payment/Mapping/Column/Currency/Title"}Brickfox - Zahlart{/s}',
                dataIndex: 'brickfoxPaymentCode',
                flex:      1,
                editor:    {
                    xtype:      'textfield',
                    allowBlank: false
                }
            },
            {
                header:    '{s name="BrickfoxUi/view/payment/Mapping/Column/Currency/SwField"}Shopware - Zahlstatus{/s}',
                dataIndex: 'mappingFieldKey',
                flex:      1,
                editor:    {
                    xtype:        'combobox',
                    displayField: 'shopwareFieldKeyName',
                    valueField:   'shopwareFieldKeyCode',
                    allowBlank:   false,
                    queryMode:    'local',
                    store:        me.comboStore
                },
                renderer:  function (val) {
                    var index = me.comboStore.findExact('shopwareFieldKeyCode', val),
                        rs;

                    if (index != -1) {
                        rs = me.comboStore.getAt(index).data;
                        return rs.shopwareFieldKeyName;
                    }
                }
            }
        ];
    },

    buildToolbar: function () {
        var me = this,
            buttons = [];


        buttons.push(
            Ext.create('Ext.button.Button', {
                text:    '{s name="BrickfoxUi/view/customized/Mapping/Toolbar/Add/Title"}Hinzufügen{/s}',
                iconCls: 'sprite-plus-circle-frame',
                handler: function () {
                    me.fireEvent('add', me)
                }
            })
        );

        buttons.push(
            Ext.create('Ext.button.Button', {
                text:    '{s name="BrickfoxUi/view/customized/Mapping/Toolbar/Delete/Title"}Löschen{/s}',
                iconCls: 'sprite-minus-circle-frame',
                handler: function () {
                    me.fireEvent('delete', me);
                }
            })
        );

        buttons.push({
            xtype: 'tbfill'
        });

        buttons.push({
            xtype: 'tbspacer',
            width: 6
        });

        return Ext.create('Ext.toolbar.Toolbar', {
            ui:    'shopware-ui',
            items: buttons
        });
    },

    buildToolbarBottom: function () {
        var me = this;

        return Ext.create('Ext.toolbar.Toolbar', {
            cls:   'shopware-toolbar',
            dock:  'bottom',
            ui:    'shopware-ui',
            items: [
                Ext.create('Ext.PagingToolbar', {
                    store:       me.store,
                    displayInfo: true
                }),
                {
                    xtype: 'tbfill'
                },
                {
                    xtype: 'tbspacer',
                    width: 6
                },
                {
                    xtype:   'button',
                    text:    '{s name="BrickfoxUi/view/configuration/button/save"}Speichern{/s}',
                    cls:     'primary',
                    handler: function () {
                        me.fireEvent('saveAttribute', me);
                    }
                }
            ]
        });
    }
});
// {/block}