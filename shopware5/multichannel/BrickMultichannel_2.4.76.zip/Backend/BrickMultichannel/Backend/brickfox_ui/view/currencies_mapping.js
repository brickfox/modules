// {namespace name=backend/BrickfoxUi/view}
// {block name=backend/BrickfoxUi/view/CurrenciesMapping}
Ext.define('Shopware.apps.BrickfoxUi.view.CurrenciesMapping', {

    extend: 'Ext.grid.Panel',

    alias: 'widget.BrickfoxUi-view-CurrenciesMapping',

    title: '{s name="BrickfoxUi/view/currencies/Mapping/title"}Währungs Mapping Shopware zu Brickfox{/s}',

    layout: 'border',

    autoScroll: true,

    border: false,

    store: Ext.create('Shopware.apps.BrickfoxUi.store.CurrenciesMapping'),

    comboStore: Ext.create('Shopware.apps.BrickfoxUi.store.combo.CurrenciesMapping'),

    comboStore2: Ext.create('Shopware.apps.BrickfoxUi.store.combo.IsNetMapping'),

    comboStoreBf: Ext.create('Shopware.apps.BrickfoxUi.store.combo.CurrenciesMappingBrickfox'),

    selType: 'checkboxmodel',

    selModel: {
        mode: 'MULTI'
    },

    viewConfig: {
        stripeRows: true
    },

    isBuilt: false,

    validateListUrl: 'BrickfoxUi/getCurrenciesMappingList',

    listeners: {
        delay:        1, // time for render
        validateedit: function (editor, e) {
            this.fireEvent('validateUniqueReference', this, editor, e, this.validateListUrl, 'brickfoxCurrenciesCode');
        }
    },

    init: function () {
        var me = this;

        me.getView().setLoading(true);
        me.comboStoreBf.load({
            async:    false,
            callback: function () {
                if (me.isBuilt === true) {
                    me.fireEvent('reloadMapping', me);
                }
            }
        });

        me.comboStore2.load({
            async: false,
            callback: function () {
                me.getView().setLoading(false);
            }
        });
    },

    initComponent: function () {
        var me = this;

        me.registerEvents();

        me.columns = me.buildColumns();
        me.plugins = me.buildEditingPlugin();
        me.tbar = me.buildToolbar();
        me.dockedItems = me.buildToolbarBottom();

        me.callParent(arguments);

        me.isBuilt = true;
    },

    registerEvents: function () {
        var me = this;

        me.addEvents('add', 'delete', 'save', 'reloadMapping');
    },

    buildEditingPlugin: function () {
        return Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToEdit: 2
        });
    },

    buildColumns: function () {
        var me = this;

        return [
            {
                header:    '{s name="BrickfoxUi/view/currencies/Mapping/Column/Id"}Id{/s}',
                dataIndex: 'id',
                hidden:    true,
                width:     35
            },
            {
                header:    '{s name="BrickfoxUi/view/currencies/Mapping/Column/Currency/Title"}Brickfox - Currencies Code{/s}',
                dataIndex: 'brickfoxCurrenciesCode',
                flex:      1,
                editor:    {
                    xtype:        'combobox',
                    displayField: 'brickfoxFieldKeyName',
                    valueField:   'brickfoxFieldKeyCode',
                    allowBlank:   false,
                    queryMode:    'local',
                    store:        me.comboStoreBf
                },
                renderer:  function (val) {
                    var index = me.comboStoreBf.findExact('brickfoxFieldKeyCode', val),
                        rs,
                        result = '';

                    if (index != -1) {
                        rs = me.comboStoreBf.getAt(index).data;
                        result = rs.brickfoxFieldKeyName;
                    } else {
                        result = val;
                    }

                    return result;
                }
            },
            {
                header:    '{s name="BrickfoxUi/view/currencies/Mapping/Column/Currency/SwField"}Shopware - Customergroup Key{/s}',
                dataIndex: 'mappingFieldKey',
                flex:      1,
                editor:    {
                    xtype:        'combobox',
                    displayField: 'shopwareFieldKeyName',
                    valueField:   'shopwareFieldKeyCode',
                    allowBlank:   false,
                    queryMode:    'local',
                    store:        me.comboStore
                },
                renderer:  function (val) {
                    var index = me.comboStore.findExact('shopwareFieldKeyCode', val),
                        rs;

                    if (index != -1) {
                        rs = me.comboStore.getAt(index).data;
                        return rs.shopwareFieldKeyName;
                    }
                }
            },
            {
                header:    '{s name="BrickfoxUi/view/currencies/Mapping/Column/Currency/isNet"}Netto / Brutto{/s}',
                dataIndex: 'isNetFieldKey',
                flex:      1,
                editor:    {
                    xtype:        'combobox',
                    displayField: 'isNetFieldKeyName',
                    valueField:   'isNetFieldKeyCode',
                    allowBlank:   false,
                    queryMode:    'local',
                    store:        me.comboStore2
                },
                renderer:  function (val) {
                    var index = me.comboStore2.findExact('isNetFieldKeyCode', val),
                        rs;

                    if (index != -1) {
                        rs = me.comboStore2.getAt(index).data;
                        return rs.isNetFieldKeyName;
                    }
                }
            }
        ];
    },

    buildToolbar: function () {
        var me = this,
            buttons = [];


        buttons.push(
            Ext.create('Ext.button.Button', {
                text:    '{s name="BrickfoxUi/view/customized/Mapping/Toolbar/Add/Title"}Hinzufügen{/s}',
                iconCls: 'sprite-plus-circle-frame',
                handler: function () {
                    me.fireEvent('add', me)
                }
            })
        );

        buttons.push(
            Ext.create('Ext.button.Button', {
                text:    '{s name="BrickfoxUi/view/customized/Mapping/Toolbar/Delete/Title"}Löschen{/s}',
                iconCls: 'sprite-minus-circle-frame',
                handler: function () {
                    me.fireEvent('delete', me);
                }
            })
        );

        buttons.push({
            xtype: 'tbfill'
        });

        //buttons.push({
        //    xtype:             'textfield',
        //    name:              'searchfield',
        //    width:             170,
        //    cls:               'searchfield',
        //    enableKeyEvents:   true,
        //    checkChangeBuffer: 500,
        //    emptyText:         '{s name="BrickfoxUi/view/customized/Mapping/Toolbar/Search"}Suchen..{/s}',
        //    listeners:         {
        //        'change': function (field, value) {
        //            console.log(value);
        //            var store = me.store,
        //                searchString = Ext.String.trim(value);
        //
        //            //scroll the store to first page
        //            store.currentPage = 1;
        //
        //            //if the search-value is empty, reset the filter
        //            if (searchString.length === 0) {
        //                store.clearFilter();
        //            } else {
        //                //this won't reload the store
        //                store.filters.clear();
        //
        //                //loads the store with a special filter
        //                store.filter('search', searchString);
        //            }
        //        }
        //    }
        //});

        buttons.push({
            xtype: 'tbspacer',
            width: 6
        });

        return Ext.create('Ext.toolbar.Toolbar', {
            ui:    'shopware-ui',
            items: buttons
        });
    },

    buildToolbarBottom: function () {
        var me = this;

        return Ext.create('Ext.toolbar.Toolbar', {
            cls:   'shopware-toolbar',
            dock:  'bottom',
            ui:    'shopware-ui',
            items: [
                Ext.create('Ext.PagingToolbar', {
                    store:       me.store,
                    displayInfo: true
                }),
                {
                    xtype: 'tbfill'
                },
                {
                    xtype: 'tbspacer',
                    width: 6
                },
                {
                    xtype:   'button',
                    text:    '{s name="BrickfoxUi/view/configuration/button/save"}Speichern{/s}',
                    cls:     'primary',
                    handler: function () {
                        me.fireEvent('saveAttribute', me);
                    }
                }
            ]
        });
    }
});
// {/block}