// {namespace name=backend/BrickfoxUi/view}
// {block name=backend/BrickfoxUi/view/AttributesVariationsMapping}
Ext.define('Shopware.apps.BrickfoxUi.view.AttributesVariationsMapping', {
    extend: 'Ext.grid.Panel',

    alias: 'widget.BrickfoxUi-view-AttributesVariations',

    title: '{s name="BrickfoxUi/view/attributes/Variations/Mapping/title"}Attribut-Varianten Mapping Shopware zu Brickfox{/s}',

    layout: 'border',

    autoScroll: true,

    border: false,

    store: Ext.create('Shopware.apps.BrickfoxUi.store.AttributesVariationsMapping'),

    comboStore: Ext.create('Shopware.apps.BrickfoxUi.store.combo.AttributesVariationsMapping'),

    selType: 'checkboxmodel',

    selModel: {
        mode: 'MULTI'
    },

    viewConfig: {
        stripeRows: true
    },

    isBuilt: false,

    validateListUrl: '',

    listeners: {
        delay: 1 //time for render
        // validateedit: function (editor, e) {
        //     this.fireEvent('validateUniqueReference', this, editor, e, this.validateListUrl, 'brickfoxCurrenciesCode');
        // }
    },
    
    init: function () {
        var me = this;
        
        me.getView().setLoading(true);

        me.comboStore.load({
            async:    false,
            callback: function () {
                if (me.isBuilt === true) {
                    me.fireEvent('reloadMapping', me);
                }
                me.getView().setLoading(false);
            }
        });
        
        me.getView().setLoading(false);
    },
    
    initComponent: function () {
        var me = this;

        me.registerEvents();

        me.columns = me.buildColumns();
        me.plugins = me.buildEditingPlugin();
        me.tbar = me.buildToolbar();
        me.dockedItems = me.buildToolbarBottom();

        me.callParent(arguments);

        me.isBuilt = true;
    },

    registerEvents: function () {
        var me = this;

        me.addEvents('add', 'delete', 'save', 'reloadMapping');
    },

    buildEditingPlugin: function () {
        return Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToEdit: 2
        });
    },
    
    buildColumns: function () {
        var me = this;

        return [
            {
                header:    '{s name="BrickfoxUi/view/attributes/Variations/Mapping/Column/Id"}Id{/s}',
                dataIndex: 'id',
                hidden:    true,
                width:     35
            },
            {
                header:    '{s name="BrickfoxUi/view/attributes/Variations/Mapping/Column/BfAttrCode/Title"}Shopware Attribut - Code{/s}',
                dataIndex: 'attributesVariationsCode',
                flex:      1,
                editor:    {
                    xtype:        'combobox',
                    displayField: 'shopwareAttributesCode',
                    valueField:   'shopwareAttributesCode',
                    allowBlank:   false,
                    queryMode:    'local',
                    listConfig:   {
                        loadingText: 'Searching...',
                        emptyText:   'No matching posts found.',
                    },
                    pageSize:     10,
                    store:        me.comboStore
                },
                renderer:  function (val) {
                    var index = me.comboStore.findExact('shopwareAttributesCode', val),
                        rs,
                        result = '';

                    if (index != -1) {
                        rs = me.comboStore.getAt(index).data;

                        result = rs.shopwareAttributesCode;
                    } else {
                        result = val;
                    }

                    return result;
                }
            }
        ];
    },

    buildToolbar: function () {
        var me = this,
            buttons = [];


        buttons.push(
            Ext.create('Ext.button.Button', {
                text:    '{s name="BrickfoxUi/view/attributes/Mapping/Toolbar/Add/Title"}Hinzufügen{/s}',
                iconCls: 'sprite-plus-circle-frame',
                handler: function () {
                    me.fireEvent('add', me)
                }
            })
        );

        buttons.push(
            Ext.create('Ext.button.Button', {
                text:    '{s name="BrickfoxUi/view/attributes/Mapping/Toolbar/Delete/Title"}Löschen{/s}',
                iconCls: 'sprite-minus-circle-frame',
                handler: function () {
                    me.fireEvent('delete', me);
                }
            })
        );

        buttons.push({
            xtype: 'tbfill'
        });

        buttons.push({
            xtype:             'textfield',
            name:              'searchfield',
            width:             170,
            cls:               'searchfield',
            enableKeyEvents:   true,
            checkChangeBuffer: 500,
            emptyText:         '{s name="BrickfoxUi/view/attribute/Mapping/Toolbar/Search"}Suchen..{/s}',
            listeners:         {
                'change': function (field, value) {
                    var store = me.store,
                        searchString = Ext.String.trim(value);

                    //scroll the store to first page
                    store.currentPage = 1;

                    //if the search-value is empty, reset the filter
                    if (searchString.length === 0) {
                        store.clearFilter();
                    } else {
                        //this won't reload the store
                        store.filters.clear();

                        //loads the store with a special filter
                        store.filter('search', searchString);
                    }
                }
            }
        });

        buttons.push({
            xtype: 'tbspacer',
            width: 6
        });

        return Ext.create('Ext.toolbar.Toolbar', {
            ui:    'shopware-ui',
            items: buttons
        });
    },

    buildToolbarBottom: function () {
        var me = this;

        return Ext.create('Ext.toolbar.Toolbar', {
            cls:   'shopware-toolbar',
            dock:  'bottom',
            ui:    'shopware-ui',
            items: [
                Ext.create('Ext.PagingToolbar', {
                    store:       me.store,
                    displayInfo: true
                }),
                {
                    xtype: 'tbfill'
                },
                {
                    xtype: 'tbspacer',
                    width: 6
                },
                {
                    xtype:   'button',
                    text:    '{s name="BrickfoxUi/view/configuration/button/save"}Speichern{/s}',
                    cls:     'primary',
                    handler: function () {
                        me.fireEvent('saveAttribute', me);
                    }
                }
            ]
        });
    }
});
// {/block}