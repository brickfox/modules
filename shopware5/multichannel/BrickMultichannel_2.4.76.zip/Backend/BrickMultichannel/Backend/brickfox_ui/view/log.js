// {namespace name=backend/BrickfoxUi/view}
// {block name=backend/BrickfoxUi/view/Log}
Ext.define('Shopware.apps.BrickfoxUi.view.Log', {

    extend: 'Ext.tab.Panel',

    alias: 'widget.BrickfoxUi-view-log',

    title: '{s name="BrickfoxUi/view/Log/Title"}Logs{/s}',

    defaults: {
        listeners: {
            activate: function (tab, eOpts) {
                tab.init();
            }
        }
    },

    init: function () {

    },

    initComponent: function () {
        var me = this;

        me.activeTab = 0;

        me.items = me.buildItems();

        me.callParent(arguments);
    },

    buildItems: function () {
        return [
            {
                title: '{s name="BrickfoxUi/view/Log/Gui/Title"}Logs Gui{/s}',
                xtype: 'BrickfoxUi-view-LogGui',
                id:    'configurationLog'
            }
        ];
    }
});
// {/block}