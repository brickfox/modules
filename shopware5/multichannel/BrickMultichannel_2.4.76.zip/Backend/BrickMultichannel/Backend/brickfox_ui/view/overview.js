// {namespace name=backend/BrickfoxUi/view}
// {block name=backend/BrickfoxUi/view/overview}
Ext.define('Shopware.apps.BrickfoxUi.view.Overview', {

    extend: 'Ext.form.Panel',

    alias: 'widget.BrickfoxUi-view-Overview',

    title: '{s name="BrickfoxUi/view/start/title"}Übersicht{/s}',

    autoScroll: true,

    cls: 'shopware-form',

    layout: 'anchor',

    border: false,

    store: Ext.create('Shopware.apps.BrickfoxUi.store.Overview'),

    isBuilt: false,

    default: {
        anchor:     '100%',
        margin:     10,
        labelWidth: '33%'
    },

    init: function () {
        var me = this;

        if (me.isBuilt === false) {
            me.buildItems();

            me.store.load({
                callback: function (records) {
                    me.loadRecord(records[0]);
                }
            });
        } else {
            me.fireEvent('check', me);
        }
    },

    initComponent: function () {
        var me = this;

        me.registerEvents();
        me.callParent(arguments);
    },

    registerEvents: function () {
        var me = this;

        me.addEvents('check');
    },

    buildItems: function () {
        var me = this;

        me.add([
            {
                xtype:    'fieldset',
                title:    'Server - Konfiguration',
                defaults: {
                    anchor:     '100%',
                    labelWidth: '33%',
                    xtype:      'displayfield'
                },
                items:    [
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/overview/displayField/PhpVersion"}PHP-Version{/s}',
                        name:       'phpVersion'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/overview/displayField/MemoryLimit"}Memory-Limit{/s}',
                        name:       'phpMemoryLimit'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/overview/displayField/MaxExecutionTime"}Script-Laufzeit{/s}',
                        name:       'phpMaxExecutionTime'
                    }
                ]
            },
            {
                xtype:    'fieldset',
                title:    'Gespeicherte Plugin - Konfiguration',
                defaults: {
                    anchor:     '100%',
                    labelWidth: '33%',
                    xtype:      'displayfield'
                },
                items:    [
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/overview/displayField/pluginMode"}Modus{/s}',
                        value:      'Shopware ist PIM'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/overview/displayField/proFtpActive"}Pro-FTP{/s}',
                        name:       'proFtpActive'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUio/view/overview/displayField/masterShopsName"}Master - Shop{/s}',
                        name:       'masterShopName'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/brickfoxCustomerUrl"}Brickfox - Mandanten URL{/s}',
                        name:       'brickfoxCustomerUrl'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/brickfoxApiKey"}Brickfox REST API - KEY{/s}',
                        name:       'brickfoxApiKey'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUio/view/overview/displayField/incomingPath"}Pfad für eingehende XML Dateien{/s}',
                        name:       'incomingPath'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUio/view/overview/displayField/outgoingPath"}Pfad für ausgehende XML Dateien{/s}',
                        name:       'outgoingPath'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/overview/displayField/logging"}Logging aktiv{/s}',
                        name:       'logging'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/overview/displayField/logPath"}Pfad für Logfiles{/s}',
                        name:       'logPath'
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/overview/displayField/scriptLogger"}Zurücksetzen des Script-Logger{/s}',
                        name:       'scriptLogger'
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/overview/displayField/httpsProtocol"}Server-Protokoll https{/s}',
                        name:       'serverProtocol'
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/overview/displayField/isIncreaseInnoDBLockWaitTimeoutEnabled"}Increase InnoDBLockWaitTimeout{/s}',
                        name:       'isIncreaseInnoDBLockWaitTimeoutEnabled'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/combobox/specialAndRrpPricesToBrickfox"}Shopware Pseudopreis - Übertragung{/s}',
                        name:       'rrpSpecialPrice'
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuation/combobox/useExternOrdersNumberAsShopwareOrdersNumber"}BF-Externe Bestellnummer verwenden{/s}',
                        name:       'useExternOrdersNumberAsShopwareOrdersNumber'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/disabledCategories"}Nicht zu exprtierende Kategorie{/s}',
                        name:       'disabledCategories'
                    },                    {
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/importedOrderStatus"}Orderstatus nach Order Import{/s}',
                        name:       'importedOrderStatus'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/orderStatusForOrdersWithComment"}Orderstatus bei Bestellungen mit Kommentar{/s}',
                        name:       'orderStatusForOrdersWithComment'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/defaultCustomerGroup"}Neu-Kunden Kundengruppe{/s}',
                        name:       'defaultCustomerGroup'
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/checkbox/baseProductExportPreviewImageAlways"}Vorschaubild auf Stammartikel-Ebene exportieren{/s}',
                        name:       'baseProductExportPreviewImageAlways',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/checkbox/usePickwareCompability"}Kompatibilität für Pickware "Stücklisten / Sets"{/s}',
                        name:       'usePickwareCompability',
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/imageAttributeKeys"}Keywords - Bildattribute{/s}',
                        name:       'imageAttributesKeyWords'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/productsExportAttributes"}Produkte mit Attribut exportieren{/s}',
                        name:       'productsExportAttributes',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/combobox/AttributesAsBulletsExport"}Attribute/Eigenschaften als Bulletpoints{/s}',
                        name:       'attributesMultiSelectId'
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/combobox/BulletsAsAttributesExport"}Attribute als Bulletpoints-Attribute{/s}',
                        name:       'bulletsAsAttributesMultiSelectId'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/checkbox/multiShopExport"}Multishops - Exportieren{/s}',
                        name:       'multiShopExport'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/checkbox/multiLanguagesExport"}Übersetzungen - Exportieren{/s}',
                        name:       'multiLanguagesExport'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/checkbox/exportMultivaluedPropertiesAsSingleAttributes"}Mehrfache Eigenschaften als Mehrfachattribute getrennt exportieren{/s}',
                        name:       'exportMultivaluedPropertiesAsSingleAttributes'
                    },
                    {
                        fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/orderAttributes"}Plattform-Bestellnummer in Attributfeld{/s}',
                        name: 'orderAttributes'
                    },
                    {
                        fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/enableShopsNameToComment"}Marktplatzname in Kommentarfeld speichern{/s}',
                        name: 'enableShopsNameToComment'
                    },
                    {
                        fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/enableShopsOrderIdToComment"}Plattform-Bestellnummer in Kommentarfeld speichern{/s}',
                        name: 'enableShopsOrderIdToComment'
                    },
                    {
                        fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/enableShopsCustomerIdToComment"}Plattform-Kundennummer in Kommentarfeld speichern{/s}',
                        name:        'enableShopsCustomerIdToComment'
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/combobox/shopsInformationCommentField"}Shopware Kommentarfeld für Marktplatzname, Plattform-Bestellnummer, Plattform-Kundennummer{/s}',
                        name: 'shopsInformationCommentField'
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/combobox/saveOrderNumberInCommentField"}Interne B2B-Händler Bestellnummer in Kommentarfeld speichern{/s}',
                        name: 'orderNumberInCommentField'
                    },
                    {
                        name: 'ordersLinesIdAttributesField',
                        fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/ordersLinesIdAttributesField"}brickfox Bestellpositions-Nummer in Attributfeld{/s}'
                    },
                    {
                        name: 'exportOrderLineStatus',
                        fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/exportOrderLineStatus"}Status auf Bestellpositionsebene exportieren{/s}'
                    },
                    {
                        name: 'orderStatusExportUsesPickware',
                        fieldLabel:  '{s name="BrickfoxUi/view/configuration/checkbox/orderStatusExportUsesPickware"}Orderstatus-Export verwendet Pickware{/s}'
                    },
                    {
                        name: 'customerOrderNumberAttributesField',
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/customerOrderNumberAttributesField"}Attributefeld für Kundennummer{/s}'
                    },
                    {
                        name: 'orderAttributesFieldReturnTrackingId',
                        fieldLabel: '{s name="BrickfoxUi/view/configuration/textfield/orderAttributesFieldReturnTrackingId"}Bestellung-Attribut-Feld für Return-Tracking-ID{/s}'
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/checkbox/orderCarrierColumnName"}Bestellung Feld für Versanddienstleister{/s}',
                        name:       'orderCarrierColumnName',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/checkbox/orderTrackingIdColumnName"}Bestellung Feld für Tracking-Id{/s}',
                        name:       'orderTrackingIdColumnName',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/checkbox/enableOrderImportWithItemNumber"}Order Import über Artikelnummer{/s}',
                        name:       'enableOrderImportWithItemNumber',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/textfield/cleanBfScriptloggerAfterDays"}Scriptlogger-Daten nach X-Tage(n) bereinigen{/s}',
                        name:       'cleanBfScriptloggerAfterDays',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/combobox/invoiceDocumentType"}Shopware Dokumententyp für Rechnungen{/s}',
                        name:       'invoiceDocumentType',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/textfield/invoiceFolderPath"}Präfix für Rechnungspfad vom FTP-Root{/s}',
                        name:       'invoiceFolderPath',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/textfield/isbnFromAttribute"}ISBN aus Attribut{/s}',
                        name:       'isbnFromAttribute',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/checkbox/skipArticlesWithoutVariations"}Artikel ohne Varianten überspringen{/s}',
                        name:       'skipArticlesWithoutVariations',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/checkbox/orderDisablePartnerImport"}Keinen Partner beim Bestell-Import anlegen{/s}',
                        name:       'orderDisablePartnerImport',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/checkbox/orderPartnerIdIncludeSalesChannelName"}Den Marktplatz der Bestellung an die Partner-ID anfügen{/s}',
                        name:       'orderPartnerIdIncludeSalesChannelName',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/textareafield/mappingActionToScriptTimeLimit"}Mapping von Skript zu Laufzeit (Sekunden){/s}',
                        name:       'mappingActionToScriptTimeLimit',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/displayField/customergrouTaxRate"}Kundengruppe für Steuerrate{/s}',
                        name:       'customergroupTaxRate',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/displayField/orderCarrierColumnNameMain"}Feld für Versanddienstleister (Bestellung){/s}',
                        name:       'orderCarrierColumnNameMain',
                    },
                    {
                        fieldLabel: '{s name="Brickfox/view/configuration/displayField/orderTrackingIdColumnNameMain"}Feld für Tracking-ID (Bestellung){/s}',
                        name:       'orderTrackingIdColumnNameMain',
                    }
                ]
            },
            {
                xtype:    'fieldset',
                title:    'Letzte Importe',
                defaults: {
                    anchor:     '100%',
                    labelWidth: '33%',
                    xtype:      'displayfield'
                },
                items:    [
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/overview/displayField/lastOrderStatusImport"}Letzter Bestell-Import{/s}',
                        name:       'lastOrderImport'
                    }
                ]
            },
            {
                xtype:    'fieldset',
                title:    'Letzte Exporte',
                defaults: {
                    anchor:     '100%',
                    labelWidth: '33%',
                    xtype:      'displayfield'
                },
                items:    [
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/overview/displayField/lastProductsExport"}Letzter Produkt-Export{/s}',
                        name:       'lastProductsExport'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/overview/displayField/lastCategoriesExport"}Letzter Kategorie-Export{/s}',
                        name:       'lastCategoriesExport'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/overview/displayField/lastSuppliersExport"}Letzter Hersteller-Export{/s}',
                        name:       'lastSuppliersExport'
                    },
                    {
                        fieldLabel: '{s name="BrickfoxUi/view/overview/displayField/lastOrderStatusExport"}Letzter Bestellstatus-Export{/s}',
                        name:       'lastOrderStatusExport'
                    }
                ]
            },
            {
                xtype:    'fieldset',
                title:    'Produkt Exporte Tabelle leeren',
                defaults: {
                    anchor:     '25%',
                    labelWidth: '33%',
                    xtype:      'displayfield'
                },
                items:    [
                    {
                        xtype:   'button',
                        text:    '{s name="BrickfoxUi/view/overview/button/removeProductExports"}Ausführen{/s}',
                        cls:     'primary',
                        handler: function () {
                            me.fireEvent('removeProductExports', me);
                        },
                        id:      'removeProductExportsBtn'
                    },
                ]
            }
        ]);
        me.isBuilt = true;
    }
});
// {/block}
