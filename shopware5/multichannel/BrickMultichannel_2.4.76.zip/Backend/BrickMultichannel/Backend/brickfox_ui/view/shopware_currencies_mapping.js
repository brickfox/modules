// {namespace name=backend/BrickfoxUi/view}
// {block name=backend/BrickfoxUi/view/ShopwareCurrenciesMapping}
Ext.define('Shopware.apps.BrickfoxUi.view.ShopwareCurrenciesMapping', {

    extend: 'Ext.grid.Panel',

    alias: 'widget.BrickfoxUi-view-ShopwareCurrenciesMapping',

    title: '{s name="BrickfoxUi/view/currenciesShopware/Mapping/title"}Währungs Mapping Bestell-Import Brickfox zu Shopware{/s}',

    layout: 'border',

    autoScroll: true,

    border: false,

    store: Ext.create('Shopware.apps.BrickfoxUi.store.ShopwareCurrenciesMapping'),

    comboStore: Ext.create('Shopware.apps.BrickfoxUi.store.combo.ShopwareCurrenciesMapping'),

    comboStoreBf: Ext.create('Shopware.apps.BrickfoxUi.store.combo.ShopwareCurrenciesMappingBrickfox'),

    selType: 'checkboxmodel',

    selModel: {
        mode: 'MULTI'
    },

    viewConfig: {
        stripeRows: true
    },

    isBuilt: false,

    validateListUrl: 'BrickfoxUi/getShopwareCurrenciesMappingList',

    listeners: {
        delay:        1, // time for render
    },

    init: function () {
        var me = this;

        me.getView().setLoading(true);
        me.comboStoreBf.load({
            async:    false,
            callback: function () {
                if (me.isBuilt === true) {
                    me.fireEvent('reloadMapping', me);
                }
                me.getView().setLoading(false);
            }
        });
    },

    initComponent: function () {
        var me = this;

        me.registerEvents();

        me.columns = me.buildColumns();
        me.plugins = me.buildEditingPlugin();
        me.tbar = me.buildToolbar();
        me.dockedItems = me.buildToolbarBottom();

        me.callParent(arguments);

        me.isBuilt = true;
    },

    registerEvents: function () {
        var me = this;

        me.addEvents('add', 'delete', 'save', 'reloadMapping');
    },

    buildEditingPlugin: function () {
        return Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToEdit: 2
        });
    },

    buildColumns: function () {
        var me = this;

        return [
            {
                header:    '{s name="BrickfoxUi/view/currencies/Mapping/Column/Id"}Id{/s}',
                dataIndex: 'id',
                hidden:    true,
                width:     35
            },
            {
                header:    '{s name="BrickfoxUi/view/currencies/Mapping/Column/Currency/Title"}Brickfox - Currencies Code{/s}',
                dataIndex: 'brickfoxCurrenciesCode',
                flex:      1,
                editor:    {
                    xtype:        'combobox',
                    displayField: 'brickfoxFieldKeyName',
                    valueField:   'brickfoxFieldKeyCode',
                    allowBlank:   false,
                    queryMode:    'local',
                    store:        me.comboStoreBf
                },
                renderer:  function (val) {
                    var index = me.comboStoreBf.findExact('brickfoxFieldKeyCode', val),
                        rs,
                        result = '';

                    if (index != -1) {
                        rs = me.comboStoreBf.getAt(index).data;
                        result = rs.brickfoxFieldKeyName;
                    } else {
                        result = val;
                    }

                    return result;
                }
            },
            {
                header:    '{s name="BrickfoxUi/view/currencies/Mapping/Column/Currency/SwCodeField"}Shopware - Currencies Code{/s}',
                dataIndex: 'mappingFieldKey',
                flex:      1,
                editor:    {
                    xtype:        'combobox',
                    displayField: 'shopwareFieldKeyName',
                    valueField:   'shopwareFieldKeyCode',
                    allowBlank:   false,
                    queryMode:    'local',
                    store:        me.comboStore
                },
                renderer:  function (val) {
                    var index = me.comboStore.findExact('shopwareFieldKeyCode', val),
                        rs;

                    if (index != -1) {
                        rs = me.comboStore.getAt(index).data;
                        return rs.shopwareFieldKeyName;
                    }
                }
            },
        ];
    },

    buildToolbar: function () {
        var me = this,
            buttons = [];


        buttons.push(
            Ext.create('Ext.button.Button', {
                text:    '{s name="BrickfoxUi/view/customized/Mapping/Toolbar/Add/Title"}Hinzufügen{/s}',
                iconCls: 'sprite-plus-circle-frame',
                handler: function () {
                    me.fireEvent('add', me)
                }
            })
        );

        buttons.push(
            Ext.create('Ext.button.Button', {
                text:    '{s name="BrickfoxUi/view/customized/Mapping/Toolbar/Delete/Title"}Löschen{/s}',
                iconCls: 'sprite-minus-circle-frame',
                handler: function () {
                    me.fireEvent('delete', me);
                }
            })
        );

        buttons.push({
            xtype: 'tbfill'
        });

        buttons.push({
            xtype: 'tbspacer',
            width: 6
        });

        return Ext.create('Ext.toolbar.Toolbar', {
            ui:    'shopware-ui',
            items: buttons
        });
    },

    buildToolbarBottom: function () {
        var me = this;

        return Ext.create('Ext.toolbar.Toolbar', {
            cls:   'shopware-toolbar',
            dock:  'bottom',
            ui:    'shopware-ui',
            items: [
                Ext.create('Ext.PagingToolbar', {
                    store:       me.store,
                    displayInfo: true
                }),
                {
                    xtype: 'tbfill'
                },
                {
                    xtype: 'tbspacer',
                    width: 6
                },
                {
                    xtype:   'button',
                    text:    '{s name="BrickfoxUi/view/configuration/button/save"}Speichern{/s}',
                    cls:     'primary',
                    handler: function () {
                        me.fireEvent('saveAttribute', me);
                    }
                }
            ]
        });
    }
});
// {/block}