// {namespace name=backend/BrickfoxUi/view}
// {block name=backend/BrickfoxUi/view/LogGui}
Ext.define('Shopware.apps.BrickfoxUi.view.LogGui', {

    extend: 'Ext.grid.Panel',

    alias: 'widget.BrickfoxUi-view-LogGui',

    title: '{s name="BrickfoxUi/view/Log/Gui/Title"}Logs Konfigurationen{/s}',

    layout: 'border',

    autoScroll: true,

    border: false,

    selType: 'checkboxmodel',

    selModel: {
        mode: 'MULTI'
    },

    viewConfig: {
        stripeRows:  false,
        getRowClass: function (record) {
            var returnVal = null;

            switch (record.get('type')) {
            case 'SUCCESS':
                returnVal = 'success-row';
                break;
            case 'ERROR':
                returnVal = 'error-row';
                break;
            case 'Fatal Error':
                returnVal = 'fatal-error-row';
                break;
            case 'Warning':
                returnVal = 'warning-row';
                break;
            default:
                break;
            }

            return returnVal;
        }
    },

    isBuilt: false,

    init: function () {
        var me = this;

        if (me.isBuilt === true) {
            me.store.load();
        }
    },

    initComponent: function () {
        var me = this;

        me.registerEvents();

        me.store = Ext.create('Shopware.apps.BrickfoxUi.store.LogGui').load();
        me.columns = me.buildColumns();
        me.tbar = me.buildToolbar();
        me.dockedItems = me.buildToolbarBottom();

        me.callParent(arguments);

        me.isBuilt = true;
    },

    registerEvents: function () {
        var me = this;

        me.addEvents('reloadLog', 'delete');
    },

    buildColumns: function () {
        return [
            {
                header:    '{s name="BrickfoxUi/view/Log/Gui/Column/Id"}Id{/s}',
                dataIndex: 'id',
                hidden:    true,
                width:     25
            },
            {
                header:    '{s name="BrickfoxUi/view/Log/Gui/Column/ExportType"}type{/s}',
                dataIndex: 'type',
                flex:      1
            },
            {
                header:    '{s name="BrickfoxUi/view/Log/Gui/Column/ErrorCode"}Fehler-Code{/s}',
                dataIndex: 'errorCode',
                flex:      1
            },
            {
                header:    '{s name="BrickfoxUi/view/Log/Gui/Column/Message"}Meldung{/s}',
                dataIndex: 'message',
            },
            {
                xtype:     'datecolumn',
                header:    '{s name="BrickfoxUi/view/Log/Gui/Column/lastUpdate"}Letzte Aktualisierung{/s}',
                dataIndex: 'lastUpdate',
                flex:      1,
                format:    'Y-m-d H:i:s'
            },
            {
                header:    '{s name="BrickfoxUi/view/Log/Gui/Column/lastUpdater"}Benutzer{/s}',
                dataIndex: 'lastUpdater',
                flex:      1
            }
        ];
    },

    buildToolbar: function () {
        var me = this,
            buttons = [];

        buttons.push(
            Ext.create('Ext.button.Button', {
                text:    '{s name="BrickfoxUi/view/attributes/Mapping/Toolbar/Delete/Title"}Löschen{/s}',
                iconCls: 'sprite-minus-circle-frame',
                handler: function () {
                    me.fireEvent('delete', me);
                }
            })
        );

        buttons.push({
            xtype: 'tbfill'
        });

        buttons.push({
            xtype:             'textfield',
            name:              'searchfield',
            width:             170,
            cls:               'searchfield',
            enableKeyEvents:   true,
            checkChangeBuffer: 500,
            emptyText:         '{s name="BrickfoxUi/view/attribute/Mapping/Toolbar/Search"}Suchen..{/s}',
            listeners:         {
                'change': function (field, value) {
                    console.log(value);
                    var store = me.store,
                        searchString = Ext.String.trim(value);

                    //scroll the store to first page
                    store.currentPage = 1;

                    //if the search-value is empty, reset the filter
                    if (searchString.length === 0) {
                        store.clearFilter();
                    } else {
                        //this won't reload the store
                        store.filters.clear();

                        //loads the store with a special filter
                        store.filter('search', searchString);
                    }
                }
            }
        });

        buttons.push({
            xtype: 'tbspacer',
            width: 6
        });

        return Ext.create('Ext.toolbar.Toolbar', {
            ui:    'shopware-ui',
            items: buttons
        });
    },

    buildToolbarBottom: function () {
        var me = this;

        return Ext.create('Ext.toolbar.Toolbar', {
            cls:   'shopware-toolbar',
            dock:  'bottom',
            ui:    'shopware-ui',
            items: [
                Ext.create('Ext.PagingToolbar', {
                    store:       me.store,
                    displayInfo: true
                }),
                {
                    xtype: 'tbfill'
                },
                {
                    xtype: 'tbspacer',
                    width: 6
                }
            ]
        });
    }
});
// {/block}