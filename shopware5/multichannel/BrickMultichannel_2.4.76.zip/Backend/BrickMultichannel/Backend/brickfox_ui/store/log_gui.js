// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/LogGui"}
Ext.define('Shopware.apps.BrickfoxUi.store.LogGui', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-LogGui',

    model: 'Shopware.apps.BrickfoxUi.model.LogGui',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getLogGuiList}',
            destroy: '{url action=deleteLogGui}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}