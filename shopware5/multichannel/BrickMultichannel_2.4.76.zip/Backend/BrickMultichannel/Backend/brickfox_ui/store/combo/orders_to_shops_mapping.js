// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/OrdersToShopsMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.OrdersToShopsMapping', {

    extend: 'Ext.data.Store',

    model: 'Shopware.apps.BrickfoxUi.model.combo.OrdersToShopsMapping',

    storeId: 'BrickfoxUi-store-combo-OrdersToShopsMapping',

    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getOrdersToShopsMappingDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}