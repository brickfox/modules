// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/ShopwareCurrenciesMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.ShopwareCurrenciesMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-ShopwareCurrenciesMapping',

    model: 'Shopware.apps.BrickfoxUi.model.ShopwareCurrenciesMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getShopwareCurrenciesMappingList}',
            create:  '{url action=saveShopwareCurrenciesMapping}',
            update:  '{url action=saveShopwareCurrenciesMapping}',
            destroy: '{url action=deleteShopwareCurrenciesMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}