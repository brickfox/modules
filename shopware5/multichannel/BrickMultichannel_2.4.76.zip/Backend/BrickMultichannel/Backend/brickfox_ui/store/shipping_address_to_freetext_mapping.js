// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/ShippingAddressToFreetextMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.ShippingAddressToFreetextMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-ShippingAddressToFreetextMapping',

    model: 'Shopware.apps.BrickfoxUi.model.ShippingAddressToFreetextMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type: 'ajax',
        api:    {
            read:    '{url action=getShippingAddressToFreetextMappingList}',
            create:  '{url action=saveShippingAddressToFreetextMapping}',
            update:  '{url action=saveShippingAddressToFreetextMapping}',
            destroy: '{url action=deleteShippingAddressToFreetextMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }

});
// {/block}