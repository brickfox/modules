// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/OrderState"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.OrderState', {
    extend: 'Ext.data.Store',
    storeId: 'BrickfoxUi-store-combo-OrderState',
    model: 'Shopware.apps.BrickfoxUi.model.combo.OrderState',
    autoLoad: true,
    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getOrderStates}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}