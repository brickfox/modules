// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/OrdersToCustomerGroupsMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.OrdersToCustomerGroupsMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-OrdersToCustomerGroupsMapping',

    model: 'Shopware.apps.BrickfoxUi.model.OrdersToCustomerGroupsMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getOrdersToCustomerGroupsMappingList}',
            create:  '{url action=saveOrdersToCustomerGroupsMapping}',
            update:  '{url action=saveOrdersToCustomerGroupsMapping}',
            destroy: '{url action=deleteOrdersToCustomerGroupsMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}