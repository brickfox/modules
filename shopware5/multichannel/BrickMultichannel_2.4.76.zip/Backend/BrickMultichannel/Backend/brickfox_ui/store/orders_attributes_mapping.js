// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/OrdersAttributesMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.OrdersAttributesMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-OrdersAttributesMapping',

    model: 'Shopware.apps.BrickfoxUi.model.OrdersAttributesMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getOrdersAttributesMappingList}',
            create:  '{url action=setOrdersAttributesMapping}',
            update:  '{url action=setOrdersAttributesMapping}',
            destroy: '{url action=deleteOrdersAttributesMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}