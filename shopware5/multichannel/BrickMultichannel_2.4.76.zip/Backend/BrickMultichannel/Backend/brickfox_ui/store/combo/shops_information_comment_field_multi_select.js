// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/ShopsInformationCommentFieldMultiSelect"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.ShopsInformationCommentFieldMultiSelect', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-ShopsInformationCommentFieldMultiSelect',

    model: 'Shopware.apps.BrickfoxUi.model.combo.ShopsInformationCommentFieldMultiSelect',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getShopsInformationCommentFieldDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}