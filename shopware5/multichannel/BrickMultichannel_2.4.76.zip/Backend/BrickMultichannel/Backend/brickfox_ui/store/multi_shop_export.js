// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/MultiShopExport"}
Ext.define('Shopware.apps.BrickfoxUi.store.MultiShopExport', {
    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-MultiShopExport',

    model: 'Shopware.apps.BrickfoxUi.model.MultiShopExport',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getMultiShopExportList}',
            create:  '{url action=saveMultiShopExport}',
            update:  '{url action=saveMultiShopExport}',
            destroy: '{url action=deleteMultiShopExport}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}