// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/TaxRatesMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.TaxRatesMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-TaxRatesMapping',

    model: 'Shopware.apps.BrickfoxUi.model.TaxRatesMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getTaxRatesMappingList}',
            create:  '{url action=saveTaxRatesMapping}',
            update:  '{url action=saveTaxRatesMapping}',
            destroy: '{url action=deleteTaxRatesMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}