// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/Configuration"}
Ext.define('Shopware.apps.BrickfoxUi.store.Configuration', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-configuration',

    autoLoad: false,

    constructor: function () {
        var me = this;

        Ext.Ajax.request({
            url:     'BrickfoxUi/getConfigurationSchema',
            async:   false,
            success: function (response) {
                try {
                    var resp = response.responseText;

                    if (resp) {
                        var data = Ext.JSON.decode(resp);

                        var model = Ext.define('Shopware.apps.BrickfoxUi.model.ConfigurationSchema', {
                            extend: 'Ext.data.Model',
                            fields: data.fields
                        });

                        me.model = Ext.ModelManager.getModel(model.$className);
                    }
                } catch (e) {
                    console.log(e);
                }
            },
            failure: function (e) {
                console.log(e);
            }
        });

        me.callParent(arguments);
    },

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getMainConfiguration}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}