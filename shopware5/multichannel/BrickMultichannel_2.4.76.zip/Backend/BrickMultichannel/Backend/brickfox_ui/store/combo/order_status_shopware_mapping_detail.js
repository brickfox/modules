// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/OrderStatusShopwareMappingDetail"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.OrderStatusShopwareMappingDetail', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-OrderStatusShopwareMappingDetail',

    model: 'Shopware.apps.BrickfoxUi.model.combo.OrderStatusShopwareMappingDetail',

    autoLoad: true,

    pageSize: 10,

    remoteSort: 10,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getOrderStatusShopwareMappingDetailDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}