// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/MultiShopExport"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.MultiShopExport', {
    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-MultiShopExport',

    model: 'Shopware.apps.BrickfoxUi.model.combo.MultiShopExport',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getMultiShopExportDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}