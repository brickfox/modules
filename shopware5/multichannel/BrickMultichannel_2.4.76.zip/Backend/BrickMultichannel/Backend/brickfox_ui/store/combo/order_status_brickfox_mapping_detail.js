// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/OrderStatusBrickfoxMappingDetail"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.OrderStatusBrickfoxMappingDetail', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-OrderStatusBrickfoxMappingDetail',

    model: 'Shopware.apps.BrickfoxUi.model.combo.OrderStatusBrickfoxMappingDetail',

    autoLoad: false,

    pageSize: 10,

    remoteSort: 10,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getOrderStatusBrickfoxMappingDetailDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}