// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/PaymentMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.PaymentMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-PaymentMapping',

    model: 'Shopware.apps.BrickfoxUi.model.PaymentMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getPaymentMappingList}',
            create:  '{url action=savePaymentMapping}',
            update:  '{url action=savePaymentMapping}',
            destroy: '{url action=deletePaymentMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}