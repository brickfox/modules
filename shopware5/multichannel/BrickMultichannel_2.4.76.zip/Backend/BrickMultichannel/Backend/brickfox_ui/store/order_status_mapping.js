// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/OrderStatusMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.OrderStatusMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-OrderStatusMapping',

    model: 'Shopware.apps.BrickfoxUi.model.OrderStatusMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getOrderStatusMappingList}',
            create:  '{url action=saveOrderStatusMapping}',
            update:  '{url action=saveOrderStatusMapping}',
            destroy: '{url action=deleteOrderStatusMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}