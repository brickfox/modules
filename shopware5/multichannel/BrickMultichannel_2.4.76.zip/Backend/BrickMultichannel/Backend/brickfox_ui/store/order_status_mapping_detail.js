// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/OrderStatusMappingDetail"}
Ext.define('Shopware.apps.BrickfoxUi.store.OrderStatusMappingDetail', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-OrderStatusMappingDetail',

    model: 'Shopware.apps.BrickfoxUi.model.OrderStatusMappingDetail',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getOrderStatusMappingDetailList}',
            create:  '{url action=saveOrderStatusMappingDetail}',
            update:  '{url action=saveOrderStatusMappingDetail}',
            destroy: '{url action=deleteOrderStatusMappingDetail}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}