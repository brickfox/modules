// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/OrdersToShopsMappingBrickfox"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.OrdersToShopsMappingBrickfox', {

    extend: 'Ext.data.Store',

    model: 'Shopware.apps.BrickfoxUi.model.combo.OrdersToShopsMappingBrickfox',

    storeId: 'BrickfoxUi-store-combo-OrdersToShopsMappingBrickfox',

    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getOrdersToShopsMappingBrickfoxDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}