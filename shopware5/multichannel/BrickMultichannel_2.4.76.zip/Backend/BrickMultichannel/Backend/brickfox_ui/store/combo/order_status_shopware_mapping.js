// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/OrderStatusShopwareMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.OrderStatusShopwareMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-OrderStatusShopwareMapping',

    model: 'Shopware.apps.BrickfoxUi.model.combo.OrderStatusShopwareMapping',

    autoLoad: true,

    pageSize: 10,

    remoteSort: 10,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getOrderStatusShopwareMappingDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}