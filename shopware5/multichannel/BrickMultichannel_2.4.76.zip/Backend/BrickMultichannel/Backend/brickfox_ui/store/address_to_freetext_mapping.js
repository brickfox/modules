// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/AddressToFreetextMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.AddressToFreetextMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-AddressToFreetextMapping',

    model: 'Shopware.apps.BrickfoxUi.model.AddressToFreetextMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type: 'ajax',
        api:    {
            read:    '{url action=getAddressToFreetextMappingList}',
            create:  '{url action=saveAddressToFreetextMapping}',
            update:  '{url action=saveAddressToFreetextMapping}',
            destroy: '{url action=deleteAddressToFreetextMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }

});
// {/block}