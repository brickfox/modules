// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/AttributesAsBulletsMultiSelect"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.AttributesAsBulletsMultiSelect', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-AttributesAsBulletsMultiSelect',

    model: 'Shopware.apps.BrickfoxUi.model.combo.AttributesAsBulletsMultiSelect',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getAttributesAsBulletsMultiSelectDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}