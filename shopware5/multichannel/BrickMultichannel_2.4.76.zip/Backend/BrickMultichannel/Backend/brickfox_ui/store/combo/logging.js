// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/brickfoxUi/store/combo/logging"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.Logging', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-Logging',

    model: 'Shopware.apps.BrickfoxUi.model.combo.Logging',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getYesOrNoComboListValues}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}