// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/PseudoPrice"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.PseudoPrice', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-pseudoPrice',

    model: 'Shopware.apps.BrickfoxUi.model.combo.PseudoPrice',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getPseudoPriceDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}