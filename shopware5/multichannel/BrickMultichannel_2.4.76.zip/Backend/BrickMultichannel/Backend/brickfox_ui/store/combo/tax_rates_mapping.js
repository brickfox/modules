// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/TaxRatesMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.TaxRatesMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-TaxRatesMapping',

    model: 'Shopware.apps.BrickfoxUi.model.combo.TaxRatesMapping',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getTaxRatesMappingDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}