// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/AddressToFreetext"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.AddressToFreetext', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-AddressToFreetext',

    model: 'Shopware.apps.BrickfoxUi.model.combo.AddressToFreetext',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getAddressAttributesDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data',
            totalProperty: 'count'
        }
    }
});
// {/block}