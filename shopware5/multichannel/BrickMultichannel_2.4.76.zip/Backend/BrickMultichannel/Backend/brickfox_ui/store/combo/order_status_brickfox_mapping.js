// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/OrderStatusBrickfoxMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.OrderStatusBrickfoxMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-OrderStatusBrickfoxMapping',

    model: 'Shopware.apps.BrickfoxUi.model.combo.OrderStatusBrickfoxMapping',

    autoLoad: false,

    pageSize: 10,

    remoteSort: 10,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getOrderStatusBrickfoxMappingDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}