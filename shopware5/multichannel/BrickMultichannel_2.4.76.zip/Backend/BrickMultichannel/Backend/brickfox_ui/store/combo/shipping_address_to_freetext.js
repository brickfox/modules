// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/ShippingAddressToFreetext"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.ShippingAddressToFreetext', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-ShippingAddressToFreetext',

    model: 'Shopware.apps.BrickfoxUi.model.combo.ShippingAddressToFreetext',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getShippingAddressAttributesDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data',
            totalProperty: 'count'
        }
    }
});
// {/block}