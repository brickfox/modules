// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/CustomerGroup"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.CustomerGroup', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-CustomerGroup',

    model: 'Shopware.apps.BrickfoxUi.model.combo.CustomerGroup',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getCustomerGroupsList}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}