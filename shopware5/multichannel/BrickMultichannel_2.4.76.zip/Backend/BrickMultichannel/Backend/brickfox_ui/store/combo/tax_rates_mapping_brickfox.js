// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/TaxRatesMappingBrickfox"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.TaxRatesMappingBrickfox', {

    extend: 'Ext.data.Store',

    model: 'Shopware.apps.BrickfoxUi.model.combo.TaxRatesMappingBrickfox',

    storeId: 'BrickfoxUi-store-combo-TaxRatesMappingBrickfox',

    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getTaxRatesMappingBrickfoxDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}