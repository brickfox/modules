// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/OrdersToShopsMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.OrdersToShopsMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-OrdersToShopsMapping',

    model: 'Shopware.apps.BrickfoxUi.model.OrdersToShopsMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getOrdersToShopsMappingList}',
            create:  '{url action=saveOrdersToShopsMapping}',
            update:  '{url action=saveOrdersToShopsMapping}',
            destroy: '{url action=deleteOrdersToShopsMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}