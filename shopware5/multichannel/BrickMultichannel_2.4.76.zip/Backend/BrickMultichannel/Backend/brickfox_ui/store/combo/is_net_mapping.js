// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/IsNetMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.IsNetMapping', {
    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-CurrenciesMapping',

    model: 'Shopware.apps.BrickfoxUi.model.combo.IsNetMapping',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getIsNetMappingDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}