// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/BulletsAsAttributesMultiSelect"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.BulletsAsAttributesMultiSelect',{
    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-BulletsAsAttributesMultiSelect',

    model: 'Shopware.apps.BrickfoxUi.model.combo.BulletsAsAttributesMultiSelect',

    autoLoad: true,

    proxy: {
        type: 'ajax',
        api: {
            read: '{url action=getBulletsAsAttributesMultiSelectDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}