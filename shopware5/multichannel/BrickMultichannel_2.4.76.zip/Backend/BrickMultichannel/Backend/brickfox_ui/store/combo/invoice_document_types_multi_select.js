// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/InvoiceDocumentTypesMultiSelect"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.InvoiceDocumentTypesMultiSelect', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-InvoiceDocumentTypesMultiSelect',

    model: 'Shopware.apps.BrickfoxUi.model.combo.InvoiceDocumentTypesMultiSelect',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getInvoiceDocumentTypesDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}