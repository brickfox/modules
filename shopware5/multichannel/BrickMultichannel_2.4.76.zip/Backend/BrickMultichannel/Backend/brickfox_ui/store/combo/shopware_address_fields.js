// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/ShopwareAddressFields"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.ShopwareAddressFields', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-ShopwareAddressFields',

    model: 'Shopware.apps.BrickfoxUi.model.combo.ShopwareAddressFields',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getShopwareAddressAttributesDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data',
            totalProperty: 'count'
        }
    }
});
// {/block}