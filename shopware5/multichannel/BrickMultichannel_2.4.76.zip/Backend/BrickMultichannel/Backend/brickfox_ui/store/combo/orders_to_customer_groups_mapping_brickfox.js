// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/OrdersToCustomerGroupsMappingBrickfox"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.OrdersToCustomerGroupsMappingBrickfox', {

    extend: 'Ext.data.Store',

    model: 'Shopware.apps.BrickfoxUi.model.combo.OrdersToCustomerGroupsMappingBrickfox',

    storeId: 'BrickfoxUi-store-combo-OrdersToCustomerGroupsMappingBrickfox',

    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getOrdersToCustomerGroupsMappingBrickfoxDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}