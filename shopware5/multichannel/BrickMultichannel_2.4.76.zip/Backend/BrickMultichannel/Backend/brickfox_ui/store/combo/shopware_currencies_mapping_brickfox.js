// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/ShopwareCurrenciesMappingBrickfox"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.ShopwareCurrenciesMappingBrickfox', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-ShopwareCurrenciesMappingBrickfox',

    model: 'Shopware.apps.BrickfoxUi.model.combo.ShopwareCurrenciesMappingBrickfox',

    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getBrickfoxCurrenciesMappingDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}