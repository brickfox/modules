// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/ShopwareCurrenciesMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.ShopwareCurrenciesMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-ShopwareCurrenciesMapping',

    model: 'Shopware.apps.BrickfoxUi.model.combo.ShopwareCurrenciesMapping',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getShopwareCurrenciesMappingDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});
// {/block}