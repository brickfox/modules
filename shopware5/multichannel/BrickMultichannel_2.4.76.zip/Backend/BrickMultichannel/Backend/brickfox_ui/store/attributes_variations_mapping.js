// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/AttributesVariationsMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.AttributesVariationsMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-FilterMapping',

    model: 'Shopware.apps.BrickfoxUi.model.AttributesVariationsMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type: 'ajax',
        api:    {
            read:    '{url action=getAttributesVariationsList}',
            create:  '{url action=setNewAttributesVariationsMapping}',
            update:  '{url action=setNewAttributesVariationsMapping}',
            destroy: '{url action=deleteAttributesVariationsMapping}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }

});
// {/block}