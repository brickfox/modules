// {namespace name="backend/BrickfoxUi/store"}
// {block name="backend/BrickfoxUi/store/OrdersAddInfosMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.OrdersAddInfosMapping', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-OrdersAddInfosMapping',

    model: 'Shopware.apps.BrickfoxUi.model.OrdersAddInfosMapping',

    autoLoad: false,

    remoteSort: true,

    remoteFilter: true,

    proxy: {
        type:   'ajax',
        api:    {
            read:    '{url action=getOrdersAddInfoList}',
            create:  '{url action=setNewOrdersAddInfo}',
            update:  '{url action=setNewOrdersAddInfo}',
            destroy: '{url action=deleteOrdersAddInfo}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}