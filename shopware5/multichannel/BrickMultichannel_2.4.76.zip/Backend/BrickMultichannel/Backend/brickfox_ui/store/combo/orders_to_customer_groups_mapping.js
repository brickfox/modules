// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/OrdersToCustomerGroupsMapping"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.OrdersToCustomerGroupsMapping', {

    extend: 'Ext.data.Store',

    model: 'Shopware.apps.BrickfoxUi.model.combo.OrdersToCustomerGroupsMapping',

    storeId: 'BrickfoxUi-store-combo-OrdersToCustomerGroupsMapping',

    autoLoad: false,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getOrdersToCustomerGroupsMappingDropDown}'
        },
        reader: {
            type:          'json',
            root:          'data',
            totalProperty: 'count'
        }
    }
});
// {/block}