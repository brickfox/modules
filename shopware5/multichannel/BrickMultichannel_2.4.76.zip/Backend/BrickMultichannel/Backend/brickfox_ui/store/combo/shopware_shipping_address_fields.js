// {namespace name="backend/BrickfoxUi/store/combo"}
// {block name="backend/BrickfoxUi/store/combo/ShopwareShippingAddressFields"}
Ext.define('Shopware.apps.BrickfoxUi.store.combo.ShopwareShippingAddressFields', {

    extend: 'Ext.data.Store',

    storeId: 'BrickfoxUi-store-combo-ShopwareShippingAddressFields',

    model: 'Shopware.apps.BrickfoxUi.model.combo.ShopwareShippingAddressFields',

    autoLoad: true,

    proxy: {
        type:   'ajax',
        api:    {
            read: '{url action=getShopwareShippingAddressAttributesDropDown}'
        },
        reader: {
            type: 'json',
            root: 'data',
            totalProperty: 'count'
        }
    }
});
// {/block}