// {namespace name="backend/BrickfoxUi/controller"}
// {block name="backend/BrickfoxUi/controller/Main"}
Ext.define('Shopware.apps.BrickfoxUi.controller.Main', {

    extend: 'Ext.app.Controller',

    mainWindow: null,

    init: function () {
        var me = this;

        me.mainWindow = me.subApplication.getView('Main').create().show();
        me.mainWindow.createTabPanel();

        me.control({
            'BrickfoxUi-view-TranslationMapping':        {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-CurrenciesMapping':         {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-ShopwareCurrenciesMapping': {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-PaymentMapping':            {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-MultiShopExport':           {
                add:                     me.onAddRow,
                delete:                  me.onDeleteRow,
                saveAttribute:           me.onSaveMapping,
                reloadMapping:           me.onReloadMapping,
                validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-AttributesVariations':      {
                add:           me.onAddRow,
                delete:        me.onDeleteRow,
                saveAttribute: me.onSaveMapping,
                reloadMapping: me.onReloadMapping
                // validateUniqueReference: me.onValidateUniqueReference
            },
            'BrickfoxUi-view-OrderStatusMapping':        {
                add:           me.onAddRow,
                delete:        me.onDeleteRow,
                saveAttribute: me.onSaveMapping,
                reloadMapping: me.onReloadMapping
            },
            'BrickfoxUi-view-OrdersAddInfosMapping':     {
                add:           me.onAddRow,
                delete:        me.onDeleteRow,
                saveAttribute: me.onSaveMapping,
                reloadMapping: me.onReloadMapping
            },
            'BrickfoxUi-view-OrdersToShopsMapping':      {
                add:           me.onAddRow,
                delete:        me.onDeleteRow,
                saveAttribute: me.onSaveMapping,
                reloadMapping: me.onReloadMapping
            },
            'BrickfoxUi-view-OrdersToCustomerGroupsMapping':      {
                add:           me.onAddRow,
                delete:        me.onDeleteRow,
                saveAttribute: me.onSaveMapping,
                reloadMapping: me.onReloadMapping
            },
            'BrickfoxUi-view-OrdersAttributesMapping':   {
                add:           me.onAddRow,
                delete:        me.onDeleteRow,
                saveAttribute: me.onSaveMapping,
                reloadMapping: me.onReloadMapping
            },
            'BrickfoxUi-view-OrderStatusMappingDetail':  {
                add:           me.onAddRow,
                delete:        me.onDeleteRow,
                saveAttribute: me.onSaveMapping,
                reloadMapping: me.onReloadMapping
            },
            'BrickfoxUi-view-TaxRatesMapping':            {
                add:           me.onAddRow,
                delete:        me.onDeleteRow,
                saveAttribute: me.onSaveMapping,
                reloadMapping: me.onReloadMapping
            },
            'BrickfoxUi-view-AddressToFreetextMapping':      {
                add:           me.onAddRow,
                delete:        me.onDeleteRow,
                saveAttribute: me.onSaveMapping,
                reloadMapping: me.onReloadMapping
            },
            'BrickfoxUi-view-ShippingAddressToFreetextMapping':      {
                add:           me.onAddRow,
                delete:        me.onDeleteRow,
                saveAttribute: me.onSaveMapping,
                reloadMapping: me.onReloadMapping
            }
        });

        me.callParent(arguments);
    },

    onValidateUniqueReference: function (view, editor, e, url, uniqueConstraintKey) {
        if (e.newValues[uniqueConstraintKey] !== undefined) {
            if (
                e.newValues.mappingFieldKey !== e.originalValues.mappingFieldKey && (e.newValues[uniqueConstraintKey] !== e.originalValues[uniqueConstraintKey]
                || e.newValues[uniqueConstraintKey] == e.originalValues[uniqueConstraintKey])
            ) {
                Ext.Ajax.request({
                    method:  'POST',
                    url:     url,
                    success: function (res) {
                        var response = Ext.JSON.decode(res.responseText),
                            i;

                        for (i = 0; i < response.data.length; i++) {
                            if (response.data[i].mappingFieldKey === e.newValues.mappingFieldKey && e.newValues.mappingFieldKey !== e.originalValues.mappingFieldKey) {
                                e.record.set('mappingFieldKey', e.originalValues.mappingFieldKey);
                                e.newValues.mappingFieldKey = e.originalValues.mappingFieldKey;
                                e.record.data.mappingFieldKey = e.originalValues.mappingFieldKey;

                                Shopware.Notification.createGrowlMessage('Fehler', 'Das von Ihnen angegebene Shopware-Model Feld wurde bereits gemapped.', 'Brickfox Connector');
                                break;
                            } else if (response.data[i][uniqueConstraintKey] === e.newValues[uniqueConstraintKey] && uniqueConstraintKey !== 'mappingFieldKey') {
                                e.record.set(uniqueConstraintKey, e.originalValues[uniqueConstraintKey]);
                                e.newValues[uniqueConstraintKey] = e.originalValues[uniqueConstraintKey];
                                e.record.data[uniqueConstraintKey] = e.originalValues[uniqueConstraintKey];

                                Shopware.Notification.createGrowlMessage('Fehler',
                                    'Das von Ihnen angegebene Feld mit dem Wert ' + uniqueConstraintKey + ' existiert bereits.',
                                    'Brickfox Connector');
                            }
                        }
                    },
                    failure: function () {
                        Shopware.Notification.createGrowlMessage('Fehler', 'Fehler beim prüfen des Mapping-Keys', 'Brickfox Connector')
                    },
                    params:  {
                        start: 0,
                        limit: 0
                    }
                })
            }
        }
    },

    onReloadMapping: function (view) {
        view.store.load();
    },

    onAddRow: function (view) {
        var model = Ext.create(view.store.model.modelName);

        switch (view.$className) {
            case 'Shopware.apps.BrickfoxUi.view.AttributesMapping' :
                model.set('attributesCode', '');
                model.set('mappingFieldKey', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.CurrenciesMapping':
                model.set('brickfoxCurrenciesCode', '');
                model.set('mappingFieldKey', '');
                model.set('isNetFieldKey', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.ShopwareCurrenciesMapping':
                model.set('brickfoxCurrenciesCode', '');
                model.set('mappingFieldKey', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.TranslationMapping':
                model.set('brickfoxIsoCode', '');
                model.set('mappingFieldKey', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.ShopsMapping':
                model.set('brickfoxShop', '');
                model.set('mappingFieldKey', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.PaymentMapping':
                model.set('brickfoxPaymentCode', '');
                model.set('mappingFieldKey', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.MultiShopExport':
                model.set('exportShopName', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.AttributesVariationsMapping':
                model.set('attributesVariationsCode', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.OrderStatusMapping':
                model.set('orderStatusId', '');
                model.set('brickfoxOrderStatusCode', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.OrdersAddInfosMapping':
                model.set('shopwareFieldName', '');
                model.set('brickfoxOrderAddInfoKey', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.OrdersToShopsMapping':
                model.set('brickfoxShopsId', '');
                model.set('shopwareShopsId', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.OrdersToCustomerGroupsMapping':
                model.set('brickfoxShopsId', '');
                model.set('shopwareCustomerGroupId', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.OrdersAttributesMapping':
                model.set('brickfoxOrderAddInfoKey', '');
                model.set('shopwareFieldName', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.OrderStatusMappingDetail':
                model.set('orderStatusId', '');
                model.set('brickfoxOrderStatusCode', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.TaxRatesMapping':
                model.set('mappingFieldKey', '');
                model.set('brickfoxTaxClass', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.AddressToFreetextMapping':
                model.set('freetextFieldId', '');
                model.set('addressFieldName', '');
                break;

            case 'Shopware.apps.BrickfoxUi.view.ShippingAddressToFreetextMapping':
                model.set('freetextFieldId', '');
                model.set('shippingAddressFieldName', '');
                break;
        }

        view.store.add(model);
        view.editingPlugin.startEdit(model, 1);
    },

    onDeleteRow: function (view) {
        var selectedRows = view.getSelectionModel().getSelection();

        if (selectedRows.length) {
            Ext.MessageBox.confirm('Info', 'Sind Sie sicher das Sie diesen Datensatz löschen wollen?', function (btn) {
                if (btn === 'yes') {
                    view.store.remove(selectedRows);
                    view.store.suspendAutoSync();
                    view.store.destroy(selectedRows);
                    view.store.resumeAutoSync();
                    Shopware.Notification.createSuccessMessage('Löschen erfolgreich.', 'Daten konnten gelöscht werden.');
                }
            });
        } else {
            Shopware.Notification.createNoticeMessage('Info', 'Bitte wählen Sie ein Attribut aus das Sie löschen möchten.');
        }
    },

    onSaveMapping: function (view) {
        view.store.save({
            success: function (batch, eOpts) {
                Shopware.Notification.createSuccessMessage('Speichern erfolgreich.', 'Daten konnten gespeichert werden.');
            },
            failure: function (batch, eOpts) {
                Shopware.Notification.createErrorMessage('Speichern fehlgeschlagen.', 'Daten konnten nicht gespeichert werden.');
            }
        });
    }
});
// {/block}