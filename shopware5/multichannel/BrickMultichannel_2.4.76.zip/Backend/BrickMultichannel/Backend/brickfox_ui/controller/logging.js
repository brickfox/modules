// {namespace name="backend/BrickfoxUi/controller"}
// {block name="backend/BrickfoxUi/controller/Logging"}
Ext.define('Shopware.apps.BrickfoxUi.controller.Logging', {

    extend: 'Ext.app.Controller',

    init: function () {
        var me = this;

        me.control({
            'BrickfoxUi-view-LogOrders': {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            },
            'BrickfoxUi-view-LogExport': {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            },
            'BrickfoxUi-view-LogGui':    {
                reloadLog:    me.onReloadLog,
                delete:       me.onDeleteRow,
                itemdblclick: me.onRowDbClick
            }
        });

        me.callParent(arguments);
    },

    onRowDbClick: function (dv, record) {
        if (record.data.bf_shops_orders_id !== undefined && record.data.bf_shops_orders_id !== null) {
            Ext.create('Shopware.apps.BrickfoxUi.view.LogDetailWindow', {
                bfShopsOrdersId: record.data.bf_shops_orders_id,
                bfShopsName:     record.data.bf_shops_name,
                error:           record.data.error,
                processed:       record.data.processed,
                lastUpdate:      record.data.last_update
            }).show();
        } else if (record.data.type !== undefined && record.data.lastUpdater !== undefined) {
            Ext.create('Shopware.apps.BrickfoxUi.view.LogDetailGuiWindow', {
                type:        record.data.type,
                errorCode:   record.data.errorCode,
                message:     record.data.message,
                lastUpdate:  record.data.lastUpdate,
                lastUpdater: record.data.lastUpdater
            }).show();
        } else {
            Ext.create('Shopware.apps.BrickfoxUi.view.LogDetailExportWindow', {
                exportType: record.data.exportType,
                identifier: record.data.identifier,
                errorCode:  record.data.errorCode,
                message:    record.data.message,
                lastUpdate: record.data.lastUpdate
            }).show();
        }
    },

    onReloadLog: function (view) {
        view.setLoading(true);

        view.store.load({
            callback: function () {
                view.setLoading(false);
            }
        });
    },

    onDeleteRow: function (view) {
        var selectedRows = view.getSelectionModel().getSelection();

        if (selectedRows.length) {
            Ext.MessageBox.confirm('Info', 'Sind Sie sicher das Sie diesen Datensatz löschen wollen?', function (btn) {
                if (btn === 'yes') {
                    view.store.remove(selectedRows);
                    view.store.suspendAutoSync();
                    view.store.destroy(selectedRows);
                    view.store.resumeAutoSync();
                    Shopware.Notification.createSuccessMessage('Löschen erfolgreich.', 'Daten konnten gelöscht werden.');
                }
            });
        } else {
            Shopware.Notification.createNoticeMessage('Info', 'Bitte wählen Sie ein Datensatz aus das Sie löschen möchten.');
        }
    }
});
// {/block}