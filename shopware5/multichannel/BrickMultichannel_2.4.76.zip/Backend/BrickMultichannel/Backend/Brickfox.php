<?php
use Bf\Multichannel\Components\ExportController;
use Bf\Multichannel\Components\ImportController;
use Bf\Multichannel\Components\Util\ConfigManager;
use Shopware\Components\CSRFWhitelistAware;

/**
 * Brickfox
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */
class Shopware_Controllers_Backend_Brickfox extends \Enlight_Controller_Action implements CSRFWhitelistAware
{
    public function getWhitelistedCSRFActions()
    {
        return [
            'exportBrands',
            'exportCategories',
            'exportProducts',
            'exportProductsUpdate',
            'exportProductsAssignment',
            'exportOrdersStatus',
            'exportDeleteFeed',
            'importOrders',
            'processedOrders',
            'downloadOrders',
            'showScriptLoggerMessageById',
            'showCronList',
            'clearFileArchive'
        ];
    }

    public function init()
    {
        Shopware()->Plugins()->Backend()->Auth()->setNoAuth();
        Shopware()->Plugins()->Controller()->ViewRenderer()->setNoRender();

        $mappingsActionsToTimeLimit = ConfigManager::getInstance()->getMappingScriptToTimeLimit();

        $actionName = $this->Request()->getActionName();

        if(array_key_exists($actionName, $mappingsActionsToTimeLimit) === true) {
            set_time_limit($mappingsActionsToTimeLimit[$actionName]);
        }
    }

    public function indexAction()
    {
        echo 'foo';
    }

    public function exportBrandsAction()
    {
        $exporter = new ExportController();
        $exporter->exportBrands();
    }

    public function exportCategoriesAction()
    {
        $exporter = new ExportController();
        $exporter->exportCategories();
    }

    public function exportProductsAction()
    {
        $exporter = new ExportController();
        $exporter->exportProducts();
    }

    public function exportProductsUpdateAction()
    {
        $exporter = new ExportController();
        $exporter->exportProductsUpdate();
    }

    public function exportProductsAssignmentAction()
    {
        $exporter = new ExportController();
        $exporter->exportProductsAssignments();
    }

    public function exportOrdersStatusAction()
    {
        $exporter = new ExportController();
        $exporter->exportOrdersStatus();
    }

    public function exportDeleteFeedAction()
    {
        $exporter = new ExportController();
        $exporter->exportDeleteFeed();
    }

    public function importOrdersAction()
    {
        $importer = new ImportController();
        $importer->importOrders();
    }

    public function processedOrdersAction()
    {
        $importer = new ImportController();
        $importer->processOrders();
    }

    public function downloadOrdersAction()
    {
        $ignoreWaitingTime = $this->Request()->getParam('ignoreWaitingTime', false);
        $importer          = new ImportController();
        $importer->downloadOrdersFromBrickfoxToShopware($ignoreWaitingTime);
    }

    public function showScriptLoggerMessageByIdAction()
    {
        $id = $this->Request()->getParam('scriptLoggerId', null);

        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\Scriptlogger');
        /** @var Shopware\CustomModels\BfSaleschannel\ScriptLogger $scriptLoggerModel */
        $scriptLoggerModel = $repository->find((int) $id);

        echo '<pre>';
        print_r($scriptLoggerModel->getScriptMessage());
        echo '</pre>';
    }

    public function showCronListAction()
    {
        $shopwareBackendCronPath = 'www.domain.de/backend/Brickfox/';

        echo '<strong>Cron-Aufrufe f&uuml;r das Exportieren der XMl: </strong><br />';
        echo $shopwareBackendCronPath . 'exportBrands<br />';
        echo $shopwareBackendCronPath . 'exportCategories<br />';
        echo $shopwareBackendCronPath . 'exportProducts<br />';
        echo $shopwareBackendCronPath . 'exportProductsAssignment<br />';
        echo $shopwareBackendCronPath . 'exportOrdersStatus<br />';
        echo $shopwareBackendCronPath . 'exportDeleteFeed<br /><br />';

        echo '<strong>Cron-Aufrufe f&uuml;r das Importieren der XMl: </strong><br />';
        echo $shopwareBackendCronPath . 'importOrders<br /><br/>';

        echo '<strong>Cron-Aufrufe f&uuml;r das Importieren der Daten:</strong><br />';
        echo $shopwareBackendCronPath . 'processedOrders<br />';
    }

    public function clearFileArchiveAction()
    {
        \Bf\Multichannel\Components\Util\FileManager::getInstance()->recursiveDeleteFiles();
    }
}
