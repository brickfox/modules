<?php
use Bf\Multichannel\Components\Gui\Log;

/**
 * BrickfoxUiLog
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */
class Shopware_Controllers_Backend_BrickfoxUiLog extends Shopware_Controllers_Backend_ExtJs
{
    public function indexAction()
    {
    }

    public function getExportLogListAction()
    {
        $data         = array();
        $logType      = $this->Request()->getParam('logType', null);
        $start        = $this->Request()->getParam('start', 0);
        $limit        = $this->Request()->getParam('limit', 25);
        $filter       = null;
        $searchFilter = null;
        $sort         = 'desc';
        $orderBy      = 'last_update';

        if($this->Request()->has('filter') === true)
        {
            $filter = $this->Request()->getParam('filter');

            foreach($filter as $elements)
            {
                if($elements['property'] === 'logType')
                {
                    $logType = $elements['value'];
                }

                if($elements['property'] === 'search')
                {
                    $logType = $elements['value'];
                }
            }
        }

        if($this->Request()->has('sort') === true)
        {
            $sort = $this->Request()->getParam('sort');

            if($sort[0]['property'] === 'errorMessageShort')
            {
                $orderBy = 'message';
            }
            else
            {
                $orderBy = $sort[0]['property'];
            }

            $sort = $sort[0]['direction'];
        }

        if($logType !== null)
        {
            $log  = new Log($logType, $start, $limit, $searchFilter, $sort, $orderBy);
            $data = $log->prepareLogList();
        }

        $this->View()->assign(
            array(
                'success' => true,
                'count'   => $data['count'],
                'data'    => $data['data']
            )
        );
    }
}
