<?php
/**
 * ExportController
 *
 * @package   Bf\Multichannel\Components
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components;

use Bf\Multichannel\Components\Export\Brands;
use Bf\Multichannel\Components\Export\Categories;
use Bf\Multichannel\Components\Export\Products;
use Bf\Multichannel\Components\Export\DeleteFeed;
use Bf\Multichannel\Components\Export\OrdersStatus;
use Bf\Multichannel\Components\Export\ProductsUpdate;
use Bf\Multichannel\Components\Util\FileManager;
use Bf\Multichannel\Components\Util\ScriptLogger;
use Bf\Multichannel\Components\Export\ProductsAssignment;

class ExportController
{
    public function exportAll()
    {
        $this->exportOrdersStatus();
        $this->exportBrands();
        $this->exportCategories();
        $this->exportProducts();
        $this->exportProductsAssignments();
        $this->exportDeleteFeed();
    }

    public function exportBrands()
    {
        ScriptLogger::getInstance()->run('export/Brands');
        $exporter = new Brands();
        $exporter->export(FileManager::FILENAME_BASE_MANUFACTURERS);
    }

    public function exportCategories()
    {
        ScriptLogger::getInstance()->run('export/Categories');
        $exporter = new Categories();
        $exporter->export(FileManager::FILENAME_BASE_CATEGORIES);
    }

    public function exportProducts()
    {
        $productsUpdateIsRunning = ScriptLogger::getInstance()->checkIfSpecifiedScriptLoggerIsRunning('export/ProductsUpdate');

        if($productsUpdateIsRunning === false)
        {
            ScriptLogger::getInstance()->run('export/Products');
            $exporter = new Products();
            $exporter->export(FileManager::FILENAME_BASE_PRODUCTS);
        }
    }

    public function exportProductsUpdate()
    {
        $productsExportIsRunning = ScriptLogger::getInstance()->checkIfSpecifiedScriptLoggerIsRunning('export/Products');

        if($productsExportIsRunning === false)
        {
            ScriptLogger::getInstance()->run('export/ProductsUpdate');
            $exporter = new ProductsUpdate();
            $exporter->setAlternativeRootName(FileManager::FILENAME_BASE_PRODUCTS);
            $exporter->export(FileManager::FILENAME_BASE_PRODUCTS_UPDATE);
        }
    }

    public function exportProductsAssignments()
    {
        ScriptLogger::getInstance()->run('export/ProductsAssignments');
        $exporter = new ProductsAssignment();
        $exporter->setAlternativeRootName(FileManager::FILENAME_BASE_PRODUCTS);
        $exporter->export(FileManager::FILENAME_BASE_PRODUCTS_ASSIGNMENTS);
    }

    public function exportOrdersStatus()
    {
        ScriptLogger::getInstance()->run('export/OrdersStatus');
        $exporter = new OrdersStatus();
        $exporter->setAlternativeRootName(FileManager::FILENAME_BASE_ORDERS);
        $exporter->export(FileManager::FILENAME_BASE_ORDERS_STATUS);
    }

    public function exportDeleteFeed()
    {
        ScriptLogger::getInstance()->run('export/DeleteFeed');
        $exporter = new DeleteFeed();
        $exporter->setAlternativeRootName(FileManager::FILENAME_BASE_PRODUCTS);
        $exporter->export(FileManager::FILENAME_BASE_PRODUCTS_DELETE);
    }
}
