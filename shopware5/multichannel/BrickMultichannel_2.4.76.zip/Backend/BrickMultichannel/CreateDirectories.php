<?php
/**
 * CreateDirectories
 *
 * @package   Bf\Saleschannel\Install
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Install;

use Bf\Multichannel\Components\Util\Helper as Helper;

class CreateDirectories extends InstallAbstract
{
    /**
     * @param \Shopware_Components_Plugin_Bootstrap $shopwarePluginBootstrapClass
     */
    public function __construct($shopwarePluginBootstrapClass)
    {
        parent::__construct($shopwarePluginBootstrapClass);
    }

    public function executeCreateDirectories()
    {
        $installDirectories = array(
            './uploads/brickfox/in',
            './uploads/brickfox/out',
            './uploads/brickfox/failure',
            './uploads/brickfox/success',
            './uploads/brickfox/processed',
            './uploads/brickfox/processedError',
            './uploads/brickfox/logs'
        );

        foreach($installDirectories as $directoryPath)
        {
            Helper::checkPath($directoryPath, true);
        }
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
