<?php
/**
 * RegisterMenu
 *
 * @package   Bf\Saleschannel\Install
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Install;

class RegisterMenu extends InstallAbstract
{
    /**
     * @param \Shopware_Components_Plugin_Bootstrap $shopwarePluginBootstrapClass
     */
    public function __construct($shopwarePluginBootstrapClass)
    {
        parent::__construct($shopwarePluginBootstrapClass);
    }

    public function executeRegisterMenu()
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Menu\Menu');
        $parentMenu = $repository->findOneBy(array('label' => 'Einstellungen'));

        if($parentMenu !== null)
        {
            $mainMenu = new \Shopware\Models\Menu\Menu();
            $mainMenu->setLabel('Brickfox Connector');
            $mainMenu->setClass('bf_icon');
            $mainMenu->setActive(true);
            $mainMenu->setParent($parentMenu);
            $mainMenu->setPlugin($this->getShopwarePluginBootstrapClass()->Plugin());

            Shopware()->Models()->persist($mainMenu);

            $firstMenu = new \Shopware\Models\Menu\Menu();
            $firstMenu->setLabel('Konfiguration');
            $firstMenu->setClass('bf_icon_settings');
            $firstMenu->setActive(true);
            $firstMenu->setController('BrickfoxUi');
            $firstMenu->setAction('Index');
            $firstMenu->setParent($mainMenu);
            $firstMenu->setPlugin($this->getShopwarePluginBootstrapClass()->Plugin());

            Shopware()->Models()->persist($firstMenu);

            $secondMenu = new \Shopware\Models\Menu\Menu();
            $secondMenu->setLabel('Log');
            $secondMenu->setClass('bf_icon_log');
            $secondMenu->setActive(true);
            $secondMenu->setController('BrickfoxUiLog');
            $secondMenu->setAction('Index');
            $secondMenu->setParent($mainMenu);
            $secondMenu->setPlugin($this->getShopwarePluginBootstrapClass()->Plugin());

            Shopware()->Models()->persist($secondMenu);

            $thirdMenu = new \Shopware\Models\Menu\Menu();
            $thirdMenu->setLabel('Fehler-Code übersicht');
            $thirdMenu->setClass('bf_icon_error_code_list');
            $thirdMenu->setActive(true);
            $thirdMenu->setController('BrickfoxUiErrorCodeList');
            $thirdMenu->setAction('Index');
            $thirdMenu->setParent($mainMenu);
            $thirdMenu->setPlugin($this->getShopwarePluginBootstrapClass()->Plugin());

            Shopware()->Models()->persist($thirdMenu);

            Shopware()->Models()->flush();
        }
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
