UPDATE bf_configuration
SET configuration_key='shopsInformationCommentField'
WHERE configuration_key = 'shopsOrderIdCommentField';