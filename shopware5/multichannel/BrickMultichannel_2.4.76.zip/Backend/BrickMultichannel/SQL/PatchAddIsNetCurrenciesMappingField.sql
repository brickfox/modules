ALTER TABLE bf_mapping_currencies
ADD `is_net_field_key` VARCHAR(255);