ALTER TABLE bf_api_export_media DROP INDEX mediaID;
ALTER TABLE bf_api_export_media ADD CONSTRAINT media_mapping UNIQUE (mediaID, articleID);