INSERT INTO `bf_configuration` (`configuration_key`, `configuration_value`)
VALUES ('enableShopsOrderIdToComment', '0');
INSERT INTO `bf_configuration` (`configuration_key`, `configuration_value`)
VALUES ('shopsOrderIdCommentField', '');