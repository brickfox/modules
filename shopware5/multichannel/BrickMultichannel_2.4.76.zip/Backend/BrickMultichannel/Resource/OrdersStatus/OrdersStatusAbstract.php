<?php
/**
 * OrdersStatusAbstract
 *
 * @package   Bf\Multichannel\Components\Resource\OrdersStatus
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\OrdersStatus;

abstract class OrdersStatusAbstract
{
    /** @var \Shopware\Models\Order\Order */
    private $ordersModel;

    /**
     * @param $orderModel
     */
    public function __construct($orderModel)
    {
        $this->ordersModel = $orderModel;
    }

    /**
     * @param $ordersStatusId
     *
     * @return string|null
     */
    private function getDefaultOrdersStatusId($ordersStatusId)
    {
        $orderStatus = null;

        switch($ordersStatusId)
        {
            case 1://In Bearbeitung
                $orderStatus = 'Pending';
                break;

            case 2://Komplett abgeschlossen
                $orderStatus = 'Shipped';
                break;

            case 4://Storniert / Abgelehnt
                $orderStatus = 'Cancelled';
                break;

            case 5://Zur Lieferung bereit
                $orderStatus = 'ReadyForShipout';
                break;

            case 6://Teilweise ausgeliefert
                $orderStatus = 'PartlyShipped';
                break;

            case 7: //komplett ausgeliefert
                $orderStatus = 'Shipped';
                break;

            default:
                $orderStatus = 'Pending';
                break;
        }

        return $orderStatus;
    }

    /**
     * @param $ordersStatusId
     *
     * @return string|null
     */
    public function getOrderDetailsStatusByShopwareStatus($ordersStatusId)
    {
        $ordersStatus = $this->getDefaultOrdersStatusId($ordersStatusId);

        $mappingOrderStatusDetailRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingOrderStatusDetail');
        /** @var \Shopware\CustomModels\BfMultichannel\MappingOrderStatusDetail $mappingOrdersStatusDetailModel */
        $mappingOrdersStatusDetailModel = $mappingOrderStatusDetailRepository->findOneBy(array('shopwareId' => $ordersStatusId));

        if ($mappingOrdersStatusDetailModel !== null) {
            $ordersStatus = $mappingOrdersStatusDetailModel->getBrickfoxOrderStatusCode();
        }

        return $ordersStatus;
    }

    /**
     * @param $ordersStatusId
     * @return string
     */
    protected function getOrderStatusByShopwareStatus($ordersStatusId)
    {
        $orderStatus = null;

        $mappingOrderStatusRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingOrderStatus');
        /** @var \Shopware\CustomModels\BfMultichannel\MappingOrderStatus $mappingOrderStatusModel */
        $mappingOrderStatusModel = $mappingOrderStatusRepository->findOneBy(array('shopwareId' => $ordersStatusId));

        if ($mappingOrderStatusModel !== null) {
            $orderStatus = $mappingOrderStatusModel->getBrickfoxOrderStatusCode();
        } else {
            switch($ordersStatusId)
            {
                case 1://In Bearbeitung
                    $orderStatus = 'Pending';
                    break;

                case 2://Komplett abgeschlossen
                    $orderStatus = 'Shipped';
                    break;

                case 4://Storniert / Abgelehnt
                    $orderStatus = 'Cancelled';
                    break;

                case 5://Zur Lieferung bereit
                    $orderStatus = 'ReadyForShipout';
                    break;

                case 6://Teilweise ausgeliefert
                    $orderStatus = 'PartlyShipped';
                    break;

                case 7: //komplett ausgeliefert
                    $orderStatus = 'Shipped';
                    break;

                default:
                    $orderStatus = 'Pending';
                    break;
            }
        }

        return $orderStatus;
    }

    /**
     * @return \Shopware\Models\Order\Order
     */
    public function getOrdersModel()
    {
        return $this->ordersModel;
    }

    /**
     * @param mixed $ordersModel
     *
     * @return OrdersStatusAbstract
     */
    public function setOrdersModel($ordersModel)
    {
        $this->ordersModel = $ordersModel;

        return $this;
    }

    /**
     */
    public function __destruct()
    {
        $this->ordersModel = null;
    }
}
