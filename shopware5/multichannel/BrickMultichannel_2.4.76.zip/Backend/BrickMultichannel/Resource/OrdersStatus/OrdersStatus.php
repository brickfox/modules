<?php
/**
 * OrdersStatus
 *
 * @package   Bf\Multichannel\Components\Resource\OrdersStatus
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\OrdersStatus;

use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\Exceptions\SkipItemExportException;
use Bf\Multichannel\Components\Util\FileWriter;
use Bf\Multichannel\Components\Util\PickwareCompability;

class OrdersStatus extends OrdersStatusAbstract
{
    const EXPORT_TYPE      = 'Orderstatus';
    const PATH_TO_INVOICES = 'files/documents/';

    /**
     * @param \Shopware\Models\Order\Order $item
     */
    public function __construct($item)
    {
        parent::__construct($item);
    }

    /**
     * @param int $exportItemCount
     */
    public function prepareOrdersStatusNode($exportItemCount = 0)
    {
        $orderLineArray    = [];
        $orderLinesCounter = 1;

        if ((bool)ConfigManager::getInstance()->getExportOrderLineStatus()->getConfigurationValue() === true) {
            $ordersDetails = $this->getOrdersModel()->getDetails();

            if (ConfigManager::getInstance()->isUsePickwareCompability() === true
                && PickwareCompability::isHasRepository()) {

                $ordersDetails = $ordersDetails->filter(function ($orderDetail) {
                    $attribute = $orderDetail->getAttribute();

                    if ($attribute !== null && $attribute->getAttribute1() === 'pickware_subarticle_by_brickfox') {
                        return false;
                    } else {
                        return true;
                    }
                });
            }

            /** @var \Shopware\Models\Order\Detail $ordersDetail */
            foreach ($ordersDetails as $ordersDetail) {
                if ($ordersDetail->getStatus()->getId() !== 0) {
                    $ordersLinesStatus = $this->getOrderDetailsStatusByShopwareStatus($ordersDetail->getStatus()->getId());

                    $articleDetail = $ordersDetail->getArticleDetail();

                    if ($articleDetail !== null) {
                        $variationId = $articleDetail->getId();
                    } else {
                        $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Article');

                        /** @var \Shopware\Models\Article\Article $articleModel */
                        $articleModel = $repository->find($ordersDetail->getArticleId());
                        $mainDetail = $articleModel->getMainDetail();

                        if($mainDetail === null) {
                            // will get caught on ExportAbstract
                            // skip s_orders with s_order_details that have no s_articles_details attached
                            // this can for example happen if there are s_order_details that represent partial reimbursements for the customer
                            // for example if the article had an issue
                            throw new SkipItemExportException();
                        }

                        $variationId  = $mainDetail->getId();
                    }

                    /** @var \Shopware\CustomModels\BfMultichannel\Configuration $ordersLinesIdAttributesField */
                    $ordersLinesIdAttributesFieldConfigurationModel = ConfigManager::getInstance()->getConfigurationRepository()->findOneBy(
                        [
                            'configurationKey' => 'ordersLinesIdAttributesField'
                        ]
                    );

                    $orderLineId = '';

                    if ($ordersLinesIdAttributesFieldConfigurationModel !== null) {
                        $getter = 'get' . ucfirst($ordersLinesIdAttributesFieldConfigurationModel->getConfigurationValue());

                        if (method_exists($ordersDetail->getAttribute(), $getter) === true) {
                            $orderLineId = $ordersDetail->getAttribute()->$getter();
                        }
                    }

                    if (ConfigManager::getInstance()->getOrderStatusExportUsesPickware() === true) {
                        $pickwareReturnShipentItem = Shopware()
                            ->Db()
                            ->fetchRow("select * from pickware_erp_return_shipment_items where orderDetailId = ?",
                                array($ordersDetail->getId()));

                        $quantityReturned  = 0;
                        $quantityCancelled = 0;
                        $quantityShipped   = 0;
                        $quantityOrdered   = 0;

                        if($ordersLinesStatus === "Returned") {
                            if (isset($pickwareReturnShipentItem['returnedQuantity']) === true) {
                                $quantityReturned = $pickwareReturnShipentItem['returnedQuantity'];
                                $quantityOrdered  = $quantityReturned;
                            }
                        }

                        if($ordersLinesStatus === "Cancelled") {
                            if (isset($pickwareReturnShipentItem['cancelledQuantity']) === true) {
                                $quantityCancelled = $pickwareReturnShipentItem['cancelledQuantity'];
                                $quantityOrdered  = $quantityCancelled;
                            }
                        }

                        if($ordersLinesStatus === "Shipped") {
                            $quantityShipped = (int)$ordersDetail->getShipped();
                            $quantityOrdered  = $quantityShipped;
                        }
                    } else {
                        $quantityReturned = $ordersLinesStatus !== 'Returned' ? 0 : $ordersDetail->getQuantity();
                        $quantityCancelled = $ordersLinesStatus !== 'Cancelled' ? 0 : $ordersDetail->getQuantity();
                        $quantityShipped = $ordersLinesStatus !== 'Shipped' ? 0 : $ordersDetail->getQuantity();
                        $quantityOrdered = $ordersDetail->getQuantity();
                    }

                    $orderLineArray['OrderLine' . $orderLinesCounter] = [
                        '@attributes'       => ['num' => $orderLinesCounter],
                        'OrderLineId'       => ['@value' => $orderLineId],
                        'ProductId'         => ['@value' => $ordersDetail->getArticleId()],
                        'VariationId'       => ['@value' => $variationId],
                        'OrderLineStatus'   => ['@value' => $ordersLinesStatus],
                        'QuantityOrdered'   => ['@value' => $quantityOrdered],
                        'QuantityCancelled' => ['@value' => $quantityCancelled],
                        'QuantityShipped'   => ['@value' => $quantityShipped],
                        'QuantityReturned'  => ['@value' => $quantityReturned]
                    ];

                    $orderLinesCounter++;
                }
            }
        }

        if (count($orderLineArray) > 0) {
            $orderLineArray['@attributes'] = ['count' => count($orderLineArray)];

            $orderLines = $orderLineArray;
        } else {
            $orderLines = [
                '@attributes' => ['count' => 1]
            ];
        }

        $returnTrackingId = null;

        /** @var \Shopware\CustomModels\BfMultichannel\Configuration $orderAttributesFieldReturnTrackingIdConfigurationModel */
        $orderAttributesFieldReturnTrackingIdConfigurationModel = ConfigManager::getInstance()->getConfigurationRepository()->findOneBy(
            [
                'configurationKey' => 'orderAttributesFieldReturnTrackingId'
            ]
        );

        if ($orderAttributesFieldReturnTrackingIdConfigurationModel !== null && strlen($orderAttributesFieldReturnTrackingIdConfigurationModel->getConfigurationValue()) > 0) {
            $orderAttributes = $this->getOrdersModel()->getAttribute();

            $getter = 'get' . ConfigManager::snakeCaseToCamelCase($orderAttributesFieldReturnTrackingIdConfigurationModel->getConfigurationValue());

            if (method_exists($orderAttributes, $getter)) {
                $returnTrackingId = $orderAttributes->$getter();
            }
        }

        $orderFiles        = [];
        $invoicePathPrefix = $this->getInvoiceFolderPathPrefix();

        $repository = Shopware()->Models()->getRepository('Shopware\Models\Order\Document\Document');
        /** @var \Shopware\Models\Order\Document\Document[] $invoiceDocuments */
        $invoiceDocuments = $repository->findBy([
            'orderId' => $this->getOrdersModel()->getId(),
            'type'    => $this->getInvoiceDocumentTypeId()
        ]);

        if (count($invoiceDocuments) > 0) {
            /** @var \Shopware\Models\Order\Document\Document $invoiceDocument */
            foreach ($invoiceDocuments as $index => $invoiceDocument) {
                $orderFiles['OrderFile' . $index] = [
                    'Type'          => ['@value' => 'invoice_pdf'],
                    'Value'         => ['@value' => $invoicePathPrefix . self::PATH_TO_INVOICES . $invoiceDocument->getHash() . '.pdf'],
                    'InvoiceNumber' => ['@value' => $invoiceDocument->getDocumentId()]
                ];
            }
        }
        $trackingIdAndCarrierName = $this->getTrackingIdAndCarrierName();
        FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter] = [
            '@attributes'        => ['num' => $exportItemCount],
            'OrderId'            => ['@value' => $this->getOrdersModel()->getTemporaryId()],
            'OrderStatusChanged' => ['@value' => $this->getOrderStatusChangedDate()],
            'OrderStatus'        => ['@value' => $this->getOrderStatusByShopwareStatus($this->getOrdersModel()->getOrderStatus()->getId())],
            'ShippingTrackingId' => ['@value' => $trackingIdAndCarrierName['trackingId']],
            'ReturnTrackingId'   => ['@value' => $returnTrackingId],
            'CarrierName'        => ['@value' => $trackingIdAndCarrierName['carrierName']],
            'OrderLines'         => $orderLines,
            'OrderFiles'         => $orderFiles
        ];
    }

    /**
     * @return string
     */
    private function getInvoiceFolderPathPrefix()
    {

        $path = '';

        /** @var \Shopware\CustomModels\BfMultichannel\Configuration $configModel */
        $configModel = ConfigManager::getInstance()->getConfigurationRepository()->findOneBy([
            'configurationKey' => 'invoiceFolderPath'
        ]);

        if ($configModel !== null && strlen($configModel->getConfigurationValue()) > 0) {
            $path = (string)$configModel->getConfigurationValue();
            $path = str_replace(self::PATH_TO_INVOICES, '', $path);
            if (strlen($path) > 0 && substr($path, strlen($path) - 1, 1) !== DIRECTORY_SEPARATOR) {
                $path .= DIRECTORY_SEPARATOR;
            }
        }

        return $path;
    }

    /**
     * @return int
     */
    private function getInvoiceDocumentTypeId()
    {

        $documentTypeId = 1;

        /** @var \Shopware\CustomModels\BfMultichannel\Configuration $configModel */
        $configModel = ConfigManager::getInstance()->getConfigurationRepository()->findOneBy([
            'configurationKey' => 'invoiceDocumentType'
        ]);

        if ($configModel !== null && strlen($configModel->getConfigurationValue()) > 0) {
            $documentTypeId = (int)$configModel->getConfigurationValue();
        }

        return $documentTypeId;
    }

    /**
     * @return \DateTime
     */
    private function getOrderStatusChangedDate()
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Order\History');
        /** @var \Shopware\Models\Order\History $orderHistoryModel */
        $orderHistoryModel = $repository->findOneBy(['orderId' => $this->getOrdersModel()->getId()]);

        if ($orderHistoryModel === null) {
            $changeDate = date('Y-m-d H:i:s');
        } else {
            $changeDate = $orderHistoryModel->getChangeDate()->format('Y-m-d H:i:s');
        }

        return $changeDate;
    }

    protected function getTrackingIdAndCarrierName() {
        $trackingId  = null;
        $carrierName = null;

        $orderTrackingIdAndCarrierName = $this->getTrackingIdAndCarrierNameFromOrder();

        if(strlen($orderTrackingIdAndCarrierName['trackingId']) > 0) {
            $trackingId = $orderTrackingIdAndCarrierName['trackingId'];
        }

        if(strlen($orderTrackingIdAndCarrierName['carrierName']) > 0) {
            $carrierName = $orderTrackingIdAndCarrierName['carrierName'];
        }

        $orderPositionTrackingIdAndCarrierName = $this->getTrackingIdAndCarrierNameFromOrderPositions();

        if(strlen($trackingId) <= 0 && strlen($orderPositionTrackingIdAndCarrierName['trackingId']) > 0) {
            $trackingId = $orderPositionTrackingIdAndCarrierName['trackingId'];
        }

        if(strlen($carrierName) <= 0 && strlen($orderPositionTrackingIdAndCarrierName['carrierName']) > 0) {
            $carrierName = $orderPositionTrackingIdAndCarrierName['carrierName'];
        }

        if(strlen($trackingId) <= 0)
        {
            $trackingId = $this->getOrdersModel()->getTrackingCode();
        }

        if(strlen($carrierName) <= 0)
        {
            $carrierName = $this->getOrdersModel()->getDispatch()->getName();
        }

        return ['trackingId' => $trackingId, 'carrierName' => $carrierName];
    }

    protected function getTrackingIdAndCarrierNameFromOrder() {
        $trackingId  = null;
        $carrierName = null;

        $orderTrackingIdColumnName = ConfigManager::getInstance()->getOrderTrackingIdColumnNameMain();
        $orderCarrierColumnName    = ConfigManager::getInstance()->getOrderCarrierColumnNameMain();
        if(strlen($orderTrackingIdColumnName) > 0 || strlen($orderCarrierColumnName) > 0) {
            $sOrderAttribute = $this->getOrdersModel()->getAttribute();
            if($sOrderAttribute !== null) {
                $getterTrackingId = 'get' . ucfirst($orderTrackingIdColumnName);

                if(method_exists($sOrderAttribute, $getterTrackingId) === true) {
                    $trackingId  = $sOrderAttribute->$getterTrackingId();
                }
                $getterCarrierName = 'get' . ucfirst($orderCarrierColumnName);

                if(method_exists($sOrderAttribute, $getterCarrierName) === true) {
                    $carrierName  = $sOrderAttribute->$getterCarrierName();
                }
            }
        }
        return ['trackingId' => $trackingId, 'carrierName' => $carrierName];
    }

    /**
     * @return array
     */
    protected function getTrackingIdAndCarrierNameFromOrderPositions()
    {
        $trackingId  = null;
        $carrierName = null;

        // configs to get shipment infos from s_order_detail_attributes
        // tries to make the best pick
        $orderTrackingIdColumnName = ConfigManager::getInstance()->getOrderTrackingIdColumnName();
        $orderCarrierColumnName    = ConfigManager::getInstance()->getOrderCarrierColumnName();

        if(strlen($orderTrackingIdColumnName) > 0 || strlen($orderCarrierColumnName) > 0)
        {
            $sOrderDetails     = $this->getOrdersModel()->getDetails()->toArray();

            /** @var \Shopware\Models\Order\Detail $sOrderDetail */
            foreach($sOrderDetails as $sOrderDetail)
            {
                $sOrderDetailAttribute = $sOrderDetail->getAttribute();

                $tmpTrackingId  = null;
                $tmpCarrierName = null;

                if(strlen($orderTrackingIdColumnName) > 0 && strlen($orderCarrierColumnName) > 0)
                {
                    $getterTrackingId = 'get' . ucfirst($orderTrackingIdColumnName);

                    if(method_exists($sOrderDetailAttribute, $getterTrackingId) === true) {
                        $tmpTrackingId  = $sOrderDetailAttribute->$getterTrackingId();
                    }

                    $getterCarrierName = 'get' . ucfirst($orderCarrierColumnName);

                    if(method_exists($sOrderDetailAttribute, $getterCarrierName) === true) {
                        $tmpCarrierName  = $sOrderDetailAttribute->$getterCarrierName();
                    }

                    // prefer s_order_details_attributes with both tracking-ID and carrier-name
                    if(strlen($tmpTrackingId) > 0 && strlen($tmpCarrierName) > 0)
                    {
                        $trackingId  = $tmpTrackingId;
                        $carrierName = $tmpCarrierName;
                        break;
                    }
                    else if(strlen($tmpTrackingId) > 0 && strlen($trackingId) <= 0)
                    {
                        $trackingId = $tmpTrackingId;
                    }
                    else if(strlen($tmpCarrierName) > 0 && strlen($carrierName) <= 0)
                    {
                        $carrierName = $tmpCarrierName;
                    }
                }
                else if(strlen($orderTrackingIdColumnName) > 0)
                {
                    $getterTrackingId = 'get' . ucfirst($orderTrackingIdColumnName);

                    if(method_exists($sOrderDetailAttribute, $getterTrackingId) === true) {
                        $tmpTrackingId  = $sOrderDetailAttribute->$getterTrackingId();
                    }

                    if(strlen($tmpTrackingId) > 0 && strlen($trackingId) <= 0)
                    {
                        $trackingId = $tmpTrackingId;
                    }
                }
                else if(strlen($orderCarrierColumnName) > 0)
                {
                    $getterCarrierName = 'get' . ucfirst($orderCarrierColumnName);

                    if(method_exists($sOrderDetailAttribute, $getterCarrierName) === true) {
                        $tmpCarrierName  = $sOrderDetailAttribute->$getterCarrierName();
                    }

                    if(strlen($tmpCarrierName) > 0 && strlen($carrierName) <= 0)
                    {
                        $carrierName = $tmpCarrierName;
                    }
                }
            }
        }

        return ['trackingId' => $trackingId, 'carrierName' => $carrierName];
    }
}
