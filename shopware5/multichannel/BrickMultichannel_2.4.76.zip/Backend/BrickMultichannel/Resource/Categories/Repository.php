<?php

/**
 * Repository
 *
 * @package   Bf\Multichannel\Components\Export
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Categories;

use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\LogCodes;
use Bf\Multichannel\Components\Util\LogManager;

class Repository
{
    const EXPORT_TYPE = 'Categories';

    public $mainCategoriesId;

    private $categories;

    public function __construct()
    {
        $this->mainCategoriesId = null;
        $this->categories       = array();
    }

    public function getActiveDefaultShopsCategory()
    {
        $qb = Shopware()->Models()->createQueryBuilder();

        $qb->select(array('shops'))->from('\Shopware\Models\Shop\Shop', 'shops')->where('shops.default = :default')->andWhere('shops.active = :active')->setParameters(
            array(
                'default' => true,
                'active'  => 1
            )
        );

        $sql = $qb->getQuery();

        $mainCategory = $sql->getArrayResult();

        if(count($mainCategory) <= 0)
        {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE,
                LogCodes::EXPORT_CATEGORIES_BY_DEFAULT_CODE,
                LogCodes::EXPORT_CATEGORIES_BY_DEFAULT
            );
        }

        $this->setMainCategoriesId($mainCategory[0]['categoryId']);
    }

    /**
     * @param int|null $currentCategoriesId
     *
     * @return void
     */
    public function getExportCategoriesByMainCategoryId($currentCategoriesId = null)
    {
        if($currentCategoriesId === null)
        {
            $currentCategoriesId = $this->getMainCategoriesId();
            $sqlResult = $this->fetchCategories(null, $currentCategoriesId);

        } else {
            $sqlResult = $this->fetchCategories($currentCategoriesId);
        }

        if(count($sqlResult) > 0)
        {
            $disabledCategories = explode(',', ConfigManager::getInstance()->getDisabledCategories()->getConfigurationValue());

            foreach($sqlResult as $category)
            {
                if (in_array($category['id'], $disabledCategories) === false) {
                    $this->setCategories($category);
                    $this->getExportCategoriesByMainCategoryId($category['id']);
                }
            }
        }
        else
        {
            return;
        }
    }

    /**
     * @param null $parentId
     * @param null $id
     *
     * @return array
     */
    private function fetchCategories($parentId = null, $id = null)
    {
        $sqlResult = array();

        if ($parentId !== null) {
            $sqlResult = Shopware()->Db()->fetchAll(
                "select id, description, parent from s_categories where parent = ?",
                array($parentId)
            );
        } elseif ($parentId === null && $id !== null) {
            $sqlResult = Shopware()->Db()->fetchAll(
                "select id, description, parent from s_categories where id = ?",
                array($id)
            );
        }

        return $sqlResult;
    }

    /**
     * @param int $mainCategoriesId
     *
     * @return \Bf\Multichannel\Components\Resource\Categories\Repository
     */
    public function setMainCategoriesId($mainCategoriesId)
    {
        $this->mainCategoriesId = $mainCategoriesId;

        return $this;
    }

    /**
     * @return int
     */
    public function getMainCategoriesId()
    {
        return $this->mainCategoriesId;
    }

    /**
     * @param array $category
     */
    public function setCategories(array $category)
    {
        $this->categories[] = array(
            'id'          => $category['id'],
            'description' => $category['description'],
            'parent'      => $category['parent']
        );
    }

    /**
     * @return array
     */
    public function getCategories()
    {
        return $this->categories;
    }

    public function __destruct()
    {
        $this->mainCategoriesId = null;
        $this->categories       = array();
    }
}
