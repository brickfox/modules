<?php
/**
 * Categories
 *
 * @package   Bf\Multichannel\Components\Resource\Categories
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Categories;

use Bf\Multichannel\Components\Interfaces\ProductsInterface;
use Bf\Multichannel\Components\Util\FileWriter;
use Doctrine\Common\Collections\ArrayCollection;

class Categories implements ProductsInterface
{
    private $model;

    /**
     * @param ArrayCollection $model
     */
    public function __construct($model)
    {
        $this->model = $model;
    }

    /**
     */
    public function prepareCategoriesNode()
    {
        if ($this->getModel()->count() > 0) {
            $repository   = Shopware()->Models()->getRepository('Shopware\Models\Category\Category');

            /** @var \Shopware\Models\Category\Category $category */
            foreach ($this->getModel() as $category) {
                $rewrittenCategoryPath = [];
                if (strlen($category->getPath()) > 0) {
                    $categoryPath = explode('|', $category->getPath());
                    foreach ($categoryPath as $id => $categoryId) {
                        if($categoryId !== '' && is_numeric($categoryId)) {
                            /** @var \Shopware\Models\Category\Category|null $categoryModel */
                            $categoryModel = $repository->find($categoryId);
                            $rewrittenCategoryPath[$id] = $categoryModel->getName();
                        }
                    }
                }

                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Categories'][] = [
                    'Category' => [
                        'ExternCategoryId' => ['@value' => $category->getId()],
                        'CategoryPath'     => ['@cdata' => implode('/', $rewrittenCategoryPath)]
                    ]
                ];

            }
        }
    }

    /**
     * @return ArrayCollection
     */
    public function getModel()
    {
        return $this->model;
    }

    /**
     * @param ArrayCollection $model
     *
     * @return Categories
     */
    public function setModel($model)
    {
        $this->model = $model;

        return $this;
    }

    public function __destruct()
    {
        $this->model = null;
    }
}
