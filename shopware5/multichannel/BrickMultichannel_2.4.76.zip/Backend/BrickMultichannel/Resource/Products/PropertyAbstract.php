<?php
/**
 * PropertyAbstract
 *
 * @package   Bf\Multichannel\Components\Resource\Products
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Bf\Multichannel\Components\Resource\Translation\TranslationAbstract;

class PropertyAbstract extends TranslationAbstract
{
    /**
     * @param \Shopware\Models\Article\Article|\Shopware\Models\Article\Detail $model
     */
    public function __construct($model)
    {
        parent::__construct($model);
    }

    protected function getPropertyOptionIdByValueId($valueId)
    {
        $optionId = Shopware()->Db()->fetchOne(
            "select optionID from s_filter_values where id = ?",
            array($valueId)
        );

        return $optionId;
    }

    /**
     * @return array
     */
    protected function getSFilterArticlesList()
    {
        $sFilterArticleList = Shopware()->Db()->fetchAll(
            "
                SELECT
                  sfa.valueID as `valueID`, sfv.optionID as `optionID`,
                  sfv.value as `value`, sfo.name as `optionName`
                FROM s_filter_articles sfa
                LEFT JOIN s_filter_values sfv on sfv.id = sfa.valueID
                LEFT JOIN s_filter_options sfo on sfo.id = sfv.optionID
                WHERE sfa.articleID = ?
            ",
            array($this->getModel()->getId())
        );

        return $sFilterArticleList;
    }

    /**
     * @param $valueId
     *
     * @return \Shopware\Models\Property\Value
     */
    protected function getPropertyValue($valueId)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Property\Value');
        /** @var \Shopware\Models\Property\Value $propertyValuesList */
        $propertyValuesList = $repository->findOneBy(array('id' => $valueId));

        return $propertyValuesList;
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
