<?php
/**
 * SeoUrlAbstract.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Bf\Multichannel\Components\Util\ConfigManager;

abstract class SeoUrlAbstract
{
    const SEO_URL_PRODUCTS            = 'PRODUCTS';
    const SEO_URL_PRODUCTS_VARIATIONS = 'PRODUCTS_VARIATIONS';
    const ORG_PATH_PART               = 'sViewport=detail&sArticle=';

    /** @var integer $item */
    protected $itemId = null;

    /** @var array $sCoreRewriteUrlsInformation */
    protected $sCoreRewriteUrlsInformation = array();

    /** @var int */
    protected $variationId = 0;

    /**
     * @param integer $itemId
     * @param $variationId
     */
    public function __construct($itemId, $variationId = 0)
    {
        $this->itemId                      = $itemId;
        $this->variationId                 = $variationId;
        $this->sCoreRewriteUrlsInformation = $this->generateSCoreRewriteUrlsInformation();
    }

    public function __destruct()
    {
        $this->itemId                      = null;
        $this->sCoreRewriteUrlsInformation = array();
        $this->variationId                 = 0;
    }

    /**
     * @return mixed
     */
    private function generateSCoreRewriteUrlsInformation()
    {
        $result = Shopware()->Db()->fetchRow(
            "
                select * from s_core_rewrite_urls where org_path = ? and main = ?
            ",
            array(self::ORG_PATH_PART . $this->getItemId(), 1), 2);

        if(is_bool($result)) {
            $result = [];
        }

        return $result;
    }

    /**
     * @return string
     */
    protected function getHostInformation()
    {
        $secureResult = Shopware()->Db()->fetchOne('select host from s_core_shops where `default` = ? and active = ?', array(1, 1));

        $hostInformation = ConfigManager::getInstance()->getServerProtocol() . rtrim($secureResult, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;

        return $hostInformation;
    }

    /**
     * @return int
     */
    public function getItemId()
    {
        return $this->itemId;
    }

    /**
     * @param int $itemId
     */
    public function setItemId($itemId)
    {
        $this->itemId = $itemId;
    }

    /**
     * @return array
     */
    public function getSCoreRewriteUrlsInformation()
    {
        return $this->sCoreRewriteUrlsInformation;
    }

    /**
     * @param array $sCoreRewriteUrlsInformation
     */
    public function setSCoreRewriteUrlsInformation($sCoreRewriteUrlsInformation)
    {
        $this->sCoreRewriteUrlsInformation = $sCoreRewriteUrlsInformation;
    }

    /**
     * @return int
     */
    public function getVariationId()
    {
        return $this->variationId;
    }

    /**
     * @param int $variationId
     */
    public function setVariationId($variationId)
    {
        $this->variationId = $variationId;
    }

    abstract public function setBfApiSeoUrls($seoType = self::SEO_URL_PRODUCTS);
}