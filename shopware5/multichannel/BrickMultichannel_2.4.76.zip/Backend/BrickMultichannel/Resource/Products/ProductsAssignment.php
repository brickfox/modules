<?php
/**
 * ProductsAssignment
 *
 * @package   Bf\Multichannel\Components\Resource\Products
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Bf\Multichannel\Components\Util\FileWriter;
use League\Flysystem\Exception;

class ProductsAssignment
{
    const ASSIGNMENT_TYPE_CROSS_SELLING = 'crossselling';
    const ASSIGNMENT_TYPE_ACCESSORIES   = 'accessories';

    private $productsModel;

    /**
     * @param $productsModel
     */
    public function __construct($productsModel)
    {
        $this->productsModel = $productsModel;
    }

    /**
     * @param $exportNum
     *
     * @throws Exception
     */
    public function prepareProductsAssignmentsNode($exportNum)
    {
        FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter] = array(
            '@attributes' => array('num' => $exportNum),
            'ProductId'   => array('@value' => $this->getProductsModel()->getId())
        );

        if($this->getProductsModel()->getRelated()->count() > 0)
        {
            $internalKey = 1;

            /** @var \Shopware\Models\Article\Article $related */
            foreach($this->getProductsModel()->getRelated() as $related)
            {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Assignments'][] = array(
                    'Assignment' => array(
                        '@attributes' => array('type' => self::ASSIGNMENT_TYPE_ACCESSORIES, 'sort' => $internalKey),
                        'ProductId'   => array('@value' => $related->getId())
                    )
                );

                $internalKey++;
            }
        }

        if($this->getProductsModel()->getSimilar()->count() > 0)
        {
            $internalKey = 1;

            /** @var \Shopware\Models\Article\Article $similar */
            foreach($this->getProductsModel()->getSimilar() as $similar)
            {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Assignments'][] = array(
                    'Assignment' => array(
                        '@attributes' => array('type' => self::ASSIGNMENT_TYPE_CROSS_SELLING, 'sort' => $internalKey),
                        'ProductId'   => array('@value' => $similar->getId())
                    )
                );
            }
        }

        if($this->getProductsModel()->getRelated()->count() <= 0 && $this->getProductsModel()->getSimilar()->count() <= 0)
        {
            throw new Exception("No related or simiar articles found for product with order number: " . $this->getProductsModel()->getMainDetail()->getNumber());
        }
    }

    /**
     * @return \Shopware\Models\Article\Article
     */
    public function getProductsModel()
    {
        return $this->productsModel;
    }

    /**
     * @param mixed $productsModel
     *
     * @return ProductsAssignment
     */
    public function setProductsModel($productsModel)
    {
        $this->productsModel = $productsModel;

        return $this;
    }
}
