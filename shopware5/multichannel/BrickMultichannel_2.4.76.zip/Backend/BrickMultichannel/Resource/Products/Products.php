<?php
/**
 * Products
 *
 * @package   Bf\Multichannel\Components\Resource\Products
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Bf\Multichannel\Components\Resource\Categories\Categories;
use Bf\Multichannel\Components\Resource\Variations\Variations;
use Bf\Multichannel\Components\Util\Exceptions\SkipItemExportException;
use Bf\Multichannel\Components\Util\FileWriter;
use Exception;

class Products extends ProductsAbstract
{
    private $model;

    /**
     * @param $model
     */
    public function __construct($model)
    {
        $this->model = $model;
    }

    /**
     * @throws SkipItemExportException
     * @throws Exception
     */
    public function prepareProductNode()
    {
        $taxRate = $this->getModel()->getTax()->getTax();
        $taxRate = number_format($taxRate, 2, '.', '');

        $mainDetailModel = $this->getModel()->getMainDetail();

        if($mainDetailModel === null) {
            $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Detail');
            /** @var \Shopware\Models\Article\Detail $mainDetailModel */
            $mainDetailModel = $repository->findOneBy(
                array(
                    'article' => $this->getModel()->getId(),
                    'kind'      => 1
                ));

            if($mainDetailModel === null) {
                throw new Exception('missing main s_articles_details');
            }
        }

        FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter] = [
            'ProductExternId' => ['@value' => $this->getModel()->getId()],
            'ItemNumber'      => ['@value' => $mainDetailModel->getNumber()],
            'Active'          => ['@value' => (int)$this->getModel()->getActive()],
            'TaxClass'        => ['@value' => $this->getTaxClassByTaxId($this->getModel())],
            'TaxRate'         => ['@value' => $taxRate],
            'Manufacturer'    => ['@cdata' => $this->getSupplierName()]
        ];

        $attributesKeyCounter = (new Attributes($this->getModel()))->prepareAttributesNode();
        (new Property($this->getModel()))->preparePropertyNode($attributesKeyCounter);
        (new Categories($this->getModel()->getCategories()))->prepareCategoriesNode();
        (new Descriptions($this->getModel()))->prepareDescriptionNode();
        (new Images($this->getModel()))->prepareImagesNode();
        (new Media($this->getModel()))->prepareMediaNode();
        (new Variations($this->getModel()))->prepareVariationsNode();
    }

    /**
     * @return \Shopware\Models\Article\Article
     */
    public function getModel()
    {
        return $this->model;
    }

    /**
     * @param mixed $model
     *
     * @return Products
     */
    public function setModel($model)
    {
        $this->model = $model;

        return $this;
    }

    /**
     * @return string
     * @throws \Exception
     */
    private function getSupplierName()
    {
        if ($this->getModel()->getSupplier() === null) {
            throw new Exception('No supplier is assigned for product');
        }

        return $this->getModel()->getSupplier()->getName();
    }

    public function __destruct()
    {
        $this->model = null;
    }
}
