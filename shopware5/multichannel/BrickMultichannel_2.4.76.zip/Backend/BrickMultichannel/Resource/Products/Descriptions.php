<?php
/**
 * Descriptions
 *
 * @package   Bf\Multichannel\Components\Resource\Products
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Bf\Multichannel\Components\Resource\Translation\TranslationAbstract;
use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\FileManager;
use Bf\Multichannel\Components\Util\FileWriter;
use Bf\Multichannel\Components\Util\Helper;
use Bf\Multichannel\Components\Util\LogCodes;
use Bf\Multichannel\Components\Util\LogManager;

class Descriptions extends TranslationAbstract
{
    const EXPORT_TYPE                    = FileManager::FILENAME_BASE_PRODUCTS;
    const BULLET_POINTS_MAX_COUNTER      = 10;
    const SHOPWARE_REWRITE_URLS_ORG_PATH = 'sViewport=detail&sArticle=';

    /**
     * @param \Shopware\Models\Article\Article $model
     */
    public function __construct($model)
    {
        parent::__construct($model);
    }

    public function prepareDescriptionNode()
    {
        if (strlen($this->getModel()->getName()) <= 0) {
            LogManager::getInstance()
                ->createDbLogEntry(time(), self::EXPORT_TYPE, LogCodes::EXPORT_DESCRIPTION_NO_PRODUCTS_NAME_CODE,
                    str_replace('{$itemNumber}', $this->getModel()->getMainDetail()->getNumber(), LogCodes::EXPORT_DESCRIPTION_NO_PRODUCTS_NAME));
        }

        $key = 0;

        //Ändern der Abfrage damit MultiSHop Exporte nicht mehr an die Übersetzugen gehen.
        if (ConfigManager::getInstance()->getIsMultiShop() === true) {

            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Descriptions'][$key] = array(
                'Description' => array(
                    '@attributes'      => array(
                        'lang' => $this->getMultiShopLanguageCode()
                    ),
                    'Title'            => array('@cdata' => $this->getModel()->getName()),
                    'ShortDescription' => array('@cdata' => Helper::removeControlChars($this->getModel()->getDescription())),
                    'LongDescription'  => array('@cdata' => Helper::removeControlChars($this->getModel()->getDescriptionLong())),
                    'SearchKeys'       => array('@cdata' => $this->getModel()->getKeywords()),
                    'ProductUrl'       => array('@cdata' => $this->getProductsUrl())
                )
            );
        } else {
            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Descriptions'][$key] = array(
                'Description' => array(
                    '@attributes'      => array(
                        'lang' => $this->getMainLanguageCode()
                    ),
                    'Title'            => array('@cdata' => $this->getModel()->getName()),
                    'ShortDescription' => array('@cdata' => Helper::removeControlChars($this->getModel()->getDescription())),
                    'LongDescription'  => array('@cdata' => Helper::removeControlChars($this->getModel()->getDescriptionLong())),
                    'SearchKeys'       => array('@cdata' => $this->getModel()->getKeywords()),
                    'ProductUrl'       => array('@cdata' => $this->getProductsUrl())
                )
            );
        }

        $this->addBulletPoints($key);
        $key++;

        if ((bool) ConfigManager::getInstance()->getMultiLanguagesExport()->getConfigurationValue() === true) {
            $this->getItemTranslations();

            if ($this->getTranslationCollection() > 0) {
                $this->writerDescriptionsTranslations($key);
            }
        }


    }

    /**
     * @return string
     */
    private function getProductsUrl()
    {
        $seoUrlClass = new SeoUrl($this->getModel()->getId());
        $seoUrl      = $seoUrlClass->prepareSeoUrl();

        if (isset($seoUrlClass->getSCoreRewriteUrlsInformation()['org_path']) === true) {
            $orgPath = $seoUrlClass->getSCoreRewriteUrlsInformation()['org_path'];
        } else {
            $orgPath = '';
        }

        $seoUrlClass->setBfApiSeoUrls($seoUrl, $orgPath);

        return $seoUrl;
    }

    /**
     * @param null $counter
     */
    private function writerDescriptionsTranslations($counter = null)
    {
        foreach ($this->getTranslationCollection() as $key => $translationElement) {
            if ($counter === null) {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Descriptions'][0] = array(
                    'Description' => array(
                        '@attributes'      => array(
                            'lang' => $translationElement['lang']
                        ),
                        'Title'            => array('@cdata' => $translationElement['Title']),
                        'ShortDescription' => array('@cdata' => Helper::removeControlChars($translationElement['ShortDescription'])),
                        'LongDescription'  => array('@cdata' => Helper::removeControlChars($translationElement['LongDescription'])),
                        'SearchKeys'       => array('@cdata' => $translationElement['SearchKeys'])
                    )
                );
            } else {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Descriptions'][$counter] = array(
                    'Description' => array(
                        '@attributes'      => array(
                            'lang' => $translationElement['lang']
                        ),
                        'Title'            => array('@cdata' => $translationElement['Title']),
                        'ShortDescription' => array('@cdata' => Helper::removeControlChars($translationElement['ShortDescription'])),
                        'LongDescription'  => array('@cdata' => Helper::removeControlChars($translationElement['LongDescription'])),
                        'SearchKeys'       => array('@cdata' => $translationElement['SearchKeys'])
                    )
                );
                $counter++;
            }
        }
    }

    /**
     * @param $key
     */
    private function addBulletPoints($key)
    {
        if (ConfigManager::getInstance()->getAttributesAsBulletPointsDescriptionConfiguration() !== null &&
            strlen(ConfigManager::getInstance()->getAttributesAsBulletPointsDescriptionConfiguration()->getConfigurationValue()) > 0
        ) {
            $configurationValue = explode(',', ConfigManager::getInstance()->getAttributesAsBulletPointsDescriptionConfiguration()->getConfigurationValue());
            $sort               = 0;
            $counter            = 1;

            if (count($configurationValue) > 0) {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Descriptions'][$key]['Description']['BulletPoints'] = [];
            }

            foreach ($configurationValue as $columnHeaders) {
                $getter = ucwords($columnHeaders, '_');
                $getter = 'get' . ucfirst($getter);
                $getter = str_replace('_', '', $getter);

                if (is_object($this->getModel()) === true && method_exists($this->getModel()->getMainDetail()->getAttribute(), $getter) === true) {
                    if (strlen($this->getModel()->getMainDetail()->getAttribute()->$getter()) > 0) {
                        FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Descriptions'][$key]['Description']['BulletPoints'][] = array(
                            'Bullet-' . $counter => array(
                                '@attributes' => array(
                                    'sort' => $sort
                                ),
                                '@cdata'      => $this->getModel()->getMainDetail()->getAttribute()->$getter()
                            )
                        );

                        ++$sort;
                        ++$counter;
                    }
                } elseif (is_object($this->getModel()) === true) {
                    $filterValuesForOption = $this->getFilterValuesForOptionsByArticle($columnHeaders);

                    if (strlen($filterValuesForOption) > 0) {
                        FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Descriptions'][$key]['Description']['BulletPoints'][] = array(
                            'Bullet-' . $counter => array(
                                '@attributes' => array(
                                    'sort' => $sort
                                ),
                                '@cdata'      => $filterValuesForOption
                            )
                        );

                        ++$sort;
                        ++$counter;
                    }
                }

                if ($counter === self::BULLET_POINTS_MAX_COUNTER) {
                    break;
                }
            }
        }
    }

    /**
     * @param $filterOptionName
     *
     * @return string
     */
    private function getFilterValuesForOptionsByArticle($filterOptionName)
    {
        $filterAsBullet         = '';
        $repositoryFilterOption = Shopware()->Models()->getRepository('Shopware\Models\Property\Option');
        /** @var \Shopware\Models\Property\Option $optionModel */
        $optionModel = $repositoryFilterOption->findOneBy(array('name' => $filterOptionName));

        if ($optionModel !== null) {
            $optionId   = $optionModel->getId();
            $filterList = Shopware()->Db()->fetchAll("
                    select * from s_filter_articles sfa
                    left join s_filter_values sfv on sfv.id = sfa.valueID
                    left join s_filter_options sfo on sfo.id = sfv.optionID
                    where sfa.articleID = ? and sfv.optionID = ?
                ", array($this->getModel()->getId(), $optionId));

            if (count($filterList) > 0) {
                $array   = array_keys($filterList);
                $lastKey = end($array);

                foreach ($filterList as $key => $filter) {
                    if (strlen($filterAsBullet) === 0) {
                        $filterAsBullet .= $filter['name'] . ': ';
                    }

                    if ($key === $lastKey) {
                        $filterAsBullet .= $filter['value'];
                    } else {
                        $filterAsBullet .= $filter['value'] . ', ';
                    }
                }
            }
        }

        return $filterAsBullet;
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
