<?php
/**
 * Created by PhpStorm.
 * User: bastiankurz
 * Date: 19.08.15
 * Time: 22:27
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Bf\Multichannel\Components\Interfaces\ProductsInterface;
use Bf\Multichannel\Components\Util\FileWriter;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\PersistentCollection;

class Media extends MediaAbstract implements ProductsInterface
{
    private $model;

    /** @var int */
    private $sort = 1;

    /**
     * @param \Shopware\Models\Article\Article $model
     */
    public function __construct($model)
    {
        $this->model = $model;
    }

    public function prepareMediaNode()
    {
        $mediaService = Shopware()->Container()->get('shopware_media.media_service');

        if($this->getModel()->getDownloads()->count() > 0)
        {
            /** @var \Shopware\Models\Article\Download $download */
            foreach($this->prepareDownloadContent($this->getModel()->getDownloads()) as $download)
            {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Media'][] = array(
                    'MediaEntry' => array(
                        '@attributes' => array(
                            'sort'    => $this->sort,
                            'changed' => $this->evaluateMediaChangedStatus($this->getModel()->getId(), $download->getId())
                        ),
                        'Path'        => array('@value' => $mediaService->getUrl($download->getFile())),
                        'Name'        => array('@cdata' => $download->getName()),
                        'Type'        => array('@value' => $this->getMediaTypeByMediaFile($download->getFile()))
                    )
                );

                $this->sort++;
            }
        }
    }

    /**
     * @param ArrayCollection|PersistentCollection $downloadArrayCollection
     *
     * @return \Generator
     */
    private function prepareDownloadContent($downloadArrayCollection)
    {
        $downloadContent = array();

        /** @var \Shopware\Models\Article\Download $download */
        foreach($downloadArrayCollection as $download)
        {
            $downloadContent[] = $download;
        }

        return $downloadContent;
    }

    /**
     * @return \Shopware\Models\Article\Article
     */
    public function getModel()
    {
        return $this->model;
    }

    /**
     * @param mixed $model
     *
     * @return Products
     */
    public function setModel($model)
    {
        $this->model = $model;

        return $this;
    }

    public function __destruct()
    {
        $this->model = null;
    }
}