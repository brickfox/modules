<?php
/**
 * Created by PhpStorm.
 * User: bastiankurz
 * Date: 19.08.15
 * Time: 22:20
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Bf\Multichannel\Components\Interfaces\ProductsInterface;
use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\FileManager;
use Bf\Multichannel\Components\Util\FileWriter;
use Bf\Multichannel\Components\Util\Helper;
use Bf\Multichannel\Components\Util\LogManager;
use Doctrine\ORM\EntityNotFoundException;
use Exception;

class Images extends MediaAbstract implements ProductsInterface
{
    private $model;

    /**
     * @param \Shopware\Models\Article\Article $model
     */
    public function __construct($model)
    {
        $this->model = $model;
    }

    public function prepareImagesNode()
    {
        $writtenImage = false;
        $mediaService = null;
        $imageCounter = 0;

        if($this->getModel()->getImages()->count() > 0)
        {
            if(ConfigManager::getInstance()->getShopwareVersion() === 5.1)
            {
                $mediaService = Shopware()->Container()->get('shopware_media.media_service');
            }

            if(strlen(Helper::getConfigurationByKey('imageAttributesKeyWords')->getConfigurationValue()) > 0)
            {
                $this->setImageAttributesValues(explode(',', Helper::getConfigurationByKey('imageAttributesKeyWords')->getConfigurationValue()));
            }

            $isAlwaysExportPreviewImage = (bool)ConfigManager::getInstance()->isBaseProductExportPreviewImageAlways();
            $hasPreviewImage = false;
            $images = $this->prepareImageContent($this->getModel()->getImages(), self::IMAGE_EXPORT_TYPE_PRODUCT);

            usort($images, function ($imageA) {
                return $imageA[1]->getMain() === 1 ? -1 : 0;
            });

            try
            {
                /** @var \Shopware\Models\Article\Image $image */
                foreach($images as $imageType => $image)
                {
                    if(count($this->getImageAttributesValues()) > 0)
                    {
                        $writable                    = false;
                        $attributeCounter            = 1;
                        $attributeHeaderColumns      = $this->getImageAttributesHeaderColumns();
                        $exportImageAttributesValues = $this->getExportImagesAttributesValues();

                        if(count($attributeHeaderColumns) > 0)
                        {
                            try
                            {
                                foreach($attributeHeaderColumns as $columns)
                                {
                                    $getter = ucwords($columns, '_');
                                    $getter = 'get' . ucfirst($getter);
                                    $getter = str_replace('_', '', $getter);

                                    if($image[1]->getAttribute() !== null)
                                    {
                                        if(method_exists($image[1]->getAttribute(), $getter) === true)
                                        {
                                            if($image[1]->getAttribute()->$getter() !== null)
                                            {
                                                if(in_array($image[1]->getAttribute()->$getter(), $this->getImageAttributesValues()) === true)
                                                {
                                                    $exportImageAttributesValues['ImageAttribute' . $attributeCounter] = array(
                                                        '@attributes' => array('code' => self::EXPORT_IMAGES_ATTRIBUTES_CODE),
                                                        'Name'        => array('@cdata' => $image[1]->getAttribute()->$getter())
                                                    );
                                                    $this->setExportImagesAttributesValues($exportImageAttributesValues);
                                                    $writable = true;
                                                    ++$attributeCounter;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            catch(Exception $e)
                            {
                                LogManager::getInstance()->logException($e, FileManager::FILENAME_BASE_PRODUCTS);
                            }
                        }
                    }
                    else
                    {
                        $writable = true;
                    }

                    if($writable === true && is_object($image[1]->getMedia()) === true)
                    {
                        try {

                            if($isAlwaysExportPreviewImage === true && $image[1]->getMain() === 1) {
                                $hasPreviewImage = true;
                                $sortOrder = 1;
                            } else if($isAlwaysExportPreviewImage === true && $hasPreviewImage === true) {
                                // in the regular case shopware images are sorted upwards from 1->n
                                // this can be different for some customers that use custom product imports
                                $sortOrder = max(1, $image[1]->getPosition) + 1;
                            } else {
                                $sortOrder = $image[1]->getPosition();
                            }

                            $path = $this->getImagePath($mediaService, $image);

                            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Images'][] = array(
                                'Image' => array(
                                    '@attributes' => array(
                                        'sort'    => $sortOrder,
                                        'changed' => 1
                                    ),
                                    'Name'        => array('@cdata' => $image[1]->getDescription()),
                                    'Path'        => array('@value' => $path)
                                )
                            );
                        } catch(EntityNotFoundException $e) {
                            LogManager::getInstance()->logException($e, FileManager::FILENAME_BASE_PRODUCTS);
                        }

                        if(count($this->getExportImagesAttributesValues()) > 0)
                        {
                            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Images'][$imageCounter]['Image']['ImageAttributes'] = array(
                                $this->getExportImagesAttributesValues()
                            );
                        }

                        $writtenImage = true;
                        $imageCounter++;
                    }

                    $this->setExportImagesAttributesValues(array());
                }
            }
            catch(Exception $e)
            {
                LogManager::getInstance()->logException($e, FileManager::FILENAME_BASE_PRODUCTS);
            }

            if($writtenImage === false)
            {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Images'] = array();
            }
        }
        else
        {
            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Images'] = array();
        }
    }

    /**
     * @return \Shopware\Models\Article\Article
     */
    public function getModel()
    {
        return $this->model;
    }

    /**
     * @param mixed $model
     *
     * @return Products
     */
    public function setModel($model)
    {
        $this->model = $model;

        return $this;
    }

    public function __destruct()
    {
        $this->model     = null;
        $this->xmlWriter = null;
    }
}