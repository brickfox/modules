<?php
/**
 * Property
 *
 * @package   Bf\Multichannel\Components\Resource\Products
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\FileWriter;
use Bf\Multichannel\Components\Util\Helper;

class Property extends PropertyAbstract
{
    /** @var int */
    private $internalAttributeKey;

    public function __construct($model)
    {
        parent::__construct($model);
    }

    /**
     * @throws \Exception
     */
    public function preparePropertyNode($internalKey = 0)
    {
        $this->internalAttributeKey = $internalKey;

        FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Attributes'][$this->internalAttributeKey] = array();

        $sFilterArticlesList = $this->getSFilterArticlesList();

        if (count($sFilterArticlesList) > 0) {
            $tmpPropertyArr = array();
            foreach ($sFilterArticlesList as $sFilterArticles) {
                $tmpPropertyArr[$sFilterArticles['optionID']][] = array(
                    'optionName'    => $sFilterArticles['optionName'],
                    'optionValue'   => $sFilterArticles['value'],
                    'optionValueId' => $sFilterArticles['valueID']
                );
            }

            $this->writeProperties($tmpPropertyArr, ConfigManager::getInstance()->getExportMultivaluedPropertiesAsSingleAttributes());
        }
    }

    public function __destruct()
    {
        parent::__destruct();
    }

    /**
     * @param array $propertyArr
     * @param bool $exportMultivaluedPropertiesAsSingleAttributes
     * @throws \Exception
     */
    private function writeProperties(array $propertyArr, $exportMultivaluedPropertiesAsSingleAttributes = false)
    {
        if($propertyArr <= 0) {
            return;
        }

        if($exportMultivaluedPropertiesAsSingleAttributes === true) {
            $this->exportPropertiesAsSingleAttributes($propertyArr);
        } else {
            $this->exportProperties($propertyArr);
        }
    }

    /**
     * @param array $propertyArr
     * @throws \Exception
     */
    private function exportProperties(array $propertyArr)
    {
        foreach ($propertyArr as $optionId => $key) {
            $count       = 1;
            $optionValue = '';
            $optionName  = null;
            $valueIds    = array();

            foreach ($key as $propertyContent) {
                if ($optionName === null) {
                    $optionName = $propertyContent['optionName'];
                }

                if ($count === 1) {
                    $optionValue .= $propertyContent['optionValue'];
                } else {
                    $optionValue .= ', ' . $propertyContent['optionValue'];
                }

                $valueIds[$count] = $propertyContent['optionValueId'];

                ++$count;
            }

            if (strlen($optionName) > 0 && strlen($optionValue) > 0) {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Attributes'][$this->internalAttributeKey] = array(
                    'String' => array(
                        'Translations' => array(
                            array(
                                'Translation' => array(
                                    '@attributes' => array('lang' => $this->getMainLanguageCode()),
                                    'Name'        => array('@cdata' => Helper::removeControlChars($optionName)),
                                    'Value'       => array('@cdata' => Helper::removeControlChars($optionValue))
                                )
                            )
                        )
                    )
                );

                if (
                    ConfigManager::getInstance()->getIsMultiShop() === true ||
                    (bool)ConfigManager::getInstance()->getMultiLanguagesExport()->getConfigurationValue() === true
                ) {
                    $translations = [];

                    foreach ($valueIds as $valueId) {
                        foreach ($this->getPropertyTranslations($optionId, [$valueId]) as $isoCode => $propertyTranslation) {
                            $translationsData = $this->getTranslationsFallback($isoCode, $propertyTranslation, $optionName, $optionValue);

                            $translations[$isoCode]['name'] = Helper::removeControlChars($translationsData['name']);

                            if(!empty($translations[$isoCode]['value'])) {
                                if(!empty($translationsData['value'])) {
                                    $translations[$isoCode]['value'] .= ', ' . Helper::removeControlChars($translationsData['value']);
                                }
                            } else {
                                $translations[$isoCode]['value'] = Helper::removeControlChars($translationsData['value']);
                            }
                        }
                    }

                    foreach ($translations as $isoCode => $translation) {
                        if(!empty($translation['name']) && !empty($translation['value'])) {
                            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Attributes'][$this->internalAttributeKey]['String']['Translations'][] = [
                                'Translation' => [
                                    '@attributes' => ['lang' => $isoCode],
                                    'Name'        => ['@cdata' => $translation['name']],
                                    'Value'       => ['@cdata' => $translation['value']]
                                ]
                            ];
                        }
                    }
                }

                ++$this->internalAttributeKey;
            }
        }
    }

    /**
     * @param array $propertyArr
     * @throws \Exception
     */
    private function exportPropertiesAsSingleAttributes(array $propertyArr)
    {
        foreach ($propertyArr as $optionId => $key) {
            foreach ($key as $value) {
                $optionName = $value['optionName'];
                $optionValue = $value['optionValue'];
                $valueId = $value['optionValueId'];

                if (strlen($optionName) > 0 && strlen($optionValue) > 0) {
                    FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Attributes'][$this->internalAttributeKey] = array(
                        'String' => array(
                            'Translations' => array(
                                array(
                                    'Translation' => array(
                                        '@attributes' => array('lang' => $this->getMainLanguageCode()),
                                        'Name'        => array('@cdata' => Helper::removeControlChars($optionName)),
                                        'Value'       => array('@cdata' => Helper::removeControlChars($optionValue))
                                    )
                                )
                            )
                        )
                    );

                    if (
                        ConfigManager::getInstance()->getIsMultiShop() === true ||
                        (bool)ConfigManager::getInstance()->getMultiLanguagesExport()->getConfigurationValue() === true
                    ) {
                        foreach ($this->getPropertyTranslations($optionId, [$valueId]) as $isoCode => $propertyTranslation) {
                            $translationsData = $this->getTranslationsFallback($isoCode, $propertyTranslation, $optionName, $optionValue);

                            if(!empty($translationsData['name']) && !empty($translationsData['value'])) {
                                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Attributes'][$this->internalAttributeKey]['String']['Translations'][] = [
                                    'Translation' => [
                                        '@attributes' => ['lang' => $isoCode],
                                        'Name'        => ['@cdata' => Helper::removeControlChars($translationsData['name'])],
                                        'Value'       => ['@cdata' => Helper::removeControlChars($translationsData['value'])]
                                    ]
                                ];
                            }
                        }
                    }

                    ++$this->internalAttributeKey;
                }
            }
        }
    }

    /**
     * @param string $isoCode
     * @param array $propertyTranslation
     * @param string $optionName
     * @param string $optionValue
     * @return array
     */
    private function getTranslationsFallback($isoCode, $propertyTranslation, $optionName, $optionValue)
    {
        $useFallbackToMain = false;

        if (strlen($this->getBfMappingTranslations()[$isoCode]['fallback_field_key']) > 0) {
            foreach ($this->getBfMappingTranslations() as $bfMappingTranslation) {
                if (
                    $bfMappingTranslation['mapping_field_key'] === $this->getBfMappingTranslations()[$isoCode]['fallback_field_key'] &&
                    $bfMappingTranslation['main'] === true
                ) {
                    $useFallbackToMain = true;

                    break;
                }
            }
        }
        $translatedOptionName = $propertyTranslation['propertyoption'];
        if (strlen($translatedOptionName) === 0 && $useFallbackToMain === true) {
            $translatedOptionName = $optionName;
        }

        $translatedOptionValue = $propertyTranslation['propertyvalue'];
        if (strlen($translatedOptionValue) === 0 && $useFallbackToMain === true) {
            $translatedOptionValue = $optionValue;
        }

        return array(
            'name' => $translatedOptionName,
            'value' => $translatedOptionValue
        );
    }
}
