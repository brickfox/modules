<?php
/**
 * ProductsAbstract
 *
 * @package   Bf\Multichannel\Components\Resource\Products
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Shopware\Models\Article\Article as SwArticle;

abstract class ProductsAbstract
{
    const STANDARD_TAX_CLASS = 'standard';

    /**
     * @param SwArticle $article
     *
     * @return string
     */
    protected function getTaxClassByTaxId(SwArticle $article)
    {
        $taxClass = self::STANDARD_TAX_CLASS;

        try {
            $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingTaxRates');
            /** @var \Shopware\CustomModels\BfMultichannel\MappingTaxRates $mappingTaxRates */
            $mappingTaxRates = $repository->findOneBy(['mappingFieldKey' => $article->getTax()->getId()]);
            if ($mappingTaxRates !== null) {
                $taxClass = $mappingTaxRates->getBrickfoxTaxClass();
            }
        } catch (\Exception $exception) {
        }

        return $taxClass;
    }
}
