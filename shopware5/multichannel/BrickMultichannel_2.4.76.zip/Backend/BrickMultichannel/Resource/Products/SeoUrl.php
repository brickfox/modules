<?php
/**
 * SeoUrl.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Shopware\CustomModels\BfMultichannel\ApiExportSeoUrls;

class SeoUrl extends SeoUrlAbstract
{
    /**
     * @param integer $itemId
     * @param $variationId
     */
    public function __construct($itemId, $variationId = 0)
    {
        parent::__construct($itemId, $variationId);
    }

    public function __destruct()
    {
        parent::__destruct();
    }

    /**
     * @param string $seoType
     *
     * @return string
     */
    public function prepareSeoUrl($seoType = self::SEO_URL_PRODUCTS)
    {
        $seoUrl = '';

        switch($seoType)
        {
            case self::SEO_URL_PRODUCTS:
                $seoUrl = $this->generateProductsSeoUrl();
                break;

            case self::SEO_URL_PRODUCTS_VARIATIONS:
                $seoUrl = $this->generateProductsVariationsSeoUrl();
                break;

            default:
                break;
        }

        return $seoUrl;
    }

    /**
     * @return string
     */
    private function generateProductsVariationsSeoUrl()
    {
        $seoUrl = '';

        if(count($this->getSCoreRewriteUrlsInformation()) > 0)
        {
            $sArticlesDetailsOrderNumber = Shopware()->Db()->fetchOne(
                "
                    select ordernumber from s_articles_details where articleID = ? and id = ?
                ",
                array($this->getItemId(), $this->getVariationId())
            );

            if(strlen($sArticlesDetailsOrderNumber) > 0 && isset($this->getSCoreRewriteUrlsInformation()['path']) === true &&
               strlen($this->getSCoreRewriteUrlsInformation()['path']) > 0
            )
            {
                $seoUrl = $this->getHostInformation() . $this->getSCoreRewriteUrlsInformation()['path'] . '?number=' . $sArticlesDetailsOrderNumber;
            }
        }

        return $seoUrl;
    }

    /**
     * @return string
     */
    private function generateProductsSeoUrl()
    {
        $seoUrl = '';

        if(count($this->getSCoreRewriteUrlsInformation()) > 0 && isset($this->getSCoreRewriteUrlsInformation()['path']) === true &&
           strlen($this->getSCoreRewriteUrlsInformation()['path']) > 0
        )
        {
            $seoUrl = $this->getHostInformation() . $this->getSCoreRewriteUrlsInformation()['path'];
        }

        return $seoUrl;
    }

    public function setBfApiSeoUrls($seoUrl = '', $originalUrl = '', $seoType = self::SEO_URL_PRODUCTS)
    {
        $bfApiExportSeoUrlsRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportSeoUrls');

        /** @var \Shopware\CustomModels\BfMultichannel\ApiExportSeoUrls $bfApiExportSeoUrlsModel */
        switch($seoType)
        {
            case self::SEO_URL_PRODUCTS_VARIATIONS:
                $bfApiExportSeoUrlsModel = $bfApiExportSeoUrlsRepository->findOneBy(
                    array('brickfoxExternId' => $this->getItemId(), 'shopwareDetailsId' => $this->getVariationId())
                );
                $shopwareId              = $this->getItemId();
                $shopwareDetailsId       = $this->getVariationId();
                $brickfoxExternId        = $this->getItemId();
                break;

            default:
                $bfApiExportSeoUrlsModel = $bfApiExportSeoUrlsRepository->findOneBy(array('brickfoxExternId' => $this->getItemId(), 'shopwareDetailsId' => null));
                $shopwareId              = $this->getItemId();
                $brickfoxExternId        = $this->getItemId();
                $shopwareDetailsId       = null;
                break;
        }

        if($bfApiExportSeoUrlsModel === null)
        {
            $bfApiExportSeoUrlsModel = new ApiExportSeoUrls();
            $bfApiExportSeoUrlsModel->setBrickfoxExternId($brickfoxExternId);
            $bfApiExportSeoUrlsModel->setShopwareId($shopwareId);
            $bfApiExportSeoUrlsModel->setShopwareDetailsId($shopwareDetailsId);
            $bfApiExportSeoUrlsModel->setDateInsert(date('Y-m-d H:i:s', time()));
        }

        $bfApiExportSeoUrlsModel->setSeoPath($seoUrl);
        $bfApiExportSeoUrlsModel->setOriginalPath($originalUrl);
        $bfApiExportSeoUrlsModel->setLastUpdate(date('Y-m-d H:i:s', time()));

        Shopware()->Models()->persist($bfApiExportSeoUrlsModel);
    }
}