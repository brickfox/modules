<?php
/**
 * Attributes
 *
 * @package   Bf\Multichannel\Components\Resource\Products
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\FileWriter;
use Bf\Multichannel\Components\Util\Helper;

class Attributes extends AttributesAbstract
{
    /**
     * @param \Shopware\Models\Article\Article $model
     */
    public function __construct($model)
    {
        parent::__construct($model);
    }

    /**
     * @param int $key
     *
     * @return int
     */
    public function prepareAttributesNode($key = 0)
    {
        $internalKey = 0;
        if (method_exists($this->getModel(), 'getMainDetail') === true && $this->getModel()->getMainDetail() !== null &&
            method_exists($this->getModel()->getMainDetail(), 'getAttribute') === true) {
            $attributesModel = $this->getModel()->getMainDetail()->getAttribute();

            if ($attributesModel instanceof \Shopware\Models\Attribute\Article) {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Attributes'][$internalKey] = [];

                foreach ($this->getSingleAttributes($attributesModel) as $attributeElements) {
                    foreach ($attributeElements as $type => $attributesInformation) {
                        if ((bool)$attributesInformation['variantable'] === false) {
                            $brickfoxType = $this->detectBrickFoxAttributesType($type);

                            if (
                                empty($attributesInformation['Value']) === false
                                || strlen($attributesInformation['Value']) > 0
                            ) {
                                switch ($brickfoxType) {
                                    case self::BRICKFOX_TEXT_AREA_TYPE:
                                    case self::BRICKFOX_STRING_TYPE:
                                        $this->writeStringAttribute($key, $attributesInformation, $type, $internalKey);
                                        break;

                                    case self::BRICKFOX_DATE_TIME_TYPE:
                                    case self::BRICKFOX_INTEGER_TYPE:
                                    case self::BRICKFOX_FLOAT_TYPE:
                                    case self::BRICKFOX_BOOLEAN_TYPE:
                                        $this->writeNumericAttribute($key, $attributesInformation, $type, $internalKey);
                                        break;

                                    default:
                                        $this->writeStringAttribute($key, $attributesInformation, $type, $internalKey);
                                        break;
                                }
                                $internalKey++;
                            }
                        }
                    }
                }
            }
        }

        return $internalKey;
    }

    /**
     * @param $key
     * @param $attributesInformation
     * @param $type
     * @param $internalKey
     */
    protected function writeStringAttribute($key, $attributesInformation, $type, $internalKey)
    {
        $typeNumericOrString = self::ATTRIBUTES_TYPE_STRING_CODE;

        FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Attributes'][$internalKey] = [
            $this->detectBrickFoxAttributesType($type) => [
                '@attributes' => ['code' => $attributesInformation['attributesCode']],
                'Translations' => [
                    [
                        'Translation' => [
                            '@attributes' => ['lang' => $this->getMainLanguageCode()],
                            'Name' => ['@cdata' => Helper::removeControlChars($attributesInformation['Name'])],
                            'Value' => ['@cdata' => Helper::removeControlChars($attributesInformation['Value'])]
                        ]
                    ]
                ]
            ]
        ];

        // after talking with Sven it might be possible that there are customers with both true or 1 in these fields so allow both for now
        // 1 should be the default
        if ((bool)$attributesInformation['translatable'] === true &&
            ((ConfigManager::getInstance()->getIsMultiShop() === 'true'
                    || ConfigManager::getInstance()->getIsMultiShop() == '1')
                || (ConfigManager::getInstance()->getMultiLanguagesExport()->getConfigurationValue() === 'true'
                    || ConfigManager::getInstance()->getMultiLanguagesExport()->getConfigurationValue() == '1'))) {
            $this->getItemTranslations($attributesInformation);
            $this->writeTranslationAttribute($key, $type, $typeNumericOrString, $internalKey);
            $this->clearTranslationCollection();
        }
    }

    /**
     * @param $key
     * @param $attributesInformation
     * @param $type
     * @param $internalKey
     */
    protected function writeNumericAttribute($key, $attributesInformation, $type, $internalKey)
    {
        $value = $attributesInformation['Value'];
        if ($type === 'datetime') {
            $value = $attributesInformation['Value']->format('Y-m-d H:i:s');
        }

        FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Attributes'][$internalKey] = [
            $this->detectBrickFoxAttributesType($type) => [
                '@attributes' => ['code' => $attributesInformation['attributesCode']],
                'Value' => ['@cdata' => Helper::removeControlChars($value)],
                'Translations' => [
                    [
                        'Translation' => [
                            '@attributes' => ['lang' => $this->getMainLanguageCode()],
                            'Name' => ['@cdata' => Helper::removeControlChars($attributesInformation['Name'])],
                        ]
                    ]
                ]
            ]
        ];
    }

    /**
     * @param $key
     * @param $type
     * @param $typeNumericOrString
     * @param $internalKey
     */
    protected function writeTranslationAttribute($key, $type, $typeNumericOrString, $internalKey)
    {
        foreach ($this->getTranslationCollection() as $values) {
            if (isset($values['Value']) === true && strlen($values['Value']) > 0) {
                if ($typeNumericOrString === self::ATTRIBUTES_TYPE_STRING_CODE) {
                    FileWriter::$xmlElements['Product-' .
                    FileWriter::$internalArrayKeyCounter]['Attributes'][$internalKey][$this->detectBrickFoxAttributesType($type)]['Translations'][] = [
                        'Translation' => [
                            '@attributes' => ['lang' => $values['lang']],
                            'Name' => ['@cdata' => Helper::removeControlChars($values['Name'])],
                            'Value' => ['@cdata' => Helper::removeControlChars($values['Value'])]
                        ]
                    ];
                }
            }
        }
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
