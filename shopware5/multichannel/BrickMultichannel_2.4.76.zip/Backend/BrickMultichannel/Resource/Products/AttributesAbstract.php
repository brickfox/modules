<?php
/**
 * AttributesAbstract
 *
 * @package   Bf\Multichannel\Components\Resource\Products
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Bf\Multichannel\Components\Resource\Translation\TranslationAbstract;
use Bf\Multichannel\Components\Util\ConfigManager;
use Shopware\Models\Attribute\Article as SwAttributes;

abstract class AttributesAbstract extends TranslationAbstract
{
    const ATTRIBUTES_TYPE_STRING_CODE            = 'STRING';
    const ATTRIBUTES_TYPE_NUMERIC_CODE           = 'NUMERIC';
    const ATTR_CODE                              = 'attr';
    const SHOPWARE_STRING_TYPE                   = 'text';
    const SHOPWARE_TEXT_AREA_TYPE                = 'textarea';
    const SHOPWARE_BOOLEAN_TYPE                  = 'boolean';
    const SHOPWARE_SELECT_TYPE                   = 'select';
    const SHOPWARE_DATE_TYPE                     = 'date';
    const SHOPWARE_DATETIME_TYPE                 = 'datetime';
    const SHOPWARE_NUMBER_TYPE                   = 'number';
    const SHOPWARE_HTML_TYPE                     = 'html';
    const SHOPWARE_ARTICLE_TYPE                  = 'article';
    const BULLETS_AS_ATTRIBUTES                  = 'Bulletpoint_';
    const BRICKFOX_STRING_TYPE                   = 'String';
    const BRICKFOX_INTEGER_TYPE                  = 'Integer';
    const BRICKFOX_FLOAT_TYPE                    = 'Float';
    const BRICKFOX_BOOLEAN_TYPE                  = 'Boolean';
    const BRICKFOX_DATE_TIME_TYPE                = 'DateTime';
    const BRICKFOX_TEXT_AREA_TYPE                = 'Text';
    const SHOPWARE_ARTICLE_ATTRIBUTES_TABLE_NAME = 's_articles_attributes';
    const SHOPWARE_ATTRIBUTE_TRANSLATION_PREFIX  = '__attribute_';

    /**
     * @param \Shopware\Models\Article\Article|\Shopware\Models\Article\Detail $model
     */
    public function __construct($model)
    {
        parent::__construct($model);
    }

    /**
     * @param SwAttributes $attributes
     *
     * @return array
     */
    protected function getSingleAttributes(SwAttributes $attributes)
    {
        $singleAttributes = array();
        $attributeGetter  = $this->getAttributeGetter();

        if(count($attributeGetter) > 0)
        {
            foreach($attributeGetter as $attributeColumnHeader)
            {

                $attributeColumnsHeaderParts = explode('_', $attributeColumnHeader);
                $getter = '';

                $closure = function ($columnPart) use (&$getter) {
                    if(ctype_digit($columnPart) === true) {
                        $getter .= '_' . $columnPart;
                    } else {
                        $getter .= ucfirst($columnPart);
                    }
                };

                array_walk($attributeColumnsHeaderParts, $closure);

                $getter = 'get' . $getter;

                if(method_exists($attributes, $getter) === true)
                {
                    $sql    = $this->getAttributesQuery();
                    $result = Shopware()->Db()->fetchAll($sql, array(self::SHOPWARE_ARTICLE_ATTRIBUTES_TABLE_NAME, $attributeColumnHeader));

                    if(count($result) > 0)
                    {
                        $name           = $result[0]['label'];
                        $attributesCode = $attributeColumnHeader;

                        $singleAttributes[$attributeColumnHeader][$result[0]['type']] = array(
                            'Name'           => $name,
                            'Value'          => $attributes->$getter(),
                            'translatable'   => $result[0]['translatable'],
                            'variantable'    => 0,
                            'attributesCode' => $attributesCode
                        );

                        if($this->isVariationAttribute($attributeColumnHeader) === true)
                        {
                            $singleAttributes[$attributeColumnHeader][$result[0]['type']]['variantable'] = 1;
                        }
                    }
                }
            }
        }

        return $singleAttributes;
    }

    /**
     * @param $attributeColumnHeader
     *
     * @return bool
     */
    private function isVariationAttribute($attributeColumnHeader)
    {
        $isVariationsAttribute = false;

        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingAttributesVariations');
        /** @var \Shopware\CustomModels\BfMultichannel\MappingAttributesVariations $attributesVariationsModel */
        $attributesVariationsModel = $repository->findOneBy(array('attributesVariationsCode' => $attributeColumnHeader));

        if($attributesVariationsModel !== null)
        {
            $isVariationsAttribute = true;
        }

        return $isVariationsAttribute;
    }

    /**
     * @return array
     */
    private function getAttributeGetter()
    {
        $attributeGetter = array();

        $queryResult = Shopware()->Db()->fetchAll(
            "show columns from s_articles_attributes"
        );

        if(count($queryResult) > 0)
        {
            foreach($queryResult as $columns)
            {
                if($columns['Field'] !== 'id' && $columns['Field'] !== 'articleID' && $columns['Field'] !== 'articledetailsID')
                {
                    $attributeGetter[] = $columns['Field'];
                }
            }
        }

        return $attributeGetter;
    }

    /**
     * @param $type
     *
     * @return string
     */
    protected function detectBrickFoxAttributesType($type)
    {
        switch($type)
        {
            case self::SHOPWARE_SELECT_TYPE:
            case self::SHOPWARE_ARTICLE_TYPE:
            case self::SHOPWARE_STRING_TYPE:
                return self::BRICKFOX_STRING_TYPE;
                break;

            case self::SHOPWARE_TEXT_AREA_TYPE:
            case self::SHOPWARE_HTML_TYPE:
                return self::BRICKFOX_TEXT_AREA_TYPE;
                break;

            case self::SHOPWARE_BOOLEAN_TYPE:
                return self::BRICKFOX_BOOLEAN_TYPE;
                break;

            case self::SHOPWARE_DATETIME_TYPE:
            case self::SHOPWARE_DATE_TYPE:
                return self::BRICKFOX_DATE_TIME_TYPE;
                break;

            case self::SHOPWARE_NUMBER_TYPE:
                return self::BRICKFOX_FLOAT_TYPE;
                break;

            default:
                return self::BRICKFOX_STRING_TYPE;
                break;
        }
    }

    /**
     * @param array $attributesInformation
     * @param bool $isVariation
     */
    public function getItemTranslations($attributesInformation = null, $isVariation = false)
    {
        $id = ($isVariation === false) ? $this->getModel()->getId() : $this->getModel()->getArticle()->getId();

        $translationCollection = Shopware()->Db()->fetchAll(
            $this->getTranslationQuery(self::OBJECT_TYPE_TRANSLATION_CODE_ARTICLE),
            array(self::OBJECT_TYPE_TRANSLATION_CODE_ARTICLE, $id)
        );

        $translationData = $this->prepareTranslationData($translationCollection);

        foreach($translationData as $isoCode => $translationStream)
        {
            if(strpos($isoCode, self::FALLBACK_ISO_CODE_SUFFIX) === false) {
                $value = $this->getTranslationValue($translationData, $isoCode, self::SHOPWARE_ATTRIBUTE_TRANSLATION_PREFIX . $attributesInformation['attributesCode']);

                if(strlen($value) > 0) {
                    $this->setTranslationCollection(
                        array(
                            'lang'  => $isoCode,
                            'Name'  => $attributesInformation['Name'],
                            'Value' => $value
                        )
                    );
                } elseif(strlen($this->getBfMappingTranslations()[$isoCode]['fallback_field_key']) > 0) {
                    foreach($this->getBfMappingTranslations() as $bfMappingTranslation) {
                        if(
                            $bfMappingTranslation['mapping_field_key'] === $this->getBfMappingTranslations()[$isoCode]['fallback_field_key'] &&
                            $bfMappingTranslation['main'] === true
                        ) {
                            $this->setTranslationCollection(
                                array(
                                    'lang'  => $isoCode,
                                    'Name'  => $attributesInformation['Name'],
                                    'Value' => $attributesInformation['Value']
                                )
                            );

                            break;
                        }
                    }
                }
            }
        }
    }

    /**
     * @return string
     */
    private function getAttributesQuery()
    {
        return "select column_type as `type`, translatable , label from s_attribute_configuration where `table_name` = ? and `column_name` = ?";
    }

    public function __destruct()
    {
        parent::__destruct();
    }

    /**
     * @param $key
     * @param $attributesInformation
     * @param $type
     * @param $internalKey
     */
    abstract protected function writeStringAttribute($key, $attributesInformation, $type, $internalKey);

    /**
     * @param $key
     * @param $attributesInformation
     * @param $type
     * @param $internalKey
     */
    abstract protected function writeNumericAttribute($key, $attributesInformation, $type, $internalKey);

    /**
     * @param $key
     * @param $type
     * @param $typeNumericOrString
     * @param $internalKey
     */
    abstract protected function writeTranslationAttribute($key, $type, $typeNumericOrString, $internalKey);
}
