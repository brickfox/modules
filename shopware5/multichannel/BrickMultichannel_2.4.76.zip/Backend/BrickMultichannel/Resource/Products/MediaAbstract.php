<?php
/**
 * MediaAbstract
 *
 * @package   Bf\Multichannel\Components\Resource\Products
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\FileManager;
use Bf\Multichannel\Components\Util\Helper;
use Bf\Multichannel\Components\Util\LogCodes;
use Bf\Multichannel\Components\Util\LogManager;
use Doctrine\Common\Collections\ArrayCollection;
use Shopware\Bundle\StoreFrontBundle\Service\Core\MediaService;
use Shopware\CustomModels\BfMultichannel\ApiExportMedia;
use Shopware\Models\Article\Image as SwImage;

abstract class MediaAbstract
{
    const EXPORT_IMAGES_ATTRIBUTES_CODE = 'ChannelCode';
    const IMAGE_EXPORT_TYPE_PRODUCT     = 'PRODUCTS_IMAGES';
    const IMAGE_EXPORT_TYPE_VARIATIONS  = 'VARIATIONS_IMAGES';
    const EXPORT_TYPE                   = FileManager::FILENAME_BASE_PRODUCTS;
    const HTTP_KEY                      = 'http';

    /** @var array */
    protected $imageAttributesValues = array();

    /** @var array */
    protected $exportImagesAttributesValues = array();

    /**
     * @return string
     */
    protected function getProtocol()
    {
        return stripos($_SERVER['SERVER_PROTOCOL'], 'https') === true ? 'https://' : 'http://';
    }

    /**
     * @return string
     */
    protected function getHost()
    {
        $repositoty = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop');
        /** @var \Shopware\Models\Shop\Shop $shopModel */
        $shopModel = $repositoty->findOneBy(array('default' => true, 'active' => true));

        if($shopModel !== null)
        {
            $host = $shopModel->getHost() . $shopModel->getBasePath() . DIRECTORY_SEPARATOR;
        }
        else
        {
            $host = $_SERVER['SERVER_NAME'];
        }

        return $host;
    }

    /**
     * @param array $imageArrayCollection
     * @param                 $imageType
     *
     * @return array
     */
    protected function prepareImageContent($imageArrayCollection, $imageType)
    {
        $imageContent = array();

        /** @var \Shopware\Models\Article\Image $image */
        foreach($imageArrayCollection as $image)
        {
            if($imageType === self::IMAGE_EXPORT_TYPE_PRODUCT && $this->getOnlyNonVariationImages($image, $imageType) === true)
            {
                $imageContent[] = array(
                    'image/' . $image->getExtension(),
                    $image
                );
            }

            if($imageType === self::IMAGE_EXPORT_TYPE_VARIATIONS && $this->getOnlyNonVariationImages($image, $imageType) === false)
            {
                $imageContent[] = array(
                    'image/' . $image->getExtension(),
                    $image
                );
            }
        }

        return $imageContent;
    }

    /**
     * @param SwImage $image
     * @param         $imageType
     *
     * @return bool|int
     */
    private function getOnlyNonVariationImages(SwImage $image, $imageType)
    {
        $onlyProductsImage = true;
        $imageModel        = null;

        if($imageType === self::IMAGE_EXPORT_TYPE_PRODUCT)
        {
            $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Image');
            $imageModel = $repository->findOneBy(array('parentId' => $image->getId()));

            $isPreviewImage = $image->getMain() === 1;

            if((bool)ConfigManager::getInstance()->isBaseProductExportPreviewImageAlways() === true && $isPreviewImage) {
                $imageModel = null;
            }
        }
        elseif($imageType === self::IMAGE_EXPORT_TYPE_VARIATIONS)
        {
            $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Image');
            $parent = $image->getParent();

            if($parent !== null) {
                $imageModel = $repository->findOneBy(array('id' => $parent->getId()));
            }
        }

        if($imageModel !== null)
        {
            $onlyProductsImage = false;
        }

        return $onlyProductsImage;
    }

    /**
     * @param      $articleId
     * @param      $imageId
     * @param null $articleDetailsId
     *
     * @return int
     */
    protected function evaluateImageChangedStatus($articleId, $imageId, $articleDetailsId = null)
    {
        $changed = 1;

        $apiExportProductsModel = Helper::getApiExportProductsModelById($articleId);

        if($apiExportProductsModel !== null)
        {
            $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportImages');
            /** @var \Shopware\CustomModels\BfMultichannel\ApiExportImages $apiExportImagesModel */
            $apiExportImagesModel = $repository->findOneBy(array('articleId' => $articleId, 'imageId' => $imageId));

            if($apiExportImagesModel !== null)
            {
                $lastExportDate  = Helper::getDateTime($apiExportProductsModel->getLasExportDate());
                $lastImageUpdate = Helper::getDateTime($apiExportImagesModel->getLastUpdate());

                if($lastExportDate > $lastImageUpdate)
                {
                    $changed = 0;
                }
            }
        }

        return $changed;
    }

    /**
     * @param $articleId
     * @param $mediaId
     *
     * @return int
     */
    protected function evaluateMediaChangedStatus($articleId, $mediaId)
    {
        $changed        = 1;
        $lastUpdateDate = date('Y-m-d H:i:s', time());

        /** @var \Shopware\CustomModels\BfMultichannel\ApiExportProducts $apiExportProductsModel */
        $apiExportProductsModel = Helper::getApiExportProductsModelById($articleId);

        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportMedia');

        /** @var \Shopware\CustomModels\BfMultichannel\ApiExportMedia $apiExportMediaModel */
        $apiExportMediaModel = $repository->findOneBy(array('articleId' => $articleId, 'mediaId' => $mediaId));

        if($apiExportMediaModel === null)
        {
            $apiExportMediaModel = new ApiExportMedia();
            $apiExportMediaModel->setArticleId($articleId);
            $apiExportMediaModel->setMediaId($mediaId);
            $apiExportMediaModel->setLastUpdate($lastUpdateDate);
        }
        else
        {
            if($apiExportProductsModel !== null)
            {
                $lastExportDate  = Helper::getDateTime($apiExportProductsModel->getLasExportDate()->format('Y-m-d H:i:s'));
                $lastMediaUpdate = Helper::getDateTime($apiExportMediaModel->getLastUpdate()->format('Y-m-d H:i:s'));

                if($lastExportDate >= $lastMediaUpdate)
                {
                    $changed = 0;
                }
            }
        }

        Shopware()->Models()->persist($apiExportMediaModel);

        return $changed;
    }

    /**
     * @param string $fileName
     *
     * @return string
     */
    protected function getMediaTypeByMediaFile($fileName = '')
    {
        $mediaType = '';

        if(strlen($fileName) > 0)
        {
            $mediaType = substr(strrchr($fileName, '.'), 1);
        }
        else
        {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE,
                LogCodes::EXPORT_MEDIA_TYPE_NOT_FOUND_CODE,
                LogCodes::EXPORT_MEDIA_TYPE_NOT_FOUND
            );
        }

        return $mediaType;
    }

    /**
     * @param null|mixed $mediaService
     * @param array $image
     * @param string $exportType
     *
     * @return string
     */
    public function getImagePath($mediaService = null, array $image = array(), $exportType = self::IMAGE_EXPORT_TYPE_PRODUCT)
    {
        if($exportType === self::IMAGE_EXPORT_TYPE_VARIATIONS && $image[1]->getParent()->getMedia() !== null)
        {
            $path = $image[1]->getParent()->getMedia()->getPath();
        }
        elseif($exportType !== self::IMAGE_EXPORT_TYPE_VARIATIONS && $image[1]->getMedia() !== null)
        {
            $path = $image[1]->getMedia()->getPath();
        }
        else
        {
            return '';
        }

        if(strpos(strtolower($path), self::HTTP_KEY) !== false)
        {
            $path = strstr($path, self::HTTP_KEY);
        }
        else
        {
            $path2 = $this->getProtocol() . $this->getHost() . $path;

            if($mediaService !== null)
            {
                $path = $mediaService->getUrl($path);
            }
            else
            {
                $path = $path2;
            }
        }

        return $path;
    }

    /**
     * @return array
     */
    protected function getImageAttributesHeaderColumns()
    {
        $imageAttributesHeaderColumns = array();

        $queryResult = Shopware()->Db()->fetchAll(
            "show columns from s_articles_img_attributes"
        );

        if(count($queryResult) > 0)
        {
            foreach($queryResult as $columns)
            {
                if($columns['Field'] !== 'id' && $columns['Field'] !== 'imageID')
                {
                    $imageAttributesHeaderColumns[] = $columns['Field'];
                }
            }
        }

        return $imageAttributesHeaderColumns;
    }

    /**
     * @return array
     */
    public function getImageAttributesValues()
    {
        return $this->imageAttributesValues;
    }

    /**
     * @param array $imageAttributesValues
     *
     * @return MediaAbstract
     */
    public function setImageAttributesValues($imageAttributesValues)
    {
        $this->imageAttributesValues = $imageAttributesValues;

        return $this;
    }

    /**
     * @return array
     */
    public function getExportImagesAttributesValues()
    {
        return $this->exportImagesAttributesValues;
    }

    /**
     * @param array $exportImagesAttributesValues
     *
     * @return MediaAbstract
     */
    public function setExportImagesAttributesValues($exportImagesAttributesValues)
    {
        $this->exportImagesAttributesValues = $exportImagesAttributesValues;

        return $this;
    }
}
