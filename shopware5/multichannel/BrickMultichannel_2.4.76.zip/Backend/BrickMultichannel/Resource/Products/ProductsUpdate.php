<?php
/**
 * ProductsUpdate
 *
 * @package   Bf\Multichannel\Components\Resource\Products
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Bf\Multichannel\Components\Resource\Variations\VariationsUpdate;
use Bf\Multichannel\Components\Util\FileWriter;

class ProductsUpdate extends ProductsAbstract
{
    private $model;

    /**
     * @param $model
     */
    public function __construct($model)
    {
        $this->model = $model;
    }

    public function prepareNode()
    {
        FileWriter::$xmlElements['ProductUpdate-' . FileWriter::$internalArrayKeyCounter] = array(
            'ProductExternId' => array('@value' => $this->getModel()->getId()),
            'Active'          => array('@value' => (int) $this->getModel()->getActive())
        );

        (new VariationsUpdate($this->getModel()))->prepareVariationsUpdateNode();
    }

    /**
     * @return \Shopware\Models\Article\Article
     */
    public function getModel()
    {
        return $this->model;
    }

    /**
     * @param \Shopware\Models\Article\Article $model
     *
     * @return ProductsUpdate
     */
    public function setModel($model)
    {
        $this->model = $model;

        return $this;
    }
}
