<?php
/**
 * Repository
 *
 * @package   Bf\Multichannel\Components\Resource\Products
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Products;

use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\Helper;

class Repository
{
    const EXPORT_PRODUCTS_TYPE_PRODUCT    = 'PRODUCT';
    const EXPORT_PRODUCTS_TYPE_ASSIGNMENT = 'ASSIGNMENT';
    const EXPORT_PRODUCTS_TYPE_UPDATE     = 'PRODUCTS_UPDATE';

    private $products;

    /** @var array */
    private $ignoreProductsIds = array();

    public function __construct()
    {
        $this->products = array();
    }

    /**
     * @param integer $categoryId
     */
    public function getProductsExportItemList($categoryId)
    {
        $sqlResult = Shopware()->Db()->query($this->getArticleIdsQuery(), array($categoryId));

        $this->buildIgnoreProductsByIgnoredCategories();

        /** @var \Shopware\Models\Article\Article $articleModel */
        foreach ($this->getToExportItems($sqlResult, self::EXPORT_PRODUCTS_TYPE_PRODUCT) as $articleModel) {
            $this->setProducts($articleModel);
        }
    }

    /**
     * @param integer $subShopId
     */
    public function getProductsExportOrdersStatusItemList($subShopId)
    {
        foreach ($this->getToExportOrderStatus($subShopId) as $id) {
            $repository = Shopware()->Models()->getRepository('Shopware\Models\Order\Order');
            $orderModel = $repository->find($id);

            if ($orderModel !== null) {
                $this->setProducts($orderModel);
            }
        }
    }

    /**
     * @param integer $categoryId
     */
    public function getProductsUpdateExportItemList($categoryId)
    {
        $sqlResult = Shopware()->Db()->fetchAll($this->getArticleIdsQuery(), array($categoryId));

        $this->buildIgnoreProductsByIgnoredCategories();

        /** @var \Shopware\Models\Article\Article $item */
        foreach ($this->getToExportItems($sqlResult, self::EXPORT_PRODUCTS_TYPE_UPDATE) as $item) {
            $this->setProducts($item);
        }
    }

    /**
     * @param integer $categoryId
     */
    public function getProductsAssignmentItemList($categoryId)
    {
        $sqlResult = Shopware()->Db()->fetchAll($this->getArticleIdsQuery(), array($categoryId));

        /** @var \Shopware\Models\Article\Article $item */
        foreach ($this->getToExportItems($sqlResult, self::EXPORT_PRODUCTS_TYPE_ASSIGNMENT) as $item) {
            $this->setProducts($item);
        }
    }

    public function getProductsExportToDeleteItemList()
    {
        foreach ($this->getToDeleteExportItems() as $articleIds) {
            $this->setProducts($articleIds);
        }
    }

    /**
     * @param        $articleIds
     * @param string $type
     *
     * @return array
     */
    private function getToExportItems($articleIds, $type = self::EXPORT_PRODUCTS_TYPE_PRODUCT)
    {
        $exportItems    = array();
        $tmpExportItems = array();
        foreach ($articleIds as $ids) {
            $tmpExportItems[] = $ids['articleID'];
        }

        $articleIds = array_diff($tmpExportItems, $this->getIgnoreProductsIds());

        foreach ($articleIds as $ids) {
            $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportProducts');

            /** @var \Shopware\CustomModels\BfMultichannel\ApiExportProducts $apiExportProductsModel */
            $apiExportProductsModel = $repository->findOneBy(array('shopwareId' => $ids, 'isDeleted' => 0, 'toDelete' => 0));

            if ($type === self::EXPORT_PRODUCTS_TYPE_PRODUCT) {
                if ($apiExportProductsModel === null) {
                    if ($this->verifyIfArticleExists($ids)) {
                        $exportItems[] = $ids;
                    }
                } else {
                    $lastExportDate = $apiExportProductsModel->getLasExportDate()->format('Y-m-d H:i:s');
                    $lastUpdateDate = $apiExportProductsModel->getArticleLastUpdate()->format('Y-m-d H:i:s');

                    if ($lastExportDate < $lastUpdateDate || $this->seoUrlIsChanged($ids) === true) {
                        if ($this->verifyIfArticleExists($ids) === true) {
                            $exportItems[] = $ids;
                        }
                    }
                }
            } elseif ($type === self::EXPORT_PRODUCTS_TYPE_ASSIGNMENT) {
                if ($apiExportProductsModel !== null) {
                    if ($apiExportProductsModel->getLastAssignmentsExportDate() === null) {
                        if ($this->verifyIfArticleExists($ids) === true) {
                            if ($this->verifyIfRelationOrSimilarExists($ids) === true) {
                                $exportItems[] = $ids;
                            }
                        }
                    } else {
                        $lastExportDateAssignment = $apiExportProductsModel->getLastAssignmentsExportDate()->format('Y-m-d H:i:s');
                        $lastUpdateDate           = $apiExportProductsModel->getArticleLastUpdate()->format('Y-m-d H:i:s');

                        if ($lastExportDateAssignment < $lastUpdateDate) {
                            if ($this->verifyIfArticleExists($ids) === true) {
                                if ($this->verifyIfRelationOrSimilarExists($ids) === true) {
                                    $exportItems[] = $ids;
                                }
                            }
                        }
                    }
                }
            } elseif ($type === self::EXPORT_PRODUCTS_TYPE_UPDATE) {
                if ($apiExportProductsModel !== null) {
                    $repositoryApiExportProductsUpdate = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportProductsUpdate');
                    /** @var \Shopware\CustomModels\BfMultichannel\ApiExportProductsUpdate $apiExportProductsUpdateModel */
                    $apiExportProductsUpdateModel = $repositoryApiExportProductsUpdate->findOneBy(array('shopwareId' => $ids));

                    if ($apiExportProductsUpdateModel !== null) {
                        $stockHash = Helper::getCombinedArticleStockHash($ids);
                        $priceHash = Helper::getCombinedArticlePricesHash($ids);

                        if (strlen($stockHash) > 0) {
                            if ($apiExportProductsUpdateModel->getStockHash() !== $stockHash || $apiExportProductsUpdateModel->getPriceHash() !== $priceHash) {
                                if ($this->verifyIfArticleExists($ids) === true) {
                                    $exportItems[] = $ids;
                                }
                            }
                        }
                    } else {
                        if ($this->verifyIfArticleExists($ids) === true) {
                            $exportItems[] = $ids;
                        }
                    }
                }
            }
        }

        return $exportItems;
    }

    /**
     * @param integer $subShopId
     *
     * @return array
     */
    private function getToExportOrderStatus($subShopId)
    {
        $exportOrdersStatus = array();

        $query = "select o.id from s_order o
                  left join bf_export_order_status eos on eos.orderID = o.id
                  where o.subshopID = ? and o.`status` != eos.lastExportStatus";

        $result = Shopware()->Db()->fetchAll($query, array($subShopId));

        if (count($result) > 0) {
            foreach ($result as $element) {
                $exportOrdersStatus[] = $element['id'];
            }
        }

        return $exportOrdersStatus;
    }

    /**
     * @return array
     */
    private function getToDeleteExportItems()
    {
        $toDeleteExportItems  = array();
        $updateLastExportDate = date('Y-m-d H:i:s', time());
        $updateLastUpdateDate = date('Y-m-d H:i:s', time());

        $repository              = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportProducts');
        $apiExportProductsModels = $repository->findBy(array('toDelete' => 1, 'isDeleted' => 0));

        if (count($apiExportProductsModels) > 0) {
            /** @var \Shopware\CustomModels\BfMultichannel\ApiExportProducts $apiExportProductsModel */
            foreach ($apiExportProductsModels as $apiExportProductsModel) {
                $lastExportDate = $apiExportProductsModel->getLasExportDate()->format('Y-m-d H:i:s');
                $lastUpdateDate = $apiExportProductsModel->getArticleLastUpdate()->format('Y-m-d H:i:s');

                if ($lastExportDate < $lastUpdateDate) {
                    if ($apiExportProductsModel->getShopwareId() !== null) {
                        $apiExportProductsModel->setToDelete(0);
                        $apiExportProductsModel->setIsDeleted(1);
                        $apiExportProductsModel->setLasExportDate($updateLastExportDate);
                        $apiExportProductsModel->setArticleLastUpdate($updateLastUpdateDate);

                        Shopware()->Models()->persist($apiExportProductsModel);

                        $toDeleteExportItems[] = $apiExportProductsModel->getShopwareId();
                    }
                }
            }
        }

        return $toDeleteExportItems;
    }

    private function buildIgnoreProductsByIgnoredCategories()
    {
        $ignoredCategories = ConfigManager::getInstance()->getDisabledCategories()->getConfigurationValue();

        if (strlen($ignoredCategories) > 0) {

            $sql = 'select distinct articleID from s_articles_categories_ro where categoryID in ('.$ignoredCategories.')';
            $ids      = Shopware()->Db()->fetchAll($sql);
            $tmpArray = array();

            foreach ($ids as $fetch) {
                $tmpArray[] = $fetch['articleID'];
            }

            $this->setIgnoreProductsIds($tmpArray);
        }
    }

    /**
     * @return string
     */
    private function getArticleIdsQuery()
    {
        $sql = "select distinct articleID from s_articles_categories_ro where categoryID = ?";

        if (strlen(ConfigManager::getInstance()->getProductsToExportAttributesConfiguration()->getConfigurationValue()) > 0) {
            $attributes     = array();
            $attributeParts = array_map('trim',explode(',', ConfigManager::getInstance()->getProductsToExportAttributesConfiguration()->getConfigurationValue()));

            foreach ($attributeParts as $attributePart) {
                $tmpAttributesPart                 = array_map('trim',explode('=>', $attributePart));
                $attributes[$tmpAttributesPart[0]] = $tmpAttributesPart[1];
            }

            if (count($attributes) > 0) {
                $attributeQueryPart = '';
                $attributesCounter  = count($attributes);
                $queryCounter       = 1;

                foreach ($attributes as $attributeField => $attributeValue) {
                    if ($queryCounter === 1) {
                        $attributeQueryPart .= 'and (';
                    }

                    if ($queryCounter < $attributesCounter) {
                        $attributeQueryPart .= "saa.$attributeField = '$attributeValue' or ";
                    }

                    if ($queryCounter === $attributesCounter) {
                        $attributeQueryPart .= "saa.$attributeField = '$attributeValue')";
                    }

                    $queryCounter++;
                }

                $sql = "
                        select distinct sacr.articleID from s_articles_attributes saa 
                        left join s_articles_details sad on saa.articledetailsID = sad.id
                        left join s_articles_categories_ro sacr on sad.articleID = sacr.articleID
                        where sacr.categoryID = ? " . $attributeQueryPart;
            }
        }

        return $sql;
    }

    /**
     * @param $articleId
     *
     * @return bool
     */
    private function verifyIfArticleExists($articleId)
    {
        $exists = false;

        $result = Shopware()->Db()->fetchOne("select id from s_articles where id = ?", $articleId);

        $resultDetail = Shopware()->Db()->fetchOne("select id from s_articles_details where articleID = ?", $articleId);

        if (($result != null && $result !== false && strlen($result) > 0) && ($resultDetail !== null && $resultDetail !== false && strlen($resultDetail) > 0)) {
            $exists = true;
        }

        return $exists;
    }

    /**
     * @param $articleId
     *
     * @return bool
     */
    private function verifyIfRelationOrSimilarExists($articleId)
    {
        $exists = false;

        $similar  = Shopware()->Db()->fetchOne("select distinct id from s_articles_similar where articleID = ?", array($articleId));
        $relation = Shopware()->Db()->fetchOne("select distinct id from s_articles_relationships where articleID = ?", array($articleId));

        if (($similar !== null && $similar !== false && strlen($similar) > 0) || ($relation !== null && $relation !== false && strlen($relation) > 0)) {
            $exists = true;
        }

        return $exists;
    }

    /**
     * @param $articleId
     *
     * @return bool
     */
    private function seoUrlIsChanged($articleId)
    {
        $seoUrlIsChanged = false;

        $bfApiExportSeoUrlsRepository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportSeoUrls');
        /** @var \Shopware\CustomModels\BfMultichannel\ApiExportSeoUrls $bfApiExportSeoUrlModel */
        $bfApiExportSeoUrlModel = $bfApiExportSeoUrlsRepository->findOneBy(array('brickfoxExternId' => $articleId, 'shopwareDetailsId' => null));

        if ($bfApiExportSeoUrlModel !== null) {
            $sCoreRewriteUrls = Shopware()
                ->Db()
                ->fetchRow("select * from s_core_rewrite_urls where org_path = ? and main = ?", array(SeoUrlAbstract::ORG_PATH_PART . $articleId, 1));

            if (isset($sCoreRewriteUrls['org_path']) === true) {
                $orgPath = $sCoreRewriteUrls['org_path'];
            } else {
                $orgPath = '';
            }

            if (isset($sCoreRewriteUrls['path']) === true) {
                $secureResult    = Shopware()->Db()->fetchOne('select host from s_core_shops where `default` = ? and active = ?', array(1, 1));
                $hostInformation = ConfigManager::getInstance()->getServerProtocol() . rtrim($secureResult, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;

                $seoUrl = $hostInformation . $sCoreRewriteUrls['path'];
            } else {
                $seoUrl = '';
            }

            if (is_array($sCoreRewriteUrls) && @count($sCoreRewriteUrls) > 0) {
                if ($bfApiExportSeoUrlModel->getOriginalPath() !== $orgPath || $bfApiExportSeoUrlModel->getSeoPath() !== $seoUrl) {
                    $seoUrlIsChanged = true;
                }
            }
        }

        return $seoUrlIsChanged;
    }

    /**
     * @return mixed
     */
    public function getProducts()
    {
        return $this->products;
    }

    /**
     * @param mixed $products
     *
     * @return Repository
     */
    public function setProducts($products)
    {
        $this->products[] = $products;

        return $this;
    }

    /**
     * @return array
     */
    public function getIgnoreProductsIds()
    {
        return $this->ignoreProductsIds;
    }

    /**
     * @param array $ignoreProductsIds
     */
    public function setIgnoreProductsIds($ignoreProductsIds)
    {
        $this->ignoreProductsIds = $ignoreProductsIds;
    }
}
