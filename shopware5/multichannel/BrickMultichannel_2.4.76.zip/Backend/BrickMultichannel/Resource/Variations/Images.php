<?php
/**
 * Images
 *
 * @package   Bf\Multichannel\Components\Resource\Variations
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Variations;

use Bf\Multichannel\Components\Interfaces\ProductsInterface;
use Bf\Multichannel\Components\Resource\Products\MediaAbstract;
use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\FileWriter;
use Bf\Multichannel\Components\Util\Helper;
use Doctrine\ORM\EntityNotFoundException;
use Exception;

class Images extends MediaAbstract implements ProductsInterface
{
    private $model;

    /**
     * @param \Shopware\Models\Article\Detail $model
     */
    public function __construct($model)
    {
        $this->model = $model;
    }

    /**
     * @param int $key
     */
    public function prepareVariationsImagesNode($key = 0)
    {
        $writtenImage = false;
        $mediaService = null;
        $imageCounter = 0;

        if ($this->getModel()->getImages()->count() > 0) {
            if (ConfigManager::getInstance()->getShopwareVersion() === 5.1) {
                $mediaService = Shopware()->Container()->get('shopware_media.media_service');
            }

            if (strlen(Helper::getConfigurationByKey('imageAttributesKeyWords')->getConfigurationValue()) > 0) {
                $this->setImageAttributesValues(explode(',', Helper::getConfigurationByKey('imageAttributesKeyWords')->getConfigurationValue()));
            }

            $images = $this->prepareImageContent($this->getModel()->getImages(), self::IMAGE_EXPORT_TYPE_VARIATIONS);

            try {
                /** @var \Shopware\Models\Article\Image $image */
                foreach ($images as $imageType => $image) {
                    if (count($this->getImageAttributesValues()) > 0) {
                        $writable                    = false;
                        $attributeCounter            = 1;
                        $attributeHeaderColumns      = $this->getImageAttributesHeaderColumns();
                        $exportImageAttributesValues = $this->getExportImagesAttributesValues();

                        if (count($attributeHeaderColumns) > 0) {
                            try {
                                foreach ($attributeHeaderColumns as $columns) {
                                    $getter = ucwords($columns, '_');
                                    $getter = 'get' . ucfirst($getter);
                                    $getter = str_replace('_', '', $getter);

                                    if ($image[1]->getParent()->getAttribute() !== null) {
                                        if (method_exists($image[1]->getParent()->getAttribute(), $getter) === true) {
                                            if ($image[1]->getParent()->getAttribute()->$getter() !== null) {
                                                if (in_array($image[1]->getParent()->getAttribute()->$getter(), $this->getImageAttributesValues()) === true) {
                                                    $exportImageAttributesValues['ImageAttribute' . $attributeCounter] = array(
                                                        '@attributes' => array('code' => self::EXPORT_IMAGES_ATTRIBUTES_CODE),
                                                        'Name'        => array('@cdata' => $image[1]->getParent()->getAttribute()->$getter())
                                                    );
                                                    $this->setExportImagesAttributesValues($exportImageAttributesValues);
                                                    $writable = true;
                                                    ++$attributeCounter;
                                                }
                                            }
                                        }
                                    }
                                }
                            } catch (Exception $e) {
                            }
                        }
                    } else {
                        $writable = true;
                    }

                    if ($writable === true && is_object($image[1]->getParent()->getMedia()) === true) {
                        $path = $this->getImagePath($mediaService, $image, self::IMAGE_EXPORT_TYPE_VARIATIONS);

                        FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['VariationImages'][] = array(
                            'Image' => array(
                                '@attributes' => array(
                                    'sort'    => $image[1]->getParent()->getPosition(),
                                    'changed' => 1
                                ),
                                'Name'        => array('@cdata' => $image[1]->getParent()->getDescription()),
                                'Path'        => array('@value' => $path)
                            )
                        );

                        if (count($this->getExportImagesAttributesValues()) > 0) {
                            FileWriter::$xmlElements['Product-' .
                                                     FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['VariationImages'][$imageCounter]['Image']['ImageAttributes'] = array(
                                $this->getExportImagesAttributesValues()
                            );
                        }

                        $writtenImage = true;
                        $imageCounter++;
                    }

                    $this->setExportImagesAttributesValues(array());
                }
            } catch (EntityNotFoundException $e) {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['VariationImages'] = array();
            }

            if ($writtenImage === false) {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['VariationImages'] = array();
            }
        } else {
            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['VariationImages'] = array();
        }
    }

    /**
     * @return \Shopware\Models\Article\Detail
     */
    public function getModel()
    {
        return $this->model;
    }

    /**
     * @param \Shopware\Models\Article\Detail $model
     *
     * @return Images
     */
    public function setModel($model)
    {
        $this->model = $model;

        return $this;
    }

    public function __destruct()
    {
        $this->model = null;
    }
}
