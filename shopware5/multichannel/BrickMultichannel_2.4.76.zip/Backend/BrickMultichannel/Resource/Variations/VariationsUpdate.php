<?php
/**
 * VariationsUpdate
 *
 * @package   Bf\Multichannel\Components\Resource\Variations
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Variations;

use Bf\Multichannel\Components\Util\FileWriter;

class VariationsUpdate extends VariationsAbstract
{
    const XML_START_ELEMENT = 'ProductUpdate-';

    /**
     * VariationsUpdate constructor.
     *
     * @param \Shopware\Models\Article\Article $model
     */
    public function __construct($model)
    {
        parent::__construct($model);
    }

    public function prepareVariationsUpdateNode()
    {
        $key                                                                                                   = 0;
        FileWriter::$xmlElements[self::XML_START_ELEMENT . FileWriter::$internalArrayKeyCounter]['Variations'] = array();

        /** @var \Shopware\Models\Article\Detail $variations */
        foreach($this->getVariationsArrayCollection() as $variations)
        {
            FileWriter::$xmlElements[self::XML_START_ELEMENT . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation'] = array(
                'VariationExternId' => array('@value' => $variations->getId()),
                'VariationActive'   => array('@value' => (int) $variations->getActive()),
                'Available'         => array('@value' => (int) $variations->getActive()),
                'DeliveryTime'      => array('@value' => $variations->getShippingTime()),
                'Stock'             => array('@value' => $variations->getInStock() == null ? 0 : $variations->getInStock())
            );

            (new Prices($variations))->prepareCurrenciesNode($key, self::XML_START_ELEMENT);
            ++$key;
        }
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
