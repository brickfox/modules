<?php
/**
 * Prices
 *
 * @package   Bf\Multichannel\Components\Resource\Variations
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Variations;

use Bf\Multichannel\Components\Gui\GuiOverview;
use Bf\Multichannel\Components\Util\FileWriter;
use Bf\Multichannel\Components\Util\Helper;

class Prices extends PricesAbstract
{
    const XML_START_ELEMENT = 'Product-';
    const DEFAULT_PRICE_GROUP = 'EK';

    private $priceGross;
    private $xmlStartElement;

    /**
     * @param $item
     */
    public function __construct($item)
    {
        parent::__construct($item);
    }

    /**
     * @param        $key
     * @param string $xmlStartElement
     */
    public function prepareCurrenciesNode($key, $xmlStartElement = self::XML_START_ELEMENT)
    {
        $this->setXmlStartElement($xmlStartElement);

        $internalKey                                                                                                                                  = 0;
        FileWriter::$xmlElements[$this->getXmlStartElement() . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Currencies'][] = array();

        FileWriter::$xmlElements[$this->getXmlStartElement() .
                                 FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Currencies'][$internalKey]['Currency']['ScalePrices'] = array();

        /** @var \Shopware\CustomModels\BfMultichannel\MappingCurrencies $mappingModel */
        foreach ($this->getCurrenciesMapping() as $mappingModel) {
            $isB2C = $this->isB2COrB2BShop($mappingModel->getIsNetFieldKey());
            $isNet = ($isB2C === false) ? true : false;
            FileWriter::$xmlElements[$this->getXmlStartElement() .
                                     FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Currencies'][$internalKey]['Currency'] = array(
                '@attributes' => array('code' => $mappingModel->getBrickfoxCurrenciesCode(), 'net' => $isNet),
                'Price'       => array('@value' => $this->writePrice($mappingModel, $isB2C))

            );

            $this->prepareScalePrices($mappingModel, $isB2C, $key, $internalKey);
            $this->preparePseudoPrice($mappingModel, $isB2C, $key, $internalKey);

            ++$internalKey;
        }
    }

    /**
     * @param \Shopware\CustomModels\BfMultichannel\MappingCurrencies $mappingModel
     * @param bool|true $isB2C
     * @param                                                         $key
     * @param                                                         $internalKey
     */
    private function preparePseudoPrice($mappingModel, $isB2C = true, $key, $internalKey)
    {
        $rrpSpecialPriceConfigurationValueCode = Helper::getConfigurationByKey('rrpSpecialPrice')->getConfigurationValue();

        $priceModel = $this->getPriceModel(array('customerGroupKey' => $mappingModel->getMappingFieldKey(), 'from' => 1, 'articleDetailsId' => $this->getItem()->getId()));

        if ($priceModel !== null) {
            $variationBasePrice = $priceModel->getPseudoPrice();

            if ($isB2C === true) {
                $calculatedPrice = $this->calculateB2CPrices($variationBasePrice, $this->getTaxRate($priceModel));
            } else {
                $calculatedPrice = $variationBasePrice;
            }

            switch ($rrpSpecialPriceConfigurationValueCode) {
                case GuiOverview::PSEUDO_PRICE_EQUAL_RRP_PRICE_CODE:
                    if ($calculatedPrice > 0) {
                        FileWriter::$xmlElements[$this->getXmlStartElement() .
                                                 FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Currencies'][$internalKey]['Currency']['Rrp'] = array(
                            '@value' => $calculatedPrice
                        );
                    }
                    break;

                case GuiOverview::PSEUDO_PRICE_EQUAL_SPECIAL_PRICE_CODE:
                    if ($calculatedPrice > 0) {
                        FileWriter::$xmlElements[$this->getXmlStartElement() .
                                                 FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Currencies'][$internalKey]['Currency']['Price']        = array('@value' => $calculatedPrice);
                        FileWriter::$xmlElements[$this->getXmlStartElement() .
                                                 FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Currencies'][$internalKey]['Currency']['SpecialPrice'] = array(
                            '@value' => $this->writePrice($mappingModel, $isB2C)
                        );
                    }
                    break;

                default:
                    break;
            }
        }
    }

    /**
     * @param \Shopware\CustomModels\BfMultichannel\MappingCurrencies $mappingModel
     * @param bool|true $isB2C
     * @param                                                         $key
     * @param                                                         $internalKey
     */
    private function prepareScalePrices($mappingModel, $isB2C = true, $key, $internalKey)
    {
        $priceModel = $this->getPriceModel(array('customerGroupKey' => $mappingModel->getMappingFieldKey(), 'articleDetailsId' => $this->getItem()->getId()), 'findBy');

        if (count($priceModel) > 1) {
            /** @var \Shopware\Models\Article\Price $price */
            foreach ($priceModel as $price) {
                if ($price->getFrom() !== 1) {
                    FileWriter::$xmlElements[$this->getXmlStartElement() .
                                             FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Currencies'][$internalKey]['Currency']['ScalePrices'][] = array(
                        'ScalePrice' => array(
                            'Price'    => array('@value' => ($isB2C === true) ? $this->calculateB2CPrices($price->getPrice(), $this->getTaxRate($price)) : $price->getPrice()),
                            'Quantity' => array('@value' => $price->getFrom())
                        )
                    );
                } else {
                    continue;
                }
            }
        }
    }

    /**
     * @param \Shopware\CustomModels\BfMultichannel\MappingCurrencies $mappingModel
     * @param bool $isB2C
     *
     * @return float
     */
    private function writePrice($mappingModel, $isB2C = true)
    {
        $price = 0;

        $priceModel = $this->getPriceModel(array('customerGroupKey' => $mappingModel->getMappingFieldKey(), 'from' => 1, 'articleDetailsId' => $this->getItem()->getId()));

        if ($priceModel === null) {
            $priceModel = $this->getPriceModel(array('customerGroupKey' => self::DEFAULT_PRICE_GROUP, 'from' => 1, 'articleDetailsId' => $this->getItem()->getId()));
        }

        if ($priceModel !== null) {
            if ($isB2C === true) {
                $price = (float)$this->calculateB2CPrices($priceModel->getPrice(), $this->getTaxRate($priceModel));
            } else {
                $price = $priceModel->getPrice();
            }
        }

        return $price;
    }

    /**
     * @return mixed
     */
    public function getPriceGross()
    {
        return $this->priceGross;
    }

    /**
     * @param mixed $priceGross
     *
     * @return Prices
     */
    public function setPriceGross($priceGross)
    {
        $this->priceGross = $priceGross;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getXmlStartElement()
    {
        return $this->xmlStartElement;
    }

    /**
     * @param mixed $xmlStartElement
     *
     * @return Prices
     */
    public function setXmlStartElement($xmlStartElement)
    {
        $this->xmlStartElement = $xmlStartElement;

        return $this;
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
