<?php
/**
 * Options
 *
 * @package   Bf\Multichannel\Components\Resource\Variations
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Variations;

use Bf\Multichannel\Components\Interfaces\ProductsInterface;
use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\FileWriter;

class Options extends OptionsAbstract implements ProductsInterface
{
    private $model;

    /**
     * @param \Shopware\Models\Article\Detail $model
     */
    public function __construct($model)
    {
        $this->model = $model;

        parent::__construct($model);
    }

    /**
     * @param $key
     * @throws \Exception
     */
    public function prepareVariationsOptionsNode($key)
    {
        if($this->hasOptions($this->getModel()->getId()) === true)
        {
            $optionsKey = $translationsKey = 0;
            $options = $this->getVariationsOptionsByVariationsId($this->getModel()->getId());

            if(count($options) > 0)
            {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Options'] = [];

                foreach($options as $detailOption)
                {
                    $optionName = $detailOption['group']['name'];
                    $optionValue = $detailOption['name'];

                    FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Options'][$optionsKey] = [
                        'Option' => [
                            'Translations' => [
                                $translationsKey++ => [
                                    'Translation' => [
                                        '@attributes' => ['lang' => $this->getMainLanguageCode()],
                                        'OptionName'  => ['@cdata' => $detailOption['group']['name']],
                                        'OptionValue' => ['@cdata' => $detailOption['name']]
                                    ]
                                ]
                            ]
                        ]
                    ];

                    if (
                        ConfigManager::getInstance()->getIsMultiShop() === true ||
                        (bool)ConfigManager::getInstance()->getMultiLanguagesExport()->getConfigurationValue() === true
                    ) {
                        $groupId = $detailOption['group']['id'];
                        $optionId = $detailOption['id'];


                        foreach ($this->getConfiguratorOptionTranslations($groupId, $optionId) as $isoCode => $configuratorOptionTranslation) {
                            $useFallbackToMain = false;

                            if (strlen($this->getBfMappingTranslations()[$isoCode]['fallback_field_key']) > 0) {
                                foreach ($this->getBfMappingTranslations() as $bfMappingTranslation) {
                                    if (
                                        $bfMappingTranslation['mapping_field_key'] === $this->getBfMappingTranslations()[$isoCode]['fallback_field_key'] &&
                                        $bfMappingTranslation['main'] === true
                                    ) {
                                        $useFallbackToMain = true;

                                        break;
                                    }
                                }
                            }
                            $translatedOptionName = $configuratorOptionTranslation['configuratorgroup'];
                            if (strlen($translatedOptionName) === 0 && $useFallbackToMain === true) {
                                $translatedOptionName = $optionName;
                            }

                            $translatedOptionValue = $configuratorOptionTranslation['configuratoroption'];
                            if (strlen($translatedOptionValue) === 0 && $useFallbackToMain === true) {
                                $translatedOptionValue = $optionValue;
                            }
                            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Options'][$optionsKey]['Option']['Translations'][$translationsKey] = [
                                'Translation' => [
                                    '@attributes' => ['lang' => $isoCode],
                                    'OptionName'  => ['@cdata' => $translatedOptionName],
                                    'OptionValue' => ['@cdata' => $translatedOptionValue]
                                ]
                            ];

                            $translationsKey++;
                        }
                    }

                    $optionsKey++;
                }
            }
        }
    }

    /**
     * @return \Shopware\Models\Article\Detail
     */
    public function getModel()
    {
        return $this->model;
    }

    /**
     * @param \Shopware\Models\Article\Detail $model
     *
     * @return Options
     */
    public function setModel($model)
    {
        $this->model = $model;

        return $this;
    }

    public function __destruct()
    {
        $this->model = null;
    }
}
