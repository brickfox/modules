<?php
/**
 * Variations
 *
 * @package   Bf\Multichannel\Components\Resource\Variations
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Variations;

use Bf\Multichannel\Components\Resource\Products\SeoUrl;
use Bf\Multichannel\Components\Resource\Products\SeoUrlAbstract;
use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\Exceptions\SkipItemExportException;
use Bf\Multichannel\Components\Util\FileWriter;
use Bf\Multichannel\Components\Resource\Variations\Images as VariationsImages;
use Exception;
use Shopware\Models\Article\Article as Articles;
use Shopware\Models\Article\Detail as Detail;

class Variations extends VariationsAbstract
{
    const WEIGHT_UNIT = 'g';
    const HEIGHT_WIDTH_LENGTH_UNIT = 'cm';

    /**
     * @param Articles $model
     */
    public function __construct($model)
    {
        parent::__construct($model);
    }

    /**
     * @throws SkipItemExportException
     * @throws Exception
     */
    public function prepareVariationsNode()
    {
        $key = 0;
        $hasVariations = $this->getVariationsArrayCollection()->count() > 1;

        if ($this->getVariationsArrayCollection()->count() === 0) {
            return;
        }

        FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'] = [];

        /** @var Detail $variations */
        foreach($this->getVariationsArrayCollection() as $variations)
        {
            if ($hasVariations && $variations->getConfiguratorOptions()->count() === 0) {
                continue;
            }
            if(($hasVariations && $variations->getConfiguratorOptions()->count() > 0) || !$hasVariations)
            {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation'] = [
                    'VariationExternId'      => ['@value' => $variations->getId()],
                    'VariationItemNumber'    => ['@value' => $variations->getNumber()],
                    'ManufacturerItemNumber' => ['@cdata' => $variations->getSupplierNumber()],
                    'MinimumOrderQuantity'   => ['@value' => $variations->getMinPurchase()],
                    'MaximumOrderQuantity'   => ['@value' => $variations->getMaxPurchase()],
                    'DefaultQuantity'        => ['@value' => $variations->getPurchaseSteps()],
                    'EAN'                    => ['@value' => $variations->getEan()],
                    'VariationActive'        => ['@value' => (int) $variations->getActive()],
                    'Available'              => ['@value' => (int) $variations->getActive()],
                    'DeliveryTime'           => ['@value' => $variations->getShippingTime()],
                    'Stock'                  => ['@value' => $variations->getInStock() == null ? 0 : $variations->getInStock()]
                ];

                $this->addIsbnFromAttribute($variations, $key);
                (new VariationsImages($variations))->prepareVariationsImagesNode($key);
                (new Options($variations))->prepareVariationsOptionsNode($key);
                (new Attributes($variations))->prepareVariationsAttributesNode($key);
                (new Prices($variations))->prepareCurrenciesNode($key);
                $this->preparePackage($variations, $key);
                $this->prepareDescription($variations, $key);
                $key++;
            } else {
                throw new Exception('Incorrect Variations on Product ' . $this->getModel()->getName() . ', ArticleID: ' . $this->getModel()->getId(), 999);
            }
        }

        if(
            ConfigManager::getInstance()->isSkipArticlesWithoutVariationsActive() === true &&
            count(FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations']) === 0
        ) {
            // will get caught on ExportAbstract
            throw new SkipItemExportException();
        }
    }

    /**
     * @param Detail $variations
     * @param $key
     */
    private function addIsbnFromAttribute(Detail $variations, $key)
    {
        try {
            if (strlen($isbnFromAttribute = ConfigManager::getInstance()->getIsbnFromAttribute()) > 0) {
                $getter = ucwords($isbnFromAttribute, '_');
                $getter = 'get' . ucfirst($getter);
                $getter = str_replace('_', '', $getter);

                $variationAttributes = $variations->getAttribute();

                if (method_exists($variationAttributes, $getter)) {
                    FileWriter::$xmlElements[
                    'Product-' . FileWriter::$internalArrayKeyCounter
                    ]['Variations'][$key]['Variation']['ISBN'] = ['@value' => (string)$variationAttributes->$getter()];
                }
            }
        } catch (Exception $e){
            //prevent export for crashing with the new logic
        }
    }

    /**
     * @param Detail $variation
     * @param int                             $key
     */
    private function prepareDescription($variation, $key)
    {
        FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Descriptions']['Description'] = [
            '@attributes' => ['lang' => 'de'],
        ];

        if($this->hasBasePriceInformation($variation) === true)
        {
            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['ContentQuantity'] = [
                '@value' => (float) $variation->getPurchaseUnit()
            ];

            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Descriptions']['Description']['ContentUnit'] = [
                '@value' => $variation->getUnit()->getName()
            ];

            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Descriptions']['Description']['BasePriceQuantity'] = [
                '@value' => $variation->getReferenceUnit()
            ];
        }

        FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Descriptions']['Description']['ProductUrl'] = [
            '@cdata' => $this->getProductsVariationsUrl($variation)
        ];
    }

    /**
     * @param Detail $variation
     *
     * @return string
     */
    private function getProductsVariationsUrl($variation)
    {
        $seoUrlClass = new SeoUrl($variation->getArticleId(), $variation->getId());
        $seoUrl = $seoUrlClass->prepareSeoUrl(SeoUrlAbstract::SEO_URL_PRODUCTS_VARIATIONS);

        $orgPath = '';

        if(isset($seoUrlClass->getSCoreRewriteUrlsInformation()['org_path']) === true)
        {
            $orgPath = $seoUrlClass->getSCoreRewriteUrlsInformation()['org_path'];
        }

        $seoUrlClass->setBfApiSeoUrls($seoUrl, $orgPath, SeoUrlAbstract::SEO_URL_PRODUCTS_VARIATIONS);

        return $seoUrl;
    }

    /**
     * @param Detail $variation
     *
     * @return bool
     */
    private function hasBasePriceInformation($variation)
    {
        $hasBasePriceInformation = false;

        if($variation->getUnit() !== null && $variation->getPurchaseUnit() !== null && $variation->getReferenceUnit() !== null)
        {
            $hasBasePriceInformation = true;
        }

        return $hasBasePriceInformation;
    }

    /**
     * @param Detail $variations
     * @param int                             $key
     */
    private function preparePackage($variations, $key)
    {
        if($variations->getWeight() > 0)
        {
            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Package']['Weight'] = [
                '@attributes' => ['unit' => self::WEIGHT_UNIT],
                '@value'      => (float) $variations->getWeight() * 1000
            ];
        }

        if($variations->getWidth() > 0)
        {
            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Package']['Width'] = [
                '@attributes' => ['unit' => self::HEIGHT_WIDTH_LENGTH_UNIT],
                '@value'      => (float) $variations->getWidth() * 10
            ];
        }

        if($variations->getHeight() > 0)
        {
            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Package']['Height'] = [
                '@attributes' => ['unit' => self::HEIGHT_WIDTH_LENGTH_UNIT],
                '@value'      => (float) $variations->getHeight() * 10
            ];
        }

        if($variations->getLen() > 0)
        {
            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Package']['Length'] = [
                '@attributes' => ['unit' => self::HEIGHT_WIDTH_LENGTH_UNIT],
                '@value'      => (float) $variations->getLen() * 10
            ];
        }
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
