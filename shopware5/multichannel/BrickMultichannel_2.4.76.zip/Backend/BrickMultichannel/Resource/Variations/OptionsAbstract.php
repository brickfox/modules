<?php
/**
 * OptionsAbstract
 *
 * @package   Bf\Multichannel\Components\Resource\Variations
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Variations;

use Bf\Multichannel\Components\Resource\Translation\TranslationAbstract;

class OptionsAbstract extends TranslationAbstract
{
    /**
     * @param \Shopware\Models\Article\Article|\Shopware\Models\Article\Detail $model
     */
    public function __construct($model)
    {
        parent::__construct($model);
    }

    /**
     * @param $variationsId
     *
     * @return bool
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    protected function hasOptions($variationsId)
    {
        return (bool) Shopware()->Models()->createQueryBuilder()->select(array('COUNT(options)'))->from('Shopware\Models\Article\Configurator\Option', 'options')->innerJoin(
            'options.articles',
            'details',
            'WITH',
            'details.id = :detailId'
        )->innerJoin('options.group', 'group')->addOrderBy('options.position')->setParameter('detailId', $variationsId)->getQuery()->getOneOrNullResult(
            \Doctrine\ORM\AbstractQuery::HYDRATE_SINGLE_SCALAR
        );
    }

    /**
     * @param $variationsId
     *
     * @return array
     */
    protected function getVariationsOptionsByVariationsId($variationsId)
    {
        $builder = Shopware()->Models()->createQueryBuilder();
        $builder->select(array('options', 'PARTIAL group.{id, name}'))->from('Shopware\Models\Article\Configurator\Option', 'options')->innerJoin(
            'options.articles',
            'details',
            'WITH',
            'details.id = :detailId'
        )->innerJoin('options.group', 'group')->addOrderBy('options.position')->setParameter('detailId', $variationsId);

        $detailOptions = $builder->getQuery()->getArrayResult();

        return $detailOptions;
    }

    /**
     *
     */
    public function __destruct()
    {
        parent::__destruct();
    }
}
