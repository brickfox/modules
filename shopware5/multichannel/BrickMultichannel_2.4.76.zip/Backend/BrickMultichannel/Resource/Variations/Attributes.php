<?php
/**
 * Attributes
 *
 * @package   Bf\Multichannel\Components\Resource\Variations
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Variations;

use Bf\Multichannel\Components\Resource\Products\AttributesAbstract;
use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\FileWriter;

class Attributes extends AttributesAbstract
{
    /**
     * @param \Shopware\Models\Article\Detail $model
     */
    public function __construct($model)
    {
        parent::__construct($model);
    }

    public function prepareVariationsAttributesNode($key)
    {
        $internalKey = 0;
        $attributesModel = $this->getModel()->getAttribute();

        if ($attributesModel instanceof \Shopware\Models\Attribute\Article) {
            FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Attributes'][] = [];

            foreach ($this->getSingleAttributes($attributesModel) as $attributeElements) {
                foreach ($attributeElements as $type => $attributesInformation) {
                    if (
                        empty($attributesInformation['Value']) === false
                        || strlen($attributesInformation['Value']) > 0
                    ) {
                        switch ($this->detectBrickFoxAttributesType($type)) {
                            case self::BRICKFOX_TEXT_AREA_TYPE:
                            case self::BRICKFOX_STRING_TYPE:

                                if ((bool)$attributesInformation['variantable'] === true) {
                                    $this->writeStringAttribute($key, $attributesInformation, $type, $internalKey);
                                }

                                break;

                            case self::BRICKFOX_DATE_TIME_TYPE:
                            case self::BRICKFOX_INTEGER_TYPE:
                            case self::BRICKFOX_FLOAT_TYPE:
                            case self::BRICKFOX_BOOLEAN_TYPE:

                                if ((bool)$attributesInformation['variantable'] === true) {
                                    $this->writeNumericAttribute($key, $attributesInformation, $type, $internalKey);
                                }

                                break;

                            default:

                                if ((bool)$attributesInformation['variantable'] === true) {
                                    $this->writeStringAttribute($key, $attributesInformation, $type, $internalKey);
                                }

                                break;
                        }
                        $internalKey++;
                    }
                }
            }
        }
    }

    /**
     * @param $key
     * @param $attributesInformation
     * @param $type
     * @param $internalKey
     */
    protected function writeStringAttribute($key, $attributesInformation, $type, $internalKey)
    {
        $typeNumericOrString = self::ATTRIBUTES_TYPE_STRING_CODE;

        FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Attributes'][$internalKey] = [
            $this->detectBrickFoxAttributesType($type) => [
                '@attributes' => ['code' => $attributesInformation['attributesCode']],
                'Translations' => [
                    [
                        'Translation' => [
                            '@attributes' => ['lang' => $this->getMainLanguageCode()],
                            'Name' => ['@cdata' => $attributesInformation['Name']],
                            'Value' => ['@cdata' => $attributesInformation['Value']]
                        ]
                    ]
                ]
            ]
        ];

        if (
            (bool)$attributesInformation['translatable'] === true &&
            (ConfigManager::getInstance()->getIsMultiShop() === true || (bool)ConfigManager::getInstance()->getMultiLanguagesExport()->getConfigurationValue() === true)
        ) {
            $this->getItemTranslations($attributesInformation, true);
            $this->writeTranslationAttribute($key, $type, $typeNumericOrString, $internalKey);
            $this->clearTranslationCollection();
        }
    }

    /**
     * @param $key
     * @param $attributesInformation
     * @param $type
     * @param $internalKey
     */
    protected function writeNumericAttribute($key, $attributesInformation, $type, $internalKey)
    {
        FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Attributes'][$internalKey] = [
            $this->detectBrickFoxAttributesType($type) => [
                '@attributes' => ['code' => $attributesInformation['attributesCode']],
                'Value' => ['@cdata' => $attributesInformation['Value']],
                'Translations' => [
                    [
                        'Translation' => [
                            '@attributes' => ['lang' => $this->getMainLanguageCode()],
                            'Name' => ['@value' => $attributesInformation['Name']]
                        ]
                    ]
                ]
            ]
        ];
    }

    /**
     * @param $key
     * @param $type
     * @param $typeNumericOrString
     * @param $internalKey
     */
    protected function writeTranslationAttribute($key, $type, $typeNumericOrString, $internalKey)
    {
        foreach ($this->getTranslationCollection() as $values) {
            if (isset($values['Value']) === true && strlen($values['Value']) > 0) {
                if ($typeNumericOrString === self::ATTRIBUTES_TYPE_STRING_CODE) {
                    FileWriter::$xmlElements['Product-' .
                    FileWriter::$internalArrayKeyCounter]['Variations'][$key]['Variation']['Attributes'][$internalKey][$this->detectBrickFoxAttributesType(
                        $type
                    )]['Translations'][] = [
                        'Translation' => [
                            '@attributes' => ['lang' => $values['lang']],
                            'Name' => ['@cdata' => $values['Name']],
                            'Value' => ['@cdata' => $values['Value']]
                        ]
                    ];
                }
            }
        }
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
