<?php
/**
 * VariationsAbstract
 *
 * @package   Bf\Multichannel\Components\Resource\Variations
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Variations;

use Bf\Multichannel\Components\Interfaces\ProductsInterface;
use Doctrine\Common\Collections\ArrayCollection;

abstract class VariationsAbstract implements ProductsInterface
{
    private $model;
    private $variationsArrayCollection;

    /**
     * @param \Shopware\Models\Article\Article $model
     */
    public function __construct($model)
    {
        $this->model                     = $model;
        $this->variationsArrayCollection = $this->getModel()->getDetails();
    }

    /**
     * @param $articleDetailsId
     *
     * @return int
     */
    protected function getIsDeleted($articleDetailsId)
    {
        $isDeleted = 0;

        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportProductsVariations');
        /** @var \Shopware\CustomModels\BfMultichannel\ApiExportProductsVariations $apiVariationsExportModel */
        $apiVariationsExportModel = $repository->findOneBy(array('id' => $articleDetailsId));

        if($apiVariationsExportModel !== null)
        {
            $isDeleted = $apiVariationsExportModel->getIsDeleted();
        }

        return $isDeleted;
    }

    /**
     * @return \Shopware\Models\Article\Article
     */
    public function getModel()
    {
        return $this->model;
    }

    /**
     * @param $model
     *
     * @return Variations
     */
    public function setModel($model)
    {
        $this->model = $model;

        return $this;
    }

    /**
     * @return ArrayCollection
     */
    public function getVariationsArrayCollection()
    {
        return $this->variationsArrayCollection;
    }

    /**
     * @param array $variationsArrayCollection
     *
     * @return Variations
     */
    public function setVariationsArrayCollection($variationsArrayCollection)
    {
        $this->variationsArrayCollection = $variationsArrayCollection;

        return $this;
    }

    public function __destruct()
    {
        $this->model                     = null;
        $this->variationsArrayCollection = null;
    }
}
