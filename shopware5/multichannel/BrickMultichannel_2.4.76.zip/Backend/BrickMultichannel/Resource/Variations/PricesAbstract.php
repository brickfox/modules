<?php
/**
 * PricesAbstract
 *
 * @package   Bf\Multichannel\Components\Resource\Variations
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Variations;

use Bf\Multichannel\Components\Util\FileManager;
use Bf\Multichannel\Components\Util\LogCodes;
use Bf\Multichannel\Components\Util\LogManager;
use Shopware\Models\Article\Price as SwPrice;

abstract class PricesAbstract
{
    const IS_NET_FIELD_KEY_BRUTTO = 'B';
    const IS_NET_FIELD_KEY_NETTO  = 'N';
    const EXPORT_TYPE = FileManager::FILENAME_BASE_PRODUCTS;

    private $model;

    /**
     * @param $item
     */
    public function __construct($item)
    {
        $this->model = $item;
    }

    /**
     * @param string $isNetFieldKey
     *
     * @return bool
     */
    protected function isB2COrB2BShop($isNetFieldKey = self::IS_NET_FIELD_KEY_BRUTTO)
    {
        switch ($isNetFieldKey) {
            case self::IS_NET_FIELD_KEY_BRUTTO:
                $isB2C = true;
                break;

            case self::IS_NET_FIELD_KEY_NETTO:
                $isB2C = false;
                break;

            default:
                $isB2C = true;
                break;
        }

        return $isB2C;
    }

    /**
     * @param string $loadingType
     * @param array $criteria
     *
     * @return null|\Shopware\Models\Article\Price|array
     */
    protected function getPriceModel(array $criteria = array(), $loadingType = 'findOneBy')
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Price');
        /** @var \Shopware\Models\Article\Price $priceModel */
        $priceModel = $repository->$loadingType($criteria);

        return $priceModel;
    }

    /**
     * @param $articleDetailsId
     *
     * @return float|int
     */
    protected function getVariationsBasePrice($articleDetailsId)
    {
        $basePrice = 0;

        $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Detail');
        /** @var \Shopware\Models\Article\Detail $detailModel */
        $detailModel = $repository->findOneBy(array('id' => $articleDetailsId));

        if ($detailModel !== null) {
            $basePrice = $detailModel->getPurchasePrice();
        }

        return $basePrice;
    }

    /**
     * @param $price
     * @param $tax
     *
     * @return string
     */
    protected function calculateB2CPrices($price, $tax)
    {
        return number_format($price * $tax, 2, '.', '');
    }

    /**
     * @param SwPrice $priceModel
     *
     * @return float
     */
    protected function getTaxRate(SwPrice $priceModel)
    {
        return ($priceModel->getArticle()->getTax()->getTax() / 100) + 1;
    }

    /**
     * @return array
     */
    protected function getCurrenciesMapping()
    {
        $repository              = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingCurrencies');
        $currenciesMappingModels = $repository->findAll();

        if (count($currenciesMappingModels) <= 0) {
            LogManager::getInstance()->createDbLogEntry(time(), self::EXPORT_TYPE, LogCodes::EXPORT_PRICE_WITHOUT_CURRENCIES_CODE, LogCodes::EXPORT_PRICE_WITHOUT_CURRENCIES);
        }

        return $currenciesMappingModels;
    }

    /**
     * @return mixed
     */
    public function getItem()
    {
        return $this->model;
    }

    public function __destruct()
    {
        $this->model = null;
    }
}
