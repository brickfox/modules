<?php
/**
 * TranslationAbstract
 *
 * @package   Bf\Multichannel\Components\Resource\Translation
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Translation;

use Bf\Multichannel\Components\Interfaces\TranslationInterface;
use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\FileManager;
use Bf\Multichannel\Components\Util\LogCodes;
use Bf\Multichannel\Components\Util\LogManager;
use Exception;

abstract class TranslationAbstract implements TranslationInterface
{
    const EXPORT_TYPE              = FileManager::FILENAME_BASE_PRODUCTS;
    const FALLBACK_ISO_CODE_SUFFIX = 'Fallback';

    /** @var \Shopware\Models\Article\Article */
    private $model;

    /** @var array */
    private $translationCollection = array();

    /** @var string */
    private $mainLanguageCode = null;

    /** @var array */
    private $bfMappingTranslations = array();

    /**
     * @param \Shopware\Models\Article\Article|\Shopware\Models\Article\Detail $model
     * @throws \Exception
     */
    public function __construct($model)
    {
        $this->model = $model;

        $bfMappingTranslations = Shopware()->Db()->fetchAll('SELECT * FROM bf_mapping_translation');

        foreach($bfMappingTranslations as $bfMappingTranslation) {
            if($bfMappingTranslation['brickfox_iso_code'] === $this->getMainLanguageCode()) {
                $bfMappingTranslation['main'] = true;
            } else {
                $bfMappingTranslation['main'] = false;
            }

            $this->bfMappingTranslations[$bfMappingTranslation['brickfox_iso_code']] = $bfMappingTranslation;
        }
    }

    /**
     * @return string
     */
    public function getMultiShopLanguageCode()
    {
        $localeIsoCode = Shopware()->Db()->fetchOne($this->getLocaleIsoCodeQuery(self::LOCAL_ISO_CODE_QUERY_TYPE_MULTI_SHOP), array(ConfigManager::getInstance()->getMultiShopsId()));

        if($localeIsoCode === '')
        {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE,
                LogCodes::EXPORT_TRANSLATION_WITHOUT_LOCALE_ISO_CODE,
                LogCodes::EXPORT_TRANSLATION_WITHOUT_LOCALE_ISO
            );
        }

        $translationMappingModel = $this->getTranslationMappingIsoCodeByGivenLocaleIsoCode($localeIsoCode);

        if($translationMappingModel === null)
        {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE,
                LogCodes::EXPORT_TRANSLATION_MAPPING_ERROR_CODE,
                LogCodes::EXPORT_TRANSLATION_MAPPING_ERROR
            );
        }

        return $translationMappingModel->getBrickfoxIsoCode();
    }

    /**
     * @return string
     * @throws Exception
     */
    public function getMainLanguageCode()
    {
        if($this->mainLanguageCode === null) {
            $localeIsoCode = Shopware()->Db()->fetchOne($this->getLocaleIsoCodeQuery(self::LOCALE_ISO_CODE_QUERY_TYPE_MAIN), array(1, 1));

            if ($localeIsoCode === '') {
                LogManager::getInstance()->createDbLogEntry(
                    time(),
                    self::EXPORT_TYPE,
                    LogCodes::EXPORT_TRANSLATION_WITHOUT_LOCALE_ISO_CODE,
                    LogCodes::EXPORT_TRANSLATION_WITHOUT_LOCALE_ISO
                );
            }

            $translationMappingModel = $this->getTranslationMappingIsoCodeByGivenLocaleIsoCode($localeIsoCode);

            if ($translationMappingModel === null) {
                LogManager::getInstance()->createDbLogEntry(
                    time(),
                    self::EXPORT_TYPE,
                    LogCodes::EXPORT_TRANSLATION_MAPPING_ERROR_CODE,
                    LogCodes::EXPORT_TRANSLATION_MAPPING_ERROR
                );
            }

            $this->mainLanguageCode = $translationMappingModel->getBrickfoxIsoCode();
        }

        return $this->mainLanguageCode;
    }

    /**
     */
    public function getItemTranslations()
    {
        $translationCollection = Shopware()->Db()->fetchAll(
            $this->getTranslationQuery(self::OBJECT_TYPE_TRANSLATION_CODE_ARTICLE),
            array(self::OBJECT_TYPE_TRANSLATION_CODE_ARTICLE, $this->getModel()->getId())
        );

        if (count($translationCollection) > 0) {
            $translationData = $this->prepareTranslationData($translationCollection);

            foreach ($translationData as $isoCode => $translationStream) {
                if (strpos($isoCode, self::FALLBACK_ISO_CODE_SUFFIX) === false) {
                    $useFallbackToMain = false;

                    if (strlen($this->getBfMappingTranslations()[$isoCode]['fallback_field_key']) > 0) {
                        foreach ($this->getBfMappingTranslations() as $bfMappingTranslation) {
                            if (
                                $bfMappingTranslation['mapping_field_key'] === $this->getBfMappingTranslations()[$isoCode]['fallback_field_key'] &&
                                $bfMappingTranslation['main'] === true
                            ) {
                                $useFallbackToMain = true;

                                break;
                            }
                        }
                    }

                    $title            = $this->getTranslationValue($translationData, $isoCode, 'txtArtikel');
                    $shortDescription = $this->getTranslationValue($translationData, $isoCode, 'txtshortdescription');
                    $longDescription  = $this->getTranslationValue($translationData, $isoCode, 'txtlangbeschreibung');
                    $searchKeys       = $this->getTranslationValue($translationData, $isoCode, 'txtkeywords');

                    if($useFallbackToMain === true) {
                        $this->setTranslationCollection(
                            array(
                                'lang'             => $isoCode,
                                'Title'            => strlen($title) > 0 ? $title : $this->getModel()->getName(),
                                'ShortDescription' => strlen($shortDescription) > 0 ? $shortDescription : $this->getModel()->getDescription(),
                                'LongDescription'  => strlen($longDescription) > 0 ? $longDescription : $this->getModel()->getDescriptionLong(),
                                'SearchKeys'       => strlen($searchKeys) > 0 ? $searchKeys : $this->getModel()->getKeywords()
                            )
                        );
                    } else {
                        $this->setTranslationCollection(
                            array(
                                'lang'             => $isoCode,
                                'Title'            => $title,
                                'ShortDescription' => $shortDescription,
                                'LongDescription'  => $longDescription,
                                'SearchKeys'       => $searchKeys
                            )
                        );
                    }
                }
            }
        }
    }

    /**
     * @param $translationData
     * @param $isoCode
     * @param $key
     * @return string
     */
    protected function getTranslationValue($translationData, $isoCode, $key)
    {
        if (isset($translationData[$isoCode][$key]) === true) {
            $translationValue = $translationData[$isoCode][$key];
        } elseif (
            isset($translationData[$isoCode . self::FALLBACK_ISO_CODE_SUFFIX]) === true &&
            isset($translationData[$isoCode . self::FALLBACK_ISO_CODE_SUFFIX][$key]) === true
        ) {
            $translationValue = $translationData[$isoCode . self::FALLBACK_ISO_CODE_SUFFIX][$key];
        } else {
            $translationValue = '';
        }

        return $translationValue;
    }

    /**
     * @param $optionId
     * @param array $valueIds
     * @return array
     */
    public function getPropertyTranslations($optionId, $valueIds)
    {
        $propertyTranslations = array();

        $translationCollectionPropertyOptions = Shopware()->Db()->fetchAll(
            $this->getTranslationQuery(self::OBJECT_TYPE_TRANSLATION_CODE_PROPERTY_OPTION),
            array(self::OBJECT_TYPE_TRANSLATION_CODE_PROPERTY_OPTION, $optionId)
        );

        $translationCollectionPropertyValues = Shopware()->Db()->fetchAll(
            $this->getTranslationQuery(self::OBJECT_TYPE_TRANSLATION_CODE_PROPERTY_VALUE),
            array(self::OBJECT_TYPE_TRANSLATION_CODE_PROPERTY_VALUE, implode($valueIds))
        );

        $translationData = $this->prepareTranslationData($translationCollectionPropertyOptions);

        foreach ($translationData as $isoCode => $translationStream) {
            if (strpos($isoCode, self::FALLBACK_ISO_CODE_SUFFIX) === false) {
                $optionName = $this->getTranslationValue($translationData, $isoCode, 'optionName');

                $propertyTranslations[$isoCode][self::OBJECT_TYPE_TRANSLATION_CODE_PROPERTY_OPTION] = $optionName;
            }
        }

        $translationData = $this->prepareTranslationData($translationCollectionPropertyValues);

        foreach ($translationData as $isoCode => $translationStream) {
            if (strpos($isoCode, self::FALLBACK_ISO_CODE_SUFFIX) === false) {
                $optionValue = $this->getTranslationValue($translationData, $isoCode, 'optionValue');

                if(
                    isset($propertyTranslations[$isoCode]) &&
                    isset($propertyTranslations[$isoCode][self::OBJECT_TYPE_TRANSLATION_CODE_PROPERTY_VALUE]) &&
                    strlen($propertyTranslations[$isoCode][self::OBJECT_TYPE_TRANSLATION_CODE_PROPERTY_VALUE]) > 0
                ) {
                    $propertyTranslations[$isoCode][self::OBJECT_TYPE_TRANSLATION_CODE_PROPERTY_VALUE] = ', ' . $optionValue;
                } else {
                    $propertyTranslations[$isoCode][self::OBJECT_TYPE_TRANSLATION_CODE_PROPERTY_VALUE] = $optionValue;
                }
            }
        }

        return $propertyTranslations;
    }

    /**
     * @param string|int $groupId
     * @param string|int $optionId
     * @return array
     */
    public function getConfiguratorOptionTranslations($groupId, $optionId) {

        $configuratorTranslations = [];

        $translationCollectionConfiguratorGroup = Shopware()->Db()->fetchAll(
            $this->getTranslationQuery('configuratorgroup'),
            ['configuratorgroup', $groupId]
        );

        $translationCollectionConfiguratorOptions = Shopware()->Db()->fetchAll(
            $this->getTranslationQuery('configuratoroption'),
            ['configuratoroption', $optionId]
        );

        $translationData = $this->prepareTranslationData($translationCollectionConfiguratorGroup);

        foreach ($translationData as $isoCode => $translationStream) {
            if (strpos($isoCode, self::FALLBACK_ISO_CODE_SUFFIX) === false) {
                $optionName = $this->getTranslationValue($translationData, $isoCode, 'name');

                $configuratorTranslations[$isoCode]['configuratorgroup'] = $optionName;
            }
        }

        $translationData = $this->prepareTranslationData($translationCollectionConfiguratorOptions);

        foreach ($translationData as $isoCode => $translationStream) {
            if (strpos($isoCode, self::FALLBACK_ISO_CODE_SUFFIX) === false) {
                $optionValue = $this->getTranslationValue($translationData, $isoCode, 'name');

                if (
                    isset($configuratorTranslations[$isoCode]) &&
                    isset($configuratorTranslations[$isoCode]['configuratoroption']) &&
                    strlen($configuratorTranslations[$isoCode]['configuratoroption']) > 0
                ) {
                    $configuratorTranslations[$isoCode]['configuratoroption'] = ', ' . $optionValue;
                } else {
                    $configuratorTranslations[$isoCode]['configuratoroption'] = $optionValue;
                }
            }
        }

        return $configuratorTranslations;
    }

    /**
     * @param array $translationCollection
     * @param bool $onlyIsoCode
     * @return array
     */
    public function prepareTranslationData(array $translationCollection = array(), $onlyIsoCode = false)
    {
        $translationData = array();

        if ($onlyIsoCode === false) {
            foreach($this->getBfMappingTranslations() as $bfMappingTranslation) {
                if($bfMappingTranslation['main'] === false) {
                    $translationData[$bfMappingTranslation['brickfox_iso_code']] = '';
                }
            }
        }

        foreach ($translationCollection as $data) {
            $localeIsoCode = Shopware()->Db()->fetchOne($this->getLocaleIsoCodeQuery(self::LOCALE_ISO_CODE_QUERY_TYPE_TRANSLATIONS), array($data['objectlanguage'], 1));

            if ($localeIsoCode === '') {
                continue;
            }

            $mappingTranslationModel = $this->getTranslationMappingIsoCodeByGivenLocaleIsoCode($localeIsoCode);

            if ($mappingTranslationModel !== null) {
                if ($onlyIsoCode === false) {
                    $translationData[$mappingTranslationModel->getBrickfoxIsoCode()] = unserialize($data['objectdata']);
                } else {
                    $translationData['isoCode'] = $mappingTranslationModel->getBrickfoxIsoCode();
                }
            }

            $mappingTranslationModel = $this->getMappingTranslationModelByFallbackFieldKey($localeIsoCode);

            if ($mappingTranslationModel !== null) {
                if ($onlyIsoCode === false) {
                    $translationData[$mappingTranslationModel->getBrickfoxIsoCode() . self::FALLBACK_ISO_CODE_SUFFIX] = unserialize($data['objectdata']);
                } else {
                    $translationData['isoCode'] = $mappingTranslationModel->getBrickfoxIsoCode() . self::FALLBACK_ISO_CODE_SUFFIX;
                }
            }
        }

        return $translationData;
    }

    /**
     * @param $isoCode
     *
     * @return \Shopware\CustomModels\BfMultichannel\MappingTranslation
     */
    public function getTranslationMappingIsoCodeByGivenLocaleIsoCode($isoCode)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingTranslation');
        /** @var \Shopware\CustomModels\BfMultichannel\MappingTranslation $mappingModel */
        $mappingModel = $repository->findOneBy(array('mappingFieldKey' => $isoCode));

        return $mappingModel;
    }

    /**
     * @param string $brickfoxIsoCode
     * @return \Shopware\CustomModels\BfMultichannel\MappingTranslation
     */
    public function getMappingTranslationModelByBrickfoxIsoCode($brickfoxIsoCode)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingTranslation');

        return $repository->findOneBy(array('brickfoxIsoCode' => $brickfoxIsoCode));
    }

    /**
     * @param string $fallbackFieldKey
     * @return \Shopware\CustomModels\BfMultichannel\MappingTranslation
     */
    public function getMappingTranslationModelByFallbackFieldKey($fallbackFieldKey)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingTranslation');

        return $repository->findOneBy(array('fallbackFieldKey' => $fallbackFieldKey));
    }

    /**
     * @param string $type
     *
     * @return string
     */
    public function getTranslationQuery($type = self::OBJECT_TYPE_TRANSLATION_CODE_ARTICLE)
    {
        $objectLanguageWhere = "";
        $result              = Shopware()->Db()->fetchRow("select id, locale_id from s_core_shops where `default` = 1 and active = 1");
        $sql                 = "select s_core_translations.* from s_core_translations";
        switch ($type) {
            case self::OBJECT_TYPE_TRANSLATION_CODE_ARTICLE:
                $addWhere = " where objecttype = ? and objectkey = ?";
                break;

            case self::OBJECT_TYPE_TRANSLATION_CODE_PROPERTY_GROUP_AND_OPTION:
                $addWhere = " where (objecttype = ? and objectkey = ?) or (objecttype = ? and objectkey = ?)";
                break;

            case self::OBJECT_TYPE_TRANSLATION_CODE_PROPERTY_VALUE:
                $addWhere = " where objecttype = ? and objectkey in(?)";
                break;

            default:
                $addWhere = " where objecttype = ? and objectkey = ?";
                break;
        }

        if ($result !== null && $result !== false) {
            $sql .= " inner join s_core_shops on s_core_shops.id = s_core_translations.objectlanguage ";
            $objectLanguageWhere .= " and s_core_shops.locale_id != " . $result['locale_id'];
            $objectLanguageWhere .= " and objectlanguage != " . $result['id'];
        }

        $sql = $sql . $addWhere . $objectLanguageWhere;

        return $sql;
    }

    /**
     * @param string $type
     *
     * @return string
     */
    private function getLocaleIsoCodeQuery($type = self::LOCALE_ISO_CODE_QUERY_TYPE_MAIN)
    {
        $sql = "select l.locale from s_core_shops s left join s_core_locales l on l.id = s.locale_id";

        switch($type)
        {
            case self::LOCALE_ISO_CODE_QUERY_TYPE_MAIN:
                $addWhere = " where s.default = ? and s.active = ?";
                break;

            case self::LOCALE_ISO_CODE_QUERY_TYPE_TRANSLATIONS:
                $addWhere = " where s.id = ? and s.active = ?";
                break;

            case self::LOCAL_ISO_CODE_QUERY_TYPE_MULTI_SHOP:
                $addWhere = " where s.id = ?";
                break;

            default:
                $addWhere = " where s.default = ? and s.active = ?";
                break;
        }

        return $sql . $addWhere;
    }

    /**
     * @return \Shopware\Models\Article\Article|\Shopware\Models\Article\Detail
     */
    public function getModel()
    {
        return $this->model;
    }

    /**
     * @param \Shopware\Models\Article\Article|\Shopware\Models\Article\Detail $model
     *
     * @return TranslationAbstract
     */
    public function setModel($model)
    {
        $this->model = $model;

        return $this;
    }

    /**
     * @return array
     */
    public function getTranslationCollection()
    {
        return $this->translationCollection;
    }

    /**
     * @param array $translationCollection
     *
     * @return TranslationAbstract
     */
    public function setTranslationCollection($translationCollection)
    {
        $this->translationCollection[] = $translationCollection;

        return $this;
    }

    public function clearTranslationCollection()
    {
        $this->translationCollection = array();
    }

    public function __destruct()
    {
        $this->model = null;
        $this->clearTranslationCollection();
    }

    /**
     * @return array
     */
    public function getBfMappingTranslations()
    {
        return $this->bfMappingTranslations;
    }
}
