<?php
/**
 * DeliveryParty
 *
 * @package   Bf\Multichannel\Components\Resource\Orders
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Orders;

use Shopware\Models\Attribute\CustomerAddress;
use Shopware\Models\Customer\Customer as SwCustomer;
use Shopware\Models\Order\Order as SwOrder;
use Shopware\Models\Order\Shipping as SwOrderShipping;
use Shopware\Models\Customer\Address as SwAddress;

class DeliveryParty extends OrdersPartiesAbstract
{
    /**
     * @param \SimpleXMLElement $simpleXMLElement
     * @param SwOrder $order
     * @param SwCustomer $customer
     * @param string $typeOfOrderParty
     */
    public function __construct(\SimpleXMLElement $simpleXMLElement, SwOrder $order, SwCustomer $customer, $typeOfOrderParty = self::DELIVERY_ORDER_PARTY)
    {
        parent::__construct($simpleXMLElement, $order, $customer, $typeOfOrderParty);
    }

    /**
     * @param bool $isNew
     */
    public function prepareOrdersPartiesInformation($isNew = true)
    {
        if($isNew === true)
        {
            $customerAddress = new SwAddress();
            $customerAddress->setCustomer($this->getCustomerModel());
            $customerAddress->setCompany($this->prepareCompany());
            $customerAddress->setDepartment('');
            $customerAddress->setSalutation($this->prepareSalutation());
            $customerAddress->setFirstname($this->splitFirstName());
            $customerAddress->setLastname($this->splitLastName());
            $customerAddress->setStreet($this->prepareAddress());
            $customerAddress->setZipcode($this->prepareZipCode());
            $customerAddress->setCity($this->prepareCity());
            $customerAddress->setCountry($this->prepareCountry());
            // bugfix - sw 5.4.6
            if (method_exists($customerAddress, 'setPhone')) {
                $customerAddress->setPhone($this->preparePhone());
            }
            $customerAddress->setAdditionalAddressLine1($this->prepareAddressAdd());

            $customerAddressAttribute = new CustomerAddress();
            Shopware()->Models()->persist($customerAddressAttribute);

            $customerAddress->setAttribute($customerAddressAttribute);

            Shopware()->Models()->persist($customerAddress);
            $this->getCustomerModel()->setDefaultShippingAddress($customerAddress);

            if(class_exists('Shopware\Models\Customer\Shipping') === true)
            {
                $customerShipping = new \Shopware\Models\Customer\Shipping();
                $customerShipping->setCustomer($this->getCustomerModel());
                $customerShipping->setSalutation($customerAddress->getSalutation());
                $customerShipping->setCompany($customerAddress->getCompany());
                $customerShipping->setDepartment('');
                $customerShipping->setFirstName($customerAddress->getFirstname());
                $customerShipping->setLastName($customerAddress->getLastname());
                $customerShipping->setStreet($customerAddress->getStreet());
                $customerShipping->setCity($customerAddress->getCity());
                // bugfix - sw 5.4.6
                if(method_exists($customerShipping, 'setPhone')) {
                    $customerShipping->setPhone($customerAddress->getPhone());
                }
                $customerShipping->setZipCode($customerAddress->getZipcode());
                $customerShipping->setCountryId($customerAddress->getCountry()->getId());

                Shopware()->Models()->persist($customerShipping);
            }
        }
        else
        {
            $customerAddress = $this->getCustomerModel()->getDefaultShippingAddress();
        }

        $shipping = new SwOrderShipping();
        $shipping->setCustomer($this->getCustomerModel());
        $shipping->setCountry($this->prepareCountry());
        $shipping->setSalutation($this->prepareSalutation());
        $shipping->setZipCode($this->prepareZipCode());
        $shipping->setCompany($this->prepareCompany());
        $shipping->setDepartment('');
        $shipping->setFirstName($this->splitFirstName());
        $shipping->setLastName($this->splitLastName());
        $shipping->setStreet($this->prepareAddress());
        $shipping->setCity($this->prepareCity());
        // bugfix - sw 5.4.6
        if (method_exists($shipping, 'setPhone')) {
            $shipping->setPhone($this->preparePhone());
        }
        $shipping->setAdditionalAddressLine1($this->prepareAddressAdd());

        $this->getOrderModel()->setShipping($shipping);

        $addressFreetextFields = new ShippingAddressFreetextFields();
        $addressFreetextFields->setCustomerShippingAddress($shipping);
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
