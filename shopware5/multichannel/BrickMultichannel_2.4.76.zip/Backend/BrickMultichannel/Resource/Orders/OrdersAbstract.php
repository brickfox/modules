<?php
/**
 * OrdersAbstract
 *
 * @package   Bf\Multichannel\Components\Resource\Orders
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Orders;

use Bf\Multichannel\Components\Util\FileManager;
use Bf\Multichannel\Components\Util\LogCodes;
use Bf\Multichannel\Components\Util\LogManager;
use Exception;
use Shopware\Models\Order\Order as SwOrder;

abstract class OrdersAbstract
{
    const ORDER_STATUS_TYPE_CODE = 'ORDER_STATUS';
    const PAYMENT_STATUS_TYPE_CODE = 'PAYMENT_STATUS';
    const ORDER_STATUS_ID = 0;
    const PAY_PAL_PAYMENT_STATUS_ID = 17;
    const PAYMENT_STATUS_ID = 12;
    const PAYMENT_ID = 'PAYMENT_ID';
    const DISPATCH_ID = 'DISPATCH_ID';
    const PRICES_CODE_INVOICE_AMOUNT = 'INVOICE_AMOUNT';
    const PRICES_CODE_INVOICE_AMOUNT_NET = 'INVOICE_AMOUNT_NET';
    const PRICES_CODE_INVOICE_SHIPPING = 'INVOICE_SHIPPING';
    const PRICES_CODE_INVOICE_SHIPPING_NET = 'INVOICE_SHIPPING_NET';
    const PRICES_CODE_INVOICE_SHIPPING_TAX_RATE = 'INVOICE_SHIPPING_TAX_RATE';
    const DEFAULT_PAYMENT_STATUS_ID = 17;
    const DEFAULT_CURRENCIES_ID = 1;
    const EXPORT_TYPE = FileManager::FILENAME_BASE_ORDERS;

    private $xmlOrderElement;

    private $ordersModel;

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     * @param SwOrder           $ordersModel
     */
    public function __construct(\SimpleXMLElement $simpleXMLElement, SwOrder $ordersModel)
    {
        $this->xmlOrderElement = $simpleXMLElement;
        $this->ordersModel     = $ordersModel;
    }

    /**
     * @param string $type
     *
     * @return null|\Shopware\Models\Dispatch\Dispatch|\Shopware\Models\Payment\Payment
     * @throws Exception
     */
    protected function preparePaymentOrDispatch($type = self::PAYMENT_ID)
    {
        $model = null;

        switch($type)
        {
            case self::PAYMENT_ID:
                if((bool) $this->getXmlOrderElement()->PaymentMethod === false)
                {
                    LogManager::getInstance()->createDbLogEntry(
                        time(),
                        self::EXPORT_TYPE,
                        LogCodes::IMPORT_ORDERS_NO_PAYMENT_METHOD_GIVEN_CODE,
                        str_replace('{$orderNUmber}', (string) $this->getXmlOrderElement()->ExternOrderId, LogCodes::IMPORT_ORDERS_NO_PAYMENT_METHOD_GIVEN),
                        true
                    );
                }

                $repository = Shopware()->Models()->getRepository('Shopware\Models\Payment\Payment');

                /** @var \Shopware\Models\Payment\Payment $paymentModel */
                $paymentModel = $repository->findOneBy(array('name' => (string) $this->getXmlOrderElement()->PaymentMethod));

                if($paymentModel === null)
                {
                    LogManager::getInstance()->createDbLogEntry(
                        time(),
                        self::EXPORT_TYPE,
                        LogCodes::IMPORT_ORDERS_NO_PAYMENT_MODEL_FOUND_CODE,
                        str_replace('{$orderNumber}', (string) $this->getXmlOrderElement()->ExternOrderId, LogCodes::IMPORT_ORDERS_NO_PAYMENT_MODEL_FOUND),
                        true
                    );
                }

                $model = $paymentModel;
                break;

            case self::DISPATCH_ID:
                if((bool) $this->getXmlOrderElement()->ShippingMethod === false)
                {
                    LogManager::getInstance()->createDbLogEntry(
                        time(),
                        self::EXPORT_TYPE,
                        LogCodes::IMPORT_ORDERS_NO_SHIPPING_METHOD_GIVEN_CODE,
                        str_replace('{$orderNumber}', (string) $this->getXmlOrderElement()->ExternOrderId, LogCodes::IMPORT_ORDERS_NO_SHIPPING_METHOD_GIVEN),
                        true
                    );
                }

                $repository = Shopware()->Models()->getRepository('Shopware\Models\Dispatch\Dispatch');
                /** @var \Shopware\Models\Dispatch\Dispatch $dispatchModel */
                $dispatchModel = $repository->findOneBy(array('name' => (string) $this->getXmlOrderElement()->ShippingMethod));

                if($dispatchModel === null)
                {
                    LogManager::getInstance()->createDbLogEntry(
                        time(),
                        self::EXPORT_TYPE,
                        LogCodes::IMPORT_ORDERS_NO_SHIPPING_MODEL_FOUND_CODE,
                        str_replace('{$orderNumber}', (string) $this->getXmlOrderElement()->ExternOrderId, LogCodes::IMPORT_ORDERS_NO_SHIPPING_MODEL_FOUND),
                        true
                    );
                }

                $model = $dispatchModel;
                break;

            default:
                break;
        }

        return $model;
    }

    /**
     * @return string
     */
    protected function generateRandomPass()
    {
        $charSet      = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';

        for($i = 0; $i < 20; $i++)
        {
            $randomString .= $charSet[rand(0, strlen($charSet) - 1)];
        }

        return $randomString;
    }

    /**
     * @param \SimpleXMLElement $orderLines
     *
     * @return array
     */
    protected function getSingleOrderLine(\SimpleXMLElement $orderLines)
    {
        $singleOrderLine = array();

        foreach($orderLines as $orderLine)
        {
            $singleOrderLine[] = $orderLine;
        }

        return $singleOrderLine;
    }

    /**
     * @return \Shopware\Models\Order\Order
     */
    public function getOrdersModel()
    {
        return $this->ordersModel;
    }

    /**
     * @param mixed $ordersModel
     *
     * @return OrdersAbstract
     */
    public function setOrdersModel($ordersModel)
    {
        $this->ordersModel = $ordersModel;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getXmlOrderElement()
    {
        return $this->xmlOrderElement;
    }

    /**
     * @param mixed $xmlOrderElement
     *
     * @return OrdersAbstract
     */
    public function setXmlOrderElement($xmlOrderElement)
    {
        $this->xmlOrderElement = $xmlOrderElement;

        return $this;
    }

    public function __destruct()
    {
        $this->xmlOrderElement = null;
        $this->ordersModel     = null;
    }
}
