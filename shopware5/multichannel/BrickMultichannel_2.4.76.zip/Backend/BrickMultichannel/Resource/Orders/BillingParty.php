<?php
/**
 * BillingParty
 *
 * @package   Bf\Multichannel\Components\Resource\Orders
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Orders;

use Shopware\Models\Attribute\CustomerAddress;
use Shopware\Models\Customer\Customer as SwCustomer;
use Shopware\Models\Order\Order as SwOrder;
use Shopware\Models\Order\Billing as SwOrderBilling;
use Shopware\Models\Customer\Address as SwAddress;

class BillingParty extends OrdersPartiesAbstract
{
    /**
     * @param \SimpleXMLElement $simpleXMLElement
     * @param SwOrder $order
     * @param SwCustomer $customer
     */
    public function __construct(\SimpleXMLElement $simpleXMLElement, SwOrder $order, SwCustomer $customer)
    {
        parent::__construct($simpleXMLElement, $order, $customer);
    }

    /**
     * @param bool $isNew
     *
     * @return void
     */
    public function prepareOrdersPartiesInformation($isNew = true)
    {
        if($isNew === true)
        {
            $this->getCustomerModel()->setSalutation($this->prepareSalutation());
            $this->getCustomerModel()->setFirstname($this->splitFirstName());
            $this->getCustomerModel()->setLastname($this->splitLastName());

            $customerAddress = new SwAddress();
            $customerAddress->setCustomer($this->getCustomerModel());
            $customerAddress->setCompany($this->prepareCompany());
            $customerAddress->setDepartment('');
            $customerAddress->setSalutation($this->prepareSalutation());
            $customerAddress->setFirstname($this->splitFirstName());
            $customerAddress->setLastname($this->splitLastName());
            $customerAddress->setStreet($this->prepareAddress());
            $customerAddress->setZipcode($this->prepareZipCode());
            $customerAddress->setCity($this->prepareCity());
            $customerAddress->setCountry($this->prepareCountry());
            $customerAddress->setPhone($this->preparePhone());
            $customerAddress->setVatId($this->prepareVatId());
            $customerAddress->setAdditionalAddressLine1($this->prepareAddressAdd());

            $customerAddressAttribute = new CustomerAddress();
            Shopware()->Models()->persist($customerAddressAttribute);

            $customerAddress->setAttribute($customerAddressAttribute);

            Shopware()->Models()->persist($customerAddress);
            $this->getCustomerModel()->setDefaultBillingAddress($customerAddress);

            if(class_exists('Shopware\Models\Customer\Billing') === true)
            {
                $customerBilling = new \Shopware\Models\Customer\Billing();
                $customerBilling->setCustomer($this->getCustomerModel());
                $customerBilling->setSalutation($customerAddress->getSalutation());
                $customerBilling->setCompany($customerAddress->getCompany());
                $customerBilling->setDepartment($customerAddress->getDepartment());
                $customerBilling->setFirstName($customerAddress->getFirstname());
                $customerBilling->setLastName($customerAddress->getLastname());
                $customerBilling->setStreet($customerAddress->getStreet());
                $customerBilling->setCity($customerAddress->getCity());
                $customerBilling->setZipCode($customerAddress->getZipCode());
                $customerBilling->setVatId($customerAddress->getVatId());
                // bugfix - sw 5.4.6
                if(method_exists($customerBilling, 'setPhone')) {
                    $customerBilling->setPhone($customerAddress->getPhone());
                }
                $customerBilling->setCountryId($customerAddress->getCountry()->getId());

                Shopware()->Models()->persist($customerBilling);
            }
        }
        else
        {
            $customerAddress = $this->getCustomerModel()->getDefaultBillingAddress();
        }

        $billing = new SwOrderBilling();
        $billing->setCustomer($this->getCustomerModel());
        $billing->setCountry($this->prepareCountry());
        $billing->setSalutation($this->prepareSalutation());
        $billing->setZipCode($this->prepareZipCode());
        $billing->setCompany($this->prepareCompany());
        $billing->setDepartment('');
        $billing->setFirstName($this->splitFirstName());
        $billing->setLastName($this->splitLastName());
        $billing->setStreet($this->prepareAddress());
        $billing->setCity($this->prepareCity());
        $billing->setPhone($this->preparePhone());
        $billing->setAdditionalAddressLine1($this->prepareAddressAdd());
        $billing->setNumber($this->getCustomerNumber());
        $billing->setVatId($this->prepareVatId());

        $this->getOrderModel()->setBilling($billing);

        $addressFreetextFields = new AddressFreetextFields();
        $addressFreetextFields->setCustomerBillingAddress($billing);
    }

    /**
     * @return Void
     */
    public function __destructor()
    {
        parent::__destruct();
    }
}
