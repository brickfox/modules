<?php
/**
 * AddressFreetextFields
 *
 * @package   Bf\Multichannel\Components\Resource\Orders
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2021 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Orders;


use Shopware\Models\Attribute\OrderBilling as SwOrderBilling;
use Shopware\Models\Order\Billing as SwOrderBillingAddress;

class AddressFreetextFields
{

    private $addressFreetextFields = [];
    private $addressToFreetextMapping;

    public function __construct()
    {
        $this->addressToFreetextMapping = $this->getAddressToFreetextMappings();
        if (!empty($this->addressToFreetextMapping)) {
            $this->addressFreetextFields = $this->getAddressFreetextFieldsList();
        }
    }

    /**
     * @param SwOrderBillingAddress $customerBillingAddress
     *
     */
    public function setCustomerBillingAddress(SwOrderBillingAddress $customerBillingAddress)
    {
        $fieldNamePrefix = 'billing.';
        $this->saveFreeTextFields($customerBillingAddress, $fieldNamePrefix);
    }

    /**
     * @param SwOrderBillingAddress $customerAddress
     * @param string $fieldNamePrefix
     * @throws \Doctrine\ORM\ORMException
     */
    private function saveFreeTextFields(SwOrderBillingAddress $customerAddress, string $fieldNamePrefix)
    {
        $billingAddressId = $customerAddress->getId();
        $orderBillingAddressAttributes = $this->getBillingAddressAttributes($billingAddressId);

        if ($orderBillingAddressAttributes === null) {
            $orderBillingAddressAttributes = new SwOrderBilling();
        }
            foreach ($this->addressToFreetextMapping as $mapping) {
                if (strpos($mapping->getAddressFieldName(), $fieldNamePrefix) === 0) {
                    $getter = str_replace($fieldNamePrefix, 'get', $mapping->getAddressFieldName());
                    $setter = $this->getFreetextFieldSetter($mapping->getFreetextFieldId());

                    if ($getter !== '' && $setter !== '') {
                        $orderBillingAddressAttributes->$setter($customerAddress->$getter());
                        $customerAddress->setAttribute($orderBillingAddressAttributes);
                    }
                }
            }
            Shopware()->Models()->persist($orderBillingAddressAttributes);

    }

    /**
     * @return SwOrderBillingAddress
     */
    private function getBillingAddressAttributes($id)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Attribute\OrderBilling');
        return $repository->findOneBy(['id' => $id]);
    }

    /**
     * @return string
     */
    private function getFreetextFieldSetter($freetextFieldId)
    {
        foreach ($this->addressFreetextFields as $freetextField) {
            if ($freetextFieldId === $freetextField->getId()) {
                return 'set' . ucwords($freetextField->getColumnName());
            }
        }
        return '';
    }

    /**
     * @return array
     */
    private function getAddressToFreetextMappings()
    {
        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingAddressToFreetext');
        return $repository->findAll();
    }

    /**
     * @return array
     */
    private function getAddressFreetextFieldsList()
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Attribute\Configuration');
        return $repository->findBy(['tableName' => 's_order_billingaddress_attributes']);
    }

}
