<?php
/**
 * Prices
 *
 * @package   Bf\Multichannel\Components\Resource\Orders
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Orders;

use Bf\Multichannel\Components\Util\FileManager;
use Bf\Multichannel\Components\Util\LogCodes;
use Bf\Multichannel\Components\Util\LogManager;
use Exception;

class Prices
{
    const EXPORT_TYPE = FileManager::FILENAME_BASE_ORDERS;

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     *
     * @return float
     * @throws Exception
     */
    public function getInvoiceAmount(\SimpleXMLElement $simpleXMLElement)
    {
        if((bool) $simpleXMLElement->TotalAmount === false)
        {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE,
                LogCodes::IMPORT_ORDERS_TOTAL_AMOUNT_CODE,
                str_replace('{$orderNumber}', (string) $simpleXMLElement->ExternOrderId, LogCodes::IMPORT_ORDERS_TOTAL_AMOUNT),
                true
            );
        }

        return (float) $simpleXMLElement->TotalAmount;
    }

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     *
     * @return float
     * @throws Exception
     */
    public function getInvoiceAmountNet(\SimpleXMLElement $simpleXMLElement)
    {
        if((bool) $simpleXMLElement->TotalAmount === true && (bool) $simpleXMLElement->ShippingCost === true && (bool) $simpleXMLElement->TotalAmountVat === true)
        {
            $totalAmount    = (float) $simpleXMLElement->TotalAmount;
            $shippingCost   = (float) $simpleXMLElement->ShippingCost;
            $totalAmountVat = (float) $simpleXMLElement->TotalAmountVat;

            $calculatedPrice = ($totalAmount + $shippingCost) - $totalAmountVat;
        }
        else
        {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE,
                LogCodes::IMPORT_ORDERS_INVOICE_AMOUNT_NET_CODE,
                str_replace('{$orderNumber}', (string) $simpleXMLElement->ExternOrderId, LogCodes::IMPORT_ORDERS_INVOICE_AMOUNT_NET),
                true
            );
        }

        return $calculatedPrice;
    }

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     *
     * @return float
     * @throws Exception
     */
    public function getInvoiceShipping(\SimpleXMLElement $simpleXMLElement)
    {
        if((bool) $simpleXMLElement->ShippingCost === false)
        {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE,
                LogCodes::IMPORT_ORDERS_INVOICE_SHIPPING_CODE,
                str_replace('{$orderNumber}', (string) $simpleXMLElement->ExternOrderId, LogCodes::IMPORT_ORDERS_INVOICE_SHIPPING),
                true
            );
        }

        return (float) $simpleXMLElement->ShippingCost;
    }

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     *
     * @return float
     */
    public function getInvoiceShippingNet(\SimpleXMLElement $simpleXMLElement)
    {
        $shippingCostNet = 0.00;

        $taxRate = $this->getInvoiceShippingTaxRate($simpleXMLElement);

        $formatTaxRate = (float) ($taxRate / 100) + 1;

        if((bool) $simpleXMLElement->ShippingCost === true)
        {
            if($formatTaxRate > 0)
            {
                $shippingCostNet = (float) $simpleXMLElement->ShippingCost / $formatTaxRate;
            }
            else
            {
                $shippingCostNet = (float) $simpleXMLElement->ShippingCost;
            }
        }

        return $shippingCostNet;
    }

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     * @return mixed|string
     */
    public function getInvoiceShippingTaxRate(\SimpleXMLElement $simpleXMLElement) {

        $taxRate = 19.00;

        if((bool) $simpleXMLElement->OrderLines === true)
        {
            $taxArr = array();

            foreach($simpleXMLElement->OrderLines->OrderLine as $orderLine)
            {
                if((bool) $orderLine->TaxRate === true)
                {
                    if(isset($taxArr['TaxRate-' . (string) $orderLine->TaxRate]) === true)
                    {
                        $taxArr['TaxRate-' . (string) $orderLine->TaxRate] += 1;
                    }
                    else
                    {
                        $taxArr = array(
                            'TaxRate-' . (string) $orderLine->TaxRate => 1
                        );
                    }
                }
            }

            if(count($taxArr) > 0)
            {
                $taxRateCounter = null;

                foreach($taxArr as $taxRateKey => $taxRateValue)
                {
                    if($taxRateCounter === null || $taxRateCounter < $taxRateValue)
                    {
                        $taxRateCounter = $taxRateValue;
                        $taxRate        = str_replace('TaxRate-', '', $taxRateKey);
                    }
                }
            }
        }

        return (float) $taxRate;

    }
}
