<?php
/**
 * OrdersAttributesHelper.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2019 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Orders;

class OrdersAttributesHelper
{
    public static $instance = null;

    /**
     * @var array
     */
    private $ordersAttributes = array();

    /**
     * @return OrdersAttributesHelper|null
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    public function cleanUp()
    {
        $this->ordersAttributes = array();
    }

    /**
     * @param $setter
     * @param $value
     */
    public function addOrdersAttributes($setter, $value)
    {
        $this->ordersAttributes[$setter] = $value;
    }

    /**
     * @return array
     */
    public function getOrdersAttributes()
    {
        return $this->ordersAttributes;
    }

    /**
     * @param array $ordersAttributes
     */
    public function setOrdersAttributes($ordersAttributes)
    {
        $this->ordersAttributes = $ordersAttributes;
    }

    private function __construct()
    {
    }

    private function __clone()
    {
    }
}