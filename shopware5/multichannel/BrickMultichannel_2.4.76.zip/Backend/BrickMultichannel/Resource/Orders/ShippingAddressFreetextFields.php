<?php
/**
 * ShippingAddressFreetextFields
 *
 * @package   Bf\Multichannel\Components\Resource\Orders
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2021 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Orders;

use Shopware\Models\Attribute\OrderShipping as SwOrderShipping;
use Shopware\Models\Order\Shipping as SwOrderShippingAddress;

class ShippingAddressFreetextFields
{

    private $shippingAddressFreetextFields = [];
    private $shippingAddressToFreetextMapping;

    public function __construct()
    {
        $this->shippingAddressToFreetextMapping = $this->getShippingAddressToFreetextMappings();
        if (!empty($this->shippingAddressToFreetextMapping)) {
            $this->shippingAddressFreetextFields = $this->getShippingAddressFreetextFieldsList();
        }
    }

    /**
     * @param SwOrderShippingAddress $customerAddress
     *
     */
    public function setCustomerShippingAddress(SwOrderShippingAddress $customerAddress)
    {
        $fieldNamePrefix = 'shipping.';
        $this->saveFreeTextFields($customerAddress, $fieldNamePrefix);
    }

    /**
     * @param SwOrderShippingAddress $customerAddress
     * @param string $fieldNamePrefix
     * @throws \Doctrine\ORM\ORMException
     */
    private function saveFreeTextFields(SwOrderShippingAddress $customerAddress, string $fieldNamePrefix)
    {
        $shippingAddressId = $customerAddress->getId();
        $orderShippingAddressAttributes = $this->getShippingAddressAttributes($shippingAddressId);
        if ($orderShippingAddressAttributes === null) {
            $orderShippingAddressAttributes = new SwOrderShipping();
        }
            foreach ($this->shippingAddressToFreetextMapping as $mapping) {
                if (strpos($mapping->getShippingAddressFieldName(), $fieldNamePrefix) === 0) {
                    $getter = str_replace($fieldNamePrefix, 'get', $mapping->getShippingAddressFieldName());
                    $setter = $this->getFreetextFieldSetter($mapping->getFreetextFieldId());

                    if ($getter !== '' && $setter !== '') {
                        $orderShippingAddressAttributes->$setter($customerAddress->$getter());
                        $customerAddress->setAttribute($orderShippingAddressAttributes);
                    }
                }
            }
            Shopware()->Models()->persist($orderShippingAddressAttributes);

    }

    /**
     * @return SwOrderShippingAddress
     */
    private function getShippingAddressAttributes($id)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Attribute\OrderShipping');
        return $repository->findOneBy(['id' => $id]);
    }

    /**
     * @return string
     */
    private function getFreetextFieldSetter($freetextFieldId)
    {
        foreach ($this->shippingAddressFreetextFields as $freetextField) {
            if ($freetextFieldId === $freetextField->getId()) {
                return 'set' . ucwords($freetextField->getColumnName());
            }
        }
        return '';
    }

    /**
     * @return array
     */
    private function getShippingAddressToFreetextMappings()
    {
        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingShippingAddressToFreetext');
        return $repository->findAll();
    }

    /**
     * @return array
     */
    private function getShippingAddressFreetextFieldsList()
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Attribute\Configuration');
        return $repository->findBy(['tableName' => 's_order_shippingaddress_attributes']);
    }

}
