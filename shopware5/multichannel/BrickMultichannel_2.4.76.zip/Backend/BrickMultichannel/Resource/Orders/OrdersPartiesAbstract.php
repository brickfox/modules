<?php
/**
 * OrdersPartiesAbstract
 *
 * @package   Bf\Multichannel\Components\Resource\Orders
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Orders;

use Bf\Multichannel\Components\Util\FileManager;
use Bf\Multichannel\Components\Util\LogCodes;
use Bf\Multichannel\Components\Util\LogManager;
use Exception;
use Shopware\Models\Customer\Customer as SwCustomer;
use Shopware\Models\Order\Order as SwOrder;

abstract class OrdersPartiesAbstract
{
    const MS_SALUTATION = 'ms';
    const MR_SALUTATION = 'mr';
    const BILLING_ORDER_PARTY = 'BillingParty';
    const DELIVERY_ORDER_PARTY = 'DeliveryParty';
    const ADDRESS_TYPE_STREET = 'STREET';
    const ADDRESS_TYPE_STREET_NUMBER = 'STREET_NUMBER';
    const EXPORT_TYPE = FileManager::FILENAME_BASE_ORDERS;

    private $simpleXmlElement;

    private $customerModel;

    private $orderModel;

    private $typeOfOrderParty;

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     * @param SwOrder           $order
     * @param SwCustomer        $customer
     * @param string            $typeOfOrderParty
     */
    public function __construct(\SimpleXMLElement $simpleXMLElement, SwOrder $order, SwCustomer $customer, $typeOfOrderParty = self::BILLING_ORDER_PARTY)
    {
        $this->simpleXmlElement = $simpleXMLElement;
        $this->customerModel    = $customer;
        $this->orderModel       = $order;
        $this->typeOfOrderParty = $typeOfOrderParty;
    }

    protected function prepareVatId()
    {
        $vatId            = '';
        $typeOfOrderParty = $this->getTypeOfOrderParty();

        if((bool) $this->getSimpleXmlElement()->$typeOfOrderParty->VatId === true)
        {
            $vatId = (string) $this->getSimpleXmlElement()->$typeOfOrderParty->VatId;
        }

        return $vatId;
    }

    protected function preparePhone()
    {
        $phone            = '';
        $typeOfOrderParty = $this->getTypeOfOrderParty();

        if((bool) $this->getSimpleXmlElement()->$typeOfOrderParty->PhonePrivate === true)
        {
            $phone = (string) $this->getSimpleXmlElement()->$typeOfOrderParty->PhonePrivate;
        }

        return $phone;
    }

    /**
     * @return string
     */
    protected function prepareCity()
    {
        $city             = '';
        $typeOfOrderParty = $this->getTypeOfOrderParty();

        if((bool) $this->getSimpleXmlElement()->$typeOfOrderParty->City === true)
        {
            $city = (string) $this->getSimpleXmlElement()->$typeOfOrderParty->City;
        }

        return $city;
    }

    /**
     * @return string
     */
    protected function prepareAddress()
    {
        $typeOfOrderParty = $this->getTypeOfOrderParty();

        $address = (string) $this->getSimpleXmlElement()->$typeOfOrderParty->Address;
        if(isset($this->getSimpleXmlElement()->$typeOfOrderParty->Number) === true) {
            $address .= ' ' . (string) $this->getSimpleXmlElement()->$typeOfOrderParty->Number;
        }

        return $address;

    }

    /**
     * @return string
     */
    protected function prepareAddressAdd()
    {
        $addressAdd       = '';
        $typeOfOrderParty = $this->getTypeOfOrderParty();

        if((bool) $this->getSimpleXmlElement()->$typeOfOrderParty->AddressAdd === true && strlen((string) $this->getSimpleXmlElement()->$typeOfOrderParty->AddressAdd) > 0)
        {
            $addressAdd = (string) $this->getSimpleXmlElement()->$typeOfOrderParty->AddressAdd;
        }

        return $addressAdd;
    }

    /**
     * @return mixed|string
     */
    public function splitLastName()
    {
        $lastName         = '';
        $typeOfOrderParty = $this->getTypeOfOrderParty();
        $parts            = $this->getNameParts((string) $this->getSimpleXmlElement()->$typeOfOrderParty->LastName);

        if(is_array($parts) && count($parts) !== 0)
        {
            $lastName = array_pop($parts);
        }

        return $lastName;
    }

    /**
     * @return string
     */
    protected function splitFirstName()
    {
        $firstName        = '';
        $typeOfOrderParty = $this->getTypeOfOrderParty();

        if(strlen((string) $this->getSimpleXmlElement()->$typeOfOrderParty->FirstName) > 0)
        {
            $firstName = (string) $this->getSimpleXmlElement()->$typeOfOrderParty->FirstName;
        }
        elseif(strlen((string) $this->getSimpleXmlElement()->$typeOfOrderParty->Name) <= 0)
        {
            $parts = $this->getNameParts((string) $this->getSimpleXmlElement()->$typeOfOrderParty->LastName);

            if(count($parts) > 1)
            {
                unset($parts[count($parts) - 1]);
            }

            if(count($parts) > 0)
            {
                $firstName = implode(' ', $parts);
            }
        }
        else
        {
            $parts = $this->getNameParts((string) $this->getSimpleXmlElement()->$typeOfOrderParty->Name);

            if(count($parts) > 1)
            {
                unset($parts[count($parts) - 1]);
                $firstName = implode(' ', $parts);
            }
            elseif(count($parts) === 1)
            {
                $firstName = implode(' ', $parts);
            }
        }

        return $firstName;
    }

    private function getNameParts($lastName)
    {
        return explode(' ', $lastName);
    }

    /**
     * @return string
     */
    protected function prepareCompany()
    {
        $company          = '';
        $typeOfOrderParty = $this->getTypeOfOrderParty();

        if((bool) $this->getSimpleXmlElement()->$typeOfOrderParty->Company === true)
        {
            $company = (string) $this->getSimpleXmlElement()->$typeOfOrderParty->Company;
        }

        return $company;
    }

    /**
     * @return string
     * @throws Exception
     */
    protected function prepareZipCode()
    {
        $typeOfOrderParty = $this->getTypeOfOrderParty();
        if((bool) $this->getSimpleXmlElement()->$typeOfOrderParty->PostalCode === false)
        {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE,
                LogCodes::IMPORT_ORDERS_ZIP_CODE_CODE,
                str_replace('{$orderNumber}', (string) $this->getSimpleXmlElement()->ExternOrderId, LogCodes::IMPORT_ORDERS_ZIP_CODE),
                true
            );
        }

        return (string) $this->getSimpleXmlElement()->$typeOfOrderParty->PostalCode;
    }

    /**
     * @return string
     */
    protected function prepareSalutation()
    {
        $salutation       = 'mr';
        $typeOfOrderParty = $this->getTypeOfOrderParty();

        if((bool) $this->getSimpleXmlElement()->$typeOfOrderParty->Title === true)
        {
            if(strtolower((string) $this->getSimpleXmlElement()->$typeOfOrderParty->Title) === 'mrs' || strtolower((string) $this->getSimpleXmlElement()->$typeOfOrderParty->Title) === 'frau')
            {
                $salutation = 'mrs';
            }
        }

        return $salutation;
    }

    /**
     * @return null|\Shopware\Models\Country\Country
     * @throws Exception
     */
    protected function prepareCountry()
    {
        $typeOfOrderParty = $this->getTypeOfOrderParty();

        $countryIso = (string) $this->getSimpleXmlElement()->$typeOfOrderParty->CountryIso;

        if(strlen($countryIso) <= 0 && $typeOfOrderParty === self::BILLING_ORDER_PARTY) {
            $alternativeParty = self::DELIVERY_ORDER_PARTY;
            $countryIso = (string) $this->getSimpleXmlElement()->$alternativeParty->CountryIso;
        }

        if((bool) $countryIso === false)
        {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE,
                LogCodes::IMPORT_ORDERS_COUNTRY_ISO_CODE,
                str_replace('{$orderNumber}', (string) $this->getSimpleXmlElement()->ExternOrderId, LogCodes::IMPORT_ORDERS_COUNTRY_ISO),
                true
            );
        }

        $repository = Shopware()->Models()->getRepository('Shopware\Models\Country\Country');

        $countryModel = $repository->findOneBy(array('iso' => strtoupper($countryIso)));

        if($countryModel === null)
        {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE,
                LogCodes::IMPORT_ORDERS_COUNTRY_MODEL_CODE,
                str_replace('{$orderNumber}', (string) $this->getSimpleXmlElement()->ExternOrderId, LogCodes::IMPORT_ORDERS_COUNTRY_MODEL),
                true
            );
        }

        return $countryModel;
    }

    /**
     * @return string
     */
    protected function getCustomerNumber()
    {
        $customerNumber = '';

        if ((bool) $this->getSimpleXmlElement()->CustomerId === true) {
            $customerNumber = (string) $this->getSimpleXmlElement()->CustomerId;
        }

        return $customerNumber;
    }

    /**
     * @return mixed
     */
    public function getSimpleXmlElement()
    {
        return $this->simpleXmlElement;
    }

    /**
     * @param mixed $simpleXmlElement
     *
     * @return OrdersPartiesAbstract
     */
    public function setSimpleXmlElement($simpleXmlElement)
    {
        $this->simpleXmlElement = $simpleXmlElement;

        return $this;
    }

    /**
     * @return SwCustomer
     */
    public function getCustomerModel()
    {
        return $this->customerModel;
    }

    /**
     * @param SwCustomer $customerModel
     *
     * @return OrdersPartiesAbstract
     */
    public function setCustomerModel($customerModel)
    {
        $this->customerModel = $customerModel;

        return $this;
    }

    /**
     * @return \Shopware\Models\Order\Order
     */
    public function getOrderModel()
    {
        return $this->orderModel;
    }

    /**
     * @param mixed $orderModel
     *
     * @return OrdersPartiesAbstract
     */
    public function setOrderModel($orderModel)
    {
        $this->orderModel = $orderModel;

        return $this;
    }

    /**
     * @return string
     */
    public function getTypeOfOrderParty()
    {
        return $this->typeOfOrderParty;
    }

    /**
     * @param string $typeOfOrderParty
     *
     * @return OrdersPartiesAbstract
     */
    public function setTypeOfOrderParty($typeOfOrderParty)
    {
        $this->typeOfOrderParty = $typeOfOrderParty;

        return $this;
    }

    public function __destruct()
    {
        $this->simpleXmlElement = null;
        $this->customerModel    = null;
        $this->orderModel       = null;
        $this->typeOfOrderParty = null;
    }

    abstract public function prepareOrdersPartiesInformation($isNew = true);
}
