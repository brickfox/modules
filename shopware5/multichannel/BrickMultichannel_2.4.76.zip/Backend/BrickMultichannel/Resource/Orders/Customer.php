<?php
/**
 * Customer
 *
 * @package   Bf\Multichannel\Components\Resource\Orders
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Orders;

use Bf\Multichannel\Components\Util\Helper;
use Bf\Multichannel\Components\Util\LogCodes;
use Exception;
use Shopware\Models\Order\Order as SwOrder;
use Shopware\Models\Customer\Customer as SwCustomer;

class Customer extends OrdersAbstract
{
    /**
     * @param \SimpleXMLElement $simpleXMLElement
     * @param SwOrder $order
     */
    public function __construct(\SimpleXMLElement $simpleXMLElement, SwOrder $order)
    {
        parent::__construct($simpleXMLElement, $order);
    }

    public function prepareCustomer()
    {
        $customerModel = $this->getCustomerIfExists();

        if ($customerModel === null) {
            $customerModel      = $this->createNewCustomer();
            $customerGroupModel = $this->prepareCustomerGroupModel();
            $customerModel->setGroup($customerGroupModel);

            Shopware()->Models()->persist($customerModel);

            $this->prepareBillingPartiesInformation($customerModel);
            $this->prepareDeliveryPartiesInformation($customerModel);
        } else {
            $this->prepareBillingPartiesInformation($customerModel, false);
            $this->prepareDeliveryPartiesInformation($customerModel, false);
        }

        $customerGroupModel = $this->prepareCustomerGroupModel();
        $customerModel->setGroup($customerGroupModel);
        Shopware()->Models()->persist($customerModel);

        $this->getOrdersModel()->setCustomer($customerModel);
    }

    /**
     * @return \Shopware\Models\Customer\Group
     */
    private function prepareCustomerGroupModel()
    {
        $customerGroupModel = null;

        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingOrdersToCustomerGroups');
        /** @var \Shopware\CustomModels\BfMultichannel\MappingOrdersToCustomerGroups $ordersToCustomerGroupsMappingModel */
        $ordersToCustomerGroupsMappingModel = $repository->findOneBy(array('brickfoxShopsId' => (int) $this->getXmlOrderElement()->SalesChannelId));

        if ($ordersToCustomerGroupsMappingModel !== null) {
            $repository = Shopware()->Models()->getRepository('Shopware\Models\Customer\Group');
            $customerGroupModelTmp  = $repository->findOneBy(array('id' => $ordersToCustomerGroupsMappingModel->getShopwareCustomerGroupId()));

            if ($customerGroupModelTmp !== null) {
                $customerGroupModel = $customerGroupModelTmp;
            }
        }

        if($customerGroupModel === null) {
            $defaultCustomerGroup = Helper::getConfigurationByKey('defaultCustomerGroup')->getConfigurationValue();
            $customerGroupModel   = $this->getCustomerGroupId($defaultCustomerGroup);

            $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingOrdersToShops');
            /** @var \Shopware\CustomModels\BfMultichannel\MappingOrdersToShops $ordersToShopsMappingModel */
            $ordersToShopsMappingModel = $repository->findOneBy(array('brickfoxShopsId' => (int)$this->getXmlOrderElement()->SalesChannelId));

            if ($ordersToShopsMappingModel !== null) {
                $repository = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop');
                /** @var \Shopware\Models\Shop\Shop $shopsModel */
                $shopsModel = $repository->findOneBy(array('id' => $ordersToShopsMappingModel->getShopwareShopsId()));

                if ($shopsModel !== null) {
                    $customerGroupModel = $shopsModel->getCustomerGroup();
                }
            }
        }

        return $customerGroupModel;
    }

    private function createNewCustomer()
    {
        $customer = new SwCustomer();
        $customer->setPassword($this->generateRandomPass());
        $customer->setEmail((string)$this->getXmlOrderElement()->BillingParty->EmailAddress);
        $customer->setActive(1);
        $customer->setAccountMode(1);
        $customer->setConfirmationKey('');
        $customer->setPaymentId($this->preparePaymentId());
        $customer->setFirstLogin(new \DateTime());
        $customer->setLastLogin(new \DateTime());
        $customer->setSessionId('');
        $customer->setNewsletter(0);
        $customer->setValidation('');
        $customer->setAffiliate(0);

        $customer->setPaymentPreset(0);
        $customer->setLanguageSubShop($this->prepareSubShop());

        $customer->setReferer('');
        $customer->setInternalComment('User created by brickfox GmbH');
        $customer->setFailedLogins(0);

        return $customer;
    }

    /**
     * @param SwCustomer $customer
     * @param bool $isNew
     */
    private function prepareBillingPartiesInformation(SwCustomer $customer, $isNew = true)
    {
        (new BillingParty($this->getXmlOrderElement(), $this->getOrdersModel(), $customer))->prepareOrdersPartiesInformation($isNew);
    }

    /**
     * @param SwCustomer $customer
     * @param bool $isNew
     */
    private function prepareDeliveryPartiesInformation(SwCustomer $customer, $isNew = true)
    {
        (new DeliveryParty($this->getXmlOrderElement(), $this->getOrdersModel(), $customer))->prepareOrdersPartiesInformation($isNew);
    }

    /**
     * @return null|\Shopware\Models\Shop\Shop
     */
    private function prepareSubShop()
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop');
        $shopModel  = $repository->findOneBy(array('default' => true));

        return $shopModel;
    }

    /**
     * @param $defaultCustomerGroup
     *
     * @return \Shopware\Models\Customer\Group
     */
    private function getCustomerGroupId($defaultCustomerGroup)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Customer\Group');
        /** @var \Shopware\Models\Customer\Group $customerGroupModel */
        $customerGroupModel = $repository->findOneBy(array('key' => $defaultCustomerGroup));

        return $customerGroupModel;
    }

    /**
     * @return int
     */
    private function preparePaymentId()
    {
        return $this->preparePaymentOrDispatch(self::PAYMENT_ID)->getId();
    }

    /**
     * @return null|SwCustomer
     * @throws Exception
     */
    private function getCustomerIfExists()
    {
        if ((bool)$this->getXmlOrderElement()->BillingParty->EmailAddress === false) {
            throw new Exception(str_replace('{$orderNumber}', (string)$this->getXmlOrderElement()->ExternOrderId, LogCodes::IMPORT_ORDERS_NO_EMAIL_ADDRESS_GIVEN),
                LogCodes::IMPORT_ORDERS_NO_EMAIL_ADDRESS_GIVEN_CODE);
        }

        $eMailAddress = (string)$this->getXmlOrderElement()->BillingParty->EmailAddress;
        $repository   = Shopware()->Models()->getRepository('Shopware\Models\Customer\Customer');
        /** @var \Shopware\Models\Customer\Customer $customerModel */
        $customerModel = $repository->findOneBy(array('email' => $eMailAddress));

        return $customerModel;
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
