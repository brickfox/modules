<?php
/**
 * OrderLines
 *
 * @package   Bf\Multichannel\Components\Resource\Orders
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Orders;

use Bf\Multichannel\Components\Gui\PluginConfigurations;
use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\FileManager;
use Bf\Multichannel\Components\Util\Helper;
use Bf\Multichannel\Components\Util\LastImportedOrder;
use Bf\Multichannel\Components\Util\LogCodes;
use Bf\Multichannel\Components\Util\LogManager;
use Bf\Multichannel\Components\Util\PickwareCompability;
use Exception;
use Shopware\CustomModels\BfMultichannel\MappingOrderDetailsAttributes;
use Shopware\Models\Order\Detail;
use Shopware\Models\Order\Order as SwOrder;
use Shopware\Models\Order\Detail as SwOrderDetail;

class OrderLines extends OrdersAbstract
{
    const DEFAULT_ARTICLE_NAME = 'Unbekannter Artikel';

    const EXPORT_TYPE = FileManager::FILENAME_BASE_ORDERS_STATUS;

    /** @var array */
    private $swOrderDetailsAttributes = [];

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     * @param SwOrder $order
     */
    public function __construct(\SimpleXMLElement $simpleXMLElement, SwOrder $order)
    {
        parent::__construct($simpleXMLElement, $order);
    }

    /**
     * @throws Exception
     */
    public function prepareOrderLines()
    {
        $ordersLinesDataTmp = [];

        foreach ($this->getSingleOrderLine($this->getXmlOrderElement()->OrderLine) as $orderLine) {
            $orderDetailsModel = new SwOrderDetail();

            $taxRateModel = $this->prepareTaxRate($orderLine);

            if ($taxRateModel === null) {
                // in some rare cases there might not be a s_core_tax for the TaxRate for the order
                // for example if the customer is using s_core_tax_rules to overwrite the default taxRate
                // in this case the taxID of the s_order_details model will be set to null, then the frontend displays the tax from the
                // tax_rate field instead of the value associated with the s_core_tax (taxID) model
                $taxRate = (float)$orderLine->TaxRate;
            } else {
                $taxRate = (string)$taxRateModel->getTax();
            }

            $articleDetailModel = $this->prepareArticleDetailModel($orderLine);
            $articleDetailId = $articleDetailModel->getArticleId();

            $orderDetailsModel->setTax($taxRateModel);
            $orderDetailsModel->setTaxRate($taxRate);
            $orderDetailsModel->setArticleId($articleDetailId);
            $orderDetailsModel->setArticleDetail($articleDetailModel);
            $orderDetailsModel->setArticleNumber($this->prepareArticleOrderNumber($orderLine));
            $orderDetailsModel->setArticleName($this->prepareArticleName($orderLine));
            $orderDetailsModel->setPrice($this->preparePrice($orderLine));
            $orderDetailsModel->setQuantity($this->prepareQuantity($orderLine));
            $orderDetailsModel->setStatus($this->prepareStatus());
            $orderDetailsModel->setMode(0);
            $orderDetailsModel->setOrder($this->getOrdersModel());
            $orderDetailsModel->setNumber($this->getOrdersModel()->getNumber());
            $orderDetailsModel->setEan($this->prepareEan($orderLine));

            $this->processOrderDetailsAttributes($orderDetailsModel, $orderLine);

            $ordersLinesDataTmp[] = $orderDetailsModel;

            if (ConfigManager::getInstance()->isUsePickwareCompability() === true
                && PickwareCompability::isHasRepository()
                && PickwareCompability::isSetArticleByArticle($articleDetailModel->getArticle())) {

                // this adds compability with the pickware "Stücklisten" plugin
                // pickware hooks into the oder import of shopware and converts an article that is a bundle article into its article and subarticles
                // if such a product is bought in brickfox and imported in shopware we have to do the same

                $subArticles = Shopware()->Models()->getRepository('Shopware\\CustomModels\\ViisonSetArticles\\SetArticle')->findBy([
                    'setId' => $articleDetailId,
                ]);

                foreach ($subArticles as $subArticle) {
                    $subArticleOrderDetail = new SwOrderDetail();

                    $subArticleOrderDetail->setTax($taxRateModel);
                    $subArticleOrderDetail->setTaxRate($taxRate);
                    $subArticleOrderDetail->setOrder($this->getOrdersModel());
                    $subArticleOrderDetail->setArticleId($articleDetailId); // $newArticle['articleDetailId'] = $subArticle->getArticleDetail()->getId();
                    $subArticleOrderDetail->setArticleNumber($subArticle->getArticleDetail()->getNumber());
                    $subArticleOrderDetail->setNumber($this->getOrdersModel()->getNumber()); // $newArticle['ordernumber'] = $subArticle->getArticleDetail()->getNumber();
                    $subArticleOrderDetail->setQuantity($subArticle->getQuantity() * $orderDetailsModel->getQuantity()); // $newArticle['quantity'] = $subArticle->getQuantity() * $articleDetail['quantity'];
                    $subArticleOrderDetail->setPrice(0); // $newArticle['price'] = '0,00';
                    $subArticleOrderDetail->setEan($subArticle->getArticleDetail()->getEAN()); // $newArticle['ean'] = $subArticle->getArticleDetail()->getEAN();
                    $subArticleOrderDetail->setMode($orderDetailsModel->getMode());
                    $subArticleOrderDetail->setStatus($this->prepareStatus());
                    $subArticleOrderDetail->setArticleName($subArticle->getSubArticleName(LastImportedOrder::getInstance()->getShop()));

                    $ordersLinesDataTmp[] = $subArticleOrderDetail;

                    if (class_exists('\\Shopware\\Models\\Attribute\\OrderDetail') === true) {
                        // create empty s_order_details_attributes, some other plugins might depend on that
                        $orderDetailAttributeModel = new \Shopware\Models\Attribute\OrderDetail();
                        $orderDetailAttributeModel->setOrderDetail($subArticleOrderDetail);
                        $orderDetailAttributeModel->setAttribute1('pickware_subarticle_by_brickfox');

                        $this->addSwOrderDetailsAttributes($orderDetailAttributeModel);
                    }

                    LastImportedOrder::getInstance()->addOrderDetailInfo($subArticleOrderDetail, [
                        PickwareCompability::IS_SET_SUB_ARTICLE => true,
                        PickwareCompability::VIISON_SET_ARTICLE_SET_ARTICLE_ORDER_NUMBER => $articleDetailModel->getNumber()
                    ]);
                }
            }

            LastImportedOrder::getInstance()->addOrderDetailInfo($orderDetailsModel);
        }

        if (count($ordersLinesDataTmp) > 0) {
            $this->getOrdersModel()->setDetails($ordersLinesDataTmp);
        } else {
            throw new Exception('Cannot add order missing orders line.');
        }
    }

    /**
     * @param \SimpleXMLElement $orderLine
     *
     * @return string|null
     */
    private function prepareEan(\SimpleXMLElement $orderLine)
    {
        $ean = null;

        if ((bool)$orderLine->EAN === true) {
            if (strlen((string)$orderLine->EAN) > 0) {
                $ean = (string)$orderLine->EAN;
            }
        }

        return $ean;
    }

    /**
     * @param \SimpleXMLElement $orderLine
     *
     * @return int
     * @throws Exception
     */
    private function prepareQuantity(\SimpleXMLElement $orderLine)
    {
        if ((bool)$orderLine->QuantityOrdered === true) {
            $quantity = (int)$orderLine->QuantityOrdered;
        } else {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE,
                LogCodes::IMPORT_ORDERS_NO_QUANTITY_GIVEN_CODE,
                str_replace(
                    ['{$itemNumber}', '{$orderNumber}'],
                    [(string)$orderLine->ItemNumber, (string)$this->getXmlOrderElement()->ExternOrderId],
                    LogCodes::IMPORT_ORDERS_NO_QUANTITY_GIVEN
                ),
                true
            );
        }

        return $quantity;
    }

    /**
     * @param \SimpleXMLElement $orderLine
     *
     * @return float
     * @throws Exception
     */
    private function preparePrice(\SimpleXMLElement $orderLine)
    {
        if ((bool)$orderLine->ProductsPrice === true) {
            $price = (float)$orderLine->ProductsPrice;
        } else {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE,
                LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_PRICE_GIVEN_CODE,
                str_replace(
                    ['{$itemNumber}', '{$orderNumber}'],
                    [(string)$orderLine->ItemNumber, (string)$this->getXmlOrderElement()->ExternOrderId],
                    LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_PRICE_GIVEN
                ),
                true
            );
        }

        return $price;
    }

    /**
     * @param \SimpleXMLElement $orderLine
     *
     * @return string
     */
    private function prepareArticleName(\SimpleXMLElement $orderLine)
    {
        $articleName = self::DEFAULT_ARTICLE_NAME;

        if ((bool)$orderLine->ProductName === true) {
            if (strlen((string)$orderLine->ProductName) > 0) {
                $articleName = (string)$orderLine->ProductName;
            }
        }

        return $articleName;
    }

    /**
     * @param \SimpleXMLElement $orderLine
     *
     * @return string
     * @throws Exception
     */
    private function prepareArticleOrderNumber(\SimpleXMLElement $orderLine)
    {
        if ((bool)$orderLine->ItemNumber === false) {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE,
                LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_ITEM_NUMBER_GIVEN_CODE,
                str_replace(
                    ['{$articleId}', '{$orderNumber}'],
                    [(string)$orderLine->ExternProductId, (string)$this->getXmlOrderElement()->ExternOrderId],
                    LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_ITEM_NUMBER_GIVEN
                ),
                true
            );
        }

        return (string)$orderLine->ItemNumber;
    }

    /**
     * @return \Shopware\Models\Order\DetailStatus
     */
    private function prepareStatus()
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Order\DetailStatus');
        /** @var \Shopware\Models\Order\DetailStatus $detailStatusModel */
        $detailStatusModel = $repository->findOneBy(['id' => 0]);

        return $detailStatusModel;
    }

    /**
     * @param \SimpleXMLElement $orderLine
     *
     * @return \Shopware\Models\Article\Detail
     * @throws Exception
     */
    private function prepareArticleDetailModel(\SimpleXMLElement $orderLine)
    {
        $articleModel = null;

        if (ConfigManager::getInstance()->isEnableOrderImportWithItemNumber() === true) {
            if ((bool)$orderLine->ItemNumber === false) {
                LogManager::getInstance()->createDbLogEntry(
                    time(),
                    self::EXPORT_TYPE,
                    LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_ITEM_NUMBER_GIVEN_CODE,
                    str_replace(
                        ['{$articleId}', '{$orderNumber}'],
                        [(string)$orderLine->ExternProductId, (string)$this->getXmlOrderElement()->ExternOrderId],
                        LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_ITEM_NUMBER_GIVEN
                    ),
                    true
                );
            }

            $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Detail');
            /** @var \Shopware\Models\Article\Detail $articleModel */
            $articleModel = $repository->findOneBy(['number' => (string)$orderLine->ItemNumber]);
        } else {
            if ((bool)$orderLine->ExternProductId === false) {
                LogManager::getInstance()->createDbLogEntry(
                    time(),
                    self::EXPORT_TYPE,
                    LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_PRODUCT_ID_GIVEN_CODE,
                    str_replace(
                        ['{$itemNumber}', '{$orderNumber}'],
                        [(string)$orderLine->ItemNumber, (string)$this->getXmlOrderElement()->ExternOrderId],
                        LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_PRODUCT_ID_GIVEN
                    ),
                    true
                );
            } else {
                $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Detail');
                /** @var \Shopware\Models\Article\Detail $articleModel */
                $articleModel = $repository->findOneBy(['id' => (string)$orderLine->ExternProductId]);
            }
        }

        if ($articleModel === null) {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE,
                LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_ARTICLE_NOT_FOUND_CODE,
                str_replace(
                    ['{$itemNumber}', '{$orderNumber}'],
                    [(string)$orderLine->ItemNumber, (string)$this->getXmlOrderElement()->ExternOrderId],
                    LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_ARTICLE_NOT_FOUND
                ),
                true
            );
        }

        return $articleModel;
    }

    /**
     * @param \SimpleXMLElement $orderLine
     *
     * @return null|\Shopware\Models\Tax\Tax
     */
    private function prepareTaxRate(\SimpleXMLElement $orderLine)
    {
        $taxRate = 19.00;

        if ((bool)$orderLine->TaxRate === true) {
            $taxRate = (float)$orderLine->TaxRate;
        }

        $repository = Shopware()->Models()->getRepository('Shopware\Models\Tax\Tax');
        $taxModel = $repository->findOneBy(['tax' => $taxRate]);

        return $taxModel;
    }

    /**
     * @param SwOrderDetail $orderDetailsModel
     * @param \SimpleXMLElement $orderLine
     */
    private function processOrderDetailsAttributes(Detail $orderDetailsModel, \SimpleXMLElement $orderLine)
    {
        $orderDetailAttributeModel = null;

        if (class_exists('\\Shopware\\Models\\Attribute\\OrderDetail') === true) {

            $orderDetailAttributeModel = new \Shopware\Models\Attribute\OrderDetail();
            $orderDetailAttributeModel->setOrderDetail($orderDetailsModel);

            if (isset($orderLine->OrderLineAddInfos) === true) {
                foreach ($orderLine->OrderLineAddInfos->OrderLineAddInfo as $orderLineAddInfo) {
                    $key = (string)$orderLineAddInfo->Key;
                    $value = (string)$orderLineAddInfo->Value;

                    /** @var MappingOrderDetailsAttributes $mappingOrderDetailsAttributesModel */
                    $mappingOrderDetailsAttributesModel = Helper::getMappingByValue(
                        $key,
                        'brickfoxOrderAddInfoKey',
                        'Shopware\CustomModels\BfMultichannel\MappingOrderDetailsAttributes'
                    );

                    if ($mappingOrderDetailsAttributesModel !== null) {
                        $setter = 'set' . ucfirst($mappingOrderDetailsAttributesModel->getShopwareFieldName());

                        if (method_exists($orderDetailAttributeModel, $setter)) {

                            $orderDetailAttributeModel->$setter($value);
                        }
                    }
                }
            }

            /** @var \Shopware\CustomModels\BfMultichannel\Configuration $ordersLinesIdAttributesField */
            $ordersLinesIdAttributesFieldConfigurationModel = ConfigManager::getInstance()->getConfigurationRepository()->findOneBy(
                [
                    'configurationKey' => 'ordersLinesIdAttributesField'
                ]
            );

            if ($ordersLinesIdAttributesFieldConfigurationModel !== null && strlen($ordersLinesIdAttributesFieldConfigurationModel->getConfigurationValue()) > 0) {

                $setter = 'set' . ucfirst($ordersLinesIdAttributesFieldConfigurationModel->getConfigurationValue());

                $orderDetailAttributeModel->$setter($orderLine->OrderLineId);
            }

            // always persist the s_order_details_attribute model even if the attributes are empty
            // required for shopware pickware plugin
            $this->addSwOrderDetailsAttributes($orderDetailAttributeModel);
        }
    }

    /**
     * @return array
     */
    public function getSwOrderDetailsAttributes()
    {
        return $this->swOrderDetailsAttributes;
    }

    /**
     * @param array $swOrderDetailsAttributes
     */
    public function setSwOrderDetailsAttributes($swOrderDetailsAttributes)
    {
        $this->swOrderDetailsAttributes = $swOrderDetailsAttributes;
    }

    /**
     * @param \Shopware\Models\Attribute\OrderDetail $object
     */
    public function addSwOrderDetailsAttributes(\Shopware\Models\Attribute\OrderDetail $object)
    {
        $this->swOrderDetailsAttributes[] = $object;
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
