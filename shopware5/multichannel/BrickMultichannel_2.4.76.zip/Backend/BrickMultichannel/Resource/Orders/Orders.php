<?php
/**
 * Orders
 *
 * @package   Bf\Multichannel\Components\Resource\Orders
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Resource\Orders;

use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\FileManager;
use Bf\Multichannel\Components\Util\Helper;
use Bf\Multichannel\Components\Util\LastImportedOrder;
use Bf\Multichannel\Components\Util\LogCodes;
use Bf\Multichannel\Components\Util\LogManager;
use Exception;
use Shopware\Models\Order\Order as SwOrder;
use Shopware\Models\Partner\Partner as SwPartner;

class Orders extends OrdersAbstract
{
    const BRICKFOX_ID_CODE                      = 'Brickfox';
    const S_ORDER_NUMBER_TABLE_ROW_NAME_VALUE   = 'invoice';
    const EXPORT_TYPE                           = FileManager::FILENAME_BASE_ORDERS;

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     * @param SwOrder $ordersModel
     */
    public function __construct(\SimpleXMLElement $simpleXMLElement, SwOrder $ordersModel)
    {
        parent::__construct($simpleXMLElement, $ordersModel);
    }

    /**
     * @return SwOrder
     * @throws \Doctrine\ORM\ORMException
     * @throws \Doctrine\ORM\OptimisticLockException
     * @throws \Doctrine\ORM\TransactionRequiredException
     */
    public function prepareImportOrdersInformation()
    {
        $this->getOrdersModel()->setNumber($this->prepareOrderNumber());
        $this->getOrdersModel()->setOrderStatus($this->prepareOrderStatus(self::ORDER_STATUS_TYPE_CODE));
        $this->getOrdersModel()->setPaymentStatus($this->prepareOrderStatus(self::PAYMENT_STATUS_TYPE_CODE));
        $this->getOrdersModel()->setPayment($this->preparePaymentOrDispatch(self::PAYMENT_ID));
        $this->getOrdersModel()->setDispatch($this->preparePaymentOrDispatch(self::DISPATCH_ID));
        $this->getOrdersModel()->setInvoiceAmount($this->preparePrices(self::PRICES_CODE_INVOICE_AMOUNT));
        $this->getOrdersModel()->setInvoiceAmountNet($this->preparePrices(self::PRICES_CODE_INVOICE_AMOUNT_NET));
        $this->getOrdersModel()->setInvoiceShipping($this->preparePrices(self::PRICES_CODE_INVOICE_SHIPPING));
        $this->getOrdersModel()->setInvoiceShippingNet($this->preparePrices(self::PRICES_CODE_INVOICE_SHIPPING_NET));

        if (method_exists($this->getOrdersModel(), 'setInvoiceShippingTaxRate') === true) {
            $this->getOrdersModel()->setInvoiceShippingTaxRate($this->preparePrices(self::PRICES_CODE_INVOICE_SHIPPING_TAX_RATE));
        }

        $this->getOrdersModel()->setOrderTime(new \DateTime($this->prepareOrderTime()));
        $this->getOrdersModel()->setTransactionId($this->prepareTransactionId());
        $this->getOrdersModel()->setCustomerComment($this->prepareCustomerComment());
        $this->getOrdersModel()->setComment('');
        $this->getOrdersModel()->setInternalComment('');
        $this->getOrdersModel()->setNet($this->prepareIsNetOrder());
        $this->getOrdersModel()->setTaxFree(0);
        $this->getOrdersModel()->setTemporaryId('');
        $this->getOrdersModel()->setReferer('');
        $this->getOrdersModel()->setTrackingCode('');
        $this->getOrdersModel()->setCurrencyFactor($this->prepareCurrencyFactor());
        $this->getOrdersModel()->setLanguageSubShop($this->prepareSubShop());
        $this->getOrdersModel()->setRemoteAddress('');
        $this->getOrdersModel()->setCurrency($this->prepareCurrency());
        if(ConfigManager::getInstance()->isOrderDisablePartnerImport() === false) {
            $this->getOrdersModel()->setPartner($this->preparePartner());
        }
        $this->getOrdersModel()->setShop($this->prepareSubShop());
        $this->getOrdersModel()->setTemporaryId((string)$this->getXmlOrderElement()->OrderId);

        $this->prepareCommentFields();

        if ((bool)$this->getXmlOrderElement()->OrderLines === false) {
            LogManager::getInstance()
                ->createDbLogEntry(time(), self::EXPORT_TYPE, LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_GIVEN_CODE,
                    str_replace('{$orderNumber}', (string)$this->getXmlOrderElement()->ExternOrderId, LogCodes::IMPORT_ORDERS_NO_ORDER_LINE_GIVEN), true);
        }

        $orderLinesClass = new OrderLines($this->getXmlOrderElement()->OrderLines, $this->getOrdersModel());
        $orderLinesClass->prepareOrderLines();

        if ((bool)$this->getXmlOrderElement()->BillingParty === false) {
            LogManager::getInstance()
                ->createDbLogEntry(time(), self::EXPORT_TYPE, LogCodes::IMPORT_ORDERS_NO_BILLING_ADDRESS_GIVEN_CODE,
                    str_replace('{$orderNumber}', (string)$this->getXmlOrderElement()->ExternOrderId, LogCodes::IMPORT_ORDERS_NO_BILLING_ADDRESS_GIVEN), true);
        }

        (new Customer($this->getXmlOrderElement(), $this->getOrdersModel()))->prepareCustomer();

        $this->getOrdersModel()->setAttribute($this->prepareOrderAttribute());
        Shopware()->Models()->persist($this->getOrdersModel());

        $this->prepareOrdersAttributes();

        if (count($orderLinesClass->getSwOrderDetailsAttributes()) > 0) {
            foreach ($orderLinesClass->getSwOrderDetailsAttributes() as $ordersDetailsAttributesModel) {
                Shopware()->Models()->persist($ordersDetailsAttributesModel);
            }
        }

        return $this->getOrdersModel();
    }

    private function prepareOrdersAttributes()
    {
        if (strlen(ConfigManager::getInstance()->getOrderAttributes()->getConfigurationValue()) > 0) {
            $setter = 'set' . ucfirst(ConfigManager::getInstance()->getOrderAttributes()->getConfigurationValue());
            if ((bool)$this->getXmlOrderElement()->ExternOrderId === true) {
                OrdersAttributesHelper::getInstance()->addOrdersAttributes($setter, (string)$this->getXmlOrderElement()->ExternOrderId);
            }
        }

        if (strlen(ConfigManager::getInstance()->getCustomerOrderNumberAttributesField()->getConfigurationValue()) > 0) {
            $setter = 'set' . ucfirst(ConfigManager::getInstance()->getCustomerOrderNumberAttributesField()->getConfigurationValue());
            OrdersAttributesHelper::getInstance()->addOrdersAttributes($setter, (string)$this->getXmlOrderElement()->CustomerId);
        }

        if ((bool)$this->getXmlOrderElement()->OrderAddInfos === true && (bool)$this->getXmlOrderElement()->OrderAddInfos->OrderAddInfo === true) {
            foreach ($this->getXmlOrderElement()->OrderAddInfos->OrderAddInfo as $orderAddInfo) {
                $key   = (string)$orderAddInfo->Key;
                $value = (string)$orderAddInfo->Value;

                /** @var \Shopware\CustomModels\BfMultichannel\MappingOrderAttributes $mappingOrderAttributesModel */
                $mappingOrderAttributesModel = Helper::getMappingByValue(
                    $key,
                    'brickfoxOrderAddInfoKey',
                    'Shopware\CustomModels\BfMultichannel\MappingOrderAttributes'
                );

                if ($mappingOrderAttributesModel !== null) {
                    $attributesColumnParts = explode('_', $mappingOrderAttributesModel->getShopwareFieldName());
                    $setter = '';

                    $closure = function ($columnPart) use (&$setter) {
                        if (ctype_digit($columnPart) === true) {
                            $setter .= '_' . $columnPart;
                        } else {
                            $setter .= ucfirst($columnPart);
                        }
                    };

                    array_walk($attributesColumnParts, $closure);
                    $setter = 'set' . $setter;

                    OrdersAttributesHelper::getInstance()->addOrdersAttributes($setter, $value);
                }
            }
        }
    }

    /**
     * @return string
     * @throws Exception
     */
    private function prepareOrderNumber()
    {
        $orderNumber = null;

        if ((bool)Helper::getConfigurationByKey('useExternOrdersNumberAsShopwareOrdersNumber')->getConfigurationValue() === true) {
            if ((bool)$this->getXmlOrderElement()->ExternOrderId == false) {
                LogManager::getInstance()
                    ->createDbLogEntry(time(), self::EXPORT_TYPE, LogCodes::IMPORT_ORDERS_NO_ORDER_NUMBER_GIVEN_CODE,
                        str_replace('{$orderId}', (string)$this->getXmlOrderElement()->OrderId, LogCodes::IMPORT_ORDERS_NO_ORDER_NUMBER_GIVEN), true);
            }

            $orderNumber = (string)$this->getXmlOrderElement()->ExternOrderId;
        } else {
            $repository = Shopware()->Models()->getRepository('Shopware\Models\Order\Number');
            /** @var \Shopware\Models\Order\Number $orderNumberModel */
            $orderNumberModel = $repository->findOneBy(array('name' => 'invoice'));

            if ($orderNumberModel === null) {
                LogManager::getInstance()
                    ->createDbLogEntry(time(), self::EXPORT_TYPE, LogCodes::IMPORT_ORDERS_NO_ORDER_NUMBER_GIVEN_CODE,
                        str_replace('{$orderId}', (string)$this->getXmlOrderElement()->OrderId, LogCodes::IMPORT_ORDERS_NO_ORDER_NUMBER_GIVEN), true);
            }

            $orderNumber = $orderNumberModel->getNumber() + 1;

            Shopware()->Db()->query("update s_order_number set number = ? where name= ?", array($orderNumber, self::S_ORDER_NUMBER_TABLE_ROW_NAME_VALUE));
        }

        if ($orderNumber === null) {
            LogManager::getInstance()
                ->createDbLogEntry(time(), self::EXPORT_TYPE, LogCodes::IMPORT_ORDERS_NO_ORDER_NUMBER_GIVEN_CODE,
                    str_replace('{$orderId}', (string)$this->getXmlOrderElement()->OrderId, LogCodes::IMPORT_ORDERS_NO_ORDER_NUMBER_GIVEN), true);
        }

        return (string)$orderNumber;
    }

    /**
     * @return null|\Shopware\Models\Shop\Shop
     */
    private function prepareSubShop()
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop');
        $shopModel  = $repository->findOneBy(array('default' => true));

        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingOrdersToShops');
        /** @var \Shopware\CustomModels\BfMultichannel\MappingOrdersToShops $ordersToShopsMappingModel */
        $ordersToShopsMappingModel = $repository->findOneBy(array('brickfoxShopsId' => (int)$this->getXmlOrderElement()->SalesChannelId));

        if ($ordersToShopsMappingModel !== null) {
            $repository   = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop');
            $shopModelTmp = $repository->findOneBy(array('id' => $ordersToShopsMappingModel->getShopwareShopsId()));

            if ($shopModelTmp !== null) {
                $shopModel = $shopModelTmp;
            }
        }

        if(ConfigManager::getInstance()->isUsePickwareCompability() === true) {
            LastImportedOrder::getInstance()->setShop($shopModel);
        }

        return $shopModel;
    }

    /**
     * @return null|SwPartner
     */
    private function preparePartner()
    {
        $repository   = Shopware()->Models()->getRepository('Shopware\Models\Partner\Partner');

        $idCode = self::BRICKFOX_ID_CODE;

        if(ConfigManager::getInstance()->isOrderPartnerIdIncludeSalesChannelName() === true) {
            $salesChannelName = (string)$this->getXmlOrderElement()->SalesChannelName;

            if(strlen($salesChannelName) > 0) {
                $idCode .= '-' . $salesChannelName;
            }
        }

        $partnerModel = $repository->findOneBy(array('idCode' => $idCode));

        if ($partnerModel === null) {
            $partnerModel = new SwPartner();
            $partnerModel->setActive(1);
            $partnerModel->setIdCode($idCode);
            $partnerModel->setDate(new \DateTime());
            $partnerModel->setCity('');
            $partnerModel->setStreet('');
            $partnerModel->setCompany($idCode);
            $partnerModel->setZipCode('');
            $partnerModel->setContact('');
            $partnerModel->setCookieLifeTime(0);
            $partnerModel->setCountryName('');
            $partnerModel->setEmail('');
            $partnerModel->setFax('');
            $partnerModel->setFix(0.00);
            $partnerModel->setPercent(0.00);
            $partnerModel->setWeb('');
            $partnerModel->setProfile('');
            $partnerModel->setPhone('');

            Shopware()->Models()->persist($partnerModel);
        }

        return $partnerModel;
    }

    /**
     * @return string
     */
    private function prepareCurrency()
    {
        $currency     = 'Eur';
        $currencyCode = '';

        if ((bool)$this->getXmlOrderElement()->Currency === true) {
            $currencyCode = (string)$this->getXmlOrderElement()->Currency;
        }

        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingShopwareCurrencies');
        if (empty($currencyCode) === false) {
            /** @var \Shopware\CustomModels\BfMultichannel\MappingShopwareCurrencies $shopwareCurrenciesModel */
            $shopwareCurrenciesModel = $repository->findOneBy([
                'brickfoxCurrenciesCode' => $currencyCode
            ]);
        } else {
            $shopwareCurrenciesModel = $repository->find(self::DEFAULT_CURRENCIES_ID);
        }

        if ($shopwareCurrenciesModel !== null) {
            $currency = $shopwareCurrenciesModel->getMappingFieldKey();
        }

        return $currency;
    }

    /**
     * @return int
     */
    private function prepareCurrencyFactor() {
        $currencyFactor = 1;

        if ((bool)$this->getXmlOrderElement()->Currency === true) {
            $currencyCode = (string)$this->getXmlOrderElement()->Currency;
        }

        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingShopwareCurrencies');
        if (empty($currencyCode) === false) {
            /** @var \Shopware\CustomModels\BfMultichannel\MappingShopwareCurrencies $bfMappingShopwareCurrencies */
            $bfMappingShopwareCurrencies = $repository->findOneBy([
                'brickfoxCurrenciesCode' => $currencyCode
            ]);

            if($bfMappingShopwareCurrencies !== null) {
                $shopwareCurrencyCode = $bfMappingShopwareCurrencies->getMappingFieldKey();

                $repository = Shopware()->Models()->getRepository('Shopware\Models\Shop\Currency');

                /** @var \Shopware\Models\Shop\Currency $sCoreCurrency */
                $sCoreCurrency = $repository->findOneBy([
                    'currency' => $shopwareCurrencyCode
                ]);

                if($sCoreCurrency !== null) {
                    $factor = $sCoreCurrency->getFactor();

                    if($factor !== 0.0) {
                        $currencyFactor = $factor;
                    }
                }
            }
        }

        return $currencyFactor;
    }

    /**
     * @return int
     */
    private function prepareIsNetOrder()
    {
        $isNet = 0;

        if ((bool)$this->getXmlOrderElement()->IsNet === true) {
            $isNet = 1;
        }

        return $isNet;
    }

    /**
     * @return string
     */
    private function prepareCustomerComment()
    {
        $customerComment = '';

        if ((bool)$this->getXmlOrderElement()->Comment === true) {
            $customerComment = (string)$this->getXmlOrderElement()->Comment;
        }

        return $customerComment;
    }

    /**
     * @return string
     */
    private function prepareTransactionId()
    {
        $transactionId = '';

        if ((bool)$this->getXmlOrderElement()->PaymentMethodsValues->transactionId === true) {
            $transactionId = (string)$this->getXmlOrderElement()->PaymentMethodsValues->transactionId;
        }

        return $transactionId;
    }

    /**
     * @return string
     */
    private function prepareOrderTime()
    {
        $orderTime = 'now';

        if ((bool)$this->getXmlOrderElement()->OrderDate === true) {
            $orderTime = (string)$this->getXmlOrderElement()->OrderDate;
        }

        return $orderTime;
    }

    /**
     * @param $calculationType
     *
     * @return float
     * @throws \Exception
     */
    private function preparePrices($calculationType)
    {
        $calculatedPrice = 0.00;

        $pricesClass = new Prices();

        switch ($calculationType) {
            case self::PRICES_CODE_INVOICE_AMOUNT:
                $calculatedPrice = $pricesClass->getInvoiceAmount($this->getXmlOrderElement());
                break;

            case self::PRICES_CODE_INVOICE_AMOUNT_NET:
                $calculatedPrice = $pricesClass->getInvoiceAmountNet($this->getXmlOrderElement());
                break;

            case self::PRICES_CODE_INVOICE_SHIPPING:
                $calculatedPrice = $pricesClass->getInvoiceShipping($this->getXmlOrderElement());
                break;

            case self::PRICES_CODE_INVOICE_SHIPPING_NET:
                $calculatedPrice = $pricesClass->getInvoiceShippingNet($this->getXmlOrderElement());
                break;
            case self::PRICES_CODE_INVOICE_SHIPPING_TAX_RATE:
                $calculatedPrice = $pricesClass->getInvoiceShippingTaxRate($this->getXmlOrderElement());

            default:
                break;
        }

        unset($pricesClass);

        return $calculatedPrice;
    }

    /**
     * @param string $statusTypeCode
     *
     * @return null|\Shopware\Models\Order\Status
     * @throws Exception
     * @throws \Doctrine\ORM\ORMException
     * @throws \Doctrine\ORM\OptimisticLockException
     * @throws \Doctrine\ORM\TransactionRequiredException
     */
    public function prepareOrderStatus($statusTypeCode = self::ORDER_STATUS_TYPE_CODE)
    {
        $status = null;

        switch ($statusTypeCode) {
            case self::ORDER_STATUS_TYPE_CODE:
                $strOrderStatusForOrdersWithComment = ConfigManager::getInstance()->getOrderStatusForOrdersWithComment();

                if(strlen($strOrderStatusForOrdersWithComment) > 0 && strlen((string)$this->getXmlOrderElement()->Comment) > 0) {
                    /** @var \Shopware\Models\Order\Status $status */
                    $status = Shopware()->Models()->find('Shopware\Models\Order\Status', $strOrderStatusForOrdersWithComment);
                }

                if ($status instanceof \Shopware\Models\Order\Status === false) {
                    /** @var \Shopware\Models\Order\Status $status */
                    $status = Shopware()->Models()->find('Shopware\Models\Order\Status', $this->getDefaultOrderStatus());
                }

                if ($status instanceof \Shopware\Models\Order\Status === false) {
                    LogManager::getInstance()
                        ->createDbLogEntry(time(), self::EXPORT_TYPE, LogCodes::IMPORT_ORDERS_NO_ORDER_STATUS_MODEL_FOUND_CODE,
                            str_replace('{$orderNumber}', (string)$this->getXmlOrderElement()->ExternOrderId, LogCodes::IMPORT_ORDERS_NO_ORDER_STATUS_MODEL_FOUND), true);
                }

                $status->setGroup($status::GROUP_STATE);
                break;

            case self::PAYMENT_STATUS_TYPE_CODE:

                if ((bool)$this->getXmlOrderElement()->PaymentMethod !== true) {
                    LogManager::getInstance()
                        ->createDbLogEntry(time(), self::EXPORT_TYPE, LogCodes::IMPORT_ORDERS_NO_PAYMENT_METHOD_GIVEN_CODE,
                            str_replace('{$orderNumber}', (string)$this->getXmlOrderElement()->ExternOrderId, LogCodes::IMPORT_ORDERS_NO_PAYMENT_METHOD_GIVEN), true);
                }

                /** @var \Shopware\Models\Order\Status $status */
                $status = $this->getMatchedPaymentMethod();

                if ($status instanceof \Shopware\Models\Order\Status === false) {
                    LogManager::getInstance()
                        ->createDbLogEntry(time(), self::EXPORT_TYPE, LogCodes::IMPORT_ORDERS_NO_ORDER_STATUS_MODEL_FOUND_CODE,
                            str_replace('{$orderNumber}', (string)$this->getXmlOrderElement()->ExternOrderId, LogCodes::IMPORT_ORDERS_NO_ORDER_STATUS_MODEL_FOUND), true);
                }

                $status->setGroup($status::GROUP_PAYMENT);
                break;

            default:
                break;
        }

        return $status;
    }

    /**
     * @return int
     */
    private function getDefaultOrderStatus()
    {
        $orderStatus = ConfigManager::getInstance()->getOrdersDefaultStatus();

        if (empty($orderStatus)) {
            $orderStatus = self::ORDER_STATUS_ID;
        }

        return $orderStatus;
    }

    /**
     * @return null|object
     * @throws \Doctrine\ORM\ORMException
     * @throws \Doctrine\ORM\OptimisticLockException
     * @throws \Doctrine\ORM\TransactionRequiredException
     */
    private function getMatchedPaymentMethod()
    {
        $paymentStatusId = self::DEFAULT_PAYMENT_STATUS_ID;

        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingPayment');
        /** @var \Shopware\CustomModels\BfMultichannel\MappingPayment $paymentMappingModel */
        $paymentMappingModel = $repository->findOneBy(array('brickfoxPaymentCode' => (string)$this->getXmlOrderElement()->PaymentMethod));

        if ($paymentMappingModel !== null) {
            $paymentStatusId = $paymentMappingModel->getMappingFieldKey();
        }

        return Shopware()->Models()->find('Shopware\Models\Order\Status', $paymentStatusId);
    }

    private function prepareCommentFields(){
        $commentString = '';
        if(
            ConfigManager::getInstance()->isEnableShopsOrderIdToCommentActive() === true ||
            ConfigManager::getInstance()->isEnableShopsNameToCommentActive() === true ||
            ConfigManager::getInstance()->isEnableShopsCustomerIdToCommentActive() === true
        ) {
            $commentString = $this->getShopsInformationCommentString();

            $setter = 'set' . ucfirst(ConfigManager::getInstance()->getShopsInformationCommentField());
            if(method_exists($this->getOrdersModel(), $setter) && strlen($commentString) > 0) {
                $this->getOrdersModel()->$setter($commentString);
            }
        }

        $orderNumberInCommentField = ConfigManager::getInstance()->getOrderNumberInCommentField();
        if(!empty($orderNumberInCommentField)){
            $purchaseOrderNumber = $this->getAdditionalInformationValueIfExists('PurchaseOrderNumber');
            if(!empty($purchaseOrderNumber)){
                $setter = 'set' . ucfirst(ConfigManager::getInstance()->getOrderNumberInCommentField());
                if(method_exists($this->getOrdersModel(), $setter)) {
                    $commentString = $this->appendElementToCommentString($commentString, $purchaseOrderNumber);
                    $this->getOrdersModel()->$setter($commentString);
                }
            }
        }
    }

    /**
     * @return string
     */
    private function getShopsInformationCommentString() {

        $commentString = '';

        if(
            ConfigManager::getInstance()->isEnableShopsNameToCommentActive() === true &&
            (bool)$this->getXmlOrderElement()->SalesChannelName === true
        ) {
            $commentString .= (string)$this->getXmlOrderElement()->SalesChannelName;
        }

        if(
            ConfigManager::getInstance()->isEnableShopsOrderIdToCommentActive() === true &&
            (bool)$this->getXmlOrderElement()->ExternOrderId === true
        ) {
            $commentString = $this->appendElementToCommentString($commentString, (string)$this->getXmlOrderElement()->ExternOrderId);
        }

        if(
            ConfigManager::getInstance()->isEnableShopsCustomerIdToCommentActive() === true &&
            (bool)$this->getXmlOrderElement()->CustomerId === true
        ) {
            $commentString = $this->appendElementToCommentString($commentString, (bool)$this->getXmlOrderElement()->CustomerId);
        }

        return $commentString;
    }

    /**
     * @param string $commentString
     * @param string $valueToAppend
     * @return string
     */
    private function appendElementToCommentString($commentString, $valueToAppend)
    {
        if(strlen($commentString) > 0 && strlen($valueToAppend) > 0) {
            $commentString .= ' - ';
        }

        $commentString .= $valueToAppend;

        return $commentString;
    }

    /**
     * @param $key
     * @return string
     */
    private function getAdditionalInformationValueIfExists($key){
        if ((bool)$this->getXmlOrderElement()->OrderAddInfos === true && (bool)$this->getXmlOrderElement()->OrderAddInfos->OrderAddInfo === true) {
            foreach ($this->getXmlOrderElement()->OrderAddInfos->OrderAddInfo as $orderAddInfo) {
                if ($key === (string)$orderAddInfo->Key){
                    return (string)$orderAddInfo->Value;
                }
            }
        }
        return '';
    }

    private function prepareOrderAttribute() {
        $orderAttributeModel = new \Shopware\Models\Attribute\Order();

        Shopware()->Models()->persist($orderAttributeModel);

        return $orderAttributeModel;
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
