<?php
/**
 * ExportAbstract
 *
 * @package   Bf\Multichannel\Components
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components;

use Bf\Multichannel\Components\Util\ApiExport;
use Bf\Multichannel\Components\Util\Exceptions\SkipItemExportException;
use Bf\Multichannel\Components\Util\FileManager;
use Bf\Multichannel\Components\Util\FileWriter;
use Bf\Multichannel\Components\Util\Helper;
use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\Iterator;
use Bf\Multichannel\Components\Util\LogCodes;
use Bf\Multichannel\Components\Util\LogManager;
use Bf\Multichannel\Components\Util\ScriptLogger;
use Bf\Multichannel\Components\Util\Upload;
use Bf\Multichannel\Components\Resource\Categories\Repository as CategoriesRepository;
use Bf\Multichannel\Components\Resource\Products\Repository as ProductsRepository;
use Exception;
use Shopware\CustomModels\BfMultichannel\MappingMultiShopExport;
use Shopware\Models\Article\Article;
use Shopware\Models\Order\Order;
use XMLWriter;
use Shopware\Models\Shop\Shop;

abstract class ExportAbstract extends Iterator
{
    const ITEM_EXPORT_PACKAGE_LIMIT = 5000;

    /** @var int */
    protected $exportItemsCount = 1;

    /** @var int */
    protected $itemsCount = 1;

    private $alternativeRootName = null;

    /** @var bool */
    private $isMultiShopExport = false;

    /**
     * @param $exportTypeCode
     */
    public function export($exportTypeCode)
    {
        $itemPackageCounter = 1;
        $this->preExport();
        $suppliersExported = false;

        /** @var Shop $shopModel */
        foreach(ConfigManager::getInstance()->getMultiShopModels() as $shopModel)
        {
            if ($exportTypeCode === FileManager::FILENAME_BASE_MANUFACTURERS && $suppliersExported === false) {
                $suppliersExported = true;
            } elseif ($exportTypeCode === FileManager::FILENAME_BASE_MANUFACTURERS && $suppliersExported = true) {
                break;
            }

            ConfigManager::getInstance()->setMultiShopsId($shopModel->getId());

            $exportItemList = $this->prepareExportItemList($exportTypeCode, $shopModel);

            if(count($exportItemList) > 0)
            {
                if($this->getAlternativeRootName() !== null)
                {
                    $rootNodeName = $this->getAlternativeRootName();
                }
                else
                {
                    $rootNodeName = $exportTypeCode;
                }

                $iterator = new Iterator($exportItemList);
                $iterator->rewind();

                Helper::checkPath($this->getDestinationDirectory(), true);

                $itemCounter    = 0;
                $writePackage   = false;
                $xmlWriter      = null;
                $totalItemCount = count($exportItemList);
                $writtenItem    = false;

                while($iterator->valid() === true)
                {
                    if($writePackage === false)
                    {
                        $writtenItem         = false;
                        $writePackage        = true;
                        $fileDestinationPath = FileManager::getInstance()->getUri($exportTypeCode, $itemPackageCounter);

                        $xmlWriter = new XMLWriter();
                        $xmlWriter->openUri($fileDestinationPath);
                        $xmlWriter->setIndent(true);
                        $xmlWriter->startDocument('1.0', 'UTF-8');
                        $xmlWriter->startElement($rootNodeName);
                        $xmlWriter->writeAttribute('count', count($exportItemList));
                    }

                    try
                    {
                        $this->processExport($iterator->current(), $xmlWriter);
                        $this->setExportItemsCount(1);
                        $itemCounter++;
                        FileWriter::$internalArrayKeyCounter++;
                        FileWriter::$xmlElements = array();
                        $writtenItem = true;

                        if($exportTypeCode === FileManager::FILENAME_BASE_PRODUCTS)
                        {
                            (new ApiExport($iterator->current()))->setApiExportProducts();
                        }
                        elseif($exportTypeCode === FileManager::FILENAME_BASE_PRODUCTS_ASSIGNMENTS)
                        {
                            (new ApiExport($iterator->current()))->setApiExportProducts(FileManager::FILENAME_BASE_PRODUCTS_ASSIGNMENTS);
                        }
                        elseif($exportTypeCode === FileManager::FILENAME_BASE_PRODUCTS_UPDATE)
                        {
                            (new ApiExport($iterator->current()))->setApiExportProductsUpdate();
                        }

                        Shopware()->Models()->flush();
                        Shopware()->Models()->clear();
                    }
                    catch(SkipItemExportException $e) {
                        // nothing to do, as this was intentional
                    }
                    catch(Exception $e)
                    {
                        ScriptLogger::getInstance()->errorHandler($e->getCode(), $e->getMessage(), $e->getFile(), $e->getLine());
                        LogManager::getInstance()->logException($e, $exportTypeCode);
                    }

                    $totalItemCount -= 1;
                    if($itemCounter === self::ITEM_EXPORT_PACKAGE_LIMIT || $totalItemCount === 0)
                    {
                        $itemCounter  = 0;
                        $writePackage = false;

                        $xmlWriter->endElement();
                        $xmlWriter->endDocument();

                        FileWriter::$internalArrayKeyCounter = 0;
                        if ($writtenItem === true) {
                            $this->postExport($fileDestinationPath);
                        } else {
                            if (file_exists($fileDestinationPath) === true) {
                                unlink($fileDestinationPath);
                            }
                        }
                        $itemPackageCounter++;
                    }

                    $iterator->next();
                }
            }
            else
            {
                LogManager::getInstance()->createDbLogEntry(
                    time(),
                    $exportTypeCode,
                    LogCodes::EXPORT_NOTHING_TO_DO_CODE,
                    LogCodes::EXPORT_NOTHING_TO_DO,
                    false
                );
            }

            LogManager::getInstance()->createDbLogEntry(
                time(),
                $exportTypeCode,
                LogCodes::EXPORT_SUCCESS_CODE,
                str_replace(array('{$countItemsList}', '{$countItem}'), array($this->getExportItemsCount() - 1, count($exportItemList)), LogCodes::EXPORT_SUCCESS),
                false
            );
        }

        $this->concretePostExport();
    }

    private function concretePostExport()
    {
        // 14 days
        $cleanBfScriptloggerAfterDaysConfiguration = ConfigManager::getInstance()->getScriptloggerCleanTimer()->getConfigurationValue();
        Shopware()->Db()->query(
            "delete from bf_scriptlogger where date_start < DATE_SUB(now(), INTERVAL ? DAY)",
            [(int)$cleanBfScriptloggerAfterDaysConfiguration]
        );
    }

    private function preExport()
    {
        if(ConfigManager::getInstance()->getMultiShopExportConfiguration()->getConfigurationValue() == '1')
        {
            ConfigManager::getInstance()->setIsMultiShop(true);

            $repositoryMultiShopExportMapping = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingMultiShopExport');
            $multiShopExportMappingList       = $repositoryMultiShopExportMapping->findAll();

            if(count($multiShopExportMappingList) > 0)
            {
                /** @var MappingMultiShopExport $multiShopExport */
                foreach($multiShopExportMappingList as $multiShopExport)
                {
                    $repository = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop');
                    /** @var Shop $shopModel */
                    $shopModel = $repository->findOneBy(array('id' => $multiShopExport->getMappingFieldKey()));

                    if($shopModel !== null)
                    {
                        ConfigManager::getInstance()->setMultiShopModels($shopModel);
                        ConfigManager::getInstance()->setMultiShopsCategoriesIds($shopModel->getCategory()->getId());
                    }
                }
            }
        }
        else
        {
            $repository = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop');
            /** @var Shop $shopModel */
            $shopModel = $repository->findOneBy(array('default' => true, 'active' => 1));

            if($shopModel !== null)
            {
                ConfigManager::getInstance()->setMultiShopModels($shopModel);
                ConfigManager::getInstance()->setMultiShopsCategoriesIds($shopModel->getCategory()->getId());
            }
        }
    }

    /**
     * @param $fileDestinationPath
     */
    private function postExport($fileDestinationPath)
    {
        $uploadClass = null;

        if(ConfigManager::getInstance()->getIsMultiShop() === true)
        {
            $ftpUser       = ConfigManager::getInstance()->getFtpUser(ConfigManager::getInstance()->getMultiShopsId());
            $ftpPass       = ConfigManager::getInstance()->getFtpPass(ConfigManager::getInstance()->getMultiShopsId());
            $ftpHost       = ConfigManager::getInstance()->getFtpHost(ConfigManager::getInstance()->getMultiShopsId());
            $ftpSslPort    = ConfigManager::getInstance()->getFtpSslPort(ConfigManager::getInstance()->getMultiShopsId());
            $ftpSslActive  = ConfigManager::getInstance()->getFtpSslIsActive(ConfigManager::getInstance()->getMultiShopsId());
            $ftpOrdersPath = ConfigManager::getInstance()->getFtpOrdersPath(ConfigManager::getInstance()->getMultiShopsId());

            if($ftpUser === null || $ftpPass === null || $ftpHost === null || $ftpSslPort === null
                || $ftpSslActive === null || $ftpOrdersPath === null)
            {
                // fallback
                $ftpUser    = ConfigManager::getInstance()->getFtpUser();
                $ftpPass    = ConfigManager::getInstance()->getFtpPass();
                $ftpHost    = ConfigManager::getInstance()->getFtpHost();
                $ftpSslPort = ConfigManager::getInstance()->getFtpSslPort();
                $ftpSslActive  = null;
                $ftpOrdersPath = null;
            }

            try
            {
                if($ftpUser !== null && $ftpPass !== null && $ftpHost !== null && $ftpSslPort !== null)
                {
                    if($ftpSslActive !== null) {
                        $ftpSslActive = $ftpSslActive->getConfigurationValue();
                    }

                    if($ftpOrdersPath !== null) {
                        $ftpOrdersPath = $ftpOrdersPath->getConfigurationValue();
                    }

                    $uploadClass = new Upload(
                        $ftpUser->getConfigurationValue(),
                        $ftpPass->getConfigurationValue(),
                        $ftpHost->getConfigurationValue(),
                        $ftpSslPort->getConfigurationValue(),
                        $ftpSslActive,
                        $ftpOrdersPath
                    );
                }
                else
                {
                    throw new Exception('Cannot upload file via FTP for multi shop with ID: ' . ConfigManager::getInstance()->getMultiShopsId());
                }
            }
            catch(Exception $e)
            {
                ScriptLogger::getInstance()->errorHandler($e->getCode(), $e->getMessage(), $e->getFile(), $e->getLine());
                LogManager::getInstance()->logException($e, 'File_Transfer');
            }
        }
        else
        {
            $uploadClass = new Upload(
                ConfigManager::getInstance()->getFtpUser()->getConfigurationValue(),
                ConfigManager::getInstance()->getFtpPass()->getConfigurationValue(),
                ConfigManager::getInstance()->getFtpHost()->getConfigurationValue(),
                ConfigManager::getInstance()->getFtpSslPort()->getConfigurationValue()
            );
        }

        if($uploadClass instanceof Upload)
        {
            $uploadClass->setUploadFileName($fileDestinationPath)->prepareItemUpload();
            FileManager::getInstance()->moveExportFile($fileDestinationPath);

            Shopware()->Db()->query(
                "delete from bf_api_export_log where date(date_insert) < curdate() - 30 and date_insert != '0000-00-00 00:00:00'"
            );

            Shopware()->Db()->query(
                "delete from bf_api_import_orders where date(last_update) < curdate() - 30 and last_update != '0000-00-00 00:00:00'"
            );

            FileManager::getInstance()->recursiveDeleteFiles();
        }
    }

    /**
     * @param      $exportTypeCode
     * @param Shop $shopModel
     *
     * @return array|null
     */
    private function prepareExportItemList($exportTypeCode, Shop $shopModel)
    {
        $exportItemList = null;
        
        try
        {
            switch($exportTypeCode)
            {
                case FileManager::FILENAME_BASE_MANUFACTURERS:
                    $qb = Shopware()->Models()->createQueryBuilder();

                    $qb->select(array('suppliers'))->from('\Shopware\Models\Article\Supplier', 'suppliers');

                    $sql            = $qb->getQuery();
                    $exportItemList = $sql->getArrayResult();
                    break;

                case FileManager::FILENAME_BASE_CATEGORIES:
                    $categoriesRepositoryClass = new CategoriesRepository();
                    $categoriesRepositoryClass->setMainCategoriesId($shopModel->getCategory()->getId());
                    $categoriesRepositoryClass->getExportCategoriesByMainCategoryId();
                    $exportItemList = $categoriesRepositoryClass->getCategories();
                    break;

                case FileManager::FILENAME_BASE_PRODUCTS_UPDATE:
                    $productsRepositoryClass = new ProductsRepository();
                    $productsRepositoryClass->getProductsUpdateExportItemList($shopModel->getCategory()->getId());
                    $exportItemList = $productsRepositoryClass->getProducts();
                    break;

                case FileManager::FILENAME_BASE_PRODUCTS:
                    $productsRepositoryClass = new ProductsRepository();
                    $productsRepositoryClass->getProductsExportItemList($shopModel->getCategory()->getId());
                    $exportItemList = $productsRepositoryClass->getProducts();
                    break;

                case FileManager::FILENAME_BASE_ORDERS_STATUS:
                    $productsRepositoryClass = new ProductsRepository();
                    $productsRepositoryClass->getProductsExportOrdersStatusItemList($shopModel->getId());
                    $exportItemList = $productsRepositoryClass->getProducts();
                    break;

                case FileManager::FILENAME_BASE_PRODUCTS_DELETE:
                    $productsRepositoryClass = new ProductsRepository();
                    $productsRepositoryClass->getProductsExportToDeleteItemList();
                    $exportItemList = $productsRepositoryClass->getProducts();
                    break;

                case FileManager::FILENAME_BASE_PRODUCTS_ASSIGNMENTS:
                    $productsRepositoryClass = new ProductsRepository();
                    $productsRepositoryClass->getProductsAssignmentItemList($shopModel->getCategory()->getId());
                    $exportItemList = $productsRepositoryClass->getProducts();
                    break;

                default:
                    break;
            }
        }
        catch(Exception $e)
        {
            echo $e->getMessage();
        }

        return $exportItemList;
    }

    /**
     * @return string
     */
    private function getDestinationDirectory()
    {
        return Shopware()->DocPath() . ConfigManager::getInstance()->getOutgoingDestinationDirectory();
    }

    /**
     * @return int
     */
    public function getExportItemsCount()
    {
        return $this->exportItemsCount;
    }

    /**
     * @param int $exportItemsCount
     *
     * @return ExportAbstract
     */
    public function setExportItemsCount($exportItemsCount)
    {
        $this->exportItemsCount += $exportItemsCount;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getAlternativeRootName()
    {
        return $this->alternativeRootName;
    }

    /**
     * @param mixed $alternativeRootName
     *
     * @return ExportAbstract
     */
    public function setAlternativeRootName($alternativeRootName)
    {
        $this->alternativeRootName = $alternativeRootName;

        return $this;
    }

    /**
     * @return boolean
     */
    public function getIsMultiShopExport()
    {
        return $this->isMultiShopExport;
    }

    /**
     * @param boolean $isMultiShopExport
     *
     * @return ExportAbstract
     */
    public function setIsMultiShopExport($isMultiShopExport)
    {
        $this->isMultiShopExport = $isMultiShopExport;

        return $this;
    }

    /**
     * @param array|Article|Order $item
     * @param XmlWriter                                                           $xmlWriter
     *
     * @return mixed
     *
     * @throws Exception
     * @throws SkipItemExportException
     */
    abstract protected function processExport($item, XMLWriter $xmlWriter);
}
