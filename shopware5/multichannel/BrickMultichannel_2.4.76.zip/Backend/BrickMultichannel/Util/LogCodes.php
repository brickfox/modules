<?php
/**
 * LogCodes
 *
 * @package   Bf\Multichannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

class LogCodes
{
    const EXPORT_SUCCESS_CODE = '-';
    const EXPORT_SUCCESS = '<strong>Es wurden {$countItemsList} von {$countItem} exportiert.</strong>';

    const EXPORT_NOTHING_TO_DO_CODE = 1401;
    const EXPORT_NOTHING_TO_DO = '<strong>Es gibt keine aktuellen Daten zu exportieren.</strong>';

    const EXPORT_PRODUCTS_ASSIGNMENTS_CODE = 1402;
    const EXPORT_PRODUCTS_ASSIGNMENTS = '<strong>Das Produkt mit der Artikelnummer: {$itemNumber} muss als erstes initial an brickfox übertragen werden, bevor Verknüpfungen erstellt werden können.</strong>';

    const EXPORT_CATEGORIES_BY_DEFAULT_CODE = 1403;
    const EXPORT_CATEGORIES_BY_DEFAULT = '<strong>Es kann keine Root-Kategorie gefunden werden, bitte prüfen Sie die Einstellungen in Ihrem Shop.</strong>';

    const EXPORT_ORDERS_STATUS_NO_HISTORY_CODE = 1404;
    const EXPORT_ORDERS_STATUS_NO_HISTORY = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNumber}, wurde keine Status History gefunden.</strong>';

    const EXPORT_PRICE_WITHOUT_CURRENCIES_CODE = 1405;
    const EXPORT_PRICE_WITHOUT_CURRENCIES = '<strong>Bitte hinterlegen Sie ein Währungs-Mapping. Produkte ohne Währungs-Mapping können nicht exportiert werden.</strong>';

    const EXPORT_TRANSLATION_WITHOUT_LOCALE_ISO_CODE = 1406;
    const EXPORT_TRANSLATION_WITHOUT_LOCALE_ISO = '<strong>Die Sprache des Hauptshops konnte nicht festgelegt werden, bitte überprüfen Sie das.</strong>';

    const EXPORT_TRANSLATION_MAPPING_ERROR_CODE = 1407;
    const EXPORT_TRANSLATION_MAPPING_ERROR = '<strong>Sie müssen die ISO Sprachen Mappen damit die Artikel korrekt übertragen werden.</strong>';

    const EXPORT_DESCRIPTION_NO_PRODUCTS_NAME_CODE = 1408;
    const EXPORT_DESCRIPTION_NO_PRODUCTS_NAME = '<strong>Das Produkt mit der Artikelnummer: {$itemNumber}, hat keinen Produktnamen. <br />In brickfox ist ein Produktname aber zwingend Pflicht. Bitte bereinigen Sie diesen Fehler damit das Produkt korrekt ausgesteuert werden kann.</strong>';

    const EXPORT_MEDIA_TYPE_NOT_FOUND_CODE = 1409;
    const EXPORT_MEDIA_TYPE_NOT_FOUND = '<strong>Der Medien Type der Mediendatei kann nicht erkannt werden.</strong>';

    const IMPORT_ORDERS_TOTAL_AMOUNT_CODE = 1410;
    const IMPORT_ORDERS_TOTAL_AMOUNT = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNumber}, konnte kein Gesamt Betrag gefunden werden, <br />bitte wenden Sie sich an die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_INVOICE_AMOUNT_NET_CODE = 1411;
    const IMPORT_ORDERS_INVOICE_AMOUNT_NET = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNumber}, konnte kein Nettobetrag berechnet werden.</strong>';

    const IMPORT_ORDERS_INVOICE_SHIPPING_CODE = 1412;
    const IMPORT_ORDERS_INVOICE_SHIPPING = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNumber}, konnten keine Versandkosten ermittelt werden. <br />Bitte kontaktieren sie die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_ZIP_CODE_CODE = 1413;
    const IMPORT_ORDERS_ZIP_CODE = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNumber}, konnte keine Postleitzahl festgelegt werden, <br />bitte kontaktieren Sie die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_COUNTRY_ISO_CODE = 1414;
    const IMPORT_ORDERS_COUNTRY_ISO = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNumber}, konnte kein Lieferland erkannt werden, <br />bitte kontaktieren Sie die brickfox GmbH</strong>';

    const IMPORT_ORDERS_COUNTRY_MODEL_CODE = 1415;
    const IMPORT_ORDERS_COUNTRY_MODEL = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNumber}, konnte in Shopware kein Land gefunden werden, <br />bitte wenden Sie sich an die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_NO_PAYMENT_METHOD_GIVEN_CODE = 1416;
    const IMPORT_ORDERS_NO_PAYMENT_METHOD_GIVEN = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNUmber}, konnte keine Zahlart gefunden werden, <br />bitte wenden Sie sich an die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_NO_PAYMENT_MODEL_FOUND_CODE = 1417;
    const IMPORT_ORDERS_NO_PAYMENT_MODEL_FOUND = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNumber}, konnte keine passende Shopware Zahlart gefunden werden, <br />bitte wenden Sie sich an die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_NO_SHIPPING_METHOD_GIVEN_CODE = 1418;
    const IMPORT_ORDERS_NO_SHIPPING_METHOD_GIVEN = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNumber}, konnte keine Versandart gefunden werden, <br />bitte wenden Sie sich an die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_NO_SHIPPING_MODEL_FOUND_CODE = 1419;
    const IMPORT_ORDERS_NO_SHIPPING_MODEL_FOUND = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNumber}, konnte keine passende Shopware Versandart gefunden werden, <br />bitte wenden Sie sich an die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_NO_ORDER_LINE_GIVEN_CODE = 1420;
    const IMPORT_ORDERS_NO_ORDER_LINE_GIVEN = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNumber}, konnte keine Bestellposition gefunden werden, <br />bitte wenden Sie sich an die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_NO_BILLING_ADDRESS_GIVEN_CODE = 1421;
    const IMPORT_ORDERS_NO_BILLING_ADDRESS_GIVEN = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNumber}, konnte keine Rechnungsaddresse gefunden werden. <br />Bitte kontaktieren Sie die brickfox GmbH</strong>';

    const IMPORT_ORDERS_NO_ORDER_NUMBER_GIVEN_CODE = 1422;
    const IMPORT_ORDERS_NO_ORDER_NUMBER_GIVEN = '<strong>Für die Bestellung mit der Bestell-ID: {$orderId}, konnte keine Bestellnummer gefunden werden, <br />bitte wenden Sie sich an die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_NO_ORDER_STATUS_MODEL_FOUND_CODE = 1423;
    const IMPORT_ORDERS_NO_ORDER_STATUS_MODEL_FOUND = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNumber}, konnte kein passender Bestellstatus gefunden werden, <br />bitte wenden Sie sich an die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_NO_QUANTITY_GIVEN_CODE = 1424;
    const IMPORT_ORDERS_NO_QUANTITY_GIVEN = '<strong>Für die Bestellposition mit der Artikelnummer: {$itemNumber}, Bestellnummer: {$orderNumber}, konnte keine Bestellmenge gefunden werden, <br />bitte wenden Sie sich an die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_NO_ORDER_LINE_PRICE_GIVEN_CODE = 1425;
    const IMPORT_ORDERS_NO_ORDER_LINE_PRICE_GIVEN = '<strong>Für die Bestellposition mit der Artikelnummer: {$itemNumber}, Bestellnummer: {$orderNumber}, konnte keine Preis gefunden werden, <br />bitte wenden Sie sich an die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_NO_ORDER_LINE_ITEM_NUMBER_GIVEN_CODE = 1426;
    const IMPORT_ORDERS_NO_ORDER_LINE_ITEM_NUMBER_GIVEN = '<strong>Für die Bestellposition mit der Artikel-ID: {$articleId}, Bestellnummer: {$orderNumber}, konnte keine Artikelnummer gefunden werden, <br />bitte konatktieren Sie die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_NO_ORDER_LINE_PRODUCT_ID_GIVEN_CODE = 1427;
    const IMPORT_ORDERS_NO_ORDER_LINE_PRODUCT_ID_GIVEN = '<strong>Für die Bestellposition mit der Artikelnummer: {$itemNumber}, Bestellnummer: {$orderNumber}, konnte keine System-ID gefunden werden, <br />bitte wenden Sie sich an die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_NO_ORDER_LINE_ARTICLE_NOT_FOUND_CODE = 1428;
    const IMPORT_ORDERS_NO_ORDER_LINE_ARTICLE_NOT_FOUND = '<strong>Für die Bestellposition konnte der gewünschte Artikel mit der Artikelnummer: {$itemNumber}, Bestellnummer: {$orderNumber}, nicht gefunden werden. <br />Bitte wenden Sie sich an die brickfox GmbH.</strong>';

    const IMPORT_ORDERS_NO_EMAIL_ADDRESS_GIVEN_CODE = 1429;
    const IMPORT_ORDERS_NO_EMAIL_ADDRESS_GIVEN = '<strong>Für die Bestellung mit der Bestellnummer: {$orderNumber}, wurde keine Email-Adresse gefunden, bitte wenden Sie sich an die brickfox GmbH.</strong>';

    const EXPORT_FTP_CONNECTION_TEST_CODE = 1430;
    const EXPORT_FTP_CONNECTION_TEST = '<strong>Die Verbindung zu FTP-Server ist fehlgeschlagen, bitte überprüfen Sie Ihre Konfiguration.</strong>';

    const EXPORT_FTP_TRANSFER_CODE = 1431;
    const EXPORT_FTP_TRANSFER = '<strong>Die Datei {$fileName} konnte nicht erfolgreich übertragen werden, bitte überprüfen Sie Ihre konfiguration.</strong>';

    const EXPORT_FTP_EXTENSION_NOT_INSTALLED_CODE = 1432;
    const EXPORT_FTP_EXTENSION_NOT_INSTALLED = '<strong>Auf dem Server ist die FTP - Erweiterung nicht installiert, bitte kontaktieren Sie Ihren Hoster.</strong>';

    const SAVE_MAPPING_SUCCESSFUL = 'Das Mapping-Model: {$mappingModel} wurde erfolgreich gespeichert. Für folgende Keys: {$key}, wurden die folgenden Einträge gespeichert: {$values}';

    const SAVE_MAPPING_ERROR = 'Das Mapping-Model: {$mappingModel} konnte nicht erfolgreich gespeichert werden. Bitte versuchen Sie es nochmal.';

    const SAVE_CONFIGURATION_SUCCESSFUL = 'Die Konfiguration mit folgenden Werten wurde gespeichert. {$configurationEntries}';
}
