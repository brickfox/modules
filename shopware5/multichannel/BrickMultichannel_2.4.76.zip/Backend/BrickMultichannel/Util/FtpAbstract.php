<?php
/**
 * FtpAbstract
 *
 * @package   Bf\Multichannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

use Bf\Multichannel\Components\Interfaces\FtpInterface;

abstract class FtpAbstract implements FtpInterface
{
    const EXPORT_TYPE_EXTENSION = 'FTP-Extension';
    const CONFIGURATION_KEY = 'configurationKey';
    const CONFIGURATION_KEY_HOST = 'ftpHost';
    const CONFIGURATION_KEY_USER = 'ftpUser';
    const CONFIGURATION_KEY_PASS = 'ftpPassword';
    const CONFIGURATION_KEY_SSL_ACTIVE = 'ftpSslActive';
    const CONFIGURATION_KEY_SSL_PORT = 'ftpPort';
    const CONFIGURATION_KEY_FTP_ORDERS_PATH = 'ftpOrdersPath';
    const SUCCESS_FOLDER_NAME = 'success';
    const BF_INCOMING_FOLDER_NAME = 'incoming'; //remove after holidays get incoming path from configuration
    const WAITING_TIME_IMPORT = 300;

    /** @var int */
    private $timeOut = 1800;

    /** @var int */
    private $port = 21;

    private $ftpStream;

    private $userName;

    private $password;

    private $ftpHost;

    private $ignoreWaitingTime;

    private $ftpSslActive;

    private $ftpOrdersPath;

    /**
     * @param $userName
     * @param $password
     * @param $ftpHost
     * @param $port
     */
    public function __construct($userName, $password, $ftpHost, $port = 21, $ftpSslActive = null, $ftpOrdersPath = null)
    {
        if(!extension_loaded('ftp'))
        {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE_EXTENSION,
                LogCodes::EXPORT_FTP_EXTENSION_NOT_INSTALLED_CODE,
                LogCodes::EXPORT_FTP_EXTENSION_NOT_INSTALLED
            );
        }

        $this->userName = $userName;
        $this->password = $password;
        $this->ftpHost  = $ftpHost;
        $this->port     = $port;
        $this->ftpSslActive = $ftpSslActive;
        $this->ftpOrdersPath = $ftpOrdersPath;
    }

    /**
     * @return bool
     */
    public function getFtpLogin()
    {
        return @ftp_login($this->getFtpStream(), $this->getUserName(), $this->getPassword());
    }

    /**
     *
     */
    public function prepareConnection()
    {
        if(strlen($this->ftpSslActive) > 0) {
            $ftpSslActive = (bool) $this->ftpSslActive;
        } else {
            $ftpSslActive = (bool) ConfigManager::getInstance()->getFtpSslIsActive()->getConfigurationValue();
        }

        if($ftpSslActive === false)
        {
            $this->ftpConnect();
        }
        else
        {
            $this->sslFtpConnect();
        }
    }

    public function getFtpOrdersPath() {
        if(strlen($this->ftpOrdersPath) > 0) {
            $ftpOrdersPath = $this->ftpOrdersPath;
        } else {
            $ftpOrdersPath = ConfigManager::getInstance()->getFtpOrdersPath()->getConfigurationValue();
        }

        return $ftpOrdersPath;
    }

    /**
     *
     */
    public function ftpConnect()
    {
        $this->setFtpStream(ftp_connect($this->getFtpHost(), $this->getPort(), $this->getTimeOut()));
    }

    /**
     *
     */
    public function sslFtpConnect()
    {
        $this->setFtpStream(ftp_ssl_connect($this->getFtpHost(), $this->getPort(), $this->getTimeOut()));
    }

    /**
     *
     */
    public function ftpPassive()
    {
        ftp_pasv($this->getFtpStream(), true);
    }

    /**
     * @param $filePath
     *
     * @return bool
     */
    public function ftpPut($filePath)
    {
        $return = false;

        if(ftp_put($this->getFtpStream(), self::BF_INCOMING_FOLDER_NAME . DIRECTORY_SEPARATOR . substr(strrchr($filePath, DIRECTORY_SEPARATOR), 1), $filePath, FTP_BINARY) === true)
        {
            $return = true;
        }

        return $return;
    }

    public function ftpPull()
    {
        if ((bool) ConfigManager::getInstance()->getProFtpActive()->getConfigurationValue() === true) {
            $this->useProFtp();
        } else {
            $this->useFtp();
        }
    }

    private function useProFtp()
    {
        $ftpOrdersPath = trim($this->getFtpOrdersPath(), DIRECTORY_SEPARATOR);
        $ftpOrdersPath = DIRECTORY_SEPARATOR . $ftpOrdersPath . DIRECTORY_SEPARATOR;
        $files = ftp_nlist($this->getFtpStream(), $this->getFtpOrdersPath());

        if(is_array($files) === true)
        {
            $configurationModel = Helper::getConfigurationByKey('incomingPath');

            foreach($files as $file)
            {
                $path      = rtrim($configurationModel->getConfigurationValue(), DIRECTORY_SEPARATOR);
                $localFile = $path . DIRECTORY_SEPARATOR . $file;

                if($file !== '.' && $file !== '..')
                {
                    $checkFileType = substr($file, strpos($file, '.'));

                    if($checkFileType === '.xml')
                    {
                        if($this->getIgnoreWaitingTime() === true || filemtime($file) <= (time() - self::WAITING_TIME_IMPORT))
                        {
                            echo $ftpOrdersPath . $file."<br />";

                            if(ftp_get(
                                   $this->getFtpStream(),
                                   $localFile,
                                   $ftpOrdersPath.$file,
                                   FTP_BINARY
                               ) === true
                            )
                            {
                                ftp_delete($this->getFtpStream(), $ftpOrdersPath.$file);
                            }
                            else
                            {
                                continue;
                            }
                        }
                    }
                    else
                    {
                        continue;
                    }
                }
            }
        }
    }

    private function useFtp()
    {
        $files = ftp_nlist($this->getFtpStream(), $this->getFtpOrdersPath());

        if(is_array($files) === true)
        {
            $configurationModel = Helper::getConfigurationByKey('incomingPath');

            foreach($files as $file)
            {
                $path      = rtrim($configurationModel->getConfigurationValue(), DIRECTORY_SEPARATOR);
                $localFile = $path . DIRECTORY_SEPARATOR . substr(strrchr($file, DIRECTORY_SEPARATOR), 1);

                if($file !== '.' && $file !== '..')
                {
                    $checkFileType = substr($file, strpos($file, '.'));

                    if($checkFileType === '.xml')
                    {
                        if($this->getIgnoreWaitingTime() === true || filemtime($file) <= (time() - self::WAITING_TIME_IMPORT))
                        {
                            if(ftp_get(
                                   $this->getFtpStream(),
                                   $localFile,
                                   $file,
                                   FTP_BINARY
                               ) === true
                            )
                            {
                                ftp_delete($this->getFtpStream(), $file);
                            }
                            else
                            {
                                continue;
                            }
                        }
                    }
                    else
                    {
                        continue;
                    }
                }
            }
        }
    }

    /**
     * @param bool|false $ignoreWaitingTime
     *
     * @return mixed
     */
    public function ignoreWaitingTime($ignoreWaitingTime = false)
    {
        $this->setIgnoreWaitingTime($ignoreWaitingTime);
    }

    /**
     * @return mixed
     */
    public function getFtpStream()
    {
        return $this->ftpStream;
    }

    /**
     * @param mixed $ftpStream
     *
     * @return FtpAbstract
     */
    public function setFtpStream($ftpStream)
    {
        $this->ftpStream = $ftpStream;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getUserName()
    {
        return $this->userName;
    }

    /**
     * @param mixed $userName
     *
     * @return FtpAbstract
     */
    public function setUserName($userName)
    {
        $this->userName = $userName;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param mixed $password
     *
     * @return FtpAbstract
     */
    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getFtpHost()
    {
        return $this->ftpHost;
    }

    /**
     * @param mixed $ftpHost
     *
     * @return FtpAbstract
     */
    public function setFtpHost($ftpHost)
    {
        $this->ftpHost = $ftpHost;

        return $this;
    }

    /**
     * @return int
     */
    public function getPort()
    {
        return $this->port;
    }

    /**
     * @param int $port
     *
     * @return FtpAbstract
     */
    public function setPort($port)
    {
        $this->port = $port;

        return $this;
    }

    /**
     * @return int
     */
    public function getTimeOut()
    {
        return $this->timeOut;
    }

    /**
     * @param int $timeOut
     *
     * @return FtpAbstract
     */
    public function setTimeOut($timeOut)
    {
        $this->timeOut = $timeOut;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getIgnoreWaitingTime()
    {
        return $this->ignoreWaitingTime;
    }

    /**
     * @param mixed $ignoreWaitingTime
     *
     * @return FtpAbstract
     */
    public function setIgnoreWaitingTime($ignoreWaitingTime)
    {
        $this->ignoreWaitingTime = $ignoreWaitingTime;

        return $this;
    }

    /**
     *
     */
    public function __destruct()
    {
        ftp_close($this->getFtpStream());
        $this->ftpStream         = null;
        $this->userName          = null;
        $this->ftpHost           = null;
        $this->port              = null;
        $this->password          = null;
        $this->ignoreWaitingTime = null;
    }

    /**
     * @param $filePath
     *
     * @return mixed|void
     */
    public function ftpTransfer($filePath)
    {
    }
}
