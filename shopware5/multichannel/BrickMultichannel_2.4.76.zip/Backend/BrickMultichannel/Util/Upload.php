<?php
/**
 * Upload
 *
 * @package   Bf\Multichannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

class Upload extends Ftp
{
    private $uploadFileName;

    /**
     * @param     $userName
     * @param     $password
     * @param     $ftpHost
     * @param int $port
     */
    public function __construct($userName, $password, $ftpHost, $port = 0, $ftpSslActive = null, $ftpOrdersPath = null)
    {
        parent::__construct($userName, $password, $ftpHost, $port, $ftpSslActive, $ftpOrdersPath);
    }

    public function prepareItemUpload()
    {
        if($this->ftpTestConnection() === false)
        {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE_FTP_TEST,
                LogCodes::EXPORT_FTP_CONNECTION_TEST_CODE,
                LogCodes::EXPORT_FTP_CONNECTION_TEST,
                false
            );
        }

        $this->ftpTransfer($this->getUploadFileName());
    }

    /**
     * @return mixed
     */
    public function getUploadFileName()
    {
        return $this->uploadFileName;
    }

    /**
     * @param mixed $uploadFileName
     *
     * @return Upload
     */
    public function setUploadFileName($uploadFileName)
    {
        $this->uploadFileName = $uploadFileName;

        return $this;
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
