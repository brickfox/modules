<?php
namespace Bf\Multichannel\Components\Util;

class LastImportedOrder {
    /** @var LastImportedOrder|null */
    private static $instance = null;

    /** @var null */
    private $order = null;
    /** @var array */
    private $orderDetailInfo = [];

    /** @var null|\Shopware\Models\Shop\Shop */
    private $shop = null;

    const KEY_SW_ORDER_DETAIL_MODEL = 'swOrderDetailModel';
    const KEY_ADDITIONAL_INFO = 'additionalInfo';

    private function __construct() {}
    private function __clone() {}

    /**
     * @return LastImportedOrder
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * @return \Shopware\Models\Shop\Shop|null
     */
    public function getShop()
    {
        return $this->shop;
    }

    /**
     * @param \Shopware\Models\Shop\Shop|null $shop
     */
    public function setShop($shop)
    {
        $this->shop = $shop;
    }

    /**
     * @param SwOrder $order
     */
    public function setOrder($order) {
        $this->order = $order;
    }

    /**
     * @return SwOrder|null
     */
    public function getOrder() {
        return $this->order;
    }

    /**
     * @param $swOrderDetailModel
     * @param array $additionalInfo e.g. ['isSetSubArticle' => true, 'viisonSetArticleSetArticleOrderNumber' => 'xyz']
     */
    public function addOrderDetailInfo($swOrderDetailModel, $additionalInfo = []) {
        $this->orderDetailInfo[] = [
            self::KEY_SW_ORDER_DETAIL_MODEL => $swOrderDetailModel,
            self::KEY_ADDITIONAL_INFO => $additionalInfo
        ];
    }

    /**
     * @return array
     */
    public function getOrderDetailInfo() {
        return $this->orderDetailInfo;
    }

    public function clear() {
        $this->order = null;
        $this->orderDetailInfo = [];
        $this->shop = null;
    }
}

