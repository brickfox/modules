<?php
/**
 * FileManager
 *
 * @package   Bf\Multichannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

class FileManager
{
    const WAITING_TIME_IMPORT                = 120;
    const FILENAME_BASE_CATEGORIES           = 'Categories';
    const FILENAME_BASE_MANUFACTURERS        = 'Manufacturers';
    const FILENAME_BASE_PRODUCTS             = 'Products';
    const FILENAME_BASE_PRODUCTS_DELETE      = 'ProductDelete';
    const FILENAME_BASE_PRODUCTS_UPDATE      = 'ProductUpdate';
    const FILENAME_BASE_PRODUCTS_ASSIGNMENTS = 'ProductsAssignments';
    const FILENAME_BASE_PRODUCTS_BUNDLES     = 'ProductsBundles';
    const FILENAME_BASE_ORDERS               = 'Orders';
    const FILENAME_BASE_ORDERS_STATUS        = 'Orderstatus';
    const FILENAME_BASE_SUB_SHOPS            = 'Subshops';
    const FILENAME_DELIMITER                 = '_';
    const GZ_FILE_EXTENSION                  = '.gz';

    /** @var FileManager */
    private static $instance = null;

    private function __construct()
    {
    }

    private function __clone()
    {
    }

    /**
     * getInstance.
     *
     * @return FileManager
     */
    public static function getInstance()
    {
        if(self::$instance === null)
        {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * @param string $filenameBase
     * @param $itemPackageCount
     *
     * @return string
     */
    public static function generateFilename($filenameBase, $itemPackageCount)
    {
        $multiShopId = '';

        if(ConfigManager::getInstance()->getIsMultiShop() === true)
        {
            $multiShopId = ConfigManager::getInstance()->getMultiShopsId() . '_';
        }

        return $filenameBase . '_' . $itemPackageCount . '_' . $multiShopId . date('Ymd_His') . '.xml';
    }

    /**
     * @param string $importFilenameBase
     *
     * @return array
     */
    public function getImportFiles($importFilenameBase)
    {
        $result           = array();
        $exchangeXMLFiles = $this->getExchangeXMLFiles();

        if(is_array($exchangeXMLFiles) === true)
        {
            foreach($exchangeXMLFiles as $exchangeXMLFile)
            {
                $exchangeXMLFilename = pathinfo($exchangeXMLFile, PATHINFO_FILENAME);
                list($exchangeXMLFilenameBase, $exchangeXMLFilenameCreation) = explode(self::FILENAME_DELIMITER, $exchangeXMLFilename, 2);

                if($exchangeXMLFilenameBase == $importFilenameBase)
                {
                    $useFile = true;

                    // more than one files found, so compare dates and use oldest
                    if(isset($result[$importFilenameBase]) === true)
                    {
                        $exchangeXMLFileCreationDate = $this->getTimestamp($exchangeXMLFilenameCreation);
                        $exchangeXMLFilenameCompare  = pathinfo($result[$importFilenameBase], PATHINFO_FILENAME);
                        list(, $exchangeXMLFilenameCreationCompare) = explode(self::FILENAME_DELIMITER, $exchangeXMLFilenameCompare, 2);
                        $exchangeXMLFileCreationDateCompare = $this->getTimestamp($exchangeXMLFilenameCreationCompare);

                        $useFile = $exchangeXMLFileCreationDate < $exchangeXMLFileCreationDateCompare ? true : false;
                    }

                    // Ignore files that were touched in the last n seconds
                    if (filemtime($exchangeXMLFile) > (time() - self::WAITING_TIME_IMPORT)) {
                        $useFile = false;
                    }

                    if($useFile === true)
                    {
                        $result[$importFilenameBase] = $exchangeXMLFile;
                    }
                    else {
                        continue;
                    }
                    break;
                }
            }
        }

        return $result;
    }

    /**
     * createExportFile.
     *
     * @param string $filename file name
     *
     * @return string file location
     */
    public function createExportFile($filename)
    {
        $fileLocation = $this->getExchangeShopPath() . $filename;
        $fileHandle   = fopen($fileLocation, 'w');
        fclose($fileHandle);

        return $fileLocation;
    }

    /**
     * @param        $fileLocation
     * @param string $destinationDirectory
     */
    public function moveExportFile($fileLocation, $destinationDirectory = 'success')
    {
        $extendedDestinationPath = date('Y', time()) . DIRECTORY_SEPARATOR . date('m', time()) . DIRECTORY_SEPARATOR . date('d', time());
        $destinationPath         = ConfigManager::getInstance()->getExchangeDirectory() . $destinationDirectory . DIRECTORY_SEPARATOR . $extendedDestinationPath;

        if(file_exists($fileLocation) === true)
        {
            Helper::checkPath($destinationPath, true);
        }

        $fileName = substr(strrchr($fileLocation, DIRECTORY_SEPARATOR), 1);
        $this->zipper($destinationPath, true, $fileLocation, $fileName);
    }

    /**
     * @param        $fileLocation
     * @param string $destinationDirectory
     */
    public function moveImportFile($fileLocation, $destinationDirectory = 'processed')
    {
        $extendedDestinationPath = date('Y', time()) . DIRECTORY_SEPARATOR . date('m', time()) . DIRECTORY_SEPARATOR . date('d', time());
        $destinationPath         = ConfigManager::getInstance()->getExchangeDirectory() . $destinationDirectory . DIRECTORY_SEPARATOR . $extendedDestinationPath;

        if(file_exists($fileLocation) === true)
        {
            Helper::checkPath($destinationPath, true);
        }

        $fileName = substr(strrchr($fileLocation, DIRECTORY_SEPARATOR), 1);
        $this->zipper($destinationPath, true, $fileLocation, $fileName);
    }

    /**
     * @param      $destinationPath
     * @param bool $deleteAfterZip
     * @param      $fileLocation
     * @param      $fileName
     */
    public function zipper($destinationPath, $deleteAfterZip = false, $fileLocation = null, $fileName = null)
    {
        if($fileLocation !== null && $fileName !== null)
        {
            $gzFile = $destinationPath . DIRECTORY_SEPARATOR . $fileName . self::GZ_FILE_EXTENSION;
        }
        else
        {
            $gzFile       = $destinationPath . self::GZ_FILE_EXTENSION;
            $fileLocation = $destinationPath;
        }

        $fp = gzopen($gzFile, 'w9');
        gzwrite($fp, file_get_contents($fileLocation));
        gzclose($fp);

        if($deleteAfterZip === true)
        {
            if(file_exists($fileLocation) === true)
            {
                unlink($fileLocation);
            }
        }
    }

    /**
     * @return array
     */
    private function getExchangeXMLFiles()
    {
        $importDir = $this->getImportDirectory();

        return glob($importDir . '*.xml');
    }

    private function getImportDirectory()
    {
        $importDirectory = $this->getExchangeShopPath() . $this->getIncomingDestinationDirectory();
        $this->checkDir($importDirectory);

        return $importDirectory;
    }

    /**
     * getExchangeShopDirectoryLocation.
     *
     * @return string exchange shop directory location
     */
    private function getExchangeShopPath()
    {
        $exchangeShopDirectoryLocation = '';
        $exchangeShopDirectory         = $this->getExchangeShopDirectory();

        if(is_null($exchangeShopDirectory) === false && strlen($exchangeShopDirectory) > 0)
        {
            $exchangeShopDirectoryLocation .= $exchangeShopDirectory . DIRECTORY_SEPARATOR;
        }

        return $exchangeShopDirectoryLocation;
    }

    /**
     * getExchangeDirectory.
     *
     * @return string exchange directory
     */
    private function getExchangeDirectory()
    {
        return ConfigManager::getInstance()->getExchangeDirectory();
    }

    /**
     * getExchangeShopDirectory,
     *
     * @return string exchange shop directory
     */
    private function getExchangeShopDirectory()
    {
        return ConfigManager::getInstance()->getActiveShopId();
    }

    /**
     * @return string
     */
    private function getIncomingDestinationDirectory()
    {
        return ConfigManager::getInstance()->getIncomingDestinationDirectory();
    }

    /**
     * getTimestamp.
     * Pay attention:
     * Currently PHP version 5.2.6 is in use.
     * For that reason it's not possible to use:
     * DateTime::createFromFormat('Ymd_His', $timestampString)
     *
     * @param string $timestampString timestamp string
     *
     * @return integer timestamp
     */
    private function getTimestamp($timestampString)
    {
        $ftime = strptime($timestampString, 'Ymd_His');

        return mktime($ftime['tm_hour'], $ftime['tm_min'], $ftime['tm_sec'], 1, $ftime['tm_yday'] + 1, $ftime['tm_year'] + 1900);
    }

    private function checkDir($importDirectory)
    {
        if(is_dir($importDirectory) === false)
        {
            mkdir($importDirectory, 0777, true);
        }
    }

    /**
     * @param $exportTypeCode
     * @param $itemPackageCount
     *
     * @return string
     */
    public function getUri($exportTypeCode, $itemPackageCount)
    {
        $configurationModel = Helper::getConfigurationByKey('outgoingPath');

        return rtrim($configurationModel->getConfigurationValue(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR .
               FileManager::getInstance()->generateFilename($exportTypeCode, $itemPackageCount);
    }

    /**
     * @param int $countOfMonth
     */
    public function recursiveDeleteFiles($countOfMonth = 2)
    {
        $root        = Shopware()->DocPath();
        $destination = 'uploads/brickfox/';

        $fileDirs = array(
            'success/',
            'processed/',
            'processedError/',
            'failure/',
            'logs/'
        );

        foreach($fileDirs as $dir)
        {
            $targetPath = $root . $destination . $dir . date('Y', time());

            Helper::checkPath($targetPath, true);

            $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($targetPath));

            /** @var \SplFileInfo $item */
            foreach($iterator as $item)
            {
                if($item->isFile() && $item->getMTime() < strtotime(date('Y-m', strtotime('-' . $countOfMonth . ' month')) . '-01'))
                {
                    unlink($item->getPath() . DIRECTORY_SEPARATOR . $item->getFilename());
                }
            }
        }
    }
}
