<?php
/**
 * Download
 *
 * @package   Bf\Multichannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

class Download extends Ftp
{
    /**
     * @param string $userName
     * @param string $password
     * @param string $ftpHost
     * @param int    $port
     */
    public function __construct($userName, $password, $ftpHost, $port = 0)
    {
        parent::__construct($userName, $password, $ftpHost, $port);
    }

    /**
     * @param $ignoreWaitingTime
     *
     * @throws \Exception
     */
    public function prepareItemDownload($ignoreWaitingTime)
    {
        if($this->ftpTestConnection() === false)
        {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE_FTP_TEST,
                LogCodes::EXPORT_FTP_CONNECTION_TEST_CODE,
                LogCodes::EXPORT_FTP_CONNECTION_TEST,
                false
            );
        }
        $this->ftpPullTransfer($ignoreWaitingTime);
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
