<?php
/**
 * LogCodes
 *
 * @package   Bf\Multichannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2021 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

class ShopwareAddressFields
{
    /**
     * @param $type
     * @return string[][]
     */
    public static function getShopwareAddressFieldsList($type)
    {
        switch ($type){
            case 'billing':
                return [
                    ['addressFieldValue' => 'billing.Company'],
                    ['addressFieldValue' => 'billing.Department'],
                    ['addressFieldValue' => 'billing.Salutation'],
                    ['addressFieldValue' => 'billing.Title'],
                    ['addressFieldValue' => 'billing.FirstName'],
                    ['addressFieldValue' => 'billing.LastName'],
                    ['addressFieldValue' => 'billing.Street'],
                    ['addressFieldValue' => 'billing.Zipcode'],
                    ['addressFieldValue' => 'billing.City'],
                    ['addressFieldValue' => 'billing.CountryId'],
                    ['addressFieldValue' => 'billing.Phone'],
                    ['addressFieldValue' => 'billing.AdditionalAddressLine1']
                ];
            case 'shipping':
                return [
                    ['addressFieldValue' => 'shipping.Company'],
                    ['addressFieldValue' => 'shipping.Department'],
                    ['addressFieldValue' => 'shipping.Salutation'],
                    ['addressFieldValue' => 'shipping.Title'],
                    ['addressFieldValue' => 'shipping.FirstName'],
                    ['addressFieldValue' => 'shipping.LastName'],
                    ['addressFieldValue' => 'shipping.Street'],
                    ['addressFieldValue' => 'shipping.Zipcode'],
                    ['addressFieldValue' => 'shipping.City'],
                    ['addressFieldValue' => 'shipping.CountryId'],
                    ['addressFieldValue' => 'shipping.Phone'],
                    ['addressFieldValue' => 'shipping.AdditionalAddressLine1']
                ];
            default:
                return [];
        }
    }
}
