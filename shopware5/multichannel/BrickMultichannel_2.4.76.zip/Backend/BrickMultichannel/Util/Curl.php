<?php
/**
 * Curl
 *
 * @package   Bf\Saleschannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

class Curl
{
    const API_KEY_NAMESPACE = 'apiKey:';

    const EQUAL_CHARACTER = '=';

    const AND_CHARACTER = '&';

    const QUESTION_MARK_CHARACTER = '?';

    /** @var null */
    private $ch = null;

    /** @var string */
    private $url = '';

    private $result;

    /** @var string */
    private $apiKey = '';

    /** @var string */
    private $restCall = '';

    /** @var array */
    private $param = '';

    /**
     * @param $url
     * @param $apiKey
     * @param $restCall
     * @param $param
     */
    public function __construct($url, $apiKey, $restCall, $param = '')
    {
        $this->setCh(curl_init());
        $this->setUrl($url);
        $this->setRestCall($restCall);
        $this->setParam($param);
        $this->setApiKey($apiKey);
    }

    /**
     * @return mixed
     */
    public function get()
    {
        curl_setopt($this->getCh(), CURLOPT_URL, $this->getUrl() . $this->getRestCall() . $this->getParam());
        $this->setOpts();
        curl_setopt($this->getCh(), CURLOPT_HTTPHEADER, array(self::API_KEY_NAMESPACE . $this->getApiKey()));
        curl_setopt($this->getCh(), CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($this->getCh(), CURLOPT_SSL_VERIFYHOST, false);

        $this->setResult(curl_exec($this->getCh()));

        return $this->getResult();
    }

    public function setOpts()
    {
        curl_setopt($this->getCh(), CURLOPT_RETURNTRANSFER, true);
    }

    /**
     * @return string
     */
    public function getApiKey()
    {
        return $this->apiKey;
    }

    /**
     * @param string $apiKey
     *
     * @return Curl
     */
    public function setApiKey($apiKey)
    {
        $this->apiKey = $apiKey;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getResult()
    {
        return $this->result;
    }

    /**
     * @param mixed $result
     *
     * @return Curl
     */
    public function setResult($result)
    {
        $this->result = $result;

        return $this;
    }

    /**
     * @return string
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * @param string $url
     *
     * @return Curl
     */
    public function setUrl($url)
    {
        $this->url = $url . DIRECTORY_SEPARATOR . 'BFpublic' . DIRECTORY_SEPARATOR . 'Rest' . DIRECTORY_SEPARATOR;

        return $this;
    }

    /**
     * @return null
     */
    public function getCh()
    {
        return $this->ch;
    }

    /**
     * @param null $ch
     *
     * @return Curl
     */
    public function setCh($ch)
    {
        $this->ch = $ch;

        return $this;
    }

    public function __destruct()
    {
        curl_close($this->getCh());
    }

    /**
     * @return string
     */
    public function getRestCall()
    {
        return $this->restCall;
    }

    /**
     * @param string $restCall
     *
     * @return Curl
     */
    public function setRestCall($restCall)
    {
        $this->restCall = $restCall;

        return $this;
    }

    /**
     * @return string
     */
    public function getParam()
    {
        return $this->param;
    }

    /**
     * @param array $param
     *
     * @return Curl
     */
    public function setParam($param)
    {
        if (!is_array($param)) {return $this;}

        $arrayCounter = count($param);
        $counter      = 1;

        if($arrayCounter > 0)
        {
            foreach($param as $parameter => $value)
            {
                if($counter === 1)
                {
                    $this->param .= self::QUESTION_MARK_CHARACTER . $parameter . self::EQUAL_CHARACTER . $value;
                }
                else
                {
                    $this->param .= self::AND_CHARACTER . $parameter . self::EQUAL_CHARACTER . $value;
                }

                $counter++;
            }
        }

        return $this;
    }
}
