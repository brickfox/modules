<?php

namespace Bf\Multichannel\Components\Util;

class sOrderFake
{
    /**
     * Ordernumber
     *
     * @var string
     */
    public $sOrderNumber;
}
