<?php
/**
 * Exceptions
 *
 * @package   Bf\Saleschannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

use ErrorException;
use Exception;

class Exceptions
{
    /**
     * @param array $container
     *
     * @throws Exception
     */
    public static function instanceOfException(array $container = array())
    {
        $total = count($container);

        if($total > 0)
        {
            $fileName = isset($container['fileName']) ? $container['fileName'] : null;

            for($i = 0; $i < $total - 1; $i++)
            {
                $param = isset($container[$i]['param']) ? $container[$i]['param'] : null;
                $obj   = isset($container[$i]['obj']) ? $container[$i]['obj'] : null;

                if($param !== null && $obj !== null)
                {
                    if($param instanceof $obj === false)
                    {
                        throw new Exception('no instance of ' . $obj . ' found on ' . $fileName);
                    }
                }
                else
                {
                    throw new Exception('class name cannot be null');
                }
            }
        }
    }

    /**
     * @param string $msg
     * @param array $search
     * @param array $replaces
     * @param int $code
     * @param int $severity
     *
     * @throws Exception
     */
    public static function throwException($msg, array $search = array(), array $replaces = array(), $code = 0, $severity = 1)
    {
        if(count($replaces) > 0 && count($search) > 0)
        {
            throw new ErrorException(str_replace($search, $replaces, $msg), $code, $severity);
        }
        else
        {
            throw new ErrorException($msg);
        }
    }
}
