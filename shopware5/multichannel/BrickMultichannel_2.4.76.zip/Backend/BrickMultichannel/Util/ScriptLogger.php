<?php
/**
 * ScriptLogger
 *
 * @package   Bf\Saleschannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

use Exception;
use Shopware\CustomModels\BfMultichannel\Scriptlogger as BfScriptLogger;

class ScriptLogger
{
    const LOGGER_STATUS_RUNNING = 'running';
    const LOGGER_STATUS_ERROR = 'error';
    const LOGGER_STATUS_SUCCESS = 'success';
    const LOGGER_STATUS_WARNING = 'warning';
    const LOGGER_STATUS_NOTICE = 'notice';
    const LOGGER_SCRIPT_IS_ALREADY_RUNNING_MESSAGE = 'Script {$scriptName} is already running.';

    /** @var ScriptLogger */
    private static $instance = null;

    private $scriptLoggerModel;

    private $status;

    /** @var bool */
    private $errorOccurred = false;

    /** @var string */
    private $scriptErrorMessage = '';

    private function __construct()
    {
    }

    private function __clone()
    {
    }

    /**
     * @return ScriptLogger
     */
    public static function getInstance()
    {
        if(self::$instance === null)
        {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * @param $scriptName
     */
    public function run($scriptName)
    {
        if($this->loggerIsRunning($scriptName) === false)
        {
            $this->getScriptLoggerModel()->setScriptName($scriptName);
            $this->getScriptLoggerModel()->setScriptStatus(self::LOGGER_STATUS_RUNNING);
            $this->getScriptLoggerModel()->setDateStart(date('Y-m-d H:i:s', time()));

            $this->saveModel();

            register_shutdown_function(array($this, 'shutDownHandler'));
            set_error_handler(array($this, 'errorHandler'));

            if(version_compare(phpversion(), '7.0.0', '<'))
            {
                set_exception_handler(array($this, 'exceptionHandler'));
            }
            else
            {
                set_exception_handler(array($this, 'throwableHandler'));
            }
        }
    }

    public function stop()
    {
        $this->shutDownHandler();
        self::$instance = null;
    }

    /**
     * @param Exception $exception
     *
     * @return void
     */
    public function exceptionHandler(Exception $exception)
    {
        $this->setErrorOccurred(true);
        $this->statusHandler($exception->getCode(), $exception->getMessage(), $exception->getFile(), $exception->getLine());
    }

    /**
     * @param \Throwable $throwable
     * @return void
     */
    public function throwableHandler($throwable)
    {
        $this->setErrorOccurred(true);
        $this->statusHandler($throwable->getCode(), $throwable->getMessage(), $throwable->getFile(), $throwable->getLine());
    }

    /**
     * @param $errorNumber
     * @param $errorMessage
     * @param $errorFile
     * @param $errorLine
     */
    public function errorHandler($errorNumber, $errorMessage, $errorFile, $errorLine)
    {
        $this->setErrorOccurred(true);
        $this->statusHandler($errorNumber, $errorMessage, $errorFile, $errorLine);
    }

    public function shutDownHandler()
    {
        if($this->getErrorOccurred() === false)
        {
            $this->getScriptLoggerModel()->setScriptStatus(self::LOGGER_STATUS_SUCCESS);
        }
        else
        {
            $this->getScriptLoggerModel()->setScriptStatus($this->getStatus());
            $this->getScriptLoggerModel()->setScriptMessage($this->getScriptErrorMessage());
        }


        $this->getScriptLoggerModel()->setDateEnd(date('Y-m-d H:i:s', time()));
        $this->saveModel();
    }

    private function saveModel()
    {
        $this->reloadingScriptLogger();

        if(Shopware()->Models()->isOpen() === false) {
            Shopware()->Container()->get('bootstrap')->resetResource('Models');
            Shopware()->Models()->create(
                Shopware()->Models()->getConnection(),
                Shopware()->Models()->getConfiguration()
            );
        }
        Shopware()->Models()->persist($this->getScriptLoggerModel());
        Shopware()->Models()->flush($this->getScriptLoggerModel());
    }

    private function reloadingScriptLogger()
    {
        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\Scriptlogger');
        /** @var \Shopware\CustomModels\BfSaleschannel\Scriptlogger $scriptLoggerModel */
        $scriptLoggerModel = $repository->findOneBy(array('id' => $this->getScriptLoggerModel()->getId()));

        if($scriptLoggerModel !== null)
        {
            $scriptLoggerModel->setScriptName($this->getScriptLoggerModel()->getScriptName());
            $scriptLoggerModel->setScriptStatus($this->getScriptLoggerModel()->getScriptStatus());
            $scriptLoggerModel->setScriptMessage($this->getScriptLoggerModel()->getScriptMessage());
            $scriptLoggerModel->setDateStart($this->getScriptLoggerModel()->getDateStart());
            $scriptLoggerModel->setDateEnd($this->getScriptLoggerModel()->getDateEnd());
            $this->setScriptLoggerModel($scriptLoggerModel);
        }
    }

    /**
     * @param $scriptName
     *
     * @return bool
     * @throws Exception
     */
    private function loggerIsRunning($scriptName)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\Scriptlogger');
        /** @var \Shopware\CustomModels\BfMultichannel\Scriptlogger $scriptLoggerModel */
        $scriptLoggerModel = $repository->findOneBy(array('scriptName' => $scriptName, 'scriptStatus' => self::LOGGER_STATUS_RUNNING));

        if($scriptLoggerModel !== null)
        {
            if($this->checkRuntime($scriptLoggerModel) === false)
            {
                Exceptions::throwException(
                    self::LOGGER_SCRIPT_IS_ALREADY_RUNNING_MESSAGE,
                    array('{$scriptName}'),
                    array($scriptName),
                    E_NOTICE,
                    E_NOTICE
                );
            }
            else
            {
                $this->setNewScriptLogger();
            }
        }
        else
        {
            $this->setNewScriptLogger();
        }

        return false;
    }

    /**
     * @param $specifiedScriptName
     *
     * @return bool
     */
    private function specifiedLoggerIsRunning($specifiedScriptName)
    {
        $return = false;

        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\Scriptlogger');
        /** @var \Shopware\CustomModels\BfMultichannel\Scriptlogger $scriptLoggerModel */
        $scriptLoggerModel = $repository->findOneBy(array('scriptName' => $specifiedScriptName, 'scriptStatus' => self::LOGGER_STATUS_RUNNING));

        if($scriptLoggerModel !== null)
        {
            if($this->checkRuntime($scriptLoggerModel) === false) {
                $return = true;
            }
        }

        return $return;
    }

    /**
     * @param $specifiedScriptName
     *
     * @return bool
     */
    public function checkIfSpecifiedScriptLoggerIsRunning($specifiedScriptName)
    {
        $specifiedScriptLoggerIsRunning = false;

        if($this->specifiedLoggerIsRunning($specifiedScriptName) === true)
        {
            $specifiedScriptLoggerIsRunning = true;
        }

        return $specifiedScriptLoggerIsRunning;
    }

    /**
     * @return void
     */
    private function setNewScriptLogger()
    {
        $scriptLoggerModel = new BfScriptLogger();
        $this->setScriptLoggerModel($scriptLoggerModel);
    }

    /**
     * @param BfScriptLogger $scriptLogger
     *
     * @return bool
     */
    private function checkRuntime(\Shopware\CustomModels\BfMultichannel\Scriptlogger $scriptLogger)
    {
        $result = false;

        $startDate                   = $scriptLogger->getDateStart()->format('Y-m-d H:i:s');
        $startDate                   = strtotime($startDate);
        $timeNow                     = time();
        $scriptLoggerConfigResetTime = (int) Helper::getConfigurationByKey('scriptLogger')->getConfigurationValue() * 60 * 60;

        if(($timeNow - $startDate) > $scriptLoggerConfigResetTime)
        {
            $scriptLogger->setScriptStatus('reset by script')->setDateEnd(date('Y-m-d H:i:s', time()));
            Shopware()->Models()->persist($scriptLogger);
            Shopware()->Models()->flush($scriptLogger);
            Shopware()->Models()->clear();

            $result = true;
        }

        return $result;
    }

    /**
     * @return BfScriptLogger
     */
    public function getScriptLoggerModel()
    {
        return $this->scriptLoggerModel;
    }

    /**
     * @param mixed $scriptLoggerModel
     *
     * @return ScriptLogger
     */
    public function setScriptLoggerModel($scriptLoggerModel)
    {
        $this->scriptLoggerModel = $scriptLoggerModel;

        return $this;
    }

    /**
     * @return boolean
     */
    public function getErrorOccurred()
    {
        return $this->errorOccurred;
    }

    /**
     * @param boolean $errorOccurred
     *
     * @return ScriptLogger
     */
    public function setErrorOccurred($errorOccurred)
    {
        $this->errorOccurred = $errorOccurred;

        return $this;
    }

    /**
     * @return string
     */
    public function getScriptErrorMessage()
    {
        return $this->scriptErrorMessage;
    }

    /**
     * @param string $scriptErrorMessage
     *
     * @return ScriptLogger
     */
    public function setScriptErrorMessage($scriptErrorMessage)
    {
        $this->scriptErrorMessage .= '<br />' . $scriptErrorMessage;

        return $this;
    }

    /**
     * @param $loggerStatus
     */
    private function setScriptLoggerStatus($loggerStatus)
    {
        if($this->getStatus() !== self::LOGGER_STATUS_ERROR)
        {
            $this->setStatus($loggerStatus);
        }
    }

    /**
     * @param $errorNumber
     * @param $errorMessage
     * @param $errorFile
     * @param $errorLine
     */
    private function statusHandler($errorNumber, $errorMessage, $errorFile, $errorLine)
    {
        switch($errorNumber)
        {
            case E_NOTICE:
            case E_USER_NOTICE:
                $this->setScriptLoggerStatus(self::LOGGER_STATUS_NOTICE);
                break;
            case E_WARNING:
            case E_USER_WARNING:
                $this->setScriptLoggerStatus(self::LOGGER_STATUS_WARNING);
                break;
            case 0: //Exceptions
            case E_ERROR:
            case E_USER_ERROR:
                $this->setScriptLoggerStatus(self::LOGGER_STATUS_ERROR);
                break;
            default:
                $this->setScriptLoggerStatus('Unknown Error');
                break;
        }

        $this->setScriptErrorMessage($errorMessage . ':' . $errorFile . ' ' . $errorLine);
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     *
     * @return ScriptLogger
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }
}
