<?php
/**
 * Iterator
 *
 * @package   Bf\Multichannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

class Iterator implements \Iterator, \Countable
{
    /** @var null */
    protected $dataStore = null;

    /**
     * @param array $data
     */
    public function __construct(array $data)
    {
        if(count($data) > 0)
        {
            $this->dataStore = $data;
        }
    }

    /**
     * @return mixed
     */
    public function key()
    {
        return key($this->dataStore);
    }

    /**
     * @return mixed
     */
    public function current()
    {
        return current($this->dataStore);
    }

    /**
     * @return mixed
     */
    public function next()
    {
        return next($this->dataStore);
    }

    /**
     * @return mixed
     */
    public function rewind()
    {
        return reset($this->dataStore);
    }

    /**
     * @return int
     */
    public function count()
    {
        return count($this->dataStore);
    }

    /**
     * @return bool
     */
    public function valid()
    {
        return (bool) $this->current();
    }

    /**
     * {@inheritDoc}
     */
    public function remove($key)
    {
        if(!isset($this->dataStore[$key]) && !array_key_exists($key, $this->dataStore))
        {
            return null;
        }

        $removed = $this->dataStore[$key];
        unset($this->dataStore[$key]);

        return $removed;
    }

    public function __destruct()
    {
        $this->dataStore = null;
    }
}
