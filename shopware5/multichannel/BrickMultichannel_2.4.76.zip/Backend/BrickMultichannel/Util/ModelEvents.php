<?php
/**
 * ModelEvents
 *
 * @package   Bf\Multichannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

class ModelEvents
{
    /** @var  \Shopware\Models\Article\Article|\Shopware\Models\Article\Detail */
    private $modelEntity;

    /** @var null|\Shopware\CustomModels\BfMultichannel\ApiExportProducts */
    private $apiExportProductsModel;

    private $articleLastUpdate;

    /**
     * @param $modelEntity
     */
    public function __construct($modelEntity)
    {
        $this->modelEntity            = $modelEntity;
        $this->apiExportProductsModel = null;
        $this->articleLastUpdate      = date('Y-m-d H:i:s', time());
    }

    public function updateApiExportEntry()
    {
        if($this->getApiExportProductsModel() !== null)
        {
            $this->getApiExportProductsModel()->setToDelete(1);
            $this->getApiExportProductsModel()->setArticleLastUpdate(date('Y-m-d H:i:s', time()));
        }
    }

    public function loadApiExportProductsModel()
    {
        if($this->getModelEntity() instanceof \Shopware\Models\Article\Article)
        {
            $this->setApiExportProductsModel($this->getModelEntity()->getId());
        }
        elseif($this->getModelEntity() instanceof \Shopware\Models\Article\Detail)
        {
            $this->setApiExportProductsModel($this->getModelEntity()->getArticleId());
        }
    }

    public function updateArticleLastUpdate()
    {
        if($this->getApiExportProductsModel() !== null)
        {
            $this->getApiExportProductsModel()->setArticleLastUpdate($this->getArticleLastUpdate());

            Shopware()->Db()->query(
                "update bf_api_export_products set article_last_update = ? where shopwareID = ?",
                array($this->getArticleLastUpdate(), $this->getApiExportProductsModel()->getShopwareId())
            );
        }
    }

    /**
     * @return \Shopware\Models\Article\Article|\Shopware\Models\Article\Detail
     */
    public function getModelEntity()
    {
        return $this->modelEntity;
    }

    /**
     * @param \Shopware\Models\Article\Article|\Shopware\Models\Article\Detail $modelEntity
     *
     * @return ModelEvents
     */
    public function setModelEntity($modelEntity)
    {
        $this->modelEntity = $modelEntity;

        return $this;
    }

    /**
     * @return \Shopware\CustomModels\BfMultichannel\ApiExportProducts
     */
    public function getApiExportProductsModel()
    {
        return $this->apiExportProductsModel;
    }

    /**
     * @param int $articleId
     *
     * @return ModelEvents
     */
    public function setApiExportProductsModel($articleId)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportProducts');

        $this->apiExportProductsModel = $repository->findOneBy(array('shopwareId' => $articleId));

        return $this;
    }

    /**
     * @return bool|string
     */
    public function getArticleLastUpdate()
    {
        return $this->articleLastUpdate;
    }
}
