<?php
/**
 * ApiExport
 *
 * @package   Bf\Multichannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

use Shopware\CustomModels\BfMultichannel\ApiExportProducts;
use Shopware\CustomModels\BfMultichannel\ApiExportProductsUpdate;

class ApiExport
{
    private $item;

    /**
     * @param \Shopware\Models\Article\Article $item
     */
    public function __construct($item)
    {
        $this->item = $item;
    }

    public function setApiExportProducts($type = FileManager::FILENAME_BASE_PRODUCTS)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Article');
        /** @var \Shopware\Models\Article\Article $articleModel */
        $articleModel = $repository->find($this->getItem());
        $exportDate   = date('Y-m-d H:i:s', time());

        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportProducts');

        if(is_object($articleModel) === true)
        {
            /** @var \Shopware\CustomModels\BfMultichannel\ApiExportProducts $apiExportProductsModel */
            $apiExportProductsModel = $repository->findOneBy(array('shopwareId' => $articleModel->getId()));

            if($apiExportProductsModel === null)
            {
                $apiExportProductsModel = new ApiExportProducts();
                $apiExportProductsModel->setShopwareId($articleModel->getId());
                $apiExportProductsModel->setIsDeleted(0);
                $apiExportProductsModel->setToDelete(0);

                if($type === FileManager::FILENAME_BASE_PRODUCTS)
                {
                    $apiExportProductsModel->setLasExportDate($exportDate);
                    $apiExportProductsModel->setArticleLastUpdate($exportDate);
                }
                elseif($type === FileManager::FILENAME_BASE_PRODUCTS_ASSIGNMENTS)
                {
                    $apiExportProductsModel->setLastAssignmentsExportDate($exportDate);
                }
            }
            else
            {
                if($type === FileManager::FILENAME_BASE_PRODUCTS)
                {
                    $apiExportProductsModel->setLasExportDate($exportDate);
                }
                elseif($type === FileManager::FILENAME_BASE_PRODUCTS_ASSIGNMENTS)
                {
                    $apiExportProductsModel->setLastAssignmentsExportDate($exportDate);
                }
            }

            Shopware()->Models()->persist($apiExportProductsModel);

            $this->setApiExportProductsUpdate();
        }
    }

    public function setApiExportProductsUpdate()
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Article');
        /** @var \Shopware\Models\Article\Article $articleModel */
        $articleModel = $repository->find($this->getItem());
        $exportDate   = date('Y-m-d H:i:s', time());

        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportProductsUpdate');

        if(is_object($articleModel) === true)
        {
            $apiExportProductsUpdateModel = $repository->findOneBy(array('shopwareId' => $articleModel->getId()));

            if($apiExportProductsUpdateModel === null)
            {
                $apiExportProductsUpdateModel = new ApiExportProductsUpdate();
                $apiExportProductsUpdateModel->setShopwareId($articleModel->getId());
                $apiExportProductsUpdateModel->setDateInsert($exportDate);
            }

            $apiExportProductsUpdateModel->setStockHash(Helper::getCombinedArticleStockHash($articleModel->getId()));
            $apiExportProductsUpdateModel->setPriceHash(Helper::getCombinedArticlePricesHash($articleModel->getId()));
            $apiExportProductsUpdateModel->setLastUpdate($exportDate);

            Shopware()->Models()->persist($apiExportProductsUpdateModel);
        }
    }

    /**
     * @return \Shopware\Models\Article\Article
     */
    public function getItem()
    {
        return $this->item;
    }

    /**
     * @param mixed $item
     *
     * @return ApiExport
     */
    public function setItem($item)
    {
        $this->item = $item;

        return $this;
    }

    public function __destruct()
    {
        $this->item = null;
    }
}
