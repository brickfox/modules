<?php
/**
 * LogManager
 *
 * @package   Bf\Multichannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

use Exception;
use Shopware\CustomModels\BfMultichannel\ApiExportLog;
use Shopware\CustomModels\BfMultichannel\ApiGuiLog;
use SimpleXMLElement;
use Zend_Auth;

class LogManager
{
    const LOG_TYPE_SUCCESS = 'SUCCESS';
    const LOG_TYPE_ERROR = 'ERROR';
    const LEVEL_ERROR = 4;

    private static $instance = null;

    /** @var null */
    private static $fileName = null;

    /** @var null */
    public static $destinationPathWithFileName = null;

    /**
     * @return LogManager
     */
    public static function getInstance()
    {
        if(self::$instance === null)
        {
            self::$instance = new self;
            self::$fileName = '_Log_' . date('Ymd_His', time()) . '.txt';
        }

        return self::$instance;
    }

    /**
     * @param        $identifier
     * @param string $exportType
     * @param string $errorCode
     * @param string $message
     * @param bool   $throwException
     *
     * @throws Exception
     */
    public function createDbLogEntry($identifier, $exportType = '', $errorCode = '', $message = '', $throwException = true)
    {
        $apiExportLogModel = $this->getApiExportLogModel($identifier, $exportType);

        if($apiExportLogModel instanceof ApiExportLog)
        {
            $dateInsert = $apiExportLogModel->getDateInsert();

            if($dateInsert === null)
            {
                $dateInsert = $this->getNewDateTime();
            }

            $lastUpdate = $this->getNewDateTime();

            if(strlen($apiExportLogModel->getErrorCode() > 0))
            {
                $apiExportLogModel->setErrorCode($apiExportLogModel->getErrorCode() . ',' . $errorCode);
            }
            else
            {
                $apiExportLogModel->setErrorCode($errorCode);
            }

            if(strlen($apiExportLogModel->getMessage()) > 0)
            {
                $apiExportLogModel->setMessage($apiExportLogModel->getMessage() . '\r\n' . $message);
            }
            else
            {
                $apiExportLogModel->setMessage($message);
            }

            $apiExportLogModel->setIdentifier($identifier);
            $apiExportLogModel->setExportType($exportType);
            $apiExportLogModel->setDateInsert($dateInsert);
            $apiExportLogModel->setLastUpdate($lastUpdate);

            Shopware()->Models()->persist($apiExportLogModel);
            Shopware()->Models()->flush($apiExportLogModel);
            Shopware()->Models()->clear();
        }

        if($throwException === true)
        {
            throw new Exception($message);
        }
    }

    /**
     * @param int    $errorCode
     * @param string $message
     * @param string $type
     */
    public function createConfigurationLogEntry($errorCode = 0, $message = '', $type = self::LOG_TYPE_SUCCESS)
    {
        /** @var ApiGuiLog $model */
        $model = new ApiGuiLog();

        $dataInsert = $this->getNewDateTime();
        $lastUpdate = $this->getNewDateTime();

        $model->setErrorCode($errorCode);
        $model->setType($type);
        $model->setMessage($message);
        $model->setDateInsert($dataInsert);
        $model->setLastUpdate($lastUpdate);
        $model->setLastUpdater($this->getUserName());

        Shopware()->Models()->persist($model);
        Shopware()->Models()->flush();
    }

    /**
     * @param $identifier
     * @param $exportType
     *
     * @return ApiExportLog
     */
    private function getApiExportLogModel($identifier, $exportType)
    {
        $repository        = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportLog');
        $apiExportLogModel = $repository->findOneBy(array('identifier' => $identifier, 'exportType' => $exportType));

        if($apiExportLogModel === null)
        {
            $apiExportLogModel = new ApiExportLog();
        }

        return $apiExportLogModel;
    }

    /**
     * @return string
     */
    private function getUserName()
    {
        $userName = 'Api-Import';

        if(method_exists(Zend_Auth::getInstance(), 'getIdentity') === true)
        {
            $stdClass = Zend_Auth::getInstance()->getIdentity();

            if($stdClass !== null)
            {
                $userName = $stdClass->name;
            }
        }

        return $userName;
    }

    /**
     * @return \DateTime
     */
    private function getNewDateTime()
    {
        return new \DateTime();
    }

    public static function logException(\Exception $e, $entity = null)
    {
        return self::writeLog($e->getMessage(), self::LEVEL_ERROR, $entity);
    }

    /**
     * @param        $message
     * @param        $level
     * @param string $entity
     *
     * @return bool
     */
    private static function writeLog($message, $level, $entity = 'Default')
    {
        if(ConfigManager::getInstance()->getlogIsActive() === true)
        {
            if($entity !== null)
            {
                $destinationPath = ConfigManager::getInstance()->getLogPath() . DIRECTORY_SEPARATOR . date('Y', time()) . DIRECTORY_SEPARATOR . date('m', time()) .
                                   DIRECTORY_SEPARATOR . date('d', time()) . DIRECTORY_SEPARATOR;

                Helper::checkPath($destinationPath, true);
                file_put_contents($destinationPath . $entity . self::$fileName, $message . "\r\n", FILE_APPEND);

                if(self::getInstance()->getDestinationPathWithFileName() === null)
                {
                    self::$destinationPathWithFileName = $destinationPath . $entity . self::$fileName;
                }
            }
        }

        return true;
    }

    /**
     * @return null|string
     */
    public static function getDestinationPathWithFileName()
    {
        return self::$destinationPathWithFileName;
    }

    private function __construct()
    {
    }

    private function __clone()
    {
    }
}
