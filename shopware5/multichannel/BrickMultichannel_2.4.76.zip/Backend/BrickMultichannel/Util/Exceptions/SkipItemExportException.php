<?php


namespace Bf\Multichannel\Components\Util\Exceptions;


use Exception;

class SkipItemExportException extends Exception
{

}