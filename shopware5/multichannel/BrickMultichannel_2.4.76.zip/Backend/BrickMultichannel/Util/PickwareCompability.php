<?php
namespace Bf\Multichannel\Components\Util;

use Shopware\Models\Article\Article;
use Exception;

class PickwareCompability {
    const IS_SET_SUB_ARTICLE = 'isSetSubArticle';
    const VIISON_SET_ARTICLE_SET_ARTICLE_ORDER_NUMBER = 'viisonSetArticleSetArticleOrderNumber';

    /**
     * @param Article $article
     * @return bool
     */
    public static function isSetArticleByArticle($article)
    {
        if (!$article || !$article->getMainDetail() || !$article->getMainDetail()->getAttribute()) {
            return false;
        }

        if(method_exists($article->getMainDetail()->getAttribute(), 'getViisonSetArticleActive') === false) {
            return false;
        }

        return $article->getMainDetail()->getAttribute()->getViisonSetArticleActive();
    }

    public static function isHasRepository() {
        try {
            $repository = Shopware()->Models()->getRepository('Shopware\\CustomModels\\ViisonSetArticles\\SetArticle');
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
}