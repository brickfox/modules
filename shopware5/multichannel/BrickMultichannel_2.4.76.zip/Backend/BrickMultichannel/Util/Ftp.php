<?php
/**
 * Ftp
 *
 * @package   Bf\Multichannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

use Exception;

class Ftp extends FtpAbstract
{
    const EXPORT_TYPE_FTP_TEST = 'FTP-Test';
    const EXPORT_TYPE_TRANSFER_FILE = 'FTP-Transfer';

    /**
     * @param $userName
     * @param $password
     * @param $ftpHost
     * @param $port
     */
    public function __construct($userName, $password, $ftpHost, $port = 21, $ftpSslActive = null, $ftpOrdersPath = null)
    {
        parent::__construct($userName, $password, $ftpHost, $port, $ftpSslActive, $ftpOrdersPath);
    }

    /**
     * @return bool
     */
    public function ftpTestConnection()
    {
        $return = false;

        try
        {
            if(strlen($this->getFtpHost()) > 0)
            {
                $this->prepareConnection();
                if($this->getFtpStream() !== false)
                {
                    if($this->getFtpLogin() === true)
                    {
                        $return = true;
                    }
                }
            }
        }
        catch(Exception $e)
        {
            LogManager::getInstance()->createDbLogEntry(
                time(),
                self::EXPORT_TYPE_FTP_TEST,
                LogCodes::EXPORT_FTP_CONNECTION_TEST_CODE,
                LogCodes::EXPORT_FTP_CONNECTION_TEST,
                false
            );
        }

        return $return;
    }

    /**
     * @param $filePath
     *
     * @return mixed|void
     */
    public function ftpTransfer($filePath)
    {
        if(file_exists($filePath) === true)
        {
            $this->ftpPassive();
            if($this->ftpPut($filePath) === false)
            {
                LogManager::getInstance()->createDbLogEntry(
                    time(),
                    self::EXPORT_TYPE_TRANSFER_FILE,
                    LogCodes::EXPORT_FTP_TRANSFER_CODE,
                    str_replace('{$fileName}', $filePath, LogCodes::EXPORT_FTP_TRANSFER)
                );
            }
        }
        else
        {
            echo 'can not send file via ftp, file does not exists';
        }
    }

    public function ftpPullTransfer($ignoreWaitingTime)
    {
        $this->setIgnoreWaitingTime((bool) $ignoreWaitingTime);
        $this->ftpPassive();
        $this->ftpPull();
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
