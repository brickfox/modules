<?php

/**
 * PatchesInterface
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util\Patches;

interface PatchesInterface
{
    public function __construct();

    /**
     * Verify if there is an SQL-Patch file or not.
     *
     * @param null|string $fileName
     *
     * @return mixed
     */
    public function getSqlPatches($fileName = null);

    public function __destruct();
}
