<?php
/**
 * configManager
 *
 * @package   Bf\Multichannel\Components\Util
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Util;

class ConfigManager
{
    const CONFIGURATION_REPOSITORY              = 'Shopware\CustomModels\BfMultichannel\Configuration';
    const PRODUCTS_EXPORT_ATTRIBUTES            = 'productsExportAttributes';
    const ATTRIBUTES_AS_BULLETS_CONFIG_KEY      = 'attributesMultiSelectId';
    const BULLET_AS_ATTRIBUTE_CONFIG_KEY        = 'bulletsAsAttributesMultiSelectId';
    const DISABLED_CATEGORIES                   = 'disabledCategories';
    const CUSTOMER_ORDER_NUMBER_ATTRIBUTESFIELD = 'customerOrderNumberAttributesField';

    /** @var ConfigManager */
    private static $instance = null;

    private $shopwareVersion;

    /** @var bool */
    private $isMultiShop = false;

    /** @var array */
    private $multiShopModels = array();

    /** @var array */
    private $multiShopsCategoriesIds = array();

    /** @var null */
    private $multiShopsId = null;

    private function __construct()
    {
    }

    private function __clone()
    {
    }

    /**
     * getInstance.
     *
     * @return ConfigManager
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * @return null
     */
    public function getActiveShopId()
    {
        $result = null;

        return $result;
    }

    /**
     * @return string
     */
    public function getExchangeDirectory()
    {
        $exchangeDirectory = 'uploads/brickfox';

        return Shopware()->DocPath() . $exchangeDirectory . DIRECTORY_SEPARATOR;
    }

    /**
     * @return string
     */
    public function getIncomingDestinationDirectory()
    {
        $destinationPath = 'in';

        $configurationModel = $this->getIncomingPath();

        if ($configurationModel !== null) {
            $destinationPath = $configurationModel->getConfigurationValue();
            $destinationPath = rtrim($destinationPath, DIRECTORY_SEPARATOR);
        }

        return $destinationPath . DIRECTORY_SEPARATOR;
    }

    /**
     * @return string
     */
    public function getOutgoingDestinationDirectory()
    {
        $destinationPath = 'out';

        $configurationModel = $this->getOutgoingPath();

        if ($configurationModel !== null) {
            $destinationPath = $configurationModel->getConfigurationValue();
            $destinationPath = rtrim($destinationPath, DIRECTORY_SEPARATOR);
        }

        return $destinationPath . DIRECTORY_SEPARATOR;
    }

    /**
     * @return bool
     */
    public function getlogIsActive()
    {
        return $this->getConfigurationValueAsBoolean('logging');
    }

    /**
     * @return string
     */
    public function getLogPath()
    {
        $configurationModel = $this->getConfigurationRepository()->findOneBy(['configurationKey' => 'logPath']);

        return Shopware()->DocPath() . $configurationModel->getConfigurationValue();
    }

    /**
     * @return \Shopware\CustomModels\BfSaleschannel\Configuration|null
     */
    public function getScriptloggerCleanTimer()
    {
        return $this->getConfigurationRepository()->findOneBy(['configurationKey' => 'cleanBfScriptloggerAfterDays']);
    }

    /**
     * @return \Shopware\CustomModels\BfMultichannel\Configuration|null
     */
    private function getIncomingPath()
    {
        return $this->getConfigurationRepository()->findOneBy(['configurationKey' => 'incomingPath']);
    }

    /**
     * @return \Shopware\CustomModels\BfMultichannel\Configuration|null
     */
    private function getOutgoingPath()
    {
        return $this->getConfigurationRepository()->findOneBy(['configurationKey' => 'outgoingPath']);
    }

    /**
     * @return \Shopware\CustomModels\BfMultichannel\Configuration|null
     */
    public function getMultiShopExportConfiguration()
    {
        return $this->getConfigurationRepository()->findOneBy(['configurationKey' => 'multiShopExport']);
    }

    /**
     * @return \Shopware\CustomModels\BfMultichannel\Configuration|null
     */
    public function getMultiLanguagesExport()
    {
        return $this->getConfigurationRepository()->findOneBy(['configurationKey' => 'multiLanguagesExport']);
    }

    /**
     * @return bool
     */
    public function getExportMultivaluedPropertiesAsSingleAttributes()
    {
        return $this->getConfigurationValueAsBoolean('exportMultivaluedPropertiesAsSingleAttributes');
    }

    /**
     * @return \Shopware\CustomModels\BfMultichannel\Configuration|null
     */
    public function getOrderAttributes()
    {
        return $this->getConfigurationRepository()->findOneBy(['configurationKey' => 'orderAttributes']);
    }

    /**
     * @return \Shopware\CustomModels\BfMultichannel\Configuration
     */
    public function getProFtpActive()
    {
        return $this->getConfigurationRepository()->findOneBy(['configurationKey' => 'proFtpActive']);
    }

    /**
     * @return \Shopware\CustomModels\BfMultichannel\Configuration
     */
    public function getExportOrderLineStatus()
    {
        return $this->getConfigurationRepository()->findOneBy(['configurationKey' => 'exportOrderLineStatus']);
    }

    /**
     * @return string
     */
    public function getServerProtocol()
    {
        $serverProtocol = 'http://';

        if ($this->getConfigurationValueAsBoolean('serverProtocol') === true) {
            $serverProtocol = 'https://';
        }

        return $serverProtocol;
    }

    /**
     * @return bool
     */
    public function isIncreaseInnoDBLockWaitTimeoutEnabled()
    {
        return $this->getConfigurationValueAsBoolean('isIncreaseInnoDBLockWaitTimeoutEnabled');
    }

    /**
     * @return mixed
     */
    public function getShopwareVersion()
    {
        return $this->shopwareVersion;
    }

    /**
     * @param mixed $shopwareVersion
     *
     * @return ConfigManager
     */
    public function setShopwareVersion($shopwareVersion)
    {
        $this->shopwareVersion = $shopwareVersion;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getOrdersDefaultStatus()
    {
        return $this
            ->getConfigurationRepository()
            ->findOneBy(['configurationKey' => 'importedOrderStatus'])
            ->getConfigurationValue();
    }

    /**
     * @return mixed
     */
    public function getOrderStatusForOrdersWithComment()
    {
        return $this->getConfigurationValueAsStringOrNull('orderStatusForOrdersWithComment');
    }

    /**
     * @param string $shposId
     *
     * @return null|\Shopware\CustomModels\BfMultichannel\Configuration
     */
    public function getFtpHost($shposId = '')
    {
        $key = FtpAbstract::CONFIGURATION_KEY_HOST;

        if(strlen($shposId) > 0) {
            $key = $key . '_' . $shposId;
        }

        return $this->getConfigurationRepository()->findOneBy(array(FtpAbstract::CONFIGURATION_KEY => $key));
    }

    /**
     * @param string $shposId
     *
     * @return null|\Shopware\CustomModels\BfMultichannel\Configuration
     */
    public function getFtpUser($shposId = '')
    {
        $key = FtpAbstract::CONFIGURATION_KEY_USER;

        if(strlen($shposId) > 0) {
            $key = $key . '_' . $shposId;
        }

        return $this->getConfigurationRepository()->findOneBy(array(FtpAbstract::CONFIGURATION_KEY => $key));
    }

    /**
     * @param string $shposId
     *
     * @return null|\Shopware\CustomModels\BfMultichannel\Configuration
     */
    public function getFtpPass($shposId = '')
    {
        $key = FtpAbstract::CONFIGURATION_KEY_PASS;

        if(strlen($shposId) > 0) {
            $key = $key . '_' . $shposId;
        }

        return $this->getConfigurationRepository()->findOneBy(array(FtpAbstract::CONFIGURATION_KEY => $key));
    }

    /**
     * @param string $shposId
     *
     * @return null|\Shopware\CustomModels\BfMultichannel\Configuration
     */
    public function getFtpSslIsActive($shposId = '')
    {
        $key = FtpAbstract::CONFIGURATION_KEY_SSL_ACTIVE;

        if(strlen($shposId) > 0) {
            $key = $key . '_' . $shposId;
        }

        return $this->getConfigurationRepository()->findOneBy(array(FtpAbstract::CONFIGURATION_KEY => $key));
    }

    /**
     * @param string $shposId
     *
     * @return null|\Shopware\CustomModels\BfMultichannel\Configuration
     */
    public function getFtpSslPort($shposId = '')
    {
        $key = FtpAbstract::CONFIGURATION_KEY_SSL_PORT;

        if(strlen($shposId) > 0) {
            $key = $key . '_' . $shposId;
        }

        return $this->getConfigurationRepository()->findOneBy(array(FtpAbstract::CONFIGURATION_KEY => $key));
    }

    /**
     * @return \Shopware\Components\Model\ModelRepository
     */
    public function getConfigurationRepository()
    {
        return Shopware()->Models()->getRepository(self::CONFIGURATION_REPOSITORY);
    }

    /**
     * @param string $shposId
     * @return null|\Shopware\CustomModels\BfMultichannel\Configuration
     */
    public function getFtpOrdersPath($shposId = '')
    {
        $key = FtpAbstract::CONFIGURATION_KEY_FTP_ORDERS_PATH;

        if(strlen($shposId) > 0) {
            $key = $key . '_' . $shposId;
        }

        return $this->getConfigurationRepository()->findOneBy(array(FtpAbstract::CONFIGURATION_KEY => $key));
    }

    /**
     * @return null|\Shopware\CustomModels\BfMultichannel\Configuration
     */
    public function getProductsToExportAttributesConfiguration()
    {
        return $this->getConfigurationRepository()->findOneBy(array(FtpAbstract::CONFIGURATION_KEY => self::PRODUCTS_EXPORT_ATTRIBUTES));
    }

    /**
     * @return null|\Shopware\CustomModels\BfMultichannel\Configuration
     */
    public function getAttributesAsBulletPointsDescriptionConfiguration()
    {
        return $this->getConfigurationRepository()->findOneBy(array(FtpAbstract::CONFIGURATION_KEY => self::ATTRIBUTES_AS_BULLETS_CONFIG_KEY));
    }

    /**
     * @return null|\Shopware\CustomModels\BfMultichannel\Configuration
     */
    public function getBulletAsAttributesDescriptionConfiguration()
    {
        return $this->getConfigurationRepository()->findOneBy(array(FtpAbstract::CONFIGURATION_KEY => self::BULLET_AS_ATTRIBUTE_CONFIG_KEY));
    }

    /**
     * @return null|\Shopware\CustomModels\BfMultichannel\Configuration
     */
    public function getDisabledCategories()
    {
        return $this->getConfigurationRepository()->findOneBy(array(FtpAbstract::CONFIGURATION_KEY => self::DISABLED_CATEGORIES));
    }

    /**
     * @return null|\Shopware\CustomModels\BfMultichannel\Configuration
     */
    public function getCustomerOrderNumberAttributesField()
    {
        return $this->getConfigurationRepository()->findOneBy(array(FtpAbstract::CONFIGURATION_KEY => self::CUSTOMER_ORDER_NUMBER_ATTRIBUTESFIELD));
    }

    /**
     * @return boolean
     */
    public function getIsMultiShop()
    {
        return $this->isMultiShop;
    }

    /**
     * @param boolean $isMultiShop
     *
     * @return ConfigManager
     */
    public function setIsMultiShop($isMultiShop)
    {
        $this->isMultiShop = $isMultiShop;

        return $this;
    }

    /**
     * @return null
     */
    public function getMultiShopsId()
    {
        return $this->multiShopsId;
    }

    /**
     * @param null $multiShopsId
     *
     * @return ConfigManager
     */
    public function setMultiShopsId($multiShopsId)
    {
        $this->multiShopsId = $multiShopsId;

        return $this;
    }

    /**
     * @return array
     */
    public function getMultiShopModels()
    {
        return $this->multiShopModels;
    }

    /**
     * @param \Shopware\Models\Shop\Shop $multiShopModels
     *
     * @return ConfigManager
     */
    public function setMultiShopModels($multiShopModels)
    {
        $this->multiShopModels[] = $multiShopModels;

        return $this;
    }

    /**
     * @return array
     */
    public function getMultiShopsCategoriesIds()
    {
        return $this->multiShopsCategoriesIds;
    }

    /**
     * @param integer $multiShopsCategoriesIds
     *
     * @return ConfigManager
     */
    public function setMultiShopsCategoriesIds($multiShopsCategoriesIds)
    {
        $this->multiShopsCategoriesIds[] = $multiShopsCategoriesIds;

        return $this;
    }

    /**
     * @return bool
     */
    public function isEnableShopsOrderIdToCommentActive() {
        return $this->getConfigurationValueAsBoolean('enableShopsOrderIdToComment');
    }

    /**
     * @return bool
     */
    public function isEnableShopsNameToCommentActive() {
        return $this->getConfigurationValueAsBoolean('enableShopsNameToComment');
    }

    /**
     * @return bool
     */
    public function isEnableShopsCustomerIdToCommentActive() {
        return $this->getConfigurationValueAsBoolean('enableShopsCustomerIdToComment');
    }

    /**
     * @return string
     */
    public function getShopsInformationCommentField() {
        return $this->getConfigurationValueAsStringOrNull('shopsInformationCommentField');
    }

    /**
     * @return string
     */
    public function getOrderNumberInCommentField() {
        return $this->getConfigurationValueAsStringOrNull('orderNumberInCommentField');
    }

    /**
     * @return string
     */
    public function getIsbnFromAttribute()
    {
        return $this->getConfigurationValueAsStringOrNull('isbnFromAttribute');
    }

    /**
     * @return bool
     */
    public function isSkipArticlesWithoutVariationsActive()
    {
        return $this->getConfigurationValueAsBoolean('skipArticlesWithoutVariations');
    }

    /**
     * @return bool
     */
    public function isOrderDisablePartnerImport()
    {
        return $this->getConfigurationValueAsBoolean('orderDisablePartnerImport');
    }

    /**
     * @return bool
     */
    public function isBaseProductExportPreviewImageAlways()
    {
        return $this->getConfigurationValueAsBoolean('baseProductExportPreviewImageAlways');
    }

    /**
     * @return bool
     */
    public function isUsePickwareCompability()
    {
        return $this->getConfigurationValueAsBoolean('usePickwareCompability');
    }

    /**
     * @return bool
     */
    public function isEnableOrderImportWithItemNumber()
    {
        return $this->getConfigurationValueAsBoolean('enableOrderImportWithItemNumber');
    }


    /**
     * @return bool
     */
    public function isOrderPartnerIdIncludeSalesChannelName()
    {
        return $this->getConfigurationValueAsBoolean('orderPartnerIdIncludeSalesChannelName');
    }

    /**
     * @return string
     */
    public function getOrderCarrierColumnName()
    {
        return $this->getConfigurationValueAsStringOrNull('orderCarrierColumnName');
    }

    /**
     * @return string
     */
    public function getOrderTrackingIdColumnName()
    {
        return $this->getConfigurationValueAsStringOrNull('orderTrackingIdColumnName');
    }

    /**
     * @return string
     */
    public function getOrderCarrierColumnNameMain()
    {
        return $this->getConfigurationValueAsStringOrNull('orderCarrierColumnNameMain');
    }

    /**
     * @return string
     */
    public function getOrderTrackingIdColumnNameMain()
    {
        return $this->getConfigurationValueAsStringOrNull('orderTrackingIdColumnNameMain');
    }

    /**
     * @return null|\Shopware\CustomModels\BfMultichannel\Configuration
     */
    public function getCustomerGroupForTaxRate()
    {
        return $this->getConfigurationRepository()->findOneBy(['configurationKey' => 'customergroupTaxRate']);
    }

    /**
     * @return array
     */
    public function getMappingScriptToTimeLimit()
    {
        $result = [];

        $model = $this->getConfigurationRepository()->findOneBy(
            ['configurationKey' => 'mappingActionToScriptTimeLimit']);

        $str = '';

        if($model !== null) {
            $str = $model->getConfigurationValue();
        }

        $mappings = explode(';', $str);

        foreach ($mappings as $mapping) {
            $values = explode('=>', $mapping);

            $values = array_map(function ($value) {
                return trim($value);
            }, $values);

            $values = array_values(array_filter($values, function ($val) {
                return strlen(trim($val)) > 0;
            }));

            if(array_key_exists(0, $values) && array_key_exists(1, $values)) {
                $result[$values[0]] = (int)$values[1];
            }
        }

        return $result;
    }

    /**
     * @param string $input
     * @return array|string|string[]
     */
    public static function snakeCaseToCamelCase($input) {
        return str_replace('_', '', ucwords($input, '_'));
    }

    /**
     * @return bool
     */
    public function getOrderStatusExportUsesPickware()
    {
        $model = $this->getConfigurationRepository()->findOneBy(['configurationKey' => 'orderStatusExportUsesPickware']);

        if($model !== null) {
            return (bool) $model->getConfigurationValue();
        } else {
            return false;
        }
    }

    /**
     * @param string $key
     * @param bool $default
     * @return bool
     */
    private function getConfigurationValueAsBoolean($key, $default = false) {
        if(($config = $this->getConfigurationRepository()->findOneBy(['configurationKey' => $key])) !== null) {
            return filter_var($config->getConfigurationValue(), FILTER_VALIDATE_BOOLEAN);
        }

        return $default;
    }

    /**
     * @param string $key
     * @param bool $default
     * @return string|null
     */
    private function getConfigurationValueAsStringOrNull($key, $default = null) {
        if(($config = $this->getConfigurationRepository()->findOneBy(['configurationKey' => $key])) !== null) {
            return $config->getConfigurationValue();
        }

        return $default;
    }
}
