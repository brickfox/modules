<?php

/**
 * Helper
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */
namespace Bf\Multichannel\Components\Util;

class Helper
{
    /**
     * Creates $filePath if not exists
     *
     * @param string $filePath directory with filename appended
     * @param bool   $onlyPath
     */
    public static function checkPath($filePath, $onlyPath = false)
    {
        $dirPath       = "";
        $directoryList = explode(DIRECTORY_SEPARATOR, $filePath);
        $dirCount      = count($directoryList);
        if($onlyPath === false)
        {
            $dirCount = $dirCount - 1;
        }

        for($dirCounter = 0; $dirCounter < $dirCount; $dirCounter++)
        {
            $dirPath .= $directoryList[$dirCounter] . DIRECTORY_SEPARATOR;

            if(false === file_exists($dirPath))
            {
                mkdir($dirPath, 0777);
                chmod($dirPath, 0777);
            }
        }
    }

    /**
     * @param string $key
     *
     * @return null|\Shopware\CustomModels\BfSaleschannel\Configuration
     */
    public static function getConfigurationByKey($key = '')
    {
        $configurationModel = self::getMappingByValue($key, 'configurationKey', 'Shopware\CustomModels\BfMultichannel\Configuration');

        return $configurationModel;
    }

    /**
     * @param        $value
     * @param        $searchField
     * @param string $modelNamespace
     *
     * @return null|object
     */
    public static function getMappingByValue($value, $searchField, $modelNamespace = '')
    {
        $model = null;

        $repository = Shopware()->Models()->getRepository($modelNamespace);

        if(strlen($value) > 0 && strlen($searchField) > 0)
        {
            $model = $repository->findOneBy(array($searchField => $value));
        }

        return $model;
    }

    /**
     * @param $id
     *
     * @return \Shopware\CustomModels\BfMultichannel\ApiExportProducts
     */
    public static function getApiExportProductsModelById($id)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportProducts');

        /** @var \Shopware\CustomModels\BfMultichannel\ApiExportProducts $apiExportProductsModel */
        $apiExportProductsModel = $repository->findOneBy(array('shopwareId' => $id));

        return $apiExportProductsModel;
    }

    /**
     * @param string $date
     *
     * @return \DateTime
     */
    public static function getDateTime($date = 'now')
    {
        return new \DateTime($date);
    }

    /**
     * @param       $xmlElement
     * @param array $nodes
     *
     * @return bool
     */
    public static function xmlElementExists($xmlElement, array $nodes = array())
    {
        $nodePath = '';

        foreach($nodes as $node)
        {
            if($node !== end($nodes))
            {
                $nodePath .= $node . '->';
            }
            elseif($node === end($nodes))
            {
                $nodePath .= $node;
            }
        }

        return (bool) $xmlElement->{$nodePath};
    }

    /**
     * @param $articleId
     *
     * @return string
     */
    public static function getCombinedArticleStockHash($articleId)
    {
        $stockHash = '';

        $stocks = Shopware()->Db()->fetchAll(
            "
                select instock from s_articles_details where articleID = ?
            ",
            array($articleId)
        );

        if(count($stocks) > 0)
        {
            $combinedStock = '';
            foreach($stocks as $stock)
            {
                $combinedStock .= $stock['instock'];
            }

            $stockHash = md5($combinedStock);
        }

        return $stockHash;
    }

    /**
     * @param $articleId
     *
     * @return string
     */
    public static function getCombinedArticlePricesHash($articleId)
    {
        $priceHash = '';

        $prices = Shopware()->Db()->fetchAll(
            "
                select price from s_articles_prices where articleID = ?
            ",
            array($articleId)
        );

        if(count($prices) > 0)
        {
            $combinedPrice = '';
            foreach($prices as $price)
            {
                $combinedPrice .= $price['price'];
            }

            $priceHash = md5($combinedPrice);
        }

        return $priceHash;
    }

    /**
     * @param $string
     * @return string|string[]|null
     */
    public static function removeControlChars($string)
    {
        if(is_string($string) === false) {
            return $string;
        } else {
            return preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $string);
        }
    }
}
