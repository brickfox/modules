<?php
/**
 * PatchFixUniqueKeys
 *
 * @package   Bf\Multichannel\Patches\SCRIPT
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Patches\SCRIPT;

class PatchFixUniqueKeys extends PatchesAbstract
{
    const SQL_PATCH_FILE_NAME = 'Patches/SQL/PatchFixUniqueKeys.sql';

    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    public function preparePatch()
    {
        $sqlContent = file_get_contents($this->getShopwarePluginBootstrapClass()->Path() . self::SQL_PATCH_FILE_NAME);

        Shopware()->Db()->query($sqlContent);
    }
}
