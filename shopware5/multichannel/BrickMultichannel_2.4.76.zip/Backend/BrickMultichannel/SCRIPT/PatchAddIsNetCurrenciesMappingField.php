<?php
namespace Bf\Multichannel\Patches\SCRIPT;

use Bf\Multichannel\Components\Util\Patches\PatchesAbstract;

/**
 * Class PatchAddIsNetCurrenciesMappingField
 *
 * @package Bf\Multichannel\Patches\SCRIPT
 */
class PatchAddIsNetCurrenciesMappingField extends PatchesAbstract
{
    const SQL_PATCH_FILE_NAME = 'Patches/SQL/PatchAddIsNetCurrenciesMappingField.sql';

    /**
     * @param null $shopwarePluginBootstrap
     */
    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    public function preparePatch()
    {
        $sqlContent = file_get_contents($this->getShopwarePluginBootstrapClass()->Path() . self::SQL_PATCH_FILE_NAME);

        Shopware()->Db()->query($sqlContent);
    }
}