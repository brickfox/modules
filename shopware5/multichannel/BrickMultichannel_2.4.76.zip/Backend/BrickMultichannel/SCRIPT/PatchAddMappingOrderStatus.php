<?php
/**
 * PatchAddMappingOrderStatus.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Patches\SCRIPT;

use Bf\Multichannel\Components\Util\Patches\PatchesAbstract;

class PatchAddMappingOrderStatus extends PatchesAbstract
{
    const SQL_PATCH_FILE_NAME = '';

    /**
     * @param null $shopwarePluginBootstrap
     */
    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    public function preparePatch()
    {
        $modelManager = Shopware()->Models();

        $schemaTool = new SchemaTool($modelManager);
        $schemaTool->createSchema(
            array(
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingOrderStatus')
            )
        );

        Shopware()->Db()->query(
            "
                    INSERT INTO bf_mapping_order_status (`brickfox_order_status_code`, `shopwareID`)
                    VALUES
                    ('Pending', 1),
                    ('Shipped', 2),
                    ('Cancelled', 4),
                    ('ReadyForShipout', 5),
                    ('PartlyShipped', 6)
                "
        );
    }
}