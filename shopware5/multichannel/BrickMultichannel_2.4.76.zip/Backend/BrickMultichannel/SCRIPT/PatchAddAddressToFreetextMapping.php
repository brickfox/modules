<?php
/**
 * PatchAddAddressToFreetextMapping.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2019 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Patches\SCRIPT;

use Bf\Multichannel\Components\Util\Patches\PatchesAbstract;
use Doctrine\ORM\Tools\SchemaTool;

class PatchAddAddressToFreetextMapping extends PatchesAbstract
{
    const SQL_PATCH_FILE_NAME = '';

    /**
     * @param null $shopwarePluginBootstrap
     */
    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    public function preparePatch()
    {
        $modelManager = Shopware()->Models();

        $schemaTool = new SchemaTool($modelManager);
        $schemaTool->createSchema(
            array(
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingAddressToFreetext')
            )
        );
    }
}