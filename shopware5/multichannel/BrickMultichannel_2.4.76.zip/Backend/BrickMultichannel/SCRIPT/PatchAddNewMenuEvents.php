<?php
/**
 * PatchAddNewMenuEvents
 *
 * @package   Bf\Multichannel\Patches\SCRIPT
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Patches\SCRIPT;

use Bf\Multichannel\Components\Util\Patches\PatchesAbstract;

class PatchAddNewMenuEvents extends PatchesAbstract
{
    const SQL_PATCH_FILE_NAME = '';

    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    public function preparePatch()
    {
        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Enlight_Controller_Dispatcher_ControllerPath_Backend_BrickfoxUiLog',
            'onGetUiControllerLogPath'
        );

        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Enlight_Controller_Dispatcher_ControllerPath_Backend_BrickfoxUiErrorCodeList',
            'onGetUiControllerErrorCodeListPath'
        );
    }
}
