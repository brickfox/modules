<?php
/**
 * PatchAddExportOrderLineStatusConfiguration.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Patches\SCRIPT;


use Bf\Multichannel\Components\Util\Patches\PatchesAbstract;

class PatchAddExportOrderLineStatusConfiguration extends PatchesAbstract
{
    const SQL_PATCH_FILE_NAME = 'Patches/SQL/PatchAddExportOrderLineStatusConfiguration.sql';

    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    public function preparePatch()
    {
        $sqlContent = file_get_contents($this->getShopwarePluginBootstrapClass()->Path() . self::SQL_PATCH_FILE_NAME);

        Shopware()->Db()->query($sqlContent);
    }
}