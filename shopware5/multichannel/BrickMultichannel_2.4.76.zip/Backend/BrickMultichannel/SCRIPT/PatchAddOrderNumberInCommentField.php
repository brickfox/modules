<?php

namespace Bf\Multichannel\Patches\SCRIPT;

use Bf\Multichannel\Components\Util\Patches\PatchesAbstract;

class PatchAddOrderNumberInCommentField extends PatchesAbstract
{
    const SQL_PATCH_FILE_NAME = 'Patches/SQL/PatchAddOrderNumberInCommentField.sql';

    /**
     * @param null $shopwarePluginBootstrap
     */
    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    public function preparePatch()
    {
        $sqlContent = file_get_contents($this->getShopwarePluginBootstrapClass()->Path() . self::SQL_PATCH_FILE_NAME);

        Shopware()->Db()->query($sqlContent);
    }
}
