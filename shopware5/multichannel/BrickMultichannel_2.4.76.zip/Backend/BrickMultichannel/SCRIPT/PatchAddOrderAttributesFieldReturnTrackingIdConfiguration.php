<?php
/**
 * PatchAddOrderAttributesFieldReturnTrackingIdConfiguration.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2020 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Patches\SCRIPT;

use Bf\Multichannel\Components\Util\Patches\PatchesAbstract;
use Zend_Db_Adapter_Exception;

class PatchAddOrderAttributesFieldReturnTrackingIdConfiguration extends PatchesAbstract
{
    const SQL_PATCH_FILE_NAME = 'Patches/SQL/PatchAddOrderAttributesFieldReturnTrackingIdConfiguration.sql';

    /**
     * @param $shopwarePluginBootstrap
     */
    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);

        parent::__construct('');
    }

    /**
     * @throws Zend_Db_Adapter_Exception
     */
    public function preparePatch()
    {
        $sqlContent = file_get_contents($this->getShopwarePluginBootstrapClass()->Path() . self::SQL_PATCH_FILE_NAME);

        Shopware()->Db()->query($sqlContent);
    }
}