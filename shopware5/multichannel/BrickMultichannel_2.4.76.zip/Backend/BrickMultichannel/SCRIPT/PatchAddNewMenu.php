<?php
/**
 * PatchAddNewMenu
 *
 * @package   Bf\Multichannel\Patches\SCRIPT
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Patches\SCRIPT;

use Bf\Multichannel\Components\Util\Patches\PatchesAbstract;

class PatchAddNewMenu extends PatchesAbstract
{
    const SQL_PATCH_FILE_NAME = '';

    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    public function preparePatch()
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Menu\Menu');
        $parentMenu = $repository->findOneBy(array('label' => 'Brickfox Connector'));

        if($parentMenu !== null)
        {
            $firstMenu = new \Shopware\Models\Menu\Menu();
            $firstMenu->setLabel('Koniguration');
            $firstMenu->setClass('bf_icon_settings');
            $firstMenu->setActive(true);
            $firstMenu->setController('BrickfoxUi');
            $firstMenu->setAction('Index');
            $firstMenu->setParent($parentMenu);
            $firstMenu->setPlugin($this->getShopwarePluginBootstrapClass()->Plugin());

            Shopware()->Models()->persist($firstMenu);

            $secondMenu = new \Shopware\Models\Menu\Menu();
            $secondMenu->setLabel('Log');
            $secondMenu->setClass('bf_icon_log');
            $secondMenu->setActive(true);
            $secondMenu->setController('BrickfoxUiLog');
            $secondMenu->setAction('Index');
            $secondMenu->setParent($parentMenu);
            $secondMenu->setPlugin($this->getShopwarePluginBootstrapClass()->Plugin());

            Shopware()->Models()->persist($secondMenu);

            $thirdMenu = new \Shopware\Models\Menu\Menu();
            $thirdMenu->setLabel('Fehler-Code übersicht');
            $thirdMenu->setClass('bf_icon_error_code_list');
            $thirdMenu->setActive(true);
            $thirdMenu->setController('BrickfoxUiErrorCodeList');
            $thirdMenu->setAction('Index');
            $thirdMenu->setParent($parentMenu);
            $thirdMenu->setPlugin($this->getShopwarePluginBootstrapClass()->Plugin());

            Shopware()->Models()->persist($thirdMenu);

            Shopware()->Models()->flush();
        }
    }
}
