<?php

namespace Bf\Multichannel\Patches\SCRIPT;

use Bf\Multichannel\Components\Util\Patches\PatchesAbstract;

class PatchAddOrderDisablePartnerImportConfig extends PatchesAbstract
{
    const SQL_PATCH_FILE_NAME = 'Patches/SQL/PatchAddOrderDisablePartnerImportConfig.sql';

    /**
     * @param null $shopwarePluginBootstrap
     */
    public function __construct($shopwarePluginBootstrap = null)
    {
        $this->setShopwarePluginBootstrapClass($shopwarePluginBootstrap);
        parent::__construct('');
    }

    public function preparePatch()
    {
        $sqlContent = file_get_contents($this->getShopwarePluginBootstrapClass()->Path() . self::SQL_PATCH_FILE_NAME);

        Shopware()->Db()->query($sqlContent);
    }
}
