<?php

namespace Shopware\CustomModels\BfMultichannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * MappingAttributesVariations
 *
 * @package Shopware\CustomModels\BfMultichannel
 *
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 *
 */
/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_attr_variations", uniqueConstraints={@UniqueConstraint(name="attributes_variations_code", columns={"attributes_variations_code"})})
 */
class MappingAttributesVariations extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $attributesVariationsCode
     * @ORM\Column(name="attributes_variations_code", type="string", nullable=false)
     */
    private $attributesVariationsCode;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return MappingAttributesVariations
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return string
     */
    public function getAttributesVariationsCode()
    {
        return $this->attributesVariationsCode;
    }

    /**
     * @param string $attributesVariationsCode
     *
     * @return MappingAttributesVariations
     */
    public function setAttributesVariationsCode($attributesVariationsCode)
    {
        $this->attributesVariationsCode = $attributesVariationsCode;

        return $this;
    }
}
