<?php
/**
 * ApiExportProductsUpdate
 *
 * @package   Shopware\CustomModels\BfMultichannel
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfMultichannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Doctrine\ORM\Mapping\Index;
use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_api_export_products_update", uniqueConstraints={@UniqueConstraint(name="shopwareID", columns={"shopwareID"})}, indexes={@Index(name="search_idx",
 *                                                  columns={"shopwareID"})})
 */
class ApiExportProductsUpdate extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var int $shopwareId
     * @ORM\Column(name="shopwareID", type="integer", nullable=false)
     */
    private $shopwareId;

    /**
     * @var string $stockHash
     * @ORM\Column(name="stock_hash", type="string", nullable=false)
     */
    private $stockHash;

    /**
     * @var string $priceHash
     * @ORM\Column(name="price_hash", type="string", nullable=false)
     */
    private $priceHash;

    /**
     * @var \DateTime $dateInsert
     * @ORM\Column(name="date_insert", type="datetime", nullable=false)
     */
    private $dateInsert;

    /**
     * @var \DateTime $lastUpdate
     * @ORM\Column(name="last_update", type="datetime", nullable=false)
     */
    private $lastUpdate;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return ApiExportProductsUpdate
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return int
     */
    public function getShopwareId()
    {
        return $this->shopwareId;
    }

    /**
     * @param int $shopwareId
     *
     * @return ApiExportProductsUpdate
     */
    public function setShopwareId($shopwareId)
    {
        $this->shopwareId = $shopwareId;

        return $this;
    }

    /**
     * @return string
     */
    public function getStockHash()
    {
        return $this->stockHash;
    }

    /**
     * @param string $stockHash
     *
     * @return ApiExportProductsUpdate
     */
    public function setStockHash($stockHash)
    {
        $this->stockHash = $stockHash;

        return $this;
    }

    /**
     * @return string
     */
    public function getPriceHash()
    {
        return $this->priceHash;
    }

    /**
     * @param string $priceHash
     *
     * @return ApiExportProductsUpdate
     */
    public function setPriceHash($priceHash)
    {
        $this->priceHash = $priceHash;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getDateInsert()
    {
        return $this->dateInsert;
    }

    /**
     * @param mixed $dateInsert
     *
     * @return ApiExportProductsUpdate
     */
    public function setDateInsert($dateInsert)
    {
        $this->dateInsert = $dateInsert;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getLastUpdate()
    {
        return $this->lastUpdate;
    }

    /**
     * @param mixed $lastUpdate
     *
     * @return ApiExportProductsUpdate
     */
    public function setLastUpdate($lastUpdate)
    {
        $this->lastUpdate = $lastUpdate;

        return $this;
    }
}
