<?php
/**
 * ApiExportProducts
 *
 * @package   Shopware\CustomModels\BfMultichannel
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfMultichannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Doctrine\ORM\Mapping\Index;
use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_api_export_products", uniqueConstraints={@UniqueConstraint(name="shopwareID", columns={"shopwareID"})}, indexes={@Index(name="search_idx",
 *                                           columns={"is_deleted","to_delete"})})
 */
class ApiExportProducts extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var int $shopwareId
     * @ORM\Column(name="shopwareID", type="integer", nullable=false)
     */
    private $shopwareId;

    /**
     * @var int $isDeleted
     * @ORM\Column(name="is_deleted", type="integer")
     */
    private $isDeleted;

    /**
     * @var int $toDelete
     * @ORM\Column(name="to_delete", type="integer")
     */
    private $toDelete;

    /**
     * @ORM\Column(name="last_export_date", type="datetime", nullable=false)
     */
    private $lasExportDate;

    /**
     * @ORM\Column(name="last_assignments_export_date", type="datetime", nullable=true)
     */
    private $lastAssignmentsExportDate;

    /**
     * @ORM\Column(name="article_last_update", type="datetime", nullable=false)
     */
    private $articleLastUpdate;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return ApiExportProducts
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return int
     */
    public function getShopwareId()
    {
        return $this->shopwareId;
    }

    /**
     * @param int $shopwareId
     *
     * @return ApiExportProducts
     */
    public function setShopwareId($shopwareId)
    {
        $this->shopwareId = $shopwareId;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getLasExportDate()
    {
        return $this->lasExportDate;
    }

    /**
     * @param mixed $lasExportDate
     *
     * @return ApiExportProducts
     */
    public function setLasExportDate($lasExportDate)
    {
        $this->lasExportDate = $lasExportDate;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getArticleLastUpdate()
    {
        return $this->articleLastUpdate;
    }

    /**
     * @param mixed $articleLastUpdate
     *
     * @return ApiExportProducts
     */
    public function setArticleLastUpdate($articleLastUpdate)
    {
        $this->articleLastUpdate = $articleLastUpdate;

        return $this;
    }

    /**
     * @return int
     */
    public function getIsDeleted()
    {
        return $this->isDeleted;
    }

    /**
     * @param int $isDeleted
     *
     * @return ApiExportProducts
     */
    public function setIsDeleted($isDeleted)
    {
        $this->isDeleted = $isDeleted;

        return $this;
    }

    /**
     * @return int
     */
    public function getToDelete()
    {
        return $this->toDelete;
    }

    /**
     * @param int $toDelete
     *
     * @return ApiExportProducts
     */
    public function setToDelete($toDelete)
    {
        $this->toDelete = $toDelete;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getLastAssignmentsExportDate()
    {
        return $this->lastAssignmentsExportDate;
    }

    /**
     * @param mixed $lastAssignmentsExportDate
     *
     * @return ApiExportProducts
     */
    public function setLastAssignmentsExportDate($lastAssignmentsExportDate)
    {
        $this->lastAssignmentsExportDate = $lastAssignmentsExportDate;

        return $this;
    }
}
