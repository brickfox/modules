<?php

namespace Shopware\CustomModels\BfMultichannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Doctrine\ORM\Mapping\Index;
use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_api_export_seo_urls", indexes={@Index(name="search_idx", columns={"brickfoxExternID", "shopwareID", "shopwareDetailsID", "date_insert", "last_update"})})
 */
class ApiExportSeoUrls
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $brickfoxExternId
     * @ORM\Column(name="brickfoxExternID", type="integer", nullable=false)
     */
    private $brickfoxExternId;

    /**
     * @var integer $shopwareId
     * @ORM\Column(name="shopwareID", type="integer", nullable=false)
     */
    private $shopwareId;

    /**
     * @var@var integer $shopwareDetailsId
     * @ORM\Column(name="shopwareDetailsID", type="integer", nullable=true)
     */
    private $shopwareDetailsId;

    /**
     * @var string $originalPath
     * @ORM\Column(name="original_path", type="string", nullable=false)
     */
    private $originalPath;

    /**
     * @var string $seoPath
     * @ORM\Column(name="seo_path", type="string", nullable=false)
     */
    private $seoPath;

    /**
     * @var \DateTime $dateInsert
     * @ORM\Column(name="date_insert", type="datetime", nullable=true)
     */
    private $dateInsert;

    /**
     * @var \DateTime $lastUpdate
     * @ORM\Column(name="last_update", type="datetime", nullable=true)
     */
    private $lastUpdate;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return int
     */
    public function getBrickfoxExternId()
    {
        return $this->brickfoxExternId;
    }

    /**
     * @param int $brickfoxExternId
     */
    public function setBrickfoxExternId($brickfoxExternId)
    {
        $this->brickfoxExternId = $brickfoxExternId;
    }

    /**
     * @return mixed
     */
    public function getShopwareDetailsId()
    {
        return $this->shopwareDetailsId;
    }

    /**
     * @param mixed $shopwareDetailsId
     */
    public function setShopwareDetailsId($shopwareDetailsId)
    {
        $this->shopwareDetailsId = $shopwareDetailsId;
    }

    /**
     * @return int
     */
    public function getShopwareId()
    {
        return $this->shopwareId;
    }

    /**
     * @param int $shopwareId
     */
    public function setShopwareId($shopwareId)
    {
        $this->shopwareId = $shopwareId;
    }

    /**
     * @return string
     */
    public function getOriginalPath()
    {
        return $this->originalPath;
    }

    /**
     * @param string $originalPath
     */
    public function setOriginalPath($originalPath)
    {
        $this->originalPath = $originalPath;
    }

    /**
     * @return string
     */
    public function getSeoPath()
    {
        return $this->seoPath;
    }

    /**
     * @param string $seoPath
     */
    public function setSeoPath($seoPath)
    {
        $this->seoPath = $seoPath;
    }

    /**
     * @return \DateTime
     */
    public function getDateInsert()
    {
        return $this->dateInsert;
    }

    /**
     * @param \DateTime $dateInsert
     */
    public function setDateInsert($dateInsert)
    {
        $this->dateInsert = $dateInsert;
    }

    /**
     * @return \DateTime
     */
    public function getLastUpdate()
    {
        return $this->lastUpdate;
    }

    /**
     * @param \DateTime $lastUpdate
     */
    public function setLastUpdate($lastUpdate)
    {
        $this->lastUpdate = $lastUpdate;
    }
}