<?php
/**
 * MappingOrderStatus.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfMultichannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_order_status")
 */
class MappingOrderStatus extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $brickfoxOrderStatusCode
     * @ORM\Column(name="brickfox_order_status_code", type="string", nullable=false)
     */
    private $brickfoxOrderStatusCode;

    /**
     * @var integer $shopwareId
     * @ORM\Column(name="shopwareID", type="integer", nullable=false)
     */
    private $shopwareId;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getBrickfoxOrderStatusCode()
    {
        return $this->brickfoxOrderStatusCode;
    }

    /**
     * @param string $brickfoxOrderStatusCode
     */
    public function setBrickfoxOrderStatusCode($brickfoxOrderStatusCode)
    {
        $this->brickfoxOrderStatusCode = $brickfoxOrderStatusCode;
    }

    /**
     * @return int
     */
    public function getShopwareId()
    {
        return $this->shopwareId;
    }

    /**
     * @param int $shopwareId
     */
    public function setShopwareId($shopwareId)
    {
        $this->shopwareId = $shopwareId;
    }
}