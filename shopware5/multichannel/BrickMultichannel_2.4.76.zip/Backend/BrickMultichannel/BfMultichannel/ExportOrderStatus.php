<?php
/**
 * ExportOrderStatus
 *
 * @package   Shopware\CustomModels\BfMultichannel
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfMultichannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Doctrine\ORM\Mapping\Index;
use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_export_order_status", uniqueConstraints={@UniqueConstraint(name="orderID", columns={"orderID"})}, indexes={@Index(name="search_idx",
 *                                           columns={"lastExportStatus"})})
 */
class ExportOrderStatus extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $orderId
     * @ORM\Column(name="orderID", type="integer", nullable=false)
     */
    private $orderId;

    /**
     * @var integer $lastExportStatus
     * @ORM\Column(name="lastExportStatus", type="integer", nullable=false)
     */
    private $lastExportStatus;

    /**
     * @ORM\Column(name="dateInsert", type="datetime", nullable=false)
     */
    private $dateInsert;

    /**
     * @ORM\Column(name="lastUpdate", type="datetime", nullable=false)
     */
    private $lastUpdate;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return ExportOrderStatus
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return int
     */
    public function getOrderId()
    {
        return $this->orderId;
    }

    /**
     * @param int $orderId
     *
     * @return ExportOrderStatus
     */
    public function setOrderId($orderId)
    {
        $this->orderId = $orderId;

        return $this;
    }

    /**
     * @return int
     */
    public function getLastExportStatus()
    {
        return $this->lastExportStatus;
    }

    /**
     * @param int $lastExportStatus
     *
     * @return ExportOrderStatus
     */
    public function setLastExportStatus($lastExportStatus)
    {
        $this->lastExportStatus = $lastExportStatus;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getDateInsert()
    {
        return $this->dateInsert;
    }

    /**
     * @param mixed $dateInsert
     *
     * @return ExportOrderStatus
     */
    public function setDateInsert($dateInsert)
    {
        $this->dateInsert = $dateInsert;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getLastUpdate()
    {
        return $this->lastUpdate;
    }

    /**
     * @param mixed $lastUpdate
     *
     * @return ExportOrderStatus
     */
    public function setLastUpdate($lastUpdate)
    {
        $this->lastUpdate = $lastUpdate;

        return $this;
    }
}
