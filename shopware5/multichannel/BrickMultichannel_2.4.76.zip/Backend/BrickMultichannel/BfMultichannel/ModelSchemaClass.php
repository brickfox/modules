<?php
/**
 * ModelSchemaClass
 *
 * @package   Shopware\CustomModels\BfMultichannel
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfMultichannel;

class ModelSchemaClass
{
    const DEFAULT_FIELDS_TYPE = 'string';

    private static $instance = null;

    /**
     * @return ModelSchemaClass
     */
    public static function getInstance()
    {
        if(self::$instance === null)
        {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * @return array
     */
    public function getConfigurationSchemaModel()
    {
        $schema = array(
            'fields' => array()
        );

        $repository             = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\Configuration');
        $configurationModelList = $repository->findAll();

        if(count($configurationModelList) > 0)
        {
            /** @var \Shopware\CustomModels\BfMultichannel\Configuration $configuration */
            foreach($configurationModelList as $configuration)
            {
                $schema['fields'][] = array(
                    'name' => $configuration->getConfigurationKey(),
                    'type' => self::DEFAULT_FIELDS_TYPE
                );
            }
        }

        return $schema;
    }

    private function __construct()
    {
    }

    private function __clone()
    {
    }
}
