<?php
/**
 * MappingTranslation
 *
 * @package   Shopware\CustomModels\BfSaleschannel
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfMultichannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_tax_rates", uniqueConstraints={@UniqueConstraint(name="shopware_tax_rate", columns={"mapping_field_key"})})
 */
class MappingTaxRates extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $mappingFieldKey
     * @ORM\Column(name="mapping_field_key", type="string", nullable=false)
     */
    private $mappingFieldKey;

    /**
     * @var string $brickfoxTaxClass
     * @ORM\Column(name="brickfox_tax_class", type="string", nullable=false)
     */
    private $brickfoxTaxClass;


    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return \Shopware\CustomModels\BfMultichannel\MappingTaxRates
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return string
     */
    public function getBrickfoxTaxClass()
    {
        return $this->brickfoxTaxClass;
    }

    /**
     * @param string $brickfoxTaxCategoryId
     *
     * @return \Shopware\CustomModels\BfMultichannel\MappingTaxRates
     */
    public function setBrickfoxTaxClass($brickfoxTaxClass)
    {
        $this->brickfoxTaxClass = $brickfoxTaxClass;

        return $this;
    }

    /**
     * @return string
     */
    public function getMappingFieldKey()
    {
        return $this->mappingFieldKey;
    }

    /**
     * @param string $mappingFieldKey
     *
     * @return \Shopware\CustomModels\BfMultichannel\MappingTaxRates
     */
    public function setMappingFieldKey($mappingFieldKey)
    {
        $this->mappingFieldKey = $mappingFieldKey;

        return $this;
    }
}
