<?php

namespace Shopware\CustomModels\BfMultichannel;

use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * MappingAddressToFreetext
 *
 * @package Shopware\CustomModels\BfMultichannel
 *
 * This file is part of brickfox.
 * @author brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2016 brickfox GmbH http://www.brickfox.de
 *
 */
/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_address_to_freetext")
 */
class MappingAddressToFreetext extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $freetextFieldId
     * @ORM\Column(name="freetext_field_id", type="integer", nullable=false)
     */
    private $freetextFieldId;

    /**
     * @var string $addressFieldName
     * @ORM\Column(name="address_field_name", type="string", nullable=false)
     */
    private $addressFieldName;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return MappingAddressToFreetext
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return int
     */
    public function getFreetextFieldId()
    {
        return $this->freetextFieldId;
    }

    /**
     * @param int $freetextFieldId
     */
    public function setFreetextFieldId($freetextFieldId)
    {
        $this->freetextFieldId = $freetextFieldId;
    }

    /**
     * @return string
     */
    public function getAddressFieldName()
    {
        return $this->addressFieldName;
    }

    /**
     * @param string $addressFieldName
     *
     * @return MappingAddressToFreetext
     */
    public function setAddressFieldName($addressFieldName)
    {
        $this->addressFieldName = $addressFieldName;

        return $this;
    }
}
