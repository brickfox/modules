<?php
/**
 * ApiImportOrders
 *
 * @package   Shopware\CustomModels\BfMultichannel
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfMultichannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Doctrine\ORM\Mapping\Index;
use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_api_import_orders", indexes={@Index(name="search_idx", columns={"bf_shops_orders_id"})})
 */
class ApiImportOrders extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $shopsOrdersId
     * @ORM\Column(name="bf_shops_orders_id", type="string", nullable=true)
     */
    private $shopsOrdersId;

    /**
     * @var string $channelName
     * @ORM\Column(name="bf_shops_name", type="string", nullable=true)
     */
    private $channelName;

    /**
     * @var string $orderData
     * @ORM\Column(name="order_data", type="text", nullable=false)
     */
    private $orderData;

    /**
     * @var bool $processed
     * @ORM\Column(name="processed", type="integer", nullable = false)
     */
    private $processed;

    /**
     * @var  string $error
     * @ORM\Column(name="error", type="text", nullable=true)
     */
    private $error;

    /**
     * @var \DateTime $dateInsert
     * @ORM\Column(name="date_insert", type="datetime", nullable=false)
     */
    private $dateInsert;

    /**
     * @var \DateTime $lastUpdate
     * @ORM\Column(name="last_update", type="datetime", nullable=false)
     */
    private $lastUpdate;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return ApiImportOrders
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getDateInsert()
    {
        return $this->dateInsert;
    }

    /**
     * @param \DateTime $dateInsert
     *
     * @return ApiImportOrders
     */
    public function setDateInsert($dateInsert)
    {
        $this->dateInsert = $dateInsert;

        return $this;
    }

    /**
     * @return string
     */
    public function getOrderData()
    {
        return $this->orderData;
    }

    /**
     * @param string $orderData
     *
     * @return ApiImportOrders
     */
    public function setOrderData($orderData)
    {
        $this->orderData = $orderData;

        return $this;
    }

    /**
     * @return boolean
     */
    public function getProcessed()
    {
        return $this->processed;
    }

    /**
     * @param boolean $processed
     *
     * @return ApiImportOrders
     */
    public function setProcessed($processed)
    {
        $this->processed = $processed;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getLastUpdate()
    {
        return $this->lastUpdate;
    }

    /**
     * @param \DateTime $lastUpdate
     *
     * @return ApiImportOrders
     */
    public function setLastUpdate($lastUpdate)
    {
        $this->lastUpdate = $lastUpdate;

        return $this;
    }

    /**
     * @return int
     */
    public function getShopsOrdersId()
    {
        return $this->shopsOrdersId;
    }

    /**
     * @param int $shopsOrdersId
     *
     * @return ApiImportOrders
     */
    public function setShopsOrdersId($shopsOrdersId)
    {
        $this->shopsOrdersId = $shopsOrdersId;

        return $this;
    }

    /**
     * @return string
     */
    public function getChannelName()
    {
        return $this->channelName;
    }

    /**
     * @param string $channelName
     *
     * @return ApiImportOrders
     */
    public function setChannelName($channelName)
    {
        $this->channelName = $channelName;

        return $this;
    }

    /**
     * @return string
     */
    public function getError()
    {
        return $this->error;
    }

    /**
     * @param string $error
     *
     * @return ApiImportOrders
     */
    public function setError($error)
    {
        $this->error = $error;

        return $this;
    }
}
