<?php
/**
 * MappingOrderStatus.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfMultichannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_order_details_attr")
 */
class MappingOrderDetailsAttributes extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $brickfoxOrderAddInfoKey
     * @ORM\Column(name="brickfox_order_add_info_key", type="string", nullable=false)
     */
    private $brickfoxOrderAddInfoKey;

    /**
     * @var string $shopwareFieldName
     * @ORM\Column(name="shopware_field_name", type="string", nullable=false)
     */
    private $shopwareFieldName;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getBrickfoxOrderAddInfoKey()
    {
        return $this->brickfoxOrderAddInfoKey;
    }

    /**
     * @param string $brickfoxOrderAddInfoKey
     */
    public function setBrickfoxOrderAddInfoKey($brickfoxOrderAddInfoKey)
    {
        $this->brickfoxOrderAddInfoKey = $brickfoxOrderAddInfoKey;
    }

    /**
     * @return string
     */
    public function getShopwareFieldName()
    {
        return $this->shopwareFieldName;
    }

    /**
     * @param string $shopwareFieldName
     */
    public function setShopwareFieldName($shopwareFieldName)
    {
        $this->shopwareFieldName = $shopwareFieldName;
    }
}