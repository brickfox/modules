<?php
/**
 * MappingPayment
 *
 * @package   Shopware\CustomModels\BfMultichannel
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfMultichannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_payment", uniqueConstraints={@UniqueConstraint(name="brickfox_payment_code", columns={"brickfox_payment_code"})})
 */
class MappingPayment extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $brickfoxPaymentCode
     * @ORM\Column(name="brickfox_payment_code", type="string", nullable=false)
     */
    private $brickfoxPaymentCode;

    /**
     * @var string $mappingFieldKey
     * @ORM\Column(name="mapping_field_key", type="integer", nullable=false)
     */
    private $mappingFieldKey;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return MappingPayment
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return string
     */
    public function getBrickfoxPaymentCode()
    {
        return $this->brickfoxPaymentCode;
    }

    /**
     * @param string $brickfoxPaymentCode
     *
     * @return MappingPayment
     */
    public function setBrickfoxPaymentCode($brickfoxPaymentCode)
    {
        $this->brickfoxPaymentCode = $brickfoxPaymentCode;

        return $this;
    }

    /**
     * @return string
     */
    public function getMappingFieldKey()
    {
        return $this->mappingFieldKey;
    }

    /**
     * @param string $mappingFieldKey
     *
     * @return MappingPayment
     */
    public function setMappingFieldKey($mappingFieldKey)
    {
        $this->mappingFieldKey = $mappingFieldKey;

        return $this;
    }
}
