<?php
/**
 * ApiGuiLog
 *
 * @package   Shopware\CustomModels\BfMultichannel
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfMultichannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Doctrine\ORM\Mapping\Index;
use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_api_gui_log", indexes={@Index(name="search_idx", columns={"type", "error_code", "last_updater"})})
 */
class ApiGuiLog extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $type
     * @ORM\Column(name="type", type="string", nullable=false)
     */
    private $type;

    /**
     * @var $errorCode
     * @ORM\Column(name="error_code", type="string", nullable=true)
     */
    private $errorCode;

    /**
     * @var $message
     * @ORM\Column(name="message", type="text", nullable=true)
     */
    private $message;

    /**
     * @ORM\Column(name="date_insert", type="datetime", nullable=false)
     */
    private $dateInsert;

    /**
     * @ORM\Column(name="last_update", type="datetime", nullable=false)
     */
    private $lastUpdate;

    /**
     * @var string $lastUpdater
     * @ORM\Column(name="last_updater", type="string", nullable=false)
     */
    private $lastUpdater;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     *
     * @return ApiGuiLog
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @param string $type
     *
     * @return ApiGuiLog
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getErrorCode()
    {
        return $this->errorCode;
    }

    /**
     * @param mixed $errorCode
     *
     * @return ApiGuiLog
     */
    public function setErrorCode($errorCode)
    {
        $this->errorCode = $errorCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * @param mixed $message
     *
     * @return ApiGuiLog
     */
    public function setMessage($message)
    {
        $this->message = $message;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getDateInsert()
    {
        return $this->dateInsert;
    }

    /**
     * @param mixed $dateInsert
     *
     * @return ApiGuiLog
     */
    public function setDateInsert($dateInsert)
    {
        $this->dateInsert = $dateInsert;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getLastUpdate()
    {
        return $this->lastUpdate;
    }

    /**
     * @param mixed $lastUpdate
     *
     * @return ApiGuiLog
     */
    public function setLastUpdate($lastUpdate)
    {
        $this->lastUpdate = $lastUpdate;

        return $this;
    }

    /**
     * @return string
     */
    public function getLastUpdater()
    {
        return $this->lastUpdater;
    }

    /**
     * @param string $lastUpdater
     *
     * @return ApiGuiLog
     */
    public function setLastUpdater($lastUpdater)
    {
        $this->lastUpdater = $lastUpdater;

        return $this;
    }
}
