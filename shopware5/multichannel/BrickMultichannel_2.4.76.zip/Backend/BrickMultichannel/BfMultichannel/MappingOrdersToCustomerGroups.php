<?php
/**
 * MappingOrdersToShops.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2018 brickfox GmbH http://www.brickfox.de
 */

namespace Shopware\CustomModels\BfMultichannel;

use Doctrine\ORM\Mapping\UniqueConstraint;
use Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="bf_mapping_orders_to_customergroups", uniqueConstraints={@UniqueConstraint(name="brickfox_shops_id", columns={"brickfox_shops_id"})})
 */
class MappingOrdersToCustomerGroups extends ModelEntity
{
    /**
     * Autoincrement ID
     *
     * @var integer $id
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $brickfoxShopsId
     * @ORM\Column(name="brickfox_shops_id", type="integer", nullable=false)
     */
    private $brickfoxShopsId;

    /**
     * @var integer $shopwareCustomerGroupId
     * @ORM\Column(name="shopware_customergroup_id", type="integer", nullable=false)
     */
    private $shopwareCustomerGroupId;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return int
     */
    public function getBrickfoxShopsId()
    {
        return $this->brickfoxShopsId;
    }

    /**
     * @param int $brickfoxShopsId
     */
    public function setBrickfoxShopsId($brickfoxShopsId)
    {
        $this->brickfoxShopsId = $brickfoxShopsId;
    }

    /**
     * @return int
     */
    public function getShopwareCustomerGroupId()
    {
        return $this->shopwareCustomerGroupId;
    }

    /**
     * @param int $shopwareCustomerGroupId
     */
    public function setShopwareCustomerGroupId($shopwareCustomerGroupId)
    {
        $this->shopwareCustomerGroupId = $shopwareCustomerGroupId;
    }
}