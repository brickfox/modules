<?php
/**
 * ImportAbstract
 *
 * @package   Bf\Multichannel\Components
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components;

use Bf\Multichannel\Components\Resource\Orders\Orders;
use Bf\Multichannel\Components\Resource\Orders\OrdersAttributesHelper;
use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\Helper;
use Bf\Multichannel\Components\Util\LastImportedOrder;
use Bf\Multichannel\Components\Util\PickwareCompability;
use Bf\Multichannel\Components\Util\sOrderFake;
use Exception;
use Shopware\CustomModels\BfMultichannel\ApiImportOrders;
use Shopware\CustomModels\BfMultichannel\ExportOrderStatus;

abstract class ImportAbstract
{
    /**
     * The value where we can get deadlocks
     */
    const INNODB_LOCK_WAIT_TIMEOUT_THRESHOLD = 50;
    /**
     * A value which resolved a couple of deadlocks
     */
    const INNODB_LOCK_WAIT_TIMEOUT = 120;

    public function preImport()
    {
    }

    /**
     * @param $file
     */
    public function import($file)
    {
        $this->preImport();

        $xmlReader = new \XMLReader();
        $xmlReader->open($file, null, LIBXML_NOCDATA);

        while($xmlReader->read() === true)
        {
            try
            {
                if($xmlReader->nodeType === \XMLReader::ELEMENT && $xmlReader->depth === 1)
                {
                    $simpleXmlElement = $xmlReader->readOuterXml();

                    $apiImportOrderModel = new ApiImportOrders();
                    $apiImportOrderModel->setOrderData((string) $simpleXmlElement);
                    $apiImportOrderModel->setProcessed(0);
                    $apiImportOrderModel->setDateInsert(new \DateTime());
                    $apiImportOrderModel->setLastUpdate(new \DateTime());

                    Shopware()->Models()->persist($apiImportOrderModel);
                    Shopware()->Models()->flush();
                    Shopware()->Models()->clear();
                }
            }
            catch(Exception $e)
            {
                echo '<pre>';
                print_r($e->getTrace());
                echo '</pre>';
                continue;
            }
        }

        $xmlReader->close();
    }

    /**
     * @param ApiImportOrders $apiImportOrders
     *
     * @throws Exception
     */
    public function process(\Shopware\CustomModels\BfMultichannel\ApiImportOrders $apiImportOrders, $isIncreaseInnoDBLockWaitTimeoutEnabled)
    {
        if($isIncreaseInnoDBLockWaitTimeoutEnabled === true){
            try {
                $this->increaseInnoDBLockWaitTimeout();
            }
            catch (\Zend_Db_Adapter_Exception $e) {}
            catch(\Zend_Db_Statement_Exception $e) {}
        }

        $newOrdersModel   = null;
        $simpleXmlElement = new \SimpleXMLElement($apiImportOrders->getOrderData());
        $errorMessage     = '';

        try
        {
            if(ConfigManager::getInstance()->isUsePickwareCompability() === true) {
                LastImportedOrder::getInstance()->clear();
            }

            $newOrdersModel = $this->processImport($simpleXmlElement);
        }
        catch(\Throwable $t) {
            $errorMessage = $t->getMessage();
        }
        catch(Exception $e)
        {
            $errorMessage = $e->getMessage();
        }

        $apiImportOrders = $this->reloadActiveProcessModel($apiImportOrders->getId());

        if($apiImportOrders instanceof \Shopware\CustomModels\BfMultichannel\ApiImportOrders)
        {
            $apiImportOrders->setShopsOrdersId((string) $simpleXmlElement->ExternOrderId);
            $apiImportOrders->setChannelName((string) $simpleXmlElement->SalesChannelName);
            $apiImportOrders->setProcessed(1);
            $apiImportOrders->setError($errorMessage);
            Shopware()->Models()->persist($apiImportOrders);
        }

        if($this->orderAlreadyExists((string) $simpleXmlElement->ExternOrderId, (string) $simpleXmlElement->OrderId) === false && $newOrdersModel !== null)
        {
            try
            {
                Shopware()->Models()->flush();

                if($newOrdersModel instanceof \Shopware\Models\Order\Order)
                {
                    $this->postImport($newOrdersModel);
                }

                $ordersAttributesModel = $newOrdersModel->getAttribute();

                if ($ordersAttributesModel === null) {
                    $ordersAttributesModel = new \Shopware\Models\Attribute\Order();
                    $ordersAttributesModel->setOrder($newOrdersModel);
                }

                if (count(OrdersAttributesHelper::getInstance()->getOrdersAttributes()) > 0) {
                    $ordersAttributes = OrdersAttributesHelper::getInstance()->getOrdersAttributes();
                    foreach ($ordersAttributes as $setter => $value) {
                        if (method_exists($ordersAttributesModel, $setter) === true) {
                            $ordersAttributesModel->$setter($value);
                        }
                    }
                }

                Shopware()->Models()->persist($ordersAttributesModel);
                Shopware()->Models()->flush($ordersAttributesModel);
                Shopware()->Models()->clear();

                OrdersAttributesHelper::getInstance()->cleanUp();
            }
            catch(Exception $e)
            {
                throw new Exception($e);
            }
        }
        else
        {
            if($errorMessage === '') {
                // No exception was previously caught / registered
                $apiImportOrders->setError('Die Bestellung wurde bereits importiert.');
            }
            Shopware()->Models()->flush($apiImportOrders);
            Shopware()->Models()->clear();
        }
    }

    /**
     * @param $externOrderId
     * @param $orderId
     *
     * @return bool
     */
    private function orderAlreadyExists($externOrderId, $orderId)
    {
        $orderAlreadyExists = false;

        if((bool) Helper::getConfigurationByKey('useExternOrdersNumberAsShopwareOrdersNumber')->getConfigurationValue() === false)
        {
            if (ConfigManager::getInstance()->isOrderDisablePartnerImport() === false) {
                $s_orderResult = Shopware()->Db()->fetchOne(
                    "select id from s_order where `temporaryID` = ? and `partnerID` = ?",
                    [$orderId, Orders::BRICKFOX_ID_CODE]
                );
            } else {
                $s_orderResult = Shopware()->Db()->fetchOne(
                    "select id from s_order where `temporaryID` = ?",
                    [$orderId]
                );
            }
        }
        else
        {
            $s_orderResult = Shopware()->Db()->fetchOne(
                "
             select id from s_order where `ordernumber` = ?
            ",array($externOrderId)
            );
        }

        if((int) $s_orderResult > 0)
        {
            $orderAlreadyExists = true;
        }

        return $orderAlreadyExists;
    }

    /**
     * @param $activeModelId
     *
     * @return null|object
     */
    private function reloadActiveProcessModel($activeModelId)
    {
        $repository           = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiImportOrders');
        $apiImportOrdersModel = $repository->findOneBy(array('id' => $activeModelId));

        return $apiImportOrdersModel;
    }

    /**
     * @param \Shopware\Models\Order\Order $order
     */
    public function postImport(\Shopware\Models\Order\Order $order)
    {
        try {
            $paymentMeansID = $order->getPayment()->getId();
            $userID = $order->getCustomer()->getId();
            $orderID = $order->getId();

            $orderAmount = Shopware()->Models()->createQueryBuilder()
                ->select('orders.invoiceAmount')
                ->from('Shopware\Models\Order\Order', 'orders')
                ->where('orders.id = ?1')
                ->setParameter(1, $orderID)
                ->getQuery()
                ->getSingleScalarResult();

            $addressData = Shopware()->Models()->getRepository('Shopware\Models\Customer\Customer')
                ->find($userID)->getDefaultBillingAddress();

            $date = new \DateTime();
            $data = [
                'payment_mean_id' => $paymentMeansID,
                'order_id' => $orderID,
                'user_id' => $userID,
                'firstname' => $addressData->getFirstname(),
                'lastname' => $addressData->getLastname(),
                'address' => $addressData->getStreet(),
                'zipcode' => $addressData->getZipcode(),
                'city' => $addressData->getCity(),
                'amount' => $orderAmount,
                'created_at' => $date->format('Y-m-d'),
            ];

            Shopware()->Db()->insert('s_core_payment_instance', $data);

            if(ConfigManager::getInstance()->isUsePickwareCompability() === true) {
                $order = LastImportedOrder::getInstance()->getOrder();
                $details = [];

                foreach (LastImportedOrder::getInstance()->getOrderDetailInfo() as $orderDetails) {
                    $orderDetailModel = isset($orderDetails[LastImportedOrder::KEY_SW_ORDER_DETAIL_MODEL]) ? $orderDetails[LastImportedOrder::KEY_SW_ORDER_DETAIL_MODEL] : null;
                    $additionalInfo = isset($orderDetails[LastImportedOrder::KEY_ADDITIONAL_INFO]) ? $orderDetails[LastImportedOrder::KEY_ADDITIONAL_INFO] : null;

                    if($orderDetailModel !== null && $additionalInfo !== null) {
                        $viisionArticleNumber = $additionalInfo[PickwareCompability::VIISON_SET_ARTICLE_SET_ARTICLE_ORDER_NUMBER];

                        if(is_null($viisionArticleNumber) === false && strlen($viisionArticleNumber) > 0) {
                            $details[] = [
                                'orderDetailId' => $orderDetailModel->getId(),
                                'viisonSetArticleSetArticleOrderNumber' => $viisionArticleNumber
                            ];
                        }
                    }
                }

                if(count($details) > 0) {
                    $subject = new sOrderFake();
                    $subject->sOrderNumber = $order->getNumber();

                    $shopModel = LastImportedOrder::getInstance()->getShop();

                    if($shopModel !== null) {
                        $version = Shopware()->Container()->getParameter('shopware.release.version');

                        if(is_null($version) === true) {
                            $version = '';
                        }

                        // Shopware 5.7 compatiblity
                        if (version_compare($version, '5.7', '>=')) {
                            Shopware()->Container()->set('shop', $shopModel);
                        } else {
                            Shopware()->Bootstrap()->registerResource('Shop', $shopModel);
                        }

                        Shopware()->Events()->notify('Shopware_Modules_Order_SaveOrder_ProcessDetails', [
                            'subject' => $subject,
                            'details' => $details,
                            'orderId' => $order->getId(),
                        ]);
                    }
                }
            }
        } catch (\Exception $e) {
            //Payment method code failure
        }

        $orderStatusModel = new ExportOrderStatus();
        $orderStatusModel->setOrderId($order->getId());
        $orderStatusModel->setLastExportStatus($order->getOrderStatus()->getId());
        $orderStatusModel->setDateInsert(new \DateTime());
        $orderStatusModel->setLastUpdate(new \DateTime());

        Shopware()->Models()->persist($orderStatusModel);
        Shopware()->Models()->flush();

        Shopware()->Events()->notify(
            'Shopware_Brickfox_ImportAll_ImportOrders_OrderProcessed',
            [
                'subject' => $this,
                'orderId' => $order->getId(),
                'plugin' => 'Brickfox'
            ]
        );
    }

    /**
     * @param \SimpleXMLElement $simpleXMLElement
     *
     * @return mixed
     */
    abstract protected function processImport(\SimpleXMLElement $simpleXMLElement);

    /**
     * To remediate the error "ER_LOCK_WAIT_TIMEOUT: Lock wait timeout exceeded; try restarting transaction." for MySQL databases
     *
     * @throws \Zend_Db_Adapter_Exception
     * @throws \Zend_Db_Statement_Exception
     * @throws \Exception
     */
    private function increaseInnoDBLockWaitTimeout()
    {
        $databasePlatform = Shopware()->Container()->get('dbal_connection')->getDatabasePlatform();
        if ($databasePlatform instanceof \Doctrine\DBAL\Platforms\MySqlPlatform) {
            $result = Shopware()->Container()->get('dbal_connection')->query('SELECT @@innodb_lock_wait_timeout as innodb_lock_wait_timeout')->fetch();
            if ((int)$result["innodb_lock_wait_timeout"] <= self::INNODB_LOCK_WAIT_TIMEOUT_THRESHOLD) {
                Shopware()->Container()->get('dbal_connection')->query('SET SESSION innodb_lock_wait_timeout = ' . self::INNODB_LOCK_WAIT_TIMEOUT)->execute();
                $check = Shopware()->Container()->get('dbal_connection')->query('SELECT @@innodb_lock_wait_timeout as innodb_lock_wait_timeout')->fetch();
                if ((int)$check["innodb_lock_wait_timeout"] !== self::INNODB_LOCK_WAIT_TIMEOUT) {
                    throw new \Exception('Could not increase the timeout of the platform!');
                }
            }
        }
    }
}
