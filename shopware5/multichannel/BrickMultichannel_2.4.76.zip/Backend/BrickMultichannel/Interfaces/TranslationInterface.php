<?php
/**
 * TranslationInterface
 *
 * @package   Bf\Multichannel\Components\Interfaces
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Interfaces;

interface TranslationInterface
{
    const OBJECT_TYPE_TRANSLATION_CODE_ARTICLE                   = 'article';
    const OBJECT_TYPE_TRANSLATION_CODE_ATTRIBUTES                = 'attributes';
    const OBJECT_TYPE_TRANSLATION_CODE_PROPERTY_OPTION           = 'propertyoption';
    const OBJECT_TYPE_TRANSLATION_CODE_PROPERTY_VALUE            = 'propertyvalue';
    const LOCALE_ISO_CODE_QUERY_TYPE_MAIN                        = 'MAIN_LOCALE_ISO_CODE';
    const LOCALE_ISO_CODE_QUERY_TYPE_TRANSLATIONS                = 'TRANSLATIONS_LOCAL_ISO_CODE';
    const OBJECT_TYPE_TRANSLATION_CODE_PROPERTY_GROUP_AND_OPTION = 'propertyoption_propertyvalue';
    const LOCAL_ISO_CODE_QUERY_TYPE_MULTI_SHOP                   = 'MULTI_SHOP_ISO_CODE';

    /**
     * Return the main language iso code for the brickfox import.
     * Is there no mapping for the main iso code, script throws an exception
     * and the export item will skipped. Because brickfox needs an description node
     * in the xml and the child node "Title".
     *
     * @return string
     */
    public function getMainLanguageCode();

    /**
     * Returns an array, with all found mapped translations.
     * If an translation was not mapped, the translation of this entry will skipped
     */
    public function getItemTranslations();

    /**
     * Returns an array, with all found mapped translations from the properties.
     * If an translation was not mapped, the translation of this entry will be skipped
     *
     * @param $optionId
     * @param $valueId
     *
     * @return mixed
     */
    public function getPropertyTranslations($optionId, $valueId);

    /**
     * Return single entries from the given translationCollection.
     * Selects the local iso code from shopware "s_core_shop->s_core_locale".
     * And gets the mapped iso code from the mapping table "bf_mapping_translation".
     *
     * @param array $translationCollection
     *
     * @return \Generator
     */
    public function prepareTranslationData(array $translationCollection = array());

    /**
     * Return the mapping model if the given iso code ist mapped.
     *
     * @param $isoCode
     *
     * @return mixed
     */
    public function getTranslationMappingIsoCodeByGivenLocaleIsoCode($isoCode);
}