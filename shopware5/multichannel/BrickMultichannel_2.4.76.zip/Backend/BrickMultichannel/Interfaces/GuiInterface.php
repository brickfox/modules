<?php
/**
 * GuiInterface
 *
 * @package   Bf\Multichannel\Components\Interfaces
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Interfaces;

interface GuiInterface
{
    /**
     * @param $saveItem
     *
     * @return boolean
     */
    public function save($saveItem);

    /**
     * @param int    $start
     * @param int    $limit
     * @param null   $filter
     * @param string $modelNamespace
     *
     * @return array
     */
    public function load($start = 0, $limit = 25, $filter = null, $modelNamespace = '');

    /**
     * @param $deleteItem
     *
     * @return bool
     */
    public function delete($deleteItem);
}