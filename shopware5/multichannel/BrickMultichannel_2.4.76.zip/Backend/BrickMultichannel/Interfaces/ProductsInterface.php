<?php
/**
 * ProductsInterface
 *
 * @package   Bf\Multichannel\Components\Interfaces
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Interfaces;

use Doctrine\Common\Collections\ArrayCollection;
use Shopware\Models\Article\Article as SwArticle;
use Shopware\Models\Article\Detail as SwDetail;
use Shopware\Models\Article\Price as SwPrice;
use Shopware\Models\Category\Category as SwCategory;

interface ProductsInterface
{
    /**
     * @param SwArticle|SwDetail|SwPrice|SwCategory|ArrayCollection $model
     */
    public function __construct($model);

    /**
     * @param \Shopware\Models\Article\Article|\Shopware\Models\Article\Detail $model
     *
     * @return mixed
     */
    public function setModel($model);

    /**
     * @return \Shopware\Models\Article\Article|\Shopware\Models\Article\Detail
     */
    public function getModel();

    public function __destruct();
}