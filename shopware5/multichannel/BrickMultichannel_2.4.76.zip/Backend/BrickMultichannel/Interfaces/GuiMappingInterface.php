<?php
/**
 * GuiMappingInterface
 *
 * @package   Bf\Multichannel\Components\Interfaces
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Interfaces;

use Doctrine\ORM\QueryBuilder;

interface GuiMappingInterface
{
    /**
     * @param $parameters
     * @param $mappingKeyFields
     *
     * @return mixed
     */
    public function prepareSavingOneOrModeMappingEntries($parameters, $mappingKeyFields);

    /**
     * @param       $entity
     * @param array $array
     *
     * @return mixed
     */
    public function fromArray($entity, array $array = array());

    /**
     * @param QueryBuilder $qb
     * @param              $modelNamespace
     * @param              $filter
     *
     * @return mixed
     */
    public function mappingFilterCondition(QueryBuilder $qb, $modelNamespace, $filter);
}