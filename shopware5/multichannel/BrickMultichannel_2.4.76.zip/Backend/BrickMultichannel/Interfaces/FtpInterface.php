<?php
/**
 * FtpInterface
 *
 * @package   Bf\Multichannel\Components\Interfaces
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Interfaces;

interface FtpInterface
{
    /**
     * Initialize all required parameters to open a ftp connection.
     *
     * @param string $userName <p>
     *                         The username (USER).
     *                         </p>
     * @param string $password <p>
     *                         The password (PASS).
     *                         </p>
     * @param string $ftpHost  <p>
     *                         The FTP server address. This parameter shouldn't have any trailing
     *                         slashes and shouldn't be prefixed with ftp://.
     *                         </p>
     * @param int    $port     [optional] <p>
     *                         This parameter specifies an alternate port to connect to. If it is
     *                         omitted or set to zero, then the default FTP port, 21, will be used.
     *                         </p>
     */
    public function __construct($userName, $password, $ftpHost, $port);

    /**
     * Try to put the exported file to the given ftp file system.
     *
     * @param string $filePath <p>
     *                         The local file path.
     *                         </p>
     *
     * @return mixed
     */
    public function ftpPut($filePath);

    /**
     * Try to pull all files from the given ftp file system.
     *
     * @return mixed
     */
    public function ftpPull();

    /**
     * Try's to log into the given ftp file system.
     *
     * @return mixed
     */
    public function getFtpLogin();

    /**
     * Verify if ftp connection as ssl or not if ssl active:
     * ftp_ssl_connect else
     * ftp_connect
     *
     * @return mixed
     */
    public function prepareConnection();

    /**
     * Handles ftp file transfer logic parts.
     *
     * @param string $filePath <p>
     *                         The local file path.
     *                         </p>
     *
     * @return mixed
     */
    public function ftpTransfer($filePath);

    /**
     * If ssl inactive try to get normal ssl connection.
     *
     * @return mixed
     */
    public function ftpConnect();

    /**
     * If ssl is active try to get ssl connection
     *
     * @return mixed
     */
    public function sslFtpConnect();

    /**
     * Set's the passive mode or not
     *
     * @return mixed
     */
    public function ftpPassive();

    /**
     * If $ignoreWaitingTime sets to true, all files where imported
     * or exported
     *
     * @param bool|false $ignoreWaitingTime
     *
     * @return mixed
     */
    public function ignoreWaitingTime($ignoreWaitingTime = false);

    /**
     * Destroy all given required parameters and close the ftp_connection via ftp_close(stream)
     */
    public function __destruct();
}