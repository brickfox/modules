<?php
/**
 * RegisterEvents
 *
 * @package   Bf\Saleschannel\Install
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Install;

class RegisterEvents extends InstallAbstract
{
    /**
     * @param \Shopware_Components_Plugin_Bootstrap $shopwarePluginBootstrapClass
     */
    public function __construct($shopwarePluginBootstrapClass)
    {
        parent::__construct($shopwarePluginBootstrapClass);
    }

    public function executeRegisterEvents()
    {
        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Enlight_Controller_Dispatcher_ControllerPath_Backend_Brickfox',
            'onGetControllerPath'
        );

        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Enlight_Controller_Dispatcher_ControllerPath_Backend_BrickfoxUi',
            'onGetUiControllerPath'
        );

        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Enlight_Controller_Dispatcher_ControllerPath_Backend_BrickfoxUiLog',
            'onGetUiControllerLogPath'
        );

        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Enlight_Controller_Dispatcher_ControllerPath_Backend_BrickfoxUiErrorCodeList',
            'onGetUiControllerErrorCodeListPath'
        );

        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Enlight_Controller_Action_PostDispatch_Backend_Index',
            'onPostDispatchBackendIndex'
        );

        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Shopware\Models\Article\Article::preUpdate',
            'preUpdateArticle'
        );

        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Shopware\Models\Article\Detail::preUpdate',
            'preUpdateDetail'
        );

        $this->getShopwarePluginBootstrapClass()->subscribeEvent(
            'Shopware\Models\Article\Article::preRemove',
            'preRemoveArticle'
        );
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
