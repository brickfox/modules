<?php
/**
 * MappingMultiShopExport
 *
 * @package   Bf\Multichannel\Components\Gui
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

class MappingMultiShopExport
{
    /**
     * @return array
     */
    final public function getMultiShopExportMappingFieldKeys()
    {
        $shopExportMapping = array();

        $repository    = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop');
        $shopModelList = $repository->findAll();

        if(count($shopModelList) > 0)
        {
            /** @var \Shopware\Models\Shop\Shop $shop */
            foreach($shopModelList as $shop)
            {
                $shopExportMapping[] = array(
                    'shopName' => $shop->getName(),
                    'shopId'   => $shop->getId()
                );
            }
        }

        return $shopExportMapping;
    }
}
