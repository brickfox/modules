<?php
/**
 * MappingTranslation
 *
 * @package   Bf\Saleschannel\Components\Gui
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

class MappingTranslation
{
    /**
     * @return array
     */
    public function getTranslationMappingFieldKeys()
    {
        $isoCodes = array();

        $repository = Shopware()->Models()->getRepository('Shopware\Models\Shop\Locale');
        /** @var \Shopware\Models\Shop\Locale $localModel */
        $localeModel = $repository->findAll();

        if(count($localeModel) > 0)
        {
            foreach($this->getShopwareIsoCodes($localeModel) as $isoCode => $LanguageTerritory)
            {
                $isoCodes[] = array(
                    'shopwareFieldKeyCode' => $isoCode,
                    'shopwareFieldKeyName' => $LanguageTerritory
                );
            }
        }

        return $isoCodes;
    }

    /**
     * @param array $localeModel
     *
     * @return \Generator
     */
    private function getShopwareIsoCodes(array $localeModel)
    {
        $shopwareIsoCode = array();

        /** @var \Shopware\Models\Shop\Locale $locale */
        foreach($localeModel as $locale)
        {
            $shopwareIsoCode[$locale->getLocale()] = $locale->getLanguage() . '/' . $locale->getTerritory();
        }

        return $shopwareIsoCode;
    }
}
