<?php
/**
 * GuiOverview
 *
 * @package   Bf\Multichannel\Components\Gui
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

use Exception;

class GuiOverview
{
    const NO_INFORMATION                             = 'No information from the system';
    const DROP_DOWN_YES                              = 'Ja';
    const DROP_DOWN_NO                               = 'Nein';
    const DROP_DOWN_PSEUDO_PRICE_IGNORE              = 'Pseudopreis wird ignoriert';
    const DROP_DOWN_PSEUDO_PRICE_EQUAL_SPECIAL_PRICE = 'Pseudopreis wird als Sonderpreis übertragen';
    const DROP_DOWN_PSEUDO_PRCIE_EQUAL_RRP           = 'Pseudopreis wird als UVP übertragen';
    const PSEUDO_PRICE_IGNORE_CODE                   = 'IGNORE';
    const PSEUDO_PRICE_EQUAL_SPECIAL_PRICE_CODE      = 'EQUAL_SPECIAL_PRICE';
    const PSEUDO_PRICE_EQUAL_RRP_PRICE_CODE          = 'EQUAL_RRP';
    const UNKNOWN_IMPORT_EXPORT_TIME                 = 'Nicht bekannt';

    /**
     * @return string
     */
    public function getPhpVersion()
    {
        return PHP_VERSION;
    }

    /**
     * @return string
     */
    public function getMemoryLimit()
    {
        try {
            $returnValue = ini_get('memory_limit');
        } catch (Exception $e) {
            $returnValue = self::NO_INFORMATION;
        }

        return $returnValue;
    }

    /**
     * @return string
     */
    public function getMaxExecutionTime()
    {
        try {
            $returnValue = ini_get('max_execution_time');
        } catch (Exception $e) {
            $returnValue = self::NO_INFORMATION;
        }

        return $returnValue;
    }

    /**
     * @return array
     */
    public function convertPluginConfigurationForOverviewDisplayFields()
    {
        $pluginConfigurationClass = new PluginConfigurations();
        $configuration            = $pluginConfigurationClass->load();

        try {
            if (isset($configuration['logging']) === true) {
                switch ($configuration['logging']) {
                    case 'true':
                        $configuration['logging'] = self::DROP_DOWN_YES;
                        break;

                    case 'false':
                        $configuration['logging'] = self::DROP_DOWN_NO;
                        break;

                    default:
                        break;
                }
            }

            if (isset($configuration['rrpSpecialPrice']) === true) {
                switch ($configuration['rrpSpecialPrice']) {
                    case self::PSEUDO_PRICE_IGNORE_CODE:
                        $configuration['rrpSpecialPrice'] = self::DROP_DOWN_PSEUDO_PRICE_IGNORE;
                        break;

                    case self::PSEUDO_PRICE_EQUAL_RRP_PRICE_CODE:
                        $configuration['rrpSpecialPrice'] = self::DROP_DOWN_PSEUDO_PRCIE_EQUAL_RRP;
                        break;

                    case self::PSEUDO_PRICE_EQUAL_SPECIAL_PRICE_CODE:
                        $configuration['rrpSpecialPrice'] = self::DROP_DOWN_PSEUDO_PRICE_EQUAL_SPECIAL_PRICE;
                        break;

                    default:
                        break;
                }
            }

            if (isset($configuration['ftpSslActive']) === true && $configuration['ftpSslActive'] === '1') {
                $configuration['ftpSslActive'] = 'Ja';
            } elseif (isset($configuration['ftpSslActive']) === true && $configuration['ftpSslActive'] === '0') {
                $configuration['ftpSslActive'] = 'Nein';
            }

            if (isset($configuration['attributesMultiSelectId']) == true) {
                $configuration['exportAttributesAsBulletsDescriptions'] = '';
                $lastKey                                                = null;

                if (
                    is_array($configuration['attributesMultiSelectId']) &&
                    count($configuration['attributesMultiSelectId']) > 0
                ) {
                    $elements = array_keys($configuration['attributesMultiSelectId']);
                    $lastKey = end($elements);

                    foreach ($configuration['attributesMultiSelectId'] as $key => $value) {
                        if ($key == $lastKey) {
                            $configuration['exportAttributesAsBulletsDescriptions'] .= $value;
                        } else {
                            $configuration['exportAttributesAsBulletsDescriptions'] .= $value . ' , ';
                        }
                    }
                }
            }

            if(isset($configuration['invoiceDocumentType']) === true) {
                $pluginConfigurationClass    = new PluginConfigurations();
                $documentsTypes = $pluginConfigurationClass->getDocumentsTypes();
                if(isset($documentsTypes[$configuration['invoiceDocumentType']]) === true) {
                    $configuration['invoiceDocumentType'] = $documentsTypes[$configuration['invoiceDocumentType']];
                }
            }

            if(isset($configuration['shopsInformationCommentField']) === true) {
                $commentFields = (new PluginConfigurations())->getCommentFieldDropDown();
                if(isset($commentFields[$configuration['shopsInformationCommentField']]) === true) {
                    $configuration['shopsInformationCommentField'] = $commentFields[$configuration['shopsInformationCommentField']]['commentFieldDescription'];
                }
            }

            if(isset($configuration['orderNumberInCommentField']) === true) {
                $commentFields = (new PluginConfigurations())->getCommentFieldDropDown();
                if(isset($commentFields[$configuration['orderNumberInCommentField']]) === true) {
                    $configuration['orderNumberInCommentField'] = $commentFields[$configuration['orderNumberInCommentField']]['commentFieldDescription'];
                }
            }

            $configuration['exportOrderLineStatus'] = !empty($configuration['exportOrderLineStatus']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['orderStatusExportUsesPickware'] = !empty($configuration['orderStatusExportUsesPickware']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['proFtpActive'] = !empty($configuration['proFtpActive']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['useExternOrdersNumberAsShopwareOrdersNumber'] = !empty($configuration['useExternOrdersNumberAsShopwareOrdersNumber']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['isIncreaseInnoDBLockWaitTimeoutEnabled'] = !empty($configuration['isIncreaseInnoDBLockWaitTimeoutEnabled']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['serverProtocol'] = !empty($configuration['serverProtocol']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['multiShopExport'] = !empty($configuration['multiShopExport']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['multiLanguagesExport'] = !empty($configuration['multiLanguagesExport']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['exportMultivaluedPropertiesAsSingleAttributes'] = !empty($configuration['exportMultivaluedPropertiesAsSingleAttributes']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['enableShopsOrderIdToComment'] = !empty($configuration['enableShopsOrderIdToComment']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['skipArticlesWithoutVariations'] = !empty($configuration['skipArticlesWithoutVariations']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['enableShopsNameToComment'] = !empty($configuration['enableShopsNameToComment']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['enableShopsCustomerIdToComment'] = !empty($configuration['enableShopsCustomerIdToComment']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['orderDisablePartnerImport'] = !empty($configuration['orderDisablePartnerImport']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['orderPartnerIdIncludeSalesChannelName'] = !empty($configuration['orderPartnerIdIncludeSalesChannelName']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['mappingActionToScriptTimeLimit'] = !empty($configuration['mappingActionToScriptTimeLimit']) ? $configuration['mappingActionToScriptTimeLimit'] : '';
            $configuration['orderCarrierColumnNameMain'] = !empty($configuration['orderCarrierColumnNameMain']) ? $configuration['orderCarrierColumnNameMain'] : '';
            $configuration['orderTrackingIdColumnNameMain'] = !empty($configuration['orderTrackingIdColumnNameMain']) ? $configuration['orderTrackingIdColumnNameMain'] : '';
            $configuration['baseProductExportPreviewImageAlways'] = !empty($configuration['baseProductExportPreviewImageAlways']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['enableOrderImportWithItemNumber'] = !empty($configuration['enableOrderImportWithItemNumber']) ? self::DROP_DOWN_YES : self::DROP_DOWN_NO;
            $configuration['orderStatusForOrdersWithComment'] = !empty($configuration['orderStatusForOrdersWithComment']) ? $configuration['orderStatusForOrdersWithComment'] : '';
            $configuration['usePickwareCompability'] = !empty($configuration['usePickwareCompability']) ? $configuration['usePickwareCompability'] : '';

        } catch (\Throwable $e){
            echo '<pre>';
            print_r($e->getTraceAsString());
            echo '</pre>';
        }

        return $configuration;
    }

    /**
     * @param $scriptName
     *
     * @return mixed
     */
    final public function getLastImportExportTimeFromScriptLoggerByScriptName($scriptName)
    {
        $returnValue = self::UNKNOWN_IMPORT_EXPORT_TIME;

        if (strlen($scriptName) > 0) {
            $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\Scriptlogger');

            /** @var \Shopware\CustomModels\BfMultichannel\Scriptlogger $model */
            $model = $repository->findOneBy(
                array('scriptName' => $scriptName),
                array('id' => 'DESC')
            );

            if ($model !== null) {
                if ($model->getDateEnd() !== null) {
                    $returnValue = $model->getDateEnd();
                    $returnValue = $returnValue->format('d-m-Y H:i:s');
                }
            }
        }

        return $returnValue;
    }
}
