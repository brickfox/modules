<?php
/**
 * MappingOrdersToShops.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2018 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

class MappingOrdersToShops
{
    /**
     * @return array
     */
    public function getOrdersToShopsMapping()
    {
        $sCoreShops = array();

        /** @var \Shopware\Components\Model\ModelManager $modelManager */
        $modelManager = Shopware()->Container()->get('models');
        $repository = $modelManager->getRepository('Shopware\Models\Shop\Shop');
        $sCoreShopsModel = $repository->findAll();

        if (count($sCoreShopsModel) > 0) {
            /** @var \Shopware\Models\Shop\Shop $sCoreShop */
            foreach ($sCoreShopsModel as $sCoreShop) {
                $sCoreShops[] = array(
                    'shopwareFieldKeyCode' => $sCoreShop->getId(),
                    'shopwareFieldKeyName' => $sCoreShop->getName()
                );
            }
        }

        return $sCoreShops;
    }
}