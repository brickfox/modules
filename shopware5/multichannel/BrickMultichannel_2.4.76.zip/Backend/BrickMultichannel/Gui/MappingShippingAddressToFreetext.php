<?php
/**
 * MappingShippingAddressToFreetext.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2021 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

use Bf\Multichannel\Components\Util\ShopwareAddressFields;

class MappingShippingAddressToFreetext
{
    /**
     * @return array
     */
    final public function getMappingShopwareShippingAddressFields()
    {
        return ShopwareAddressFields::getShopwareAddressFieldsList('shipping');
    }

    /**
     * @return array
     */
    public function getFreetextfields()
    {
        $userAttributes = [];

        /** @var \Shopware\Components\Model\ModelManager $modelManager */
        $modelManager = Shopware()->Container()->get('models');
        $repository = $modelManager->getRepository('Shopware\Models\Attribute\Configuration');
        $userAttributesList = $repository->findBy(['tableName' => 's_order_shippingaddress_attributes']);

        /** @var \Shopware\Models\Attribute\Configuration $userAttributes */
        foreach ($userAttributesList as $userAttribute) {
            $userAttributes[] = [
                'freetextFieldId' => $userAttribute->getId(),
                'columnName' => $userAttribute->getColumnName(),
                'label' => $userAttribute->getLabel()
            ];
        }

        return $userAttributes;
    }
}