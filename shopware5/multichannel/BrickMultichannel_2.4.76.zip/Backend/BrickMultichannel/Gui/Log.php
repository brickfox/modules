<?php
/**
 * Log
 *
 * @package   Bf\Saleschannel\Components\Gui
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

use Bf\Multichannel\Components\Util\FileManager;

class Log
{
    private $logType = null;
    /** @var int */
    private $start = 0;

    /** @var int */
    private $limit = 25;
    private $filter = null;
    private $sort = null;
    private $orderBy = null;

    /**
     * @param        $logType
     * @param        $start
     * @param        $limit
     * @param null   $filter
     * @param string $sort
     * @param string $orderBy
     */
    public function __construct($logType, $start, $limit, $filter = null, $sort = 'desc', $orderBy = 'process_date')
    {
        $this->logType = $logType;
        $this->start   = $start;
        $this->limit   = $limit;
        $this->filter  = $filter;
        $this->sort    = $sort;
        $this->orderBy = $orderBy;
    }

    /**
     * @return array
     */
    public function prepareLogList()
    {
        $filterQueryPart = '';

        if($this->getFilter() !== null)
        {
            $filterQueryPart .= "
                and (
                        bael.error_code like '%" . $this->getFilter() . "%'
                        or bael.message like '%" . $this->getFilter() . "%'
                        or bael.last_update like '%" . $this->getFilter() . "%'
                        or bael.identifier like '%" . $this->getFilter() . "%'
                )
            ";
        }

        $list = Shopware()->Db()->fetchAll(
            "
            select bael.identifier, bael.error_code, bael.message, bael.last_update
            from bf_api_export_log bael
            where bael.export_type = ?
            " . $filterQueryPart . "
            order by
            bael." . $this->getOrderBy() . " " . $this->getSort() . "
            limit " . $this->getStart() . "," . $this->getLimit(),
            array($this->getLogType())
        );

        $total = $this->getTotalLogCount($filterQueryPart, $this->getLogType());

        foreach($list as $key => $listElement)
        {
            $list[$key]['errorMessageShort'] = '-';
            $list[$key]['error_message']     = '';

            if(strlen($listElement['message']) > 0)
            {
                $list[$key]['errorMessageShort'] = mb_substr($listElement['message'], 0, 150) . '...';
                $list[$key]['error_message']     = $listElement['message'];
            }

            if(strlen($listElement['error_code']) <= 0)
            {
                $list[$key]['error_code'] = '-';
            }

            if(strlen($listElement['export_type']) > 0)
            {
                $list[$key]['export_type'] = $this->createCorrectExportType($listElement['export_type']);
            }
        }

        return array(
            'count' => $total,
            'data'  => $list
        );
    }

    /**
     * @param $filterQueryPart
     * @param $logType
     *
     * @return string
     */
    private function getTotalLogCount($filterQueryPart, $logType)
    {
        $count = Shopware()->Db()->fetchOne(
            "
                select count(bael.id) AS 'total'
                from bf_api_export_log bael
                where bael.export_type = ?
                " . $filterQueryPart . "
            ",
            array($logType)
        );

        return $count;
    }

    /**
     * @param $exportType
     *
     * @return string
     */
    private function createCorrectExportType($exportType)
    {
        $exportTypeName = '';

        switch($exportType)
        {
            case FileManager::FILENAME_BASE_CATEGORIES:
                $exportTypeName = 'Kategorien';
                break;

            case FileManager::FILENAME_BASE_MANUFACTURERS:
                $exportTypeName = 'Hersteller';
                break;

            case FileManager::FILENAME_BASE_PRODUCTS:
                $exportTypeName = 'Produkte';
                break;

            case FileManager::FILENAME_BASE_PRODUCTS_ASSIGNMENTS:
                $exportTypeName = 'Produkt Verknüpfungen';
                break;

            case FileManager::FILENAME_BASE_ORDERS_STATUS:
                $exportTypeName = 'Bestellstatus';
                break;

            case FileManager::FILENAME_BASE_PRODUCTS_DELETE:
                $exportTypeName = 'Produkte löschen';
                break;

            case FileManager::FILENAME_BASE_ORDERS:
                $exportTypeName = 'Bestellungen';
                break;

            default:
                break;
        }

        return $exportTypeName;
    }

    /**
     * @return null
     */
    public function getLogType()
    {
        return $this->logType;
    }

    /**
     * @param null $logType
     *
     * @return Log
     */
    public function setLogType($logType)
    {
        $this->logType = $logType;

        return $this;
    }

    /**
     * @return int
     */
    public function getStart()
    {
        return $this->start;
    }

    /**
     * @param int $start
     *
     * @return Log
     */
    public function setStart($start)
    {
        $this->start = $start;

        return $this;
    }

    /**
     * @return int
     */
    public function getLimit()
    {
        return $this->limit;
    }

    /**
     * @param int $limit
     *
     * @return Log
     */
    public function setLimit($limit)
    {
        $this->limit = $limit;

        return $this;
    }

    /**
     * @return null
     */
    public function getFilter()
    {
        return $this->filter;
    }

    /**
     * @param null $filter
     *
     * @return Log
     */
    public function setFilter($filter)
    {
        $this->filter = $filter;

        return $this;
    }

    /**
     * @return null
     */
    public function getSort()
    {
        return $this->sort;
    }

    /**
     * @param null $sort
     *
     * @return Log
     */
    public function setSort($sort)
    {
        $this->sort = $sort;

        return $this;
    }

    /**
     * @return null
     */
    public function getOrderBy()
    {
        return $this->orderBy;
    }

    /**
     * @param null $orderBy
     *
     * @return Log
     */
    public function setOrderBy($orderBy)
    {
        $this->orderBy = $orderBy;

        return $this;
    }

    public function __destruct()
    {
        $this->logType = null;
    }
}
