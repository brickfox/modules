<?php
/**
 * MappingPayment
 *
 * @package   Bf\Multichannel\Components\Gui
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

class MappingPayment
{
    /**
     * @return array
     */
    final public function getPaymentStateMappingFieldKeys()
    {
        $states = array();

        $repository      = Shopware()->Models()->getRepository('Shopware\Models\Order\Status');
        $statesModelList = $repository->findBy(array('group' => \Shopware\Models\Order\Status::GROUP_PAYMENT));

        if(count($statesModelList) > 0)
        {
            $prop = 'getDescription';

            /** @var \Shopware\Models\Order\Status $state */
            foreach($statesModelList as $state)
            {
                if (method_exists($state, $prop) === false) {
                    $prop = 'getName';
                }

                $states[] = array(
                    'shopwareFieldKeyCode' => $state->getId(),
                    'shopwareFieldKeyName' => $state->$prop()
                );
            }
        }

        return $states;
    }
}
