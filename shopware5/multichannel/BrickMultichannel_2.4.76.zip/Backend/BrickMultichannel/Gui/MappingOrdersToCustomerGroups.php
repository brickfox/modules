<?php
/**
 * MappingOrdersToShops.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2018 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

class MappingOrdersToCustomerGroups
{
    /**
     * @return array
     */
    public function getOrdersToCustomerGroupsMapping()
    {
        $sCoreCustomerGroups = array();

        /** @var \Shopware\Components\Model\ModelManager $modelManager */
        $modelManager = Shopware()->Container()->get('models');
        $repository = $modelManager->getRepository('Shopware\Models\Customer\Group');
        $sCoreShopsModel = $repository->findAll();

        if (count($sCoreShopsModel) > 0) {
            /** @var \Shopware\Models\Customer\Group $sCoreCustomerGroup */
            foreach ($sCoreShopsModel as $sCoreCustomerGroup) {
                $sCoreCustomerGroups[] = array(
                    'shopwareFieldKeyCode' => $sCoreCustomerGroup->getId(),
                    'shopwareFieldKeyName' => $sCoreCustomerGroup->getName()
                );
            }
        }

        return $sCoreCustomerGroups;
    }
}