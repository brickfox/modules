<?php
/**
 * PluginConfigurations
 *
 * @package   Bf\Multichannel\Components\Gui
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

use Bf\Multichannel\Components\Interfaces\GuiInterface;
use Bf\Multichannel\Components\Util\FtpAbstract;
use Bf\Multichannel\Components\Util\LogCodes;
use Bf\Multichannel\Components\Util\LogManager;
use Exception;
use Shopware\CustomModels\BfMultichannel\Configuration;
use stdClass;

class PluginConfigurations implements GuiInterface
{
    /**
     * @param stdClass $configuration
     *
     * @return bool
     */
    public function save($configuration)
    {
        $returnValue          = true;
        $configurationEntries = '';

        try {
            if ($this->getIsMultiShop() === false) {
                if (property_exists($configuration, FtpAbstract::CONFIGURATION_KEY_SSL_ACTIVE) === false) {
                    $configuration->ftpSslActive = '0';
                }
            } else {
                foreach ($this->getMultiShops() as $shops) {
                    foreach ($shops as $shopsData) {
                        if (property_exists($configuration, FtpAbstract::CONFIGURATION_KEY_SSL_ACTIVE . '_' . $shopsData['shopsId']) === false) {
                            $propertyName = FtpAbstract::CONFIGURATION_KEY_SSL_ACTIVE . '_' . $shopsData['shopsId'];

                            $configuration->$propertyName = '0';
                        }
                    }
                }
            }

            if (property_exists($configuration, 'orderStatusExportUsesPickware') === false) {
                $configuration->orderStatusExportUsesPickware = '0';
            }

            if (property_exists($configuration, 'exportOrderLineStatus') === false) {
                $configuration->exportOrderLineStatus = '0';
            }

            if (property_exists($configuration, 'proFtpActive') === false) {
                $configuration->proFtpActive = '0';
            }

            if (property_exists($configuration, 'useExternOrdersNumberAsShopwareOrdersNumber') === false) {
                $configuration->useExternOrdersNumberAsShopwareOrdersNumber = '0';
            }

            if (property_exists($configuration, 'multiShopExport') === false) {
                $configuration->multiShopExport = '0';
            }

            if (property_exists($configuration,'multiLanguagesExport') === false) {
                $configuration->multiLanguagesExport = '0';
            }

            if (property_exists($configuration, 'exportMultivaluedPropertiesAsSingleAttributes') === false) {
                $configuration->exportMultivaluedPropertiesAsSingleAttributes = '0';
            }

            if (property_exists($configuration, 'serverProtocol') === false) {
                $configuration->serverProtocol = '0';
            }

            if (property_exists($configuration, 'isIncreaseInnoDBLockWaitTimeoutEnabled') === false) {
                $configuration->isIncreaseInnoDBLockWaitTimeoutEnabled = '0';
            }

            if (property_exists($configuration, 'skipArticlesWithoutVariations') === false) {
                $configuration->skipArticlesWithoutVariations = '0';
            }

            if (property_exists($configuration, 'orderDisablePartnerImport') === false) {
                $configuration->orderDisablePartnerImport = '0';
            }

            if (property_exists($configuration, 'baseProductExportPreviewImageAlways') === false) {
                $configuration->baseProductExportPreviewImageAlways = '0';
            }

            if (property_exists($configuration, 'orderPartnerIdIncludeSalesChannelName') === false) {
                $configuration->orderPartnerIdIncludeSalesChannelName = '0';
            }

            if (property_exists($configuration, 'usePickwareCompability') === false) {
                $configuration->usePickwareCompability = '0';
            }

            if (property_exists($configuration, 'enableOrderImportWithItemNumber') === false) {
                $configuration->enableOrderImportWithItemNumber = '0';
            }

            if (property_exists($configuration, 'orderStatusForOrdersWithComment') === false) {
                $configuration->orderStatusForOrdersWithComment = '';
            }

            if (property_exists($configuration, 'importedOrderStatus') === false) {
                $configuration->importedOrderStatus = '';
            }

            foreach ($configuration as $key => $value) {
                if ($key === 'attributesMultiSelectId') {
                    $value = implode(',', $value);
                }

                if (strlen($key) > 0) {
                    $repository         = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\Configuration');
                    $configurationModel = $repository->findOneBy(array('configurationKey' => $key));

                    if ($configurationModel === null) {
                        $configurationModel = new Configuration();
                        $configurationModel->setConfigurationKey($key);
                    }

                    $configurationModel->setConfigurationValue($value);

                    if ($value === end($configuration)) {
                        $configurationEntries .= $key . ' = ' . $value;
                    } else {
                        $configurationEntries .= $key . ' = ' . $value . ', ';
                    }

                    Shopware()->Models()->persist($configurationModel);
                    Shopware()->Models()->flush();
                    Shopware()->Models()->clear();
                }
            }

            LogManager::getInstance()->createConfigurationLogEntry('', str_replace('{$configurationEntries}', $configurationEntries, LogCodes::SAVE_CONFIGURATION_SUCCESSFUL));
        } catch (\Throwable $e) {
            LogManager::getInstance()->createConfigurationLogEntry($e->getCode(), $e->getMessage(), LogManager::LOG_TYPE_ERROR);
            $returnValue = false;
        }

        return $returnValue;
    }

    /**
     * @param int $start
     * @param int $limit
     * @param null $filter
     * @param string $modelNamespace
     *
     * @return array
     */
    public function load($start = 0, $limit = 25, $filter = null, $modelNamespace = '')
    {
        $returnValue = array(
            'error' => false
        );

        try {
            $repository             = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\Configuration');
            $configurationModelList = $repository->findAll();

            if (count($configurationModelList) > 0) {
                /** @var \Shopware\CustomModels\BfMultichannel\Configuration $configuration */
                foreach ($configurationModelList as $configuration) {
                    $returnValue[$configuration->getConfigurationKey()] = $configuration->getConfigurationValue();
                }
            }
        } catch (Exception $e) {
            LogManager::getInstance()->createConfigurationLogEntry($e->getCode(), $e->getMessage(), LogManager::LOG_TYPE_ERROR);
        }

        return $returnValue;
    }

    /**
     * @return array
     */
    final public function getYesOrNoDropDownContent()
    {
        return array(array('logging' => 'true', 'name' => GuiOverview::DROP_DOWN_YES), array('logging' => 'false', 'name' => GuiOverview::DROP_DOWN_NO));
    }

    /**
     * @return array
     */
    final public function getCustomerGroupsList()
    {
        $customerGroups = array();

        $repository          = Shopware()->Models()->getRepository('Shopware\Models\Customer\Group');
        $customerGroupsModel = $repository->findAll();

        if (count($customerGroupsModel) > 0) {
            /** @var \Shopware\Models\Customer\Group $customerGroup */
            foreach ($customerGroupsModel as $customerGroup) {
                $customerGroups[] = array(
                    'defaultCustomerGroupKey' => $customerGroup->getKey(),
                    'defaultCustomerGroup'    => $customerGroup->getName()
                );
            }
        }

        return $customerGroups;
    }

    /**
     * @return array
     */
    final public function getPseudoPriceDropDownContent()
    {
        return array(
            array('rrpSpecialPrice' => GuiOverview::PSEUDO_PRICE_IGNORE_CODE, 'name' => GuiOverview::DROP_DOWN_PSEUDO_PRICE_IGNORE),
            array('rrpSpecialPrice' => GuiOverview::PSEUDO_PRICE_EQUAL_RRP_PRICE_CODE, 'name' => GuiOverview::DROP_DOWN_PSEUDO_PRCIE_EQUAL_RRP),
            array('rrpSpecialPrice' => GuiOverview::PSEUDO_PRICE_EQUAL_SPECIAL_PRICE_CODE, 'name' => GuiOverview::DROP_DOWN_PSEUDO_PRICE_EQUAL_SPECIAL_PRICE)
        );
    }

    final public function installDefaultPluginConfiguration()
    {
        try {
            Shopware()->Db()->query("
                    INSERT INTO bf_configuration (`configuration_key`, `configuration_value`)
                    VALUES
                      ('incomingPath', 'uploads/brickfox/in/'),
                      ('outgoingPath', 'uploads/brickfox/out/'),
                      ('logging', 'true'),
                      ('logPath', 'uploads/brickfox/logs/'),
                      ('masterShopName', ''),
                      ('brickfoxCustomerUrl', ''),
                      ('brickfoxApiKey', ''),
                      ('rrpSpecialPrice', 'IGNORE'),
                      ('disabledCategories', '-'),
                      ('defaultCustomerGroup', 'EK'),
                      ('ftpHost', ''),
                      ('ftpUser', ''),
                      ('ftpPassword', ''),
                      ('ftpSslActive', '0'),
                      ('ftpPort', '21'),
                      ('ftpOrdersPath', '/outgoing'),
                      ('imageAttributesKeyWords', ''),
                      ('useExternOrdersNumberAsShopwareOrdersNumber', 'true'),
                      ('scriptLogger', '4'),
                      ('productsExportAttributes', ''),
                      ('configurationValue', ''),
                      ('attributesMultiSelectId', ''),
                      ('bulletsAsAttributesMultiSelectId', ''),
                      ('multiShopExport', 'false'),
                      ('serverProtocol', 'false'),
                      ('isIncreaseInnoDBLockWaitTimeoutEnabled', 'true'),
                      ('multiLanguagesExport', 'false'),
                      ('exportMultivaluedPropertiesAsSingleAttributes', '0'),
                      ('orderAttributes', ''),
                      ('proFtpActive', '0'),
                      ('exportOrderLineStatus', '1'),
                      ('customerOrderNumberAttributesField', ''),
                      ('orderAttributesFieldReturnTrackingId', ''),
                      ('cleanBfScriptloggerAfterDays', '14'),
                      ('invoiceDocumentType', '1'),
                      ('invoiceFolderPath', ''),
                      ('enableShopsOrderIdToComment', '0'),
                      ('shopsInformationCommentField', ''),
                      ('orderNumberInCommentField', ''),
                      ('isbnFromAttribute', ''),
                      ('skipArticlesWithoutVariations', '0'),
                      ('enableShopsNameToComment', '0'),
                      ('enableShopsCustomerIdToComment', '0'),
                      ('orderDisablePartnerImport', '0'),
                      ('orderPartnerIdIncludeSalesChannelName', '0'),
                      ('orderCarrierColumnName', ''),
                      ('orderTrackingIdColumnName', ''),
                      ('mappingActionToScriptTimeLimit', ''),
                      ('customergroupTaxRate', ''),
                      ('importedOrderStatus', '0'),
                      ('orderStatusExportUsesPickware', '0'),
                      ('orderCarrierColumnNameMain', ''),
                      ('orderTrackingIdColumnNameMain', ''),
                      ('baseProductExportPreviewImageAlways', '0'),
                      ('enableOrderImportWithItemNumber', '0'),
                      ('orderStatusForOrdersWithComment', ''),
                      ('usePickwareCompability', '0')
                ");

            Shopware()->Db()->query(
                "
                    INSERT INTO bf_mapping_order_status (`brickfox_order_status_code`, `shopwareID`)
                    VALUES
                    ('Pending', 1),
                    ('Shipped', 2),
                    ('Cancelled', 4),
                    ('ReadyForShipout', 5),
                    ('PartlyShipped', 6)
                "
            );
        } catch (Exception $e) {
            LogManager::getInstance()->createConfigurationLogEntry($e->getCode(), $e->getMessage(), LogManager::LOG_TYPE_ERROR);
        }
    }

    /**
     * @return bool
     */
    public function getIsMultiShop()
    {
        $isMultiShop = false;

        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\Configuration');
        /** @var \Shopware\CustomModels\BfMultichannel\Configuration $configurationModel */
        $configurationModel = $repository->findOneBy(array('configurationKey' => 'multiShopExport'));

        if ($configurationModel !== null) {
            $isMultiShop = ($configurationModel->getConfigurationValue() == '1') ? true : false;
        }

        return $isMultiShop;
    }

    /**
     * @return array
     */
    public function getMultiShops()
    {
        $multiShops = array();

        $repository        = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\MappingMultiShopExport');
        $multiShopsMapping = $repository->findAll();

        if (count($multiShopsMapping) > 0) {
            /** @var \Shopware\CustomModels\BfMultichannel\MappingMultiShopExport $mappingEntry */
            foreach ($multiShopsMapping as $mappingEntry) {
                $shopsRepository = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop');
                /** @var \Shopware\Models\Shop\Shop $shopModel */
                $shopModel = $shopsRepository->findOneBy(array('id' => $mappingEntry->getMappingFieldKey()));

                if ($shopModel !== null) {
                    $multiShops['shops'][] = array(
                        'shopName' => $shopModel->getName(),
                        'shopsId'  => $mappingEntry->getMappingFieldKey()
                    );
                }
            }
        }

        return $multiShops;
    }

    /**
     * @return array
     */
    public function getAttributesColumnHeaderNames()
    {
        $columnHeaderNames = array();

        $queryResult = Shopware()->Db()->fetchAll("show columns from s_articles_attributes");

        if (count($queryResult) > 0) {
            foreach ($queryResult as $columns) {
                if ($columns['Field'] !== 'id' && $columns['Field'] !== 'articleID' && $columns['Field'] !== 'articledetailsID') {
                    $columnHeaderNames[] = $columns['Field'];
                }
            }
        }

        $repository = Shopware()->Models()->getRepository('Shopware\Models\Property\Option');
        $optionList = $repository->findAll();

        if (count($optionList) > 0) {
            /** @var \Shopware\Models\Property\Option $option */
            foreach ($optionList as $option) {
                $columnHeaderNames[] = $option->getName();
            }
        }

        return $columnHeaderNames;
    }

    /**
     * @param null $deleteItem
     */
    public function delete($deleteItem = null)
    {
    }

    public function getDocumentsTypes() {
        $documentTypes = [];

        $repository = Shopware()->Models()->getRepository('Shopware\Models\Document\Document');
        $documents  = $repository->findAll();

        if (count($documents) > 0) {
            /** @var \Shopware\Models\Document\Document $document */
            foreach ($documents as $document) {
                $documentTypes[$document->getId()] = $document->getName();
            }
        }

        return $documentTypes;
    }

    public function getOrderStates() {
        $orderStates = [];

        $states = Shopware()->Db()->query("
            SELECT id, description FROM s_core_states WHERE `group` = 'state' ORDER BY position ASC
        ");

        foreach ($states as $state) {
            $orderStates[$state["id"]] = $state["description"];
        }

        return $orderStates;
    }

    final public function getCommentFieldDropDown() {
        return [
            0 => [
                'commentFieldId'          => '',
                'commentFieldDescription' => ''
            ],
            'internalComment' => [
                'commentFieldId'          => 'internalComment',
                'commentFieldDescription' => 'Interner Kommentar'
            ],
            'customerComment' => [
                'commentFieldId'          => 'customerComment',
                'commentFieldDescription' => 'Kunden-Kommentar'
            ],
            'comment' => [
                'commentFieldId'          => 'comment',
                'commentFieldDescription' => 'Dein Kommentar'
            ]
        ];
    }
}
