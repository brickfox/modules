<?php
/**
 * MappingOrderStatusDetail.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2019 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

class MappingOrderStatusDetail
{
    final public function getMappingOrderStatusCodeBrickFox()
    {
        return array(
            array('brickfoxOrderStatusCode' => 'Pending', 'brickfoxOrderStatusName' => 'In Bearbeitung'),
            array('brickfoxOrderStatusCode' => 'Shipped', 'brickfoxOrderStatusName' => 'Versendet'),
            array('brickfoxOrderStatusCode' => 'Cancelled', 'brickfoxOrderStatusName' => 'Storniert'),
            array('brickfoxOrderStatusCode' => 'ReadyForShipout', 'brickfoxOrderStatusName' => 'Versandbereit'),
            array('brickfoxOrderStatusCode' => 'Returned', 'brickfoxOrderStatusName' => 'Retourniert')
        );
    }

    /**
     * @return array
     */
    final public function getMappingOrderStatusCodeShopware()
    {
        $shopwareStates = [];

        $stateRepository = Shopware()->Models()->getRepository('Shopware\Models\Order\DetailStatus');
        $stateModel      = $stateRepository->findAll();

        /** @var \Shopware\Models\Order\DetailStatus $state */
        foreach ($stateModel as $state) {
            $shopwareStates[] = array(
                'shopwareId'      => $state->getId(),
                'orderStatusName' => $state->getDescription()
            );
        }

        return $shopwareStates;
    }
}