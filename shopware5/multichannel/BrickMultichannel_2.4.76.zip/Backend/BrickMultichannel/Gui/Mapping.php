<?php
/**
 * Mapping
 *
 * @package   Bf\Multichannel\Components\Gui
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

use Bf\Multichannel\Components\Interfaces\GuiInterface;
use Bf\Multichannel\Components\Interfaces\GuiMappingInterface;
use Bf\Multichannel\Components\Util\Curl;
use Bf\Multichannel\Components\Util\Helper;
use Bf\Multichannel\Components\Util\LogCodes;
use Bf\Multichannel\Components\Util\LogManager;
use Doctrine\ORM\AbstractQuery;
use Doctrine\ORM\QueryBuilder;
use Doctrine\ORM\Tools\Pagination\Paginator;
use Exception;

class Mapping implements GuiInterface, GuiMappingInterface
{
    const DO_NOT_SET_UNIQUE_ID_SETTER = 'setId';

    /**
     * @param $saveItem
     *
     * @return bool
     */
    public function save($saveItem)
    {
        $result = false;

        $setter = $this->prepareSavingOneOrModeMappingEntries($saveItem['params'], $saveItem['mappingKeyFields']);
        foreach($setter as $key)
        {
            $model = $this->preLoad($saveItem['mappingModel'], $saveItem['uniqueKey'], $key[$saveItem['uniqueKey']]);

            if($model === null)
            {
                $model = new $saveItem['mappingModel']();
                $this->fromArray($model, $key);
            }
            elseif(is_object($model) === true)
            {
                $this->fromArray($model, $key);
            }

            $result = true;

            LogManager::getInstance()->createConfigurationLogEntry(
                '',
                str_replace(
                    array('{$mappingModel}', '{$key}', '{$values}'),
                    array(get_class($model), implode(',', array_keys($key)), implode(',', $key)),
                    LogCodes::SAVE_MAPPING_SUCCESSFUL
                )
            );
        }

        return $result;
    }

    /**
     * @param $deleteItem
     *
     * @return bool
     */
    public function delete($deleteItem)
    {
        $result = true;

        $setter = $this->prepareSavingOneOrModeMappingEntries($deleteItem['params'], $deleteItem['mappingKeyFields']);

        foreach($setter as $key)
        {
            $model = $this->preLoad($deleteItem['mappingModel'], $deleteItem['uniqueKey'], $key[$deleteItem['uniqueKey']]);

            if($model !== null)
            {
                //to do entries for log gui

                Shopware()->Models()->remove($model);
                Shopware()->Models()->flush($model);
            }
        }

        return $result;
    }

    /**
     * @param int    $start
     * @param int    $limit
     * @param null   $filter
     * @param string $modelNamespace
     *
     * @return array
     */
    public function load($start = 0, $limit = 25, $filter = null, $modelNamespace = '')
    {
        $qb = Shopware()->Models()->createQueryBuilder();
        $qb->select(array('mapping'))->from($modelNamespace, 'mapping');

        if($filter !== null)
        {
            $qb = $this->mappingFilterCondition($qb, $modelNamespace, $filter);
        }

        if((int) $limit !== 0)
        {
            $qb->setFirstResult($start)->setMaxResults($limit);
        }

        $sql = $qb->getQuery()->setHydrationMode(AbstractQuery::HYDRATE_ARRAY);

        $paginator = new Paginator($sql);

        $total = $paginator->count();
        $list  = $paginator->getIterator()->getArrayCopy();

        return array(
            'count' => $total,
            'data'  => $list
        );
    }

    /**
     * @param QueryBuilder $qb
     * @param              $modelNamespace
     * @param              $filter
     *
     * @return mixed
     */
    public function mappingFilterCondition(QueryBuilder $qb, $modelNamespace, $filter)
    {
        //todo for Attributes
    }

    /**
     * @param       $entity
     * @param array $array
     *
     * @return mixed
     */
    public function fromArray($entity, array $array = array())
    {
        //lowers the memory peek
        $conn = Shopware()->Models()->getConnection();
        $conn->getConfiguration()->setSQLLogger(null);

        if(count($array) > 0)
        {
            foreach($array as $methodAlias => $values)
            {
                $setter = ucfirst($methodAlias);
                $setter = 'set' . $setter;

                try
                {
                    if(method_exists($entity, $setter) === true)
                    {
                        if($setter !== self::DO_NOT_SET_UNIQUE_ID_SETTER)
                        {
                            $entity->$setter($values);
                        }
                    }
                }
                catch(Exception $e)
                {
                    LogManager::getInstance()->createConfigurationLogEntry(
                        $e->getCode(),
                        str_replace('{$mappingModel}', get_class($entity), LogCodes::SAVE_MAPPING_ERROR),
                        LogManager::LOG_TYPE_ERROR
                    );
                }
            }

            Shopware()->Models()->persist($entity);
            Shopware()->Models()->flush($entity);
            Shopware()->Models()->clear();
        }
    }

    /**
     * @param        $modelNamespace
     * @param string $uniqueKey
     * @param string $uniqueKeyValue
     *
     * @return null|object
     */
    final private function preLoad($modelNamespace, $uniqueKey = 'id', $uniqueKeyValue = '')
    {
        $repository = Shopware()->Models()->getRepository($modelNamespace);
        $model      = $repository->findOneBy(array($uniqueKey => $uniqueKeyValue));

        return $model;
    }

    /**
     * @param $parameters
     * @param $mappingKeyFields
     *
     * @return array
     */
    public function prepareSavingOneOrModeMappingEntries($parameters, $mappingKeyFields)
    {
        $return = array();

        foreach($mappingKeyFields as $key => $element)
        {
            if(array_key_exists($key, $parameters) === true)
            {
                $return[0][$key] = $parameters[$key];
            }
        }

        if(count($return) <= 0)
        {
            $counter = 0;

            foreach($parameters as $key => $element)
            {
                foreach($element as $index => $value)
                {
                    if(array_key_exists($index, $mappingKeyFields) === true)
                    {
                        $return[$counter][$index] = $value;
                    }
                }
                $counter++;
            }
        }

        return $return;
    }

    /**
     * @param null $restCall
     * @param null $param
     * @param null $mode
     *
     * @return array
     */
    public function getBrickfoxConfigurationMappingFieldKeys($restCall = null, $param = null, $mode = null)
    {
        $result = array();

        if($restCall !== null && $param !== null)
        {
            $curl       = self::getCurlClass($restCall, $param);
            $curlResult = json_decode($curl->get());

            if((int) $curlResult->totalCount !== 0)
            {
                switch($mode)
                {
                    case 'currencies':
                        $configurationValueList = array((string) $curlResult->data[0]->currenciesCode);
                        break;

                    case 'languages':
                        $configurationValueList = array((string) $curlResult->data[0]->code);
                        break;

                    default:
                        $configurationValueList = explode(',', (string) $curlResult->data[0]->configurationValue);
                        break;
                }

                foreach($configurationValueList as $value)
                {
                    $result[] = array(
                        'brickfoxFieldKeyName' => $value,
                        'brickfoxFieldKeyCode' => $value
                    );
                }
            }
        }

        return $result;
    }

    /**
     * @param null $restCall
     * @param null $param
     *
     * @return array
     */
    public function doRestCall($restCall = null, $param = null)
    {
        $result = array();

        if ($restCall !== null) {
            $curl = self::getCurlClass($restCall, $param);
            $curlResult = json_decode($curl->get());

            if ((int) $curlResult->totalCount !== 0) {
                switch ($restCall) {
                    case 'shops/':
                        foreach ($curlResult->data as $data) {
                            $result[] = array('brickfoxFieldKeyName' => $data->shopsName, 'brickfoxFieldKeyCode' => $data->shopsId);
                        }
                        break;
                }
            }
        }

        return $result;
    }

    /**
     * @param null   $restCall
     * @param string $param
     *
     * @return Curl
     */
    final private function getCurlClass($restCall = null, $param = '')
    {
        return new Curl(
            Helper::getConfigurationByKey('brickfoxCustomerUrl')->getConfigurationValue(),
            Helper::getConfigurationByKey('brickfoxApiKey')->getConfigurationValue(),
            $restCall,
            $param
        );
    }
}
