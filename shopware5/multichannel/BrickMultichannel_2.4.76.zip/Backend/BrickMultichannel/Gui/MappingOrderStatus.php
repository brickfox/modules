<?php
/**
 * MappingOrderStatus.php
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2017 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

class MappingOrderStatus
{
    final public function getMappingOrderStatusCodeBrickFox()
    {
        return array(
            array('brickfoxOrderStatusCode' => 'Pending', 'brickfoxOrderStatusName' => 'In Bearbeitung'),
            array('brickfoxOrderStatusCode' => 'Shipped', 'brickfoxOrderStatusName' => 'Versendet'),
            array('brickfoxOrderStatusCode' => 'Cancelled', 'brickfoxOrderStatusName' => 'Storniert'),
            array('brickfoxOrderStatusCode' => 'ReadyForShipout', 'brickfoxOrderStatusName' => 'Versandbereit'),
            array('brickfoxOrderStatusCode' => 'PartlyShipped', 'brickfoxOrderStatusName' => 'Teilversendet'),
            array('brickfoxOrderStatusCode' => 'Returned', 'brickfoxOrderStatusName' => 'Retourniert')
        );
    }

    /**
     * @return array
     */
    final public function getShopwareOrderStatusMapping()
    {
        $shopwareStates = array();

        $stateRepository = Shopware()->Models()->getRepository('Shopware\Models\Order\Status');
        $stateModel      = $stateRepository->findBy(array('group' => \Shopware\Models\Order\Status::GROUP_STATE));

        $snippetRepository = Shopware()->Models()->getRepository('Shopware\Models\Snippet\Snippet');

        $defaultLocale = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop')->getDefault()->getLocale();

        /** @var \Shopware\Models\Order\Status $state */
        foreach ($stateModel as $state) {
            $snippetModel = $snippetRepository->findOneBy(array('namespace' => 'backend/static/order_status', 'localeId' => $defaultLocale->getId(), 'name' => $state->getName()));

            if ($snippetModel !== null) {
                $shopwareStates[] = array(
                    'shopwareId'   => $state->getId(),
                    'orderStatusName' => $snippetModel->getValue()
                );
            }
        }

        return $shopwareStates;
    }
}