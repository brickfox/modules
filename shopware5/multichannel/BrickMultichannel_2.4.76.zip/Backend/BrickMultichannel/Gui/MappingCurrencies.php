<?php
/**
 * MappingCurrencies
 *
 * @package   Bf\Saleschannel\Components\Gui
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

class MappingCurrencies
{
    /**
     * @return array
     */
    final public function getCurrenciesMappingFieldKeys()
    {
        $customerGroups = array();

        $repository         = Shopware()->Models()->getRepository('Shopware\Models\Customer\Group');
        $customerGroupModel = $repository->findAll();

        if(count($customerGroupModel) > 0)
        {
            foreach($customerGroupModel as $element)
            {
                $customerGroups[] = array(
                    'shopwareFieldKeyCode' => $element->getKey(),
                    'shopwareFieldKeyName' => $element->getName()
                );
            }
        }

        return $customerGroups;
    }

    /**
     * @return array
     */
    final public function getIsNetMapping()
    {
        return array(
            array('isNetFieldKeyCode' => 'N', 'isNetFieldKeyName' => 'Netto'),
            array('isNetFieldKeyCode' => 'B', 'isNetFieldKeyName' => 'Brutto')
        );
    }
}
