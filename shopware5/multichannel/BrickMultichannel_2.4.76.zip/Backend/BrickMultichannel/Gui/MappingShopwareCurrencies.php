<?php
/**
 * MappingShopwareCurrencies
 *
 * @package   Bf\Saleschannel\Components\Gui
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2019 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

class MappingShopwareCurrencies
{
    /**
     * @return array
     */
    final public function getShopwareCurrenciesMappingFieldKeys()
    {
        $currencies = [];

        $repository      = Shopware()->Models()->getRepository('Shopware\Models\Shop\Currency');
        $currenciesModel = $repository->findAll();

        if (count($currenciesModel) > 0) {
            foreach ($currenciesModel as $element) {
                $currencies[] = [
                    'shopwareFieldKeyCode' => $element->getCurrency(),
                    'shopwareFieldKeyName' => $element->getName()
                ];
            }
        }

        return $currencies;
    }
}