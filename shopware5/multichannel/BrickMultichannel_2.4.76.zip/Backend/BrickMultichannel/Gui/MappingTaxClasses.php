<?php

/**
 * MappingTaxClasses
 *
 * @package   Bf\Saleschannel\Components\Gui
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2020 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Gui;

class MappingTaxClasses
{
    /** @var array */
    private $classConfig = [['key' => 'Regelsteuersatz','value' => 'standard'],['key' => 'Reduzierter Steuersatz','value' => 'reduced']];

    /**
     * @return array
     */
    public function getShopwareTaxRatesMappingFieldKeys()
    {
        $taxes = [];

        $repository = Shopware()->Models()->getRepository('Shopware\Models\Tax\Tax');
        /** @var \Shopware\Models\Tax\Tax $localModel */
        $taxModels = $repository->findAll();

        if (count($taxModels) > 0) {
            foreach ($this->getShopwareTaxRates($taxModels) as $id => $description) {
                $taxes[] = [
                    'shopwareFieldKeyCode' => $id,
                    'shopwareFieldKeyName' => $description
                ];
            }
        }

        return $taxes;
    }

    /**
     * @param array $taxModels
     * @return array
     */
    private function getShopwareTaxRates(array $taxModels)
    {
        $taxMapping = [];

        /** @var \Shopware\Models\Tax\Tax $tax */
        foreach ($taxModels as $tax) {
            $taxMapping[$tax->getId()] = $tax->getName();
        }

        return $taxMapping;
    }

    /**
     * @return array
     */
    public function getBrickfoxTaxCategoriesMappingFieldKeys()
    {
        $classes = [];

        foreach ($this->classConfig as $config) {
            $classes[] = [
                'brickfoxFieldKeyCode' => $config['value'],
                'brickfoxFieldKeyName' => $config['key']
            ];
        }

        return $classes;
    }
}