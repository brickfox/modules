<?php
/**
 * CreateDatabase
 *
 * @package   Bf\Saleschannel\Install
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Install;

use Bf\Multichannel\Components\Gui\PluginConfigurations as PluginConfigurations;
use Doctrine\ORM\Tools\SchemaTool as SchemaTool;

class CreateDatabase extends InstallAbstract
{
    /**
     * @param \Shopware_Components_Plugin_Bootstrap $shopwarePluginBootstrapClass
     */
    public function __construct($shopwarePluginBootstrapClass)
    {
        parent::__construct($shopwarePluginBootstrapClass);
    }

    public function executeCreateDatabase()
    {
        $modelManager = Shopware()->Models();
        $schemaTool   = new SchemaTool($modelManager);
        $schemaTool->createSchema(
            array(
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\Scriptlogger'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\Configuration'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\ApiExportProducts'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingTranslation'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingCurrencies'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\ApiExportMedia'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\ApiImportOrders'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\ExportOrderStatus'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\ApiExportLog'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\ApiGuiLog'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingPayment'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\ApiExportProductsUpdate'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingMultiShopExport'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingAttributesVariations'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\ApiExportSeoUrls'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingOrderStatus'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingOrderDetailsAttributes'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingOrdersToShops'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingOrderStatusDetail'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingOrderAttributes'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingShopwareCurrencies'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingTaxRates'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingAddressToFreetext'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingShippingAddressToFreetext'),
                $modelManager->getClassMetadata('Shopware\CustomModels\BfMultichannel\MappingOrdersToCustomerGroups')
            )
        );

        (new PluginConfigurations())->installDefaultPluginConfiguration();
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
