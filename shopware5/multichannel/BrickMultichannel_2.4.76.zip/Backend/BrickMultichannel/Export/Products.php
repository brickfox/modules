<?php
/**
 * Products
 *
 * @package   Bf\Multichannel\Components\Export
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Export;

use Bf\Multichannel\Components\ExportAbstract;
use Bf\Multichannel\Components\Resource\Products\Products as ProductExport;
use Bf\Multichannel\Components\Util\Exceptions\SkipItemExportException;
use Bf\Multichannel\Components\Util\FileWriter;
use Exception;
use Shopware\Models\Article\Article;
use XMLWriter;

class Products extends ExportAbstract
{
    public function __construct()
    {
        parent::__construct(array());
    }

    /**
     * @param array|Article|integer $item
     * @param XMLWriter                                     $xmlWriter
     *
     * @throws SkipItemExportException
     * @throws Exception
     */
    protected function processExport($item, XMLWriter $xmlWriter)
    {
        try
        {
            $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Article');
            $item       = $repository->find($item);

            if($item !== null)
            {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter] = array();
                (new ProductExport($item))->prepareProductNode();
            }
        }
        catch(SkipItemExportException $e) {
            throw $e;
        }
        catch(Exception $e)
        {
            throw new Exception($e);
        }

        FileWriter::fromArray($xmlWriter, FileWriter::$xmlElements);
    }
}
