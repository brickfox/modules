<?php

/**
 * Categories
 *
 * @package   Bf\Multichannel\Components\Export
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Export;

use Bf\Multichannel\Components\ExportAbstract;
use Bf\Multichannel\Components\Resource\Categories\Repository as CategoriesRepository;

class Categories extends ExportAbstract
{
    public function __construct()
    {
        parent::__construct(array());
    }

    public function processExport($item, \XmlWriter $xmlWriter)
    {
        $xmlWriter->startElement('Category');
        $xmlWriter->writeAttribute('num', $this->getExportItemsCount());

        $xmlWriter->writeElement('CategoryId', $item['id']);
        $xmlWriter->writeElement('ParentId', $item['parent']);

        $xmlWriter->startElement('Translations');
        $xmlWriter->startElement('Translation');

        //todo mapping translation für multilang hier wird nur die main language von der main kategorie benötigt
        // für test hart hinterlegt.
        $xmlWriter->writeAttribute('lang', 'de');
        $xmlWriter->startElement('Name');
        $xmlWriter->writeCdata($item['description']);

        $xmlWriter->endElement(); // end Name
        $xmlWriter->endElement(); // end Translation
        $xmlWriter->endElement(); // end Translations
        $xmlWriter->endElement(); // end Category
    }
}

