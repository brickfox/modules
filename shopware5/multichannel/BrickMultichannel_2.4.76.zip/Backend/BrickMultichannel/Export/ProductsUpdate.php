<?php
/**
 * ProductsUpdate
 *
 * @package   Bf\Multichannel\Components\Export
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Export;

use Bf\Multichannel\Components\ExportAbstract;
use Bf\Multichannel\Components\Util\FileWriter;
use Symfony\Component\Config\Definition\Exception\Exception;
use Bf\Multichannel\Components\Resource\Products\ProductsUpdate as ProductsUpdateExport;

class ProductsUpdate extends ExportAbstract
{
    public function __construct()
    {
        parent::__construct(array());
    }

    protected function processExport($item, \XmlWriter $xmlWriter)
    {
        try
        {
            $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Article');
            $item       = $repository->find($item);

            if($item !== null)
            {
                FileWriter::$xmlElements['ProductUpdate-' . FileWriter::$internalArrayKeyCounter] = array();
                (new ProductsUpdateExport($item))->prepareNode();

            }
        }
        catch(Exception $e)
        {
            throw new Exception($e);
        }

        FileWriter::fromArray($xmlWriter, FileWriter::$xmlElements);
    }
}
