<?php
/**
 * DeleteFeed
 *
 * @package   Bf\Multichannel\Components\Export
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Export;

use Bf\Multichannel\Components\ExportAbstract;
use Bf\Multichannel\Components\Util\FileWriter;
use Exception;

class DeleteFeed extends ExportAbstract
{
    public function __construct()
    {
        parent::__construct(array());
    }

    public function processExport($articleId, \XMLWriter $XMLWriter)
    {
        try
        {
            FileWriter::$xmlElements['ProductDelete-' . FileWriter::$internalArrayKeyCounter] = array(
                '@attributes'     => array('id' => $articleId),
                'ProductExternId' => array('@value' => $articleId)
            );
        }
        catch(Exception $e)
        {
            throw new Exception($e);
        }

        FileWriter::fromArray($XMLWriter, FileWriter::$xmlElements);
    }
}
