<?php
/**
 * Brands
 *
 * @package   Bf\Multichannel\Components\Export
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Export;

use Bf\Multichannel\Components\ExportAbstract;
use Bf\Multichannel\Components\Util\XmlWriter;

class Brands extends ExportAbstract
{
    public function __construct()
    {
        parent::__construct(array());
    }

    protected function processExport($item, \XmlWriter $xmlWriter)
    {
        if(isset($item['name']) === true)
        {
            $xmlWriter->startElement('Manufacturer');
            $xmlWriter->writeAttribute('num', $this->getExportItemsCount());

            $xmlWriter->writeElement('ManufacturerId', $item['id']);

            $xmlWriter->startElement('Translations');
            $xmlWriter->startElement('Translation');
            $xmlWriter->writeAttribute('lang', 'de');

            $xmlWriter->startElement('Name');
            $xmlWriter->writeCdata($item['name']);

            $xmlWriter->endElement(); // end Name
            $xmlWriter->endElement(); // end Translation
            $xmlWriter->endElement(); // end Translations
            $xmlWriter->endElement(); // end Manufacturer
        }
    }
}
