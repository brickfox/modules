<?php
/**
 * OrdersStatus
 *
 * @package   Bf\Multichannel\Components\Export
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Export;

use Bf\Multichannel\Components\ExportAbstract;
use Bf\Multichannel\Components\Util\Exceptions\SkipItemExportException;
use Bf\Multichannel\Components\Util\FileWriter;
use Bf\Multichannel\Components\Resource\OrdersStatus\OrdersStatus as ExportOrdersStatus;

class OrdersStatus extends ExportAbstract
{
    public function __construct()
    {
        parent::__construct(array());
    }

    /**
     * @param array|\Shopware\Models\Article\Article|\Shopware\Models\Order\Order $item
     * @param \XMLWriter                                                          $XMLWriter
     *
     * @return mixed|void
     * @throws \Exception
     */
    protected function processExport($item, \XMLWriter $XMLWriter)
    {
        try
        {
            FileWriter::$xmlElements['Order-' . FileWriter::$internalArrayKeyCounter] = array();
            (new ExportOrdersStatus($item))->prepareOrdersStatusNode($this->getExportItemsCount());
        }
        catch(SkipItemExportException $e) {
            throw $e;
        }
        catch(\Exception $e)
        {
            throw new \Exception($e);
        }

        FileWriter::fromArray($XMLWriter, FileWriter::$xmlElements);

        $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ExportOrderStatus');
        /** @var \Shopware\CustomModels\BfMultichannel\ExportOrderStatus $exportOrderStatusModel */
        $exportOrderStatusModel = $repository->findOneBy(array('orderId' => $item->getId()));

        if($exportOrderStatusModel !== null)
        {
            $exportOrderStatusModel->setLastExportStatus($item->getOrderStatus()->getId());
            $exportOrderStatusModel->setLastUpdate(new \DateTime());

            Shopware()->Models()->persist($exportOrderStatusModel);
        }
    }
}
