<?php
/**
 * ProductsAssignment
 *
 * @package   Bf\Multichannel\Components\Export
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Export;

use Bf\Multichannel\Components\ExportAbstract;
use Bf\Multichannel\Components\Util\FileWriter;
use Bf\Multichannel\Components\Resource\Products\ProductsAssignment as ExportProductsAssignment;
use Bf\Multichannel\Components\Util\LogCodes;
use Bf\Multichannel\Components\Util\LogManager;
use Exception;

class ProductsAssignment extends ExportAbstract
{
    const EXPORT_TYPE = 'Products Assignment';

    public function __construct()
    {
        parent::__construct(array());
    }

    /**
     * @param array|\Shopware\Models\Article\Article|\Shopware\Models\Order\Order|integer $item
     * @param \XMLWriter                                                                  $XMLWriter
     *
     * @return mixed|void
     * @throws Exception
     */
    protected function processExport($item, \XMLWriter $XMLWriter)
    {
        try
        {
            $repository = Shopware()->Models()->getRepository('Shopware\Models\Article\Article');
            /** @var \Shopware\Models\Article\Article $item */
            $item       = $repository->find($item);

            if($item !== null)
            {
                FileWriter::$xmlElements['Product-' . FileWriter::$internalArrayKeyCounter] = array();
                (new ExportProductsAssignment($item))->prepareProductsAssignmentsNode($this->getExportItemsCount());

                $repository = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiExportProducts');
                /** @var \Shopware\CustomModels\BfMultichannel\ApiExportProducts $apiExportProductsModel */
                $apiExportProductsModel = $repository->findOneBy(array('shopwareId' => $item->getId()));

                if($apiExportProductsModel === null)
                {
                    LogManager::getInstance()->createDbLogEntry(
                        time(),
                        self::EXPORT_TYPE,
                        LogCodes::EXPORT_PRODUCTS_ASSIGNMENTS_CODE,
                        str_replace('{$itemNumber}', $item->getNumber(), LogCodes::EXPORT_PRODUCTS_ASSIGNMENTS)
                    );
                }

                $apiExportProductsModel->setLastAssignmentsExportDate(new \DateTime());

                Shopware()->Models()->persist($apiExportProductsModel);
            }
        }
        catch(Exception $e)
        {
            throw new Exception($e);
        }

        FileWriter::fromArray($XMLWriter, FileWriter::$xmlElements);
    }
}
