<?php
/**
 * ImportController
 *
 * @package   Bf\Multichannel\Components
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components;

use Bf\Multichannel\Components\Import\Orders;
use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\Download;
use Bf\Multichannel\Components\Util\FileManager;
use Bf\Multichannel\Components\Util\ScriptLogger;
use Bf\Multichannel\Components\Util\LogManager;

class ImportController
{
    public function importAll()
    {
        $this->importOrders();
        $this->processOrders();
    }

    /**
     * @param $ignoreWaitingTime
     */
    public function downloadOrdersFromBrickfoxToShopware($ignoreWaitingTime)
    {
        $downLoadClass = new Download(
            ConfigManager::getInstance()->getFtpUser()->getConfigurationValue(),
            ConfigManager::getInstance()->getFtpPass()->getConfigurationValue(),
            ConfigManager::getInstance()->getFtpHost()->getConfigurationValue(),
            ConfigManager::getInstance()->getFtpSslPort()->getConfigurationValue()
        );

        $downLoadClass->prepareItemDownload($ignoreWaitingTime);
    }

    public function importOrders()
    {
        ScriptLogger::getInstance()->run('import/Orders');
        $fileToImport = FileManager::getInstance()->getImportFiles(FileManager::FILENAME_BASE_ORDERS);
        $importer     = new Orders();
        $this->import($fileToImport, $importer, __FUNCTION__);
    }

    public function processOrders()
    {
        ScriptLogger::getInstance()->run('import/ProcessOrders');
        $importer = new Orders();
        $this->process($importer, __FUNCTION__);
    }

    /**
     * @param array          $filesToImport
     * @param ImportAbstract $importer
     * @param                $methodName
     */
    private function import(array $filesToImport, ImportAbstract $importer, $methodName)
    {
        foreach($filesToImport as $importFile)
        {
            try
            {
                $importer->import($importFile);
                FileManager::getInstance()->moveImportFile($importFile);

            }
            catch(\Exception $exception)
            {
                ScriptLogger::getInstance()->errorHandler($exception->getCode(), $exception->getMessage(), $exception->getFile(), $exception->getLine());
                LogManager::getInstance()->logException($exception, $methodName);
            }
        }
    }

    private function process(ImportAbstract $importAbstract, $methodName)
    {
        $repository               = Shopware()->Models()->getRepository('Shopware\CustomModels\BfMultichannel\ApiImportOrders');
        $apiImportOrdersListModel = $repository->findBy(array('processed' => 0));
        $isIncreaseInnoDBLockWaitTimeoutEnabled = ConfigManager::getInstance()->isIncreaseInnoDBLockWaitTimeoutEnabled();

        /** @var \Shopware\CustomModels\BfMultichannel\ApiImportOrders $apiImportOrdersModel */
        foreach($apiImportOrdersListModel as $apiImportOrdersModel)
        {
            try {
                $importAbstract->process($apiImportOrdersModel, $isIncreaseInnoDBLockWaitTimeoutEnabled);
            } catch (\Exception $exception) {
                continue;
            }
        }
    }
}
