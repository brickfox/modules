<?php

/**
 * Orders
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Components\Import;

use Bf\Multichannel\Components\ImportAbstract;
use Bf\Multichannel\Components\Util\ConfigManager;
use Bf\Multichannel\Components\Util\Helper;
use Shopware\Models\Order\Order as SwOrder;
use Shopware\Models\Partner\Partner as SwPartner;

class Orders extends ImportAbstract
{
    /**
     * @param \SimpleXMLElement $simpleXMLElement
     *
     * @return mixed
     * @throws \Exception
     */
    protected function processImport(\SimpleXMLElement $simpleXMLElement)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Order\Order');

        if((bool) Helper::getConfigurationByKey('useExternOrdersNumberAsShopwareOrdersNumber')->getConfigurationValue() === true)
        {
            $orderModel = $repository->findOneBy(
                array(
                    'number' => (string)$simpleXMLElement->ExternOrderId
                )
            );
        }
        else
        {
            if(ConfigManager::getInstance()->isOrderDisablePartnerImport() === false) {
                $orderModel = $repository->findOneBy(
                    array(
                        'partner'     => $this->preparePartner(),
                        'temporaryId' => (string)$simpleXMLElement->OrderId
                    )
                );
            } else {
                $orderModel = $repository->findOneBy(
                    array(
                        'temporaryId' => (string)$simpleXMLElement->OrderId
                    )
                );
            }
        }

        if ($orderModel !== null) {
            //throw exception
            throw new \Exception('Die Bestellung wurde bereits Importiert.');
        }

        $newOrderModel = (new \Bf\Multichannel\Components\Resource\Orders\Orders($simpleXMLElement, new SwOrder()))->prepareImportOrdersInformation();

        return $newOrderModel;
    }

    /**
     * @return SwPartner
     */
    private function preparePartner()
    {
        $repository   = Shopware()->Models()->getRepository('Shopware\Models\Partner\Partner');
        $partnerModel = $repository->findOneBy(array('idCode' => \Bf\Multichannel\Components\Resource\Orders\Orders::BRICKFOX_ID_CODE));

        if ($partnerModel === null) {
            $partnerModel = new SwPartner();
            $partnerModel->setActive(1);
            $partnerModel->setIdCode(\Bf\Multichannel\Components\Resource\Orders\Orders::BRICKFOX_ID_CODE);
            $partnerModel->setDate(new \DateTime());
            $partnerModel->setCity('');
            $partnerModel->setStreet('');
            $partnerModel->setCompany(\Bf\Multichannel\Components\Resource\Orders\Orders::BRICKFOX_ID_CODE);
            $partnerModel->setZipCode('');
            $partnerModel->setContact('');
            $partnerModel->setCookieLifeTime(0);
            $partnerModel->setCountryName('');
            $partnerModel->setEmail('');
            $partnerModel->setFax('');
            $partnerModel->setFix(0.00);
            $partnerModel->setPercent(0.00);
            $partnerModel->setWeb('');
            $partnerModel->setProfile('');
            $partnerModel->setPhone('');

            Shopware()->Models()->persist($partnerModel);
        }

        return $partnerModel;
    }
}
