<?php
/**
 * InstallAbstract
 *
 * @package   Bf\Saleschannel\Install
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Install;

use Shopware_Components_Plugin_Bootstrap;

class InstallAbstract
{
    /** @var Shopware_Components_Plugin_Bootstrap */
    private $shopwarePluginBootstrapClass = null;

    /**
     * @param Shopware_Components_Plugin_Bootstrap $shopwarePluginBootstrapClass
     */
    public function __construct($shopwarePluginBootstrapClass)
    {
        $this->shopwarePluginBootstrapClass = $shopwarePluginBootstrapClass;
    }

    /**
     * @return Shopware_Components_Plugin_Bootstrap
     */
    public function getShopwarePluginBootstrapClass()
    {
        return $this->shopwarePluginBootstrapClass;
    }

    /**
     * @param Shopware_Components_Plugin_Bootstrap $shopwarePluginBootstrapClass
     *
     * @return InstallAbstract
     */
    public function setShopwarePluginBootstrapClass($shopwarePluginBootstrapClass)
    {
        $this->shopwarePluginBootstrapClass = $shopwarePluginBootstrapClass;

        return $this;
    }

    public function __destruct()
    {
        $this->shopwarePluginBootstrapClass = null;
    }
}
