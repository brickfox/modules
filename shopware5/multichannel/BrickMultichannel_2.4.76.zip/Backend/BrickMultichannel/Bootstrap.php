<?php

use Bf\Multichannel\Patches;

/**
 * Bootstrap
 * This file is part of brickfox.
 *
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */
class Shopware_Plugins_Backend_BrickMultichannel_Bootstrap extends Shopware_Components_Plugin_Bootstrap
{
    public function install()
    {
        if (version_compare(PHP_VERSION, '5.4.0') < 0) {
            return ['success' => false, 'message' => 'Ihr System erfüllt nicht die mindest PHP-Version von 5.4.0 bitte wenden Sie sich an Ihren Hoster.'];
        }

        $this->createDatabase();
        $this->registerEvents();
        $this->registerMenuItem();
        $this->registerCronJobs();
        $this->createDirectories();

        return ['success' => true, 'invalidateCache' => ['backend', 'config']];
    }

    private function createDatabase()
    {
        $this->registerCustomModels();

        (new \Bf\Multichannel\Install\CreateDatabase($this))->executeCreateDatabase();
    }

    private function registerEvents()
    {
        (new \Bf\Multichannel\Install\RegisterEvents($this))->executeRegisterEvents();
    }

    private function registerMenuItem()
    {
        (new \Bf\Multichannel\Install\RegisterMenu($this))->executeRegisterMenu();
    }

    private function registerCronJobs()
    {
        $this->createCronJob('BfMultichannelExport', 'BfMultichannelExportCron', 3600, 1);

        $this->subscribeEvent('Shopware_CronJob_BfMultichannelExportCron', 'onRunMultichannelExportCron');

        $this->createCronJob('BfMultichannelImport', 'BfMultichannelImportCron', 1800, 1);

        $this->subscribeEvent('Shopware_CronJob_BfMultichannelImportCron', 'onRunMultichannelImportCron');
    }

    private function createDirectories()
    {
        (new \Bf\Multichannel\Install\CreateDirectories($this))->executeCreateDirectories();
    }

    /**
     * @param Enlight_Event_EventArgs $args
     */
    public function preUpdateArticle(Enlight_Event_EventArgs $args)
    {
        /** \Shopware\Models\Article\Article $model */
        $model = $args->get('entity');

        $modelEvents = new \Bf\Multichannel\Components\Util\ModelEvents($model);
        $modelEvents->loadApiExportProductsModel();
        $modelEvents->updateArticleLastUpdate();
    }

    /**
     * @param Enlight_Event_EventArgs $args
     */
    public function preUpdateDetail(Enlight_Event_EventArgs $args)
    {
        $model = $args->get('entity');

        $modelEvents = new \Bf\Multichannel\Components\Util\ModelEvents($model);
        $modelEvents->loadApiExportProductsModel();
        $modelEvents->updateArticleLastUpdate();
    }

    /**
     * @param Enlight_Event_EventArgs $args
     */
    public function preRemoveArticle(Enlight_Event_EventArgs $args)
    {
        $model = $args->get('entity');

        $modelEvents = new \Bf\Multichannel\Components\Util\ModelEvents($model);
        $modelEvents->loadApiExportProductsModel();
        $modelEvents->updateApiExportEntry();
    }

    /**
     * @param Enlight_Event_EventArgs $args
     */
    public function onRunMultichannelExportCron(Enlight_Event_EventArgs $args)
    {
        $exportController = new \Bf\Multichannel\Components\ExportController();
        $exportController->exportAll();
    }

    /**
     * @param Enlight_Event_EventArgs $args
     */
    public function onRunMultichannelImportCron(Enlight_Event_EventArgs $args)
    {
        $importController = new \Bf\Multichannel\Components\ImportController();
        $importController->importAll();
    }

    /**
     * @return array
     */
    public function uninstall()
    {
        $this->removeDatabase();

        return ['success' => true, 'invalidateCache' => ['backend', 'config']];
    }

    private function removeDatabase()
    {
        (new \Bf\Multichannel\Install\RemoveDatabase($this))->executeRemoveDatabase();
    }

    /**
     * @param $version
     *
     * @return bool
     */
    public function update($version)
    {
        switch ($version) {
            case '1.0.0':
            case '1.0.1':
                (new Bf\Multichannel\Patches\SCRIPT\PatchUseExternOrdersNumberAsShopwareOrdersNumber($this))->preparePatch();
            case '1.0.2':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddScriptLoggerConfiguration($this))->preparePatch();
            case '1.0.3':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddPaymentMapping($this))->preparePatch();
            case '1.0.4':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddNewMenu($this))->preparePatch();
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddNewMenuEvents($this))->preparePatch();
            case '1.0.5':
            case '1.0.6':
            case '1.0.7':
            case '1.0.8':
            case '1.0.9':
            case '1.1.0':
            case '1.1.1':
            case '1.1.2':
            case '1.1.3':
            case '1.1.4':
            case '1.1.5':
            case '1.1.6':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddApiExportProductsUpdateModel($this))->preparePatch();
            case '1.1.7':
            case '1.1.8':
            case '1.1.9':
            case '1.2.0':
            case '1.2.1':
            case '1.2.2':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddProductsExportAttributesConfiguration($this))->preparePatch();
            case '1.2.3':
            case '1.2.4':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddMultiShopExportModelAndConfiguration($this))->preparePatch();
            case '1.2.5':
            case '1.2.6':
            case '1.2.7':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddAttributeAsBulletConfiguration($this))->preparePatch();
            case '1.2.8':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddAttributesVariationsMapping($this))->preparePatch();
            case '1.2.9':
            case '1.3.0':
            case '2.0.0':
            case '2.0.1':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddBulletsAsAttributesConfiguration($this))->preparePatch();
            case '2.0.2':
            case '2.0.3':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddApiExportSeoUrls($this))->preparePatch();
            case '2.0.4':
            case '2.0.5':
            case '2.0.6':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddServerProtocolConfiguration($this))->preparePatch();
            case '2.0.7':
            case '2.0.8':
            case '2.0.9':
            case '2.1.0':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddOrderAttributesConfiguration($this))->preparePatch();
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddMappingOrderStatus($this))->preparePatch();
            case '2.1.1':
            case '2.1.2':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddIsNetCurrenciesMappingField($this))->preparePatch();
            case '2.1.3':
            case '2.1.4':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddProFtpConfiguration($this))->preparePatch();
            case '2.1.5':
            case '2.1.6':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddFallbackFieldKeyColumn($this))->preparePatch();
            case '2.1.7':
            case '2.1.8':
            case '2.1.9':
            case '2.2.0':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddMappingOrderDetailsAttr($this))->preparePatch();
            case '2.2.1':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddOrdersLinesIdAttributesFieldConfiguration($this))->preparePatch();
            case '2.2.2':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddMappingOrdersToShops($this))->preparePatch();
            case '2.2.3':
            case '2.2.4':
            case '2.2.5':
            case '2.2.6':
            case '2.2.7':
            case '2.2.8':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddExportOrderLineStatusConfiguration($this))->preparePatch();
            case '2.2.9':
            case '2.2.10':
            case '2.2.11':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddCustomerOrderNumberAttributesFieldConfiguration($this))->preparePatch();
            case '2.2.12':
            case '2.2.13':
            case '2.2.14':
            case '2.2.15':
            case '2.2.16':
            case '2.2.17':
            case '2.2.18':
            case '2.2.19':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddMappingOrderAttr($this))->preparePatch();
            case '2.2.21':
            case '2.2.22':
            case '2.2.23':
            case '2.2.24':
            case '2.2.25':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddDetailsOrdersStatusMapping($this))->preparePatch();
            case '2.2.26':
            case '2.2.27':
            case '2.2.28':
            case '2.2.29':
            case '2.2.30':
            case '2.2.31':
            case '2.2.32':
            case '2.2.33':
            case '2.2.34':
            case '2.2.35':
            case '2.2.36':
            case '2.2.37':
            case '2.2.38':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddCleanScriptLoggerAfterDays($this))->preparePatch();
            case '2.2.39':
            case '2.2.40':
            case '2.2.41':
            case '2.2.42':
            case '2.2.43':
            case '2.2.44':
            case '2.2.45':
            case '2.2.46':
            case '2.2.47':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddShopwareCurrenciesMapping($this))->preparePatch();
            case '2.2.48':
            case '2.2.49':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddOrderAttributesFieldReturnTrackingIdConfiguration($this))->preparePatch();
            case '2.3.0':
            case '2.3.1':
            case '2.3.2':
            case '2.3.3':
            case '2.3.4':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddShopwareTaxRatesMapping($this))->preparePatch();
            case '2.3.5':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddInvoiceConfiguration($this))->preparePatch();
            case '2.3.6':
            case '2.3.7':
            case '2.3.8':
            case '2.3.9':
            case '2.4.0':
            case '2.4.1':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddShopsOrderIdToCommentField($this))->preparePatch();
            case '2.4.2':
            case '2.4.3':
            case '2.4.4':
            case '2.4.5':
            case '2.4.6':
            case '2.4.7':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddISBNFromAttributeConfiguration($this))->preparePatch();
            case '2.4.8':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddSkipArticlesWithoutVariationsConfig($this))->preparePatch();
            case '2.4.9':
            case '2.4.10':
            case '2.4.11':
            case '2.4.12':
            case '2.4.13':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddMarketplaceAndCustomerIdToCommentField($this))->preparePatch();
                (new Bf\Multichannel\Patches\SCRIPT\PatchRenameShopsOrderIdCommentFieldToShopsInformationCommentField($this))->preparePatch();
            case '2.4.14':
            case '2.4.15':
            case '2.4.16':
            case '2.4.17':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddOrderDisablePartnerImportConfig($this))->preparePatch();
            case '2.4.18':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddOrderCarrierColumnNameConfiguration($this))->preparePatch();
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddOrderTrackingIdColumnNameConfiguration($this))->preparePatch();
            case '2.4.19':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddOrderPartnerIdIncludeSalesChannelNameImportConfig($this))->preparePatch();
            case '2.4.20':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddExportMultivaluedPropertiesAsSingleAttributes($this))->preparePatch();
            case '2.4.21':
            case '2.4.22':
            case '2.4.23':
            case '2.4.24':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddIncreaseInnoDbLockWaitTimeoutConfiguration($this))->preparePatch();
            case '2.4.25':
            case '2.4.26':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddImportedOrderStatusConfiguration($this))->preparePatch();
            case '2.4.27':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddMappingActionToScriptTimeLimit($this))->preparePatch();
            case '2.4.28':
            case '2.4.29':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddAddressToFreetextMapping($this))->preparePatch();
            case '2.4.30':
            case '2.4.31':
            case '2.4.32':
            case '2.4.33':
            case '2.4.34':
            (new Bf\Multichannel\Patches\SCRIPT\PatchAddCustomerGroupConfiguration($this))->preparePatch();
            case '2.4.35':
            case '2.4.36':
            case '2.4.37':
            case '2.4.38':
            case '2.4.39':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddMappingOrdersToCustomerGroups($this))->preparePatch();
            case '2.4.40':
            case '2.4.41':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddShippingAddressToFreetextMapping($this))->preparePatch();
            case '2.4.42':
            case '2.4.43':
            case '2.4.44':
            case '2.4.45':
            case '2.4.46':
            case '2.4.47':
            case '2.4.48':
            case '2.4.49':
            case '2.4.50':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddOrderStatusExportUsesPickware($this))->preparePatch();
            case '2.4.51':
            case '2.4.52':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddOrderNumberInCommentField($this))->preparePatch();
            case '2.4.53':
            case '2.4.54':
            case '2.4.55':
            case '2.4.56':
            case '2.4.57':
            case '2.4.58':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddOrderCarrierColumnNameMainConfiguration($this))->preparePatch();
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddOrderTrackingIdColumnNameMainConfiguration($this))->preparePatch();
            case '2.4.59':
            case '2.4.60':
            case '2.4.61':
            case '2.4.62':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddBaseProductExportPreviewImageAlwaysConfig($this))->preparePatch();
            case '2.4.63':
            case '2.4.64':
            case '2.4.65':
            case '2.4.66':
            case '2.4.67':
            case '2.4.68':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddEnableOrderImportWithItemNumberConfig($this))->preparePatch();
            case '2.4.69':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddOrderStatusForOrdersWithCommentConfiguration($this))->preparePatch();
            case '2.4.70':
            case '2.4.71':
            case '2.4.72':
                (new Bf\Multichannel\Patches\SCRIPT\PatchAddUsePickwareCompabilityConfig($this))->preparePatch();
            default:
                break;
        }

        return true;
    }

    /**
     * @return string
     */
    public function onGetControllerPath()
    {
        if ($this->assertMinimumVersion('5.1')) {
            \Bf\Multichannel\Components\Util\ConfigManager::getInstance()->setShopwareVersion(5.1);
        }

        return $this->Path() . 'Controllers/Backend/Brickfox.php';
    }

    /**
     * @param Enlight_Event_EventArgs $args
     *
     * @return string
     */
    public function onGetUiControllerPath(Enlight_Event_EventArgs $args)
    {
        //register template dir
        $this->Application()->Template()->addTemplateDir($this->Path() . 'Views/');

        $this->registerCustomModels();

        return $this->Path() . '/Controllers/Backend/BrickfoxUi.php';
    }

    /**
     * @param Enlight_Event_EventArgs $args
     *
     * @return string
     */
    public function onGetUiControllerLogPath(Enlight_Event_EventArgs $args)
    {
        //register template dir
        $this->Application()->Template()->addTemplateDir($this->Path() . 'Views/');

        $this->registerCustomModels();

        return $this->Path() . '/Controllers/Backend/BrickfoxUiLog.php';
    }

    /**
     * @param Enlight_Event_EventArgs $args
     *
     * @return string
     */
    public function onGetUiControllerErrorCodeListPath(Enlight_Event_EventArgs $args)
    {
        //register template dir
        $this->Application()->Template()->addTemplateDir($this->Path() . 'Views/');

        $this->registerCustomModels();

        return $this->Path() . '/Controllers/Backend/BrickfoxUiErrorCodeList.php';
    }

    /**
     * @param Enlight_Event_EventArgs $args
     */
    public function onPostDispatchBackendIndex(Enlight_Event_EventArgs $args)
    {
        $request = $args->getSubject()->Request();
        $path    = str_replace('Bootstrap.php', 'style.css', __FILE__);
        $path    = preg_replace('!^(?:.*?)(/engine/Shopware.*?)$!', '$1', $path);
        $path    = str_replace('/shopware.php', '', $_SERVER['PHP_SELF']) . $path;
        $path    .= '?' . urlencode($this->getVersion());
        if ($request->getActionName() == 'index') {
            $view = $args->getSubject()->View();
            $view->extendsBlock('backend/base/header/css', '<link href="' . $path . '" type="text/css" rel="stylesheet">', 'append');
        }
    }

    public function getVersion()
    {
        return '2.4.76';
    }

    /**
     * @param $plugins
     *
     * @return mixed
     */
    public function assertRequiredPluginsPresent($plugins)
    {
        return parent::assertRequiredPluginsPresent($plugins);
    }

    public function getCapabilities()
    {
        return [
            'install' => true,
            'update'  => true,
            'enable'  => true
        ];
    }

    public function getInfo()
    {
        $banner = base64_encode(file_get_contents(dirname(__FILE__) . '/banner.png'));

        return [
            'version'     => $this->getVersion(),
            'label'       => $this->getLabel(),
            'supplier'    => 'brickfox GmbH',
            'author'      => 'brickfox GmbH',
            'description' => '<img src="data:image/png;base64,' . $banner . '" />',
            'copyright'   => 'Copyright © 2015, brickfox GmbH',
            'support'     => 'support@brickfox.de',
            'link'        => 'http://www.brickfox.de'
        ];
    }

    public function getLabel()
    {
        return 'Brickfox';
    }

    public function afterInit()
    {
        set_time_limit(60 * 60 * 12);
        $this->registerCustomModels();

        $this->Application()->Loader()->registerNamespace('Bf\Multichannel', $this->Path());
    }
}
