<?php
/**
 * RemoveDatabase
 *
 * @package   Bf\Saleschannel\Install
 *            This file is part of brickfox.
 * @author    brickfox GmbH <support@brickfox.de>
 * @copyright Copyright (c) 2011-2014 brickfox GmbH http://www.brickfox.de
 */

namespace Bf\Multichannel\Install;

class RemoveDatabase extends InstallAbstract
{
    /**
     * @param \Shopware_Components_Plugin_Bootstrap $shopwarePluginBootstrapClass
     */
    public function __construct($shopwarePluginBootstrapClass)
    {
        parent::__construct($shopwarePluginBootstrapClass);
    }

    public function executeRemoveDatabase()
    {
        $sql = "DROP TABLE IF EXISTS bf_configuration;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_scriptlogger;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_export_products;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_translation;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_currencies;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_export_images;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_export_media;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_import_orders;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_export_order_status;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_export_log;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_gui_log;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_payment;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_export_products_update;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_multi_shop_export;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_attr_variations;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_api_export_seo_urls;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_order_status;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_orders_to_shops;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_order_details_attr;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_order_attr;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_order_status_detail;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_shopware_currencies;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_tax_rates;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_shipping_address_to_freetext;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_address_to_freetext;";
        Shopware()->Db()->query($sql);

        $sql = "DROP TABLE IF EXISTS bf_mapping_orders_to_customergroups;";
        Shopware()->Db()->query($sql);
    }

    public function __destruct()
    {
        parent::__destruct();
    }
}
